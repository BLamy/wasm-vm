#!/usr/bin/env python3
"""Hash independent literal pixel matrices against the recorded physical frames."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BLACK, RED, GREEN, BLUE = [0,0,0,255], [255,0,0,255], [0,255,0,255], [0,0,255,255]
FULL = {'mid-depth occluder':BLUE, 'z=0.999 behind mid-depth':BLUE,
        'z=-0.999 in front of mid-depth':GREEN, 'depth disabled adjacent draw':RED,
        'empty scissor excludes all fragments':BLACK, 'empty update retains full scissor':GREEN,
        'lower-left Gallium winding':RED, 'opposite winding is culled':BLACK,
        'negative-Y winding reverses with coordinates':RED,
        'depth write mask false preserves middle depth':GREEN,
        'adjacent disabled depth blend scissor positive-Y':GREEN}


def matrix(predict):
    return bytes(value for y in range(16) for x in range(16) for value in predict(x,y))


def main():
    checks=[]
    for prefix in ['unpacked/hot','unpacked/cold','acceptance-replay']:
        path=HERE/prefix/('hardware/report.json' if prefix.startswith('unpacked') else 'report.json')
        report=json.loads(path.read_bytes())
        result=report['browserResult']['result']
        def check(frame,predict):
            expected=hashlib.sha256(matrix(predict)).hexdigest()
            assert frame['sha256']==expected, frame['label']
            assert frame['checkedPixels']==256
            checks.append({'record':path.relative_to(HERE).as_posix(),'scene':frame['label'],'expectedSha256':expected,'observedSha256':frame['sha256'],'held':True})
        for frame in result['literals']['frames']:
            label=frame['label']
            if label in FULL:
                check(frame,lambda x,y,c=FULL[label]:c)
            elif label=='lower-left scissor and full clear':
                check(frame,lambda x,y:GREEN if 3<=x<10 and 5<=y<11 else BLACK)
            elif label=='adjacent depth blend scissor orientation':
                check(frame,lambda x,y:[64,0,191,255] if 4<=x<12 and 4<=y<12 else BLUE)
            else:
                assert label=='positive/negative Y'
        for func,frame in enumerate(result['literals']['compares']):
            color=RED if func in [2,3,6,7] else BLACK
            check(frame,lambda x,y,c=color:c)
        for frame,x0,color in zip(result['restored']['frames'],[1,8,1],[RED,GREEN,RED]):
            check(frame,lambda x,y,x0=x0,c=color:c if x0<=x<x0+6 and 2<=y<11 else BLACK)
        for job in result['jobs']:
            check(job['frame'],lambda x,y:BLUE)
        samples={'positive-Y asymmetric triangle 2,2':RED,'positive-Y asymmetric triangle 13,13':BLACK,
                 'positive-Y asymmetric triangle 2,11':RED,'positive-Y asymmetric triangle 11,2':RED,
                 'negative-Y asymmetric triangle 2,13':RED,'negative-Y asymmetric triangle 13,2':BLACK,
                 'negative-Y asymmetric triangle 2,4':RED,'negative-Y asymmetric triangle 13,15':RED}
        for prediction,color in samples.items():
            row,= [row for row in result['assertions'] if row['prediction']==prediction]
            assert row['expected']==row['observed']==color and row['held']
    audit={'schema':1,'task':'E6-T12h','status':'passed','literalMatrices':len(checks),'asymmetricSamples':24,
           'noOriginalArtworkExpectedHashes':True,'checks':checks}
    (HERE/'pixel-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    print(json.dumps({'status':'passed','literalMatrices':len(checks),'asymmetricSamples':24}))


if __name__=='__main__':
    main()
