#!/usr/bin/env python3
"""Bind critic captures, sabotage, carry-forward boundary and diff classifications."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
BASE='10adfaaf3badf5f70ad9375f4e0bff6a615418f6'
SOURCE='49c408e10b2a5126157f099765b2da6890dd2c16'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT)


def main():
    proof={}
    worker=json.loads((HERE/'unpacked/hot/receipt.json').read_bytes())
    for leaf in ['independent','sabotage-rgb-tail','acceptance-replay']:
        path=HERE/leaf
        report=json.loads((path/'report.json').read_bytes())
        assert report['gitHead']=='e07ca745888b0119ea86133acc179a9b982a0411'
        assert report['browserErrors']=={'console':[],'page':[],'requests':[]}
        assert report['browser']['headless'] is False
        gpu=report['browser']['gpu']['featureStatus']
        assert gpu.get('webgl2',gpu.get('webgl'))=='enabled'
        served={f['path']:f for f in report['servedFiles']}
        mutation=report.get('sabotage',{})
        for item in report['sources']:
            name=item['path']
            raw=(ROOT/name).read_bytes()
            assert len(raw)==item['bytes'] and sha(raw)==item['sha256']
            if name in worker['sources']:
                assert item['sha256']==worker['sources'][name]
            if name in worker['generated']:
                assert item['sha256']==worker['generated'][name]
            if '/'+name in served:
                expected=mutation['servedSha256'] if name==mutation.get('path') else item['sha256']
                assert served['/'+name]['sha256']==expected
        if leaf=='acceptance-replay':
            assert report['status']==report['browserResult']['status']=='passed'
            assert len(report['native']['assertions'])==157 and len(report['browserResult']['result']['assertions'])==759
            assert sha((path/report['screenshot']['path']).read_bytes())==report['screenshot']['sha256']
            assert sha((path/report['browserCoverage']['path']).read_bytes())==report['browserCoverage']['sha256']
            for item in report['inputs']:
                assert sha(git('show',SOURCE+':'+item['path']))==item['sha256']
            result=report['browserResult']['result']
            assert report['native']==report['browserResult']['native']
            assert all(row['held'] for row in result['assertions'])
        else:
            assert sha((path/'browser.png').read_bytes())==report['screenshotSha256']
            assert sha((path/'browser-coverage.json').read_bytes())==report['coverageSha256']
            if leaf=='independent':
                result=report['result']
                assert report['status']==result['status']=='passed' and all(row['held'] for row in result['assertions'])
                assert len(result['assertions'])==346
                assert [row['seed'] for row in result['schedules']]==[1956311333,2789420567,728079433]
                assert all(row['gpuComplete'] for row in result['schedules'])
                exact,short,strip=result['frames']
                assert exact['sha256']==short['sha256']==sha(bytes([255,0,0,255]*256))
                assert strip['sha256']==sha(bytes([0,255,0,255]*256))
                assert all(row['frame']['sha256']==sha(bytes([0,0,255,255]*256)) for row in result['schedules'])
            else:
                assert report['status']==report['result']['status']=='failed'
                assert report['result']['error']['message']=='RGB68 truncated final component issues no draw: expected 1, got 2'
                original=git('show',SOURCE+':'+mutation['path'])
                fault=(path/'fault-source.mjs').read_bytes()
                assert original.count(mutation['needle'].encode())==1
                assert fault==original.replace(mutation['needle'].encode(),mutation['replacement'].encode())
                assert sha(original)==mutation['originalSha256'] and sha(fault)==mutation['servedSha256']
        proof[leaf]={'status':report['status'],'reportSha256':sha((path/'report.json').read_bytes()),'browserErrors':report['browserErrors']}
    # Carry the already-reviewed G6 critic seal forward, rather than rerunning numerical leaves.
    directory='evidence/virgl-required-formats/verifier/'
    manifest_raw=git('show',BASE+':'+directory+'manifest.json')
    packed=git('show',BASE+':'+directory+'recording.tar.gz')
    index_raw=git('show',BASE+':'+directory+'records.json')
    for name,raw in [('manifest.json',manifest_raw),('recording.tar.gz',packed),('records.json',index_raw)]:
        assert raw==(ROOT/directory/name).read_bytes()
    manifest=json.loads(manifest_raw)
    assert manifest['archiveSha256']==sha(packed) and manifest['recordIndexSha256']==sha(index_raw)
    records=json.loads(index_raw)['records']
    expected={r['path']:r for r in records}
    with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as archive:
        names=[]
        for member in archive:
            assert member.isfile() and member.name not in names
            raw=archive.extractfile(member).read()
            assert len(raw)==expected[member.name]['bytes'] and sha(raw)==expected[member.name]['sha256']
            names.append(member.name)
        assert set(names)==set(expected)
    unchanged={}
    changed={}
    for name,digest in worker['sources'].items():
        try:
            previous=git('show',BASE+':'+name)
        except subprocess.CalledProcessError:
            changed[name]='new H harness or documentation'
            continue
        if sha(previous)==digest:
            unchanged[name]=digest
        else:
            changed[name]='H decoder/state behavior or its affected harness/documentation; current authenticated gates cover this boundary'
    for name in ['renderer/virgl-command/resources.mjs','renderer/virgl-command/constant-domain.mjs','renderer/virgl-shader/index.mjs','renderer/virgl-shader/bridge.c','renderer/virgl-shader/UPSTREAM.json']:
        assert name in unchanged
    assert not git('diff','--name-only',BASE+'..'+SOURCE,'--','renderer/virgl-shader').strip()
    carry={'schema':1,'status':'passed','base':BASE,'reviewedPredecessorCriticArchiveSha256':sha(packed),'reviewedPredecessorCriticIndexSha256':sha(index_raw),
           'reviewedCriticMembers':len(records),'unchangedSourceBindings':unchanged,'changedSourceBindings':changed,
           'retainedCurrentG5ReceiptSha256':sha((HERE/'unpacked/hot/regression/receipt.json').read_bytes()),
           'reason':'Unchanged compiler/resource dependency proof remains HELD. Changed decoder/state and affected tests execute on the current frozen source; no workspace/numerical wall or second cold clone was required.'}
    (HERE/'carry-forward.json').write_text(json.dumps(carry,indent=2)+'\n')
    classifications={
        'renderer/virgl-command/decoder.mjs':'All22 added executable lines execute in authenticated precise V8 ranges; native guard branches record157 predictions in both Node/browser.',
        'renderer/virgl-command/state.mjs':'All72 added executable lines execute in authenticated precise V8 ranges; four comments are waived. Separate literal/adjacent/A-B-A/fetch/async scenes cover new behavior.',
        'renderer/virgl-command/tests/raster-depth.mjs':'Native/browser test entry points execute and literal expected matrices independently match81 hot/cold/replay frame hashes. Test-only optional helper branches are validation scaffolding, not product behavior.',
        'renderer/virgl-command/tests/{acceptance,depth-formats,draw-acceptance,state-acceptance}.mjs':'Each adjusted historical assertion is executed in the current retained decoder/depth/draw/state reports. Changed rejection cases track the newly admitted H boundary.',
        'renderer/virgl-command/tests/raster-depth-boundaries.mjs':'Promoted physical regression executes346 predictions, three independent owned schedules and its isolated final-fetch predicate sabotage.',
        'tools/virgl-command/raster-fixtures.mjs':'Complete original capture selection, raw packet joins and CPU input assembly execute in hot/cold and direct replay; independent wire_audit.py reproduces the state without these helpers.',
        'tools/verify-virgl-raster-depth.mjs':'Node guards, physical server/capture/report paths and all five fault replacements execute in sealed hot/cold recordings; node-only mode and infrastructure failure handling are waived as validation plumbing.',
        'tools/verify-virgl-raster-depth.sh and Makefile':'Risk-tier recipe executes in hot/cold acceptance.log and cold/cold.log. The four added Makefile lines are declarative routing.',
        'tools/virgl-command/raster-{receipt,cold,seal}.py':'Receipt and sealing programs ran at frozen head; cold report records the once-only exact-head pristine gate. Non-happy infrastructure cleanup/rejection branches are waived as proof plumbing; verifier independently authenticates custody.',
        'renderer/virgl-command/*README.md, tools/virgl-command/raster-README.md':'Documentation only; primary pinned upstream Git source independently confirms coordinate/full-clear convention and current source confirms shader-key dependencies.',
        'tasks/QUEUE.md and task frontmatter/log; sealed evidence':'Lifecycle/declarative metadata and immutable records; no product runtime behavior.'}
    audit={'schema':1,'task':'E6-T12h','status':'passed','sourceHead':SOURCE,'proof':proof,'classifications':classifications,
           'unexpectedPanicsIgnoredTestsOrDisabledAssertions':False,'productionWebImportsChanged':False,'rrRequired':False,
           'noRuntimeOrWorkerHarnessEditsByVerifier':True}
    (HERE/'review-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    print(json.dumps({'status':'passed','proof':proof,'carriedCriticRecords':len(records),'unchangedSourceBindings':len(unchanged)},indent=2))


if __name__=='__main__':
    main()
