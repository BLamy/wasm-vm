#!/usr/bin/env python3
"""Seal the independent H critic records; never includes unrelated untracked evidence."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    names=['predictions.json','authenticate.py','authentication.json','coverage_audit.py','coverage-audit.json',
           'wire_audit.py','wire-audit.json','pixel_audit.py','pixel-audit.json','source-conventions.json','pinned-vrend-renderer.c',
           'review_audit.py','review-audit.json','carry-forward.json','write_verdict.py','verdict.json','seal.py']
    for leaf in ['independent','sabotage-rgb-tail','acceptance-replay']:
        names.extend(f'{leaf}/{name}' for name in ['report.json','browser.png','browser-coverage.json'])
    names.append('sabotage-rgb-tail/fault-source.mjs')
    members={name:(HERE/name).read_bytes() for name in names}
    members['promoted/raster-depth-boundaries.mjs']=(ROOT/'renderer/virgl-command/tests/raster-depth-boundaries.mjs').read_bytes()
    verdict=json.loads(members['verdict.json'])
    assert verdict['verdict']=='verified' and all(p['status']=='HELD' for p in verdict['predictions'])
    for prediction in verdict['predictions']:
        for citation in prediction['citations']:
            path=citation['path']
            if path.startswith('unpacked/'):
                assert sha((HERE/path).read_bytes())==citation['sha256']
            else:
                assert sha(members[path])==citation['sha256']
    records={'schema':'virgl-raster-depth-critic-records-v1','task':'E6-T12h','sourceHead':verdict['sourceHead'],
             'records':[{'path':name,'bytes':len(raw),'sha256':sha(raw)} for name,raw in sorted(members.items())]}
    index=(json.dumps(records,indent=2)+'\n').encode()
    (HERE/'records.json').write_bytes(index)
    buffer=io.BytesIO()
    with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for name,raw in sorted(members.items()):
                entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mtime=0;entry.mode=0o644
                archive.addfile(entry,io.BytesIO(raw))
    packed=buffer.getvalue()
    (HERE/'recording.tar.gz').write_bytes(packed)
    manifest={'schema':'virgl-raster-depth-critic-seal-v1','task':'E6-T12h','verdict':'verified','sourceHead':verdict['sourceHead'],
              'submissionHead':verdict['submissionHead'],'records':len(members),'archiveBytes':len(packed),'archiveSha256':sha(packed),
              'recordIndexSha256':sha(index),'predictionsSha256':sha(members['predictions.json']),'verdictSha256':sha(members['verdict.json']),
              'promotedTestSha256':sha(members['promoted/raster-depth-boundaries.mjs']),
              'workerArchiveSha256':'c49cbffdd4e273b0a38ed4ed49bea91553ef78fab5c347f77f4acd81d179ca78',
              'authority':'isolated-original-draw-state','guestExecution':False,'productionNegotiation':False,'performanceClaim':False}
    (HERE/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    # Read the whole sealed artifact back, including each unique regular member.
    expected={entry['path']:entry for entry in records['records']}
    with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as archive:
        seen=set()
        for entry in archive:
            assert entry.isfile() and entry.name not in seen
            seen.add(entry.name);raw=archive.extractfile(entry).read()
            assert len(raw)==expected[entry.name]['bytes'] and sha(raw)==expected[entry.name]['sha256']
        assert seen==set(expected)
    print(json.dumps(manifest,indent=2))


if __name__=='__main__':
    main()
