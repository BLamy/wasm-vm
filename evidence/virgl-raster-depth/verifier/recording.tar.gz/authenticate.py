#!/usr/bin/env python3
"""Independently authenticate sealed exact-head raster records before review."""
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
SOURCE = '49c408e10b2a5126157f099765b2da6890dd2c16'
SUBMISSION = 'e07ca745888b0119ea86133acc179a9b982a0411'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def main():
    sealed = ROOT / 'evidence/virgl-raster-depth/worker'
    packed = (sealed / 'recording.tar.gz').read_bytes()
    index_raw = (sealed / 'records.json').read_bytes()
    manifest = json.loads((sealed / 'manifest.json').read_bytes())
    index = json.loads(index_raw)
    assert sha(packed) == manifest['archiveSha256'] == 'c49cbffdd4e273b0a38ed4ed49bea91553ef78fab5c347f77f4acd81d179ca78'
    assert sha(index_raw) == manifest['recordIndexSha256'] == '7126f218b7e944b92a66f41e9ea1b76cd07b31f309c0a74c532e02736a7181f7'
    assert len(packed) == manifest['archiveBytes'] == 4688113
    assert index['sourceHead'] == manifest['sourceHead'] == SOURCE
    assert index['task'] == manifest['task'] == 'E6-T12h'
    for name in ['manifest.json', 'records.json', 'recording.tar.gz']:
        assert git('show', SUBMISSION + ':evidence/virgl-raster-depth/worker/' + name) == (sealed / name).read_bytes()
    entries = {r['path']: r for r in index['records']}
    assert len(entries) == len(index['records']) == manifest['records'] == 126
    members = {}
    with tarfile.open(fileobj=io.BytesIO(packed), mode='r:gz') as archive:
        for member in archive:
            path = PurePosixPath(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts
            assert path.as_posix() == member.name and member.name not in members
            raw = archive.extractfile(member).read()
            rec = entries[member.name]
            assert len(raw) == rec['bytes'] == member.size and sha(raw) == rec['sha256']
            members[member.name] = raw
    assert set(members) == set(entries)
    for name, raw in members.items():
        output = HERE / 'unpacked' / name
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(raw)
    def load(name):
        return json.loads(members[name])
    cold_report = load('cold/report.json')
    assert cold_report['gitHead'] == cold_report['cloneHead'] == SOURCE
    assert cold_report['status'] == 'passed' and cold_report['exitCode'] == 0
    assert cold_report['statusBefore'] == cold_report['statusAfter'] == ''
    assert cold_report['command'] == ['make', 'verify-E6-T12h']
    assert sha(members['cold/cold.log']) == cold_report['logSha256']
    assert sha(members['cold/receipt.json']) == cold_report['receiptSha256'] == manifest['coldReceiptSha256']
    assert sha(members['cold/report.json']) == manifest['coldReportSha256']
    assert sha(members['hot/receipt.json']) == manifest['hotReceiptSha256']
    digests = {}
    receipts = {}
    hardware = {}
    faults = {'depth-direction':'mid-depth occluder literal physical pixels',
              'winding':'lower-left Gallium winding literal physical pixels',
              'negative-y':'negative-Y asymmetric triangle',
              'scissor':'lower-left scissor and full clear literal physical pixels',
              'fetch-size':'z=-0.999 in front of mid-depth literal physical pixels'}
    for prefix in ['hot', 'cold']:
        receipt = load(prefix + '/receipt.json')
        assert receipt['task'] == 'E6-T12h' and receipt['gitHead'] == SOURCE and receipt['status'] == 'passed'
        assert receipt['authority'] == 'isolated-original-draw-state'
        assert receipt['guestExecution'] is receipt['productionNegotiation'] is False
        for name, expected in receipt['files'].items():
            assert sha(members[prefix + '/' + name]) == expected
        for name, expected in receipt['sources'].items():
            assert sha(git('show', SOURCE + ':' + name)) == expected, name
            if name in digests:
                assert digests[name] == expected
            digests[name] = expected
        for name, expected in receipt['generated'].items():
            assert sha(members[prefix + '-generated/' + name]) == expected
        good = load(prefix + '/hardware/report.json')
        result = good['browserResult']['result']
        assert good['status'] == good['browserResult']['status'] == result['status'] == 'passed'
        assert good['native'] == good['browserResult']['native']
        assert len(good['native']['assertions']) == 157 and len(result['assertions']) == 759
        assert all(x['held'] for x in good['native']['assertions'] + result['assertions'])
        assert [(x['workload'], len(x['calls'])) for x in result['originals']] == [('kmscube',6),('es2gears',3)]
        assert result['guestExecution'] is result['productionNegotiation'] is False
        records = ['hardware'] + ['fault-' + mode for mode in faults]
        for leaf in records:
            report = load(prefix + '/' + leaf + '/report.json')
            assert report['task'] == 'E6-T12h' and report['gitHead'] == SOURCE
            assert report['browserErrors'] == {'console':[], 'page':[], 'requests':[]}
            assert report['browser']['headless'] is False
            gpu = report['browser']['gpu']['featureStatus']
            assert gpu.get('webgl2', gpu.get('webgl')) == 'enabled'
            assert not any(any(s in flag.lower() for s in ['swiftshader','llvmpipe','softpipe','lavapipe','--disable-gpu']) for flag in report['browser']['commandLine'])
            assert sha(members[prefix + '/' + leaf + '/' + report['screenshot']['path']]) == report['screenshot']['sha256']
            coverage_path = prefix + '/' + leaf + '/' + report['browserCoverage']['path']
            assert sha(members[coverage_path]) == report['browserCoverage']['sha256']
            served = {f['path']: f for f in report['servedFiles']}
            assert served['/fixtures.json']['sha256'] == report['fixtureTransport']['sha256']
            mutation = report.get('sabotage', {})
            if leaf != 'hardware':
                mode = leaf.removeprefix('fault-')
                assert report['status'] == report['browserResult']['status'] == 'failed'
                assert faults[mode] in report['browserResult']['error']['message']
                assert report['sources'] == good['sources'] and report['inputs'] == good['inputs']
                assert mutation['mode'] == mode and mutation['path'] == 'renderer/virgl-command/state.mjs'
                original = git('show', SOURCE + ':' + mutation['path'])
                changed = members[prefix + '/' + leaf + '/fault-source.mjs']
                assert original.count(mutation['needle'].encode()) == 1
                assert changed == original.replace(mutation['needle'].encode(), mutation['replacement'].encode())
                assert sha(original) == mutation['originalSha256'] and sha(changed) == mutation['servedSha256'] != sha(original)
            for item in report['sources'] + report['inputs']:
                name = item['path']
                raw = members[prefix + '-generated/' + name] if name in receipt['generated'] else git('show', SOURCE + ':' + name)
                assert len(raw) == item['bytes'] and sha(raw) == item['sha256'], name
                if '/' + name in served:
                    expected = mutation['servedSha256'] if name == mutation.get('path') else item['sha256']
                    assert served['/' + name]['sha256'] == expected
            for script in load(coverage_path)['scripts']:
                name = script['source']
                expected = mutation['servedSha256'] if name == mutation.get('path') else receipt['sources'][name]
                assert script['sha256'] == served['/' + name]['sha256'] == expected
        retained = load(prefix + '/regression/receipt.json')
        assert retained['task'] == 'E6-T12g5' and retained['gitHead'] == SOURCE and retained['status'] == 'passed'
        for row in retained['sources'] + retained['inputs']:
            name = row['path']
            raw = members[prefix + '-generated/' + name] if name in receipt['generated'] else git('show', SOURCE + ':' + name)
            assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
        for row in retained['records']:
            assert sha(members[prefix + '/regression/' + row['path']]) == row['sha256']
        roles = load(prefix + '/required-format-roles.json')
        expected_roles = {'status':'passed','roleChecks':288,'rejectedBeforeAllocation':35,'wireChecks':3905,'retainedIdReuse':True,'guestDepthView':False}
        assert {key:roles[key] for key in expected_roles} == expected_roles
        receipts[prefix] = {'receiptSha256':sha(members[prefix + '/receipt.json']), 'generated':receipt['generated'], 'sources':len(receipt['sources']), 'records':len(receipt['files'])}
        hardware[prefix] = {'renderer':result['renderer'], 'nativeAssertions':len(good['native']['assertions']), 'hardwareAssertions':len(result['assertions']), 'faultFailures':{m:load(prefix+'/fault-'+m+'/report.json')['browserResult']['error']['message'] for m in faults}}
    after = git('diff', '--name-only', SOURCE + '..' + SUBMISSION).decode().splitlines()
    assert set(after) == {'evidence/virgl-raster-depth/worker/manifest.json','evidence/virgl-raster-depth/worker/records.json','evidence/virgl-raster-depth/worker/recording.tar.gz','tasks/QUEUE.md','tasks/epic-6-transcendence/E6-T12h-virgl-raster-depth-state.md'}
    assert receipts['hot']['generated'] == receipts['cold']['generated']
    audit = {'schema':1,'status':'passed','sourceHead':SOURCE,'submissionHead':SUBMISSION,'archiveSha256':sha(packed),'indexSha256':sha(index_raw),'records':len(members),'receipts':receipts,'cold':cold_report,'hardware':hardware,'afterFrozenSourcePaths':after}
    (HERE / 'authentication.json').write_text(json.dumps(audit, indent=2) + '\n')
    print(json.dumps({'status':'passed','records':len(members),'receipts':receipts,'hardware':hardware}, indent=2))


if __name__ == '__main__':
    main()
