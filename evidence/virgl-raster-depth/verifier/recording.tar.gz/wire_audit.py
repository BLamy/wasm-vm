#!/usr/bin/env python3
"""Reconstruct original wire state without importing worker fixture/decoder code."""
import gzip
import hashlib
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(capture, ref):
    file = capture / 'blobs' / (ref['sha256'] + '.bin')
    raw = file.read_bytes() if file.exists() else gzip.decompress(file.with_suffix('.bin.gz').read_bytes())
    assert len(raw) == ref['bytes'] and sha(raw) == ref['sha256']
    return raw


def main():
    hot = json.loads((HERE/'unpacked/hot/hardware/report.json').read_bytes())
    cold = json.loads((HERE/'unpacked/cold/hardware/report.json').read_bytes())
    results = []
    uploads = []
    for workload, capture_path, events_selected in [
        ('kmscube','evidence/virgl-corpus/captures/kmscube',[140,154,176]),
        ('es2gears','evidence/virgl-workload-inventory/captures/es2gears',[5115]),
    ]:
        capture = ROOT / capture_path
        manifest = json.loads((capture/'manifest.json').read_bytes())
        events_raw = (capture/'events.jsonl').read_bytes()
        assert sha(events_raw) == manifest['events']['sha256']
        events = [json.loads(line) for line in events_raw.splitlines()]
        resources = {e['resourceId']:e for e in events if e['type']=='resource_create' and e['phase']=='enter' and e['seq'] < min(events_selected)}
        objects, binds, constants, vertex_buffers, framebuffer, viewport, selected_shaders = {}, {}, {}, [], None, None, {}
        observed = next(o for o in hot['browserResult']['result']['originals'] if o['workload']==workload)
        cold_observed = next(o for o in cold['browserResult']['result']['originals'] if o['workload']==workload)
        assert observed['calls'] == cold_observed['calls']
        call_index = 0
        for seq in events_selected:
            event = events[seq-1]
            assert event['seq']==seq and event['type']=='submit_cmd' and event['phase']=='enter'
            returned = [e for e in events if e.get('callSeq')==seq and e['phase']=='return']
            assert len(returned)==1 and returned[0]['result']==0
            ref = next(r for r in event['blobs'] if r['role']=='command')
            raw = blob(capture,ref)
            observed_submission = next(s for s in observed['submissions'] if s['event']==seq)
            assert observed_submission['sourceSha256']==sha(raw)
            draw_index = 0
            at = 0
            while at < len(raw):
                header, = struct.unpack_from('<I',raw,at)
                op,kind,length = header&255,(header>>8)&255,header>>16
                byte_length = 4*(length+1)
                packet = raw[at:at+byte_length]
                assert len(packet)==byte_length
                words = list(struct.unpack_from('<'+'I'*length,packet,4))
                citation = {'capture':capture_path,'event':seq,'byteOffset':at,'byteLength':byte_length,'packetSha256':sha(packet),'contextId':event['ctxId']}
                if op==1:
                    objects[kind,words[0]] = words
                elif op==2:
                    binds[kind] = words[0]
                elif op==4 and len(words)>1:
                    viewport = list(struct.unpack_from('<6f',packet,8))
                elif op==5:
                    framebuffer = words
                elif op==6:
                    vertex_buffers = [words[i:i+3] for i in range(0,len(words),3)]
                elif op==12:
                    assert words[1]==0
                    constants[words[0]] = words[2:]
                elif op==31:
                    selected_shaders[words[1]] = words[0]
                elif op==43:
                    resource_id = words[0]
                    snapshot = next(e for e in reversed(events[:seq-1]) if e['type']=='backing_snapshot' and e['resourceId']==resource_id and e['reason']=='submit')
                    backing_ref, = snapshot['blobs']
                    assert backing_ref['role']=='backing'
                    backing = blob(capture,backing_ref)
                    assert len(backing)==sum(snapshot['iovLengths'])
                    uploads.append({'workload':workload,'resourceId':resource_id,'snapshotEvent':snapshot['seq'],'backingBytes':len(backing),'backingSha256':sha(backing),'transfer':citation,'words':words})
                elif op==8:
                    call = observed['calls'][call_index]
                    summary = observed_submission['draws'][draw_index]
                    assert words[2]==5 and words[3]==0 and words[4]==1
                    assert call['op']=='drawArrays' and call['args']==[5,words[0],words[1]]
                    assert summary['byteOffset']==at and summary['count']==words[1] and summary['start']==words[0] and summary['mode']==5 and summary['indexed'] is False
                    assert summary['indexByteLength']==0 and summary['indexResourceId'] is None
                    expected_attributes = []
                    layout = objects[5,binds[5]]
                    for attribute in call['attributes']:
                        index = int(attribute['name'].removeprefix('in_'))
                        offset, divisor, buffer_index, fmt = layout[1+index*4:5+index*4]
                        assert divisor==0 and fmt in [29,30]
                        stride, base, resource_id = vertex_buffers[buffer_index]
                        components = {29:2,30:3}[fmt]
                        expected = {'name':attribute['name'],'enabled':True,'components':components,'type':5126,'stride':stride,'offset':base+offset,'resourceId':resource_id}
                        assert {key:attribute[key] for key in expected} == expected
                        fetch = next(f for f in summary['vertexFetches'] if f['attributeIndex']==index)
                        assert fetch['components']==components and fetch['offset']==base+offset and fetch['stride']==stride and fetch['resourceId']==resource_id
                        assert fetch['firstByte']==base+offset+words[0]*stride
                        assert fetch['requiredEnd']==base+offset+(words[0]+words[1]-1)*stride+components*4
                        assert fetch['requiredEnd']<=resources[resource_id]['width']
                        expected_attributes.append(expected)
                    sx,sy,sz,tx,ty,tz = viewport
                    assert call['viewport']==[tx-sx,ty-abs(sy),sx*2,abs(sy)*2]
                    assert call['winsysY']==(-1 if sy<0 else 1) and call['depthRange']==[tz-sz,tz+sz]
                    depth_bits = objects[3,binds[3]][1] if binds.get(3) else 0
                    depth_handle = framebuffer[1]
                    depth_id = objects[8,depth_handle][1] if depth_handle else None
                    expected_depth = {'enabled':bool(depth_bits&1),'write':bool(depth_bits&2),'func':[512,513,514,515,516,517,518,519][(depth_bits>>2)&7],
                                      'resourceId':depth_id,'bits':16 if depth_id else 0}
                    assert call['depth']==expected_depth
                    if depth_id:
                        assert resources[depth_id]['format']==16 and summary['framebuffer']['depthResourceId']==depth_id
                    raster_bits = objects[2,binds[2]][1]
                    assert call['cull']=={'enabled':((raster_bits>>8)&3)==2,'face':1029,'front':2304 if raster_bits&(1<<15) else 2305}
                    assert call['scissor']['enabled']==bool(raster_bits&(1<<14))
                    assert call['constants']['vsconst0']==constants[0]
                    color_id = objects[8,framebuffer[2]][1]
                    assert call['colorResourceId']==color_id and summary['framebuffer']['resourceId']==color_id
                    assert summary['vertexShader']['handle']==selected_shaders[0] and summary['fragmentShader']['handle']==selected_shaders[1]
                    results.append({'workload':workload,'draw':call_index,'citation':citation,'call':[call['op'],call['args']], 'attributes':expected_attributes,
                                    'viewport':call['viewport'],'winsysY':call['winsysY'],'depth':expected_depth,'rasterizerBits':raster_bits,'constantWords':len(constants[0]),
                                    'sourceStateIndependentOfWorkerDecoder':True,'held':True})
                    call_index += 1
                    draw_index += 1
                at += byte_length
            assert at==len(raw) and draw_index==len(observed_submission['draws'])
        assert call_index==len(observed['calls'])==({'kmscube':6,'es2gears':3}[workload])
    assert sorted(u['snapshotEvent'] for u in uploads)==[139,152,5112,5113,5114]
    output = {'schema':1,'task':'E6-T12h','status':'passed','draws':results,'uploads':uploads,
              'authority':'Independent raw original wire/state reconstruction; original readback digests are recordings, not expected artwork.'}
    (HERE/'wire-audit.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({'status':'passed','draws':len(results),'snapshots':[u['snapshotEvent'] for u in uploads]},indent=2))


if __name__=='__main__':
    main()
