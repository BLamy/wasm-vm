#!/usr/bin/env python3
"""Record the predeclared H predictions and exact evidence points."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent


def point(file,needle=None):
    raw=(HERE/file).read_bytes()
    lines=raw.decode().splitlines()
    line=next((i+1 for i,s in enumerate(lines) if needle in s),1) if needle else 1
    return {'path':file,'line':line,'sha256':hashlib.sha256(raw).hexdigest()}


def main():
    predictions=json.loads((HERE/'predictions.json').read_bytes())
    rows=[
        ('P0','All126 sealed members and frozen132 source bindings authenticate; hot/cold generated binaries agree, final clone was pristine and exact-headed.',[point('authentication.json','"records": 126')]),
        ('P1','Independent raw little-endian wire/state reconstruction matches all nine physical client draws and five CPU snapshots, with complete active VS constants and original reflected layouts.',[point('wire-audit.json','"draws":'),point('source-conventions.json','"upstreamHead"')]),
        ('P2','Independent literal matrices reproduce clip-near/far occlusion, all eight comparisons and write-mask scenes in hot/cold/replay.',[point('pixel-audit.json','"literalMatrices": 81'),point('unpacked/hot/hardware/report.json','z=0.999 behind mid-depth literal physical pixels')]),
        ('P3','Scissor/full-clear matrices, asymmetric Y samples, winding/culling and adjacent state toggles hold and their digests agree with independent expected bytes.',[point('pixel-audit.json','lower-left scissor and full clear'),point('unpacked/hot/hardware/report.json','negative-Y asymmetric triangle 2,13')]),
        ('P4','Alignment/fetch/missing/foreign/role-swapped/mismatched target errors issue no draws; A/B/A frames agree, retained Z16 public-name/ID reuse and disposal hold. Dynamic state remains outside shader emission keys, with system Y restored per draw.',[point('unpacked/hot/hardware/report.json','replacement ID cannot resolve old native texture'),point('review-audit.json','"classifications"'),point('source-conventions.json','"criterion": "full clear"')]),
        ('P5','Owned arrays complete after actual later-task fences with no GPU index reads under worker delays0/1/3 and independent PRNG seeds1956311333/2789420567/728079433. Current G5 gates hold; unchanged G6 critic54-member seal and compiler/resource boundary carry forward.',[point('independent/report.json','"schedules"'),point('carry-forward.json','"reviewedCriticMembers": 54')]),
        ('P6','Five frozen physical source faults fail exact named pixel predictions. Independent RGB-tail predicate mutation additionally fails the no-draw prediction. All original/replayed/independent/fault captures bind hardware identity and zero browser errors.',[point('authentication.json','"faultFailures"'),point('sabotage-rgb-tail/report.json','RGB68 truncated final component issues no draw')]),
        ('P7','All22 added decoder and72 added executable state lines execute in authenticated precise V8 coverage; four comments and documented validation/declarative plumbing are waived. No runtime or worker harness edits by the critic, ignored assertions/tests, or production import changes.',[point('coverage-audit.json','"executed": 22'),point('review-audit.json','"classifications"')]),
        ('P8','Physical RGB72 exact tail accepts (firstByte36, requiredEnd72); RGB68 rejects out-of-bounds before draw, with unchanged state/pixels. Indexed RGB strip succeeds. Promoted test346 predictions hold; changing only its final complete-fetch bound to8 attempts an extra draw and is killed.',[point('independent/report.json','RGB exact final fetch byte'),point('independent/report.json','RGB68 truncated final component issues no draw'),point('sabotage-rgb-tail/report.json','RGB68 truncated final component issues no draw')]),
    ]
    assert {id for id,_,_ in rows}=={p['id'] for p in predictions['predictions']}
    verdict={'schema':1,'task':'E6-T12h','verdict':'verified','sourceHead':predictions['sourceHead'],'submissionHead':predictions['submissionHead'],
             'predictionsSha256':hashlib.sha256((HERE/'predictions.json').read_bytes()).hexdigest(),
             'predictions':[{'id':id,'status':'HELD','observed':observed,'citations':citations} for id,observed,citations in rows],
             'productFindings':[],'proofGaps':[],'suite':'Promote renderer/virgl-command/tests/raster-depth-boundaries.mjs and preserve direct physical acceptance command.',
             'authority':'isolated-original-draw-state','guestExecution':False,'productionNegotiation':False,'matchedOriginalArtwork':False,'performanceClaim':False}
    (HERE/'verdict.json').write_text(json.dumps(verdict,indent=2)+'\n')
    print('VERDICT: verified — P0–P8 HELD; no product refutation or proof gap')


if __name__=='__main__':
    main()
