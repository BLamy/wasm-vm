#!/usr/bin/env python3
"""Map added executable lines to authenticated precise V8 runtime ranges."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
BASE = '10adfaaf3badf5f70ad9375f4e0bff6a615418f6'
HEAD = '49c408e10b2a5126157f099765b2da6890dd2c16'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def main():
    all_rows = []
    totals = {}
    for source in ['renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs']:
        raw = git('show', HEAD + ':' + source)
        text = raw.decode()
        digest = hashlib.sha256(raw).hexdigest()
        lines = text.splitlines(keepends=True)
        offsets, at = [], 0
        for line in lines:
            offsets.append(at)
            at += len(line.encode('utf-16-le')) // 2
        added = []
        patch = git('diff','--unified=0',BASE+'..'+HEAD,'--',source).decode()
        for line in patch.splitlines():
            match = re.match(r'@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@',line)
            if match:
                current = int(match[1])
            elif line.startswith('+') and not line.startswith('+++'):
                added.append(current)
                current += 1
            elif line.startswith(' ') and not line.startswith(' ---'):
                current += 1
        recordings = []
        for prefix in ['hot','cold']:
            for path in sorted((HERE/'unpacked'/prefix).rglob('browser-coverage.json')):
                if any(part.startswith(('fault-','sabotage-')) for part in path.parts):
                    continue
                report = json.loads(path.read_bytes())
                for script in report.get('scripts',[report] if 'source' in report else []):
                    if script.get('source') != source:
                        continue
                    assert script['sha256'] == digest, path
                    ranges = [rng for function in script['coverage']['functions'] for rng in function['ranges']]
                    recordings.append((path.relative_to(HERE).as_posix(), ranges))
        assert recordings
        for number in added:
            line = lines[number-1]
            if not line.strip() or line.lstrip().startswith(('//','/**','*')):
                all_rows.append({'source':source,'line':number,'classification':'waived','reason':'comment or blank line'})
                continue
            start = offsets[number-1]
            token_offsets = [start+i for i,char in enumerate(line.rstrip()) if not char.isspace()]
            witnesses = []
            covered = set()
            for citation,ranges in recordings:
                positive = []
                for offset in token_offsets:
                    containing = [r for r in ranges if r['startOffset'] <= offset < r['endOffset']]
                    if containing:
                        smallest = min(containing,key=lambda r:r['endOffset']-r['startOffset'])
                        if smallest['count'] > 0:
                            positive.append(offset)
                if positive:
                    covered.update(positive)
                    witnesses.append({'record':citation,'nonspaceCharactersExecuted':len(positive)})
            uncovered = []
            for offset in token_offsets:
                if offset not in covered:
                    index = offset-start
                    uncovered.append(index)
            all_rows.append({'source':source,'line':number,'classification':'executed' if not uncovered else ('partial' if covered else 'unexecuted'),
                             'sourceText':line.rstrip(),'witnesses':witnesses,'uncoveredColumns1Based':[i+1 for i in uncovered],
                             'uncoveredText':''.join(line[i] for i in uncovered)})
        selected = [r for r in all_rows if r['source'] == source]
        totals[source] = {k:sum(r['classification']==k for r in selected) for k in ['executed','partial','unexecuted','waived']}
    result = {'schema':1,'task':'E6-T12h','sourceHead':HEAD,'totals':totals,'rows':all_rows}
    (HERE/'coverage-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(totals,indent=2))
    for row in all_rows:
        if row['classification'] in ['partial','unexecuted']:
            print(f"{row['source']}:{row['line']} {row['classification']}: {row['uncoveredText']}")


if __name__ == '__main__':
    main()
