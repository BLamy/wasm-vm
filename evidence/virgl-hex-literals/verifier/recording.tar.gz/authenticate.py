#!/usr/bin/env python3
"""Authenticate independently; never execute the worker's sealing code."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import subprocess
import tarfile

OUT=Path(__file__).resolve().parent
REPO=OUT.parents[2]
SEAL=REPO/'evidence/virgl-hex-literals/worker'
FROZEN='5a039d16b2bfd756f6908a718ea063ad7c619905'
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((SEAL/'manifest.json').read_bytes())
index=json.loads((SEAL/'records.json').read_bytes())
assert sha((SEAL/'recording.tar.gz').read_bytes())=='6aa1b74273563be5ae6aabaef307904b2362a1584edd344a7b27bc9281ac1ace'
assert sha((SEAL/'records.json').read_bytes())=='e83b840de0bac0804cf99e649549fb58f50b5b261f803418ffaeecbcaa708577'
assert manifest['sourceHead']==index['sourceHead']==FROZEN
for key in ['archive','recordIndex']:
    r=manifest[key];b=(SEAL/r['path']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256']
entries={r['path']:r for r in index['records']};assert len(entries)==len(index['records'])==62
raws={}
with tarfile.open(SEAL/'recording.tar.gz') as t:
    for m in t.getmembers():
        name=PurePosixPath(m.name)
        assert not name.is_absolute() and '..' not in name.parts and m.isfile() and m.name not in raws
        raw=t.extractfile(m).read();row=entries[m.name]
        assert len(raw)==row['bytes'] and sha(raw)==row['sha256'];raws[m.name]=raw
        p=OUT/'worker'/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
assert set(raws)==set(entries)
hot=json.loads(raws['hot/receipt.json']);cold_report=json.loads(raws['cold/report.json']);cold=json.loads(raws['cold/acceptance/receipt.json'])
for name,key in [('hot/receipt.json','hotReceiptSha256'),('cold/report.json','coldReportSha256'),('cold/acceptance/receipt.json','coldReceiptSha256')]:
    assert sha(raws[name])==manifest[key]
for receipt,prefix in [(hot,'hot/'),(cold,'cold/acceptance/')]:
    assert receipt['gitHead']==FROZEN and receipt['status']=='passed' and len(receipt['sources'])==195
    for r in receipt['records']:
        b=raws[prefix+r['path']];assert len(b)==r['bytes'] and sha(b)==r['sha256']
    for r in receipt['sources']:
        if r['path'].startswith('renderer/virgl-shader/build/'):
            if prefix=='hot/':b=raws['generated/'+r['path'].removeprefix('renderer/virgl-shader/build/')]
            else:b=(Path(cold_report['clone'])/r['path']).read_bytes()
        else:
            b=subprocess.check_output(['git','show',FROZEN+':'+r['path']],cwd=REPO)
            assert (REPO/r['path']).read_bytes()==b
        assert len(b)==r['bytes'] and sha(b)==r['sha256'],r['path']
assert cold_report['gitHead']==cold_report['cloneHead']==FROZEN and cold_report['status']=='passed'
assert cold_report['statusBefore']==cold_report['statusAfter']=='' and cold_report['exitCode']==0
assert cold_report['command']==['make','verify-E6-T12g6c']
assert cold_report['receiptSha256']==sha(raws['cold/acceptance/receipt.json'])
assert cold_report['logSha256']==sha(raws['cold/cold.log'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=cold_report['clone'],text=True).strip()==FROZEN
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=cold_report['clone'])
changed=subprocess.check_output(['git','diff','--name-only',FROZEN+'..HEAD'],cwd=REPO,text=True).splitlines()
assert all(p.startswith('evidence/virgl-hex-literals/worker/') or p in ['tasks/QUEUE.md','tasks/epic-6-transcendence/E6-T12g6c-hexadecimal-immediates.md'] for p in changed)
result=dict(status='passed',archiveSha256=sha((SEAL/'recording.tar.gz').read_bytes()),members=62,sourceHead=FROZEN,
    trackedChangesSinceFreeze=changed,sourcesHot=195,sourcesCold=195,cold=cold_report,
    coldGeneratedAuthenticatedAt=cold_report['clone'],coldGenerated=[r for r in cold['sources'] if r['path'].startswith('renderer/virgl-shader/build/')])
(OUT/'authentication.json').write_text(json.dumps(result,indent=2)+'\n')
print('62 members, 195 hot/cold source+generated rows, exact frozen provenance and actual pristine cold checkout authenticated.')
