#!/usr/bin/env python3
"""Independent byte/state audit of the authenticated worker archive."""
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
FROZEN = '5a039d16b2bfd756f6908a718ea063ad7c619905'
SEEDS = [883475089, 2552332019, 3860417495]
sha = lambda b: hashlib.sha256(b).hexdigest()
findings = []

def require(ok, label):
    if not ok:
        raise AssertionError(label)

def record(name, value):
    findings.append(dict(point=name, **value))

def read(p):
    raw = p.read_bytes()
    return json.loads(raw), sha(raw)

def literal_words(text):
    """Input grammar oracle uses Python's integer/IEEE packing, not bridge IR."""
    out = []
    for m in re.finditer(r'^IMM\[(\d+)\] (FLT32|UINT32) \{([^}]*)\}', text, re.M):
        require(int(m[1]) == len(out), 'contiguous oracle immediates')
        cells = m[3].split(',')
        require(len(cells) == 4, 'four oracle words')
        words = []
        for cell in cells:
            cell = cell.strip(' \t\r')
            if m[2] == 'UINT32':
                require(re.fullmatch(r'[0-9]+', cell), 'UINT32 decimal oracle')
                word = int(cell)
            elif cell.startswith('0x'):
                require(re.fullmatch(r'0x[0-9a-fA-F]{8}', cell), 'hex exact syntax oracle')
                word = int(cell, 16)
            else:
                word = struct.unpack('<I', struct.pack('<f', float(cell)))[0]
            require(0 <= word <= 0xffffffff, 'oracle 32-bit range')
            words.append(word)
        out.append(words)
    return out

def audit_native(directory):
    native, digest = read(directory / 'native/report.json')
    lograw = (directory / 'native/native.log').read_bytes()
    lines = lograw.decode().splitlines()
    actual, primary, locations = {}, {}, {}
    for n, line in enumerate(lines, 1):
        if line == 'STATUS passed':
            continue
        m = re.fullmatch(r'(CASE|PRIMARY) (\d+) (.*)', line)
        require(m is not None, f'native unexpected log line {n}')
        ix = int(m[2]); table = actual if m[1] == 'CASE' else primary
        require(ix not in table, 'duplicate native log entry')
        table[ix] = json.loads(m[3]); locations[(m[1], ix)] = n
    require(len(actual) == len(native['cases']) == 676 and len(primary) == 512, 'native counts from log')
    require(lines[-1] == 'STATUS passed' and not (directory/'native/native.stderr').read_bytes(), 'completed sanitizer recording')
    fixture = (directory/'native/cases.bin').read_bytes()
    require(fixture[:4] == b'VHL1' and struct.unpack_from('<I',fixture,4)[0] == 676, 'fixture header')
    pos = 8; domain = []
    for ix, c in enumerate(native['cases']):
        stage, expected, pinned, size = struct.unpack_from('<4I', fixture, pos); pos += 16
        text = fixture[pos:pos+size]; pos += size
        require(text == c['text'].encode() and sha(text) == c['textSha256'], f'case {ix} fixture text')
        require(stage == (c['stage']=='fragment') and bool(expected)==c['ok'] and bool(pinned)==(c['immediates'] is not None), f'case {ix} fixture flags')
        require(c['index']==ix and actual[ix]==c['result'] and type(actual[ix]['ok']) is bool and actual[ix]['ok']==c['ok'], f'case {ix} result/log')
        if c['immediates'] is not None:
            decoded = literal_words(c['text'])
            require(decoded == c['immediates'] == c['primary']['immediates'] == primary[ix]['immediates'], f'case {ix} exact pinned words')
        if not c['ok']:
            require('glsl' not in actual[ix], f'case {ix} rejection source leak')
        if c['equivalent']:
            alt = c['equivalentResult']
            require(alt['ok']==c['ok'], f'case {ix} UINT32 authority')
            if c['equivalentMode']=='exact':
                require(actual[ix]==alt, f'case {ix} exact raw UINT32 output')
            else:
                require(actual[ix]['metadata']==alt['metadata'], f'case {ix} legacy metadata')
        if c['name'].startswith('domain-'):
            w = int(re.search(r'0x([0-9a-f]{8})', c['name'])[1],16)
            predicted = w==0x7f7fffff and (c['name'].startswith('domain-mul-') or c['name'].endswith('-true'))
            require(c['ok']==predicted, f'case {ix} independently predicted exceptional authority')
            domain.append(dict(index=ix,name=c['name'],ok=c['ok'],line=locations['CASE',ix]))
    require(pos==len(fixture), 'fixture complete, no trailing bytes')
    record(str(directory.relative_to(ROOT))+'/native/report.json',dict(sha256=digest,cases=len(actual),admissions=sum(c['ok'] for c in native['cases']),primary=len(primary),domain=domain,
        firstCaseLine=locations['CASE',0],lastCaseLine=locations['CASE',675],logSha256=sha(lograw)))
    return native

def audit_wasm(directory, native):
    w, digest = read(directory/'wasm/report.json')
    require(w['gitHead']==FROZEN and len(w['cases'])==len(w['pairs'])==676, 'Wasm provenance/count')
    for ix,(s,p,c) in enumerate(zip(w['cases'],w['pairs'],native['cases'])):
        require(s['index']==p['index']==ix and s['result']==c['result'], f'Wasm {ix} singles equality')
        require(p['result']['ok']==c['ok'] and type(p['result']['ok']) is bool, f'Wasm {ix} paired admission')
        if not c['ok']:
            require(all(k not in p['result'] for k in ['vertex','fragment','glsl','metadata']), f'Wasm {ix} closed pair rejection')
        else:
            stage = c['stage']
            require(p['result'][stage]['glsl']==c['result']['glsl'], f'Wasm {ix} paired source')
            require(p['result'][stage]['metadata']==c['result']['metadata'], f'Wasm {ix} paired metadata')
    record(str(directory.relative_to(ROOT))+'/wasm/report.json',dict(sha256=digest,singles=676,pairs=676,closedRejectedPairs=sum(not c['ok'] for c in native['cases'])))

def audit_coverage(directory):
    c,digest = read(directory/'native/coverage.json')
    f = next(f for d in c['data'] for f in d['files'] if f['filename'].endswith('/bridge.c'))
    segments = [s for s in f['segments'] if 246<=s[0]<=275]
    branches = [b for b in f['branches'] if 246<=b[0]<=275]
    require(all(s[2]>0 for s in segments if s[3] and s[4] and not s[5]), 'each executable segment in added hunk exercised')
    actual = [b for b in branches if not (b[0]==b[2] and b[1]==b[3])]
    require(all(b[4]>0 and b[5]>0 for b in actual), 'both outcomes every actual source condition')
    record(str(directory.relative_to(ROOT))+'/native/coverage.json',dict(sha256=digest,hunk='bridge.c:246-275',segments=segments,branches=branches,
        waived=['247-248 explanatory comment','268 zero-length macro-expansion branches inside isfinite are compiler artifacts, not additional source conditions','braces/blank lines']))

def audit_browser(directory, name, expect_failure=False):
    p=directory/name/'report.json';b,digest=read(p);a=b['acceptance']
    require(b['gitHead']==FROZEN and b['trackedChanges']==[], 'browser exact frozen source')
    require(b['browserErrors']==dict(console=[],page=[],requests=[]), 'zero browser errors')
    require(b['browser']['launch']['headless'] is False and b['browser']['gpu']['featureStatus'][b['browser']['webglFeature']]=='enabled', 'headed hardware enabled')
    require(not re.search('software|swiftshader|llvmpipe|softpipe',a['renderer']['renderer'],re.I),'physical hardware renderer')
    sources = {r['path']:r['sha256'] for r in b['sources']}
    for r in b['servedFiles']:
        require(sources[r['path']]==r['sha256'], 'browser served-source binding')
    cov=b['browserCoverage'];coverage,cdigest=read(directory/name/cov['path']);require(cdigest==cov['sha256'],'V8 capture digest')
    for s in coverage['scripts']:
        require(s['sha256']==sources[s['source']],'V8 source binding')
        require(s['coverage']['functions'][0]['ranges'][0]['count']>0,'script actually executed')
    capture=b.get('screenshot') or b.get('failureScreenshot')
    require(sha((directory/name/capture['path']).read_bytes())==capture['sha256'],'screenshot capture')
    require(a['objects']['live']==0 and a['productionNegotiation'] is False and a['guestExecution'] is False,'isolated disposed capture')
    created={};deleted={};compiled=linked=0
    for i,e in enumerate(a['events']):
        if e['call'].startswith('create'):
            require(e['id'] not in created,'unique GL object identity');created[e['id']]=e['call'][6:]
        if e['call'].startswith('delete'):
            require(e['id'] in created and created[e['id']]==e['call'][6:] and e['id'] not in deleted,'exact GL deletion');deleted[e['id']]=i
        if e['call'] in ['compileShader','linkProgram']:
            require(e['status'] is True,'actual GL compile/link');compiled+=e['call']=='compileShader';linked+=e['call']=='linkProgram'
    require(set(created)==set(deleted) and len(created)==a['objects']['created'],'all physically created GL objects deleted')
    fault_points=[];word_count=pixel_count=0;exponents=set()
    for ix,v in enumerate(a['vertices']):
        require(sha(v['text'].encode())==v['textSha256'],'vertex source')
        words=literal_words(v['text'])[0];require(words==v['words'],'physical literal words from source')
        exponents.update((word>>23)&255 for word in words)
        require(v['reflection']==[dict(name=n,type=35666,size=1) for n in ['gl_Position','vso_g0','vso_g1']],'actual TF vec4 reflection')
        mutation=v.get('mutation')
        if mutation:
            require(mutation['original']==v['pair']['vertex']['glsl'] and mutation['served']==mutation['original'].replace(mutation['needle'],mutation['replacement'],1),'exact actual vertex source corruption')
        served=(mutation['served'] if mutation else v['pair']['vertex']['glsl'])
        require(any(e['call']=='shaderSource' and e['source']==served for e in a['events']),'actually compiled emitted vertex source')
        for j,x in enumerate(v['vectors']):
            raw=bytes(x['bytes']);require(len(raw)==48 and sha(raw)==x['sha256'],'actual feedback bytes')
            observed=list(struct.unpack('<12I',raw))
            wanted=[struct.unpack('<I',struct.pack('<f',v))[0] for v in x['position']]
            require(x['attributeWords']==wanted,'actual position attribute state')
            wanted.extend((word%2**23)|0x3f000000 for word in words)
            wanted.extend((word//2**23)|0x3f000000 for word in words)
            require(x['observed']==observed and x['expectedWords']==wanted,'feedback expectation independently recomputed')
            if mutation:
                bad=[k for k in range(12) if observed[k]!=wanted[k]]
                require(bad,'physical source mutation sensitivity')
                fault_points.append(dict(kind='vertex',group=v['name'],vector=j,lane=bad[0],expected=wanted[bad[0]],observed=observed[bad[0]],bytesSha256=sha(raw)))
            else:
                require(observed==wanted and x['checkedWords']==12,'every feedback word exact')
                reconstructed=[(observed[4+k]&0x7fffff)|((observed[8+k]&511)<<23) for k in range(4)]
                require(reconstructed==words==x['reconstructed'],'full signed/exponent/payload reconstruction')
                word_count+=12
    planes={}
    for ix,f in enumerate(a['fragments']):
        require(sha(f['text'].encode())==f['textSha256'],'fragment source')
        raw=bytes(f['rgbaBytes']);require(len(raw)==64 and sha(raw)==f['sha256'],'actual framebuffer bytes')
        if 'plane' in f:
            words=literal_words(f['text'])[0];require(words==f['words'],'bitplane literal words from source')
            wanted=[255 if (word//2**f['plane'])%2 else 0 for word in words];budget=0
            planes.setdefault(f['name'].rsplit('-plane-',1)[0],set()).add(f['plane'])
        else:
            require(f['name'].startswith('legacy-'),'only explicit safe legacy control')
            wanted=[0,64,128,255];budget=1
        require(f['expectedBytes']==wanted,'independent framebuffer oracle')
        mutation=f.get('mutation');served=mutation['served'] if mutation else f['pair']['fragment']['glsl']
        if mutation:
            require(mutation['original']==f['pair']['fragment']['glsl'] and mutation['served']==mutation['original'].replace(mutation['needle'],mutation['replacement'],1),'exact actual fragment source corruption')
        require(any(e['call']=='shaderSource' and e['source']==served for e in a['events']),'actually compiled emitted fragment source')
        bad=[k for k,v in enumerate(raw) if abs(v-wanted[k%4])>budget]
        if mutation:
            require(bad,'physical pixel mutation sensitivity')
            first=bad[0]//4
            fault_points.append(dict(kind='fragment',group=f['name'],pixel=first,expected=wanted,observed=list(raw[4*first:4*first+4]),bytesSha256=sha(raw)))
        else:
            require(not bad and f['checkedPixels']==16,'every physical pixel')
            pixel_count+=16
    if expect_failure:
        require(b['status']=='failed' and a['status']=='failed' and len(fault_points)==1,'source corruption failed at physical point')
        require(('independent literal word mismatch' if a['fault']=='vertex' else 'independent literal pixel mismatch') in b['failure']['message'],'outer browser failed for the physical contradiction')
    else:
        require(b['status']=='passed' and a['status']=='passed' and word_count==13344 and pixel_count==5184,'actual bytes independent count')
        require(exponents==set(range(256)) and len(planes)==10 and all(s==set(range(32)) for s in planes.values()),'all exponent classes and bitplanes')
    record(str(p.relative_to(ROOT)),dict(sha256=digest,feedbackWords=word_count,framebufferPixels=pixel_count,createdObjects=len(created),deletedObjects=len(deleted),compiled=compiled,linked=linked,
        hardware=a['renderer'],faultPoints=fault_points,browserCoverageSha256=cdigest,screenshotSha256=capture['sha256']))

def audit_retained(directory):
    r,digest=read(directory/'retained/report.json')
    require(r['gitHead']==FROZEN and len(r['originals'])==25 and sum(c['native']['ok'] for c in r['originals'])==23,'literal original partition')
    rejects=[]
    for c in r['originals']:
        source=(REPO/c['path']).read_bytes();require(sha(source)==c['sha256'] and len(source)==c['bytes'],'literal original source binding')
        require(c['native']==c['wasm'],'literal original native/Wasm source+metadata')
        if c['sha256'].startswith('92cb866a'):
            require(not c['native']['ok'] and c['native']['error']['code']=='unsupported-feature','complete 92cb gate')
        else:
            require(c['old']==c['native'],'unchanged full original result')
        if not c['native']['ok']:rejects.append(c['sha256'][:8])
    require(sorted(rejects)==['92cb866a','c5806d5f'],'both unsupported originals closed')
    j,jdigest=read(directory/'independent-joins.json')
    require(j['cases']==len(j['native'])==len(j['wasm'])==402 and j['status']=='passed','complete promoted guard')
    for n,w in zip(j['native'],j['wasm']):
        require(n['result']==w['result'] and n['result']['ok']==n['ok'],'promoted independent guard expectation')
    record(str(directory.relative_to(ROOT))+'/retained/report.json',dict(sha256=digest,originals=25,admissions=23,rejectedOriginals=rejects,joins=402,joinsSha256=jdigest))

for name in ['hot','cold/acceptance']:
    d=ROOT/'worker'/name
    native=audit_native(d)
    audit_wasm(d,native)
    audit_coverage(d)
    audit_retained(d)
    for seed in SEEDS:audit_browser(d,'gpu-'+str(seed))
    for fault in ['vertex','fragment']:audit_browser(d,'fault-'+fault,True)
if (ROOT/'gpu-critic/report.json').exists():
    audit_browser(ROOT,'gpu-critic')
(ROOT/'audit.json').write_text(json.dumps(dict(status='passed',sourceHead=FROZEN,points=findings),indent=2)+'\n')
print('Independent capture audit passed:',len(findings),'report points, hot+cold exact literals/words/pixels/closed domains.')
