#!/usr/bin/env python3
"""Deterministically seal this independent critic's reports and actual captures."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

OUT=Path(__file__).resolve().parent
REPO=OUT.parents[2]
DEST=REPO/'evidence/virgl-hex-literals/verifier'
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=['authenticate.py','audit.py','seal.py','authentication.json','audit.json','coverage-authentication.json',
    'predictions-before.json','predictions.json','hunk-coverage.json','commands.json','independent-guards.json',
    'fresh-native.json','fresh-cases.bin','fresh-native.log','fresh-native.stderr','fresh.profraw','fresh.profdata',
    'fresh-coverage.json','fresh-build.log','fresh-native-build.log','sabotage.json','sabotage-guards.json',
    'sabotage-guards.stdout','sabotage-guards.stderr','sabotage-build.log',
    'gpu-critic/report.json','gpu-critic/browser-coverage.json','gpu-critic/browser.png','gpu-critic.log']
members={name:(OUT/name).read_bytes() for name in paths}
guard=REPO/'renderer/virgl-shader/tests/hex-literal-regressions.mjs'
members['promoted/hex-literal-regressions.mjs']=guard.read_bytes()
records=[dict(path=name,bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(members.items())]
index=(json.dumps(dict(schema='virgl-hex-literals-critic-records-v1',task='E6-T12g6c',sourceHead='5a039d16b2bfd756f6908a718ea063ad7c619905',records=records),indent=2)+'\n').encode()
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0) as gz:
    with tarfile.open(fileobj=gz,mode='w') as tar:
        for name,raw in sorted(members.items()):
            entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mtime=0;entry.mode=0o644
            tar.addfile(entry,io.BytesIO(raw))
archive=buffer.getvalue()
manifest=dict(schema='virgl-hex-literals-critic-seal-v1',task='E6-T12g6c',verdict='verified',
    verifiedBase='500ebfde1262e4615c9e15dbc96ecf1c407870f0',sourceHead='5a039d16b2bfd756f6908a718ea063ad7c619905',
    workerSubmission='d264649c8407f546530556e5dff9edc4b81bc9e2',workerArchiveSha256='6aa1b74273563be5ae6aabaef307904b2362a1584edd344a7b27bc9281ac1ace',
    predictions=dict(held=19,failed=0,needsEvidence=0,beforeSha256=sha(members['predictions-before.json'])),
    freshNativeCases=725,primaryComparisons=512,promotedNativeWasmGuards=49,physicalSeed=1821720247,
    physicalWords=13344,physicalPixels=5184,sabotage='owned nibble shift caught by admission and exact source words',
    archive=dict(path='recording.tar.gz',bytes=len(archive),sha256=sha(archive)),
    recordIndex=dict(path='records.json',bytes=len(index),sha256=sha(index)),records=len(records),
    promotedGuard=dict(path=str(guard.relative_to(REPO)),sha256=sha(guard.read_bytes())),
    productionNegotiation=False,guestExecution=False,unchangedG6bProofs='HELD')
DEST.mkdir(parents=True,exist_ok=True)
(DEST/'recording.tar.gz').write_bytes(archive)
(DEST/'records.json').write_bytes(index)
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(DEST/'recording.tar.gz') as t:
    assert len(t.getmembers())==len(records)
    for m in t.getmembers():
        raw=t.extractfile(m).read();r=next(r for r in records if r['path']==m.name)
        assert len(raw)==r['bytes'] and sha(raw)==r['sha256']
print(json.dumps(manifest,indent=2))
