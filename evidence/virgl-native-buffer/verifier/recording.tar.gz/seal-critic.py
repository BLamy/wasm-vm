"""Seal complete critic inputs, outputs, original oracle points and sources."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

REPO = Path.cwd()
ROOT = Path(__file__).resolve().parent
OUT = REPO / "evidence/virgl-native-buffer/verifier"
assert not OUT.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
files = {}
for path in ROOT.rglob("*"):
    if path.is_file() and not path.relative_to(ROOT).parts[0] == "worker":
        files[path.relative_to(ROOT).as_posix()] = path
# The complete worker archive remains the authenticated dependency of record.
# Copy precisely the original bodies interrogated by the critic, avoiding the
# warm gate and unrelated carried archives while retaining full oracle inputs.
for name in ["cold/report.json", "cold/recording/receipt.json", "cold/recording/native-submit.stderr",
             "cold/recording/native-submit.stdout", "cold/recording/native-coverage.json",
             "cold/recording/native.profdata", "cold/recording/native-test-binary", "cold/recording/changed-coverage.json",
             "cold/recording/hardware/report.json", "cold/recording/hardware/browser-coverage.json",
             "cold/recording/hardware/browser.png", "cold/recording/default-demo/report.json"]:
    files["worker/" + name] = ROOT / "worker" / name
for relative in ["crates/core/src/dev/virtio/gpu/control3d.rs", "crates/core/tests/virtio_gpu_submit3d.rs",
                 "tools/virgl-native-buffer/fault.py", "tools/virgl-native-buffer/coverage.py",
                 "tools/virgl-native-buffer/cold.py", "tools/virgl-native-buffer/verify.py", "AGENTS.md"]:
    files["sources/" + relative] = REPO / relative
for family, role in [("virgl-native-buffer", "worker")] + [
        (family, role) for family in ["virgl-resource-capacity", "virgl-desktop-control", "virgl-shadow-samplers",
                                     "virgl-desktop-submit", "virgl-standard-buffer-roles"] for role in ["worker", "verifier"]]:
    files[f"dependency-identities/{family}/{role}/manifest.json"] = REPO / "evidence" / family / role / "manifest.json"
    if family == "virgl-native-buffer":
        files[f"dependency-identities/{family}/{role}/records.json"] = REPO / "evidence" / family / role / "records.json"
for path in (REPO / "evidence/virgl-native-buffer/deployment").rglob("*"):
    if path.is_file():
        files["deployment/" + path.relative_to(REPO / "evidence/virgl-native-buffer/deployment").as_posix()] = path

rows = [dict(path=name, bytes=path.stat().st_size, sha256=sha(path.read_bytes())) for name, path in sorted(files.items())]
head = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
index = dict(schema="native-buffer-verifier-index-v1", task="E6-T11d53", head=head, records=rows)
OUT.mkdir(parents=True)
index_raw = (json.dumps(index, indent=2) + "\n").encode()
(OUT / "records.json").write_bytes(index_raw)
with (OUT / "recording.tar.gz").open("wb") as stream, gzip.GzipFile(fileobj=stream, mode="wb", mtime=0, filename="") as zipped, tarfile.open(fileobj=zipped, mode="w") as packed:
    for row in rows:
        raw = files[row["path"]].read_bytes()
        info = tarfile.TarInfo(row["path"])
        info.size, info.mode, info.mtime = len(raw), 0o644, 0
        packed.addfile(info, io.BytesIO(raw))
seen = 0
with tarfile.open(OUT / "recording.tar.gz", "r|gz") as packed:
    for member in packed:
        assert seen < len(rows)
        row = rows[seen]
        assert member.isfile() and member.name == row["path"]
        raw = packed.extractfile(member).read()
        assert len(raw) == row["bytes"] and sha(raw) == row["sha256"]
        seen += 1
assert seen == len(rows)
manifest = dict(schema="native-buffer-verifier-seal-v1", task="E6-T11d53", verdict="verified", head=head,
                workerRecordingHead="35a1f0c2987782ded50dc7240c33671d9265ce1a", records=len(rows), reopenedMembers=seen,
                recordIndexSha256=sha(index_raw), archiveSha256=sha((OUT / "recording.tar.gz").read_bytes()),
                archiveBytes=(OUT / "recording.tar.gz").stat().st_size, dependencyAuthentication=json.loads((ROOT / "authentication.json").read_bytes()),
                predictions="predictions.json", findings="verdict-points.jsonl", coverage="coverage-classification.json",
                promotedTest="selected_desktop_buffer_reset_reuse_rejects_high_bits_and_stale_dma",
                runtimeSha256=sha((REPO / "crates/core/src/dev/virtio/gpu/control3d.rs").read_bytes()),
                independentSeeds=[37173, 48898, 30285], guestExecution=False, productionAuthority=False)
(OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps(dict(records=len(rows), archiveBytes=manifest["archiveBytes"],
                      manifestSha256=sha((OUT / "manifest.json").read_bytes()),
                      indexSha256=manifest["recordIndexSha256"], archiveSha256=manifest["archiveSha256"])))
