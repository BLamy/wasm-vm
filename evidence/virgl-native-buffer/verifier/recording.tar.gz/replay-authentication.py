"""Repeat the critic's streaming complete-body and unchanged-boundary checks."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

REPO = Path.cwd()
ROOT = Path(__file__).resolve().parent
BASE = "59bf446955cc2b78b84d94fcd03cb3f3f4f1c230"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def filehash(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(part)
    return h.hexdigest()


checks, receipts = [], {}
families = [("virgl-native-buffer", "worker")] + [
    (family, role) for family in ["virgl-resource-capacity", "virgl-desktop-control",
                                "virgl-shadow-samplers", "virgl-desktop-submit", "virgl-standard-buffer-roles"]
    for role in ["worker", "verifier"]]
for family, role in families:
    directory = REPO / "evidence" / family / role
    manifest_raw, index_raw = (directory / "manifest.json").read_bytes(), (directory / "records.json").read_bytes()
    manifest, index = json.loads(manifest_raw), json.loads(index_raw)
    actual = [sha(manifest_raw), sha(index_raw), filehash(directory / "recording.tar.gz")]
    assert actual[1:] == [manifest["recordIndexSha256"], manifest["archiveSha256"]]
    if family == "virgl-native-buffer":
        assert actual == ["4d21b3f3fbbf1bf04bfb4031018f8ef3f935c4d96fa74d7c6b1015dfbc851722",
                          "1f53391aca79e771c27bcda31705bccb7ff21e6b39fd0552dd33e3dc4a93cdeb",
                          "c28313356f2f469e37e8791dd286ab131d16740a83fd166f3e22caa90b96d214"]
    else:
        assert manifest_raw == subprocess.check_output(["git", "show", f"{BASE}:evidence/{family}/{role}/manifest.json"])
    rows = index["records"] if isinstance(index, dict) else index
    expected = {row["path"]: row for row in rows}
    assert len(expected) == len(rows)
    bodies, links, seen = {}, {}, set()
    with tarfile.open(directory / "recording.tar.gz", "r|gz") as packed:
        for member in packed:
            assert member.name in expected and member.name not in seen
            seen.add(member.name)
            if member.isfile():
                bodies[member.name] = packed.extractfile(member).read()
            else:
                assert member.islnk()
                links[member.name] = member.linkname
    assert seen == set(expected)

    def body(name, visiting=frozenset()):
        if name in bodies:
            return bodies[name]
        assert name in links and name not in visiting
        raw = body(links[name], visiting | {name})
        bodies[name] = raw
        return raw

    checked_bytes = 0
    for name, pin in expected.items():
        raw = body(name)
        assert len(raw) == pin["bytes"] and sha(raw) == pin["sha256"]
        checked_bytes += len(raw)
        if family == "virgl-native-buffer":
            parts = Path(name)
            assert not parts.is_absolute() and ".." not in parts.parts
            path = ROOT / "worker" / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
        if family == "virgl-resource-capacity" and role == "worker" and name == "hot/receipt.json":
            receipts["storage"] = json.loads(raw)
        if family == "virgl-desktop-submit" and role == "worker" and name == "cold/recording/receipt.json":
            receipts["desktop"] = json.loads(raw)
    checks.append(dict(family=family, role=role, manifestSha256=actual[0], indexSha256=actual[1],
                       archiveSha256=actual[2], bodies=len(rows), bodyBytes=checked_bytes))
    print(f"{family}/{role}: {len(rows)} complete bodies authenticated", flush=True)
    del bodies, links

cold = ROOT / "worker/cold/recording"
receipt, report = json.loads((cold / "receipt.json").read_bytes()), json.loads((cold.parent / "report.json").read_bytes())
assert sha((cold / "receipt.json").read_bytes()) == report["receiptSha256"] == "50893a0c943bb5ee3fd3af027619b9626bec72709b7b7f10e24f139f8d992221"
for relative, pin in receipt["sources"].items():
    raw = (cold / "sources" / relative).read_bytes()
    assert sha(raw) == pin["sha256"] and len(raw) == pin["bytes"]
    if relative.startswith(("crates/core/src/", "crates/wasm/src/", "renderer/")):
        assert raw == (REPO / relative).read_bytes(), relative
for relative, pin in receipt["carriedHostSources"].items():
    assert sha((REPO / relative).read_bytes()) == pin, relative
for relative, pin in receipts["desktop"]["sources"].items():
    if relative.startswith(("crates/core/src/", "crates/wasm/src/", "renderer/virgl-command/")) and "/tests/" not in relative and relative != "crates/core/src/dev/virtio/gpu/control3d.rs":
        assert sha((REPO / relative).read_bytes()) == pin["sha256"], relative
for relative, pin in {**receipts["storage"]["sources"], **receipts["storage"]["carriedSources"]}.items():
    if relative.startswith("renderer/") and relative not in {"renderer/virgl-command/control-bridge.mjs", "renderer/virgl-command/tests/submit-acceptance.mjs"}:
        assert sha((REPO / relative).read_bytes()) == pin, relative
out = dict(predictions=["P1_authentication", "P11_cold"], worker=checks[0], carried=checks[1:],
           dependencyBodies=sum(row["bodies"] for row in checks[1:]), receiptSha256=sha((cold / "receipt.json").read_bytes()),
           heldHostPins=len(receipt["carriedHostSources"]), recordedHead=report["head"],
           submissionHead=subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(), sourcePins=len(receipt["sources"]))
assert out == json.loads((ROOT / "authentication.json").read_bytes())
print("All complete bodies and held boundaries reproduce the initial authentication.")
