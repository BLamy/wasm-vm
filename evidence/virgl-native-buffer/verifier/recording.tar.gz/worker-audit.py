"""Fresh critic: independently decode state, queue replies and original GPU words."""
import hashlib
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parent
COLD = ROOT / "worker/cold/recording"
HINTS = [0, 16, 32, 48, 64, 80, 96, 112]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


class Binary:
    def __init__(self, raw):
        self.raw, self.at = raw, 0

    def take(self, n):
        value = self.raw[self.at:self.at + n]
        assert len(value) == n
        self.at += n
        return value

    def read(self, fmt):
        return struct.unpack("<" + fmt, self.take(struct.calcsize("<" + fmt)))

    def u32(self):
        return self.read("I")[0]

    def identity(self):
        return self.read("IQ")


def control(raw):
    p = Binary(raw)
    assert p.take(8) == b"WV3DCTL2"
    epoch, generation, backing_generation, logical, gpu, backing = p.read("6Q")
    poisoned = p.take(1)[0]
    contexts = []
    for _ in range(p.u32()):
        identity, name = p.identity(), p.take(p.u32())
        members = [p.identity() for _ in range(p.u32())]
        contexts.append(dict(identity=identity, name=name.hex(), members=members))
    resources = []
    for _ in range(p.u32()):
        identity, metadata, attached = p.identity(), p.read("11I"), p.take(1)[0]
        mapping = None
        if attached:
            gen = p.read("Q")[0]
            mapping = dict(generation=gen, entries=[p.read("QI") for _ in range(p.u32())])
        resources.append(dict(identity=identity, metadata=metadata, backing=mapping))
    assert p.at == len(raw)
    return dict(epoch=epoch, nextGeneration=generation, nextBackingGeneration=backing_generation,
                logicalBytes=logical, gpuBytes=gpu, backingBytes=backing, poisoned=poisoned,
                contexts=contexts, resources=resources)


def check_record(value):
    for kind in ["transport", "submit"]:
        assert sha(bytes.fromhex(value[kind + "Canonical"])) == value[kind + "Digest"]
    assert struct.unpack_from("<H", bytes.fromhex(value["ring"]["used"]), 2)[0] == value["usedIndex"]
    request, response = bytes.fromhex(value["request"]), bytes.fromhex(value["response"])
    if response != b"\xa5" * 24:
        expected = bytearray(24)
        flags = struct.unpack_from("<I", request, 4)[0] & 1
        expected[:4], expected[16:21] = response[:4], request[16:21]
        struct.pack_into("<I", expected, 4, flags)
        if flags:
            expected[8:16] = request[8:16]
        assert response == expected
    return control(bytes.fromhex(value["transportCanonical"]))


def octets(data):
    return bytes(data if isinstance(data, list) else [data[str(i)] for i in range(len(data))])


native = (COLD / "native-submit.stderr").read_text()
records, guards, traces = [], [], []
for line, raw in enumerate(native.splitlines(), 1):
    for prefix, output in [("SUBMIT3D_PORTABLE_RECORD ", records), ("DESKTOP_SUBMIT_POINT ", guards)]:
        if raw.startswith(prefix):
            output.append(dict(line=line, point=json.loads(raw[len(prefix):])))
    if raw.startswith("SUBMIT3D_GUEST_TRACE "):
        traces.append(line)

points, hints, invalid, last = [], [], 0, None
for row in records:
    value, line = row["point"], row["line"]
    state = check_record(value)
    request, case = bytes.fromhex(value["request"]), value["case"]
    response = struct.unpack_from("<I", bytes.fromhex(value["response"]))[0]
    details = {}
    if case == "desktop-buffer-create":
        hint = struct.unpack_from("<I", request, 36)[0]
        hints.append(hint)
        assert response == 0x1100 and state["logicalBytes"] == state["gpuBytes"] == 16
        assert len(state["resources"]) == 1
        assert state["resources"][0]["metadata"] == (3, 0, 64, hint, 16, 1, 1, 1, 0, 0, 0)
        details["hint"] = hint
    if case in ["desktop-buffer-invalid", "desktop-buffer-budget-refusal"]:
        assert state == last
        assert response == (0x1201 if case.endswith("refusal") else 0x1205)
        invalid += case == "desktop-buffer-invalid"
        details["stateEqualPrevious"] = True
    if case == "desktop-buffer-budget":
        assert state["logicalBytes"] == state["gpuBytes"] == len(state["resources"]) * 4194304
        assert response == 0x1100
    if case == "desktop-buffer-budget-refusal":
        assert state["logicalBytes"] == state["gpuBytes"] == 33554432
    if case == "desktop-buffer-historical":
        hint = struct.unpack_from("<I", request, 36)[0]
        assert response == (0x1100 if hint in [16, 32, 524288] else 0x1205)
        details["hint"] = hint
        if hint == 524288:
            assert state["logicalBytes"] == 48 and state["gpuBytes"] == 32
    if case == "desktop-buffer-release":
        assert state["logicalBytes"] == state["gpuBytes"] == state["backingBytes"] == 0
    if case.startswith("desktop-buffer-"):
        points.append(dict(path="cold/recording/native-submit.stderr", line=line, case=case,
                           response=response, transportDigest=value["transportDigest"],
                           submitDigest=value["submitDigest"], state=state, **details))
    last = state
assert sorted(hints) == HINTS and invalid == 95
selected = [v for v in records if v["point"]["case"].startswith("desktop-")]
assert len(selected) == len(guards) == 294 and len(records) == 302 and len(traces) == 827
for selected_point, guard in zip(selected, guards):
    assert selected_point["point"]["case"] == guard["point"]["case"]
    assert guard["point"]["guard"] == "a5" * 40 and len(guard["point"]["machineDigest"]) == 64


def hardware(path, label):
    report = json.loads(path.read_bytes())
    assert report["status"] == "passed" and not report["trackedChanges"]
    assert report["browserErrors"] == {"console": [], "page": [], "requests": []}
    result = report["browserResult"]["result"]
    assert not result["guestExecution"] and not result["productionNegotiation"] and "Metal" in result["gpu"]
    planes, owners = [], []
    for i, run in enumerate(result["runs"]):
        raw = bytes.fromhex(next(d["bytes"] for d in run["originalData"] if d["id"] == 201))
        p, packets = Binary(bytes.fromhex(run["commands"])), []
        while p.at < len(p.raw):
            header = p.u32()
            packets.append((header & 255, p.read("I" * (header >> 16))))
        ubos = [w for op, w in packets if op == 27]
        assert len(ubos) == 2 and [w[:2] for w in ubos] == [(0, 1), (1, 1)]
        assert ubos[0][2:] == ubos[1][2:] and ubos[0][3:] == (16384, 201)
        offset = ubos[0][2] + 1023 * 16
        words = struct.unpack_from("<4I", raw, offset)
        expected = bytes((((word * 2) & 0xffffffff) >> ((run["seed"] % 4) * 8)) & 255 for word in words)
        assert bytes.fromhex(run["plane"]["bytes"]) == expected * 256 and run["expected"] == list(expected)
        assert struct.unpack_from("<3H", raw, 48) == (0, 1, 2)
        assert struct.unpack_from("<12f", raw) == (-1, -1, 0, 1, 3, -1, 0, 1, -1, 3, 0, 1)
        assert [w for op, w in packets if op == 6][-1] == (16, 0, 201)
        assert [w for op, w in packets if op == 11][-1] == (201, 2, 48)
        accepted = run["accepted"]
        owner = next(o for o in accepted["resources"] if o["identity"]["id"] == 201)
        create = next(e for e in run["events"] if e["type"] == "createResource" and e["resource"]["id"] == 201)
        attach = next(e for e in run["events"] if e["type"] == "attachBacking" and e["resource"]["id"] == 201)
        assert create["resource"] == owner["identity"] and create["metadata"] == owner["metadata"]
        assert owner["metadata"]["bind"] == run["hint"]
        assert owner["backing"]["generation"] == attach["backingGeneration"]
        assert owner["backing"]["byteLength"] == len(raw)
        attached_bytes = b"".join(octets(s["data"]) for s in attach["segments"])
        assert attached_bytes == b"\xa3" * len(raw) and raw != attached_bytes
        assert any(e["kind"] == "input" and bytes.fromhex(e["bytes"]) == raw for e in run["exchanges"])
        assert any(e["kind"] == "output" and bytes.fromhex(e["bytes"]) == expected * 256 for e in run["exchanges"])
        assert run["snapshot"]["gpuDraws"] == 1 and run["snapshot"]["liveSyncs"] == 0
        for point in run["states"]:
            n, h = point["native"], point["host"]
            assert sha(bytes(n["canonicalBytes"])) == n["digest"]
            state = control(bytes(n["canonicalBytes"]))
            total = sum(o["metadata"]["width"] if o["metadata"]["target"] == 0
                        else o["metadata"]["width"] * o["metadata"]["height"] * 4 for o in n["resources"])
            assert state["gpuBytes"] == n["gpuBytes"] == h["store"]["budgets"]["gpuBytes"] == total
            for o in n["resources"]:
                host = next(v for v in h["resources"] if v["transport"]["id"] == o["identity"]["id"])
                assert host["transport"] == o["identity"]
                if point["label"] in ["accepted job", "GPU draw completed"]:
                    assert o["identity"] in next(c["resources"] for c in n["contexts"] if c["identity"]["id"] == 1)
        before, after = [p for p in run["states"] if p["label"] in ["accepted job", "GPU draw completed"]]
        assert before["native"]["resources"] == after["native"]["resources"]
        assert before["host"]["resources"] == after["host"]["resources"]
        for record in run["records"]:
            check_record(record)
        cancelled = [e for e in run["events"] if e["type"] == "cancelJob"]
        assert len(cancelled) == 1 and run["events"][-3]["type"] == "reset"
        reset = check_record(next(v for v in run["records"] if v["case"] == "buffer selected profile after reset"))
        assert reset["epoch"] > int(accepted["epoch"], 16) and len(reset["resources"]) == 1
        assert reset["resources"][0]["metadata"][3] == run["hint"]
        released = check_record(run["records"][-1])
        assert not released["resources"] and released["gpuBytes"] == 0
        planes.append(dict(point=f"{label}:browserResult.result.runs[{i}]", seed=run["seed"], hint=run["hint"],
                           expected=list(expected), wordOffset=offset, originalWords=words,
                           inputSha256=sha(raw), outputSha256=sha(expected * 256), pixels=256,
                           transportDigest=before["native"]["digest"]))
        owners.append(dict(run=i, owner=owner, dirtyAttachmentDigest=sha(attached_bytes),
                           completedStateDigest=after["native"]["digest"], cancelledKey=cancelled[0]))
    seeds = {p["seed"] for p in planes}
    assert len(planes) == 24 and len(seeds) == 3
    assert {(p["seed"], p["hint"]) for p in planes} == {(s, h) for s in seeds for h in HINTS}
    refusals = []
    for i, row in enumerate(result["refusals"]["rows"]):
        record = row["record"]
        response = struct.unpack_from("<I", bytes.fromhex(record["response"]))[0]
        assert response == (0x1201 if "budget" in row["label"] else 0x1205)
        assert record["transportCanonical"] == bytes(row["native"]["canonicalBytes"]).hex()
        check_record(record)
        refusals.append(dict(index=i, label=row["label"], response=response, digest=record["transportDigest"],
                             hostGpuBytes=row["host"]["store"]["budgets"]["gpuBytes"], objects=row["objects"]))
    assert len(refusals) == 67 and len(result["owners"]["accepted"]["resources"]) == 64
    assert len(result["owners"]["historical"]["events"][-1]["resources"]) == 16
    names = [v["name"] for v in result["nativeCalls"]]
    assert names.count("drawElements") == 24 and "finish" not in names
    for name in ["bindBufferRange", "copyBufferSubData", "shaderSource", "compileShader", "linkProgram", "readPixels",
                 "fenceSync", "clientWaitSync", "getBufferSubData", "deleteSync"]:
        assert name in names
    return dict(reportSha256=sha(path.read_bytes()), planes=planes, acceptedPoints=owners,
                refusalPoints=refusals, hardwareCalls=len(names), seeds=sorted(seeds), gpu=result["gpu"])


covered = json.loads((COLD / "native-coverage.json").read_bytes())
f = next(f for d in covered["data"] for f in d["files"] if f["filename"].endswith("/dev/virtio/gpu/control3d.rs"))
coverage_points = []
for line, column, count in [(58, 30, 139), (58, 51, 122), (58, 71, 114), (58, 86, 91), (59, 17, 91)]:
    segment = [v for v in f["segments"] if (v[0], v[1]) <= (line, column)][-1]
    assert segment[2] == count and segment[3] and not segment[5]
    coverage_points.append(dict(line=line, column=column, count=count, segment=segment))
report = dict(nativeRecords=len(records), guards=len(guards), traces=len(traces), nativePoints=points,
              coveragePoints=coverage_points, nativeStderrSha256=sha((COLD / "native-submit.stderr").read_bytes()),
              workerHardware=hardware(COLD / "hardware/report.json", "cold/recording/hardware/report.json"),
              independentHardware=hardware(ROOT / "hardware-independent/report.json", "hardware-independent/report.json"),
              state="HELD")
(ROOT / "independent-worker-audit.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(dict(state=report["state"], nativeRecords=len(records), guards=len(guards), traces=len(traces),
                      pixels=6144, independentPixels=6144)))
