//! wasm-vm-core: the emulator itself.
//!
//! This crate is `no_std`-friendly (build with `--no-default-features`) and must stay
//! free of every browser- and JS-facing dependency. Anything that talks to the web
//! belongs in `wasm-vm-wasm`; anything that talks to a host OS belongs in `wasm-vm-cli`
//! or behind the `std` feature here.
//!
//! # Feature matrix
//!
//! | Features     | `std` | Tracing | Notes                                         |
//! |--------------|-------|---------|-----------------------------------------------|
//! | *(none)*     | no    | off     | leanest `no_std` build (embed / wasm)         |
//! | `std`        | yes   | off     | default; host integration                     |
//! | `trace`      | no    | on      | `no_std` + instruction-trace hooks (E0-T16)   |
//! | `std,trace`  | yes   | on      | full host + tracing                           |
//! | `gpu-trace`  | no    | off     | bounded virtio-gpu probe trace (E5-T07a)     |
//!
//! Diagnostics route through the [`log`] facade (never `println!`), so hosts choose the
//! backend (`env_logger` in the CLI, `console_log` in wasm). **Tracing is zero-cost when
//! off**: it is a generic [`trace::TraceSink`] type parameter whose [`trace::NullSink`]
//! has empty `#[inline(always)]` methods, so a release build erases the hook entirely
//! (proven by `tools/check-zero-cost.sh`). Only genuine data-cost machinery is gated by
//! `#[cfg(feature = "trace")]`.

#![cfg_attr(not(feature = "std"), no_std)]

extern crate alloc;

pub mod block;
pub mod bus;
pub mod compile_queue;
pub mod csr;
pub mod decode;
pub mod decode_c;
pub mod desktop_restore;
pub mod desktop_snapshot;
pub mod dev;
pub mod diag;
pub mod dispatch;
pub mod fdt;
pub mod hart;
pub mod htif;
pub mod jit;
pub mod loader;
pub mod mmio;
pub mod mmu;
pub mod platform;
pub mod pmp;
pub mod prof;
pub mod ram;
pub mod resume;
pub mod sbi;
pub mod snapshot;
pub mod softfloat;
pub mod time;
pub mod tlb;
pub mod trace;
#[cfg(feature = "zicsr-stub")]
pub mod zicsr_stub;

use hart::{Hart, Trap};
use htif::{Htif, HtifStatus};
use loader::ElfError;
use mmio::SystemBus;
use ram::Ram;

/// Private run-loop dispatch. Public traced runs always keep their recording capture, even for
/// sinks that decline JIT records; only `Machine::run` selects the unit retirement capture.
enum RunCapture<'a, T: trace::TraceSink> {
    Unit,
    Traced(&'a mut T),
}

impl<T: trace::TraceSink> RunCapture<'_, T> {
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(always)]
    fn wants_records(&self) -> bool {
        match self {
            Self::Unit => false,
            Self::Traced(sink) => sink.wants_records(),
        }
    }

    #[inline]
    fn step(&mut self, machine: &mut Machine, cached: bool) -> Result<(), Trap> {
        #[cfg(feature = "zicsr-stub")]
        let _ = cached;
        match self {
            #[cfg(not(feature = "zicsr-stub"))]
            Self::Unit if cached => machine.step_cached_with_capture(hart::UnitCapture),
            Self::Unit => machine.hart.step(&mut machine.bus),
            #[cfg(not(feature = "zicsr-stub"))]
            Self::Traced(sink) if cached => {
                machine.step_cached_with_capture(hart::RecordingCapture::new(*sink))
            }
            Self::Traced(sink) => machine.hart.step_traced(&mut machine.bus, *sink),
        }
    }
}

/// The crate version, sourced from `Cargo.toml`.
pub fn version() -> &'static str {
    env!("CARGO_PKG_VERSION")
}

/// How a [`Machine::run`] loop ended. Exhaustively matched by the CLI and wasm
/// layers — no `_ =>` swallowing (the whole point of the enum).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RunOutcome {
    /// The guest requested exit via the HTIF `tohost` convention.
    Exited(u64),
    /// A trap escaped the run loop (no CSR trap delivery at Level 0).
    Trapped(Trap),
    /// The instruction budget was exhausted without exit or trap.
    MaxInstrs,
    /// E2-T17: the guest asked the platform to power off or reboot — via the syscon test
    /// finisher (`sifive,test0`, MMIO at `TEST_BASE`) or SBI SRST reboot. Carries the reason
    /// so the host can exit cleanly (poweroff/fail) or re-boot (reboot). NO `process::exit`
    /// happens in the core — the value is surfaced so the CLI and the wasm boundary decide.
    Reset(ExitReason),
}

/// E2-T17: why the guest reset the platform — the typed outcome of a syscon finisher write
/// (or SBI SRST reboot), propagated out of the run loop to the host.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ExitReason {
    /// Clean power off (finisher `0x5555`) — the host should exit 0.
    PowerOff,
    /// Restart (finisher `0x7777` / SBI SRST reboot) — the CLI re-boots a fresh machine.
    Reboot,
    /// Guest-signalled failure (finisher `0x3333`, code in the upper 16 bits) — exit `code`.
    Fail(u16),
}

/// E2-T21: why laying out a Linux boot triple failed. Returned by [`Machine::place_and_boot`]
/// so every host (CLI, wasm) reports the same specific cause instead of re-deriving placement.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BootError {
    /// The `--ram-mib` size produced an invalid platform map.
    PlatformInvalid,
    /// The kernel's runtime footprint (`.bss` included) does not fit above `KERNEL_BASE`.
    KernelTooBig,
    /// `kernel_end` is so large that 2 MiB-aligning the initrd above it would wrap.
    KernelEndOverflow,
    /// The initrd does not fit in the gap between the kernel and the DTB.
    InitrdNoFit,
    /// The DTB does not fit near the top of RAM.
    DtbNoFit,
    /// A blob write (initrd/DTB) hit a bus fault.
    Load(bus::BusFault),
}

/// E2-T21: where the boot triple landed in DRAM (for host-side diagnostics/logging).
#[derive(Debug, Clone, Copy)]
pub struct BootLayout {
    pub kernel_end: u64,
    pub initrd: Option<fdt::Initrd>,
    pub dtb_addr: u64,
    pub dtb_len: usize,
}

/// A full Level-0 machine: one hart on a system bus, plus optional HTIF exit
/// watching. Grown from the E0-T01 placeholder — the `new`/`ram_len` surface is
/// preserved (E0-T01's verified tests and the wasm wrapper depend on it).
/// E4-T01: the base PC-sampling stride — a prime near 1024 so ~1 retire in ~1024 is sampled. The
/// actual stride is this plus a small per-sample jitter (see `prof_next_stride`); a prime base plus
/// jitter means no power-of-two or round loop period can systematically dodge every sample.
const PROF_STRIDE_BASE: u32 = 1021;
/// E4-T01: jitter span added to [`PROF_STRIDE_BASE`] each sample (stride ∈ 1021..=1148). Only the
/// (real-CSR) sampler reads it; the quarantined zicsr-stub build compiles the sampler out.
#[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
const PROF_STRIDE_JITTER: u32 = 128;

/// Persistent queue views for the six-queue virtio-console multiport device.  Keeping the views
/// in the Machine (rather than rebuilding them on every instruction) preserves the shared
/// virtqueue shadows across bounded run calls while reset/reconfiguration can explicitly discard
/// them through the console service.
struct VirtioConsoleService {
    slot_index: usize,
    state: alloc::rc::Rc<core::cell::RefCell<dev::virtio::console::ConsoleState>>,
    port0_receiveq: Option<dev::virtio::queue::Virtqueue>,
    port0_transmitq: Option<dev::virtio::queue::Virtqueue>,
    control_receiveq: Option<dev::virtio::queue::Virtqueue>,
    control_transmitq: Option<dev::virtio::queue::Virtqueue>,
    agent_receiveq: Option<dev::virtio::queue::Virtqueue>,
    agent_transmitq: Option<dev::virtio::queue::Virtqueue>,
}

/// Append one device-side virtqueue shadow to a whole-machine resume section. The transport
/// contains the guest's ring addresses; this shadow contains the device's free-running cursors.
fn append_resume_queue(
    out: &mut alloc::vec::Vec<u8>,
    queue: &Option<dev::virtio::queue::Virtqueue>,
) {
    match queue {
        Some(queue) => {
            out.push(1);
            let (last_avail, used) = queue.ring_indices();
            out.extend_from_slice(&last_avail.to_le_bytes());
            out.extend_from_slice(&used.to_le_bytes());
        }
        None => {
            out.extend_from_slice(&[0, 0, 0, 0, 0]);
        }
    }
}

/// Parse the fixed transport/ring prefix shared by the desktop device visitors. Parsing is done
/// against a detached empty transport, so malformed queue metadata is rejected before the live
/// target's MMIO file or service cursors are changed.
type ResumeDeviceParts<'a> = (
    dev::virtio::mmio::VirtioMmio,
    alloc::vec::Vec<(bool, u16, u16)>,
    &'a [u8],
);

/// Sound's original unversioned resume prefix used Rust tuple order (control/event/RX/TX),
/// not virtio queue-index order. Its cursors cannot be silently reinterpreted. Layout 2 puts a
/// little-endian version word after the transport/cursors and before the unchanged sound codec.
/// Keep this section-local: container-v1 snapshots without sound remain compatible.
const SND_RESUME_LAYOUT_VERSION: u32 = 2;

fn parse_resume_device_prefix(
    payload: &[u8],
    tag: u32,
    queue_count: usize,
) -> Result<ResumeDeviceParts<'_>, crate::resume::SnapshotError> {
    let mut reader = crate::resume::Reader::new(payload, tag);
    let mut transport = dev::virtio::mmio::VirtioMmio::empty();
    transport.restore_transport(&mut reader)?;
    let mut rings = alloc::vec::Vec::with_capacity(queue_count);
    for index in 0..queue_count {
        let has_queue = reader.bool()?;
        let last_avail = reader.u16()?;
        let used = reader.u16()?;
        let queue_state = *transport.queue(index);
        if (!has_queue && (last_avail != 0 || used != 0))
            || (has_queue
                && (!queue_state.ready
                    || dev::virtio::queue::Virtqueue::new(&queue_state, 256).is_err()))
        {
            return Err(crate::resume::SnapshotError::BadComponentState { tag });
        }
        rings.push((has_queue, last_avail, used));
    }
    if tag == crate::resume::section::VIRTIO_SND && reader.u32()? != SND_RESUME_LAYOUT_VERSION {
        return Err(crate::resume::SnapshotError::BadComponentState { tag });
    }
    let component = reader.remaining_bytes()?;
    Ok((transport, rings, component))
}

fn restore_resume_queues(
    slot: &alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
    rings: &[(bool, u16, u16)],
    tag: u32,
) -> Result<alloc::vec::Vec<Option<dev::virtio::queue::Virtqueue>>, crate::resume::SnapshotError> {
    let mut restored = alloc::vec::Vec::with_capacity(rings.len());
    let transport = slot.borrow();
    for (index, &(has_queue, last_avail, used)) in rings.iter().enumerate() {
        if !has_queue {
            restored.push(None);
            continue;
        }
        let queue_state = *transport.queue(index);
        let mut queue = dev::virtio::queue::Virtqueue::new(&queue_state, 256)
            .map_err(|_| crate::resume::SnapshotError::BadComponentState { tag })?;
        queue.set_ring_indices(last_avail, used);
        restored.push(Some(queue));
    }
    Ok(restored)
}

pub struct Machine {
    hart: Hart,
    bus: SystemBus,
    htif: Option<Htif>,
    /// Last observed `tohost` value — the watch fires only on CHANGE, giving
    /// exactly-once semantics for command writes ("logged once", E0-T11).
    last_tohost: u64,
    /// Count of unsupported (LSB-clear, non-zero) command writes seen.
    htif_commands: u64,
    /// CLINT shared state (E1-T12), present when [`Self::enable_clint`] attached the device.
    /// The run loop advances `mtime` from the retire count and samples MTIP/MSIP into `mip`.
    clint: Option<alloc::rc::Rc<core::cell::RefCell<dev::clint::ClintState>>>,
    /// `mtime` advances one tick per `clock_div` retired instructions (deterministic clock). This is
    /// the ICount [`time::TimeMode`] — the default, and the source the E4-T25 lockstep/fuzz rig runs
    /// under so timer interrupts land at identical retire indices on both engines.
    clock_div: u64,
    /// Sub-divider remainder: retirements not yet worth a whole `mtime` tick.
    tick_accum: u64,
    /// E4-T24: when `Some`, `mtime` is driven from the injected host wall clock (scaled to the DT
    /// timebase, with the monotonicity-clamp + slew + jump policy) instead of the retire count. The
    /// per-retire `advance_clock` is then a no-op; `mtime` is recomputed at each block boundary from
    /// [`Self::mono_clock`]. `None` (the default) keeps the deterministic ICount clock so every
    /// existing determinism / lockstep / predecode-diff gate stays byte-identical.
    wall_time: Option<time::TimeSource>,
    /// Opt-in ICount idle ceiling. Busy execution retains the deterministic retire clock.
    idle_pacer: Option<time::IdlePacer>,
    /// E4-T24: the injected monotonic host clock (CLI `Instant`, browser `performance.now()`, or a
    /// test mock). Read only for wall time or opt-in idle pacing; core names no host time API.
    mono_clock: Option<alloc::boxed::Box<dyn time::MonotonicClock>>,
    /// E4-T24: the last discontinuous `mtime` jump (the documented suspend/resume exception), for the
    /// host to surface / the guest to resync from the RTC. Cleared by [`Self::take_time_jump`].
    last_time_jump: Option<time::TimeJump>,
    /// PLIC shared state (E1-T13), present when [`Self::enable_plic`] attached the device. The
    /// run loop samples the per-context EIP levels into `mip.MEIP`/`mip.SEIP`.
    plic: Option<alloc::rc::Rc<core::cell::RefCell<dev::plic::PlicState>>>,
    /// E2-T03 (ADR 0002): when set, the emulator IS the M-mode firmware — `ecall` from S-mode
    /// is answered by [`sbi::dispatch`] in Rust instead of being delivered to a guest M-mode
    /// handler. Off by default (bare-metal tests and RISCOF keep architectural delivery).
    /// (Only read on the real-CSR path; the quarantined zicsr-stub build has no S-mode.)
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    builtin_sbi: bool,
    /// SBI console state (E2-T04): host output sink + input queue for DBCN/legacy console.
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    sbi_state: sbi::SbiState,
    /// E2-T07: the ns16550a UART + its PLIC IRQ-10 line, when [`Self::enable_uart16550`]
    /// attached it. The run loop ticks the char-timeout clock and mirrors the level.
    uart: Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::uart16550::Uart16550>>,
        dev::plic::IrqLine,
    )>,
    /// E2-T16: the goldfish RTC + its PLIC IRQ-11 line, when [`Self::enable_rtc`] attached it.
    /// The run loop polls the alarm and mirrors its interrupt level into the PLIC.
    rtc: Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::rtc::GoldfishRtc>>,
        dev::plic::IrqLine,
    )>,
    /// E2-T20: always-on interrupt/trap counters + the sliding-window storm detector and WFI
    /// watchdog. Plain increments; the detector runs only on the quantum boundary.
    irqstats: diag::irqstats::IrqStats,
    /// E2-T20: storm detection armed (default on). When on, the run loop checks the detector
    /// each quantum and prints a diagnosis to the log on a fire.
    storm_detect: bool,
    /// E4-T01: the always-compiled hot-PC / per-subsystem profiler ([`prof::ProfStats`]). Sampling
    /// is RUNTIME-gated by [`Self::set_profiling`] (default OFF) — the same always-on-struct +
    /// runtime-flag shape as `storm_detect`, so a normal (unprofiled) run pays only a single
    /// not-taken branch per retire.
    prof: prof::ProfStats,
    /// E4-T01: profiler armed. Off by default; the native `--profile` path and the wasm `getProfile`
    /// surface arm it.
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    profiling: bool,
    /// E4-T01: retires remaining until the next PC sample. Counts down; on zero we sample and reload
    /// it with a fresh jittered stride so no fixed loop period can hide in a sampling blind spot.
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    prof_countdown: u32,
    /// E4-T01: LCG state feeding the per-sample stride jitter. Deterministic (no wall clock) so a
    /// native and a wasm run sample the identical instruction stream.
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    prof_lcg: u32,
    /// E4-T01 phase 3: the injected monotonic host timer (outer crates provide the impl; core stays
    /// `no_std`). Set by [`Self::set_host_timer`], which also arms profiling and hands the same `Rc`
    /// to the bus so the cold device/walk paths can time themselves. `run_traced` reads it ONCE at
    /// entry and ONCE at exit to measure the total profiled wall-span (CPU time is that total minus
    /// the cold device+walk time — the hot loop reads no clock).
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    host_timer: Option<alloc::rc::Rc<dyn prof::HostTimer>>,
    /// E4-T01 phase 3: total profiled host nanoseconds measured across `run_traced` calls (the once-
    /// per-run entry→exit delta, accumulated). Fed to [`Self::prof_report`] as the span CPU-interp
    /// time is derived from by subtraction. Zero when no timer is injected.
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    prof_total_ns: u64,
    /// E2-T17: the syscon test finisher's shared reset latch, when [`Self::enable_syscon`]
    /// attached it. The run loop drains it and returns [`RunOutcome::Reset`]. (Only read on
    /// the real-CSR path; the quarantined zicsr-stub build compiles the drain + `enable_syscon`
    /// out, so the field is inert there.)
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    syscon: Option<dev::syscon::ResetCell>,
    /// E2-T08: the nine virtio-mmio slots + their PLIC lines (IRQ 1..=9), when
    /// [`Self::enable_virtio_slots`] attached them. The run loop mirrors each slot's
    /// InterruptStatus level.
    virtio: alloc::vec::Vec<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        dev::plic::IrqLine,
    )>,
    /// E5-T06d/E5-T15a: virtio-gpu service state (shared presentation sink + deferred controlq /
    /// cursorq views) and its selected optional slot. The sink is replaced by a browser callback
    /// after assembly; headless/native machines retain the GPU with [`dev::virtio::gpu::NullSink`].
    #[allow(clippy::type_complexity)]
    gpu: Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::gpu::GpuState>>,
        Option<dev::virtio::queue::Virtqueue>,
        Option<dev::virtio::queue::Virtqueue>,
        usize,
    )>,
    /// E2-T11: virtio-blk service state (shared backend state + the persistent ring view),
    /// when [`Self::enable_virtio_blk`] plugged a backend into slot 0. Serviced at every
    /// instruction boundary the guest has kicked.
    blk: Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::blk::BlkState>>,
        Option<dev::virtio::queue::Virtqueue>,
    )>,
    /// E4-T03: ADDITIONAL virtio-blk devices attached via [`Self::enable_virtio_blk_at`] (the bench
    /// harness's read-only overlay as `/dev/vdb`). Each entry is `(shared state, lazily-built ring
    /// view, virtio slot index)`; serviced at the same instruction boundary as the primary `blk` so
    /// the guest's reads complete — without which the guest hangs the moment it first reads the drive.
    /// These carry no writes/flush, so — unlike the primary `blk` — they are intentionally NOT drained
    /// by `quiesce` or serialized by the snapshot (a read-only drive has nothing to lose on restart).
    #[allow(clippy::type_complexity)]
    extra_blk: alloc::vec::Vec<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::blk::BlkState>>,
        Option<dev::virtio::queue::Virtqueue>,
        usize,
    )>,
    /// E3-T13: virtio-net service state (shared backend state + the persistent receiveq /
    /// transmitq ring views), when [`Self::enable_virtio_net`] plugged a backend into slot 1.
    /// Serviced at every boundary the guest has kicked OR the backend has an rx frame ready.
    #[allow(clippy::type_complexity)]
    net: Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::net::NetState>>,
        Option<dev::virtio::queue::Virtqueue>,
        Option<dev::virtio::queue::Virtqueue>,
    )>,
    /// Host-side control for the stable virtio-net adapter. The guest-visible device and queues
    /// remain intact when an embedding switches from WebSocket to DERP/Headscale or another
    /// backend at a quiescent run boundary.
    net_backend: Option<dev::virtio::net::NetBackendHandle>,
    /// virtio-rng service state (shared source state + the persistent requestq ring view), when
    /// [`Self::enable_virtio_rng`] plugged an entropy source into slot 2. Serviced at every
    /// boundary the guest has kicked. Seeds the guest CRNG so early TLS handshakes don't stall.
    #[allow(clippy::type_complexity)]
    rng: Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::rng::RngState>>,
        Option<dev::virtio::queue::Virtqueue>,
    )>,
    /// E5-T11b: virtio-input keyboard queue state (eventq + statusq), installed in slot 3 with
    /// a host-owned LED sink. Serviced at every instruction boundary after guest queue kicks.
    #[allow(clippy::type_complexity)]
    keyboard: Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::input::InputState>>,
        Option<dev::virtio::queue::Virtqueue>,
        Option<dev::virtio::queue::Virtqueue>,
    )>,
    /// E5-T11b: retained handle for the host/UI's NumLock/CapsLock/ScrollLock indicator state.
    keyboard_leds: Option<dev::virtio::input::keyboard::KeyboardLedHandle>,
    /// E5-T14a: absolute tablet queue state, installed in slot 4 alongside the keyboard.
    #[allow(clippy::type_complexity)]
    tablet: Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::input::InputState>>,
        Option<dev::virtio::queue::Virtqueue>,
        Option<dev::virtio::queue::Virtqueue>,
    )>,
    /// E5-T14a: relative mouse queue state, installed in slot 5 alongside the tablet.
    #[allow(clippy::type_complexity)]
    mouse: Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::input::InputState>>,
        Option<dev::virtio::queue::Virtqueue>,
        Option<dev::virtio::queue::Virtqueue>,
    )>,
    /// E5-T19d: guest-facing virtio-snd state. The control/event/playback ring views are kept
    /// across instruction boundaries just like the other virtio devices; the injected clock and
    /// sink keep pacing deterministic while allowing native WavSink and browser sinks to share
    /// the same Machine assembly seam. The capture source is the corresponding host-owned rxq
    /// adapter; the default is deterministic silence until a browser permission session replaces
    /// it with a shared-ring consumer.
    #[allow(clippy::type_complexity)]
    snd: Option<(
        usize,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::snd::SndState>>,
        Option<dev::virtio::queue::Virtqueue>,
        Option<dev::virtio::queue::Virtqueue>,
        Option<dev::virtio::queue::Virtqueue>,
        Option<dev::virtio::queue::Virtqueue>,
        alloc::rc::Rc<dyn dev::virtio::snd::AudioClock>,
        alloc::boxed::Box<dyn dev::virtio::snd::AudioSink>,
        alloc::boxed::Box<dyn dev::virtio::snd::AudioCaptureSource>,
    )>,
    /// E5-T23b: virtio-console port-0/control/agent ring views and the bounded host-side channel.
    /// The agent uses port 1 (queues 4 and 5); the UART/SBI console is intentionally not routed
    /// through this state.
    console: Option<VirtioConsoleService>,
    /// E5-T26e: host-side desktop restore state persists across adapter construction so a
    /// successful viewport/agent reconciliation cannot disappear when the call returns.
    desktop_restore_host:
        alloc::rc::Rc<core::cell::RefCell<desktop_restore::DesktopRestoreHostState>>,
    /// E3-T12c3: the snapshot coherence binding — the base disk image this machine is running against
    /// (`base_image_hash`), the emulator build (`core_hash`), and the monotonic overlay-commit
    /// generation. `save_resume` stamps all three into the blob header; `load_resume` validates them
    /// FIRST (before any component is restored) so a snapshot is never resumed onto a diverged disk.
    /// Defaults are all-zero / generation 0 — the RAM-only determinism harness round-trips against
    /// itself; a disk-backed host sets the real base hash and advances the generation on each commit.
    coherence: SnapshotCoherence,
    /// E4-T05 Phase A: the predecoded block cache. A/B TOGGLE — `block_cache_enabled` (runtime,
    /// default OFF unless the `predecode` feature flips it) selects the cached vs the legacy
    /// decode path IN ONE BINARY, so the differential harness can prove cache-ON produces
    /// BYTE-IDENTICAL retire traces to cache-OFF. The cache memoizes decode ONLY: execution
    /// still feeds each micro-op through the SAME `execute()` and the run loop still re-syncs
    /// devices + samples interrupts PER RETIRE (interrupt batching is Phase C, untouched here).
    block_cache_enabled: bool,
    /// The physically-keyed decoded-block store (Phase A: conservatively flushed on `fence.i`
    /// and on any guest store — correct but slow; Phase B adds the page-level has-code bitmap).
    block_cache: dispatch::BlockCache,
    /// Cursor into the block currently being replayed. A branch/jump/interrupt/trap moves the PC
    /// off its expected next VA, invalidating the cursor so the next step re-keys by physical PC
    /// (handling branches into mid-block). It holds the block itself, so a mid-block continuation
    /// and the batching boundary test are O(1) with no cache probe; every path that drops a live
    /// block from the cache (generation flush, page flush) clears it. Never serialized.
    block_cursor: Option<BlockCursor>,
    /// E4-T30: production-visible proof that entry PCs reuse the predecoded cache instead of
    /// rebuilding it. `(hits, builds)` is deliberately separate from `BlockDiscovery`: discovery
    /// counts every execution for JIT tier-up, while these counters describe decode-cache work.
    block_entry_hits: u64,
    block_builds: u64,
    /// Partial-block continuations whose decoded block had been evicted from `block_cache` while
    /// its compiled code was still reachable (a browser in-module direct chain enters a compiled
    /// successor without the entry lookup that keeps its decoded block resident), so the core
    /// re-decoded the block from physical memory to resume the cursor at the untranslated op.
    /// Observation-only; never serialized.
    jit_partial_resume_rebuilds: u64,
    /// Partial-block continuations that could NOT resume the cursor even after the physical
    /// re-decode (a `debug_assert` in debug builds). Expected to stay zero; surfaced by the CLI's
    /// `--jit` coverage summary so any release run that ever reaches the non-transparent fallback
    /// is visible rather than silent. Observation-only; never serialized.
    jit_partial_resume_failures: u64,
    /// Last PMP state whose execute permissions the decoded/compiled caches reflect. Effective
    /// permissions depend on both the PMP registers and the current privilege: unlocked entries
    /// are bypassed in M-mode but enforced in S/U-mode.
    pmp_revision_seen: u64,
    pmp_mode_seen: csr::Priv,
    /// Test-only work counter; never consulted by runtime permission decisions.
    #[cfg(all(test, not(feature = "zicsr-stub")))]
    pmp_audited_ops: u64,
    /// E4-T08: hotness counters + translation-candidate discovery. The block cache learns to
    /// NOMINATE JIT candidates: each block entry bumps a saturating counter, and crossing the
    /// design-doc threshold enqueues a `TranslationRequest` (dedup'd, requeued after any
    /// invalidation via a generation bump). Discovery is OBSERVATION-ONLY — it never changes the
    /// executed sequence, so `predecode_diff` byte-identity is preserved — and nothing consumes
    /// the queue yet (the translator is E4-T09/T10).
    discovery: dispatch::BlockDiscovery,
    /// E4-T05 Phase C: interrupt/device-sync BATCHING. A DISTINCT toggle from
    /// `block_cache_enabled` (batching requires the cache, but the cache runs WITHOUT batching as
    /// the byte-identical Phase-A/B mode the `predecode_diff` gate proves). When on, the device
    /// fabric re-sync (`sync_clint`/UART/RTC/virtio/`sync_plic`/`sync_sbi_timer`/DMA-drain) and the
    /// `next_interrupt` sampling are moved from PER-RETIRE to the BLOCK BOUNDARY — sampled once per
    /// `DecodedBlock` (≤128 ops) instead of once per instruction. The retire-count clock
    /// (`advance_clock`), `irqstats.on_retire`, the profiler hook, and per-op trap/ecall/WFI
    /// handling stay per-retire, so `mtime` still crosses `mtimecmp` at the identical retire index;
    /// only the SAMPLING of the resulting interrupt defers ≤128 retires (architecturally legal —
    /// interrupts need only be taken in a timely manner). NOT byte-identical to legacy by design.
    interrupt_batching: bool,
    /// E4-T10: the compiled-block (T2) executor, when a native/browser JIT runtime is installed via
    /// [`Self::set_executor`]. Core stays `no_std` and holds no engine — the run loop drives this
    /// trait object: at a block boundary, if `jit_enabled` and the block is compiled, it executes
    /// via the executor INSTEAD of interpreting; a miss (uncompiled / faulted-out) falls back to the
    /// interpreter. `None` on every build until a runtime is installed.
    executor: Option<jit::BoxedExecutor>,
    /// E4-T19: block boundaries elapsed since the last JIT compile-queue drain. The queue is drained
    /// into BATCHES (connected components) rather than one block at a time, so a burst of newly-hot
    /// blocks is allowed to ACCUMULATE for up to [`JIT_PUMP_INTERVAL`] boundaries (or until it reaches
    /// [`JIT_BATCH_TRIGGER`]) before being packed into modules — this is what lets `pump` see a whole
    /// component at once instead of a trickle of singletons. Bounded either way, so compilation is
    /// deferred by at most a few boundaries and never starved. Read only on the real-CSR run-loop
    /// path; the quarantined `zicsr-stub` build compiles the pump out, so the field is dead there.
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    jit_pump_ticks: u32,
    /// E4-T32: blocks still allowed to enter the synchronous compiler during the current public
    /// `run` call. This is reset from the installed executor at each call and shared by every
    /// periodic pump plus the one bounded final pump, so a browser `runChunk` has one hard compile
    /// budget rather than an accidental budget per block boundary.
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    jit_run_attempt_remaining: usize,
    /// Discovery nominations still allowed to enter the priority queue during the current public
    /// run. This separately bounds synchronous staging/backpressure work before compilation.
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    jit_run_staging_remaining: usize,
    /// True while a host cooperative slice is active. Normally one `run_traced` call owns the
    /// scope; browser `runChunk` opens it around all of its internal UART/persistence sub-runs.
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    jit_run_scope_active: bool,
    /// True when the active scope was opened by the browser/host wrapper rather than by an
    /// unscoped `run` call. Host-owned terminal scopes preserve queued translations for a later
    /// quantum; an ordinary `run` may flush its final warmed translation before returning.
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    jit_run_scope_external: bool,
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    jit_run_submissions_before: u64,
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    jit_run_staged_nominations: u64,
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    jit_run_attempted_blocks: u64,
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    jit_run_final_pumps: u64,
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    jit_run_final_attempted_blocks: u64,
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    jit_run_final_submitted_blocks: u64,
    /// E4-T10: the JIT on/off runtime flag. Effective only with the block cache on and an executor
    /// installed (see [`Self::jit_active`]). Off by default so every existing path is unchanged.
    jit_enabled: bool,
    /// E4-T21: the priority compile-staging queue between discovery and the executor. Discovery's
    /// FIFO nominations are drained into this at a boundary, re-ordered by hotness, admission-
    /// controlled (bounded, drop-and-recount), and stale-cancelled on a generation bump before the
    /// install step feeds the executor. Keeps compilation off the guest hot path and orders it so
    /// the hottest block compiles first. See [`compile_queue::CompileQueue`].
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    compile_queue: compile_queue::CompileQueue,
    /// Bumped by every guest MMIO access to a fabric device window ([`FabricTouch`]).
    /// Microarchitectural: never serialized, never part of any digest.
    fabric_epoch: alloc::rc::Rc<core::cell::Cell<u64>>,
    /// `Some(epoch)` when the last full boundary sync found every fabric device idle at that
    /// epoch; cleared at every run entry (the host may have changed device state in between).
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    fabric_idle_epoch: Option<u64>,
    /// Test-only control: force every boundary through the full device sync (the pre-quiescence
    /// behaviour) so equivalence tests can compare both paths.
    #[cfg(all(test, not(feature = "zicsr-stub")))]
    fabric_fast_path_off: bool,
    /// Test-only work counter: boundaries served by the quiescent fast path.
    #[cfg(all(test, not(feature = "zicsr-stub")))]
    fabric_fast_hits: u64,
    /// Test-only control: route every mid-block op through the general loop body instead of the
    /// replay loop, so equivalence tests can compare both paths.
    #[cfg(all(test, not(feature = "zicsr-stub")))]
    replay_tail_off: bool,
    /// Test-only work counter: ops retired by the mid-block replay loop.
    #[cfg(all(test, not(feature = "zicsr-stub")))]
    replay_tail_ops: u64,
    /// Test-only work counter: replay-loop ops whose retire accounting was deferred and settled
    /// in bulk.
    #[cfg(all(test, not(feature = "zicsr-stub")))]
    replay_deferred_ops: u64,
}

/// The run loop's position inside the decoded block it is replaying (see `Machine::block_cursor`).
/// Microarchitectural only: rebuilt on demand, never serialized, never part of any digest.
#[derive(Clone, Debug)]
#[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
struct BlockCursor {
    /// The block being replayed (shared with its cache slot while resident).
    block: alloc::rc::Rc<dispatch::DecodedBlock>,
    /// Index of the next op to replay.
    idx: usize,
    /// Guest VA that op must be fetched from; any other PC ends the continuation.
    next_va: u64,
}

impl BlockCursor {
    /// `(entry phys key, next op index, expected next VA)` — the identity the pre-Rc cursor tuple
    /// carried. Test-only: equality of cursor positions across operations that must not move it.
    #[cfg(test)]
    #[cfg_attr(feature = "zicsr-stub", allow(dead_code))]
    fn position(&self) -> (u64, usize, u64) {
        (self.block.phys_start, self.idx, self.next_va)
    }
}

/// A fabric device window (UART, RTC, virtio slot) wrapped so every guest MMIO access bumps the
/// machine's fabric epoch. The run loop's quiescence fast path (see `Machine::boundary_sync`)
/// relies on this: devices found idle stay idle until the guest touches one of these windows (or
/// the host calls in between runs), so an unchanged epoch proves the device half of a boundary
/// sync would be a no-op. Purely observational — reads/writes are forwarded unchanged.
struct FabricTouch<D> {
    inner: D,
    epoch: alloc::rc::Rc<core::cell::Cell<u64>>,
}

impl<D: mmio::MmioDevice> mmio::MmioDevice for FabricTouch<D> {
    fn read(&mut self, offset: u64, width: mmio::Width) -> Result<u64, bus::BusFault> {
        self.epoch.set(self.epoch.get().wrapping_add(1));
        self.inner.read(offset, width)
    }

    fn write(&mut self, offset: u64, width: mmio::Width, value: u64) -> Result<(), bus::BusFault> {
        self.epoch.set(self.epoch.get().wrapping_add(1));
        self.inner.write(offset, width, value)
    }
}

/// E3-T12c3: the identity a snapshot is bound to. A restore is refused unless the target machine's
/// build (`core_hash`), base disk image (`base_image_hash`), and overlay-commit `generation` all
/// match the blob — otherwise a resumed CPU/RAM would land on an overlay its page cache disagrees
/// with (silent corruption). The generation is monotonic: it only ever advances (as the overlay
/// commits), so a snapshot taken before a commit can never be restored after one.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct SnapshotCoherence {
    pub core_hash: [u8; 32],
    pub base_image_hash: [u8; 32],
    pub generation: u64,
}

/// E4-T18: the outcome of running one compiled block in a chain (see `Machine::run_one_jit_block`).
#[cfg(not(feature = "zicsr-stub"))]
enum BlockStep {
    /// A clean `FALLTHROUGH`/`BRANCH_TAKEN` exit; PC committed at the successor. `edge` is the
    /// static outgoing edge for chaining, or `None` for a dynamic (`jalr`) / non-linkable exit.
    Committed { edge: Option<u8>, retired: u64 },
    /// A `Trap` exit (precise mem-fault / `ecall` / `ebreak`); `retired` body ops committed before
    /// the faulting instruction, which consumes one work slot but does not retire.
    Trapped { trap: Trap, retired: u64 },
    /// The browser's bounded in-module chain stopped before entering its next successor. The
    /// committed prefix is returned to the outer loop so it can observe the normal boundary before
    /// another compiled call begins.
    Budget { retired: u64 },
}

/// E4-T31: one bounded JIT dispatch result. `work_used` is the exact number of outer-loop work
/// slots consumed by all compiled blocks in the chain (clean retires, plus one faulting attempt for
/// a terminal trap), and is always in `1..=remaining_work`.
#[cfg(not(feature = "zicsr-stub"))]
struct JitProgress {
    result: Result<(), Trap>,
    work_used: u64,
}

/// E4-T21 hotness of the pending block at `phys`, including the queued hits the block currently
/// cached there has buffered in its discovery memo (see [`dispatch::DiscMemo`]).
#[cfg(not(feature = "zicsr-stub"))]
fn queued_hotness_of(
    discovery: &dispatch::BlockDiscovery,
    block_cache: &dispatch::BlockCache,
    phys: u64,
) -> u32 {
    discovery.queued_hotness_with(phys, block_cache.get(phys).map(|b| b.disc.get()))
}

/// Decode the instruction at PHYSICAL address `pa` exactly as [`hart::Hart::decode_at`] decodes
/// it once translated (C-expansion, raw trace bits, length), with no MMU/TLB/PMP involvement.
/// `None` on a bus fault, a 32-bit op whose upper parcel leaves the page, or an illegal encoding —
/// each of which also ends a block walk there.
#[cfg(not(feature = "zicsr-stub"))]
fn decode_phys(bus: &mut impl crate::bus::Bus, pa: u64) -> Option<dispatch::MicroOp> {
    let lo = bus.load16(pa).ok()?;
    let (insn, len, raw) = if lo & 0b11 != 0b11 {
        (crate::decode_c::expand_c(lo).ok()?, 2, u32::from(lo))
    } else {
        if (pa & (dispatch::PAGE - 1)) + 4 > dispatch::PAGE {
            return None;
        }
        let hi = bus.load16(pa.wrapping_add(2)).ok()?;
        let word = (u32::from(hi) << 16) | u32::from(lo);
        (word, 4, word)
    };
    let instr = crate::decode::decode(insn).ok()?;
    Some(dispatch::MicroOp { instr, len, raw })
}

/// E4-T18: which outgoing link-slot edge a block's clean exit corresponds to, or `None` if the edge
/// must NOT be statically linked (a dynamic `jalr` target, or a defensive `Reserved` exit). Edge 0
/// is the taken / sole / fall-through successor; edge 1 is a conditional branch's not-taken side.
#[cfg(not(feature = "zicsr-stub"))]
fn chain_edge(terminator: Option<crate::decode::Instr>, code: jit::ExitCode) -> Option<u8> {
    use crate::decode::Instr::*;
    match terminator {
        // Conditional branch: two static edges — taken (BranchTaken → 0), not-taken (Fallthrough → 1).
        Some(Beq { .. } | Bne { .. } | Blt { .. } | Bge { .. } | Bltu { .. } | Bgeu { .. }) => {
            match code {
                jit::ExitCode::BranchTaken => Some(0),
                jit::ExitCode::Fallthrough => Some(1),
                _ => None,
            }
        }
        // Direct jump: one static edge.
        Some(Jal { .. }) => (code == jit::ExitCode::BranchTaken).then_some(0),
        // Indirect jump: the target is a register value — never statically linkable.
        Some(Jalr { .. }) => None,
        // No architectural terminator (128-op cap / page edge) or a fence: sole fall-through edge.
        Some(Fence { .. } | FenceI) | None => (code == jit::ExitCode::Fallthrough).then_some(0),
        // Anything else (ecall/ebreak) exits via Trap, not a chain edge.
        _ => None,
    }
}

/// E4-T19: drain the JIT compile queue once it holds this many pending blocks — a batch's worth is
/// ready to pack (mirrors the design's compile-queue depth, `docs/jit-architecture.md` §7 D10).
#[cfg(not(feature = "zicsr-stub"))]
const JIT_BATCH_TRIGGER: usize = 32;

/// E4-T19: force a compile-queue drain at least every this many block boundaries even below the
/// trigger, so a small hot component (fewer than [`JIT_BATCH_TRIGGER`] blocks) still compiles promptly
/// while accumulating enough to batch as one connected component.
#[cfg(not(feature = "zicsr-stub"))]
const JIT_PUMP_INTERVAL: u32 = 64;

/// E4-T21: the maximum number of validated blocks SUBMITTED for translation/compilation in a single
/// [`Machine::pump_jit_translations`] call — the per-boundary submission work bound that keeps the
/// JIT-attributable execution-thread pause bounded (the ≤5 ms target, `docs/jit-architecture.md` §7
/// D10). Popping the compile queue hottest-first up to this budget means a compile storm is spread
/// across many boundaries instead of one long stall; the leftover stays queued (priority preserved)
/// for the next boundary. The `JitPauseStats::max_submitted_blocks` counter asserts this bound is never
/// exceeded (the headless stand-in for the wall-clock histogram).
#[cfg(not(feature = "zicsr-stub"))]
const JIT_INSTALL_BUDGET: usize = 64;

/// E4-T34: maximum guest-work fuel handed to one browser in-module chain. This keeps a direct wasm
/// call chain bounded even when the outer `run` quantum is large, preserving the existing batched
/// interrupt/device observation window while replacing dozens of JS dispatches with one call.
#[cfg(not(feature = "zicsr-stub"))]
const JIT_DIRECT_CHAIN_FUEL: u64 = 128;

/// E4-T19: the static successor PHYSICAL PCs of a decoded block — `[edge0, edge1]` where edge 0 is
/// the taken / sole / fall-through successor and edge 1 is a conditional branch's not-taken side.
/// A successor is returned ONLY when it lies on the SAME physical page as the block, so its physical
/// address is exactly `phys_start + byte_offset` with no paging ambiguity (a block never crosses a
/// page, so its own bytes are identity-mapped within the page). Cross-page and dynamic (`jalr`)
/// targets are `None` — they become cross-batch edges (dispatch / E4-T18 funcref links), always
/// correct. Used purely to GROUP the compile queue; a conservative `None` only means "don't batch
/// these together", never a correctness change.
#[cfg(not(feature = "zicsr-stub"))]
fn static_successors(b: &dispatch::DecodedBlock) -> [Option<u64>; 2] {
    use crate::decode::Instr::*;
    let base = b.phys_start;
    let page = base & !(dispatch::PAGE - 1);
    let same_page = |t: u64| ((t & !(dispatch::PAGE - 1)) == page).then_some(t);
    let last = match b.ops.last() {
        Some(o) => o,
        None => return [None, None],
    };
    let last_len = last.len as u64;
    let term_off = b.total_len.saturating_sub(last_len); // byte offset of the terminator op
    if !dispatch::is_terminator(&last.instr) {
        // Fell through the 128-op cap / page edge: sole successor is the next byte after the block.
        return [same_page(base.wrapping_add(b.total_len)), None];
    }
    match last.instr {
        Jal { imm, .. } => [
            same_page(base.wrapping_add(term_off).wrapping_add(imm as u64)),
            None,
        ],
        Beq { imm, .. }
        | Bne { imm, .. }
        | Blt { imm, .. }
        | Bge { imm, .. }
        | Bltu { imm, .. }
        | Bgeu { imm, .. } => [
            same_page(base.wrapping_add(term_off).wrapping_add(imm as u64)),
            same_page(base.wrapping_add(b.total_len)),
        ],
        // `fence`/`fence.i` fall through to the next block (sole edge); `jalr`/`ecall`/`ebreak`/CSR
        // have no static successor.
        Fence { .. } | FenceI => [same_page(base.wrapping_add(b.total_len)), None],
        _ => [None, None],
    }
}

/// E4-T19: partition `blocks` into batches (each a `Vec` of indices into `blocks`) by connected
/// components of the undirected static-edge graph, then split any component larger than `k` into
/// chunks of ≤ `k`. A union-find over the block set; edges are the same-page static successors that
/// land on another drained block. Splitting an oversized component only turns some intra-batch edges
/// into cross-batch ones (still correct), so `k` is a hard cap on module size. Once components have
/// been split to that cap, adjacent disconnected chunks may share a module:
/// `intra_edges_for_group` only emits calls for real same-batch edges, so coalescing them changes
/// compilation granularity, not guest control flow. The executors retain unaffected members when a
/// page-granular SMC invalidation touches only part of such a batch; a batch is dropped atomically
/// only when all of its members are on the invalidated page.
#[cfg(not(feature = "zicsr-stub"))]
fn group_into_batches(
    blocks: &[dispatch::DecodedBlock],
    k: usize,
) -> alloc::vec::Vec<alloc::vec::Vec<usize>> {
    let n = blocks.len();
    if n == 0 {
        return alloc::vec::Vec::new();
    }
    let phys_to_idx: alloc::collections::BTreeMap<u64, usize> = blocks
        .iter()
        .enumerate()
        .map(|(i, b)| (b.phys_start, i))
        .collect();
    // Union-find.
    let mut parent: alloc::vec::Vec<usize> = (0..n).collect();
    fn find(parent: &mut [usize], mut x: usize) -> usize {
        while parent[x] != x {
            parent[x] = parent[parent[x]];
            x = parent[x];
        }
        x
    }
    for (i, b) in blocks.iter().enumerate() {
        for succ in static_successors(b).into_iter().flatten() {
            if let Some(&j) = phys_to_idx.get(&succ) {
                let (ri, rj) = (find(&mut parent, i), find(&mut parent, j));
                if ri != rj {
                    parent[ri] = rj;
                }
            }
        }
    }
    // Bucket indices by component root, preserving insertion order within each component.
    let mut comps: alloc::collections::BTreeMap<usize, alloc::vec::Vec<usize>> =
        alloc::collections::BTreeMap::new();
    for i in 0..n {
        let r = find(&mut parent, i);
        comps.entry(r).or_default().push(i);
    }
    // Emit components, chunking oversized ones to the batch-size cap. Pack consecutive chunks from
    // disconnected components together where there is room. The old one-component-per-module
    // policy made a large compile drain create many tiny Wasm instances for code with no static
    // relationship, which increased instance/LRU churn without adding any direct-call edges.
    let mut out = alloc::vec::Vec::new();
    let mut current = alloc::vec::Vec::new();
    for (_, members) in comps {
        for chunk in members.chunks(k) {
            if !current.is_empty() && current.len() + chunk.len() > k {
                out.push(core::mem::take(&mut current));
            }
            current.extend_from_slice(chunk);
            if current.len() == k {
                out.push(core::mem::take(&mut current));
            }
        }
    }
    if !current.is_empty() {
        out.push(current);
    }
    out
}

/// E4-T19: for a batch (a slice of indices into `blocks`), compute the per-block intra-batch edge map
/// `intra[local][edge] = Some(local_of_successor)` when that static successor is another block IN THE
/// SAME batch, else `None`. Edge 0 = taken/sole/fall-through, edge 1 = branch not-taken — matching
/// `chain_edge` and the translator's edge numbering.
#[cfg(not(feature = "zicsr-stub"))]
fn intra_edges_for_group(
    blocks: &[dispatch::DecodedBlock],
    group: &[usize],
) -> alloc::vec::Vec<[Option<usize>; 2]> {
    // Map a block's phys → its LOCAL index within this batch.
    let local_of: alloc::collections::BTreeMap<u64, usize> = group
        .iter()
        .enumerate()
        .map(|(l, &gi)| (blocks[gi].phys_start, l))
        .collect();
    group
        .iter()
        .map(|&gi| {
            let succ = static_successors(&blocks[gi]);
            [
                succ[0].and_then(|p| local_of.get(&p).copied()),
                succ[1].and_then(|p| local_of.get(&p).copied()),
            ]
        })
        .collect()
}

impl Machine {
    /// Create a machine with `ram_bytes` of zeroed guest RAM at `DRAM_BASE`, an
    /// empty hart (PC 0), and no HTIF watch. Panics only on allocation failure — use
    /// [`Self::try_new`] when the size comes from untrusted input (e.g. the wasm wrapper).
    pub fn new(ram_bytes: usize) -> Self {
        Self::try_new(ram_bytes).expect("guest RAM allocation failed")
    }

    /// Fallible constructor: returns [`ram::OutOfMemory`] instead of panicking when the
    /// allocation is refused, so a hostile RAM size becomes a caught error rather than a
    /// process abort. `Ram::new` allocates through `try_reserve_exact`.
    pub fn try_new(ram_bytes: usize) -> Result<Self, ram::OutOfMemory> {
        let mut m = Self {
            hart: Hart::new(),
            bus: SystemBus::new(Ram::new(ram_bytes)?),
            htif: None,
            last_tohost: 0,
            htif_commands: 0,
            clint: None,
            clock_div: 1,
            tick_accum: 0,
            plic: None,
            builtin_sbi: false,
            sbi_state: sbi::SbiState::default(),
            uart: None,
            rtc: None,
            irqstats: diag::irqstats::IrqStats::new(),
            storm_detect: true,
            prof: prof::ProfStats::new(),
            profiling: false,
            prof_countdown: PROF_STRIDE_BASE,
            prof_lcg: 0x1234_5678,
            host_timer: None,
            prof_total_ns: 0,
            syscon: None,
            virtio: alloc::vec::Vec::new(),
            gpu: None,
            blk: None,
            extra_blk: alloc::vec::Vec::new(),
            net: None,
            net_backend: None,
            rng: None,
            keyboard: None,
            keyboard_leds: None,
            tablet: None,
            mouse: None,
            snd: None,
            console: None,
            desktop_restore_host: alloc::rc::Rc::new(core::cell::RefCell::new(
                desktop_restore::DesktopRestoreHostState::default(),
            )),
            coherence: SnapshotCoherence::default(),
            // E4-T05: default the toggle to the `predecode` feature (OFF in the normal build);
            // the differential harness flips it at runtime via `set_block_cache`.
            block_cache_enabled: cfg!(feature = "predecode"),
            block_cache: dispatch::BlockCache::with_capacity(1 << 12),
            discovery: dispatch::BlockDiscovery::new(),
            block_cursor: None,
            block_entry_hits: 0,
            block_builds: 0,
            jit_partial_resume_rebuilds: 0,
            jit_partial_resume_failures: 0,
            pmp_revision_seen: 0,
            pmp_mode_seen: csr::Priv::M,
            #[cfg(all(test, not(feature = "zicsr-stub")))]
            pmp_audited_ops: 0,
            // E4-T05 Phase C: batching is OFF by default even under `predecode` (the cache stays
            // byte-identical); it is opted in explicitly via `set_interrupt_batching`.
            interrupt_batching: false,
            executor: None,
            jit_pump_ticks: 0,
            jit_run_attempt_remaining: 0,
            jit_run_staging_remaining: 0,
            jit_run_scope_active: false,
            jit_run_scope_external: false,
            jit_run_submissions_before: 0,
            jit_run_staged_nominations: 0,
            jit_run_attempted_blocks: 0,
            jit_run_final_pumps: 0,
            jit_run_final_attempted_blocks: 0,
            jit_run_final_submitted_blocks: 0,
            jit_enabled: false,
            compile_queue: compile_queue::CompileQueue::default(),
            wall_time: None,
            idle_pacer: None,
            mono_clock: None,
            last_time_jump: None,
            fabric_epoch: alloc::rc::Rc::new(core::cell::Cell::new(0)),
            fabric_idle_epoch: None,
            #[cfg(all(test, not(feature = "zicsr-stub")))]
            fabric_fast_path_off: false,
            #[cfg(all(test, not(feature = "zicsr-stub")))]
            fabric_fast_hits: 0,
            #[cfg(all(test, not(feature = "zicsr-stub")))]
            replay_tail_off: false,
            #[cfg(all(test, not(feature = "zicsr-stub")))]
            replay_tail_ops: 0,
            #[cfg(all(test, not(feature = "zicsr-stub")))]
            replay_deferred_ops: 0,
        };
        // E4-T05 Phase B: arm the bus's physical-frame write log iff the cache is on, so guest
        // stores AND device/DMA writes feed page-granular invalidation.
        m.bus.arm_code_write_tracking(m.block_cache_enabled);
        Ok(m)
    }

    /// E4-T05: the A/B toggle — turn the predecoded block cache on/off at runtime. Flushing on
    /// every transition guarantees the two paths never share a stale block, so a differential
    /// run can flip mid-stream and still be byte-identical.
    pub fn set_block_cache(&mut self, on: bool) {
        self.block_cache_enabled = on;
        self.block_cache.flush();
        self.block_cursor = None;
        self.block_entry_hits = 0;
        self.block_builds = 0;
        // The cache is empty after this toggle, so it already reflects the current permissions.
        self.pmp_revision_seen = self.hart.csr.pmp.revision();
        self.pmp_mode_seen = self.hart.csr.mode;
        // E4-T08: a cache toggle wholesale-flushes blocks; reset the discovery state to match.
        self.discovery.reset();
        // E4-T10: a wholesale flush drops every compiled block too — they mirror the cache.
        if let Some(e) = self.executor.as_mut() {
            e.invalidate_all();
        }
        // E4-T05 Phase B: keep the bus write log armed in lockstep with the cache.
        self.bus.arm_code_write_tracking(on);
    }

    /// E4-T05: whether the predecoded block cache is currently active.
    pub fn block_cache_enabled(&self) -> bool {
        self.block_cache_enabled
    }

    /// E4-T30 entry-cache accounting: `(entry_hits, block_builds)` since the last cache toggle or
    /// resize. A hot taken loop should build once, then record one hit per later entry. This is
    /// observation-only and never participates in architectural state or snapshots.
    pub fn block_cache_entry_stats(&self) -> (u64, u64) {
        (self.block_entry_hits, self.block_builds)
    }

    /// Partial-block continuations that had to re-decode their evicted decoded block from
    /// physical memory before resuming the block cursor at the untranslated op (see
    /// `run_one_jit_block`'s `CallInterp` arm). Always zero on an executor that runs one block per
    /// host call; the browser's in-module direct chaining can reach it. Observation-only.
    pub fn jit_partial_resume_rebuilds(&self) -> u64 {
        self.jit_partial_resume_rebuilds
    }

    /// Partial-block continuations that could not resume the block cursor at all (the untranslated
    /// op then ran as a fresh block entry, which is not timing-transparent). Must stay zero; a
    /// nonzero value in a release run is a bug report. Observation-only.
    pub fn jit_partial_resume_failures(&self) -> u64 {
        self.jit_partial_resume_failures
    }

    /// PMP regions may split a physical page, while decoded/JIT caches are page-keyed. An effective
    /// PMP CSR change therefore invalidates all cached code before another block runs. A privilege
    /// change is cheaper to audit: if every cached instruction has the same execute permission in
    /// the old and new modes, the physically keyed code remains valid and can be retained. This is
    /// the common full-grant case used by Linux; a split or mode-sensitive PMP map still takes the
    /// conservative flush path. S and U have identical PMP checks, so their transition needs no
    /// per-instruction audit while the PMP revision is unchanged. This does not skip MMU/PTE
    /// permission checks, which still use the actual current privilege at instruction fetch.
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(always)]
    fn sync_pmp_code_permissions(&mut self) {
        // Every boundary: unchanged PMP revision and privilege is the overwhelmingly common case.
        if self.hart.csr.pmp.revision() != self.pmp_revision_seen
            || self.hart.csr.mode != self.pmp_mode_seen
        {
            self.sync_pmp_code_permissions_changed();
        }
    }

    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(never)]
    fn sync_pmp_code_permissions_changed(&mut self) {
        let revision = self.hart.csr.pmp.revision();
        let mode = self.hart.csr.mode;
        if revision == self.pmp_revision_seen
            && matches!(
                (self.pmp_mode_seen, mode),
                (csr::Priv::S, csr::Priv::U) | (csr::Priv::U, csr::Priv::S)
            )
        {
            self.pmp_mode_seen = mode;
            return;
        }
        if revision == self.pmp_revision_seen
            && mode != self.pmp_mode_seen
            && self.block_cache.live_blocks().all(|block| {
                let mut pc = block.phys_start;
                block.ops.iter().all(|op| {
                    #[cfg(test)]
                    {
                        self.pmp_audited_ops += 1;
                    }
                    let len = u64::from(op.len);
                    let old_ok = self.hart.csr.pmp_ok(
                        pc,
                        len,
                        crate::pmp::PmpAccess::Exec,
                        self.pmp_mode_seen,
                    );
                    let new_ok = self
                        .hart
                        .csr
                        .pmp_ok(pc, len, crate::pmp::PmpAccess::Exec, mode);
                    pc = pc.wrapping_add(len);
                    old_ok == new_ok
                })
            })
        {
            self.pmp_mode_seen = mode;
            return;
        }
        self.pmp_revision_seen = revision;
        self.pmp_mode_seen = mode;
        self.block_cache.flush();
        self.block_cursor = None;
        self.discovery.on_invalidate();
        if let Some(e) = self.executor.as_mut() {
            e.invalidate_all();
        }
    }

    /// E4-T05 Phase C: turn interrupt/device-sync BATCHING on/off. Distinct from
    /// [`Self::set_block_cache`] — batching requires the cache (it is a no-op without it), but the
    /// cache runs independently WITHOUT batching as the byte-identical mode. Flushing the cursor on
    /// a transition keeps boundary bookkeeping consistent.
    pub fn set_interrupt_batching(&mut self, on: bool) {
        self.interrupt_batching = on;
        self.block_cursor = None;
    }

    /// E4-T05 Phase C: whether interrupt/device-sync batching is active (and effective — it
    /// requires the block cache to be on).
    pub fn interrupt_batching(&self) -> bool {
        self.interrupt_batching && self.block_cache_enabled
    }

    /// Actual decoded-cache slot count; host configuration, not snapshot/architectural state.
    pub fn decoded_cache_entries(&self) -> usize {
        self.block_cache.capacity()
    }

    /// E5-T26k: bounded host selection. Invalid values and selecting the actual current size
    /// leave all state untouched, including live decoded cursors and compiled handles.
    pub fn set_decoded_cache_entries(&mut self, entries: usize) -> Result<(), &'static str> {
        if !matches!(entries, 4096 | 16384) {
            return Err("decoded cache entries must be 4096 or 16384");
        }
        if entries != self.decoded_cache_entries() {
            self.set_block_cache_capacity(entries);
        }
        Ok(())
    }

    /// E4-T05: resize the block cache (rounded up to a power of two). `capacity == 1` is the
    /// adversarial pathological-eviction mode — a 1-entry cache that must STILL be byte-identical.
    pub fn set_block_cache_capacity(&mut self, capacity: usize) {
        self.block_cache = dispatch::BlockCache::with_capacity(capacity);
        self.block_cursor = None;
        self.block_entry_hits = 0;
        self.block_builds = 0;
        self.pmp_revision_seen = self.hart.csr.pmp.revision();
        self.pmp_mode_seen = self.hart.csr.mode;
        // E4-T08: a fresh cache has no blocks; reset discovery so stale counts/requests are dropped.
        self.discovery.reset();
        // E4-T10: fresh cache ⇒ every compiled block is stale; drop them all.
        if let Some(e) = self.executor.as_mut() {
            e.invalidate_all();
        }
        // Fresh cache ⇒ no cached code ⇒ any pending write frames are moot.
        self.bus.code_write_log_mut().clear();
    }

    /// E4-T08: set the hotness promotion threshold (the tunable `N`; default
    /// [`dispatch::HOT_THRESHOLD`] = 64). E4-T08 owns sweeping this against the ledger; tests use a
    /// low value to nominate with short guests. Persists across a cache toggle.
    pub fn set_hotness_threshold(&mut self, threshold: u32) {
        self.discovery.set_threshold(threshold);
    }

    /// E4-T08: a snapshot of the block-discovery counters — blocks nominated, deduped,
    /// dropped-stale, queue depth + high-water mark, and the live generation. Exposed for the
    /// profiling report and for tests; also folded into [`Self::prof_report`].
    pub fn discovery_stats(&self) -> dispatch::DiscoveryStats {
        let mut s = self.discovery.stats();
        // E4-T16: fold in the block-cache invalidation-event counters so a test can assert on
        // whole-cache flushes and page-discarded blocks without assembling a full prof report.
        let (cache_flushes, blocks_discarded) = self.block_cache.invalidation_stats();
        s.cache_flushes = cache_flushes;
        s.blocks_discarded = blocks_discarded;
        s.fence_i = self.block_cache.fence_i_noops();
        s
    }

    /// Default-off admission witness observer. Never enables profiling or changes JIT policy.
    pub fn set_admission_probe(&mut self, enabled: bool) {
        self.discovery.set_admission_probe(enabled);
    }

    /// Explicit default-off admission trial. Does not select JIT, profiling, timers,
    /// or mutate caches/queues; recycling can occur only on a later full-map entry.
    pub fn set_cold_counter_recycling(&mut self, enabled: bool) {
        self.discovery.set_cold_counter_recycling(enabled);
    }

    pub fn cold_counter_recycling_stats(&self) -> dispatch::ColdCounterRecyclingStats {
        self.discovery.cold_counter_recycling_stats()
    }

    /// One immutable host observation of exact queue membership and PC-only executor residency.
    /// The latter is deliberately not evidence of an exact historical installation.
    pub fn admission_probe_stats(&self) -> dispatch::AdmissionProbeStats {
        let mut stats = self.discovery.admission_probe_stats();
        for row in &mut stats.records {
            row.compile_queued = self.compile_queue.contains_request(&row.request);
            row.executor_resident_at_report = self
                .executor
                .as_ref()
                .map(|e| e.is_compiled(row.request.phys_pc));
        }
        stats
    }

    /// Immutable compile-queue accounting, resident depth and capacity from the same borrow.
    /// These are lifetime queue counters, independent of discovery's generation/reset counters.
    pub fn compile_queue_stats(&self) -> (compile_queue::CompileQueueStats, usize, usize) {
        (
            self.compile_queue.stats(),
            self.compile_queue.len(),
            self.compile_queue.cap(),
        )
    }

    /// E4-T08: drain the pending translation-candidate FIFO (a trivial consumer; the real compile
    /// queue is E4-T21). Each request carries its coherence generation — validate with
    /// [`Self::discovery_install_check`] before acting on it.
    pub fn take_translation_requests(&mut self) -> alloc::vec::Vec<dispatch::TranslationRequest> {
        self.discovery.take_requests()
    }

    /// E4-T08: validate a translation request at (mock) install time against live guest memory —
    /// returns `true` only if its generation is current AND its snapshotted bytes still match. The
    /// choke point behind the "never install stale bytes" guarantee.
    pub fn discovery_install_check(
        &mut self,
        req: &dispatch::TranslationRequest,
        live_bytes: &[u8],
    ) -> bool {
        self.discovery.install_check(req, live_bytes)
    }

    /// E4-T10: install a compiled-block executor (a native/browser JIT runtime). The run loop
    /// drives it once the JIT is enabled and the block cache is on. Installing a fresh executor
    /// (or replacing one) drops any previously compiled state by construction.
    pub fn set_executor(&mut self, mut executor: jit::BoxedExecutor) {
        executor.set_entry_timing(self.profiling);
        self.executor = Some(executor);
    }

    /// E4-T10: reclaim the installed executor (e.g. to read its stats after a run). Leaves the
    /// machine with no executor, so the JIT is inert until one is set again.
    pub fn take_executor(&mut self) -> Option<jit::BoxedExecutor> {
        self.executor.take()
    }

    /// E4-T10: borrow the installed executor (stats: compiled/executed/retired counts).
    pub fn executor(&self) -> Option<&dyn jit::CompiledBlockExecutor> {
        self.executor.as_deref()
    }

    /// E4-T10: the JIT on/off runtime flag. Enabling it also turns on the block cache (the JIT
    /// consumes the cache's block discovery). Disabling drops all compiled state to guarantee the
    /// interpreter and JIT paths never share a stale block.
    pub fn set_jit(&mut self, on: bool) {
        self.jit_enabled = on;
        if on {
            self.set_block_cache(true);
        } else if let Some(e) = self.executor.as_mut() {
            e.invalidate_all();
        }
    }

    /// E4-T10: is the JIT effectively active — enabled, an executor installed, and the block cache
    /// on (the discovery front end the JIT feeds off)?
    pub fn jit_active(&self) -> bool {
        self.jit_enabled && self.block_cache_enabled && self.executor.is_some()
    }

    /// E4-T18: A/B flag — turn direct block→block chaining on/off on the installed executor. With
    /// chaining off, the dispatch loop returns after every compiled block (the E4-T10 behavior);
    /// with it on, hot edges are followed directly through link-slots. No-op without an executor.
    pub fn set_chaining(&mut self, on: bool) {
        if let Some(e) = self.executor.as_mut() {
            e.set_chaining(on);
        }
    }

    /// E4-T39: independently enable or disable generated dynamic-return (`jalr`) chaining. This
    /// keeps the static region-chain control available for a separate entry-path comparison.
    pub fn set_dynamic_chaining(&mut self, on: bool) {
        if let Some(e) = self.executor.as_mut() {
            e.set_dynamic_chaining(on);
        }
    }

    /// E4-T18: set the chain-depth budget (max links per chain before a mandatory dispatch return;
    /// clamped to ≥ 1, where 1 is the degenerate "no chaining past one link" mode). No-op without an
    /// executor.
    pub fn set_chain_depth_budget(&mut self, n: u32) {
        if let Some(e) = self.executor.as_mut() {
            e.set_chain_depth_budget(n);
        }
    }

    /// E4-T18: a snapshot of the chaining statistics (links made/cut, dispatch-loop entries, and the
    /// chain-depth histogram). Empty if no executor is installed.
    pub fn chain_stats(&self) -> jit::ChainStats {
        self.executor
            .as_deref()
            .map(|e| e.chain_stats())
            .unwrap_or_default()
    }

    /// E4-T19: set the batching knob K (max blocks packed into one WASM module). `1` forces the
    /// one-block-per-module mode. No-op without an executor.
    pub fn set_batch_size(&mut self, k: usize) {
        if let Some(e) = self.executor.as_mut() {
            e.set_batch_size(k);
        }
    }

    /// E4-T19: the current batching K (1 if no executor is installed).
    pub fn batch_size(&self) -> usize {
        self.executor
            .as_deref()
            .map(|e| e.batch_size())
            .unwrap_or(1)
    }

    /// E4-T19 instance registry: `(live module/instance count, estimated live bytes)` across every
    /// compiled batch — the raw material for E4-T20's budgets. `(0, 0)` without an executor.
    pub fn jit_registry(&self) -> (usize, u64) {
        self.executor
            .as_deref()
            .map(|e| (e.module_count(), e.estimated_bytes()))
            .unwrap_or((0, 0))
    }

    /// E4-T20: set the JIT translation-cache budget enforced at install time (code bytes, live
    /// batch count, table slots, metadata bytes). No-op without an executor.
    pub fn set_jit_budget(&mut self, budget: jit::JitCacheBudget) {
        if let Some(e) = self.executor.as_mut() {
            e.set_jit_budget(budget);
        }
    }

    /// E4-T20: select the eviction policy (full generational flush vs batch-LRU). No-op without an
    /// executor.
    pub fn set_evict_policy(&mut self, policy: jit::EvictPolicy) {
        if let Some(e) = self.executor.as_mut() {
            e.set_evict_policy(policy);
        }
    }

    /// E4-T20: a snapshot of the JIT cache accounting (usage vs budget, evictions, re-translation
    /// rate). Default (zeroed) without an executor.
    pub fn jit_cache_stats(&self) -> jit::JitCacheStats {
        self.executor
            .as_deref()
            .map(|e| e.jit_cache_stats())
            .unwrap_or_default()
    }

    /// E4-T20 (AC3 directed-test / debug hook): force-evict the batch owning the block at `phys_pc`
    /// through the single ordered `evict_batch` obligation path. Returns `true` iff a batch was
    /// evicted.
    pub fn evict_jit_batch_containing(&mut self, phys_pc: u64) -> bool {
        let (evicted, list) = match self.executor.as_mut() {
            Some(e) => (e.evict_batch_containing(phys_pc), e.take_evicted()),
            None => return false,
        };
        // Re-nominate the evicted blocks so they re-translate when hot again (AC3).
        for phys in list {
            self.discovery.renominate(phys);
        }
        evicted
    }

    /// E4-T20: the `jitstat` debug dump — current usage vs budgets, eviction activity, and the
    /// re-translation (thrash) rate. Usable as the browser-console `jitstat` payload.
    pub fn jitstat(&self) -> alloc::string::String {
        use alloc::format;
        let s = self.jit_cache_stats();
        let (modules, est) = self.jit_registry();
        format!(
            "=== jitstat ===\n\
             policy={:?} generation={}\n\
             code_bytes={}/{} ({:.1}%)  batches={}/{}  table_slots={}/{}  metadata_bytes={}/{}\n\
             modules={} est_bytes={}\n\
             evictions={} flushes={} installs={} retranslations={} retranslation_rate={:.4}\n",
            s.policy,
            s.generation,
            s.code_bytes,
            s.budget.code_bytes,
            100.0 * s.code_bytes as f64 / s.budget.code_bytes.max(1) as f64,
            s.batches,
            s.budget.max_batches,
            s.table_slots,
            s.budget.table_slots,
            s.metadata_bytes,
            s.budget.metadata_bytes,
            modules,
            est,
            s.evictions,
            s.flushes,
            s.installs,
            s.retranslations,
            s.retranslation_rate(),
        )
    }

    /// E3-T12c3: bind this machine to a base disk image + emulator build for snapshot coherence.
    /// `save_resume` stamps these into the header and `load_resume` refuses a snapshot whose header
    /// disagrees — a resume onto a different image or a stale build is rejected before any mutation.
    pub fn set_snapshot_identity(&mut self, core_hash: [u8; 32], base_image_hash: [u8; 32]) {
        self.set_snapshot_identity_with_generation(
            core_hash,
            base_image_hash,
            self.coherence.generation,
        );
    }

    /// E3-T12d: bind this machine to a base disk image, emulator build, and generation recovered
    /// from the durable overlay metadata. The persistent browser boot uses this on reopen so the
    /// resume guard sees the same generation that was committed with the loaded blocks.
    pub fn set_snapshot_identity_with_generation(
        &mut self,
        core_hash: [u8; 32],
        base_image_hash: [u8; 32],
        generation: u64,
    ) {
        self.coherence.core_hash = core_hash;
        self.coherence.base_image_hash = base_image_hash;
        self.coherence.generation = generation;
    }

    /// E3-T12c3: the current overlay-commit generation the next `save_resume` will bind.
    pub fn overlay_generation(&self) -> u64 {
        self.coherence.generation
    }

    /// E3-T12c3: advance the monotonic overlay-commit generation. The persist pump calls this each
    /// time a durable overlay transaction commits, so a snapshot taken before the commit binds an
    /// older generation and is refused if restored afterward (no stale-overlay resume). Saturating:
    /// the counter never wraps back onto a value an outstanding snapshot could match.
    pub fn advance_overlay_generation(&mut self) -> u64 {
        self.coherence.generation = self.coherence.generation.saturating_add(1);
        self.coherence.generation
    }

    /// E3-T12c3: the full coherence binding (build + base image + generation) this machine stamps.
    pub fn snapshot_coherence(&self) -> &SnapshotCoherence {
        &self.coherence
    }

    /// Attach a CLINT (E1-T12) at [`bus::mmap::CLINT_BASE`] and drive its `mtime` from the
    /// retired-instruction count: one tick per `clock_div` retirements (a deterministic clock
    /// — native and wasm agree). `clock_div` is clamped to at least 1. The run loop then
    /// samples MTIP (`mtime >= mtimecmp`) and MSIP into `mip` at every instruction boundary.
    /// Returns the shared state handle so tests/hosts can inspect or drive the registers.
    pub fn enable_clint(
        &mut self,
        clock_div: u64,
    ) -> alloc::rc::Rc<core::cell::RefCell<dev::clint::ClintState>> {
        let (device, state) = dev::clint::Clint::new();
        self.bus
            .attach(
                bus::mmap::CLINT_BASE,
                dev::clint::CLINT_LEN,
                alloc::boxed::Box::new(device),
            )
            .expect("CLINT window overlaps RAM or another device");
        self.clock_div = clock_div.max(1);
        self.tick_accum = 0;
        self.clint = Some(alloc::rc::Rc::clone(&state));
        state
    }

    /// E4-T24: the current guest `mtime` (0 when no CLINT is attached). One read point for tests and
    /// hosts that sample the clock — the value CLINT reads, mtimecmp scheduling, and SBI-time queries
    /// all agree on.
    pub fn clint_mtime(&self) -> u64 {
        self.clint.as_ref().map_or(0, |c| c.borrow().mtime)
    }

    /// Attach a PLIC (E1-T13) at [`bus::mmap::PLIC_BASE`] and drive `mip.MEIP` (hart-0 M context
    /// 0) / `mip.SEIP` (hart-0 S context 1) from its external-interrupt levels each instruction
    /// boundary. Returns the shared state handle so tests/devices can program registers and
    /// obtain [`dev::plic::IrqLine`]s.
    pub fn enable_plic(&mut self) -> alloc::rc::Rc<core::cell::RefCell<dev::plic::PlicState>> {
        let (device, state) = dev::plic::Plic::new();
        self.bus
            .attach(
                bus::mmap::PLIC_BASE,
                dev::plic::PLIC_LEN,
                alloc::boxed::Box::new(device),
            )
            .expect("PLIC window overlaps RAM or another device");
        self.plic = Some(alloc::rc::Rc::clone(&state));
        state
    }

    /// Size of guest RAM in bytes.
    pub fn ram_len(&self) -> usize {
        self.bus.ram().len()
    }

    /// Linear-memory address of the guest RAM allocation. This is an integration seam for the
    /// wasm browser JIT's imported-memory fast path; callers must use the value only while this
    /// machine owns the allocation (the `Vec` is not resized during execution).
    pub fn ram_host_ptr(&self) -> usize {
        self.bus.ram().as_bytes().as_ptr() as usize
    }

    /// Guest physical base address of the RAM allocation.
    pub fn ram_base(&self) -> u64 {
        self.bus.ram().base()
    }

    /// E2-T07: attach the ns16550a UART at [`platform::virt::UART0_BASE`], wired to PLIC
    /// IRQ 10. Requires [`Self::enable_plic`] first. The run loop ticks the UART's
    /// deterministic char-timeout clock and mirrors its level into the PLIC every
    /// instruction boundary. Returns the shared handle (host input via
    /// `borrow_mut().push_input`, output via `take_output`).
    pub fn enable_uart16550(
        &mut self,
    ) -> alloc::rc::Rc<core::cell::RefCell<dev::uart16550::Uart16550>> {
        let plic = self
            .plic
            .as_ref()
            .expect("enable_plic before enable_uart16550");
        let line = dev::plic::Plic::irq_line(plic, platform::virt::UART0_IRQ as usize);
        let cell = alloc::rc::Rc::new(core::cell::RefCell::new(dev::uart16550::Uart16550::new()));
        self.bus
            .attach(
                bus::mmap::UART0_BASE,
                bus::mmap::UART0_LEN,
                alloc::boxed::Box::new(FabricTouch {
                    inner: dev::uart16550::SharedUart(alloc::rc::Rc::clone(&cell)),
                    epoch: alloc::rc::Rc::clone(&self.fabric_epoch),
                }),
            )
            .expect("UART window overlaps RAM or another device");
        self.uart = Some((alloc::rc::Rc::clone(&cell), line));
        cell
    }

    /// E2-T08: attach the virtio-mmio slots (spec 1.2 §4.2.2, Version=2) at
    /// [`platform::virt::VIRTIO_BASE`]`+ i*stride`, each wired to PLIC IRQ `1+i`. Slot 0
    /// gets `slot0` as its backend (E2-T11 plugs the real blk device in); remaining slots are
    /// EMPTY (`DeviceID` 0 — the kernel skips them silently). Requires
    /// [`Self::enable_plic`] first. Returns the slot handles (tests/backends raise
    /// used/config interrupts and inspect queue state through them).
    pub fn enable_virtio_slots(
        &mut self,
        slot0: Option<alloc::boxed::Box<dyn dev::virtio::VirtioDevice>>,
    ) -> alloc::vec::Vec<alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>> {
        use dev::virtio::mmio::VirtioMmio;
        let plic = self
            .plic
            .as_ref()
            .expect("enable_plic before enable_virtio_slots");
        let mut handles = alloc::vec::Vec::new();
        let mut slot0 = slot0;
        for i in 0..platform::virt::VIRTIO_COUNT {
            let slot = match (i, slot0.take()) {
                (0, Some(d)) => VirtioMmio::new(d),
                _ => VirtioMmio::empty(),
            };
            let cell = alloc::rc::Rc::new(core::cell::RefCell::new(slot));
            let line = dev::plic::Plic::irq_line(plic, platform::Platform::virtio_irq(i) as usize);
            self.bus
                .attach(
                    platform::Platform::virtio_base(i),
                    platform::virt::VIRTIO_LEN,
                    alloc::boxed::Box::new(FabricTouch {
                        inner: dev::virtio::mmio::SharedVirtioMmio(alloc::rc::Rc::clone(&cell)),
                        epoch: alloc::rc::Rc::clone(&self.fabric_epoch),
                    }),
                )
                .expect("virtio window overlaps RAM or another device");
            self.virtio.push((alloc::rc::Rc::clone(&cell), line));
            handles.push(cell);
        }
        handles
    }

    /// E2-T11: attach a virtio-blk device (DeviceID 2) backed by `backend` in slot 0 and
    /// the seven empty slots alongside (calls [`Self::enable_virtio_slots`] internally).
    /// Returns (slot-0 handle, shared blk state — inspect `flush_count`, swap inputs).
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_blk(
        &mut self,
        backend: alloc::boxed::Box<dyn block::BlockBackend>,
    ) -> (
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::blk::BlkState>>,
    ) {
        let (devhalf, state) = dev::virtio::blk::new(backend);
        let slots = self.enable_virtio_slots(Some(alloc::boxed::Box::new(devhalf)));
        self.blk = Some((alloc::rc::Rc::clone(&state), None));
        (alloc::rc::Rc::clone(&slots[0]), state)
    }

    /// E4-T03: attach an ADDITIONAL virtio-blk device (DeviceID 2) backed by `backend` into an
    /// already-existing EMPTY slot (`enable_virtio_blk`/`enable_virtio_slots` first). The benchmark
    /// harness attaches its read-only overlay as a second drive (slot 1) so the guest sees `/dev/vdb`
    /// alongside the root `/dev/vda`, without disturbing the single-drive path. Returns the shared
    /// blk state. Panics if `slot` is out of range or already occupied (a wiring bug).
    pub fn enable_virtio_blk_at(
        &mut self,
        slot: usize,
        backend: alloc::boxed::Box<dyn block::BlockBackend>,
    ) -> alloc::rc::Rc<core::cell::RefCell<dev::virtio::blk::BlkState>> {
        assert!(
            slot < self.virtio.len(),
            "enable_virtio_slots/enable_virtio_blk before enable_virtio_blk_at"
        );
        let (devhalf, state) = dev::virtio::blk::new(backend);
        assert!(
            self.virtio[slot]
                .0
                .borrow_mut()
                .install_device(alloc::boxed::Box::new(devhalf))
                .is_ok(),
            "virtio slot {slot} already has a device"
        );
        // Register it for run-loop servicing (the ring view builds lazily on the guest's first kick,
        // like the primary blk). Omitting this is exactly the hang: the device probes but its reads
        // never complete.
        self.extra_blk
            .push((alloc::rc::Rc::clone(&state), None, slot));
        state
    }

    /// E5-T06d/E5-T07a: attach the virtio-gpu control queue to the highest free optional slot.
    /// Slots 7 and 6 remain preferred so the browser's established device layout is unchanged;
    /// native proof assemblies may also keep the fixed agent console in slot 7 and sound in slot
    /// 6, in which case the GPU uses an earlier empty slot. Returning `None` lets callers with
    /// every slot consumed keep their existing device set without replacing another backend.
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_gpu(
        &mut self,
        sink: alloc::boxed::Box<dyn dev::virtio::gpu::FrameSink>,
    ) -> Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::gpu::GpuState>>,
    )> {
        let (device, state) = dev::virtio::gpu::VirtioGpu::new_with_sink_state(sink);
        self.install_virtio_gpu(device, state)
    }

    /// Explicit proof-only constructor; default assembly remains unaccelerated.
    #[cfg(feature = "virgl-renderer")]
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_gpu_control3d_proof(
        &mut self,
        frame_sink: alloc::boxed::Box<dyn dev::virtio::gpu::FrameSink>,
        control_sink: alloc::boxed::Box<dyn dev::virtio::gpu::control3d::Control3dSink>,
    ) -> Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::gpu::GpuState>>,
    )> {
        let (device, state) =
            dev::virtio::gpu::VirtioGpu::new_with_control3d_proof_state(frame_sink, control_sink);
        self.install_virtio_gpu(device, state)
    }

    /// Host-selected captured-desktop control envelope; not a production API profile.
    #[cfg(feature = "virgl-renderer")]
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_gpu_standard_desktop_control3d_proof(
        &mut self,
        frame_sink: alloc::boxed::Box<dyn dev::virtio::gpu::FrameSink>,
        control_sink: alloc::boxed::Box<dyn dev::virtio::gpu::control3d::Control3dSink>,
    ) -> Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::gpu::GpuState>>,
    )> {
        let (device, state) =
            dev::virtio::gpu::VirtioGpu::new_with_standard_desktop_control3d_proof_state(
                frame_sink,
                control_sink,
            );
        self.install_virtio_gpu(device, state)
    }

    #[cfg(feature = "virgl-renderer")]
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_gpu_submit3d_proof(
        &mut self,
        frame_sink: alloc::boxed::Box<dyn dev::virtio::gpu::FrameSink>,
        control_sink: alloc::boxed::Box<dyn dev::virtio::gpu::control3d::Control3dSink>,
        submit_sink: alloc::boxed::Box<dyn dev::virtio::gpu::submit3d::Submit3dSink>,
        mailbox: dev::virtio::gpu::submit3d::Submit3dMailbox,
    ) -> Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::gpu::GpuState>>,
    )> {
        let (device, state) = dev::virtio::gpu::VirtioGpu::new_with_submit3d_proof_state(
            frame_sink,
            control_sink,
            submit_sink,
            mailbox,
        );
        self.install_virtio_gpu(device, state)
    }

    /// Host-selected desktop control/store profile with ordered submission ownership.
    #[cfg(feature = "virgl-renderer")]
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_gpu_standard_desktop_submit3d_proof(
        &mut self,
        frame_sink: alloc::boxed::Box<dyn dev::virtio::gpu::FrameSink>,
        control_sink: alloc::boxed::Box<dyn dev::virtio::gpu::control3d::Control3dSink>,
        submit_sink: alloc::boxed::Box<dyn dev::virtio::gpu::submit3d::Submit3dSink>,
        mailbox: dev::virtio::gpu::submit3d::Submit3dMailbox,
    ) -> Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::gpu::GpuState>>,
    )> {
        let (device, state) =
            dev::virtio::gpu::VirtioGpu::new_with_standard_desktop_submit3d_proof_state(
                frame_sink,
                control_sink,
                submit_sink,
                mailbox,
            );
        self.install_virtio_gpu(device, state)
    }

    /// Host-selected original layered allocation/DMA; this grants no capsets.
    #[cfg(feature = "virgl-renderer")]
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_gpu_standard_dimensional_submit3d_proof(
        &mut self,
        frame_sink: alloc::boxed::Box<dyn dev::virtio::gpu::FrameSink>,
        control_sink: alloc::boxed::Box<dyn dev::virtio::gpu::control3d::Control3dSink>,
        submit_sink: alloc::boxed::Box<dyn dev::virtio::gpu::submit3d::Submit3dSink>,
        mailbox: dev::virtio::gpu::submit3d::Submit3dMailbox,
    ) -> Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::gpu::GpuState>>,
    )> {
        let (device, state) =
            dev::virtio::gpu::VirtioGpu::new_with_standard_dimensional_submit3d_proof_state(
                frame_sink,
                control_sink,
                submit_sink,
                mailbox,
            );
        self.install_virtio_gpu(device, state)
    }

    /// Host-selected original cube/array depth layout; production caps stay off.
    #[cfg(feature = "virgl-renderer")]
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_gpu_standard_dimensional_depth_submit3d_proof(
        &mut self,
        frame_sink: alloc::boxed::Box<dyn dev::virtio::gpu::FrameSink>,
        control_sink: alloc::boxed::Box<dyn dev::virtio::gpu::control3d::Control3dSink>,
        submit_sink: alloc::boxed::Box<dyn dev::virtio::gpu::submit3d::Submit3dSink>,
        mailbox: dev::virtio::gpu::submit3d::Submit3dMailbox,
    ) -> Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::gpu::GpuState>>,
    )> {
        let (device, state) =
            dev::virtio::gpu::VirtioGpu::new_with_standard_dimensional_depth_submit3d_proof_state(
                frame_sink,
                control_sink,
                submit_sink,
                mailbox,
            );
        self.install_virtio_gpu(device, state)
    }

    /// Host-selected original buffer stream-output layout; production caps stay off.
    #[cfg(feature = "virgl-renderer")]
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_gpu_standard_stream_output_submit3d_proof(
        &mut self,
        frame_sink: alloc::boxed::Box<dyn dev::virtio::gpu::FrameSink>,
        control_sink: alloc::boxed::Box<dyn dev::virtio::gpu::control3d::Control3dSink>,
        submit_sink: alloc::boxed::Box<dyn dev::virtio::gpu::submit3d::Submit3dSink>,
        mailbox: dev::virtio::gpu::submit3d::Submit3dMailbox,
    ) -> Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::gpu::GpuState>>,
    )> {
        let (device, state) =
            dev::virtio::gpu::VirtioGpu::new_with_standard_stream_output_submit3d_proof_state(
                frame_sink,
                control_sink,
                submit_sink,
                mailbox,
            );
        self.install_virtio_gpu(device, state)
    }

    #[cfg(feature = "virgl-renderer")]
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_gpu_scanout3d_proof(
        &mut self,
        frame_sink: alloc::boxed::Box<dyn dev::virtio::gpu::FrameSink>,
        control_sink: alloc::boxed::Box<dyn dev::virtio::gpu::control3d::Control3dSink>,
        submit_sink: alloc::boxed::Box<dyn dev::virtio::gpu::submit3d::Submit3dSink>,
        mailbox: dev::virtio::gpu::submit3d::Submit3dMailbox,
    ) -> Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::gpu::GpuState>>,
    )> {
        let (device, state) = dev::virtio::gpu::VirtioGpu::new_with_scanout3d_proof_state(
            frame_sink,
            control_sink,
            submit_sink,
            mailbox,
        );
        self.install_virtio_gpu(device, state)
    }

    #[cfg(feature = "virgl-renderer")]
    pub fn submit3d_gather(
        &mut self,
        exchange: &dev::virtio::gpu::submit3d::Submit3dExchange,
    ) -> Result<alloc::vec::Vec<u8>, dev::virtio::gpu::control3d::Control3dError> {
        let (state, _, _, index) = self
            .gpu
            .as_ref()
            .ok_or(dev::virtio::gpu::control3d::Control3dError::InvalidParameter)?;
        let bytes = dev::virtio::gpu::submit3d_dma(
            &self.virtio[*index].0,
            state,
            &mut self.bus,
            exchange,
            None,
            None,
        )?;
        state.borrow_mut().mirror_legacy_input(exchange, &bytes)?;
        Ok(bytes)
    }
    #[cfg(feature = "virgl-renderer")]
    pub fn submit3d_scatter(
        &mut self,
        exchange: &dev::virtio::gpu::submit3d::Submit3dExchange,
        bytes: &[u8],
    ) -> Result<(), dev::virtio::gpu::control3d::Control3dError> {
        let (state, _, _, index) = self
            .gpu
            .as_ref()
            .ok_or(dev::virtio::gpu::control3d::Control3dError::InvalidParameter)?;
        dev::virtio::gpu::submit3d_dma(
            &self.virtio[*index].0,
            state,
            &mut self.bus,
            exchange,
            Some(bytes),
            None,
        )
        .map(|_| ())
    }

    #[cfg(feature = "virgl-renderer")]
    pub fn submit3d_gather_layered(
        &mut self,
        exchange: &dev::virtio::gpu::submit3d::Submit3dExchange,
        layer_stride: u32,
        layer_count: u32,
    ) -> Result<alloc::vec::Vec<u8>, dev::virtio::gpu::control3d::Control3dError> {
        let (state, _, _, index) = self
            .gpu
            .as_ref()
            .ok_or(dev::virtio::gpu::control3d::Control3dError::InvalidParameter)?;
        dev::virtio::gpu::submit3d_dma(
            &self.virtio[*index].0,
            state,
            &mut self.bus,
            exchange,
            None,
            Some((layer_stride, layer_count)),
        )
    }

    #[cfg(feature = "virgl-renderer")]
    pub fn submit3d_scatter_layered(
        &mut self,
        exchange: &dev::virtio::gpu::submit3d::Submit3dExchange,
        layer_stride: u32,
        layer_count: u32,
        bytes: &[u8],
    ) -> Result<(), dev::virtio::gpu::control3d::Control3dError> {
        let (state, _, _, index) = self
            .gpu
            .as_ref()
            .ok_or(dev::virtio::gpu::control3d::Control3dError::InvalidParameter)?;
        dev::virtio::gpu::submit3d_dma(
            &self.virtio[*index].0,
            state,
            &mut self.bus,
            exchange,
            Some(bytes),
            Some((layer_stride, layer_count)),
        )
        .map(|_| ())
    }

    #[allow(clippy::type_complexity)]
    /// Replace the never-negotiated assembly device with a qualified host GPU.
    /// The transport itself remains at the same DTB/MMIO/IRQ address.
    #[cfg(feature = "virgl-renderer")]
    pub fn attach_qualified_virgl(
        &mut self,
        control_sink: alloc::boxed::Box<dyn dev::virtio::gpu::control3d::Control3dSink>,
        submit_sink: alloc::boxed::Box<dyn dev::virtio::gpu::submit3d::Submit3dSink>,
        mailbox: dev::virtio::gpu::submit3d::Submit3dMailbox,
        capabilities: dev::virtio::gpu::capabilities::QualifiedCapabilities,
    ) -> Result<(), &'static str> {
        if self.irq_stats().retired != 0 {
            return Err("GPU must be attached before guest execution");
        }
        let Some((old, control_queue, cursor_queue, index)) = self.gpu.as_ref() else {
            return Err("No GPU slot is installed");
        };
        if old.borrow().control3d_proof_installed()
            || control_queue.is_some()
            || cursor_queue.is_some()
        {
            return Err("GPU must be attached before its first probe");
        }
        let index = *index;
        let (device, state) = dev::virtio::gpu::VirtioGpu::new_with_qualified_renderer(
            alloc::boxed::Box::new(dev::virtio::gpu::NullSink),
            control_sink,
            submit_sink,
            mailbox,
            capabilities,
        );
        self.virtio[index]
            .0
            .borrow_mut()
            .replace_unnegotiated_device(alloc::boxed::Box::new(device))
            .map_err(|_| "GPU transport has already been negotiated")?;
        self.gpu = Some((state, None, None, index));
        Ok(())
    }

    #[allow(clippy::type_complexity)]
    fn install_virtio_gpu(
        &mut self,
        device: dev::virtio::gpu::VirtioGpu,
        state: alloc::rc::Rc<core::cell::RefCell<dev::virtio::gpu::GpuState>>,
    ) -> Option<(
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::gpu::GpuState>>,
    )> {
        assert!(
            self.virtio.len() > dev::virtio::gpu::VIRTIO_GPU_SLOT,
            "enable_virtio_slots/enable_virtio_blk before enable_virtio_gpu"
        );
        assert!(self.gpu.is_none(), "virtio-gpu is already enabled");
        let slot_index = (4..=dev::virtio::gpu::VIRTIO_GPU_SLOT)
            .rev()
            .find(|&index| self.virtio[index].0.borrow().device_id() == 0)?;
        assert!(
            self.virtio[slot_index]
                .0
                .borrow_mut()
                .install_device(alloc::boxed::Box::new(device))
                .is_ok(),
            "virtio slot {slot_index} already has a device"
        );
        self.gpu = Some((alloc::rc::Rc::clone(&state), None, None, slot_index));
        Some((alloc::rc::Rc::clone(&self.virtio[slot_index].0), state))
    }

    /// Snapshots cannot describe the installed proof renderer, even when its
    /// public maps are empty: independent renderer leases may still exist.
    #[cfg(feature = "virgl-renderer")]
    pub fn control3d_proof_installed(&self) -> bool {
        self.gpu
            .as_ref()
            .is_some_and(|(state, ..)| state.borrow().control3d_proof_installed())
    }

    /// E5-T06d: replace the host presentation callback after assembly. The guest-visible GPU
    /// device and queue state remain untouched, so attaching a browser sink cannot reset or stall
    /// a running guest.
    pub fn replace_virtio_gpu_sink(
        &mut self,
        sink: alloc::boxed::Box<dyn dev::virtio::gpu::FrameSink>,
    ) -> bool {
        let Some((state, _, _, _)) = self.gpu.as_ref() else {
            return false;
        };
        state.borrow_mut().frame_sink = sink;
        true
    }

    /// E5-T06d: report the selected virtio-gpu slot and shared state, if the display capability was
    /// installed. Hosts use the handle only for diagnostics; queue servicing stays in `run`.
    #[allow(clippy::type_complexity)]
    pub fn virtio_gpu(
        &self,
    ) -> Option<(
        usize,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::gpu::GpuState>>,
    )> {
        self.gpu
            .as_ref()
            .map(|(state, _, _, slot)| (*slot, alloc::rc::Rc::clone(state)))
    }

    /// E3-T13: attach a virtio-net device (DeviceID 1) backed by `backend` in slot 1. The
    /// nine slots must already exist ([`Self::enable_virtio_blk`] or
    /// [`Self::enable_virtio_slots`] first) — net installs into the empty slot 1 (the DTB
    /// already advertises all eight windows, so the kernel probes it with no DTB change).
    /// Returns (slot-1 handle, shared net state — inspect `rx_dropped`/`tx_count`, drive the
    /// backend).
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_net(
        &mut self,
        backend: alloc::boxed::Box<dyn dev::virtio::net::NetBackend>,
    ) -> (
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::net::NetState>>,
    ) {
        assert!(
            self.virtio.len() > 1,
            "enable_virtio_slots/enable_virtio_blk before enable_virtio_net"
        );
        let (switchable, control) = dev::virtio::net::NetBackendHandle::new(backend);
        let (devhalf, state) = dev::virtio::net::new(alloc::boxed::Box::new(switchable));
        assert!(
            self.virtio[1]
                .0
                .borrow_mut()
                .install_device(alloc::boxed::Box::new(devhalf))
                .is_ok(),
            "virtio slot 1 already has a device"
        );
        self.net = Some((alloc::rc::Rc::clone(&state), None, None));
        self.net_backend = Some(control);
        (alloc::rc::Rc::clone(&self.virtio[1].0), state)
    }

    /// Replace the host-side virtio-net backend while preserving the guest-visible device,
    /// negotiated features, MAC, and queue positions. This must be called between `run`/`step`
    /// calls, never from a backend callback. Existing backend-owned frames and socket state are
    /// discarded at the handoff; the guest remains attached to the same virtio NIC.
    pub fn replace_virtio_net_backend(
        &mut self,
        backend: alloc::boxed::Box<dyn dev::virtio::net::NetBackend>,
    ) -> Result<(), &'static str> {
        let Some(control) = &self.net_backend else {
            return Err("virtio-net is not enabled");
        };
        control.replace(backend);
        Ok(())
    }

    /// Attach a virtio-rng device (DeviceID 4) backed by `source` in slot 2. The nine slots must
    /// already exist ([`Self::enable_virtio_slots`]/`enable_virtio_blk` first) — rng installs into
    /// the empty slot 2 (the DTB already advertises all eight windows, so the kernel's
    /// `virtio-rng`/`rng-core` probe binds it with no DTB change). The kernel feeds the delivered
    /// bytes into its CRNG, so guest `getrandom(2)`/`/dev/urandom` seed promptly and early TLS
    /// handshakes stop stalling on entropy. Returns (slot-2 handle, shared rng state).
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_rng(
        &mut self,
        source: alloc::boxed::Box<dyn dev::virtio::rng::EntropySource>,
    ) -> (
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::rng::RngState>>,
    ) {
        assert!(
            self.virtio.len() > 2,
            "enable_virtio_slots/enable_virtio_blk before enable_virtio_rng"
        );
        let (devhalf, state) = dev::virtio::rng::new(source);
        assert!(
            self.virtio[2]
                .0
                .borrow_mut()
                .install_device(alloc::boxed::Box::new(devhalf))
                .is_ok(),
            "virtio slot 2 already has a device"
        );
        self.rng = Some((alloc::rc::Rc::clone(&state), None));
        (alloc::rc::Rc::clone(&self.virtio[2].0), state)
    }

    /// E5-T11b: attach the concrete virtio-input keyboard in slot 3. The standard nine slots
    /// must already exist (`enable_virtio_slots`/`enable_virtio_blk` first); slot 3 is reserved
    /// for the keyboard so GPU slot 0, net slot 1, and rng slot 2 retain their established shape.
    /// Returns the slot, event/status queue state, and host-owned LED indicator handle.
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_keyboard(
        &mut self,
    ) -> (
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::input::InputState>>,
        dev::virtio::input::keyboard::KeyboardLedHandle,
    ) {
        let slot_index = dev::virtio::input::keyboard::KEYBOARD_VIRTIO_SLOT;
        assert!(
            self.virtio.len() > slot_index,
            "enable_virtio_slots/enable_virtio_blk before enable_virtio_keyboard"
        );
        let leds = alloc::rc::Rc::new(core::cell::RefCell::new(
            dev::virtio::input::keyboard::KeyboardLedState::default(),
        ));
        let sink = alloc::boxed::Box::new(dev::virtio::input::keyboard::KeyboardLedSink::new(
            alloc::rc::Rc::clone(&leds),
        ));
        let (device, state) = dev::virtio::input::VirtioInput::new_with_status_sink_state(
            dev::virtio::input::keyboard::keyboard_spec(),
            sink,
        );
        assert!(
            self.virtio[slot_index]
                .0
                .borrow_mut()
                .install_device(alloc::boxed::Box::new(device))
                .is_ok(),
            "virtio slot {slot_index} already has a device"
        );
        self.keyboard = Some((alloc::rc::Rc::clone(&state), None, None));
        self.keyboard_leds = Some(alloc::rc::Rc::clone(&leds));
        (
            alloc::rc::Rc::clone(&self.virtio[slot_index].0),
            state,
            leds,
        )
    }

    /// Current host-side keyboard LED state, if the virtio-input keyboard is attached.
    pub fn keyboard_leds(&self) -> Option<dev::virtio::input::keyboard::KeyboardLedHandle> {
        self.keyboard_leds.as_ref().map(alloc::rc::Rc::clone)
    }

    /// Host/UI handle for injecting framed keyboard events into the guest-facing eventq. The
    /// caller appends one or more events with
    /// [`dev::virtio::input::InputState::inject_event`] and closes the frame with
    /// [`dev::virtio::input::InputState::sync`], matching the transport contract used by the
    /// browser keymap.
    pub fn keyboard_input(
        &self,
    ) -> Option<alloc::rc::Rc<core::cell::RefCell<dev::virtio::input::InputState>>> {
        self.keyboard
            .as_ref()
            .map(|(state, _, _)| alloc::rc::Rc::clone(state))
    }

    /// E5-T14a: attach the absolute tablet in slot 4 and relative mouse in slot 5. The standard
    /// nine slots must already exist; both queue states stay independent so the host can route a
    /// selected pointer mode without changing the keyboard's slot or pending frames. Returns
    /// `(tablet_slot, tablet_state, mouse_slot, mouse_state)`.
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_pointer(
        &mut self,
    ) -> (
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::input::InputState>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::input::InputState>>,
    ) {
        let tablet_slot = dev::virtio::input::pointer::TABLET_VIRTIO_SLOT;
        let mouse_slot = dev::virtio::input::pointer::MOUSE_VIRTIO_SLOT;
        assert!(
            self.virtio.len() > mouse_slot,
            "enable_virtio_slots/enable_virtio_blk before enable_virtio_pointer"
        );

        let (tablet, tablet_state) = dev::virtio::input::VirtioInput::new_with_state(
            dev::virtio::input::pointer::tablet_spec(),
        );
        assert!(
            self.virtio[tablet_slot]
                .0
                .borrow_mut()
                .install_device(alloc::boxed::Box::new(tablet))
                .is_ok(),
            "virtio slot {tablet_slot} already has a device"
        );
        self.tablet = Some((alloc::rc::Rc::clone(&tablet_state), None, None));

        let (mouse, mouse_state) = dev::virtio::input::VirtioInput::new_with_state(
            dev::virtio::input::pointer::mouse_spec(),
        );
        assert!(
            self.virtio[mouse_slot]
                .0
                .borrow_mut()
                .install_device(alloc::boxed::Box::new(mouse))
                .is_ok(),
            "virtio slot {mouse_slot} already has a device"
        );
        self.mouse = Some((alloc::rc::Rc::clone(&mouse_state), None, None));

        (
            alloc::rc::Rc::clone(&self.virtio[tablet_slot].0),
            tablet_state,
            alloc::rc::Rc::clone(&self.virtio[mouse_slot].0),
            mouse_state,
        )
    }

    /// Host/UI handle for injecting framed absolute tablet events.
    pub fn tablet_input(
        &self,
    ) -> Option<alloc::rc::Rc<core::cell::RefCell<dev::virtio::input::InputState>>> {
        self.tablet
            .as_ref()
            .map(|(state, _, _)| alloc::rc::Rc::clone(state))
    }

    /// Host/UI handle for injecting framed relative mouse events.
    pub fn mouse_input(
        &self,
    ) -> Option<alloc::rc::Rc<core::cell::RefCell<dev::virtio::input::InputState>>> {
        self.mouse
            .as_ref()
            .map(|(state, _, _)| alloc::rc::Rc::clone(state))
    }

    /// E5-T19d: attach the four-queue virtio-snd device to the first free sound slot. Slot 6 is
    /// the standard location after keyboard/tablet/mouse; slot 7 is used only when an optional
    /// secondary disk already occupies slot 6. Existing virtio slots are never replaced.
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_snd(
        &mut self,
    ) -> (
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::snd::SndState>>,
    ) {
        let clock = alloc::rc::Rc::new(dev::virtio::snd::ManualAudioClock::new());
        self.enable_virtio_snd_with_audio_and_capture(
            clock,
            alloc::boxed::Box::new(dev::virtio::snd::NullSink::new()),
            false,
        )
    }

    /// Attach the deterministic headless sound device with an explicit microphone advertisement
    /// gate. `enable_mic` changes only the guest-visible PCM configuration; it never opens a host
    /// device or requests permission.
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_snd_with_capture(
        &mut self,
        enable_mic: bool,
    ) -> (
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::snd::SndState>>,
    ) {
        let clock = alloc::rc::Rc::new(dev::virtio::snd::ManualAudioClock::new());
        self.enable_virtio_snd_with_audio_and_capture(
            clock,
            alloc::boxed::Box::new(dev::virtio::snd::NullSink::new()),
            enable_mic,
        )
    }

    /// Attach virtio-snd with a host-provided monotonic clock and output sink. The core owns both
    /// for the life of the Machine, so a native WavSink, a browser ring sink, and the default
    /// headless NullSink all exercise the same guest transport path.
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_snd_with_audio(
        &mut self,
        clock: alloc::rc::Rc<dyn dev::virtio::snd::AudioClock>,
        sink: alloc::boxed::Box<dyn dev::virtio::snd::AudioSink>,
    ) -> (
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::snd::SndState>>,
    ) {
        self.enable_virtio_snd_with_audio_and_capture(clock, sink, false)
    }

    /// Attach virtio-snd with host-provided playback timing and an explicit microphone
    /// advertisement gate. The gate is applied while the device is created, before it is
    /// installed into a virtio-mmio slot, and does not create a host capture handle.
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_snd_with_audio_and_capture(
        &mut self,
        clock: alloc::rc::Rc<dyn dev::virtio::snd::AudioClock>,
        sink: alloc::boxed::Box<dyn dev::virtio::snd::AudioSink>,
        enable_mic: bool,
    ) -> (
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::snd::SndState>>,
    ) {
        assert!(
            self.virtio.len() > dev::virtio::snd::VIRTIO_SND_SLOT,
            "enable_virtio_slots/enable_virtio_blk before enable_virtio_snd"
        );
        assert!(self.snd.is_none(), "virtio-snd is already enabled");
        let slot_index = (dev::virtio::snd::VIRTIO_SND_SLOT..self.virtio.len())
            .find(|&index| self.virtio[index].0.borrow().device_id() == 0)
            .expect("no free virtio slot for virtio-snd");
        let (device, state) = dev::virtio::snd::VirtioSnd::new_with_capture(enable_mic);
        assert!(
            self.virtio[slot_index]
                .0
                .borrow_mut()
                .install_device(alloc::boxed::Box::new(device))
                .is_ok(),
            "virtio slot {slot_index} already has a device"
        );
        self.snd = Some((
            slot_index,
            alloc::rc::Rc::clone(&state),
            None,
            None,
            None,
            None,
            clock,
            sink,
            alloc::boxed::Box::new(dev::virtio::snd::NullCaptureSource),
        ));
        (alloc::rc::Rc::clone(&self.virtio[slot_index].0), state)
    }

    /// Replace the host-side sound clock and sink after the platform has been assembled. The
    /// browser constructs the machine before it can transfer its AudioWorklet SharedArrayBuffers;
    /// narrowing the advertised PCM rate here keeps the subsequent guest probe consistent with
    /// the already-negotiated AudioContext.
    pub fn replace_virtio_snd_audio(
        &mut self,
        clock: alloc::rc::Rc<dyn dev::virtio::snd::AudioClock>,
        sink: alloc::boxed::Box<dyn dev::virtio::snd::AudioSink>,
        sample_rate_hz: u32,
    ) -> bool {
        let Some((_, state, _, _, _, _, current_clock, current_sink, _)) = self.snd.as_mut() else {
            return false;
        };
        if !state.borrow_mut().set_output_sample_rate(sample_rate_hz) {
            return false;
        }
        *current_clock = clock;
        *current_sink = sink;
        true
    }

    /// Replace the host-side sound capture source after the platform has been assembled. The
    /// default source is deterministic silence; a browser installs its shared SAB consumer only
    /// after the guest has successfully issued input PCM_START and the page has a media stream.
    pub fn replace_virtio_snd_capture(
        &mut self,
        source: alloc::boxed::Box<dyn dev::virtio::snd::AudioCaptureSource>,
    ) -> bool {
        let Some((_, _, _, _, _, _, _, _, current_source)) = self.snd.as_mut() else {
            return false;
        };
        *current_source = source;
        true
    }

    /// Current guest-visible virtio-snd slot and shared state, if sound was assembled.
    #[allow(clippy::type_complexity)]
    pub fn virtio_snd(
        &self,
    ) -> Option<(
        usize,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::snd::SndState>>,
    )> {
        self.snd
            .as_ref()
            .map(|(slot, state, _, _, _, _, _, _, _)| (*slot, alloc::rc::Rc::clone(state)))
    }

    /// E5-T26e: restore the composite desktop envelope through the concrete T26b--d device
    /// adapter. The coordinator is intentionally assembled at this boundary so a native or wasm
    /// host cannot accidentally report success from three independent device restore calls.
    pub fn restore_desktop_snapshot(
        &mut self,
        blob: &[u8],
        host_viewport: desktop_restore::DisplaySize,
    ) -> Result<desktop_restore::DesktopRestoreReport, desktop_restore::DesktopRestoreError> {
        #[cfg(feature = "virgl-renderer")]
        if self.control3d_proof_installed() {
            return Err(desktop_restore::DesktopRestoreError::CommitRefused {
                code: "proof_3d_installed",
            });
        }
        if self.gpu.is_none() {
            self.cold_boot_desktop_fallback();
            return Err(desktop_restore::DesktopRestoreError::CommitRefused {
                code: "gpu_unavailable",
            });
        }
        if self.keyboard.is_none() {
            self.cold_boot_desktop_fallback();
            return Err(desktop_restore::DesktopRestoreError::CommitRefused {
                code: "input_unavailable",
            });
        }
        if self.snd.is_none() {
            self.cold_boot_desktop_fallback();
            return Err(desktop_restore::DesktopRestoreError::CommitRefused {
                code: "sound_unavailable",
            });
        }
        if self.console.is_none() {
            // This is a pre-backend refusal. It must have the same visible result as a dropped
            // agent during staging: no retained frame, no dirty device queues, and no stale host
            // reconciliation tuple.
            self.cold_boot_desktop_fallback();
            return Err(desktop_restore::DesktopRestoreError::CommitRefused {
                code: "agent_unavailable",
            });
        }
        let gpu = self
            .gpu
            .as_ref()
            .map(|(state, _, _, _)| alloc::rc::Rc::clone(state))
            .expect("GPU checked above");
        let input = self
            .keyboard
            .as_ref()
            .map(|(state, _, _)| alloc::rc::Rc::clone(state))
            .expect("keyboard checked above");
        let sound = self
            .snd
            .as_ref()
            .map(|(_, state, _, _, _, _, _, _, _)| alloc::rc::Rc::clone(state))
            .expect("sound checked above");
        let console = self.console.as_ref().expect("console checked above");
        let backend = desktop_restore::VirtioDesktopRestoreBackend::new_with_agent(
            gpu,
            input,
            sound,
            alloc::rc::Rc::clone(&console.state),
            alloc::rc::Rc::clone(&self.desktop_restore_host),
        );
        let mut backend = match backend {
            Ok(backend) => backend,
            Err(error) => {
                self.cold_boot_desktop_fallback();
                return Err(desktop_restore::DesktopRestoreError::CommitRefused {
                    code: error.code(),
                });
            }
        };
        let mut coordinator = desktop_restore::DesktopRestoreCoordinator::new();
        coordinator.restore(blob, host_viewport, &mut backend)
    }

    /// Reset every desktop surface participating in restore to a fresh power-on baseline. This is
    /// also used before the concrete backend exists, so all early missing-device refusals clear
    /// the live presentation instead of merely discarding host metadata.
    fn cold_boot_desktop_fallback(&mut self) {
        let gpu = self
            .gpu
            .as_ref()
            .map(|(state, _, _, _)| alloc::rc::Rc::clone(state));
        let input = self
            .keyboard
            .as_ref()
            .map(|(state, _, _)| alloc::rc::Rc::clone(state));
        let sound = self
            .snd
            .as_ref()
            .map(|(_, state, _, _, _, _, _, _, _)| alloc::rc::Rc::clone(state));
        let agent = self
            .console
            .as_ref()
            .map(|console| alloc::rc::Rc::clone(&console.state));
        desktop_restore::reset_live_desktop_to_cold(
            gpu.as_ref(),
            input.as_ref(),
            sound.as_ref(),
            agent.as_ref(),
            &self.desktop_restore_host,
        );
    }

    /// E5-T26e: host-facing state from the last successful desktop restore commit.
    pub fn desktop_restore_host_state(&self) -> desktop_restore::DesktopRestoreHostState {
        *self.desktop_restore_host.borrow()
    }

    /// E5-T26f: compose the live desktop component codecs into one versioned browser snapshot.
    /// The worker calls this only at a scheduler boundary, and the existing bounded block-device
    /// quiesce gate runs first so a parked virtio-blk descriptor is never copied into the desktop
    /// envelope. Device codecs remain the owners of their payload semantics; this method only
    /// supplies the canonical section order and the current deterministic boundary id.
    pub fn save_desktop_snapshot(
        &mut self,
    ) -> Result<alloc::vec::Vec<u8>, desktop_snapshot::DesktopSnapshotSaveError> {
        #[cfg(feature = "virgl-renderer")]
        if self.control3d_proof_installed() {
            return Err(
                desktop_snapshot::DesktopSnapshotSaveError::ComponentRefused {
                    tag: desktop_snapshot::section::GPU,
                },
            );
        }
        self.quiesce()
            .map_err(|_| desktop_snapshot::DesktopSnapshotSaveError::BlockNotQuiesced)?;

        let gpu = self
            .gpu
            .as_ref()
            .map(|(state, _, _, _)| alloc::rc::Rc::clone(state))
            .ok_or(
                desktop_snapshot::DesktopSnapshotSaveError::MissingComponent {
                    tag: desktop_snapshot::section::GPU,
                },
            )?;
        let input = self
            .keyboard
            .as_ref()
            .map(|(state, _, _)| alloc::rc::Rc::clone(state))
            .ok_or(
                desktop_snapshot::DesktopSnapshotSaveError::MissingComponent {
                    tag: desktop_snapshot::section::INPUT,
                },
            )?;
        let sound = self
            .snd
            .as_ref()
            .map(|(_, state, _, _, _, _, _, _, _)| alloc::rc::Rc::clone(state))
            .ok_or(
                desktop_snapshot::DesktopSnapshotSaveError::MissingComponent {
                    tag: desktop_snapshot::section::SOUND,
                },
            )?;
        let console = self.console.as_ref().ok_or(
            desktop_snapshot::DesktopSnapshotSaveError::MissingComponent {
                tag: desktop_snapshot::section::AGENT,
            },
        )?;

        let gpu_payload = gpu.borrow().to_snapshot().map_err(|_| {
            desktop_snapshot::DesktopSnapshotSaveError::ComponentRefused {
                tag: desktop_snapshot::section::GPU,
            }
        })?;
        let input_payload = input.borrow().to_snapshot().map_err(|_| {
            desktop_snapshot::DesktopSnapshotSaveError::ComponentRefused {
                tag: desktop_snapshot::section::INPUT,
            }
        })?;
        let sound_payload = sound.borrow().to_snapshot().map_err(|_| {
            desktop_snapshot::DesktopSnapshotSaveError::ComponentRefused {
                tag: desktop_snapshot::section::SOUND,
            }
        })?;
        let agent_payload = console.state.borrow().generation().to_le_bytes();

        let mut builder = desktop_snapshot::DesktopSnapshotBuilder::new(self.irqstats.retired);
        builder
            .section(
                desktop_snapshot::section::GPU,
                desktop_snapshot::FORMAT_VERSION,
                &gpu_payload,
            )
            .map_err(
                |_| desktop_snapshot::DesktopSnapshotSaveError::ComponentRefused {
                    tag: desktop_snapshot::section::GPU,
                },
            )?;
        builder
            .section(
                desktop_snapshot::section::INPUT,
                desktop_snapshot::FORMAT_VERSION,
                &input_payload,
            )
            .map_err(
                |_| desktop_snapshot::DesktopSnapshotSaveError::ComponentRefused {
                    tag: desktop_snapshot::section::INPUT,
                },
            )?;
        builder
            .section(
                desktop_snapshot::section::SOUND,
                desktop_snapshot::FORMAT_VERSION,
                &sound_payload,
            )
            .map_err(
                |_| desktop_snapshot::DesktopSnapshotSaveError::ComponentRefused {
                    tag: desktop_snapshot::section::SOUND,
                },
            )?;
        builder
            .section(
                desktop_snapshot::section::AGENT,
                desktop_snapshot::FORMAT_VERSION,
                &agent_payload,
            )
            .map_err(
                |_| desktop_snapshot::DesktopSnapshotSaveError::ComponentRefused {
                    tag: desktop_snapshot::section::AGENT,
                },
            )?;
        builder.finish().map_err(
            |_| desktop_snapshot::DesktopSnapshotSaveError::ComponentRefused {
                tag: desktop_snapshot::section::AGENT,
            },
        )
    }

    /// E5-T23b: attach the six-queue virtio-console device (DeviceID 3) in the reserved native
    /// slot. Port 0 keeps the standard virtio-console queue pair; port 1 is the named
    /// `org.wasmvm.agent` channel. The existing UART/SBI console remains at its original MMIO
    /// address and has no shared queue or buffer with this device.
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_console(
        &mut self,
    ) -> (
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::console::ConsoleState>>,
    ) {
        self.enable_virtio_console_at(dev::virtio::console::VIRTIO_CONSOLE_SLOT)
    }

    /// Attach the same console service at an explicitly selected empty slot. The browser uses
    /// the ninth platform window so it can retain the established net/rng/input/sound/GPU layout;
    /// native callers should use [`Self::enable_virtio_console`] to keep the fixed slot-7 contract.
    #[allow(clippy::type_complexity)]
    pub fn enable_virtio_console_at(
        &mut self,
        slot_index: usize,
    ) -> (
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::mmio::VirtioMmio>>,
        alloc::rc::Rc<core::cell::RefCell<dev::virtio::console::ConsoleState>>,
    ) {
        assert!(
            self.virtio.len() > slot_index,
            "enable_virtio_slots/enable_virtio_blk before enable_virtio_console"
        );
        assert!(self.console.is_none(), "virtio-console is already enabled");
        let (device, state) = dev::virtio::console::VirtioConsole::new_with_state();
        assert!(
            self.virtio[slot_index]
                .0
                .borrow_mut()
                .install_device(alloc::boxed::Box::new(device))
                .is_ok(),
            "virtio slot {slot_index} already has a device"
        );
        self.console = Some(VirtioConsoleService {
            slot_index,
            state: alloc::rc::Rc::clone(&state),
            port0_receiveq: None,
            port0_transmitq: None,
            control_receiveq: None,
            control_transmitq: None,
            agent_receiveq: None,
            agent_transmitq: None,
        });
        (alloc::rc::Rc::clone(&self.virtio[slot_index].0), state)
    }

    /// Current guest-facing virtio-console state, if the E5 agent transport is assembled.
    pub fn virtio_console(
        &self,
    ) -> Option<alloc::rc::Rc<core::cell::RefCell<dev::virtio::console::ConsoleState>>> {
        self.console
            .as_ref()
            .map(|console| alloc::rc::Rc::clone(&console.state))
    }

    /// Record that the host-side T23d Channel completed a fresh application HELLO intersection.
    /// The transport/device readiness bits alone are intentionally insufficient for desktop
    /// restore. Returns the application HELLO generation when a live named port accepted it.
    pub fn confirm_virtio_console_agent_hello(&self) -> Option<u64> {
        let console = self.console.as_ref()?;
        console.state.borrow_mut().mark_application_hello()
    }

    /// E2-T16: attach the goldfish RTC at [`platform::virt::RTC_BASE`], wired to PLIC IRQ 11,
    /// with `clock` as its wall-clock source (`SystemTime` in the CLI, `Date.now()` in wasm, a
    /// mock in tests). Matches the `google,goldfish-rtc` node the DTB advertises — without it
    /// the kernel's `rtc-goldfish` probe takes a load access fault on the unbacked window. The
    /// guest reads real time (`clock.now_ns()` + any `date -s` offset) and can arm alarms; the
    /// run loop polls the alarm each boundary and mirrors its level into the PLIC. Requires
    /// [`Self::enable_plic`] first. Returns the shared handle (tests drive it directly).
    pub fn enable_rtc(
        &mut self,
        clock: alloc::boxed::Box<dyn dev::rtc::WallClock>,
    ) -> alloc::rc::Rc<core::cell::RefCell<dev::rtc::GoldfishRtc>> {
        let plic = self.plic.as_ref().expect("enable_plic before enable_rtc");
        let line = dev::plic::Plic::irq_line(plic, platform::virt::RTC_IRQ as usize);
        let cell = alloc::rc::Rc::new(core::cell::RefCell::new(dev::rtc::GoldfishRtc::new(clock)));
        self.bus
            .attach(
                platform::virt::RTC_BASE,
                platform::virt::RTC_LEN,
                alloc::boxed::Box::new(FabricTouch {
                    inner: dev::rtc::SharedRtc(alloc::rc::Rc::clone(&cell)),
                    epoch: alloc::rc::Rc::clone(&self.fabric_epoch),
                }),
            )
            .expect("RTC window overlaps RAM or another device");
        self.rtc = Some((alloc::rc::Rc::clone(&cell), line));
        cell
    }

    /// E2-T20: the interrupt/trap counters + storm/WFI diagnostics ([`diag::irqstats::IrqStats`]).
    /// Read after a run for `--stats`, or exposed through the wasm boundary.
    pub fn irq_stats(&self) -> &diag::irqstats::IrqStats {
        &self.irqstats
    }

    /// E2-T20: turn the always-on storm/WFI detectors on or off (default on). Off makes the
    /// per-trap `storm_check` a single early-return branch.
    pub fn set_storm_detect(&mut self, on: bool) {
        self.storm_detect = on;
    }

    /// E4-T01: arm/disarm the hot-PC + subsystem profiler (default off). Arming resets the sampling
    /// countdown so the first sample lands a full stride into the profiled span. When off, the run
    /// loop's sampling is a single not-taken branch per retire.
    pub fn set_profiling(&mut self, on: bool) {
        self.profiling = on;
        if let Some(executor) = self.executor.as_mut() {
            executor.set_entry_timing(on);
        }
        if on {
            self.prof_countdown = PROF_STRIDE_BASE;
        }
    }

    /// E4-T01 phase 3: inject the monotonic host timer AND arm profiling. The same `Rc` is handed to
    /// the bus so the cold device-dispatch and page-walk paths can bracket themselves; `run_traced`
    /// reads it once per run at entry/exit for the total wall-span. Outer crates provide the impl
    /// (native `Instant`, wasm `performance.now()`); tests use [`prof::FixedTimer`].
    pub fn set_host_timer(&mut self, timer: alloc::rc::Rc<dyn prof::HostTimer>) {
        self.host_timer = Some(alloc::rc::Rc::clone(&timer));
        self.bus.set_host_timer(timer);
        self.set_profiling(true);
    }

    /// E4-T01 phase 3: total profiled host nanoseconds measured by `run_traced` (entry→exit,
    /// accumulated across runs). Feed this to [`Self::prof_report`] as `total_ns` for the
    /// CPU-by-subtraction accounting. Zero when no [`Self::set_host_timer`] was injected.
    pub fn prof_total_ns(&self) -> u64 {
        self.prof_total_ns
    }

    /// E4-T38: the JIT compile-pause ledger without constructing the full ranked profile. Browser
    /// policy screens poll this alongside cache residency, so keep the read path allocation-free
    /// and make the pause counters share the profiler's single source of truth.
    pub fn jit_pause_stats(&self) -> prof::JitPauseStats {
        self.prof.jit_pause()
    }

    /// E4-T01: the accumulated profile as a ranked [`prof::ProfReport`]. `total_ns` is the profiled
    /// wall span (pass [`Self::prof_total_ns`] for the timer-measured span, or 0 when only the
    /// hot-PC histogram is wanted). CPU-interp time is derived as `total_ns −` the cold device+walk
    /// time folded in from the bus; `top_k` bounds the hot-region list. Non-mutating and idempotent.
    pub fn prof_report(&self, total_ns: u64, top_k: usize) -> prof::ProfReport {
        let ta = self.bus.time_accum();
        let mut report = self
            .prof
            .report_with_time(total_ns, top_k, &ta.ns, ta.walk_count);
        // E4-T08: surface the block-discovery counters through the profiling report.
        report.discovery = self.discovery.stats();
        // E4-T16: fold in the block-cache invalidation-event counters (whole-cache flushes +
        // blocks discarded by page-granular SMC/DMA invalidation). `blocks_discarded` staying flat
        // across an SFENCE.VMA storm is the "phys-keying means SFENCE.VMA does not kill blocks" proof.
        let (cache_flushes, blocks_discarded) = self.block_cache.invalidation_stats();
        report.discovery.cache_flushes = cache_flushes;
        report.discovery.blocks_discarded = blocks_discarded;
        report.discovery.fence_i = self.block_cache.fence_i_noops();
        // E4-T20: fold in the JIT translation-cache accounting when an executor is installed.
        report.jit_cache = self.executor.as_deref().map(|e| e.jit_cache_stats());
        report
    }

    /// E4-T01: the next PC-sampling stride — [`PROF_STRIDE_BASE`] plus a deterministic LCG jitter in
    /// `0..PROF_STRIDE_JITTER`. The jitter is what stops a loop whose length divides the base stride
    /// from being sampled always-at-the-same-instruction (or never); the LCG carries no wall clock so
    /// native and wasm sample identically.
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline]
    fn prof_next_stride(&mut self) -> u32 {
        self.prof_lcg = self.prof_lcg.wrapping_mul(1664525).wrapping_add(1013904223);
        PROF_STRIDE_BASE + (self.prof_lcg >> 24) % PROF_STRIDE_JITTER
    }

    /// E2-T20 `--stats`: the counter dump, with the latest PLIC claim counts synced in first
    /// (they otherwise only refresh when the storm detector runs).
    pub fn stats_dump(&mut self) -> alloc::string::String {
        if let Some(plic) = &self.plic {
            self.irqstats.claims = *plic.borrow().claim_counts();
        }
        self.irqstats.dump()
    }

    /// E2-T19 `--blk-log`: start recording virtio-blk requests (a no-op if no blk device is
    /// attached). The host drains them with [`Self::drain_blk_log`].
    pub fn enable_blk_log(&mut self) {
        if let Some((state, _)) = &self.blk {
            state.borrow_mut().enable_log();
        }
    }

    /// E2-T19: take the virtio-blk request log recorded since the last drain (empty if
    /// logging is off or no blk device is attached).
    pub fn drain_blk_log(&mut self) -> alloc::vec::Vec<dev::virtio::blk::BlkReq> {
        self.blk
            .as_ref()
            .map(|(s, _)| s.borrow_mut().take_log())
            .unwrap_or_default()
    }

    /// E3-T02: the chunks that parked virtio-blk reads are waiting on — what a lazy-fetch layer must
    /// load next. Empty unless a `WouldBlock`-returning backend has parked reads. After the layer
    /// populates these chunks, the next run-loop boundary re-services the parked reads and completes them.
    /// E3-T08: whether a guest FLUSH is parked awaiting the durable commit barrier — the
    /// persist pump should drain IMMEDIATELY (the guest's `sync` is blocked on it).
    pub fn blk_flush_waiting(&self) -> bool {
        self.blk
            .as_ref()
            .is_some_and(|(s, _)| s.borrow().flush_waiting())
    }

    /// E3-T10: whether a persistent virtio-blk WRITE is parked before used-ring acknowledgement,
    /// awaiting the host durable transaction. The wasm driver must prioritize `persistPending`
    /// while this is true; quota failure then resolves the same request with IOERR.
    pub fn blk_write_waiting(&self) -> bool {
        self.blk
            .as_ref()
            .is_some_and(|(s, _)| s.borrow().write_waiting())
    }

    pub fn pending_blk_chunks(&self) -> alloc::vec::Vec<usize> {
        self.blk
            .as_ref()
            .map(|(s, _)| s.borrow().pending_chunks())
            .unwrap_or_default()
    }

    /// E2-T17: attach the syscon test finisher (`sifive,test0`) at
    /// [`platform::virt::TEST_BASE`], matching the DTB's `test@…` node + its
    /// `syscon-poweroff`/`syscon-reboot` children. A recognized write (`0x5555` poweroff,
    /// `0x7777` reboot, `0x3333|code<<16` fail) ends the run with [`RunOutcome::Reset`]. No
    /// PLIC line — the finisher carries no interrupt.
    ///
    /// Gated `not(zicsr-stub)` to match the run loop's reset drain (critic A1): under the
    /// quarantined stub the drain is compiled out, so attaching the device would latch a reset
    /// that never ends the run — a silent hang. Making this a compile error there removes the
    /// footgun entirely.
    #[cfg(not(feature = "zicsr-stub"))]
    pub fn enable_syscon(&mut self) {
        let (device, cell) = dev::syscon::SysconFinisher::new();
        self.bus
            .attach(
                platform::virt::TEST_BASE,
                platform::virt::TEST_LEN,
                alloc::boxed::Box::new(device),
            )
            .expect("syscon window overlaps RAM or another device");
        self.syscon = Some(cell);
    }

    /// E2-T03 (ADR 0002): route `ecall`-from-S to the built-in Rust SBI ([`sbi::dispatch`])
    /// instead of delivering it as an architectural trap. Enable together with
    /// [`Self::boot_supervisor`] for the emulator-as-firmware boot path.
    #[cfg(not(feature = "zicsr-stub"))]
    pub fn enable_builtin_sbi(&mut self) {
        self.builtin_sbi = true;
    }

    /// E2-T04: where SBI console output (DBCN + legacy putchar) goes — the same
    /// [`dev::console::ConsoleSink`] trait the UART stub uses, so hosts wire both channels
    /// to one terminal. Without a sink, SBI console output is dropped (machine still runs).
    #[cfg(not(feature = "zicsr-stub"))]
    pub fn sbi_set_console(&mut self, sink: alloc::boxed::Box<dyn dev::console::ConsoleSink>) {
        self.sbi_state.console_out = Some(sink);
    }

    /// E2-T04: queue host input bytes for SBI console reads (DBCN `console_read` / legacy
    /// `getchar`). Non-blocking semantics are the callee's: an empty queue reads 0 / -1.
    #[cfg(not(feature = "zicsr-stub"))]
    pub fn sbi_push_input(&mut self, bytes: &[u8]) {
        self.sbi_state.console_in.extend(bytes.iter().copied());
    }

    /// E2-T03 boot contract (ADR 0002): enter a supervisor payload the way OpenSBI `fw_jump`
    /// would hand off to a kernel. Sets, precisely:
    /// - privilege = **S-mode**, `pc = platform::virt::KERNEL_BASE` (0x8020_0000);
    /// - `a0 = hartid`, `a1 = dtb_addr` (the standard Linux/SBI convention);
    /// - `mideleg = 0x222` (SSI/STI/SEI to S), `medeleg = 0xB1FF` (OpenSBI's full set: causes
    ///   0..=8 incl. illegal-instruction and load/store access faults, + I/L/S page faults to
    ///   S — wide by necessity, since with no guest M-mode firmware `mtvec` stays 0 and any
    ///   non-delegated trap would abort the whole machine instead of reaching the kernel);
    /// - `satp = 0` (Bare; the kernel builds its own tables), `sstatus.SIE = 0`
    ///   (interrupts masked until the kernel opts in) — both reset defaults, restated here
    ///   as part of the contract;
    /// - PMP entry 0 opened R/W/X over all of memory (S-mode needs an explicit grant).
    #[cfg(not(feature = "zicsr-stub"))]
    pub fn boot_supervisor(&mut self, hartid: u64, dtb_addr: u64) {
        use crate::csr::{CsrOp, MCOUNTEREN, MEDELEG, MIDELEG, Priv};
        self.hart.csr.pmp.allow_all();
        // Legalized writes from M (the mode we're in pre-handoff).
        self.hart.csr.mode = Priv::M;
        self.hart
            .csr
            .access(MIDELEG, CsrOp::Write, 0x222, false, false, 0)
            .expect("mideleg write from M cannot fail");
        // medeleg = 0xB1FF — OpenSBI's full delegation set: causes 0..=8 (misaligned-fetch,
        // fetch-access, ILLEGAL-INSTRUCTION, breakpoint, misaligned/access load & store,
        // ecall-from-U) plus the three page-faults (12/13/15). This MUST be the wide set, not
        // a minimal one: there is no guest M-mode firmware here (SBI is Rust) and Linux runs
        // in S-mode, so it only ever programs `stvec` — `mtvec` stays 0 forever. Any cause we
        // DON'T delegate therefore traps to M-mode, finds no handler (mtvec==0), and aborts
        // the whole machine (RunOutcome::Trapped) instead of reaching the kernel. With the
        // wide set, a userspace illegal instruction becomes SIGILL and a bad access becomes
        // SIGSEGV/SIGBUS in just that process — exactly as on real hardware + OpenSBI.
        self.hart
            .csr
            .access(MEDELEG, CsrOp::Write, 0xB1FF, false, false, 0)
            .expect("medeleg write from M cannot fail");
        // E2-T05: grant S-mode the CY/TM/IR counters (mcounteren = 0x7) — the kernel's
        // sched_clock reads `time` via rdtime, which traps without this (OpenSBI grants the
        // same). E1-T30: scounteren is granted too (just below) so U-mode rdtime works.
        self.hart
            .csr
            .access(MCOUNTEREN, CsrOp::Write, 0x7, false, false, 0)
            .expect("mcounteren write from M cannot fail");
        // E1-T30: also grant U-mode CY/TM/IR via scounteren (=0x7) so userspace `rdtime` works.
        // Stock glibc riscv64 binaries (e.g. Docker Hub busybox:latest) execute a raw userspace
        // `rdtime` (CSR `time`=0xC01) — captured SIGILL: epc in libc, insn=0xc01027f3. Our gate is
        // spec-correct (U-mode counter reads need mcounteren.TM AND scounteren.TM, §3.1.10/§4.1.5),
        // but this kernel leaves scounteren=0 and neither emulates the read nor uses only the vDSO,
        // so the read traps IllegalInstruction → the kernel delivers SIGILL and glibc dies. Granting
        // scounteren at reset mirrors firmware/platforms that expose userspace counters (the same
        // rationale as mcounteren above); the kernel remains free to restrict it by writing the CSR.
        // Verified: with this, busybox:latest glibc runs to a normal exit (was SIGILL); musl (Alpine)
        // is unaffected (it never executes userspace rdtime). See E1-T30 verification log.
        self.hart
            .csr
            .access(crate::csr::SCOUNTEREN, CsrOp::Write, 0x7, false, false, 0)
            .expect("scounteren write from M cannot fail");
        self.hart.csr.mode = Priv::S;
        self.hart.regs.pc = platform::virt::KERNEL_BASE;
        self.hart.regs.write(10, hartid); // a0
        self.hart.regs.write(11, dtb_addr); // a1
    }

    /// Load an ELF image: copy segments into RAM, set the PC to `e_entry`, and
    /// arm the HTIF watch on `tohost` if the symbol is present. A missing `tohost`
    /// leaves HTIF unarmed → the guest can only end via trap or `MaxInstrs`. Returns the
    /// [`loader::LoadedImage`] (entry + HTIF + RISCOF signature symbols) — existing callers
    /// that ignore it are unaffected.
    pub fn load_elf(&mut self, bytes: &[u8]) -> Result<loader::LoadedImage, ElfError> {
        let img = loader::load_elf(bytes, self.bus.ram_mut())?;
        self.hart.regs.pc = img.entry;
        self.htif = img.tohost.map(Htif::new);
        self.last_tohost = self
            .htif
            .map_or(0, |h| h.check(&mut self.bus).raw_or_zero());
        Ok(img)
    }

    /// E2-T15: load a flat kernel `Image` (the Linux/RISC-V boot format — a raw binary, NOT
    /// an ELF) at [`platform::virt::KERNEL_BASE`] and return `kernel_end` — one past the last
    /// byte the RUNNING kernel occupies, which is what the initrd/DTB must be placed above.
    ///
    /// Crucially this is NOT `KERNEL_BASE + file_len`: the Image file omits `.bss`/init, but
    /// the kernel reserves that memory at runtime. The RISC-V Image header (arch/riscv/kernel/
    /// head.S) carries `image_size` at byte offset 16 (LE u64), the total memory footprint;
    /// when the `RISCV\0\0\0`→`RSC\x05` magic at offset 0x38 is present and `image_size`
    /// exceeds the file, we honour it. Placing the initrd at `KERNEL_BASE + file_len` instead
    /// lands it inside `.bss` → the kernel logs "overlaps in-use memory region — disabling
    /// initrd" and boots without a rootfs. Fails `Access` if the image — or its full runtime
    /// footprint (`.bss` and all) — does not fit above `KERNEL_BASE` in RAM.
    pub fn load_kernel_image(&mut self, bytes: &[u8]) -> Result<u64, bus::BusFault> {
        let footprint = kernel_image_footprint(bytes);
        // Sweep-critic (E2-T15, MEDIUM): a hostile `image_size` near u64::MAX wrapped this add
        // in release mode — kernel_end landed BELOW KERNEL_BASE, passed the RAM-ceiling check,
        // and the initrd was silently placed on top of the kernel. checked_add → typed refusal.
        let kernel_end = platform::virt::KERNEL_BASE
            .checked_add(footprint)
            .ok_or(bus::BusFault::Access)?;
        // The RUNTIME footprint (not just the file) must fit: the no-initrd boot path has no
        // later placement check to catch a `.bss` that overflows top-of-RAM, so guard here so
        // the doc's "fails Access if it doesn't fit" is actually true.
        let ram_top = self.bus.ram().base() + self.bus.ram().len() as u64;
        if kernel_end > ram_top {
            return Err(bus::BusFault::Access);
        }
        self.bus
            .ram_mut()
            .write_slice(platform::virt::KERNEL_BASE, bytes)?;
        Ok(kernel_end)
    }

    /// E2-T15: place a blob (initrd, DTB) at an absolute guest-physical address in RAM.
    /// A thin wrapper over the RAM loader escape hatch used by the boot assembler.
    pub fn load_blob(&mut self, addr: u64, bytes: &[u8]) -> Result<(), bus::BusFault> {
        self.bus.ram_mut().write_slice(addr, bytes)
    }

    /// E2-T21: lay out the Linux boot triple in DRAM and enter it — the SHARED assembly both
    /// the native CLI and the wasm boundary call, so the (subtle, drift-prone) placement lives
    /// in exactly one place. Loads the kernel `Image` at `KERNEL_BASE`, places the initrd on
    /// the 2 MiB PMD boundary above the kernel's runtime footprint (clearing the memblock
    /// reservation — see [`Self::load_kernel_image`]), builds + places the DTB near the top of
    /// RAM (probing its length with a placeholder initrd so its address is stable), writes both
    /// blobs, and calls [`Self::boot_supervisor`] with `a1 = dtb_addr`. Device wiring
    /// (clint/plic/uart/rtc/virtio/syscon/SBI) is the CALLER's job — do it before this. Returns
    /// the [`BootLayout`] for logging.
    #[cfg(not(feature = "zicsr-stub"))]
    pub fn place_and_boot(
        &mut self,
        kernel: &[u8],
        initrd: Option<&[u8]>,
        bootargs: &str,
    ) -> Result<BootLayout, BootError> {
        let plat = platform::Platform::try_new(self.ram_len() as u64)
            .map_err(|_| BootError::PlatformInvalid)?;
        let kernel_end = self
            .load_kernel_image(kernel)
            .map_err(|_| BootError::KernelTooBig)?;
        const PMD_SIZE: u64 = 2 * 1024 * 1024;
        let initrd_floor = kernel_end
            .checked_add(PMD_SIZE - 1)
            .map(|v| v & !(PMD_SIZE - 1))
            .ok_or(BootError::KernelEndOverflow)?;

        let (dtb, dtb_addr, placed) = match initrd {
            Some(bytes) => {
                // Probe the DTB length with placeholder initrd props (same props → identical
                // length), place the DTB, then the initrd below it, then rebuild with real vals.
                let probe =
                    fdt::build_virt_dtb(&plat, bootargs, Some(fdt::Initrd { start: 0, end: 0 }));
                let dtb_addr =
                    fdt::dtb_placement(&plat, probe.len() as u64).ok_or(BootError::DtbNoFit)?;
                let place = fdt::initrd_placement(initrd_floor, dtb_addr, bytes.len() as u64)
                    .ok_or(BootError::InitrdNoFit)?;
                let dtb = fdt::build_virt_dtb(&plat, bootargs, Some(place));
                debug_assert_eq!(
                    dtb.len(),
                    probe.len(),
                    "DTB length changed with real initrd"
                );
                (dtb, dtb_addr, Some(place))
            }
            None => {
                let dtb = fdt::build_virt_dtb(&plat, bootargs, None);
                let dtb_addr =
                    fdt::dtb_placement(&plat, dtb.len() as u64).ok_or(BootError::DtbNoFit)?;
                (dtb, dtb_addr, None)
            }
        };

        if let (Some(place), Some(bytes)) = (placed, initrd) {
            self.load_blob(place.start, bytes)
                .map_err(BootError::Load)?;
        }
        self.load_blob(dtb_addr, &dtb).map_err(BootError::Load)?;
        self.boot_supervisor(0, dtb_addr);
        Ok(BootLayout {
            kernel_end,
            initrd: placed,
            dtb_addr,
            dtb_len: dtb.len(),
        })
    }

    /// Borrow the hart / bus for test rigs and the CLI (seeding instructions,
    /// inspecting the register file).
    pub fn hart_mut(&mut self) -> &mut Hart {
        // The caller may rewrite any hart state (satp, the whole CSR file, …) behind the fast
        // TLB's back; drop its entries. Semantically invisible (the architectural TLB is untouched).
        self.hart.tlb.fast_flush();
        &mut self.hart
    }
    pub fn bus_mut(&mut self) -> &mut SystemBus {
        &mut self.bus
    }
    pub fn hart(&self) -> &Hart {
        &self.hart
    }

    /// E3-T12c2: the maximum number of service passes [`Self::quiesce`] spends draining the virtio-blk
    /// in-flight set before it refuses the snapshot. A hard upper bound so a chain parked on a
    /// never-arriving event yields a *bounded* refusal, never an unbounded wait. Each pass re-executes
    /// every parked chain once; a resolvable event (a resident chunk, a now-durable flush/write) drains
    /// on the pass after it resolves, so a few passes suffice for genuinely drainable state.
    pub const QUIESCE_MAX_PASSES: u32 = 16;

    /// E3-T12c2: drive the virtio-blk in-flight (parked) set to empty within a bounded number of
    /// service passes, or refuse with the residual reason. Guarantees a coherent snapshot boundary:
    /// on `Ok(())` no descriptor chain is half-processed (nothing parked); on
    /// [`crate::resume::SnapshotError::NotQuiesced`] the caller must NOT serialize — the state is torn
    /// and a snapshot would double-complete or lose the parked request on restore.
    ///
    /// Each pass re-services the device (which re-executes parked chains; a chain whose event has
    /// resolved completes and drops out, one still waiting is re-parked). The loop terminates as soon
    /// as the set is empty, or after [`Self::QUIESCE_MAX_PASSES`] — never waits unboundedly on an event
    /// that will not arrive (a base-chunk fetch with no fetch layer, a durability barrier that never
    /// clears). No blk device ⇒ trivially quiesced.
    pub fn quiesce(&mut self) -> Result<(), crate::resume::SnapshotError> {
        // No block device (or the ring was never brought up) means there is nothing to drain.
        if self.blk.is_none() {
            return Ok(());
        }
        for _ in 0..Self::QUIESCE_MAX_PASSES {
            // Already empty — quiesced. Checked BEFORE servicing so an already-coherent machine is
            // never mutated (no spurious used-ring push or IRQ) by the quiesce itself.
            if self
                .blk
                .as_ref()
                .is_some_and(|(state, _)| state.borrow().residual().is_none())
            {
                return Ok(());
            }
            // One drain pass. `service` proceeds even without a fresh kick when the parked set is
            // non-empty (E3-T02), re-executing each parked chain; a resolved event completes it.
            if let Some((state, vq)) = &mut self.blk {
                let slot = alloc::rc::Rc::clone(&self.virtio[0].0);
                dev::virtio::blk::service(&slot, vq, state, &mut self.bus);
            }
        }
        // Budget exhausted with chains still parked → typed refusal carrying the residual.
        match self
            .blk
            .as_ref()
            .and_then(|(state, _)| state.borrow().residual())
        {
            Some((reason, in_flight)) => {
                Err(crate::resume::SnapshotError::NotQuiesced { reason, in_flight })
            }
            None => Ok(()),
        }
    }

    /// E3-T12b: serialize the machine's resumable state (CPU + RAM + CLINT when present) into one
    /// versioned resume blob.
    ///
    /// E3-T12c3: the header binds this machine's coherence identity — `core_hash` (build),
    /// `base_image_hash` (base disk), and the current overlay-commit `generation` — so
    /// [`Self::load_resume`] can refuse a stale or foreign restore. The RAM-only determinism harness
    /// leaves the defaults (all-zero / generation 0) and round-trips against an identically-bound
    /// machine; a disk-backed host calls [`Self::set_snapshot_identity`] and advances the generation.
    ///
    /// E3-T12c2: quiesces the virtio-blk in-flight set FIRST and refuses (typed
    /// [`crate::resume::SnapshotError::NotQuiesced`], no blob emitted) rather than serialize a torn
    /// boundary — a parked descriptor chain must never be captured half-processed.
    pub fn save_resume(&mut self) -> Result<alloc::vec::Vec<u8>, crate::resume::SnapshotError> {
        #[cfg(feature = "virgl-renderer")]
        if self.control3d_proof_installed() {
            return Err(crate::resume::SnapshotError::BadComponentState {
                tag: crate::resume::section::VIRTIO_GPU,
            });
        }
        self.quiesce()?;
        use crate::resume::{ComponentSnapshot, SnapshotWriter, section};
        let mut w = SnapshotWriter::new(
            &self.coherence.core_hash,
            &self.coherence.base_image_hash,
            self.coherence.generation,
        );
        w.section(section::CPU, &self.hart.to_snapshot());
        w.section(section::RAM, &self.bus.ram().to_snapshot());
        if let Some(clint) = &self.clint {
            w.section(section::CLINT, &clint.borrow().to_snapshot());
        }
        // E3-T12c4: the interrupt controller + console + RTC device state. Without these a resumed
        // guest lands with a live driver (its register writes are in the restored RAM) but a
        // freshly-reset device — the UART's RX-interrupt-enable is lost and the console wedges, the
        // PLIC's enables/priorities are gone and external IRQs never route. Restoring them makes the
        // resumed machine's devices agree with the guest's driver state.
        if let Some(plic) = &self.plic {
            w.section(section::PLIC, &plic.borrow().to_snapshot());
        }
        if let Some((uart, _)) = &self.uart {
            w.section(section::UART, &uart.borrow().to_snapshot());
        }
        if let Some((rtc, _)) = &self.rtc {
            w.section(section::RTC, &rtc.borrow().to_snapshot());
        }
        // E3-T12c1: virtio-blk transport lifecycle + device ring position + FLUSH-forward count. The
        // disk bytes are the overlay (bound by generation, E3-T12c3), not serialized here; the parked
        // in-flight set is drained/refused by the quiesce (E3-T12c2) so it is empty at this boundary.
        if let (Some((state, vq)), Some((slot, _))) = (&self.blk, self.virtio.first()) {
            let mut v = alloc::vec::Vec::new();
            slot.borrow().snapshot_transport(&mut v);
            match vq {
                Some(q) => {
                    v.push(1);
                    let (la, ui) = q.ring_indices();
                    v.extend_from_slice(&la.to_le_bytes());
                    v.extend_from_slice(&ui.to_le_bytes());
                }
                None => {
                    v.push(0);
                    v.extend_from_slice(&[0u8; 4]);
                }
            }
            v.extend_from_slice(&state.borrow().flush_count.to_le_bytes());
            w.section(section::VIRTIO_BLK, &v);
        }
        // E3-T12c1: virtio-net transport + BOTH ring positions (receiveq/transmitq) + counters. The
        // backend's live connections cannot resume (peers/TCP state are gone — the guest sees drops,
        // E3-T25); but the transport + ring state must match the guest's driver so it isn't wedged.
        if let (Some((state, rx_vq, tx_vq)), Some((slot, _))) = (&self.net, self.virtio.get(1)) {
            let mut v = alloc::vec::Vec::new();
            slot.borrow().snapshot_transport(&mut v);
            for q in [rx_vq, tx_vq] {
                match q {
                    Some(vq) => {
                        v.push(1);
                        let (la, ui) = vq.ring_indices();
                        v.extend_from_slice(&la.to_le_bytes());
                        v.extend_from_slice(&ui.to_le_bytes());
                    }
                    None => {
                        v.push(0);
                        v.extend_from_slice(&[0u8; 4]);
                    }
                }
            }
            let st = state.borrow();
            v.extend_from_slice(&st.rx_dropped.to_le_bytes());
            v.extend_from_slice(&st.tx_count.to_le_bytes());
            v.extend_from_slice(&st.rx_count.to_le_bytes());
            w.section(section::VIRTIO_NET, &v);
        }
        // E5-T26h: compose each desktop codec with its live MMIO register file and service-ring
        // cursors. Host sinks/clocks remain owned by the freshly assembled target machine; only
        // guest-visible state and deterministic device shadows cross the resume boundary.
        if let Some((state, vq, cursor_vq, slot_index)) = &self.gpu {
            let mut v = alloc::vec::Vec::new();
            self.virtio[*slot_index]
                .0
                .borrow()
                .snapshot_transport(&mut v);
            append_resume_queue(&mut v, vq);
            append_resume_queue(&mut v, cursor_vq);
            let payload = state.borrow().to_snapshot().map_err(|_| {
                crate::resume::SnapshotError::BadComponentState {
                    tag: section::VIRTIO_GPU,
                }
            })?;
            v.extend_from_slice(&payload);
            w.section(section::VIRTIO_GPU, &v);
        }
        if let Some((state, eventq, statusq)) = &self.keyboard {
            // A physical key/button belongs to the old host session. Turn it into a protected
            // release frame before encoding so a fresh target cannot inherit a stuck key.
            state.borrow_mut().release_all();
            let mut v = alloc::vec::Vec::new();
            self.virtio[dev::virtio::input::keyboard::KEYBOARD_VIRTIO_SLOT]
                .0
                .borrow()
                .snapshot_transport(&mut v);
            append_resume_queue(&mut v, eventq);
            append_resume_queue(&mut v, statusq);
            let payload = state.borrow().to_snapshot().map_err(|_| {
                crate::resume::SnapshotError::BadComponentState {
                    tag: section::VIRTIO_KEYBOARD,
                }
            })?;
            v.extend_from_slice(&payload);
            w.section(section::VIRTIO_KEYBOARD, &v);
        }
        if let Some((state, eventq, statusq)) = &self.tablet {
            state.borrow_mut().release_all();
            let mut v = alloc::vec::Vec::new();
            self.virtio[dev::virtio::input::pointer::TABLET_VIRTIO_SLOT]
                .0
                .borrow()
                .snapshot_transport(&mut v);
            append_resume_queue(&mut v, eventq);
            append_resume_queue(&mut v, statusq);
            let payload = state.borrow().to_snapshot().map_err(|_| {
                crate::resume::SnapshotError::BadComponentState {
                    tag: section::VIRTIO_TABLET,
                }
            })?;
            v.extend_from_slice(&payload);
            w.section(section::VIRTIO_TABLET, &v);
        }
        if let Some((state, eventq, statusq)) = &self.mouse {
            state.borrow_mut().release_all();
            let mut v = alloc::vec::Vec::new();
            self.virtio[dev::virtio::input::pointer::MOUSE_VIRTIO_SLOT]
                .0
                .borrow()
                .snapshot_transport(&mut v);
            append_resume_queue(&mut v, eventq);
            append_resume_queue(&mut v, statusq);
            let payload = state.borrow().to_snapshot().map_err(|_| {
                crate::resume::SnapshotError::BadComponentState {
                    tag: section::VIRTIO_MOUSE,
                }
            })?;
            v.extend_from_slice(&payload);
            w.section(section::VIRTIO_MOUSE, &v);
        }
        if let Some((slot_index, state, controlq, eventq, rxq, txq, _, _, _)) = &self.snd {
            let mut v = alloc::vec::Vec::new();
            self.virtio[*slot_index]
                .0
                .borrow()
                .snapshot_transport(&mut v);
            // Prefix entries are indexed by the transport: control=0, event=1, TX=2, RX=3.
            // The Machine tuple keeps RX before TX, so do not copy its field order here.
            for queue in [controlq, eventq, txq, rxq] {
                append_resume_queue(&mut v, queue);
            }
            v.extend_from_slice(&SND_RESUME_LAYOUT_VERSION.to_le_bytes());
            let payload = state.borrow().to_snapshot().map_err(|_| {
                crate::resume::SnapshotError::BadComponentState {
                    tag: section::VIRTIO_SND,
                }
            })?;
            v.extend_from_slice(&payload);
            w.section(section::VIRTIO_SND, &v);
        }
        if let Some((state, vq)) = &self.rng {
            let mut v = alloc::vec::Vec::new();
            self.virtio[2].0.borrow().snapshot_transport(&mut v);
            append_resume_queue(&mut v, vq);
            state.borrow().snapshot_resume(&mut v);
            w.section(section::VIRTIO_RNG, &v);
        }
        // E5-T26f: the guest's virtio-console driver remains live in restored RAM. Persist its
        // transport lifecycle and device-side ring cursors as well as the small host lifecycle
        // tuple, while intentionally dropping application bytes so the browser can establish a
        // fresh Channel generation after reload.
        if let Some(console) = &self.console {
            let slot = alloc::rc::Rc::clone(&self.virtio[console.slot_index].0);
            let mut v = alloc::vec::Vec::new();
            slot.borrow().snapshot_transport(&mut v);
            for q in [
                &console.port0_receiveq,
                &console.port0_transmitq,
                &console.control_receiveq,
                &console.control_transmitq,
                &console.agent_receiveq,
                &console.agent_transmitq,
            ] {
                append_resume_queue(&mut v, q);
            }
            console.state.borrow().snapshot_resume(&mut v);
            w.section(section::VIRTIO_CONSOLE, &v);
        }
        // Deterministic-clock phase (E3-T12b): the sub-`clock_div` remainder + `clock_div` itself, so
        // the next `mtime` tick lands at the identical retirement after resume (instruction-exact
        // timer placement). Machine-level state, so it has its own section.
        let mut clock = alloc::vec::Vec::with_capacity(24);
        clock.extend_from_slice(&self.tick_accum.to_le_bytes());
        clock.extend_from_slice(&self.clock_div.to_le_bytes());
        // The built-in-SBI S-timer deadline (`stimecmp`) drives mip.STIP = (mtime >= stimecmp) each
        // boundary; without it a timer-armed guest resumes with the S-timer cancelled and the
        // interrupt lands at a different instruction (E3-T12b timer-placement).
        clock.extend_from_slice(&self.sbi_state.stimecmp.to_le_bytes());
        w.section(section::CLOCK, &clock);
        Ok(w.finish())
    }

    /// E3-T12b: restore the machine from a [`Self::save_resume`] blob — CPU, RAM, and CLINT. Each
    /// component's `restore` is all-or-nothing (a malformed section is a typed error that leaves that
    /// component untouched); an unknown/unsupported/garbage section is refused, never skipped.
    ///
    /// E3-T12c3: the coherence guard runs FIRST — the header's `core_hash` / `base_image_hash` /
    /// `overlay_generation` are validated against this machine's binding BEFORE any component is
    /// restored. A changed base image or a bumped overlay generation is a typed refusal
    /// ([`crate::resume::SnapshotError::BaseImageMismatch`] /
    /// [`crate::resume::SnapshotError::OverlayGenerationMismatch`]) with the target machine left
    /// byte-identical to its pre-restore state — a resumed CPU/RAM never lands on a diverged disk.
    pub fn load_resume(&mut self, blob: &[u8]) -> Result<(), crate::resume::SnapshotError> {
        #[cfg(feature = "virgl-renderer")]
        if self.control3d_proof_installed() {
            return Err(crate::resume::SnapshotError::BadComponentState {
                tag: crate::resume::section::VIRTIO_GPU,
            });
        }
        use crate::resume::{ComponentSnapshot, SectionReader, section};
        let (hdr, reader) = SectionReader::new(blob)?;
        // Coherence guard BEFORE any mutation: refuse a foreign/stale snapshot up front so a failed
        // restore never half-applies a component onto a diverged disk (all-or-nothing at the machine
        // level). The iterator below has not touched machine state yet.
        hdr.validate_for(
            &self.coherence.core_hash,
            &self.coherence.base_image_hash,
            self.coherence.generation,
        )?;
        // Parse the complete TLV list before applying anything. The desktop sections below are
        // then decoded against detached transports and throwaway codec instances. Every fallible
        // legacy component is checked too: a later CPU/RAM/device refusal must not leave an earlier
        // desktop commit (including a host GPU repair frame) behind.
        let mut sections = alloc::vec::Vec::new();
        for sec in reader {
            sections.push(sec?);
        }
        let desktop_sections = [
            (section::VIRTIO_GPU, self.gpu.is_some()),
            (section::VIRTIO_KEYBOARD, self.keyboard.is_some()),
            (section::VIRTIO_TABLET, self.tablet.is_some()),
            (section::VIRTIO_MOUSE, self.mouse.is_some()),
            (section::VIRTIO_SND, self.snd.is_some()),
            (section::VIRTIO_CONSOLE, self.console.is_some()),
            (section::VIRTIO_RNG, self.rng.is_some()),
        ];
        for &(tag, present) in &desktop_sections {
            let count = sections.iter().filter(|sec| sec.tag == tag).count();
            if count > 1 || (present != (count == 1)) {
                return Err(crate::resume::SnapshotError::BadComponentState { tag });
            }
        }
        for sec in &sections {
            match sec.tag {
                section::CPU => Hart::new().restore(sec.payload)?,
                section::RAM => {
                    crate::resume::validate_sparse(sec.payload, self.bus.ram().len())?;
                }
                section::CLINT => dev::clint::ClintState::default().restore(sec.payload)?,
                section::PLIC => dev::plic::PlicState::default().restore(sec.payload)?,
                section::UART => dev::uart16550::Uart16550::new().restore(sec.payload)?,
                section::RTC => {
                    dev::rtc::GoldfishRtc::new(alloc::boxed::Box::new(dev::rtc::FixedClock(0)))
                        .restore(sec.payload)?;
                }
                section::CLOCK => {
                    let mut reader = crate::resume::Reader::new(sec.payload, sec.tag);
                    reader.u64()?;
                    reader.u64()?;
                    reader.u64()?;
                    reader.finish()?;
                }
                section::VIRTIO_BLK | section::VIRTIO_NET => {
                    let (slot_index, queue_count, counter_count) = if sec.tag == section::VIRTIO_BLK
                    {
                        (0, 1, 1)
                    } else {
                        (1, 2, 3)
                    };
                    if self.virtio.get(slot_index).is_none() {
                        return Err(crate::resume::SnapshotError::BadComponentState {
                            tag: sec.tag,
                        });
                    }
                    // Use the same transport decoder and field reads as the legacy commit pass,
                    // keeping its accepted wire layout while moving all refusal ahead of writes.
                    let mut reader = crate::resume::Reader::new(sec.payload, sec.tag);
                    dev::virtio::mmio::VirtioMmio::empty().restore_transport(&mut reader)?;
                    for _ in 0..queue_count {
                        reader.bool()?;
                        reader.u16()?;
                        reader.u16()?;
                    }
                    for _ in 0..counter_count {
                        reader.u64()?;
                    }
                    reader.finish()?;
                }
                section::VIRTIO_GPU => {
                    let (_, _, payload) = parse_resume_device_prefix(sec.payload, sec.tag, 2)?;
                    let mut device = dev::virtio::gpu::VirtioGpu::new();
                    device.restore_snapshot(payload).map_err(|_| {
                        crate::resume::SnapshotError::BadComponentState { tag: sec.tag }
                    })?;
                }
                section::VIRTIO_KEYBOARD => {
                    let (_, _, payload) = parse_resume_device_prefix(sec.payload, sec.tag, 2)?;
                    let (_, state) = dev::virtio::input::VirtioInput::new_with_state(
                        dev::virtio::input::keyboard::keyboard_spec(),
                    );
                    state.borrow_mut().restore_snapshot(payload).map_err(|_| {
                        crate::resume::SnapshotError::BadComponentState { tag: sec.tag }
                    })?;
                }
                section::VIRTIO_TABLET => {
                    let (_, _, payload) = parse_resume_device_prefix(sec.payload, sec.tag, 2)?;
                    let (_, state) = dev::virtio::input::VirtioInput::new_with_state(
                        dev::virtio::input::pointer::tablet_spec(),
                    );
                    state.borrow_mut().restore_snapshot(payload).map_err(|_| {
                        crate::resume::SnapshotError::BadComponentState { tag: sec.tag }
                    })?;
                }
                section::VIRTIO_MOUSE => {
                    let (_, _, payload) = parse_resume_device_prefix(sec.payload, sec.tag, 2)?;
                    let (_, state) = dev::virtio::input::VirtioInput::new_with_state(
                        dev::virtio::input::pointer::mouse_spec(),
                    );
                    state.borrow_mut().restore_snapshot(payload).map_err(|_| {
                        crate::resume::SnapshotError::BadComponentState { tag: sec.tag }
                    })?;
                }
                section::VIRTIO_SND => {
                    let (_, _, payload) = parse_resume_device_prefix(sec.payload, sec.tag, 4)?;
                    let mut device = dev::virtio::snd::VirtioSnd::new();
                    device.restore_snapshot(payload).map_err(|_| {
                        crate::resume::SnapshotError::BadComponentState { tag: sec.tag }
                    })?;
                }
                section::VIRTIO_CONSOLE => {
                    let (_, _, payload) = parse_resume_device_prefix(sec.payload, sec.tag, 6)?;
                    let mut state = dev::virtio::console::ConsoleState::new();
                    let mut reader = crate::resume::Reader::new(payload, sec.tag);
                    state.restore_resume(&mut reader)?;
                    reader.finish()?;
                }
                section::VIRTIO_RNG => {
                    let (_, _, payload) = parse_resume_device_prefix(sec.payload, sec.tag, 1)?;
                    let mut reader = crate::resume::Reader::new(payload, sec.tag);
                    reader.bool()?;
                    reader.bool()?;
                    reader.u64()?;
                    reader.finish()?;
                }
                _ => {}
            }
        }
        for sec in &sections {
            match sec.tag {
                section::VIRTIO_GPU => {
                    let (_, rings, payload) = parse_resume_device_prefix(sec.payload, sec.tag, 2)?;
                    let Some((state, control_vq, cursor_vq, slot_index)) = &mut self.gpu else {
                        return Err(crate::resume::SnapshotError::BadComponentState {
                            tag: sec.tag,
                        });
                    };
                    let slot = alloc::rc::Rc::clone(&self.virtio[*slot_index].0);
                    let mut reader = crate::resume::Reader::new(sec.payload, sec.tag);
                    slot.borrow_mut().restore_transport(&mut reader)?;
                    for _ in &rings {
                        reader.bool()?;
                        reader.u16()?;
                        reader.u16()?;
                    }
                    let mut queues = restore_resume_queues(&slot, &rings, sec.tag)?;
                    state.borrow_mut().restore_snapshot(payload).map_err(|_| {
                        crate::resume::SnapshotError::BadComponentState { tag: sec.tag }
                    })?;
                    *control_vq = queues.remove(0);
                    *cursor_vq = queues.remove(0);
                }
                section::VIRTIO_KEYBOARD | section::VIRTIO_TABLET | section::VIRTIO_MOUSE => {
                    let slot_index = match sec.tag {
                        section::VIRTIO_KEYBOARD => {
                            dev::virtio::input::keyboard::KEYBOARD_VIRTIO_SLOT
                        }
                        section::VIRTIO_TABLET => dev::virtio::input::pointer::TABLET_VIRTIO_SLOT,
                        _ => dev::virtio::input::pointer::MOUSE_VIRTIO_SLOT,
                    };
                    let (_, rings, payload) = parse_resume_device_prefix(sec.payload, sec.tag, 2)?;
                    let (state, eventq, statusq) = match sec.tag {
                        section::VIRTIO_KEYBOARD => self
                            .keyboard
                            .as_mut()
                            .map(|device| (&mut device.0, &mut device.1, &mut device.2)),
                        section::VIRTIO_TABLET => self
                            .tablet
                            .as_mut()
                            .map(|device| (&mut device.0, &mut device.1, &mut device.2)),
                        _ => self
                            .mouse
                            .as_mut()
                            .map(|device| (&mut device.0, &mut device.1, &mut device.2)),
                    }
                    .ok_or(crate::resume::SnapshotError::BadComponentState { tag: sec.tag })?;
                    let slot = alloc::rc::Rc::clone(&self.virtio[slot_index].0);
                    let mut reader = crate::resume::Reader::new(sec.payload, sec.tag);
                    slot.borrow_mut().restore_transport(&mut reader)?;
                    for _ in &rings {
                        reader.bool()?;
                        reader.u16()?;
                        reader.u16()?;
                    }
                    let mut queues = restore_resume_queues(&slot, &rings, sec.tag)?;
                    state.borrow_mut().restore_snapshot(payload).map_err(|_| {
                        crate::resume::SnapshotError::BadComponentState { tag: sec.tag }
                    })?;
                    *eventq = queues.remove(0);
                    *statusq = queues.remove(0);
                }
                section::VIRTIO_SND => {
                    let (_, rings, payload) = parse_resume_device_prefix(sec.payload, sec.tag, 4)?;
                    let Some((slot_index, state, controlq, eventq, rxq, txq, _, _, _)) =
                        &mut self.snd
                    else {
                        return Err(crate::resume::SnapshotError::BadComponentState {
                            tag: sec.tag,
                        });
                    };
                    let slot = alloc::rc::Rc::clone(&self.virtio[*slot_index].0);
                    let mut reader = crate::resume::Reader::new(sec.payload, sec.tag);
                    slot.borrow_mut().restore_transport(&mut reader)?;
                    for _ in &rings {
                        reader.bool()?;
                        reader.u16()?;
                        reader.u16()?;
                    }
                    let mut queues = restore_resume_queues(&slot, &rings, sec.tag)?;
                    state.borrow_mut().restore_snapshot(payload).map_err(|_| {
                        crate::resume::SnapshotError::BadComponentState { tag: sec.tag }
                    })?;
                    *controlq = queues.remove(0);
                    *eventq = queues.remove(0);
                    *txq = queues.remove(0);
                    *rxq = queues.remove(0);
                }
                section::VIRTIO_RNG => {
                    let (_, rings, payload) = parse_resume_device_prefix(sec.payload, sec.tag, 1)?;
                    let Some((state, vq)) = &mut self.rng else {
                        return Err(crate::resume::SnapshotError::BadComponentState {
                            tag: sec.tag,
                        });
                    };
                    let slot = alloc::rc::Rc::clone(&self.virtio[2].0);
                    let mut reader = crate::resume::Reader::new(sec.payload, sec.tag);
                    slot.borrow_mut().restore_transport(&mut reader)?;
                    for _ in &rings {
                        reader.bool()?;
                        reader.u16()?;
                        reader.u16()?;
                    }
                    let mut queues = restore_resume_queues(&slot, &rings, sec.tag)?;
                    let mut state_reader = crate::resume::Reader::new(payload, sec.tag);
                    state.borrow_mut().restore_resume(&mut state_reader)?;
                    state_reader.finish()?;
                    *vq = queues.remove(0);
                }
                _ => {}
            }
        }
        for sec in sections {
            match sec.tag {
                section::CPU => self.hart.restore(sec.payload)?,
                section::RAM => self.bus.ram_mut().restore(sec.payload)?,
                section::CLINT => {
                    if let Some(clint) = &self.clint {
                        clint.borrow_mut().restore(sec.payload)?;
                    }
                }
                // E3-T12c4: interrupt controller / console / RTC device state — restore so the
                // resumed devices match the guest driver (RX IRQ enable, PLIC enables, RTC alarm).
                section::PLIC => {
                    if let Some(plic) = &self.plic {
                        plic.borrow_mut().restore(sec.payload)?;
                    }
                }
                section::UART => {
                    if let Some((uart, _)) = &self.uart {
                        uart.borrow_mut().restore(sec.payload)?;
                    }
                }
                section::RTC => {
                    if let Some((rtc, _)) = &self.rtc {
                        rtc.borrow_mut().restore(sec.payload)?;
                    }
                }
                section::CLOCK => {
                    let mut r = crate::resume::Reader::new(sec.payload, section::CLOCK);
                    let tick_accum = r.u64()?;
                    let clock_div = r.u64()?;
                    let stimecmp = r.u64()?;
                    r.finish()?;
                    self.tick_accum = tick_accum;
                    self.clock_div = clock_div;
                    self.sbi_state.stimecmp = stimecmp;
                }
                section::VIRTIO_BLK => {
                    let slot = self
                        .virtio
                        .first()
                        .map(|(s, _)| alloc::rc::Rc::clone(s))
                        .ok_or(crate::resume::SnapshotError::BadComponentState {
                            tag: section::VIRTIO_BLK,
                        })?;
                    let mut r = crate::resume::Reader::new(sec.payload, section::VIRTIO_BLK);
                    slot.borrow_mut().restore_transport(&mut r)?;
                    let has_vq = r.bool()?;
                    let la = r.u16()?;
                    let ui = r.u16()?;
                    let flush = r.u64()?;
                    r.finish()?;
                    // Rebuild the ring view from the restored transport config, then set the ring
                    // position; only if the driver had a ready queue and a live view at save time.
                    let qs = *slot.borrow().queue(0);
                    if let Some((state, vq)) = &mut self.blk {
                        *vq = if has_vq && qs.ready {
                            dev::virtio::queue::Virtqueue::new(&qs, 256)
                                .ok()
                                .map(|mut q| {
                                    q.set_ring_indices(la, ui);
                                    q
                                })
                        } else {
                            None
                        };
                        state.borrow_mut().flush_count = flush;
                    }
                }
                section::VIRTIO_NET => {
                    let slot = self
                        .virtio
                        .get(1)
                        .map(|(s, _)| alloc::rc::Rc::clone(s))
                        .ok_or(crate::resume::SnapshotError::BadComponentState {
                            tag: section::VIRTIO_NET,
                        })?;
                    let mut r = crate::resume::Reader::new(sec.payload, section::VIRTIO_NET);
                    slot.borrow_mut().restore_transport(&mut r)?;
                    let rx_has = r.bool()?;
                    let rx_la = r.u16()?;
                    let rx_ui = r.u16()?;
                    let tx_has = r.bool()?;
                    let tx_la = r.u16()?;
                    let tx_ui = r.u16()?;
                    let rx_dropped = r.u64()?;
                    let tx_count = r.u64()?;
                    let rx_count = r.u64()?;
                    r.finish()?;
                    let qs0 = *slot.borrow().queue(0);
                    let qs1 = *slot.borrow().queue(1);
                    if let Some((state, rx_vq, tx_vq)) = &mut self.net {
                        *rx_vq = if rx_has && qs0.ready {
                            dev::virtio::queue::Virtqueue::new(&qs0, 256)
                                .ok()
                                .map(|mut q| {
                                    q.set_ring_indices(rx_la, rx_ui);
                                    q
                                })
                        } else {
                            None
                        };
                        *tx_vq = if tx_has && qs1.ready {
                            dev::virtio::queue::Virtqueue::new(&qs1, 256)
                                .ok()
                                .map(|mut q| {
                                    q.set_ring_indices(tx_la, tx_ui);
                                    q
                                })
                        } else {
                            None
                        };
                        let mut st = state.borrow_mut();
                        st.rx_dropped = rx_dropped;
                        st.tx_count = tx_count;
                        st.rx_count = rx_count;
                    }
                }
                section::VIRTIO_CONSOLE => {
                    let Some(console) = &mut self.console else {
                        return Err(crate::resume::SnapshotError::BadComponentState {
                            tag: section::VIRTIO_CONSOLE,
                        });
                    };
                    let (_, rings, payload) = parse_resume_device_prefix(sec.payload, sec.tag, 6)?;
                    let slot = alloc::rc::Rc::clone(&self.virtio[console.slot_index].0);
                    let mut reader = crate::resume::Reader::new(sec.payload, sec.tag);
                    slot.borrow_mut().restore_transport(&mut reader)?;
                    for _ in &rings {
                        reader.bool()?;
                        reader.u16()?;
                        reader.u16()?;
                    }
                    let mut restored_queues = restore_resume_queues(&slot, &rings, sec.tag)?;
                    let mut state_reader = crate::resume::Reader::new(payload, sec.tag);
                    console
                        .state
                        .borrow_mut()
                        .restore_resume(&mut state_reader)?;
                    state_reader.finish()?;
                    console.port0_receiveq = restored_queues.remove(0);
                    console.port0_transmitq = restored_queues.remove(0);
                    console.control_receiveq = restored_queues.remove(0);
                    console.control_transmitq = restored_queues.remove(0);
                    console.agent_receiveq = restored_queues.remove(0);
                    console.agent_transmitq = restored_queues.remove(0);
                }
                // Desktop devices are decoded and committed in the transactional passes above;
                // skip them here so the legacy component restores retain their existing order
                // without applying the same transport or codec twice.
                section::VIRTIO_GPU
                | section::VIRTIO_KEYBOARD
                | section::VIRTIO_TABLET
                | section::VIRTIO_MOUSE
                | section::VIRTIO_SND
                | section::VIRTIO_RNG => {}
                other => {
                    return Err(crate::resume::SnapshotError::UnsupportedSection { tag: other });
                }
            }
        }
        // Agent TX still in guest RAM belongs to the saved application session, including any
        // pending HELLO. Complete it without forwarding bytes into the new host Channel. Do this
        // after every section (RAM need not precede console in the container), before any guest
        // execution can post fresh descriptors or observe completions and reuse old ones.
        if let Some(console) = &mut self.console {
            let slot = alloc::rc::Rc::clone(&self.virtio[console.slot_index].0);
            dev::virtio::console::discard_resume_agent_tx(
                &slot,
                &mut console.agent_transmitq,
                &console.state,
                &mut self.bus,
            );
        }
        // E4-T05: a restore swaps CPU + RAM wholesale, so any predecoded block (keyed by the
        // pre-restore physical layout) is now stale — flush the cache and drop the cursor.
        self.block_cache.flush();
        self.block_cursor = None;
        self.pmp_revision_seen = self.hart.csr.pmp.revision();
        self.pmp_mode_seen = self.hart.csr.mode;
        // E4-T08: the restored physical layout invalidates every nominated block — reset discovery.
        self.discovery.reset();
        // E4-T10: recompile from cold on the restored image — every compiled block is stale.
        if let Some(e) = self.executor.as_mut() {
            e.invalidate_all();
        }
        // Host epochs are not portable snapshot data. Only a successful whole-machine commit
        // may discard the previous wall anchor; every refusal above preserves it untouched.
        #[cfg(not(feature = "zicsr-stub"))]
        self.rebase_guest_clock();
        Ok(())
    }

    /// RISCOF signature dump (E1-T20): the memory region `[begin, end)` formatted as the
    /// arch-test signature — one `granularity`-byte little-endian value per line, lowercase
    /// hex, zero-padded to `2*granularity` digits. Only `granularity == 4` (the RISCOF default)
    /// is supported. Reads through the bus (so it goes through the same physical map the guest
    /// wrote); a byte outside RAM reads 0. `end` is rounded up to the next word.
    pub fn signature(
        &mut self,
        begin: u64,
        end: u64,
        granularity: u32,
    ) -> Result<alloc::string::String, alloc::string::String> {
        use crate::bus::Bus;
        use core::fmt::Write as _;
        // `String`/`format!` come from `alloc`, not the prelude, under the `no_std` (wasm)
        // build — fully-qualify so this compiles in BOTH configs (E1-T24 gate caught a
        // latent no_std break here: the E1-T20 signature dump used the bare prelude names,
        // which silently broke `make wasm` until the Level-1 gate exercised the wasm leg).
        if granularity != 4 {
            return Err(alloc::format!(
                "unsupported --signature-granularity {granularity} (only 4)"
            ));
        }
        let mut out = alloc::string::String::new();
        let mut a = begin & !3; // word-align the start
        while a < end {
            let w = self.bus.load32(a).unwrap_or(0);
            let _ = writeln!(out, "{w:08x}");
            a += 4;
        }
        Ok(out)
    }

    /// Arm the HTIF watch directly (for blobs assembled in-memory without an ELF).
    pub fn set_htif(&mut self, tohost_addr: u64) {
        self.htif = Some(Htif::new(tohost_addr));
        self.last_tohost = self
            .htif
            .map_or(0, |h| h.check(&mut self.bus).raw_or_zero());
    }

    /// Count of unsupported HTIF command writes observed so far ("logged once"
    /// each: the change-detection watch never re-counts a value that sits).
    pub fn htif_command_count(&self) -> u64 {
        self.htif_commands
    }

    /// Step one instruction with a [`trace::TraceSink`] hook (E0-T16). Does NOT consult
    /// HTIF — the caller drives termination (e.g. via [`Self::htif_exit`]); use this to
    /// trace a run instruction-by-instruction. The untraced [`Self::step`] path uses the
    /// private unit capture; this method always retains public retirement records.
    pub fn step_traced<T: trace::TraceSink>(&mut self, sink: &mut T) -> Result<(), hart::Trap> {
        self.hart.step_traced(&mut self.bus, sink)
    }

    /// One PURE step (E1-T10): fetch-decode-execute a single instruction WITHOUT trap
    /// delivery. On `Err(trap)` the PC and all architectural state are exactly as before —
    /// the faulting instruction's raw `Trap` is surfaced, not vectored through mtvec. The
    /// run loop layers delivery on top; this is the primitive tests use to inspect a raw
    /// trap or prove execute-purity.
    pub fn step(&mut self) -> Result<(), hart::Trap> {
        self.hart.step(&mut self.bus)
    }

    /// If HTIF is armed and `tohost` currently requests exit, the exit code; else `None`.
    /// A read-only peek for trace loops (does not affect the "logged once" command watch).
    pub fn htif_exit(&mut self) -> Option<u64> {
        let htif = self.htif?;
        match htif.check(&mut self.bus) {
            HtifStatus::Exit(e) => Some(e.code),
            _ => None,
        }
    }

    /// Step up to `max_instrs` instructions, consulting HTIF after each. Returns
    /// on the first guest exit, the first escaping trap, or after exactly
    /// `max_instrs` retirements — whichever comes first.
    ///
    /// Selects the private unit retirement capture through the ordinary/cached dispatch below.
    pub fn run(&mut self, max_instrs: u64) -> RunOutcome {
        self.run_with_capture::<trace::NullSink>(max_instrs, RunCapture::Unit)
    }

    /// E1-T12: mirror the CLINT interrupt LEVELS into `mip`. MTIP (bit 7) tracks
    /// `mtime >= mtimecmp` and MSIP (bit 3) tracks `msip` — device-owned bits software cannot
    /// set. A no-op when no CLINT is attached.
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(always)]
    fn sync_clint(&mut self) {
        if let Some(clint) = &self.clint {
            let s = *clint.borrow();
            self.hart.csr.set_mip_bit(7, s.mtip()); // MTIP
            self.hart.csr.set_mip_bit(3, s.msip); // MSIP
            // E1-T14: the unprivileged `time` counter is a window onto the CLINT mtime — refresh
            // its shadow each instruction boundary so `rdtime` tracks the deterministic clock.
            self.hart.csr.set_time(s.mtime);
        }
    }

    /// E1-T13: mirror the PLIC external-interrupt levels into `mip`: MEIP (bit 11) from the
    /// M-mode context (0), SEIP (bit 9) from the S-mode context (1) — device-owned bits. A no-op
    /// when no PLIC is attached.
    ///
    /// SIMPLIFICATION: strictly, `mip.SEIP` is `software_SEIP | controller_SEIP` (Priv §3.1.9) —
    /// SEIP is writable by M-mode (E1-T11 keeps bit 9 in `MIP_SW_WMASK`) AND driven by the
    /// interrupt controller. Here the PLIC OWNS the S-external line, so we OVERWRITE SEIP with the
    /// controller signal rather than OR-ing it with a software-injected bit. Every PLIC-driven
    /// guest (OpenSBI/Linux) drives SEIP through the controller, so this changes no real flow; a
    /// full OR would matter only for a guest that injects SEIP via `csrs mip` while also using the
    /// PLIC, which does not occur in this system. (MEIP is not software-writable, so it has no such
    /// interaction.)
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(always)]
    fn sync_plic(&mut self) {
        if let Some(plic) = &self.plic {
            let s = plic.borrow();
            let meip = s.eip(0);
            let seip = s.eip(1);
            drop(s);
            self.hart.csr.set_mip_bit(11, meip); // MEIP ← M context
            self.hart.csr.set_mip_bit(9, seip); // SEIP ← S context (see SIMPLIFICATION above)
        }
    }

    /// E2-T05: derive `mip.STIP` from the built-in-SBI timer deadline — a LEVEL, exactly
    /// like MTIP: `STIP = (mtime >= stimecmp)`. Re-evaluated every boundary, so a
    /// `set_timer` in the past fires at the NEXT boundary, a future deadline CLEARS a
    /// pending STIP before the guest runs another instruction (the spec's "clears the
    /// pending timer interrupt" clause), and `u64::MAX` never fires. A no-op unless the
    /// built-in SBI is enabled and a CLINT provides `mtime`.
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(always)]
    fn sync_sbi_timer(&mut self) {
        if self.builtin_sbi
            && let Some(clint) = &self.clint
        {
            let mtime = clint.borrow().mtime;
            self.hart
                .csr
                .set_mip_bit(5, mtime >= self.sbi_state.stimecmp); // STIP
        }
    }

    /// E1-T12/E4-T31: advance `mtime` for `retired` instructions in one exact span. `u128`
    /// arithmetic preserves the sub-`clock_div` residue without overflowing when a large host run
    /// budget is supplied. A no-op in wall-clock mode or when no CLINT is attached.
    #[cfg(not(feature = "zicsr-stub"))]
    fn advance_clock_by(&mut self, retired: u64) {
        // E4-T24: in WallClock mode `mtime` is host-derived and recomputed at the block boundary
        // (`sample_wall_clock`), so the retire count must NOT drive it. Default (ICount) path below is
        // byte-identical to the legacy retire clock.
        if self.wall_time.is_some() {
            return;
        }
        if let Some(clint) = &self.clint {
            let divisor = self.clock_div.max(1);
            // A span whose residue sum fits in u64 (every realistic one) divides in hardware; the
            // quotient/remainder are identical to the u128 form kept for the overflow edge.
            let (ticks, residue) = match self.tick_accum.checked_add(retired) {
                Some(total) => (total / divisor, total % divisor),
                None => {
                    let total = u128::from(self.tick_accum) + u128::from(retired);
                    let divisor = u128::from(divisor);
                    // Casting truncates modulo 2^64, which is exactly the value a wrapping u64
                    // mtime addition observes even for the theoretical `u64::MAX` run-budget edge.
                    ((total / divisor) as u64, (total % divisor) as u64)
                }
            };
            self.tick_accum = residue;
            if ticks != 0 {
                let mut s = clint.borrow_mut();
                s.mtime = s.mtime.wrapping_add(ticks);
            }
        }
    }

    /// The one-instruction interpreter wrapper around [`Self::advance_clock_by`], run after every
    /// interpreted retirement. With the sub-tick residue below the divider (the invariant every
    /// setter maintains) one retirement yields exactly `(tick_accum + 1 == clock_div)` ticks, so
    /// the hot path is an add and a compare — the identical `mtime`/`tick_accum` sequence as the
    /// `u128` division, which remains the fallback for any out-of-invariant restored residue.
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(always)]
    fn advance_clock(&mut self) {
        if self.wall_time.is_some() {
            return;
        }
        let Some(clint) = &self.clint else { return };
        if self.tick_accum < self.clock_div {
            // Branch-free: the tick lands on one retirement in `clock_div`, a period the branch
            // predictor cannot learn through the interpreter's own branches.
            let next = self.tick_accum + 1;
            let tick = next == self.clock_div;
            self.tick_accum = if tick { 0 } else { next };
            let mut s = clint.borrow_mut();
            s.mtime = s.mtime.wrapping_add(u64::from(tick));
        } else {
            self.advance_clock_by(1);
        }
    }

    /// E4-T24: recompute `mtime` from the injected host wall clock at a block boundary — the ONE place
    /// wall-derived `mtime` is produced, so CLINT reads, mtimecmp scheduling, and SBI-time queries all
    /// see a single clamped-monotone value. Applies the [`time::TimeSource`] clamp + slew + jump
    /// policy; a documented suspend/resume jump is stashed in [`Self::last_time_jump`]. A no-op unless
    /// wall-clock mode is armed (default ICount path never enters here).
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(always)]
    fn sample_wall_clock(&mut self) {
        // ICount mode (the default) never samples: one test, inlined at every boundary.
        if self.wall_time.is_some() {
            self.sample_wall_clock_now();
        }
    }

    /// The WallClock-mode body of [`Self::sample_wall_clock`].
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(never)]
    fn sample_wall_clock_now(&mut self) {
        let (Some(ts), Some(clock), Some(clint)) =
            (&mut self.wall_time, &self.mono_clock, &self.clint)
        else {
            return;
        };
        let host_ns = clock.now_nanos();
        let current = clint.borrow().mtime;
        let (mtime, jump) = ts.sample_wall(host_ns, current);
        clint.borrow_mut().mtime = mtime;
        if let Some(j) = jump {
            self.last_time_jump = Some(j);
        }
    }

    /// E4-T24: switch `mtime` to WallClock mode — host-wall-derived (scaled to the DT timebase) with
    /// the monotonicity-clamp + slew + jump policy — driven by the injected monotonic `clock`. Requires
    /// a CLINT (the `mtime` register lives there). Off by default: the deterministic ICount clock is
    /// what the lockstep/determinism gates depend on.
    #[cfg(not(feature = "zicsr-stub"))]
    pub fn set_wall_clock(
        &mut self,
        clock: alloc::boxed::Box<dyn time::MonotonicClock>,
        policy: time::WallClockPolicy,
    ) {
        let mut ts =
            time::TimeSource::wall_clock(u64::from(platform::virt::TIMEBASE_FREQ_HZ), policy);
        // Seed the monotone floor from the current mtime so the clock can't be dragged backward.
        if let Some(clint) = &self.clint {
            ts.sync_floor(clint.borrow().mtime);
        }
        self.wall_time = Some(ts);
        self.idle_pacer = None;
        self.mono_clock = Some(clock);
        self.rebase_guest_clock();
    }

    /// The selected guest timer policy (host state, deliberately absent from resume wire data).
    pub fn guest_clock_mode(&self) -> time::TimeMode {
        if self.wall_time.is_some() {
            time::TimeMode::WallClock
        } else if self.idle_pacer.is_some() {
            time::TimeMode::PacedICount
        } else {
            time::TimeMode::ICount
        }
    }

    /// Keep retire-derived busy time, but prevent idle jumps from outrunning host input.
    /// Selection is explicit and preserves guest time, deadlines and the sub-tick phase.
    #[cfg(not(feature = "zicsr-stub"))]
    pub fn set_paced_icount_clock(
        &mut self,
        clock: alloc::boxed::Box<dyn time::MonotonicClock>,
    ) -> Result<(), &'static str> {
        let mtime = self
            .clint
            .as_ref()
            .ok_or("paced ICount requires an attached CLINT")?
            .borrow()
            .mtime;
        if self.clock_div == 0 || self.tick_accum >= self.clock_div {
            return Err("paced ICount requires a valid saved clock phase");
        }
        let pacer = time::IdlePacer::new(
            clock.now_nanos(),
            mtime,
            u64::from(platform::virt::TIMEBASE_FREQ_HZ),
        );
        self.wall_time = None;
        self.idle_pacer = Some(pacer);
        self.mono_clock = Some(clock);
        self.last_time_jump = None;
        Ok(())
    }

    /// Retirements per tick in ICount mode; retained, but inactive, in wall mode.
    pub fn guest_clock_div(&self) -> u64 {
        self.clock_div
    }

    /// Select an explicit deterministic timer rate without replacing the CLINT or advancing time.
    /// Fractional progress toward the next tick is conservatively quantized to the new divisor.
    /// Host configuration only: the existing resume clock section already stores both fields.
    pub fn set_icount_divider(&mut self, divider: u64) -> Result<(), &'static str> {
        if !(1..=1024).contains(&divider) {
            return Err("ICount divider must be an integer from 1 to 1024");
        }
        if self.clint.is_none() {
            return Err("ICount divider requires an attached CLINT");
        }
        if self.wall_time.is_some() || self.idle_pacer.is_some() {
            return Err("ICount divider requires ICount mode");
        }
        if self.clock_div == 0 || self.tick_accum >= self.clock_div {
            return Err("ICount divider requires a valid saved clock phase");
        }
        if divider == self.clock_div {
            return Ok(());
        }
        let phase = u128::from(self.tick_accum) * u128::from(divider) / u128::from(self.clock_div);
        self.tick_accum = phase as u64;
        self.clock_div = divider;
        Ok(())
    }

    /// Freeze elapsed host time across an explicit pause or a successful snapshot restore.
    /// Does not change guest mtime, deadlines, ICount phase, or policy. Ordinary worker/background
    /// gaps must NOT call this: they keep the existing clamp/slew/jump behavior.
    #[cfg(not(feature = "zicsr-stub"))]
    pub fn rebase_guest_clock(&mut self) {
        if let (Some(ts), Some(clock), Some(clint)) =
            (&mut self.wall_time, &self.mono_clock, &self.clint)
        {
            ts.rebase_wall(clock.now_nanos(), clint.borrow().mtime);
            self.last_time_jump = None;
        }
        if let (Some(pacer), Some(clock), Some(clint)) =
            (&mut self.idle_pacer, &self.mono_clock, &self.clint)
        {
            pacer.rebase(clock.now_nanos(), clint.borrow().mtime);
            self.last_time_jump = None;
        }
    }

    /// E4-T24: revert to the deterministic ICount clock (retire-derived `mtime`).
    pub fn set_icount_clock(&mut self) {
        self.wall_time = None;
        self.idle_pacer = None;
        self.mono_clock = None;
        self.last_time_jump = None;
    }

    /// E4-T24: take the last discontinuous `mtime` jump (suspend/resume exception), if any — the host
    /// surfaces it and the guest resyncs from the RTC.
    pub fn take_time_jump(&mut self) -> Option<time::TimeJump> {
        self.last_time_jump.take()
    }

    /// E2-T23b: deterministic idle fast-forward ("tickless idle"). Called right after a `WFI`
    /// retires with no interrupt pending (the boundary's `next_interrupt()` returned `None`).
    /// Without this, an idle/sleeping guest spins `WFI`, and because `mtime` is the retire-count
    /// clock it advances only one tick per `clock_div` WFI retirements — so a guest `sleep`
    /// burns `deadline_ticks * clock_div` instructions of pure spin (≈20× real time in the slow
    /// browser interpreter). Instead, jump `mtime` straight to the nearest armed timer deadline
    /// (machine `mtimecmp` or the SBI S-timer `stimecmp`), so the timer fires on the very next
    /// boundary and the guest wakes immediately in wall-clock terms.
    ///
    /// This preserves determinism: the jump is a pure function of machine state
    /// (`mtime`, `mtimecmp`, `stimecmp`) with no host clock, so native and wasm fast-forward by
    /// the identical amount and the timer still lands at the same retire index on both. Only the
    /// *number of idle spin retirements* shrinks; the guest-visible `mtime` reaches the same
    /// deadline it would have, just without the spin. When no timer is armed (a genuine deadlock,
    /// caught by [`Self::wfi_watchdog_check`]) there is no deadline to jump to and this is a no-op.
    #[cfg(not(feature = "zicsr-stub"))]
    fn wfi_fast_forward(&mut self) {
        // E4-T24: the idle fast-forward jumps `mtime` to the next timer deadline — a determinism-
        // preserving ICount trick. In WallClock mode `mtime` IS real time, so a `sleep` must actually
        // wait; jumping would make it return early. Let the wall clock advance mtime instead.
        if self.wall_time.is_some() {
            return;
        }
        let Some(clint) = &self.clint else { return };
        // Sweep-critic (E2-T23b LOW): a pending+enabled interrupt (mip & mie != 0) satisfies
        // the WFI wake condition RIGHT NOW (per the ISA, even with global xIE=0) — no time
        // needs to pass, so jumping mtime to a timer deadline would be a semantic time
        // distortion. Skip the jump; the WFI retires as a nop and execution proceeds.
        if self.hart.csr.mip_and_mie_nonzero() {
            return;
        }
        // Nearest armed FUTURE deadline. A deadline already <= mtime is "due" — its interrupt is
        // pending and WFI wakes next boundary anyway, so there is nothing to skip. `u64::MAX` is
        // the "cancelled" sentinel for both compares.
        let mut deadline: Option<u64> = None;
        let mtime = {
            let c = clint.borrow();
            if c.mtimecmp != u64::MAX && c.mtimecmp > c.mtime {
                deadline = Some(c.mtimecmp);
            }
            c.mtime
        };
        let stimecmp = self.sbi_state.stimecmp;
        if stimecmp != u64::MAX && stimecmp > mtime {
            deadline = Some(deadline.map_or(stimecmp, |d| d.min(stimecmp)));
        }
        if let Some(d) = deadline {
            let d = match (&mut self.idle_pacer, &self.mono_clock) {
                (Some(pacer), Some(clock)) => pacer.limit_deadline(clock.now_nanos(), mtime, d),
                _ => d,
            };
            // Jump the machine clock to the deadline; next boundary re-evaluates MTIP/STIP as a
            // level (mtime >= cmp) and delivers the timer. tick_accum (sub-tick remainder from
            // retirements) is left untouched — whole-tick jumps are independent of the divider.
            clint.borrow_mut().mtime = d;
        }
    }

    /// Whether a network backend is waiting on an event that only the host can deliver between
    /// execution chunks. Fast-forwarding WFI to a guest timer deadline in this state can make a
    /// socket timeout fire before the browser gets a chance to run its WebSocket callback.
    #[cfg(not(feature = "zicsr-stub"))]
    fn external_net_io_pending(&self) -> bool {
        self.net
            .as_ref()
            .is_some_and(|(state, _, _)| state.borrow().backend.external_io_pending())
    }

    /// Browser GPU fences and retained scanout receipts complete between CPU
    /// chunks. Tickless idle must not turn that wait into an immediate timeout.
    #[cfg(not(feature = "zicsr-stub"))]
    fn external_gpu_io_pending(&self) -> bool {
        #[cfg(feature = "virgl-renderer")]
        {
            self.gpu
                .as_ref()
                .is_some_and(|(state, _, _, _)| state.borrow().external_renderer_io_pending())
        }
        #[cfg(not(feature = "virgl-renderer"))]
        false
    }

    /// Original keyboard breaks arrive between host execution chunks. Skipping
    /// directly to a repeat timer before that turn would manufacture a long
    /// guest key hold from a short physical press.
    #[cfg(not(feature = "zicsr-stub"))]
    fn external_keyboard_io_pending(&self) -> bool {
        self.keyboard
            .as_ref()
            .is_some_and(|(state, _, _)| state.borrow().awaiting_host_key_release())
    }

    /// E2-T20: run the sliding-window interrupt-storm detector. Called only when a trap lands
    /// (event-driven, so zero cost while quiet — a trap during normal operation is rare, and
    /// during a storm the detector is exactly what we want running). Syncs the PLIC claim
    /// counters in, then checks for `>5000 traps / 10^6 retired` sustained over 3 windows.
    #[cfg(not(feature = "zicsr-stub"))]
    fn storm_check(&mut self) {
        if !self.storm_detect {
            return;
        }
        // Called only when a trap lands (interrupt or exception), so this runs a few thousand
        // times over a whole boot — cheap to sync the 32-entry PLIC claim vector so the storm's
        // per-window "hot line" naming is current (critic #2). check_storm itself is a rate
        // compare that does real work only when a 10^6-retired window closes.
        if let Some(plic) = &self.plic {
            self.irqstats.claims = *plic.borrow().claim_counts();
        }
        if let Some(r) = self.irqstats.check_storm(1_000_000, 5_000, 3) {
            let hot = match r.hot_irq {
                Some((id, n)) => alloc::format!("hottest PLIC irq {id} ({n} claims this window)"),
                None => alloc::string::String::from("no external PLIC irq is hot"),
            };
            log::warn!(
                "E2-T20 INTERRUPT STORM: {} traps in {} retired instrs — {hot}\n{}",
                r.window_traps,
                r.window_retired,
                self.irqstats.dump(),
            );
        }
    }

    /// E2-T20: the WFI-deadlock watchdog. Called right after a `WFI` retires; if no wakeup can
    /// ever arrive (nothing pending+enabled in `mip`&`mie`, no armed timer deadline), the guest
    /// will idle forever — report it once instead of spinning silently.
    #[cfg(not(feature = "zicsr-stub"))]
    fn wfi_watchdog_check(&mut self) {
        if !self.storm_detect {
            return;
        }
        let armed = self.any_wakeup_armed();
        if let Some(msg) = self.irqstats.wfi_watchdog(true, armed) {
            log::warn!("E2-T20 {msg}\n{}", self.irqstats.dump());
        }
    }

    /// E2-T20: could any interrupt ever wake a WFI? True if something is already pending AND
    /// enabled (`mip & mie != 0` — this already reflects a PLIC line held high, which
    /// `sync_plic` mirrors into `mip.SEIP`), OR a timer deadline is armed in the future (CLINT
    /// `mtimecmp` or the SBI S-timer `stimecmp` below `u64::MAX`) — a future deadline is not in
    /// `mip` yet but WILL fire, so it counts as an armed wakeup.
    #[cfg(not(feature = "zicsr-stub"))]
    fn any_wakeup_armed(&self) -> bool {
        if self.hart.csr.mip_and_mie_nonzero() {
            return true;
        }
        // Sweep-critic (E2-T20 BUG 2): a wakeup source only counts if it is DELIVERABLE — an
        // armed mtimecmp with MTIE=0 (or msip with MSIE=0) can never end the WFI loop under
        // our semantics, which is exactly the deadlock the watchdog exists to report. Gate
        // each CLINT source on its mie enable bit (stimecmp rides the S-timer → STIE, bit 5).
        let mie = self.hart.csr.mie_bits();
        if self.sbi_state.stimecmp != u64::MAX && mie & (1 << 5) != 0 {
            return true;
        }
        if let Some(clint) = &self.clint {
            let c = clint.borrow();
            return (c.mtimecmp != u64::MAX && mie & (1 << 7) != 0)
                || (c.msip && mie & (1 << 3) != 0);
        }
        false
    }

    /// Open one host cooperative-execution scope around one or more [`Self::run_traced`] calls.
    /// Browser `WasmLinux::runChunk` uses this because it may split one JS-visible quantum into
    /// several internal UART/persistence runs; all of them must share one aggregate synchronous JIT
    /// submission budget. Ordinary callers need not use this API: an unscoped `run_traced` call opens
    /// and closes its own scope automatically.
    pub fn begin_cooperative_run(&mut self) {
        #[cfg(not(feature = "zicsr-stub"))]
        self.begin_cooperative_run_mode(true);
    }

    #[cfg(not(feature = "zicsr-stub"))]
    fn begin_cooperative_run_mode(&mut self, external: bool) {
        #[cfg(not(feature = "zicsr-stub"))]
        {
            assert!(
                !self.jit_run_scope_active,
                "cooperative run scopes must not nest"
            );
            self.jit_run_scope_active = true;
            self.jit_run_scope_external = external;
            self.jit_run_submissions_before = self.prof.jit_pause().total_submitted_blocks;
            self.jit_run_staged_nominations = 0;
            self.jit_run_attempted_blocks = 0;
            self.jit_run_final_pumps = 0;
            self.jit_run_final_attempted_blocks = 0;
            self.jit_run_final_submitted_blocks = 0;
            self.jit_run_attempt_remaining = if self.jit_enabled {
                self.executor
                    .as_ref()
                    .map(|exec| exec.max_translation_attempts_per_run())
                    .unwrap_or(0)
            } else {
                0
            };
            self.jit_run_staging_remaining = if self.jit_enabled {
                self.executor
                    .as_ref()
                    .map(|exec| exec.max_staged_nominations_per_run())
                    .unwrap_or(0)
            } else {
                0
            };
        }
    }

    /// Close a scope opened by [`Self::begin_cooperative_run`] and publish its aggregate compile
    /// counters. Panics on mismatched calls: silently resetting a live scope would reopen the exact
    /// unbounded-per-`runChunk` bug this boundary exists to prevent.
    pub fn end_cooperative_run(&mut self, _outcome: RunOutcome) {
        #[cfg(not(feature = "zicsr-stub"))]
        {
            assert!(
                self.jit_run_scope_active,
                "no cooperative run scope is active"
            );
            // Only host-visible completion boundaries get a final pump. Internal UART/persistence
            // sub-runs do not flush independently, and a host-owned terminal scope preserves its
            // backlog for a later quantum. An escaped trap can still be resumed after the host
            // repairs the faulting state, so publish that warmed translation for the precise-fault
            // path. An ordinary unscoped run also flushes on a normal exit so short programs can
            // prove their compiled path before returning. The final pump sits outside run_traced's
            // timer, so explicitly fold its measured pause into total_ns.
            let terminal_exit_flush =
                !self.jit_run_scope_external && matches!(_outcome, RunOutcome::Exited(_));
            if self.jit_enabled
                && (matches!(_outcome, RunOutcome::MaxInstrs | RunOutcome::Trapped(_))
                    || terminal_exit_flush)
                && self.jit_run_attempt_remaining > 0
                && (!self.compile_queue.is_empty()
                    || (self.jit_run_staging_remaining > 0 && self.discovery.queue_len() > 0))
            {
                self.jit_pump_ticks = 0;
                let pause_before = self.prof.jit_pause().sum_ns;
                self.jit_run_final_pumps = 1;
                let (attempted, submitted) = self.pump_jit_translations();
                self.jit_run_final_attempted_blocks = attempted as u64;
                self.jit_run_final_submitted_blocks = submitted as u64;
                let final_pause_ns = self.prof.jit_pause().sum_ns.saturating_sub(pause_before);
                if self.profiling {
                    self.prof_total_ns = self.prof_total_ns.saturating_add(final_pause_ns);
                }
            }
            if self.jit_enabled {
                let submitted = self
                    .prof
                    .jit_pause()
                    .total_submitted_blocks
                    .saturating_sub(self.jit_run_submissions_before);
                self.prof.record_jit_run(
                    self.jit_run_attempted_blocks,
                    submitted,
                    self.jit_run_staged_nominations,
                    self.jit_run_final_pumps,
                    self.jit_run_final_attempted_blocks,
                    self.jit_run_final_submitted_blocks,
                );
            }
            self.jit_run_scope_active = false;
            self.jit_run_scope_external = false;
            self.jit_run_attempt_remaining = 0;
            self.jit_run_staging_remaining = 0;
        }
    }

    /// Like [`Self::run`], but feeds every retired instruction to `sink` (E0-T18's
    /// `--trace`). Termination and the "logged once" HTIF command watch are identical to
    /// `run` — the ONE place the run-loop / HTIF state machine lives, so a traced run and
    /// an untraced run can never diverge in when they stop.
    /// Run up to `max_instrs`, timing the total profiled wall-span ONCE at entry and ONCE at exit
    /// (E4-T01 phase 3) — never inside the loop. When profiling is armed with a host timer, the
    /// entry→exit delta accumulates into `prof_total_ns`, the span CPU-interp time is later derived
    /// from by subtraction. The `_inner` body holds the actual loop and is untouched by profiling.
    pub fn run_traced<T: trace::TraceSink>(&mut self, max_instrs: u64, sink: &mut T) -> RunOutcome {
        self.run_with_capture(max_instrs, RunCapture::Traced(sink))
    }

    fn run_with_capture<T: trace::TraceSink>(
        &mut self,
        max_instrs: u64,
        mut capture: RunCapture<'_, T>,
    ) -> RunOutcome {
        // One timer read at entry (cold, once per run) — only when profiling armed with a timer.
        let t0 = if self.profiling {
            self.host_timer.as_ref().map(|t| t.now_ns())
        } else {
            None
        };
        #[cfg(not(feature = "zicsr-stub"))]
        let owns_cooperative_scope = !self.jit_run_scope_active;
        #[cfg(not(feature = "zicsr-stub"))]
        if owns_cooperative_scope {
            self.begin_cooperative_run_mode(false);
        }
        let outcome = self.run_capture_inner(max_instrs, &mut capture);
        // One timer read at exit; accumulate the total profiled span. The device+walk time timed on
        // the cold paths is a SUBSET of this span, so `total − (device + walk)` is the interpreter's.
        if let (Some(t0), Some(t)) = (t0, self.host_timer.as_ref()) {
            self.prof_total_ns = self
                .prof_total_ns
                .saturating_add(t.now_ns().saturating_sub(t0));
        }
        #[cfg(not(feature = "zicsr-stub"))]
        if owns_cooperative_scope {
            self.end_cooperative_run(outcome);
        }
        outcome
    }

    /// E4-T05 Phase A: execute EXACTLY ONE instruction using the predecoded block cache,
    /// returning the SAME `Result<(), Trap>` contract as [`Hart::step_traced`]. It replays a
    /// memoized micro-op instead of re-fetching/decoding, but performs the identical
    /// architectural sequence — counter arm, execute-trigger check, `execute`, `retire_tick`,
    /// retire hook — so the retire trace is byte-identical to the legacy path. Only decode is
    /// memoized. Called once per outer-loop iteration, so the loop's per-op device sync +
    /// interrupt sampling stay per-retire (interrupt batching is Phase C).
    #[cfg(not(feature = "zicsr-stub"))]
    fn step_cached_with_capture<C: hart::RetirementCapture>(
        &mut self,
        capture: C,
    ) -> Result<(), Trap> {
        // Same ordering as `step_traced`: arm counters, then the execute-address trigger check,
        // BEFORE obtaining the instruction.
        self.hart.csr.arm_counters();
        let pc = self.hart.regs.pc;
        if !self.hart.csr.triggers_idle()
            && self
                .hart
                .csr
                .trigger_fires(pc, crate::csr::TrigKind::Execute)
        {
            return Err(Trap {
                cause: hart::Exception::Breakpoint,
                tval: pc,
            });
        }
        // Fetch the micro-op: a cursor hit replays a cached op with NO re-translation. Page-table
        // permissions stay valid for that page until SFENCE.VMA, while an effective PMP change
        // bumps its revision and flushes this cursor at the next block boundary. A miss (re)builds
        // the block at pc's physical address, reproducing any fetch/decode trap.
        let op = self.next_micro_op(pc)?;
        self.retire_cached_op(&op, pc, capture, false)
    }

    /// The execute-and-retire half of [`Self::step_cached_with_capture`] for an op already taken
    /// from the block cursor: execute, tick the counters, record the retirement, then keep the
    /// fetch stream coherent (`fence.i` note + page-granular drain of any code-page store). Shared
    /// verbatim by the one-op step and the mid-block replay loop ([`Self::replay_block_tail`]).
    ///
    /// `defer` (only for a [`dispatch::retire_deferrable`] op, only from the replay loop) leaves
    /// the counter tick to the caller's bulk settle and skips the fetch-coherence tail: such an op
    /// is not `fence.i` and never reaches the bus, so the write log it would drain is still the
    /// empty log the previous op's drain left.
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(always)]
    fn retire_cached_op<C: hart::RetirementCapture>(
        &mut self,
        op: &dispatch::MicroOp,
        pc: u64,
        mut capture: C,
        defer: bool,
    ) -> Result<(), Trap> {
        if defer {
            debug_assert!(dispatch::retire_deferrable(&op.instr));
            debug_assert!(self.bus.code_write_log_mut().is_empty());
            // The decoded block has already classified this as a pure integer op. Inline its
            // shared semantics into replay without entering the general executor's bus/trap path.
            let (rd, value) = self
                .hart
                .integer_result(op.instr)
                .expect("deferred operations have pure integer semantics");
            self.hart.regs.write(rd, value);
            self.hart.regs.pc = pc.wrapping_add(u64::from(op.len));
            let output = capture.finish(rd, value);
            capture.retire(output, pc, op.raw);
            return Ok(());
        }
        let output = self.hart.execute(
            &mut self.bus,
            op.instr,
            u64::from(op.len),
            u64::from(op.raw),
            &mut capture,
        )?;
        self.hart.csr.retire_tick();
        capture.retire(output, pc, op.raw);
        // E4-T17 page-granular invalidation (supersedes E4-T16's conservative fence.i flush):
        //  - a store (this op's `mem.is_store`, incl. SC/AMO) reached RAM via the bus, which
        //    recorded its physical frame(s). Drain that log through PAGE-GRANULAR invalidation:
        //    only a store into a frame that actually holds cached code drops blocks (and the
        //    cursor). Ordinary data stores are set-misses → the cache is RETAINED.
        //  - `fence.i` is now NEAR-FREE: it drops NO blocks. Every code-writing store already
        //    invalidated its physical page eagerly at store time (the drain below fires per retire),
        //    so by the time `fence.i` retires the fetch stream is already coherent — RISC-V permits
        //    (indeed this is a valid icache-less implementation), and un-dirtied pages' blocks
        //    SURVIVE the fence (the E4-T16 whole-cache flush no longer fires). We only note the event
        //    and clear the cursor (a terminator ends the block); the drain still runs to sweep any
        //    frame written but not yet drained (a `fence.i`-adjacent host/DMA poke).
        if matches!(op.instr, crate::decode::Instr::FenceI) {
            self.block_cache.note_fence_i();
            self.block_cursor = None;
        }
        self.drain_code_writes();
        Ok(())
    }

    /// E4-T05 Phase B: drain the bus's physical-frame write log (guest stores AND device/DMA
    /// writes — both reach RAM through the same physical `store*`) into the block cache's
    /// page-granular invalidation. If any drained frame held cached code, the in-flight block
    /// cursor may point into a just-dropped block, so it is reset (conservative-safe — a
    /// spurious reset only costs a rebuild). Cheap when the log is empty (the common case).
    /// Returns whether a code page was flushed (and so the cursor was reset).
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(always)]
    fn drain_code_writes(&mut self) -> bool {
        // Hot path (after every retire): an empty log — no store since the last drain — is one
        // length test, and a single logged frame that provably holds no cached code (the block
        // cache's presence filter; `flush_page` would miss) is dropped inline. Anything else takes
        // the out-of-line page-invalidation walk.
        if self.block_cache_enabled {
            let log = self.bus.code_write_log_mut();
            match log.len() {
                0 => false,
                1 if !self.block_cache.may_hold_code(log[0]) => {
                    log.clear();
                    false
                }
                _ => self.drain_code_writes_slow(),
            }
        } else {
            false
        }
    }

    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(never)]
    fn drain_code_writes_slow(&mut self) -> bool {
        // Disjoint borrows: drain the bus log while page-invalidating the cache.
        let Self {
            bus,
            block_cache,
            block_cursor,
            discovery,
            executor,
            ..
        } = self;
        let log = bus.code_write_log_mut();
        if log.is_empty() {
            return false;
        }
        let mut flushed = false;
        for &frame in log.iter() {
            if block_cache.flush_page(frame) {
                flushed = true;
                // E4-T10: the SMC / DMA-into-code store dropped this frame's cached blocks — drop
                // the matching compiled blocks so the executor recompiles from the new bytes.
                if let Some(e) = executor.as_mut() {
                    e.invalidate_page(frame);
                }
            }
        }
        log.clear();
        if flushed {
            *block_cursor = None;
            // E4-T08: a store landed on a code page (SMC / DMA-into-code) and dropped ≥1 cached
            // block. Bump the discovery generation so any pending request for the overwritten bytes
            // is dropped at install time and the re-decoded block re-nominates fresh.
            discovery.on_invalidate();
        }
        flushed
    }

    /// E4-T05: return the [`MicroOp`](dispatch::MicroOp) to execute at virtual address `pc`,
    /// serving it from the block cache. A valid cursor (same expected VA, block still live)
    /// replays the next cached op with no translation; otherwise the block at `pc` is (re)built
    /// by walking [`Hart::decode_at`] to the first terminator / page boundary / 128-op cap. On a
    /// fetch/decode fault the precise trap is returned (identical to the legacy path).
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(always)]
    fn next_micro_op(&mut self, pc: u64) -> Result<dispatch::MicroOp, Trap> {
        // Fast path: continue the block we are mid-replay of. The cursor holds the block, which
        // is still cache-resident (every live-block drop clears the cursor), so this is exactly
        // the former `block_cache.get(key)` hit with no probe. Inlined into the interpreter loop;
        // block entry (translate + cache lookup / build) stays out of line.
        if let Some(cursor) = &mut self.block_cursor
            && cursor.next_va == pc
            && let Some(op) = cursor.block.ops.get(cursor.idx).copied()
        {
            cursor.idx += 1;
            cursor.next_va = pc.wrapping_add(u64::from(op.len));
            return Ok(op);
        }
        self.enter_block(pc)
    }

    /// The block-ENTRY half of [`Self::next_micro_op`]: the cursor missed, so re-key by physical
    /// PC — reuse the cached block at `pc`'s physical address or walk and insert a fresh one.
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(never)]
    fn enter_block(&mut self, pc: u64) -> Result<dispatch::MicroOp, Trap> {
        self.block_cursor = None;

        // A device/DMA write can land between host run chunks, before any guest instruction gets
        // the usual post-retire drain. Sweep that log at the boundary before an entry-cache hit so
        // the first instruction after resume cannot execute stale code. Guest stores are already
        // drained after their own retirement; the common boundary path only observes an empty log.
        self.drain_code_writes();

        // E4-T30: translate + PMP-check the CURRENT entry before consulting physically-keyed code.
        // This preserves execute-permission faults after a cached hit and fills the same TLB entry
        // `decode_at` uses. The old path decoded first and then unconditionally rebuilt/reinserted
        // the whole block at every branch target, making the "cache" ~4.7x slower on a hot loop.
        let phys = self.hart.fetch_phys(&mut self.bus, pc)?;

        // Entry hit: reuse the cached first op and resume its cursor. Discovery MUST still observe
        // every entry — otherwise a cache hit would prevent the JIT hotness counter reaching its
        // threshold. SMC/DMA writes already remove the whole physical page before this lookup.
        if let Some(block) = self.block_cache.get_rc_touch(phys)
            && let Some(first) = block.ops.first().copied()
        {
            self.discovery
                .on_block_entry_memo(phys, &block.ops, &block.disc);
            self.block_cursor = Some(BlockCursor {
                block,
                idx: 1,
                next_va: pc.wrapping_add(u64::from(first.len)),
            });
            self.block_entry_hits = self.block_entry_hits.saturating_add(1);
            return Ok(first);
        }

        // Miss: decode through the single shared decoder, then walk and insert exactly as before.
        // `fetch_phys` above populated/checked the TLB, so this first decode's translation is a hit.
        let first = self.hart.decode_at(&mut self.bus, pc)?;
        self.block_builds = self.block_builds.saturating_add(1);

        // An entry op that straddles a physical page cannot live in a page-bounded block; run it
        // uncached (byte-identical — `decode_at` already did the split fetch). Cursor stays None.
        let page_off = pc & (dispatch::PAGE - 1);
        if page_off + u64::from(first.len) > dispatch::PAGE {
            return Ok(first);
        }

        // Walk contiguous ops within this physical page to the first terminator / page edge / cap.
        let mut ops = alloc::vec::Vec::with_capacity(8);
        let mut total_len = u64::from(first.len);
        ops.push(first);
        let page_base = pc & !(dispatch::PAGE - 1);
        if !dispatch::is_terminator(&first.instr) {
            let mut va = pc.wrapping_add(u64::from(first.len));
            while ops.len() < dispatch::MAX_BLOCK_OPS {
                // Stop if the next op would begin in a different physical page.
                if (va & !(dispatch::PAGE - 1)) != page_base {
                    break;
                }
                let op = match self.hart.decode_at(&mut self.bus, va) {
                    Ok(op) => op,
                    // A fetch/decode fault ahead ends the block here; it is reproduced precisely
                    // when execution reaches that VA and rebuilds a fresh (trapping) block there.
                    Err(_) => break,
                };
                // An op straddling the page boundary belongs to the next block, not this one.
                if (va & (dispatch::PAGE - 1)) + u64::from(op.len) > dispatch::PAGE {
                    break;
                }
                debug_assert_eq!(
                    va & !(dispatch::PAGE - 1),
                    page_base,
                    "block op must not leave the entry physical page"
                );
                total_len += u64::from(op.len);
                let is_term = dispatch::is_terminator(&op.instr);
                ops.push(op);
                if is_term {
                    break;
                }
                va = va.wrapping_add(u64::from(op.len));
            }
        }

        // E4-T08: this is a block ENTRY (a cursor miss re-keyed and rebuilt the block at `phys`).
        // Bump the hotness counter and, on crossing the threshold, nominate a TranslationRequest.
        // Observation-only: it reads the walked ops and mutates only the discovery side-structure,
        // never the executed sequence — so the retire trace is byte-identical (`predecode_diff`).
        let block = dispatch::DecodedBlock::new(phys, ops, total_len);
        self.discovery
            .on_block_entry_memo(phys, &block.ops, &block.disc);
        let (block, evicted) = self.block_cache.insert_rc_evicting(block);
        // A replaced block leaves the cache: fold any queued hits it buffered into discovery.
        if let Some(old) = evicted {
            self.discovery.settle_memo(old.phys_start, &old.disc);
        }
        // Entry op (index 0) is consumed now; the cursor resumes at index 1.
        self.block_cursor = Some(BlockCursor {
            block,
            idx: 1,
            next_va: pc.wrapping_add(u64::from(first.len)),
        });
        Ok(first)
    }

    /// E4-T05 Phase C: is the hart about to execute the ENTRY of a (fresh) basic block, i.e. a
    /// block boundary where interrupts/devices must be re-sampled under batching? True unless the
    /// next step is a live continuation of the block currently being replayed — mirroring exactly
    /// the fast-path hit test in [`Self::next_micro_op`] (same VA, block still cached, op present).
    /// A branch/jump/trap/ecall/WFI (all block terminators) moves the PC off the cursor's expected
    /// VA, so the following step is a boundary and re-syncs — matching the legacy per-op behavior at
    /// every point interrupt-enable state could have changed. Because the answer depends only on the
    /// block structure (terminators / 128-op cap / page edges), never on cache capacity (a block is
    /// never evicted mid-replay by its own straight-line execution), the boundaries — and thus the
    /// interrupt-sampling points — are deterministic across cache sizes.
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline]
    fn at_block_boundary(&self) -> bool {
        let pc = self.hart.regs.pc;
        match &self.block_cursor {
            Some(cursor) if cursor.next_va == pc => cursor.idx >= cursor.block.ops.len(),
            _ => true,
        }
    }

    /// E4-T10: drain the block-discovery FIFO and install compiled blocks. For each nominated
    /// request, the snapshotted bytes are re-validated against LIVE guest memory (the E4-T08
    /// `install_check` — guards SMC/stale between nomination and install); on success the (still
    /// physically-keyed) decoded block is handed to the executor, which translates + compiles +
    /// registers it. Called at block boundaries; cheap when the queue is empty (the common case).
    #[cfg(not(feature = "zicsr-stub"))]
    fn pump_jit_translations(&mut self) -> (usize, usize) {
        use crate::bus::Bus;
        if self.executor.is_none() || self.jit_run_attempt_remaining == 0 {
            return (0, 0);
        }
        if self.compile_queue.is_empty()
            && (self.discovery.queue_len() == 0 || self.jit_run_staging_remaining == 0)
        {
            return (0, 0);
        }
        // Include nomination staging, stale cancellation and backpressure/recount work in the same
        // wall-time pause as validation/compilation. Previously the timer started after an unbounded
        // discovery drain, hiding the very Worker stall this instrumentation is meant to expose.
        let t0 = self.host_timer.as_ref().map(|t| t.now_ns());
        // ── E4-T21: stage discovery's FIFO nominations into the priority compile queue. ──
        // Admit only the aggregate staging budget for this host-visible cooperative run. Remaining
        // FIFO work stays in discovery for later slices, while the priority queue still compiles the
        // hottest admitted block first.
        let staging_budget = self.jit_run_staging_remaining;
        let staged = self.discovery.take_requests_bounded(staging_budget);
        self.jit_run_staging_remaining =
            self.jit_run_staging_remaining.saturating_sub(staged.len());
        self.jit_run_staged_nominations = self
            .jit_run_staged_nominations
            .saturating_add(staged.len() as u64);
        for req in staged {
            let hotness = queued_hotness_of(&self.discovery, &self.block_cache, req.phys_pc);
            self.compile_queue
                .push(compile_queue::CompileJob { req, hotness });
        }
        // Cancellation on generation bump: any job whose generation went stale while it waited is
        // dropped here (a cheap first line of defence; the per-block install_check below is the
        // authoritative one). This models async-with-delay: the world can change under a queued job.
        self.compile_queue.cancel_stale(self.discovery.generation());
        // Recount jobs the queue dropped under backpressure so a still-hot block is re-nominated
        // instead of being suppressed by dedup forever.
        for phys in self.compile_queue.take_recount() {
            self.discovery.renominate(phys);
        }
        // Surviving backlog can accrue interpreted hits across exhausted host budgets, even when
        // this pump staged nothing. Refresh only now; keep admission/cancellation/recount ordering.
        self.compile_queue
            .refresh_hotness(|phys| queued_hotness_of(&self.discovery, &self.block_cache, phys));
        // ── E4-T21: pop the hottest jobs up to the per-boundary INSTALL budget (bounds the stall). ──
        let mut reqs: alloc::vec::Vec<dispatch::TranslationRequest> = alloc::vec::Vec::new();
        let attempt_budget = JIT_INSTALL_BUDGET.min(self.jit_run_attempt_remaining);
        while reqs.len() < attempt_budget {
            match self.compile_queue.pop_hottest() {
                Some(job) => reqs.push(job.req),
                None => break,
            }
        }
        let mut exec = self.executor.take().expect("executor present");
        // ── 1. Validate each request against live memory and collect the still-valid decoded blocks. ──
        let mut valid: alloc::vec::Vec<dispatch::DecodedBlock> = alloc::vec::Vec::new();
        let mut installed_bytes: u64 = 0;
        for req in &reqs {
            // Re-read the live physical bytes for the block and validate: a store/`fence.i` between
            // nomination and now would fail this and the request is dropped (never compile stale code).
            let n = req.code_bytes.len();
            let mut live = alloc::vec::Vec::with_capacity(n);
            let mut ok = true;
            for i in 0..n {
                match self.bus.load8(req.phys_pc.wrapping_add(i as u64)) {
                    Ok(b) => live.push(b),
                    Err(_) => {
                        ok = false;
                        break;
                    }
                }
            }
            if !ok {
                self.discovery.renominate(req.phys_pc);
                continue;
            }
            if !self.discovery.install_check(req, &live) {
                continue;
            }
            // The predecoded block is still cached (physical keying); take a clone for the batch.
            if let Some(block) = self.block_cache.get(req.phys_pc) {
                installed_bytes = installed_bytes.saturating_add(req.code_bytes.len() as u64);
                valid.push(block.clone());
            } else {
                // A bounded/evicting decoded cache can lose this block while its nomination waits.
                // Clear the Queued dedup state so a later execution rebuilds and re-nominates it.
                self.discovery.renominate(req.phys_pc);
            }
        }
        // ── 2. Group the drained blocks into batches by connected components of the observed static-
        //       edge graph (E4-T19 §7), capped at the executor's batch-size K, then install each
        //       group as ONE module with intra-batch edges lowered to direct calls. ──
        let k = exec.batch_size().max(1);
        for group in group_into_batches(&valid, k) {
            let group_blocks: alloc::vec::Vec<dispatch::DecodedBlock> =
                group.iter().map(|&i| valid[i].clone()).collect();
            let intra = intra_edges_for_group(&valid, &group);
            exec.install_batch(&group_blocks, &intra);
        }
        // E4-T20: any batch the install-time budget enforcement EVICTED must be re-nominated in
        // discovery, else dedup would suppress its re-translation forever (AC3 thrash signal).
        for phys in exec.take_evicted() {
            self.discovery.renominate(phys);
        }
        self.executor = Some(exec);
        // E4-T21: record this install step's pause (wall ns when timed, always the work bound). The
        // block count fed the executor is `valid.len()`, hard-capped at `JIT_INSTALL_BUDGET`.
        let pause_ns = match (t0, self.host_timer.as_ref()) {
            (Some(t0), Some(t)) => t.now_ns().saturating_sub(t0),
            _ => 0,
        };
        self.prof.record_jit_pause(
            pause_ns,
            reqs.len() as u64,
            valid.len() as u64,
            installed_bytes,
        );
        self.jit_run_attempt_remaining = self.jit_run_attempt_remaining.saturating_sub(reqs.len());
        self.jit_run_attempted_blocks = self
            .jit_run_attempted_blocks
            .saturating_add(reqs.len() as u64);
        (reqs.len(), valid.len())
    }

    /// E4-T31: commit one compiled exit's exact retirement span into every counter that the
    /// interpreter advances per successful instruction. The block translator's only CSR ops are
    /// `fflags`/`frm`/`fcsr` accesses, which never write a counter, so one bulk addition is
    /// architecturally equivalent to `retire_tick()` after every op.
    #[cfg(not(feature = "zicsr-stub"))]
    fn account_jit_retired(&mut self, retired: u64) {
        self.hart.csr.retire_span(retired);
        self.advance_clock_by(retired);
        self.irqstats.on_retire_n(retired);
        if let Some(exec) = self.executor.as_mut() {
            exec.note_jit_retired(retired);
        }
    }

    /// E4-T10/E4-T31: try to execute a compiled chain at the current PC within
    /// `remaining_work`. `None` means the first block did not run and the caller may interpret it;
    /// `Some(progress)` means at least one block committed and reports the exact work consumed plus
    /// its clean/trapping result. A later short-tail refusal preserves prior progress.
    ///
    /// The device/interrupt sample already happened at this boundary (in the loop, before this call),
    /// and `mtime` advances per retired op below, so the E4-T05 interrupt-batching semantics are
    /// preserved: a compiled block is exactly one `DecodedBlock` (≤128 ops), sampled at its entry.
    /// E4-T18: run the compiled block at the current PC and, if chaining is on, keep following
    /// direct block→block links (through the executor's link-slots) instead of returning to the
    /// dispatch loop on every edge — up to the chain-depth budget, and re-checking the
    /// interrupt/instruction budget at EVERY link so a timer still fires inside a chained loop.
    ///
    /// Every committed block updates registers, PC, clocks, and retirement statistics before the
    /// next link is considered. A faulting instruction consumes one work slot but does not retire.
    #[cfg(not(feature = "zicsr-stub"))]
    fn try_jit_block(&mut self, remaining_work: u64) -> Option<JitProgress> {
        debug_assert!(remaining_work > 0);
        let pc0 = self.hart.regs.pc;
        let mut phys = self.hart.fetch_phys(&mut self.bus, pc0).ok()?;
        if !self.executor.as_ref()?.is_compiled(phys) {
            return None;
        }
        let chaining = self.executor.as_ref()?.chaining();
        let budget = self.executor.as_ref()?.chain_depth_budget().max(1);
        let direct_chain_fuel = self.executor.as_ref()?.uses_direct_chain_fuel();
        let mut depth: u32 = 0;
        let mut work_used = 0u64;
        let mut ran_any = false;
        // The edge just traversed to reach `phys` (from_phys, edge) — linked lazily on arrival.
        let mut pending_link: Option<(u64, u8, u64)> = None;
        let result = loop {
            let block_budget = remaining_work - work_used;
            let device_accesses = self.bus.device_access_count();
            // Trim the in-module chain fuel to the next timer deadline for EVERY host entry: `mtime`
            // advanced by the blocks this host-level chain already retired, so fuel computed once
            // at chain start would let a later host entry's direct chain run past the deadline.
            let (direct_chain_budget, allow_direct_chaining) = if direct_chain_fuel {
                self.direct_chain_budget(block_budget)
            } else {
                (block_budget, false)
            };
            let Some(step) = self.run_one_jit_block(
                phys,
                block_budget,
                direct_chain_budget.min(block_budget),
                allow_direct_chaining,
            ) else {
                // The first block left the hart untouched, so the caller can interpret it. If a
                // LATER block refused the short tail or hit a defensive pre-call metadata miss,
                // prior blocks already committed: return their progress and let the next dispatch
                // handle this PC.
                break (work_used != 0).then_some(JitProgress {
                    result: Ok(()),
                    work_used,
                });
            };
            ran_any = true;
            match step {
                BlockStep::Budget { retired } => {
                    debug_assert!(retired > 0 && retired <= block_budget);
                    work_used += retired;
                    break Some(JitProgress {
                        result: Ok(()),
                        work_used,
                    });
                }
                BlockStep::Trapped { trap, retired } => {
                    let step_work = retired
                        .checked_add(1)
                        .expect("a compiled block cannot retire u64::MAX instructions");
                    debug_assert!(step_work <= block_budget);
                    work_used += step_work;
                    break Some(JitProgress {
                        result: Err(trap),
                        work_used,
                    });
                }
                BlockStep::Committed { edge, retired } => {
                    // Link only after the successor really ran. A short-tail refusal or defensive
                    // pre-call cache miss must not publish an edge as though it executed.
                    if let (Some((from, edge, to_virtual)), Some(e)) =
                        (pending_link.take(), self.executor.as_mut())
                    {
                        e.link_edge_authorized(from, edge, to_virtual, phys);
                    }
                    debug_assert!(retired > 0 && retired <= block_budget);
                    work_used += retired;
                    // The block ran clean; PC now sits at its successor's entry.
                    // Ending exactly on the host budget is not a new instruction boundary inside
                    // this call: do not sample devices/interrupts until the next `run` invocation.
                    if work_used == remaining_work {
                        break Some(JitProgress {
                            result: Ok(()),
                            work_used,
                        });
                    }
                    if !chaining {
                        break Some(JitProgress {
                            result: Ok(()),
                            work_used,
                        });
                    }
                    // A block that touched a device (a virtio kick, a UART IER/IIR access, a PLIC
                    // claim, ...) must be followed by the FULL boundary pass — device service and
                    // UART/RTC/virtio IRQ-line mirroring — exactly as the batched interpreter does
                    // at the next block boundary. The in-chain sync below only mirrors
                    // CLINT/SBI/PLIC levels, so return to the run loop instead of chaining on.
                    if self.bus.device_access_count() != device_accesses {
                        break Some(JitProgress {
                            result: Ok(()),
                            work_used,
                        });
                    }
                    depth += 1;
                    if depth >= budget {
                        break Some(JitProgress {
                            result: Ok(()),
                            work_used,
                        }); // chain-depth bound: force a dispatch return.
                    }
                    // Interrupt/instruction budget across chains: refresh the timer levels (mtime
                    // advanced per retired op above) AND re-mirror the PLIC external-interrupt levels
                    // and, if an interrupt is now pending, return to dispatch so the boundary poll
                    // delivers it — a timer OR a device completion thus fires within one block
                    // (≤128 ops) of becoming pending even inside a fully-chained loop.
                    //
                    // E4-T23: `sync_plic()` is what makes an INJECTED device completion (virtio-blk /
                    // net → a PLIC source pending bit, set by the backend on the other thread) take
                    // effect INSIDE the chain. Without it a device IRQ would only be sampled when the
                    // chain happens to exit to dispatch (the chain-depth bound / a fetch miss), so a
                    // blk-completion could be delayed by thousands of loop iterations — refuted by
                    // `device_completion_fires_inside_chained_loop`. The level is already asserted by
                    // the device; this only mirrors it into `mip`, so it is cheap and side-effect-free.
                    self.sync_clint();
                    self.sync_sbi_timer();
                    self.sync_plic();
                    if self.hart.csr.next_interrupt().is_some() {
                        break Some(JitProgress {
                            result: Ok(()),
                            work_used,
                        });
                    }
                    // Follow the edge only if the successor is itself compiled; otherwise return to
                    // dispatch (which will interpret / compile it).
                    let from = phys;
                    let next_virtual = self.hart.regs.pc;
                    let next_phys = match self.hart.fetch_phys(&mut self.bus, next_virtual) {
                        Ok(p) => p,
                        Err(_) => {
                            break Some(JitProgress {
                                result: Ok(()),
                                work_used,
                            });
                        }
                    };
                    let next_compiled = self
                        .executor
                        .as_ref()
                        .is_some_and(|e| e.is_compiled(next_phys));
                    if next_compiled {
                        // Dynamic `jalr` targets still use the virtual-target cache. Static edges
                        // are published into the source/edge-local slot when the successor arrives;
                        // this removes the hash/key probe and keeps invalidation source-local.
                        if edge.is_none()
                            && self.executor.as_ref().is_some_and(|e| e.dynamic_chaining())
                            && let Some(e) = self.executor.as_mut()
                        {
                            e.link_dynamic_target(next_virtual, next_phys);
                        }
                    } else {
                        break Some(JitProgress {
                            result: Ok(()),
                            work_used,
                        });
                    }
                    // Record the edge to link on arrival (only static edges carry an `edge`; a
                    // dynamic `jalr` target has `edge == None` — followed but never linked).
                    pending_link = edge.map(|e| (from, e, next_virtual));
                    phys = next_phys;
                }
            }
        };
        // Stats: one dispatch-loop entry per chain, with its depth binned into the histogram.
        if ran_any && let Some(e) = self.executor.as_mut() {
            e.note_chain(depth);
        }
        result
    }

    /// Resume the block cursor at op `index` of the decoded block keyed `key`, whose virtual
    /// address is `pc`: the continuation of a partial block's compiled prefix
    /// ([`jit::ExitCode::CallInterp`]). The batched interpreter replays that op from the cursor of
    /// the block it entered, so it must never become a block boundary (no device sync, no
    /// interrupt sample) here either.
    ///
    /// The native executor runs one block per host call and [`Self::run_one_jit_block`] only
    /// starts a block whose decoded form is cached, so `key` is resident. A browser in-module
    /// direct chain, however, enters a compiled successor without any host lookup, and the bounded
    /// decoded-block cache may have evicted that successor's decoded block since it was compiled.
    /// Its bytes cannot have changed meanwhile: a store into a code page invalidates the compiled
    /// module together with the decoded blocks, and a page stays tracked as code after its blocks
    /// are evicted. So the block is re-decoded from physical memory — with no MMU, TLB or PMP
    /// side effect, as the continuation op is never fetched by the interpreter either — and the
    /// cursor resumes in it.
    #[cfg(not(feature = "zicsr-stub"))]
    fn resume_partial_block(&mut self, key: u64, index: usize, pc: u64) {
        if self.block_cache.get(key).is_none() && self.rebuild_decoded_block_phys(key) {
            self.jit_partial_resume_rebuilds = self.jit_partial_resume_rebuilds.saturating_add(1);
        }
        // Only resume a cursor that provably names the op at `pc` (same page offset).
        let page_mask = dispatch::PAGE - 1;
        let resumes = self.block_cache.get(key).is_some_and(|b| {
            index < b.ops.len() && {
                let offset: u64 = b.ops[..index].iter().map(|op| u64::from(op.len)).sum();
                key.wrapping_add(offset) & page_mask == pc & page_mask
            }
        });
        debug_assert!(
            resumes,
            "partial block {key:#x} op {index} at {pc:#x}: the decoded block must resume"
        );
        if resumes && let Some(block) = self.block_cache.get_rc(key).cloned() {
            self.block_cursor = Some(BlockCursor {
                block,
                idx: index,
                next_va: pc,
            });
        } else {
            self.jit_partial_resume_failures = self.jit_partial_resume_failures.saturating_add(1);
        }
    }

    /// Re-decode the block whose physical entry is `key` from physical memory and insert it in the
    /// decoded-block cache, walking exactly as [`Self::next_micro_op`] does (to the first
    /// terminator, the page edge, a page-straddling op, an undecodable op or the op cap). Returns
    /// `false` when not even the entry op decodes, which a compiled block's entry always does.
    #[cfg(not(feature = "zicsr-stub"))]
    fn rebuild_decoded_block_phys(&mut self, key: u64) -> bool {
        let page_mask = dispatch::PAGE - 1;
        let page_base = key & !page_mask;
        let mut ops = alloc::vec::Vec::with_capacity(8);
        let mut total_len = 0_u64;
        let mut pa = key;
        while ops.len() < dispatch::MAX_BLOCK_OPS && pa & !page_mask == page_base {
            let Some(op) = decode_phys(&mut self.bus, pa) else {
                break;
            };
            // An op straddling the page edge belongs to the next block (an entry op that straddles
            // is never cached, so never compiled).
            if (pa & page_mask) + u64::from(op.len) > dispatch::PAGE {
                break;
            }
            total_len += u64::from(op.len);
            ops.push(op);
            if dispatch::is_terminator(&op.instr) {
                break;
            }
            pa = pa.wrapping_add(u64::from(op.len));
        }
        if ops.is_empty() {
            return false;
        }
        self.block_cache
            .insert(dispatch::DecodedBlock::new(key, ops, total_len));
        true
    }

    /// Compute the fuel for one browser in-module chain. Direct chaining is only enabled with the
    /// existing Phase-C interrupt batching contract: that contract already permits observation to
    /// lag by one bounded block, while the fuel keeps a chain from spanning an arbitrary outer run
    /// quantum. In deterministic ICount mode, trim the fuel so a chain cannot retire past a future
    /// CLINT/SBI timer deadline; wall-clock mode keeps the conservative dispatch path because time
    /// can advance independently of guest retirement.
    #[cfg(not(feature = "zicsr-stub"))]
    fn direct_chain_budget(&self, remaining_work: u64) -> (u64, bool) {
        let mut budget = remaining_work.clamp(1, JIT_DIRECT_CHAIN_FUEL);
        if !self.interrupt_batching() || self.wall_time.is_some() {
            return (remaining_work, false);
        }

        let mut deadline = None;
        if let Some(clint) = &self.clint {
            let state = clint.borrow();
            if state.mtimecmp != u64::MAX && state.mtimecmp > state.mtime {
                deadline = Some(state.mtimecmp);
            }
            if self.builtin_sbi
                && self.sbi_state.stimecmp != u64::MAX
                && self.sbi_state.stimecmp > state.mtime
            {
                deadline = Some(
                    deadline.map_or(self.sbi_state.stimecmp, |d| d.min(self.sbi_state.stimecmp)),
                );
            }
            if let Some(deadline) = deadline {
                let ticks = u128::from(deadline - state.mtime);
                let need = ticks
                    .saturating_mul(u128::from(self.clock_div.max(1)))
                    .saturating_sub(u128::from(self.tick_accum));
                budget = budget.min(u64::try_from(need.max(1)).unwrap_or(u64::MAX));
            }
        }
        (budget.max(1), true)
    }

    /// E4-T18: execute exactly ONE compiled block at physical entry `phys` (the former body of
    /// `try_jit_block`), committing its registers / PC / retire clock. Returns:
    /// * `None` — the block did not run (metadata vanished, it cannot fit in the remaining tail,
    ///   or its first instruction cannot fit in the direct-chain fuel), so the caller may interpret
    ///   it from entry.
    /// * `Some(BlockStep::Committed { edge, retired })` — a clean exit and its exact retirement
    ///   span; `edge` identifies a static successor for chaining.
    /// * `Some(BlockStep::Trapped { trap, retired })` — a precise trap plus the body prefix that
    ///   committed before the faulting instruction.
    #[cfg(not(feature = "zicsr-stub"))]
    fn run_one_jit_block(
        &mut self,
        phys: u64,
        remaining_work: u64,
        direct_chain_budget: u64,
        allow_direct_chaining: bool,
    ) -> Option<BlockStep> {
        // Op count + terminator from the physically-keyed decoded block. A block too large for the
        // remaining host tail is refused BEFORE touching executor/hart state, so the interpreter can
        // consume exactly the remaining instruction attempts without overshoot.
        let (nops, terminator) = {
            let b = self.block_cache.get(phys)?;
            (b.ops.len() as u64, b.ops.last().map(|o| o.instr))
        };
        if nops == 0 || nops > remaining_work {
            return None;
        }
        // A host-side direct CSR write may leave the one-instruction suppression flags armed. JIT
        // candidates contain no counter-writing CSR ops, so clear stale flags once at block entry
        // before bulk-retire.
        self.hart.csr.arm_counters();
        let entry_pc = self.hart.regs.pc;
        // Take the executor out so it can borrow hart + bus for the duration of the call.
        let mut exec = self.executor.take().expect("compiled ⇒ executor present");
        let exit = exec.execute_with_budget(
            phys,
            &mut self.hart,
            &mut self.bus,
            remaining_work,
            direct_chain_budget,
            allow_direct_chaining,
        );
        self.executor = Some(exec);
        // `None` is exclusively a defensive pre-call executor metadata miss; compiled code did not
        // run, so interpreting from entry is replay-safe. Recorded faults return `Some(Trap)`, and
        // an unclassified failure after dispatch fails closed inside the executor.
        let exit = exit?;

        // PC is about to jump to a block entry; the block cursor no longer describes it.
        self.block_cursor = None;
        match exit.code {
            jit::ExitCode::Fallthrough | jit::ExitCode::BranchTaken => {
                self.hart.regs.pc = exit.next_pc;
                let retired = if exit.retired == 0 {
                    nops
                } else {
                    exit.retired
                };
                debug_assert!(retired > 0 && retired <= remaining_work);
                // E4-T17: a JIT block ending in `fence.i` orders the fetch stream the SAME near-free
                // way `step_cached` does — the block's own stores were logged and are drained
                // page-granularly below, so any page this block wrote (incl. its own, the self-write
                // corner) is invalidated; `fence.i` itself drops NOTHING, so un-dirtied pages' blocks
                // survive. Note the event, then drain: a store may have landed on a code page
                // (SMC / DMA-into-code / self-write) and must invalidate exactly that page.
                if matches!(terminator, Some(crate::decode::Instr::FenceI)) {
                    self.block_cache.note_fence_i();
                }
                self.drain_code_writes();
                self.account_jit_retired(retired);
                Some(BlockStep::Committed {
                    edge: (retired == nops)
                        .then(|| chain_edge(terminator, exit.code))
                        .flatten(),
                    retired,
                })
            }
            jit::ExitCode::CallInterp => {
                // Partial-block exit: the compiled prefix retired and the block's first
                // untranslated op (always a block-ending system/CSR op today) must now execute in
                // the interpreter as the CONTINUATION of the same decoded block. Resuming the block
                // cursor keeps `at_block_boundary()` false for that op, so no device sync or
                // interrupt sample happens in between — exactly the batched interpreter's replay.
                let key = exit.exit_info & ((1_u64 << 56) - 1);
                let index = (exit.exit_info >> 56) as usize;
                let retired = if exit.retired != 0 {
                    exit.retired
                } else {
                    index as u64
                };
                debug_assert!(retired > 0 && retired <= remaining_work);
                self.hart.regs.pc = exit.next_pc;
                self.account_jit_retired(retired);
                // A prefix store into a code page drops the cursor, exactly as the interpreter's
                // per-store drain would before the next op: that op is then a block boundary in
                // the batched interpreter too, so do not resume.
                if !self.drain_code_writes() {
                    self.resume_partial_block(key, index, exit.next_pc);
                }
                Some(BlockStep::Budget { retired })
            }
            jit::ExitCode::Budget => {
                let retired = exit.retired;
                if retired == 0 {
                    // The first block did not fit the direct-chain fuel. No architectural state
                    // was changed by the prologue, so the caller can safely interpret it.
                    return None;
                }
                debug_assert!(retired <= remaining_work);
                self.hart.regs.pc = exit.next_pc;
                self.account_jit_retired(retired);
                self.drain_code_writes();
                Some(BlockStep::Budget { retired })
            }
            jit::ExitCode::Trap | jit::ExitCode::IllegalInstruction => {
                // E4-T12: a PRECISE mid-block memory fault carries the interpreter-produced `Trap`
                // (cause + `mtval`) directly. `exit.next_pc` is the faulting instruction's PC; the
                // executor already synced the precise register file (as of the instruction before
                // it) back into `hart.regs`. Advance the retire clock by exactly the number of ops
                // that retired before the faulting one (found by walking the block's op lengths to
                // the faulting PC), leave PC at the faulting instruction, and hand the trap to the
                // loop's normal `take_trap` delivery — so mcause/mtval/mepc come from the ONE
                // trusted implementation and no already-committed side-effect is re-executed.
                let precise_trap = if exit.code == jit::ExitCode::IllegalInstruction {
                    Some(Trap {
                        cause: hart::Exception::IllegalInstruction,
                        tval: exit.exit_info,
                    })
                } else {
                    exit.trap
                };
                if let Some(trap) = precise_trap {
                    let faulting_pc = exit.next_pc;
                    // `exit.next_pc` is a guest VIRTUAL PC. Walking from the physical block key is
                    // accidentally correct only under identity mapping; use the virtual entry PC so
                    // Sv39 aliases account the exact prefix too. The executor writes only a static
                    // per-op PC from this trusted block; an out-of-block value is an internal ABI
                    // violation and must fail closed rather than fabricate architectural counters.
                    let retired = if exit.retired != 0 {
                        exit.retired
                    } else {
                        let block = self
                            .block_cache
                            .get(phys)
                            .expect("executed JIT block metadata remains live until write drain");
                        let mut pc = entry_pc;
                        block
                            .ops
                            .iter()
                            .position(|op| {
                                let matches = pc == faulting_pc;
                                pc = pc.wrapping_add(u64::from(op.len));
                                matches
                            })
                            .expect("JIT precise-trap PC must name an op in its decoded block")
                            as u64
                    };
                    debug_assert!(retired < nops || exit.retired != 0);
                    debug_assert!(retired <= remaining_work);
                    self.account_jit_retired(retired);
                    self.hart.regs.pc = faulting_pc;
                    // A store before the fault may have hit a code page (SMC/DMA-into-code); drain
                    // the bus write log through page-granular invalidation, exactly as the
                    // interpreter would after that store retired.
                    self.drain_code_writes();
                    return Some(BlockStep::Trapped { trap, retired });
                }
                // Otherwise: the trapping terminator (`ecall`/`ebreak`) retires NOTHING; only the
                // `nops-1` body ops did. Advance the clock for those.
                let retired = if exit.retired != 0 {
                    exit.retired
                } else {
                    nops.saturating_sub(1)
                };
                debug_assert!(retired <= remaining_work);
                self.account_jit_retired(retired);
                // Leave PC at the faulting instruction and derive the trap from the CURRENT
                // privilege mode (the block cannot know it) so the cause matches the interpreter.
                self.hart.regs.pc = exit.next_pc;
                let trap = match exit.exit_info as i64 {
                    3 => Trap {
                        cause: hart::Exception::Breakpoint,
                        tval: exit.next_pc,
                    },
                    _ => Trap {
                        cause: match self.hart.csr.mode {
                            crate::csr::Priv::U => hart::Exception::EcallFromU,
                            crate::csr::Priv::S => hart::Exception::EcallFromS,
                            crate::csr::Priv::M => hart::Exception::EcallFromM,
                        },
                        tval: 0,
                    },
                };
                Some(BlockStep::Trapped { trap, retired })
            }
            jit::ExitCode::Reserved(_) => {
                // The E4-T09 translator never emits these; on a clean return the executor already
                // committed registers, so re-interpreting would double-execute. Commit PC and treat
                // as a benign fall-through (defensive — unreachable for the current translator).
                self.hart.regs.pc = exit.next_pc;
                self.account_jit_retired(nops);
                // Reserved never carries a static successor edge — do not chain-link it.
                Some(BlockStep::Committed {
                    edge: None,
                    retired: nops,
                })
            }
        }
    }

    /// The device-fabric re-sync performed at every interrupt-sampling boundary (per retire in
    /// legacy mode, per decoded block under Phase-C batching): latch host config IRQs, refresh the
    /// wall/ICount clock levels, service every attached device, mirror the interrupt LEVELS into
    /// the PLIC and `mip`, drain DMA-into-code, and pump the JIT compile queue. Out of line so the
    /// per-instruction interpreter loop stays compact; the ORDER of every step is load-bearing.
    ///
    /// Quiescence fast path: when the previous full sync found every device IDLE (each service
    /// took its no-work early return, the UART timeout clock was stopped, no RTC alarm was armed,
    /// no config request was latched) and no guest MMIO access has reached a fabric device window
    /// since (the [`FabricTouch`] epoch is unchanged) and no host call intervened (every run entry
    /// clears the marker), then repeating the device half would take exactly the same no-op paths
    /// and write the same PLIC levels — so only the clock/`mip` mirrors, the DMA drain and the JIT
    /// pump run. The result is identical to the full sync at every boundary.
    ///
    /// The quiescent half is inlined into the run loop (it runs at almost every boundary: a few
    /// loads and `mip` bit updates); the device half stays out of line in
    /// [`Self::boundary_sync_full`], so the common boundary pays neither a call nor that function's
    /// large frame.
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(always)]
    fn boundary_sync(&mut self) {
        #[cfg(test)]
        let quiescent =
            !self.fabric_fast_path_off && self.fabric_idle_epoch == Some(self.fabric_epoch.get());
        #[cfg(not(test))]
        let quiescent = self.fabric_idle_epoch == Some(self.fabric_epoch.get());
        if quiescent {
            #[cfg(test)]
            {
                self.fabric_fast_hits += 1;
            }
            self.sample_wall_clock();
            self.sync_clint();
            self.sync_plic();
            self.sync_sbi_timer();
            self.drain_code_writes();
            self.boundary_jit_pump();
            return;
        }
        self.boundary_sync_full();
    }

    /// The non-quiescent [`Self::boundary_sync`]: the full device-fabric pass (see there).
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(never)]
    fn boundary_sync_full(&mut self) {
        let mut idle = true;
        // E5-T04: host-owned virtio devices may have requested a config change through a
        // retained state handle (for example a GPU canvas resize).  Latch those requests
        // before mirroring InterruptStatus into the PLIC so the guest sees one precise
        // config IRQ at this boundary, even when no queue was kicked.
        for (slot, _) in &self.virtio {
            idle &= !slot.borrow_mut().sync_backend_config_irq();
        }
        // E4-T24: in WallClock mode, recompute `mtime` from the host clock BEFORE sync_clint
        // samples the MTIP level, so a just-elapsed wall deadline fires this boundary. No-op on
        // the default ICount path.
        self.sample_wall_clock();
        self.sync_clint();
        // E2-T07: tick the UART char-timeout clock and mirror its level into the
        // PLIC BEFORE sync_plic samples EIP, so a UART edge lands this boundary.
        if let Some((uart, line)) = &self.uart {
            let mut u = uart.borrow_mut();
            idle &= !u.tick();
            line.set(u.irq_level());
        }
        // E2-T16: poll the RTC alarm and mirror its interrupt level into the PLIC,
        // BEFORE sync_plic samples EIP, so a just-reached alarm fires this boundary.
        if let Some((rtc, line)) = &self.rtc {
            let mut r = rtc.borrow_mut();
            line.set(r.poll());
            idle &= !r.alarm_armed();
        }
        // Device services borrow the slot, their own ring views and the bus disjointly (no
        // per-boundary `Rc` clone of the slot handle).
        let Self {
            virtio,
            bus,
            blk,
            extra_blk,
            net,
            rng,
            keyboard,
            tablet,
            mouse,
            gpu,
            snd,
            console,
            ..
        } = self;
        // E2-T11: service pending virtio-blk kicks BEFORE mirroring levels, so a
        // completed request's used-ring interrupt lands this same boundary.
        if let Some((state, vq)) = blk {
            idle &= dev::virtio::blk::service(&virtio[0].0, vq, state, bus);
        }
        // E4-T03: service each ADDITIONAL (read-only) blk device on the same boundary, so a
        // guest read of `/dev/vdb…` completes promptly.
        for (state, vq, slot_index) in extra_blk.iter_mut() {
            idle &= dev::virtio::blk::service(&virtio[*slot_index].0, vq, state, bus);
        }
        // E3-T13: service virtio-net kicks (and async backend rx frames) the same
        // boundary, so tx completions + delivered echoes interrupt promptly. The backend is
        // polled every boundary (it may be event-driven) unless it reports `NetBackend::idle`.
        if let Some((state, rx_vq, tx_vq)) = net {
            idle &= dev::virtio::net::service(&virtio[1].0, rx_vq, tx_vq, state, bus);
        }
        // virtio-rng: fill guest entropy requests the same boundary the driver kicked, so
        // the CRNG seeds without waiting on the run loop.
        if let Some((state, vq)) = rng {
            idle &= dev::virtio::rng::service(&virtio[2].0, vq, state, bus);
        }
        // E5-T11b: service keyboard eventq/statusq on slot 3. The status sink retains
        // guest LED changes in the host-owned indicator before the next boundary.
        if let Some((state, eventq, statusq)) = keyboard {
            idle &= dev::virtio::input::service(
                &virtio[dev::virtio::input::keyboard::KEYBOARD_VIRTIO_SLOT].0,
                eventq,
                statusq,
                state,
                bus,
            );
        }
        // E5-T14a: service the absolute tablet and relative mouse independently. The
        // browser may select either host route, but both guest-visible devices remain
        // present and their bounded frames cannot consume one another's queues.
        if let Some((state, eventq, statusq)) = tablet {
            idle &= dev::virtio::input::service(
                &virtio[dev::virtio::input::pointer::TABLET_VIRTIO_SLOT].0,
                eventq,
                statusq,
                state,
                bus,
            );
        }
        if let Some((state, eventq, statusq)) = mouse {
            idle &= dev::virtio::input::service(
                &virtio[dev::virtio::input::pointer::MOUSE_VIRTIO_SLOT].0,
                eventq,
                statusq,
                state,
                bus,
            );
        }
        // E5-T06d: service the deferred virtio-gpu control queue at the same boundary as
        // the other guest devices. RESOURCE_FLUSH invokes the retained host sink only
        // after guest backing has been validated and copied into the resource shadow.
        if let Some((state, control_vq, cursor_vq, slot_index)) = gpu {
            idle &= dev::virtio::gpu::service_with_cursor(
                &virtio[*slot_index].0,
                control_vq,
                cursor_vq,
                state,
                bus,
            );
        }
        // E5-T19d: service sound controlq before eventq/txq so a Linux snd_virtio probe
        // receives its QEMU-shaped responses at the same guest-visible boundary that it
        // kicks the queue. Playback then uses the injected host clock/sink without changing
        // any of the established blk/net/input slots.
        if let Some((slot_index, state, controlq, eventq, rxq, txq, clock, sink, source)) = snd {
            let (_, snd_idle) = dev::virtio::snd::service_with_control_eventq_and_capture_idle(
                &virtio[*slot_index].0,
                controlq,
                eventq,
                Some(rxq),
                Some(source.as_mut()),
                txq,
                state,
                clock.as_ref(),
                sink.as_mut(),
                bus,
            );
            idle &= snd_idle;
        }
        // E5-T23b: service the independent virtio-console port-0/control/agent queues.
        // Control transitions run before agent data so a freshly opened port can carry
        // bytes at this same device boundary; the UART/SBI path above remains untouched.
        if let Some(console) = console {
            idle &= dev::virtio::console::service(
                &virtio[console.slot_index].0,
                &mut console.port0_receiveq,
                &mut console.port0_transmitq,
                &mut console.control_receiveq,
                &mut console.control_transmitq,
                &mut console.agent_receiveq,
                &mut console.agent_transmitq,
                &console.state,
                bus,
            );
        }
        // E2-T08: mirror each virtio slot's InterruptStatus level into the PLIC.
        for (slot, line) in &self.virtio {
            line.set(slot.borrow().irq_level());
        }
        // E1-T13: refresh the PLIC-driven MEIP/SEIP levels too, before sampling.
        self.sync_plic();
        // E2-T05: refresh the built-in-SBI S-timer level (STIP) before sampling.
        self.sync_sbi_timer();
        // E4-T05 Phase B: the device services above may have DMA'd into guest RAM (a
        // virtio-blk read completion writing sector bytes, virtio-net rx, virtio-rng,
        // a used-ring publish). Those writes went through the bus and were logged by
        // physical frame; drain them through page-granular invalidation so a guest that
        // DMAs code then jumps to it can never execute a stale cached block. (Phase C
        // does NOT touch this — the device sync above is still per-retire.)
        self.drain_code_writes();
        self.boundary_jit_pump();
        // Idle devices stay idle until a fabric MMIO access (epoch bump) or a new run call.
        self.fabric_idle_epoch = idle.then(|| self.fabric_epoch.get());
    }

    /// E4-T19: at a block boundary, drain the compile queue into BATCHES — but let a burst of
    /// newly-hot blocks accumulate first, so a connected component compiles as ONE module rather
    /// than a trickle of one-block modules. Drain when the queue reaches `JIT_BATCH_TRIGGER` (a
    /// batch's worth is ready) or every `JIT_PUMP_INTERVAL` boundaries (flush stragglers). Cheap
    /// when the queue is empty.
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(always)]
    fn boundary_jit_pump(&mut self) {
        if self.jit_enabled
            && self.jit_run_attempt_remaining > 0
            && (!self.compile_queue.is_empty() || self.jit_run_staging_remaining > 0)
        {
            self.jit_pump_ticks = self.jit_pump_ticks.wrapping_add(1);
            if self.discovery.queue_len() >= JIT_BATCH_TRIGGER
                || self.jit_pump_ticks >= JIT_PUMP_INTERVAL
            {
                self.jit_pump_ticks = 0;
                self.pump_jit_translations();
            }
        }
    }

    /// The post-retire bookkeeping of a retired `wfi` (shared by the one-op loop body and
    /// [`Self::replay_block_tail`]).
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(never)]
    fn after_wfi_retire(&mut self) {
        self.irqstats.on_wfi();
        self.hart.last_was_wfi = false;
        self.wfi_watchdog_check(); // deadlock watchdog (WFI + no wakeup armed)
        // E2-T23b: no interrupt was pending this boundary (next_interrupt returned None before
        // this block ran), so this WFI is a real idle wait. Skip the idle spin by jumping mtime to
        // the nearest armed timer deadline — deterministic, so native and wasm agree. Turns a ~20×
        // `sleep` into near-real-time. No-op if no timer armed.
        if !self.external_net_io_pending()
            && !self.external_gpu_io_pending()
            && !self.external_keyboard_io_pending()
        {
            self.wfi_fast_forward();
        }
    }

    /// Phase-C mid-block replay: run the rest of the decoded block the cursor is inside, one op at
    /// a time, with exactly the per-instruction work of the run loop's non-boundary interpreted
    /// iteration and none of its per-iteration mode dispatch.
    ///
    /// The caller (the run loop) establishes, for the current iteration: interrupt batching and
    /// the block cache are on, this is NOT a sampling boundary (so the cursor continues at `pc`
    /// with an op left), no profiler or HTIF is armed, no debug trigger is armed, and
    /// `remaining_work > 0`. Within one block those conditions can only change at the block's
    /// terminator (triggers/CSRs), which is its last op, so after each op the loop re-evaluates
    /// exactly the run loop's next loop-top tests in the same order — work budget, syscon
    /// finisher, [`Self::at_block_boundary`] — and returns to the run loop the moment any of them
    /// would take it off the non-boundary path. Per op, in order: counter arm, cursor advance (the
    /// [`Self::next_micro_op`] continuation), [`Self::retire_cached_op`], work slot, then on
    /// success the retire clock, the progress counter and the WFI hook — the loop body's order.
    ///
    /// Deferred accounting: a [`dispatch::retire_deferrable`] op (pure integer register op) cannot
    /// observe the per-retire accounting — the Zicntr counters (`retire_tick`), the ICount clock
    /// (`advance_clock`) and the progress counter (`on_retire`) — so for a run of them the loop
    /// only counts, and [`Self::settle_retired`] applies the bulk-equivalent spans before the next
    /// op that could observe them (any memory, CSR, system or control op: e.g. a CLINT `mtime`
    /// load, a `csrr cycle`, a `wfi`) and before returning. Each is an exact bulk form: counter
    /// spans with the one-instruction write flags clear, `advance_clock_by(n)` ≡ `n` ×
    /// `advance_clock`, `on_retire_n(n)` ≡ `n` × `on_retire`.
    ///
    /// Returns `Some(trap)` when an op trapped: that op has NOT consumed its work slot, so the run
    /// loop charges it and delivers the trap through its one trap path. `None` otherwise.
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(never)]
    fn replay_block_tail<T: trace::TraceSink>(
        &mut self,
        remaining_work: &mut u64,
        capture: &mut RunCapture<'_, T>,
    ) -> Option<Trap> {
        // One loop per capture kind, so the per-op body carries no capture dispatch.
        match capture {
            RunCapture::Unit => self.replay_block_tail_with(remaining_work, |m, op, pc, defer| {
                m.retire_cached_op(op, pc, hart::UnitCapture, defer)
            }),
            RunCapture::Traced(sink) => {
                self.replay_block_tail_with(remaining_work, |m, op, pc, defer| {
                    m.retire_cached_op(op, pc, hart::RecordingCapture::new(&mut **sink), defer)
                })
            }
        }
    }

    /// The body of [`Self::replay_block_tail`] for one capture kind (`retire` is
    /// [`Self::retire_cached_op`] with that capture).
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(always)]
    fn replay_block_tail_with(
        &mut self,
        remaining_work: &mut u64,
        mut retire: impl FnMut(&mut Self, &dispatch::MicroOp, u64, bool) -> Result<(), Trap>,
    ) -> Option<Trap> {
        // Hold the block for the whole tail: the ops are read from this handle while `self` is
        // mutated. The cursor (which owns the same block) stays the authority for liveness — a
        // drain/fence.i that clears it ends the tail at the boundary test below.
        let block = alloc::rc::Rc::clone(&self.block_cursor.as_ref()?.block);
        let ops: &[dispatch::MicroOp] = &block.ops;
        // Successfully retired deferrable ops whose accounting is not yet applied.
        let mut pending: u64 = 0;
        let result = loop {
            // step_cached_with_capture, minus the execute-trigger test (no trigger is armed).
            self.hart.csr.arm_counters();
            let pc = self.hart.regs.pc;
            // The next_micro_op continuation: the caller / the previous iteration's boundary test
            // established `cursor.next_va == pc` and an op at `cursor.idx`.
            let Some(cursor) = self.block_cursor.as_mut() else {
                break None;
            };
            let idx = cursor.idx;
            let Some(op) = ops.get(idx) else {
                break None;
            };
            cursor.idx = idx + 1;
            cursor.next_va = pc.wrapping_add(u64::from(op.len));
            let defer = block.op_deferrable(idx);
            if !defer && pending != 0 {
                // This op may observe the accounting: bring it up to date first (the counter
                // write flags were just cleared by `arm_counters`).
                self.settle_retired(pending);
                pending = 0;
            }
            if let Err(trap) = retire(self, op, pc, defer) {
                break Some(trap);
            }
            *remaining_work -= 1;
            #[cfg(test)]
            {
                self.replay_tail_ops += 1;
            }
            if defer {
                pending += 1;
                #[cfg(test)]
                {
                    self.replay_deferred_ops += 1;
                }
                // The run loop's next loop-top tests, in its order. A deferrable op cannot write
                // the syscon finisher (no bus access; it was clear when this op began) or clear
                // the cursor (no drain, not `fence.i`), and it falls through to `pc + len` — the
                // cursor's `next_va` — so `at_block_boundary` reduces to the block-end test.
                if *remaining_work == 0 || idx + 1 >= ops.len() {
                    break None;
                }
                continue;
            }
            // The loop body's successful-retire accounting (profiling is off here).
            self.advance_clock();
            self.irqstats.on_retire(); // E2-T20 progress denominator
            if self.hart.last_was_wfi {
                self.after_wfi_retire();
            }
            // The run loop's next loop-top tests, in its order.
            if *remaining_work == 0 {
                break None;
            }
            if self.syscon.as_ref().is_some_and(|c| c.borrow().is_some()) {
                break None;
            }
            if self.at_block_boundary() {
                break None;
            }
        };
        if pending != 0 {
            self.settle_retired(pending);
        }
        result
    }

    /// Apply the per-retire accounting of `n` retired deferrable ops in one step (see
    /// [`Self::replay_block_tail`]): the Zicntr counter span (write flags are clear: no deferred
    /// op writes a CSR), the ICount clock span and the progress counter.
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline(always)]
    fn settle_retired(&mut self, n: u64) {
        self.hart.csr.retire_span(n);
        self.advance_clock_by(n);
        self.irqstats.on_retire_n(n);
    }

    fn run_capture_inner<T: trace::TraceSink>(
        &mut self,
        max_instrs: u64,
        capture: &mut RunCapture<'_, T>,
    ) -> RunOutcome {
        // A host/device can mutate RAM through `bus_mut()` while execution is yielded between
        // bounded run calls. Drain once before even considering a saved mid-block cursor: waiting
        // until the next post-retire drain would execute one stale cached instruction on resume.
        // Device service performed later in this run is covered by the boundary drain in
        // `next_micro_op`; guest stores retain their existing post-retire drain.
        #[cfg(not(feature = "zicsr-stub"))]
        if self.block_cache_enabled {
            self.sync_pmp_code_permissions();
        }
        #[cfg(not(feature = "zicsr-stub"))]
        self.drain_code_writes();
        // The host may have pushed input, resized a display, restored a snapshot, or otherwise
        // changed device state since the last run: the first boundary performs a full sync.
        self.fabric_idle_epoch = None;
        // Run-invariant dispatch configuration: only host calls between runs change these, so
        // read them once instead of per retired instruction.
        #[cfg(not(feature = "zicsr-stub"))]
        let batching = self.interrupt_batching();
        #[cfg(not(feature = "zicsr-stub"))]
        let jit_on = self.jit_active();
        #[cfg(not(feature = "zicsr-stub"))]
        let cache_on = self.block_cache_enabled;
        // Mid-block ops may take the tight replay loop when no per-op hook needs the general loop
        // body: batching (hence the cache) on, no hot-PC profiler, no HTIF mailbox. (Debug
        // triggers are re-checked per block below: a CSR write can arm them.)
        #[cfg(not(feature = "zicsr-stub"))]
        let tail_ok = batching && !self.profiling && self.htif.is_none();
        #[cfg(all(test, not(feature = "zicsr-stub")))]
        let tail_ok = tail_ok && !self.replay_tail_off;

        let mut remaining_work = max_instrs;
        while remaining_work != 0 {
            // E2-T17: a syscon finisher write (poweroff/reboot/fail) during the previous
            // instruction ends the run before the next one executes.
            #[cfg(not(feature = "zicsr-stub"))]
            if let Some(reason) = self.syscon.as_ref().and_then(|c| *c.borrow()) {
                return RunOutcome::Reset(reason);
            }
            // E4-T05 Phase C: when interrupt batching is on, the device-fabric re-sync + the
            // `next_interrupt` sampling below run ONLY at a block boundary (once per DecodedBlock,
            // ≤128 ops), not per instruction. Mid-block they are skipped: no CSR/xret/wfi/fence can
            // change interrupt-enable state mid-block (all are terminators), and no device state
            // changes mid-block (device service is itself batched here), so the only new mid-block
            // interrupt source is `mtime` crossing `mtimecmp` — and `mtime` still advances
            // per-retire (`advance_clock`), so that interrupt becomes pending at the identical
            // retire index and is merely SAMPLED at the next boundary (≤128 retires later). With
            // batching OFF (incl. cache-on/batching-off, the byte-identical mode) this is `true`
            // every iteration, so the legacy per-op behavior is bit-for-bit preserved.
            #[cfg(not(feature = "zicsr-stub"))]
            let sample_boundary = !batching || self.at_block_boundary();
            // CSR writes that change PMP are block terminators. Invalidate decoded/compiled code
            // at that next boundary before the JIT or cursor can reuse permissions from the old
            // configuration. Direct host mutations between run calls are caught by the entry sync.
            #[cfg(not(feature = "zicsr-stub"))]
            if cache_on && sample_boundary {
                self.sync_pmp_code_permissions();
            }
            // E1-T12: refresh the CLINT-driven interrupt LEVELS (MTIP = mtime >= mtimecmp, MSIP
            // = msip) into `mip` before sampling — a continuously re-evaluated level, so a
            // just-crossed timer fires and a raised `mtimecmp` clears MTIP with no CSR access.
            #[cfg(not(feature = "zicsr-stub"))]
            if sample_boundary {
                self.boundary_sync();
            }
            // E1-T11: sample interrupts at the instruction boundary (precise). Deliver the
            // highest-priority pending&enabled interrupt through mtvec/stvec BEFORE fetching the
            // next instruction — sepc/mepc then points at the resume address (the interrupted
            // instruction fully retired or never ran). Taking the trap clears xIE, so a pending
            // line does not re-fire while its handler runs. (No real CSR file under zicsr-stub.)
            // E4-T05 Phase C: sample interrupts only at a block boundary when batching (see above);
            // `sample_boundary` is always `true` when batching is off, so this is unchanged there.
            #[cfg(not(feature = "zicsr-stub"))]
            if sample_boundary && let Some((cause, to_s)) = self.hart.csr.next_interrupt() {
                let epc = self.hart.regs.pc;
                self.hart.take_interrupt(cause, to_s, epc);
                self.irqstats.on_interrupt(cause); // E2-T20 storm counter
                self.storm_check(); // CRITIC #1: an INTERRUPT storm must be detected too
                // Preserve the established `run(N)` contract: a taken boundary interrupt consumes
                // one bounded work slot even though it retires no guest instruction.
                remaining_work -= 1;
                continue;
            }
            // E4-T01: capture the PC of the instruction ABOUT to execute — after `step_traced` it has
            // already advanced to the successor, so the retired instruction's address must be read
            // here. A single register-resident field read; the sampling decision itself is gated below.
            #[cfg_attr(feature = "zicsr-stub", allow(unused_variables))]
            let prof_pc = self.hart.regs.pc;
            // E4-T05: when the block cache is enabled, decode is served from the memoized block
            // (via `step_cached`); everything ELSE in this loop body — the per-op device sync,
            // `next_interrupt`, `advance_clock`, `on_retire`, and the profiler hook — is UNCHANGED
            // and still runs PER RETIRE. So the ONLY cache-on vs cache-off difference is memoized
            // decode; the retire trace must be byte-identical. (Batching those is Phase C.)
            // E4-T10: at a block boundary, if the JIT is active and this block is compiled, run it
            // via the executor INSTEAD of interpreting. `try_jit_block` commits the retire clock for
            // the block's ops itself (so the per-op accounting below is skipped for a JIT run).
            #[cfg(not(feature = "zicsr-stub"))]
            let jit_attempt = if jit_on && sample_boundary && !capture.wants_records() {
                self.try_jit_block(remaining_work)
            } else {
                None
            };
            #[cfg(not(feature = "zicsr-stub"))]
            let (step_result, ran_via_jit, work_used) = match jit_attempt {
                Some(progress) => (progress.result, true, progress.work_used),
                // Mid-block: replay the rest of the block in the tight loop. It retires ops (with
                // all their per-op accounting) until the next loop-top test would leave the
                // non-boundary path; a trapping op comes back here unaccounted, exactly like a
                // trapping one-op step.
                None if tail_ok && !sample_boundary && self.hart.csr.triggers_idle() => {
                    match self.replay_block_tail(&mut remaining_work, capture) {
                        None => continue,
                        Some(trap) => (Err(trap), false, 1),
                    }
                }
                None => (capture.step(self, cache_on), false, 1),
            };
            #[cfg(feature = "zicsr-stub")]
            let (step_result, work_used) = (capture.step(self, false), 1u64);
            debug_assert!(work_used > 0 && work_used <= remaining_work);
            remaining_work -= work_used;
            // E1-T12: an instruction retired iff the step succeeded — advance the deterministic
            // retire-count clock ONLY then (a delivered trap or a taken interrupt retires nothing).
            // A JIT run already advanced the clock per retired op inside `try_jit_block`, so this
            // per-op accounting runs only for an interpreted step.
            #[cfg(not(feature = "zicsr-stub"))]
            if !ran_via_jit && step_result.is_ok() {
                self.advance_clock();
                self.irqstats.on_retire(); // E2-T20 progress denominator
                // E4-T01: hot-PC sampling — only when armed, and only 1-in-~1024 retires (a jittered
                // stride) so the histogram write is off the per-instruction hot path. We record the
                // guest VIRTUAL PC: it is what `System.map` symbolizes and the guest-virtual address
                // space a future JIT keys blocks on, so on-sample physical translation buys nothing.
                if self.profiling {
                    self.prof_countdown = self.prof_countdown.saturating_sub(1);
                    if self.prof_countdown == 0 {
                        self.prof.record_pc(prof_pc);
                        self.prof_countdown = self.prof_next_stride();
                    }
                }
                if self.hart.last_was_wfi {
                    self.after_wfi_retire();
                }
            }
            if let Err(trap) = step_result {
                // E2-T03 (ADR 0002): with the built-in SBI enabled, `ecall` from S-mode is a
                // FIRMWARE CALL, not an architectural trap — answer it in Rust and resume at
                // the next instruction (ecall is always a 4-byte encoding). a7=EID, a6=FID,
                // a0..a5=args; returns a0=error, a1=value. Everything else still traps below.
                #[cfg(not(feature = "zicsr-stub"))]
                if self.builtin_sbi && trap.cause == hart::Exception::EcallFromS {
                    let eid = self.hart.regs.read(17); // a7
                    let fid = self.hart.regs.read(16); // a6
                    let args = [
                        self.hart.regs.read(10),
                        self.hart.regs.read(11),
                        self.hart.regs.read(12),
                        self.hart.regs.read(13),
                        self.hart.regs.read(14),
                        self.hart.regs.read(15),
                    ];
                    let ret = sbi::handle(
                        &mut self.sbi_state,
                        &mut self.bus,
                        &mut self.hart,
                        eid,
                        fid,
                        &args,
                    );
                    // E2-T06 SRST: a requested shutdown ends the run NOW — the guest never
                    // executes another instruction (spec: system_reset does not return).
                    if let Some(code) = self.sbi_state.shutdown {
                        return RunOutcome::Exited(code);
                    }
                    // E2-T17 SRST: a requested reboot ends the run so the host re-boots.
                    if self.sbi_state.reboot {
                        return RunOutcome::Reset(ExitReason::Reboot);
                    }
                    self.hart.regs.write(10, ret.error as u64); // a0
                    // Legacy extensions (EID < 0x10) clobber ONLY a0 (SBI v0.1 convention).
                    if !sbi::is_legacy(eid) {
                        self.hart.regs.write(11, ret.value as u64); // a1
                    }
                    self.hart.regs.pc = self.hart.regs.pc.wrapping_add(4);
                    continue;
                }
                // E1-T10: DELIVER the trap through the CSR machinery (mepc/mcause/mtval +
                // mtvec vector) and keep running — a guest with a handler installed resumes
                // at mtvec. `step`/`execute` stay pure (they returned Err having touched
                // nothing), so `take_trap` writes the ONLY architectural effect.
                //
                // HOST CONVENTION: if NO handler is installed (mtvec BASE == 0, its reset
                // value), the trap is UNHANDLED — vectoring to address 0 would just re-trap
                // forever. Surface it to the host as `Trapped` instead, so the native runner
                // can report the cause and a bare ECALL/EBREAK is observable. Every real guest
                // (OpenSBI, the riscv-tests p-env, Linux) sets mtvec before it can trap, so
                // this only affects handler-less host-level programs and never changes the
                // architectural delivery those guests see. Under the quarantined zicsr-stub
                // there is no real CSR file, so it always escapes (the rv64ui/um/ua harnesses
                // read a7/a0 from the ECALL). Delegation to S-mode arrives in E1-T11.
                #[cfg(not(feature = "zicsr-stub"))]
                {
                    // "No handler installed" is judged against the tvec the trap will actually
                    // use: a medeleg-delegated exception taken below M vectors through stvec, so
                    // check THAT base — otherwise a guest with only stvec set (mtvec==0) would
                    // wrongly escape (E1-T11).
                    let to_s = self.hart.csr.delegates_to_s(trap.cause as u64, false);
                    let handler = if to_s {
                        self.hart.csr.stvec_base()
                    } else {
                        self.hart.csr.mtvec_base()
                    };
                    if handler == 0 {
                        return RunOutcome::Trapped(trap);
                    }
                    let epc = self.hart.regs.pc;
                    self.hart.take_trap(trap, epc);
                    self.irqstats.on_exception(trap.cause as u64); // E2-T20 storm counter
                    self.storm_check(); // livelock/storm: a trap just landed — cheap to check
                }
                #[cfg(feature = "zicsr-stub")]
                {
                    return RunOutcome::Trapped(trap);
                }
            }
            // Consult HTIF only when it is armed and the word CHANGED — this is
            // what makes command writes "logged once" rather than re-counted.
            if let Some(htif) = self.htif {
                let raw = htif.check(&mut self.bus).raw_or_zero();
                if raw != self.last_tohost {
                    self.last_tohost = raw;
                    match HtifStatus::decode(raw) {
                        HtifStatus::Exit(e) => return RunOutcome::Exited(e.code),
                        HtifStatus::Command(v) => {
                            log::debug!("HTIF command ignored: tohost={v:#018x}");
                            self.htif_commands += 1;
                        }
                        HtifStatus::Idle => {}
                    }
                }
            }
        }
        // E2-T17 (critic A2): a finisher write on the VERY LAST budgeted instruction latches
        // the reset cell but the top-of-loop drain never runs again. Drain it once more here
        // so a poweroff/reboot on the final instruction isn't misreported as MaxInstrs.
        #[cfg(not(feature = "zicsr-stub"))]
        if let Some(reason) = self.syscon.as_ref().and_then(|c| *c.borrow()) {
            return RunOutcome::Reset(reason);
        }
        RunOutcome::MaxInstrs
    }
}

/// The memory footprint (bytes from `KERNEL_BASE`) of a RISC-V Linux `Image`. Returns
/// `image_size` from the Image header when the header is valid and larger than the file;
/// otherwise the raw file length (a kernel without the header, or a truncated/foreign blob,
/// still loads and the caller gets a safe lower bound).
///
/// Header layout (arch/riscv/kernel/head.S `_start`): `code0`(4) `code1`(4) `text_offset`(8)
/// `image_size`(8) `flags`(8) `version`(4) `res1`(4) `res2`(8) `magic`(8, deprecated
/// `"RISCV\0\0\0"` at 0x30) then the 4-byte `magic2 = "RSC\x05"` at offset **0x38**. We key
/// off `magic2`, which is stable across the header revisions that carry `image_size`.
///
/// Limitation: a pre-4.6 kernel (or one built without CONFIG) can leave `image_size == 0`
/// ("unbounded"); we then fall back to `file_len`, which under-reports the `.bss` footprint
/// and could mis-place the initrd. Every kernel we ship (6.6.63) sets it, and the boot glue's
/// RAM ceiling still prevents an overflow — but an image_size-0 kernel is unsupported here.
fn kernel_image_footprint(bytes: &[u8]) -> u64 {
    let file_len = bytes.len() as u64;
    if bytes.len() >= 0x3c && &bytes[0x38..0x3c] == b"RSC\x05" {
        let image_size = u64::from_le_bytes(bytes[16..24].try_into().unwrap());
        if image_size > file_len {
            return image_size;
        }
    }
    file_len
}

#[cfg(all(test, not(feature = "zicsr-stub")))]
mod pmp_audit_tests;

#[cfg(all(test, not(feature = "zicsr-stub")))]
mod decoded_cache_capacity_tests;

#[cfg(all(test, not(feature = "zicsr-stub")))]
mod clock_advance_tests;

#[cfg(all(test, not(feature = "zicsr-stub")))]
mod partial_resume_tests;

#[cfg(all(test, not(feature = "zicsr-stub")))]
mod paced_idle_clock_tests;

#[cfg(test)]
mod tests {
    use super::*;

    /// The quiescent-fabric fast path must be unobservable: an interrupt-driven UART echo plus an
    /// RTC alarm, whose level changes come from host input between runs (while the guest is
    /// parked in a device-silent spin), from guest MMIO mid-run (IER/alarm arm/claim/RBR/
    /// complete), from the UART char-timeout clock, and from an RTC clock that only advances when
    /// polled, retires the identical instruction stream, output, and machine state with the fast
    /// path forced off — in legacy, cache-only and batched modes, across slicings that split
    /// blocks.
    #[cfg(not(feature = "zicsr-stub"))]
    #[test]
    fn fabric_quiescence_fast_path_is_unobservable() {
        use crate::bus::Bus;
        use crate::resume::ComponentSnapshot;
        use crate::trace::HashSink;
        fn i_type(imm: i32, rs1: u32, f3: u32, rd: u32, op: u32) -> u32 {
            (((imm as u32) & 0xFFF) << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | op
        }
        let addi = |rd, rs1, imm| i_type(imm, rs1, 0, rd, 0x13);
        let lui = |rd: u32, imm20: u32| (imm20 << 12) | (rd << 7) | 0x37;
        let csrrw =
            |rd: u32, csr: u32, rs1: u32| (csr << 20) | (rs1 << 15) | (1 << 12) | (rd << 7) | 0x73;
        let csrrs =
            |rd: u32, csr: u32, rs1: u32| (csr << 20) | (rs1 << 15) | (2 << 12) | (rd << 7) | 0x73;
        let lw = |rd, rs1, imm| i_type(imm, rs1, 2, rd, 0x03);
        let lb = |rd, rs1, imm| i_type(imm, rs1, 0, rd, 0x03);
        let s_type = |imm: i32, rs2: u32, rs1: u32, f3: u32| {
            let iu = (imm as u32) & 0xFFF;
            ((iu >> 5) << 25) | (rs2 << 20) | (rs1 << 15) | (f3 << 12) | ((iu & 0x1F) << 7) | 0x23
        };
        let sw = |rs2, rs1, imm| s_type(imm, rs2, rs1, 2);
        let sb = |rs2, rs1, imm| s_type(imm, rs2, rs1, 0);
        const SRET: u32 = 0x1020_0073;
        // main: stvec, sie.SEIE, sstatus.SIE, PLIC prio/enable/threshold for UART IRQ 10 on the
        // S context, then a few hundred device-silent instructions before UART IER is enabled
        // by guest MMIO (input may already be pending), then a counting spin loop.
        let mut code = alloc::vec![
            lui(5, 0x80201),
            addi(5, 5, -0x800),
            i_type(32, 5, 1, 5, 0x13),
            i_type(32, 5, 5, 5, 0x13),
            csrrw(0, 0x105, 5),
            addi(5, 0, 0x200),
            csrrs(0, 0x104, 5),
            addi(5, 0, 0x2),
            csrrs(0, 0x100, 5),
            lui(5, 0x0C000),
            addi(6, 0, 1),
            sw(6, 5, 0x28),
            addi(6, 0, 1),
            sw(6, 5, 0x2C),
            lui(5, 0x0C002),
            addi(6, 0, 0x400),
            addi(6, 6, 0x400),
            addi(6, 6, 0x400),
            sw(6, 5, 0x80),
            lui(5, 0x0C201),
            sw(0, 5, 0),
            lui(7, 0x10000),
            // RTC: IRQ_ENABLED = 1, alarm = 4096 ns of a clock that ticks once per poll.
            lui(30, 0x00101),
            addi(6, 0, 1),
            sw(6, 30, 0x10),
            sw(0, 30, 0x0c),
            lui(6, 1),
            sw(6, 30, 0x08),
        ];
        // Device-silent countdown (3000 iterations = 3000 boundaries even when batched) so the
        // UART char-timeout clock latches and the fabric goes QUIESCENT before the guest's own
        // IER store must raise the level: only the MMIO epoch bump can wake the full sync here.
        let bne_back =
            (1 << 31) | (0x3F << 25) | (9 << 15) | (1 << 12) | (0b1110 << 8) | (1 << 7) | 0x63;
        code.extend([lui(9, 1), addi(9, 9, -1096), addi(9, 9, -1), bne_back]);
        // FCR: FIFOs on, RX trigger level 8 — so short input interrupts ONLY via the UART's
        // char-timeout clock, which must keep ticking at boundaries while the guest spins.
        // Then IER = ERBFI.
        code.extend([addi(6, 0, 0x81), sb(6, 7, 2), addi(6, 0, 0x01), sb(6, 7, 1)]);
        code.extend([addi(8, 8, 1), 0xffdf_f06f]); // spin: addi x8,x8,1 ; j -4
        // handler: claim, IIR, RBR -> THR echo, complete, sret.
        let handler = [
            addi(28, 28, 1),
            lui(5, 0x0C201),
            lw(6, 5, 4),
            lb(29, 7, 2),
            lb(31, 7, 0),
            sb(31, 7, 0),
            sw(0, 30, 0x1c), // RTC CLEAR_INTERRUPT (harmless for a UART claim)
            sw(6, 5, 4),
            SRET,
        ];
        struct PolledClock(alloc::rc::Rc<core::cell::Cell<u64>>);
        impl dev::rtc::WallClock for PolledClock {
            fn now_ns(&self) -> u64 {
                let now = self.0.get();
                self.0.set(now + 1);
                now
            }
        }
        let run = |block_cache: bool, batching: bool, fast_off: bool, slices: &[u64]| {
            let mut m = Machine::new(8 * 1024 * 1024);
            m.enable_clint(10);
            m.enable_plic();
            let uart = m.enable_uart16550();
            let clock = alloc::rc::Rc::new(core::cell::Cell::new(0));
            let rtc = m.enable_rtc(alloc::boxed::Box::new(PolledClock(alloc::rc::Rc::clone(
                &clock,
            ))));
            let _ = m.enable_virtio_slots(None);
            let _ = m.enable_virtio_keyboard();
            // A loopback virtio-net (behind the switchable adapter, as the hosts attach it): an
            // idle synchronous backend must not keep the fabric out of the fast path.
            let _ = m.enable_virtio_net(alloc::boxed::Box::new(
                dev::virtio::net::LoopbackBackend::new(),
            ));
            m.enable_builtin_sbi();
            m.boot_supervisor(0, 0);
            m.set_block_cache(block_cache);
            m.set_interrupt_batching(batching);
            m.fabric_fast_path_off = fast_off;
            for (i, insn) in code.iter().enumerate() {
                m.bus_mut()
                    .store32(platform::virt::KERNEL_BASE + 4 * i as u64, *insn)
                    .unwrap();
            }
            for (i, insn) in handler.iter().enumerate() {
                m.bus_mut()
                    .store32(platform::virt::KERNEL_BASE + 0x800 + 4 * i as u64, *insn)
                    .unwrap();
            }
            uart.borrow_mut().push_input(b"a");
            let mut trace = HashSink::new();
            let mut out = alloc::vec::Vec::new();
            let inputs: [&[u8]; 5] = [b"b", b"", b"cd", b"e", b""];
            for (round, input) in inputs.iter().enumerate() {
                let mut remaining = 20_000u64;
                let mut step = round;
                while remaining > 0 {
                    let budget = remaining.min(slices[step % slices.len()]);
                    assert_eq!(m.run_traced(budget, &mut trace), RunOutcome::MaxInstrs);
                    remaining -= budget;
                    step += 1;
                }
                out.extend(uart.borrow_mut().take_output());
                uart.borrow_mut().push_input(input);
            }
            assert!(
                !rtc.borrow().alarm_armed(),
                "the alarm fired inside the run"
            );
            let rtc_claims = m.plic.as_ref().unwrap().borrow().claim_counts()[11];
            out.retain(|&byte| byte != 0); // the RTC claim echoes an empty RBR
            (
                (
                    trace.hash(),
                    trace.retired(),
                    out,
                    rtc_claims,
                    clock.get(),
                    m.snapshot(),
                    m.hart.to_snapshot(),
                ),
                m.fabric_fast_hits,
            )
        };
        for (block_cache, batching) in [(false, false), (true, false), (true, true)] {
            for slices in [&[20_000][..], &[1, 7, 333][..], &[4096, 3][..]] {
                let (control, full_hits) = run(block_cache, batching, true, slices);
                let (fast, fast_hits) = run(block_cache, batching, false, slices);
                assert_eq!(full_hits, 0);
                assert!(fast_hits > 0, "the quiescent path must actually engage");
                assert_eq!(
                    fast, control,
                    "cache={block_cache} batching={batching} {slices:?}"
                );
                assert_eq!(
                    control.2, b"abcde",
                    "every byte echoed through the IRQ path"
                );
                assert_eq!(control.3, 1, "one RTC alarm interrupt");
            }
        }
    }

    /// The mid-block replay loop retires the identical instruction stream and leaves the identical
    /// machine state as the general loop body, under trace capture and unit capture and across run
    /// slicings that split blocks. The workload puts, INSIDE straight-line blocks: RAM stores and
    /// loads, a load access fault (a trapping mid-block op, delivered to an S handler), a store
    /// that rewrites a later op of the same block (self-modifying code: the drain drops the cursor
    /// mid-block and the rest re-decodes), an execute-address debug trigger on a mid-block op
    /// (which must keep that block on the general path), and a syscon poweroff store followed by
    /// more ops (the run must stop before the next op).
    /// The replay loop's deferred retire accounting must be unobservable: runs of pure integer ops
    /// settle `mcycle`/`minstret`, the ICount `mtime` clock and the progress counter in bulk, so
    /// every op that can observe them — a CLINT `mtime` MMIO load mid-block, `csrr minstret` /
    /// `csrr mcycle` / `csrr time` terminators, a `csrw minstret` whose own tick is suppressed —
    /// must see exactly the per-retire values. M-mode, compared against the general per-op loop
    /// (replay loop forced off) with traced and unit capture across slicings that split blocks.
    #[cfg(not(feature = "zicsr-stub"))]
    #[test]
    fn deferred_retire_accounting_is_unobservable() {
        use crate::bus::Bus;
        use crate::resume::ComponentSnapshot;
        use crate::trace::HashSink;
        fn i_type(imm: i32, rs1: u32, f3: u32, rd: u32, op: u32) -> u32 {
            (((imm as u32) & 0xFFF) << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | op
        }
        fn r_type(f7: u32, rs2: u32, rs1: u32, f3: u32, rd: u32) -> u32 {
            (f7 << 25) | (rs2 << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | 0x33
        }
        let addi = |rd, rs1, imm| i_type(imm, rs1, 0, rd, 0x13);
        let add = |rd, rs1, rs2| r_type(0, rs2, rs1, 0, rd);
        let sub = |rd, rs1, rs2| r_type(0x20, rs2, rs1, 0, rd);
        let xor = |rd, rs1, rs2| r_type(0, rs2, rs1, 4, rd);
        let mul = |rd, rs1, rs2| r_type(1, rs2, rs1, 0, rd);
        let ld = |rd, rs1, imm| i_type(imm, rs1, 3, rd, 0x03);
        let lui = |rd: u32, imm20: u32| ((imm20 & 0xF_FFFF) << 12) | (rd << 7) | 0x37;
        let csrrs =
            |rd: u32, csr: u32, rs1: u32| (csr << 20) | (rs1 << 15) | (2 << 12) | (rd << 7) | 0x73;
        let csrrw =
            |rd: u32, csr: u32, rs1: u32| (csr << 20) | (rs1 << 15) | (1 << 12) | (rd << 7) | 0x73;
        let bne_back = |ops: i32| {
            let o = (-(4 * ops)) as u32;
            (((o >> 12) & 1) << 31)
                | (((o >> 5) & 0x3F) << 25)
                | (11 << 15)
                | (1 << 12)
                | (((o >> 1) & 0xF) << 8)
                | (((o >> 11) & 1) << 7)
                | 0x63
        };
        const JDOT: u32 = 0x0000_006F;
        const MCYCLE: u32 = 0xB00;
        const MINSTRET: u32 = 0xB02;
        const TIME: u32 = 0xC01;
        let base = platform::virt::KERNEL_BASE;
        let mtime = bus::mmap::CLINT_BASE + 0xBFF8;
        assert!(mtime < 0x8000_0000 && mtime & 0xFFF == 0xFF8);
        let mut code = alloc::vec![
            lui(10, ((mtime + 0x1000) >> 12) as u32), // x10 = mtime (lo12 = -8)
            addi(11, 0, 300),                         // loop count
        ];
        let lp = code.len();
        code.extend([
            addi(5, 5, 1),
            addi(6, 6, 3),
            xor(7, 5, 6),
            add(8, 8, 7),
            ld(9, 10, -8), // CLINT mtime after four deferrable ops
            addi(5, 5, 1),
            mul(12, 5, 6),
            add(13, 13, 9),
            csrrs(14, MINSTRET, 0), // counters after three deferrable ops
            addi(15, 15, 1),
            add(16, 16, 14),
            csrrs(17, MCYCLE, 0),
            addi(18, 18, 5),
            csrrw(0, MINSTRET, 18), // suppresses its own minstret tick
            addi(19, 19, 1),
            sub(20, 20, 19),
            csrrs(21, TIME, 0),
            addi(22, 22, 7),
            add(23, 23, 21),
            addi(11, 11, -1),
        ]);
        let back = (code.len() - lp) as i32;
        code.push(bne_back(back));
        code.push(JDOT);
        let run = |tail_off: bool, traced: bool, slices: &[u64]| {
            let mut m = Machine::new(8 * 1024 * 1024);
            m.enable_clint(3);
            m.hart.csr.pmp.allow_all();
            m.set_block_cache(true);
            m.set_interrupt_batching(true);
            m.replay_tail_off = tail_off;
            for (i, insn) in code.iter().enumerate() {
                m.bus_mut().store32(base + 4 * i as u64, *insn).unwrap();
            }
            m.hart.regs.pc = base;
            let mut trace = HashSink::new();
            let mut total = 0u64;
            let mut step = 0;
            while total < 12_000 {
                let budget = slices[step % slices.len()];
                step += 1;
                total += budget;
                let outcome = if traced {
                    m.run_traced(budget, &mut trace)
                } else {
                    m.run(budget)
                };
                assert_eq!(outcome, RunOutcome::MaxInstrs);
            }
            let regs: alloc::vec::Vec<u64> = (0..32).map(|r| m.hart.regs.read(r)).collect();
            assert!(
                regs[9] > 100,
                "the loop must observe an advancing mtime: {}",
                regs[9]
            );
            (
                (
                    trace.hash(),
                    trace.retired(),
                    regs,
                    m.clint_mtime(),
                    m.snapshot(),
                    m.hart.to_snapshot(),
                ),
                m.replay_deferred_ops,
            )
        };
        for traced in [true, false] {
            for slices in [&[1_000_000][..], &[1, 7, 333][..], &[5, 3][..], &[2][..]] {
                let (control, off_deferred) = run(true, traced, slices);
                let (fast, deferred) = run(false, traced, slices);
                assert_eq!(off_deferred, 0);
                assert!(
                    deferred > 1000,
                    "deferred accounting must engage: {deferred}"
                );
                assert_eq!(control, fast, "traced={traced} slices={slices:?}");
            }
        }
    }

    #[cfg(not(feature = "zicsr-stub"))]
    #[test]
    fn replay_block_tail_is_unobservable() {
        use crate::bus::Bus;
        use crate::csr::{CsrOp, Priv, TDATA1, TDATA2, TSELECT};
        use crate::resume::ComponentSnapshot;
        use crate::trace::HashSink;
        fn i_type(imm: i32, rs1: u32, f3: u32, rd: u32, op: u32) -> u32 {
            (((imm as u32) & 0xFFF) << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | op
        }
        fn s_type(imm: i32, rs2: u32, rs1: u32, f3: u32) -> u32 {
            let iu = (imm as u32) & 0xFFF;
            ((iu >> 5) << 25) | (rs2 << 20) | (rs1 << 15) | (f3 << 12) | ((iu & 0x1F) << 7) | 0x23
        }
        fn b_type(off: i32, rs2: u32, rs1: u32, f3: u32) -> u32 {
            let o = off as u32;
            (((o >> 12) & 1) << 31)
                | (((o >> 5) & 0x3F) << 25)
                | (rs2 << 20)
                | (rs1 << 15)
                | (f3 << 12)
                | (((o >> 1) & 0xF) << 8)
                | (((o >> 11) & 1) << 7)
                | 0x63
        }
        let addi = |rd, rs1, imm| i_type(imm, rs1, 0, rd, 0x13);
        let xor =
            |rd: u32, rs1: u32, rs2: u32| (rs2 << 20) | (rs1 << 15) | (4 << 12) | (rd << 7) | 0x33;
        let add = |rd: u32, rs1: u32, rs2: u32| (rs2 << 20) | (rs1 << 15) | (rd << 7) | 0x33;
        let lui = |rd: u32, imm20: u32| ((imm20 & 0xF_FFFF) << 12) | (rd << 7) | 0x37;
        let li32 = |rd: u32, v: u32| {
            let lo = ((v & 0xFFF) as i32) << 20 >> 20;
            let hi = v.wrapping_sub(lo as u32) >> 12;
            [lui(rd, hi), addi(rd, rd, lo)]
        };
        // A zero-extended 32-bit address (RV64 `lui` sign-extends bit 31): li32 + slli/srli 32.
        let la = |rd: u32, v: u32| {
            let [hi, lo] = li32(rd, v);
            [
                hi,
                lo,
                i_type(32, rd, 1, rd, 0x13),
                i_type(32, rd, 5, rd, 0x13),
            ]
        };
        let lw = |rd, rs1, imm| i_type(imm, rs1, 2, rd, 0x03);
        let sw = |rs2, rs1, imm| s_type(imm, rs2, rs1, 2);
        let csrrw =
            |rd: u32, csr: u32, rs1: u32| (csr << 20) | (rs1 << 15) | (1 << 12) | (rd << 7) | 0x73;
        let csrrs =
            |rd: u32, csr: u32, rs1: u32| (csr << 20) | (rs1 << 15) | (2 << 12) | (rd << 7) | 0x73;
        const SRET: u32 = 0x1020_0073;
        const JDOT: u32 = 0x0000_006F;
        let base = platform::virt::KERNEL_BASE;
        // The self-modified op (index `PATCHED`) alternates between these two encodings.
        let enc_a = addi(22, 22, 7);
        let enc_b = addi(22, 22, 1);
        let mut code = alloc::vec::Vec::new();
        code.extend(la(6, (base + 0x800) as u32)); // x6 = handler
        code.push(csrrw(0, 0x105, 6)); // stvec = handler
        code.extend(la(10, (base + 0x3000) as u32)); // x10 = data page
        code.push(addi(11, 0, 150)); // loop count
        code.extend(la(12, base as u32)); // x12 = code base (SMC target)
        code.extend(li32(19, enc_a)); // x19 = first patch value
        code.extend(li32(23, enc_a ^ enc_b)); // x23 = toggle mask
        let lp = code.len();
        let (patched, triggered) = (lp + 12, lp + 3);
        code.extend([
            addi(13, 13, 3),                  // +0
            sw(13, 10, 0),                    // +1 RAM store
            lw(14, 10, 0),                    // +2 RAM load
            xor(15, 14, 13),                  // +3 (execute trigger here in one variant)
            add(16, 16, 14),                  // +4
            lw(17, 0, 0),                     // +5 load access fault -> handler skips it
            addi(18, 18, 1),                  // +6
            sw(19, 12, (4 * patched) as i32), // +7 rewrite op +12 (same block, ahead)
            addi(20, 20, 1),                  // +8
            addi(21, 21, 1),                  // +9
            xor(19, 19, 23),                  // +10 toggle the next patch value
            add(24, 24, 22),                  // +11
            enc_b,                            // +12 (overwritten before it runs)
            add(25, 25, 22),                  // +13
            addi(11, 11, -1),                 // +14
            b_type(-(4 * 15), 0, 11, 1),      // +15 bne x11, x0, loop
        ]);
        // Poweroff through the syscon finisher mid-block, then ops that must never run.
        code.extend(la(26, platform::virt::TEST_BASE as u32));
        code.extend(li32(27, 0x5555));
        code.push(sw(27, 26, 0));
        code.extend([addi(28, 28, 1), addi(28, 28, 1), JDOT]);
        let handler = [
            csrrs(5, 0x141, 0), // sepc
            addi(5, 5, 4),
            csrrw(0, 0x141, 5),
            addi(29, 29, 1),
            SRET,
        ];
        let run = |tail_off: bool, traced: bool, trigger: bool, slices: &[u64]| {
            let mut m = Machine::new(8 * 1024 * 1024);
            m.enable_clint(10);
            m.enable_plic();
            m.enable_syscon();
            m.enable_builtin_sbi();
            m.boot_supervisor(0, 0);
            m.set_block_cache(true);
            m.set_interrupt_batching(true);
            m.replay_tail_off = tail_off;
            for (i, insn) in code.iter().enumerate() {
                m.bus_mut().store32(base + 4 * i as u64, *insn).unwrap();
            }
            for (i, insn) in handler.iter().enumerate() {
                m.bus_mut()
                    .store32(base + 0x800 + 4 * i as u64, *insn)
                    .unwrap();
            }
            if trigger {
                let mode = m.hart.csr.mode;
                m.hart.csr.mode = Priv::M;
                for (csr, v) in [
                    (TSELECT, 0),
                    (TDATA2, base + 4 * triggered as u64),
                    (TDATA1, (2u64 << 60) | (1 << 4) | (1 << 2)),
                ] {
                    m.hart
                        .csr
                        .access(csr, CsrOp::Write, v, false, false, 0)
                        .unwrap();
                }
                m.hart.csr.mode = mode;
                assert!(!m.hart.csr.triggers_idle());
            }
            let mut trace = HashSink::new();
            let mut outcomes = alloc::vec::Vec::new();
            let mut step = 0;
            let mut total = 0u64;
            while total < 200_000 {
                let budget = slices[step % slices.len()];
                step += 1;
                total += budget;
                let outcome = if traced {
                    m.run_traced(budget, &mut trace)
                } else {
                    m.run(budget)
                };
                outcomes.push(outcome);
                if outcome != RunOutcome::MaxInstrs {
                    break;
                }
            }
            let regs: alloc::vec::Vec<u64> = (0..32).map(|r| m.hart.regs.read(r)).collect();
            (
                (
                    trace.hash(),
                    trace.retired(),
                    outcomes,
                    regs,
                    m.snapshot(),
                    m.hart.to_snapshot(),
                ),
                m.replay_tail_ops,
            )
        };
        for trigger in [false, true] {
            for traced in [true, false] {
                for slices in [
                    &[1_000_000][..],
                    &[1, 7, 333][..],
                    &[4096, 3][..],
                    &[2, 5][..],
                ] {
                    let (control, off_ops) = run(true, traced, trigger, slices);
                    let (fast, tail_ops) = run(false, traced, trigger, slices);
                    assert_eq!(off_ops, 0);
                    if trigger {
                        // An armed execute trigger keeps every block on the general path.
                        assert_eq!(tail_ops, 0, "an armed trigger must disable the replay loop");
                    } else {
                        assert!(tail_ops > 1000, "the replay loop must actually engage");
                    }
                    assert_eq!(
                        fast, control,
                        "trigger={trigger} traced={traced} {slices:?}"
                    );
                    let (_, _, outcomes, regs, _, _) = &control;
                    assert_eq!(
                        outcomes.last(),
                        Some(&RunOutcome::Reset(ExitReason::PowerOff)),
                        "the guest reached the poweroff store"
                    );
                    assert_eq!(regs[28], 0, "no op after the poweroff store ran");
                    assert_eq!(regs[11], 0, "the loop ran to completion");
                    // 150 iterations; the patched op alternates +7 / +1 starting with +7.
                    assert_eq!(
                        regs[22],
                        75 * 7 + 75,
                        "every rewrite executed its new bytes"
                    );
                    let traps = regs[29];
                    let expected = if trigger { 300 } else { 150 };
                    assert_eq!(
                        traps, expected,
                        "each fault (and trigger) trapped once per pass"
                    );
                }
            }
        }
    }

    #[cfg(not(feature = "zicsr-stub"))]
    #[test]
    fn cold_counter_recycling_retired_trace_architecture_parity_varied_schedules() {
        use crate::bus::{Bus, mmap::DRAM_BASE};
        use crate::resume::ComponentSnapshot;
        use crate::trace::HashSink;
        for flood in [4u64, 5, 9, 17] {
            let run = |enabled: bool, slices: &[u64]| {
                let mut m = Machine::new(64 * 1024);
                for i in 0..flood {
                    m.bus_mut().store32(DRAM_BASE + i * 4, 0x0040_006f).unwrap(); // jal +4
                }
                let hot = DRAM_BASE + flood * 4;
                m.bus_mut().store32(hot, 0x0010_8093).unwrap(); // addi x1,x1,1
                m.bus_mut().store32(hot + 4, 0xffdf_f06f).unwrap(); // jal -4
                m.hart.regs.pc = DRAM_BASE;
                m.set_block_cache(true);
                m.set_interrupt_batching(true);
                m.discovery = dispatch::BlockDiscovery::with_bounds(4, 4);
                m.set_hotness_threshold(512);
                m.set_cold_counter_recycling(enabled);
                assert!(!m.profiling && m.host_timer.is_none());
                // This is actual retired guest execution through discovery, not a claim
                // that a synthetic executor implements native/browser compiled semantics.
                assert!(m.executor.is_none());
                let mut trace = HashSink::new();
                let total = flood + 2 * (512 + 17);
                let mut remaining = total;
                let mut step = 0;
                while remaining > 0 {
                    let budget = remaining.min(slices[step % slices.len()]);
                    assert_eq!(m.run_traced(budget, &mut trace), RunOutcome::MaxInstrs);
                    remaining -= budget;
                    step += 1;
                }
                assert_eq!(trace.retired(), total);
                assert_eq!(m.hart.regs.read(1), 529);
                assert_eq!(m.discovery_stats().nominated, u64::from(enabled));
                assert_eq!(m.cold_counter_recycling_stats().epochs > 0, enabled);
                if enabled {
                    let requests = m.take_translation_requests();
                    assert_eq!(requests.len(), 1);
                    assert_eq!(requests[0].phys_pc, hot);
                } else {
                    assert!(m.discovery_stats().counts_dropped >= 529);
                }
                (
                    trace.hash(),
                    trace.retired(),
                    m.snapshot(),
                    m.hart.to_snapshot(),
                )
            };
            let control = run(false, &[10_000]);
            for slices in [&[10_000][..], &[1, 7, 31, 3][..], &[127, 2, 64][..]] {
                assert_eq!(run(false, slices), control);
                assert_eq!(run(true, slices), control);
            }
        }
    }

    #[cfg(not(feature = "zicsr-stub"))]
    #[test]
    fn cold_counter_recycling_preserves_compile_queue_cache_and_installed_sentinel() {
        use crate::bus::mmap::DRAM_BASE;
        use crate::dispatch::{DecodedBlock, MicroOp};
        use crate::resume::ComponentSnapshot;
        // Synthetic residency sentinel: every mutation/execution callback is forbidden.
        // This tests preservation, not translation or a real JIT execution result.
        struct InstalledSentinel(u64);
        impl jit::CompiledBlockExecutor for InstalledSentinel {
            fn install(&mut self, _: &DecodedBlock) {
                panic!("unexpected install");
            }
            fn is_compiled(&self, pc: u64) -> bool {
                pc == self.0
            }
            fn execute(
                &mut self,
                _: u64,
                _: &mut hart::Hart,
                _: &mut mmio::SystemBus,
            ) -> Option<jit::JitExit> {
                panic!("unexpected execution");
            }
            fn invalidate_all(&mut self) {
                panic!("recycling invalidated installed code");
            }
            fn invalidate_page(&mut self, _: u64) {
                panic!("recycling invalidated a page");
            }
            fn compiled_count(&self) -> usize {
                1
            }
            fn executed_blocks(&self) -> u64 {
                0
            }
            fn retired_via_jit(&self) -> u64 {
                0
            }
        }
        let raw = 0x0000_006f;
        let ops = [MicroOp {
            instr: decode::decode(raw).unwrap(),
            raw,
            len: 4,
        }];
        let mut m = Machine::new(64 * 1024);
        m.set_block_cache(true);
        m.discovery = dispatch::BlockDiscovery::with_bounds(4, 2);
        m.set_hotness_threshold(512);
        m.block_cache
            .insert(DecodedBlock::new(DRAM_BASE, ops.to_vec(), 4));
        m.set_executor(alloc::boxed::Box::new(InstalledSentinel(DRAM_BASE)));
        for phys in [DRAM_BASE, DRAM_BASE + 16, DRAM_BASE + 32] {
            for _ in 0..512 {
                m.discovery.on_block_entry(phys, &ops);
            }
        }
        for _ in 0..9 {
            m.discovery.on_block_entry(DRAM_BASE + 16, &ops);
        }
        let requests = m.discovery.take_requests_bounded(2);
        for req in &requests {
            m.compile_queue.push(compile_queue::CompileJob {
                req: req.clone(),
                hotness: m.discovery.queued_hotness(req.phys_pc),
            });
        }
        for phys in [DRAM_BASE + 64, DRAM_BASE + 80] {
            m.discovery.on_block_entry(phys, &ops);
        }
        let pending = m.discovery.peek_request().unwrap().clone();
        let queue = m.compile_queue_stats();
        let generation = m.discovery.generation();
        let memory = m.snapshot();
        let hart = m.hart.to_snapshot();
        let cache = m.block_cache.invalidation_stats();
        m.set_cold_counter_recycling(true);
        m.discovery.on_block_entry(DRAM_BASE + 96, &ops);
        assert_eq!(m.cold_counter_recycling_stats().epochs, 1);
        assert_eq!(m.cold_counter_recycling_stats().discarded_counters, 2);
        assert_eq!(m.discovery.generation(), generation);
        assert_eq!(m.discovery.peek_request(), Some(&pending));
        assert_eq!(m.compile_queue_stats(), queue);
        assert!(
            requests
                .iter()
                .all(|req| m.compile_queue.contains_request(req))
        );
        assert!(m.compile_queue.take_recount().is_empty());
        assert_eq!(m.block_cache.get(DRAM_BASE).unwrap().ops, ops);
        assert_eq!(m.block_cache.invalidation_stats(), cache);
        assert!(m.executor().unwrap().is_compiled(DRAM_BASE));
        assert_eq!(m.executor().unwrap().compiled_count(), 1);
        assert_eq!(m.snapshot(), memory);
        assert_eq!(m.hart.to_snapshot(), hart);
        assert!(!m.profiling && m.host_timer.is_none());
        let hottest = m.compile_queue.pop_hottest().unwrap();
        assert_eq!(hottest.req, requests[1]);
        assert_eq!(hottest.hotness, 521);
        assert_eq!(m.compile_queue.pop_hottest().unwrap().req, requests[0]);
    }

    #[cfg(not(feature = "zicsr-stub"))]
    #[test]
    fn cold_counter_recycling_smc_stale_generation_and_live_byte_guards() {
        use crate::bus::{Bus, mmap::DRAM_BASE};
        use crate::trace::HashSink;
        for enabled in [false, true] {
            let mut m = Machine::new(64 * 1024);
            m.bus_mut().store32(DRAM_BASE, 0x0010_8093).unwrap();
            m.bus_mut().store32(DRAM_BASE + 4, 0xffdf_f06f).unwrap();
            m.hart.regs.pc = DRAM_BASE;
            m.set_block_cache(true);
            m.discovery = dispatch::BlockDiscovery::with_bounds(4, 1);
            m.set_hotness_threshold(512);
            m.set_cold_counter_recycling(enabled);
            assert_eq!(
                m.run_traced(1024, &mut HashSink::new()),
                RunOutcome::MaxInstrs
            );
            let stale = m.take_translation_requests().pop().unwrap();
            let ops = m.block_cache.get(DRAM_BASE).unwrap().ops.clone();
            m.discovery.on_block_entry(DRAM_BASE + 4096, &ops);
            m.discovery.on_block_entry(DRAM_BASE + 8192, &ops);
            assert_eq!(m.cold_counter_recycling_stats().epochs, u64::from(enabled));
            assert!(m.discovery_install_check(&stale, &stale.code_bytes));
            let mut changed = stale.code_bytes.clone();
            changed[..4].copy_from_slice(&0x0020_8093u32.to_le_bytes());
            assert!(
                !m.discovery_install_check(&stale, &changed),
                "live bytes alone must reject stale work"
            );
            m.bus_mut().store32(DRAM_BASE, 0x0020_8093).unwrap();
            m.drain_code_writes(); // Real code-page write invalidation, not a fabricated generation.
            assert_eq!(m.discovery.generation(), stale.generation + 1);
            assert!(m.block_cache.get(DRAM_BASE).is_none());
            assert!(
                !m.discovery_install_check(&stale, &stale.code_bytes),
                "generation alone must reject"
            );
            assert!(!m.discovery_install_check(&stale, &changed));
            assert_eq!(
                m.run_traced(1024, &mut HashSink::new()),
                RunOutcome::MaxInstrs
            );
            let fresh = m.take_translation_requests().pop().unwrap();
            assert_eq!(fresh.generation, stale.generation + 1);
            assert_eq!(fresh.code_bytes, changed);
            assert!(m.discovery_install_check(&fresh, &changed));
            assert_eq!(m.hart.regs.read(1), 1536);
        }
    }

    #[cfg(not(feature = "zicsr-stub"))]
    #[test]
    fn admission_probe_enabled_disabled_trace_state_and_nomination_parity() {
        use crate::bus::{Bus, mmap::DRAM_BASE};
        use crate::resume::ComponentSnapshot;
        use crate::trace::HashSink;
        let run = |enabled| {
            let mut m = Machine::new(64 * 1024);
            // 100 iterations nominate the first loop. One fall-through jump then fills the
            // one-slot counter map; the final recurring loop is actually refused while full.
            let words = [
                0xfff1_0113,
                0xfe01_1ee3,
                0x0040_006f,
                0x0010_8093,
                0xffdf_f06f,
            ];
            for (i, word) in words.into_iter().enumerate() {
                m.bus_mut().store32(DRAM_BASE + i as u64 * 4, word).unwrap();
            }
            m.hart.regs.pc = DRAM_BASE;
            m.hart.regs.write(2, 100);
            m.set_block_cache(true);
            m.set_interrupt_batching(true);
            m.discovery = dispatch::BlockDiscovery::with_bounds(4, 1);
            m.set_hotness_threshold(8);
            m.set_admission_probe(enabled);
            assert!(!m.profiling);
            assert!(m.host_timer.is_none());
            let mut trace = HashSink::new();
            let outcome = m.run_traced(1000, &mut trace);
            let probe = m.admission_probe_stats();
            assert_eq!(probe.enabled, enabled);
            if enabled {
                assert_eq!(probe.records.len(), 1);
                assert_eq!(probe.records[0].request.phys_pc, DRAM_BASE + 12);
                assert!(probe.records[0].reasons.counts_full > 100);
                assert_eq!(probe.records[0].executor_resident_at_report, None);
                assert_eq!(probe, m.admission_probe_stats(), "report must be read-only");
            } else {
                assert!(probe.records.is_empty());
            }
            assert_eq!(m.discovery_stats().nominated, 1);
            (
                trace.hash(),
                trace.retired(),
                outcome,
                m.snapshot(),
                m.hart.to_snapshot(),
                m.discovery_stats(),
                m.take_translation_requests(),
            )
        };
        assert_eq!(run(false), run(true));
    }

    #[test]
    fn kernel_footprint_honours_image_size() {
        // A minimal header: image_size at offset 16, RSC\x05 magic at 0x3c.
        let mut img = alloc::vec![0u8; 0x3c];
        img[16..24].copy_from_slice(&0x0011_4d00u64.to_le_bytes());
        img[0x38..0x3c].copy_from_slice(b"RSC\x05");
        assert_eq!(kernel_image_footprint(&img), 0x0011_4d00);
    }

    #[test]
    fn kernel_footprint_falls_back_to_file_len() {
        // No magic → use the file length (never place initrd below the raw image).
        let img = alloc::vec![0u8; 0x200];
        assert_eq!(kernel_image_footprint(&img), 0x200);
        // Magic present but image_size smaller than the file → still the file length.
        let mut small = alloc::vec![0u8; 0x400];
        small[16..24].copy_from_slice(&0x100u64.to_le_bytes());
        small[0x38..0x3c].copy_from_slice(b"RSC\x05");
        assert_eq!(kernel_image_footprint(&small), 0x400);
    }

    #[test]
    fn version_matches_manifest() {
        // Golden value, not env!("CARGO_PKG_VERSION") — comparing version() against the
        // same macro it returns is a tautology that can never fail (verifier finding,
        // 2026-07-02). Bump this literal when the workspace version bumps.
        assert_eq!(version(), "0.0.1");
    }

    #[test]
    fn machine_allocates_requested_ram() {
        let m = Machine::new(4096);
        assert_eq!(m.ram_len(), 4096);
    }

    #[test]
    fn machine_tolerates_zero_ram() {
        let m = Machine::new(0);
        assert_eq!(m.ram_len(), 0);
    }

    #[cfg(not(feature = "zicsr-stub"))]
    #[test]
    fn group_batches_coalesces_disconnected_chunks() {
        let blocks: alloc::vec::Vec<_> = (0..5)
            .map(|i| {
                dispatch::DecodedBlock::new(
                    0x8000_0000 + i * 8,
                    alloc::vec![dispatch::MicroOp {
                        instr: decode::Instr::Addi {
                            rd: 1,
                            rs1: 1,
                            imm: 1,
                        },
                        len: 4,
                        raw: 0,
                    }],
                    4,
                )
            })
            .collect();

        assert_eq!(
            group_into_batches(&blocks, 2),
            alloc::vec![alloc::vec![0, 1], alloc::vec![2, 3], alloc::vec![4]]
        );

        let pages: alloc::vec::Vec<_> = (0..3)
            .map(|i| {
                dispatch::DecodedBlock::new(
                    0x9000_0000 + i * dispatch::PAGE,
                    alloc::vec![dispatch::MicroOp {
                        instr: decode::Instr::Addi {
                            rd: 1,
                            rs1: 1,
                            imm: 1,
                        },
                        len: 4,
                        raw: 0,
                    }],
                    4,
                )
            })
            .collect();
        assert_eq!(
            group_into_batches(&pages, 2),
            alloc::vec![alloc::vec![0, 1], alloc::vec![2]]
        );
    }
}
