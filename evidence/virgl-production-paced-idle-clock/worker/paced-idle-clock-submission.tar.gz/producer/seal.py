from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
repo=Path.cwd();out=Path(__file__).resolve().parent
sha=lambda x:hashlib.sha256(x).hexdigest()
entries={}
def add(file,name):
 assert file.is_file(),file
 data=file.read_bytes();assert len(data)<25*1024*1024,file
 assert name not in entries,name
 entries[name]=data
def tree(root,name):
 for p in sorted(root.rglob('*')):
  if p.is_file():add(p,name+'/'+str(p.relative_to(root)))
root=repo/'target/evidence/production-paced-idle-frozen01';cold=repo/'target/evidence/production-paced-idle-cold01'
for path in [root/'report.json',cold/'report.json',cold/'paced-idle/report.json',repo/'target/evidence/production-paced-idle-final-supplement01/report.json',repo/'target/evidence/production-paced-idle-final-gpu01/report.json']:
 d=json.loads(path.read_text());assert d['status']=='passed',path
 assert all(x['exitCode']==0 for x in d['commands']),path
for prefix in [root,cold/'paced-idle']:
 d=json.loads((prefix/'default/report.json').read_text());assert d['passed']==127 and d['failed']==0 and d['errors']==[]
for path in [repo/'web/dist/pkg/wasm_vm_wasm_bg.wasm',cold/'clone/web/dist/pkg/wasm_vm_wasm_bg.wasm']:
 assert sha(path.read_bytes())=='d055c473b686ce543d8b87da68034e240ba0f66cf8aacbb482e03a405a64363f'
assert json.loads((repo/'target/evidence/production-paced-idle-negative01/report.json').read_text())['status']=='expected-failure'
tree(root,'root');tree(cold/'paced-idle','cold/acceptance')
for p in sorted(cold.iterdir()):
 if p.is_file():add(p,'cold/'+p.name)
for name in ['production-paced-idle-negative01','production-paced-idle-supplement02','production-paced-idle-final-supplement01','production-paced-idle-gpu-supplement01','production-paced-idle-final-gpu01']:
 for p in sorted((repo/'target/evidence'/name).iterdir()):
  if p.is_file():add(p,name+'/'+p.name)
for n in ['01','02','03','04']:
 p=repo/('target/evidence/paced-idle-browser-self'+n)
 if p.exists():tree(p,'self-validation/browser'+n)
for pattern in ['paced-idle-self-check*','paced-idle-private-supplement01.*','paced-idle-independent-promoted01.*','paced-idle-freeze01.*','paced-idle-supplement-freeze01.*','paced-idle-gpu-freeze01.*']:
 for p in sorted((repo/'target/evidence').glob(pattern)):
  if p.is_file():add(p,'self-validation/'+p.name)
files=['Makefile','crates/core/src/lib.rs','crates/core/src/time.rs','crates/core/src/paced_idle_clock_tests.rs','crates/core/tests/paced_idle_clock.rs','crates/core/tests/production_keyboard_host_wait.rs','crates/core/tests/production_paced_idle_critic.rs','crates/core/tests/production_virgl_critic.rs','crates/wasm/src/lib.rs','crates/wasm/tests/paced_idle_clock.rs','tools/virgl-production/verify-paced-idle.py','tools/virgl-production/paced-clock-browser.mjs','tools/virgl-production/cold.py','tools/verify-virgl-default-demo.mjs','web/roadmap.js','web/dist/pkg/wasm_vm_wasm_bg.wasm','tasks/epic-6-transcendence/E6-T11d73-paced-idle-clock.md']
for f in files:add(repo/f,'source/'+f)
add(Path(__file__),'producer/seal.py')
manifest={'schema':1,'scope':'D73 opt-in native/Wasm idle pacing only; stock Omarchy input, production selection, deployment and300MIPS not proved','head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'componentHead':'5537fbe6','wasmSha256':'d055c473b686ce543d8b87da68034e240ba0f66cf8aacbb482e03a405a64363f','files':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(entries.items())]}
entries['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
p=out/'paced-idle-clock-submission.tar.gz'
with p.open('wb') as target:
 with gzip.GzipFile(fileobj=target,mode='wb',mtime=0,filename='') as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,data in sorted(entries.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(p,'r:gz') as tar:
 actual={m.name:tar.extractfile(m).read() for m in tar}
 assert actual==entries
receipt={'path':str(p.relative_to(repo)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'members':len(entries),'identities':len(manifest['files']),'head':manifest['head'],'allMembersReopened':True}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
