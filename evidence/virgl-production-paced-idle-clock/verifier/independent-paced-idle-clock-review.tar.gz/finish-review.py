from pathlib import Path
import hashlib, io, json, tarfile, gzip, subprocess
R=Path('target/evidence/critic-paced-idle-clock73')
O=Path('evidence/virgl-production-paced-idle-clock/verifier')
O.mkdir(parents=True,exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,v): (R/n).write_text(json.dumps(v,indent=2)+'\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='f0f24eaef09496e8c7587e565e4f7f8a4182aa7b'
assert not subprocess.check_output(['git','diff','--name-only'],text=True).strip()
worker=Path('evidence/virgl-production-paced-idle-clock/worker/paced-idle-clock-submission.tar.gz')
assert sha(worker.read_bytes())=='bea622c1049539743340a05e7dd874914e2b844da785b8df9bedd58e8df09c1c'
wa=json.loads((R/'final-worker-authentication.json').read_text())
assert wa['archive']['allMembersReopened']==146
assert wa['independentPromotionTraceMatchesOwnOriginalRun']['allStateLinesEqual']
assert wa['runtimeLibExactly5537AfterRemovingCfgTestOnlyDeclaration']
assert len(wa['privateRefusals'])==3 and len(wa['originalGpuWaitRows'])==16
p=json.loads((R/'novel-positive01/report.json').read_text())
n=json.loads((R/'novel-ceiling-control01/report.json').read_text())
assert p['exit']==0 and n['exit']==101 and n['expectedLiteralMismatchObserved']
for d,rr in [('novel-positive01',p),('novel-ceiling-control01',n)]:
 for stream in ['stdout','stderr']: assert sha((R/d/stream).read_bytes())==rr[stream+'Sha256']
assert (R/'production_paced_idle_critic.rs').read_bytes()==Path('crates/core/tests/production_paced_idle_critic.rs').read_bytes()
results=[
('P1','Atomic selection and truthful policy','Original missing source/CLINT/invalid mode refusals pass; private divider/residue 0/0,7/7,7/8 each sample new source zero times and preserve old wall state. Restored phase then actual old-source retirement reaches mtime133456.', ['final-worker-authentication.json','worker:production-paced-idle-final-supplement01/private.stderr','worker:root/wasm-adapter.stderr']),
('P2','Idle ceiling and host jitter','Literal stalled mtime0/71000000; advancing and backward samples hold50000/71050000; nearest deadline200000/71200000 with actual timer handler. No time rewind.', ['literal-state-and-browser-audit.json','worker:root/native-clock.stderr']),
('P3','Busy execution, above-ceiling state and source replacement','Independent busy77 retires to initial+2,residue3 without host sampling; subsequent WFI preserves above-ceiling time. Replacing source at residue5 preserves bytes and stops all reads of discarded source.', ['novel-literal-predictions.json','novel-positive01/stderr','worker:production-paced-idle-final-supplement01/independent.stderr']),
('P4','Arithmetic and timer/IRQ boundaries','IdlePacer fixed literal arithmetic/near-u64 tests pass; independent initial above2^53 remains exact. Current time can exceed ceiling without rewind. Exact host99800ns earns1000ticks; actual MTIP then real handler t1=1.', ['literal-state-and-browser-audit.json','novel-positive01/stderr','worker:root/core-unit.stderr']),
('P5','IRQ, keyboard and GPU host waits','Independent original MSIP does not sample source or jump. Original keyboard lifecycle combinations hold. Paced GPU mailbox success/failure/reset/loss in both caches, plus unpaced controls, preserve pendingmtime0 then settled500000 even though earned ceiling10000000 exceeds deadline.', ['final-worker-authentication.json','novel-positive01/stderr','worker:production-paced-idle-final-gpu01/gpu.stderr','worker:root/native-clock.stderr']),
('P6','Bounded host turns','Native original run_traced returns finite work at future ceiling; actual ordinary-Wasm runChunk returns255/256retirements under256work, next host turn progresses while deadline staysfuture. Modern SBI_TIME fixture and compiled busy control run actual Wasm.', ['literal-state-and-browser-audit.json','worker:root/browser-clock/report.json','worker:cold/acceptance/browser-clock/report.json']),
('P7','Explicit rebase, restore and epoch exclusion','Literal before/after pause10091 unchanged, later20091/30091 progresses after rebase. Existing architectural CLOCK bytes remain unchanged by selection/source replacement; successful restore reanchors host state, rejected restore does not replace source. New host epoch is absent from serialized fields.', ['literal-state-and-browser-audit.json','novel-positive01/stderr','worker:root/native-clock.stderr','worker:root/wasm-clock.stderr']),
('P8','Defaults and compiled retirement','Fresh load remains ordinary ICount and immediately reaches deadline. Existing wall/unpaced controls pass. Actual compiled busy16384retired => mtime256 atdivider64,128executed blocks,16258retirements viaJIT. No production JS policy selected in73.', ['literal-state-and-browser-audit.json','frozen-hot-cold-authentication.json','worker:root/browser-clock/report.json']),
('P9','Actual Wasm API','Six API and11actualWasm fixtures pass; exact mode stringpaced-icount, lossless decimalmtime, missing source and invalid admission refuse atomically. Real served ordinaryWasmd055 and generated JS identities held.', ['frozen-hot-cold-authentication.json','worker:root/wasm-adapter.stderr','worker:root/wasm-clock.stderr']),
('P10','Exact-head hot, cold and incremental custody','All13root and full-history no-local clone/build/13cold gates pass at5537, scrubbed env/no alternates/clean clone. Test-only73bd/2192 supplements pass4+3commands with production/dependency equality and identical1744311B Wasmd055. All146worker members reopened/145identities authenticated; default127/0/errors[].', ['final-worker-authentication.json','frozen-hot-cold-authentication.json','worker:root/report.json','worker:cold/report.json','worker:cold/acceptance/report.json']),
('P11','Independent novel and negative control','Four original Machine rows cache0/1 x initial0/(2^53+1234), divider37 pass40literal state/digest lines; promoted run exactlymatches. One copied-core hunk removing onlylimit_deadline compiles then fails101 at firstWFI: mtime1000 observed vs2expected; originals unchanged.', ['novel-literal-predictions.json','novel-positive01/report.json','novel-positive01/stderr','isolated-ceiling-control/source.delta','novel-ceiling-control01/report.json','novel-ceiling-control01/stderr'])
]
save('verdict-and-coverage.json',{
 'schema':1,'verdict':'verified','task':'E6-T11d73','reviewedSubmission':'f0f24eaef09496e8c7587e565e4f7f8a4182aa7b','scope':'Explicit opt-in native/Wasm host-paced ICount idle primitive only',
 'predictionRecord':'pre-data-predictions.json','workerArchive':wa['archive'],
 'predictions':[{'id':i,'boundary':b,'status':'HELD','observed':o,'citations':c} for i,b,o,c in results],
 'coverage':[
  {'hunks':['crates/core/src/time.rs:116-172','crates/core/src/lib.rs:299/default construction/getter/selection/rebase/after_wfi_retire'],'status':'HELD','evidence':'Literal arithmetic unit/native/actualWasm, independent source/phase/IRQ fixture, real browser bounded turns and exact-deadline handler.'},
  {'hunks':['crates/core/src/lib.rs wall/icount source replacement, divider refusal, successful/failed restore rebase'],'status':'HELD','evidence':'Native and actualWasm lifecycle/snapshot/selection tests, private invalid phase rows, independent snapshot-byte equality.'},
  {'hunks':['crates/wasm/src/lib.rs select_guest_clock and clock state mode match'],'status':'HELD','evidence':'Nativeadapter, actual6WasmAPI and11integration fixtures, served ordinaryWasm proof.'},
  {'hunks':['new paced_idle_clock tests, original keyboard lifecycle refactor, GPU test-only combinations'],'status':'HELD','evidence':'Root/cold13gates plus clean-head private/promoted4 andGPU3commands; original transport used/mailbox ownership explicitly asserted.'},
  {'hunks':['tools/virgl-production/verify-paced-idle.py,cold.py,paced-clock-browser.mjs,Makefile and recorded fixtures'],'status':'HELD','evidence':'Executed commands in scrubbed no-local cold; own independent copied-core refusal validates literal assertion sensitivity.'},
  {'hunks':['new enum/field declarations, explanatory docs, partial roadmap metadata'],'status':'WAIVED','reason':'Types/declarations or non-runtime publication copy. Roadmap remainspartial; default127/0 physically recorded.'},
  {'hunks':['Some(idle_pacer) with missing clock source fallback tuple'],'status':'WAIVED','reason':'Unreachable through public constructors/selectors: pacing commits source and pacer together; source replacement clears pacer. No claim permitting private invalid pair.'}
 ],
 'loggingObservation':{'prediction':'Optional raw native/Wasm eprintln trace equality','status':'WAIVED','observation':'Native60trace/33state rows exist; Wasm harness emits no raw eprintln rows. No raw trace equality claim. Same literal fixtures execute11Wasm tests; architectural/API/JIT/browser proof independently recorded. This is logging coverage, not missing semantic task acceptance.'},
 'suite':'Retain promoted production_paced_idle_critic.rs SHA4fbf10ace355a5256caa57f88fd3b11481fe15b08df5962a0b4e7a43f9cac2be, private invalid-phase test, GPU combination test and make verify-E6-T11d73.',
 'exclusions':['D72 stock50ms input remains refuted; no new production policy selected.','D71,parent production desktop,recovery,live deployment remain gated.','No300MIPS/GPUthroughput/full-offload-completion/snapshot-portability claim.'],
 'remainingRequiredProofGaps':[]
})
files=[]
for q in sorted(R.rglob('*')):
 if not q.is_file() or any(x in q.relative_to(R).parts for x in ['native-target','negative-target','__pycache__']):continue
 files.append((q.relative_to(R).as_posix(),q.read_bytes()))
# The canonical worker archive remains a separately committed authenticated artifact; avoid duplicate archive copy.
manifest={'schema':1,'task':'E6-T11d73','role':'independent verifier','verdict':'verified','reviewedHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'workerArchive':wa['archive'],'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in files],'excluded':['native-target','negative-target','__pycache__'],'scope':'Native/Wasm opt-in primitive; production-input/parent/recovery/deployment expressly excluded'}
mb=(json.dumps(manifest,indent=2)+'\n').encode()
archive=O/'independent-paced-idle-clock-review.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for n,b in [('manifest.json',mb)]+files:
    info=tarfile.TarInfo(n);info.size=len(b);info.mtime=0;info.mode=0o644;t.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as t:
 assert len(t.getnames())==len(set(t.getnames()))==len(files)+1
 for n,b in [('manifest.json',mb)]+files:assert t.extractfile(n).read()==b
receipt={'schema':1,'task':'E6-T11d73','verdict':'verified','path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'membersReopened':len(files)+1,'identities':len(files),'manifestSha256':sha(mb),'files':manifest['files'],'workerArchive':wa['archive']}
(O/'independent-paced-idle-clock-review.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['files','workerArchive']},indent=2))
