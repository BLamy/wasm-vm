	.build_version macos, 11, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvMs1_NtCs5joLtdXDRmI_12wasm_vm_core4hartNtB6_4Hart11step_tracedNtNtB8_5trace8HashSinkNtNtB8_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	stp	x24, x23, [sp, #64]
	stp	x22, x21, [sp, #80]
	stp	x20, x19, [sp, #96]
	stp	x29, x30, [sp, #112]
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x2
	mov	x22, x1
	mov	x21, x0
	strh	wzr, [x0, #728]
	ldr	x20, [x0, #3088]
	ldrb	w8, [x0, #732]
	cmp	w8, #1
	b.ne	LBB0_12
	ldr	x8, [x21, #704]
	and	x9, x8, #0xfffffffffffffffc
	and	x9, x9, #0xf000000000000007
	mov	x10, #4
	movk	x10, #8192, lsl #48
	cmp	x9, x10
	b.ne	LBB0_12
	ldrb	w9, [x21, #733]
	cmp	w9, #3
	b.eq	LBB0_5
	cmp	w9, #1
	b.ne	LBB0_7
	and	x9, x8, #0x10
	b	LBB0_8
LBB0_5:
	tbz	w8, #6, LBB0_12
	ldr	x9, [x21, #720]
	and	x9, x9, #0x8
	b	LBB0_8
LBB0_7:
	and	x9, x8, #0x8
LBB0_8:
	mov	w10, #63360
	tst	x8, x10
	b.ne	LBB0_12
	cbz	x9, LBB0_12
	ldr	x8, [x21, #712]
	cmp	x8, x20
	b.ne	LBB0_12
	mov	w0, #3
	b	LBB0_21
LBB0_12:
	add	x0, sp, #8
	mov	x1, x21
	mov	x2, x22
	mov	x3, x20
	bl	__RINvMs1_NtCs5joLtdXDRmI_12wasm_vm_core4hartNtB6_4Hart9decode_atNtNtB8_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldrb	w8, [sp, #8]
	cmp	w8, #255
	b.eq	LBB0_15
	ldur	q0, [sp, #8]
	str	q0, [sp, #48]
	ldrb	w4, [sp, #28]
	ldr	w23, [sp, #24]
	add	x0, sp, #8
	add	x3, sp, #48
	mov	x1, x21
	mov	x2, x22
	mov	x5, x23
	bl	__RINvMs1_NtCs5joLtdXDRmI_12wasm_vm_core4hartNtB6_4Hart7executeNtNtB8_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldrb	w8, [sp, #41]
	ldp	x0, x10, [sp, #8]
	cmp	w8, #255
	b.ne	LBB0_16
	mov	x20, x10
	b	LBB0_21
LBB0_15:
	ldp	x0, x20, [sp, #16]
	b	LBB0_21
LBB0_16:
	ldrb	w9, [sp, #40]
	ldrb	w11, [x21, #728]
	tbnz	w11, #0, LBB0_18
	ldr	x11, [x21, #656]
	add	x11, x11, #1
	str	x11, [x21, #656]
LBB0_18:
	ldp	x12, x11, [sp, #24]
	ldrb	w13, [x21, #729]
	tbnz	w13, #0, LBB0_20
	ldr	x13, [x21, #664]
	add	x13, x13, #1
	str	x13, [x21, #664]
LBB0_20:
	ldp	x13, x14, [x19]
	eor	x13, x13, x20
	mov	x15, #435
	movk	x15, #256, lsl #32
	ands	x10, x10, #0xff
	mul	x13, x13, x15
	eor	x13, x13, x23
	mul	x13, x13, x15
	eor	x16, x13, #0x200000000000000
	orr	x10, x10, #0x100000000000000
	eor	x10, x13, x10
	mul	x10, x10, x15
	eor	x10, x10, x0
	csel	x10, x16, x10, eq
	mul	x10, x10, x15
	cmp	w8, #2
	eor	x13, x10, #0x400000000000000
	eor	x10, x10, x12
	mul	x10, x10, x15
	orr	x8, x8, x9, lsl #1
	eor	x8, x10, x8
	mul	x8, x8, x15
	eor	x8, x8, x11
	csel	x8, x13, x8, eq
	mul	x8, x8, x15
	add	x9, x14, #1
	stp	x8, x9, [x19]
	mov	x0, #-1
LBB0_21:
	mov	x1, x20
	.cfi_def_cfa wsp, 128
	ldp	x29, x30, [sp, #112]
	ldp	x20, x19, [sp, #96]
	ldp	x22, x21, [sp, #80]
	ldp	x24, x23, [sp, #64]
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	ret
	.cfi_endproc

	.p2align	2
__RINvMs1_NtCs5joLtdXDRmI_12wasm_vm_core4hartNtB6_4Hart7executeNtNtB8_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	stp	x28, x27, [sp, #32]
	stp	x26, x25, [sp, #48]
	stp	x24, x23, [sp, #64]
	stp	x22, x21, [sp, #80]
	stp	x20, x19, [sp, #96]
	stp	x29, x30, [sp, #112]
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_remember_state
	mov	x6, x5
	ldrb	w8, [x3]
	cmp	w8, #82
	b.lo	LBB1_2
	ldrb	w9, [x1, #641]
	tst	w9, #0x60
	b.eq	LBB1_370
LBB1_2:
	add	x24, x1, #2832
	ldr	x10, [x1, #3088]
	add	x19, x10, x4
	mov	w26, #2
	mov	x20, #0
	mov	w25, #0
Lloh0:
	adrp	x9, LJTI1_0@PAGE
Lloh1:
	add	x9, x9, LJTI1_0@PAGEOFF
	adr	x11, LBB1_3
	ldrh	w12, [x9, x8, lsl #1]
	add	x11, x11, x12, lsl #2
	br	x11
LBB1_3:
	ldrb	w25, [x3, #1]
	ldr	x20, [x3, #8]
	mov	x10, x19
	b	LBB1_401
LBB1_4:
	ldrb	w8, [x3, #4]
	ldrb	w9, [x1, #735]
	cmp	w8, #7
	csel	w2, w9, w8, eq
	and	w8, w2, #0xff
	cmp	w8, #5
	b.hs	LBB1_370
	ldrb	w8, [x3, #2]
	cmp	x8, #31
	b.hi	LBB1_441
	add	x22, x1, #3104
	ldr	x8, [x22, x8, lsl #3]
	ldrb	w9, [x3, #3]
	mov	x11, #-4294967297
	cmp	x8, x11
	mov	w12, #2143289344
	csel	w8, w8, w12, hi
	cmp	w9, #32
	b.hs	LBB1_444
	ldrb	w10, [x3, #5]
	ldrb	w21, [x3, #1]
	ldr	x9, [x22, x9, lsl #3]
	cmp	x9, x11
	csel	w9, w9, w12, hi
	mov	x20, x1
	mov	x23, x0
	mov	x0, x8
	mov	x1, x9
	cmp	w10, #1
	b.gt	LBB1_409
	cbnz	w10, LBB1_426
	bl	__RNvXsg_NtCs5joLtdXDRmI_12wasm_vm_core9softfloatNtB5_3F32NtB5_9SoftFloat3add
	b	LBB1_428
LBB1_10:
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_442
	ldrb	w21, [x3, #1]
	mov	x22, x1
	add	x24, x1, #3104
	ldr	x8, [x24, x0, lsl #3]
	mov	x9, #-4294967297
	cmp	x8, x9
	mov	w9, #2143289344
	csel	w0, w8, w9, hi
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core9softfloat10f32_to_f64
	cmp	x21, #32
	b.lo	LBB1_367
	b	LBB1_443
LBB1_12:
	ldrb	w9, [x3, #1]
	cmp	x9, #32
	b.hs	LBB1_439
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_442
	mov	x8, x2
	ldr	x10, [x3, #8]
	ldr	x9, [x24, x9, lsl #3]
	add	x21, x9, x10
	add	x9, x1, x0, lsl #3
	ldr	x22, [x9, #3104]
	add	x0, sp, #8
	mov	x9, x1
	add	x1, x1, #24
	mov	x26, x9
	add	x2, x9, #736
	mov	x3, x8
	mov	x4, x21
	mov	x5, x22
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart18cstore32_with_physNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	w8, [sp, #8]
	tbnz	w8, #0, LBB1_286
	mov	w25, #0
	mov	x20, #0
	mov	w22, w22
	mov	w9, #4
	b	LBB1_374
LBB1_16:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_441
	ldrb	w25, [x3, #1]
	add	x8, x1, x8, lsl #3
	ldrsw	x20, [x8, #3104]
	mov	x10, x19
	b	LBB1_401
LBB1_18:
	ldrb	w8, [x3, #3]
	ldrb	w9, [x1, #735]
	cmp	w8, #7
	csel	w2, w9, w8, eq
	and	w8, w2, #0xff
	cmp	w8, #5
	b.hs	LBB1_370
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #31
	b.hi	LBB1_442
	ldrb	w8, [x3, #4]
	ldrb	w25, [x3, #1]
	add	x9, x1, x0, lsl #3
	ldr	x0, [x9, #3104]
	mov	x21, x1
	mov	x1, x8
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core9softfloat10f64_to_int
	b	LBB1_39
LBB1_21:
	ldrb	w8, [x1, #733]
	cbz	w8, LBB1_370
	cmp	w8, #1
	b.ne	LBB1_24
	ldrb	w8, [x1, #642]
	tbnz	w8, #6, LBB1_370
LBB1_24:
	mov	x20, x0
	add	x0, x1, #24
	mov	x21, x1
	mov	w1, #321
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs4read
	mov	x19, x0
	add	x0, x21, #24
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs4sret
	b	LBB1_333
LBB1_25:
	ldrb	w8, [x3, #1]
	cmp	x8, #32
	b.hs	LBB1_437
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_442
	mov	x9, x2
	ldr	x10, [x3, #8]
	ldr	x8, [x24, x8, lsl #3]
	add	x21, x8, x10
	add	x8, x1, x0, lsl #3
	ldr	x22, [x8, #3104]
	b	LBB1_285
LBB1_28:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #1]
	cmp	x9, #32
	b.hs	LBB1_445
	mov	w25, #0
	mov	x20, #0
	ldr	x8, [x24, x8, lsl #3]
	b	LBB1_194
LBB1_31:
Lloh2:
	adrp	x8, l_switch.table._RINvMs1_NtCs5joLtdXDRmI_12wasm_vm_core4hartNtB6_4Hart7executeNtNtB8_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe@PAGE
Lloh3:
	add	x8, x8, l_switch.table._RINvMs1_NtCs5joLtdXDRmI_12wasm_vm_core4hartNtB6_4Hart7executeNtNtB8_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe@PAGEOFF
	ldrb	w9, [x1, #733]
	ldr	x8, [x8, x9, lsl #3]
	stp	x8, xzr, [x0]
	b	LBB1_371
LBB1_32:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldr	x8, [x24, x8, lsl #3]
	ldrb	w25, [x3, #1]
	ldr	x9, [x24, x9, lsl #3]
	mul	x20, x9, x8
	mov	x10, x19
	b	LBB1_401
LBB1_35:
	mov	x23, x0
	ldrb	w25, [x3, #1]
	cmp	w25, #0
	cset	w5, eq
	ldrb	w9, [x3, #2]
	cmp	x9, #0
	cset	w4, eq
	ldrh	w10, [x3, #4]
	b	LBB1_321
LBB1_36:
	ldrb	w8, [x3, #3]
	ldrb	w9, [x1, #735]
	cmp	w8, #7
	csel	w2, w9, w8, eq
	and	w8, w2, #0xff
	cmp	w8, #5
	b.hs	LBB1_370
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #31
	b.hi	LBB1_442
	ldrb	w8, [x3, #4]
	ldrb	w25, [x3, #1]
	add	x9, x1, x0, lsl #3
	ldr	x9, [x9, #3104]
	mov	x10, #-4294967297
	cmp	x9, x10
	mov	w10, #2143289344
	csel	w0, w9, w10, hi
	mov	x21, x1
	mov	x1, x8
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core9softfloat10f32_to_int
LBB1_39:
	mov	x20, x0
	mov	x8, x1
	mov	x1, x21
	and	w8, w8, #0x1f
	ldrb	w9, [x21, #734]
	orr	w8, w8, w9
	strb	w8, [x21, #734]
	ldr	x8, [x21, #640]
	orr	x8, x8, #0x6000
	orr	x8, x8, #0x8000000000000000
	str	x8, [x21, #640]
	b	LBB1_399
LBB1_40:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	ldr	x9, [x24, x9, lsl #3]
	asr	w8, w8, w9
	b	LBB1_314
LBB1_43:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_441
	mov	x23, x0
	ldrb	w0, [x3, #3]
	cmp	x0, #32
	b.hs	LBB1_442
	ldrb	w2, [x3, #4]
	ldrb	w21, [x3, #1]
	mov	x22, x1
	add	x24, x1, #3104
	ldr	x8, [x24, x8, lsl #3]
	mov	x9, #-4294967297
	cmp	x8, x9
	mov	w10, #2143289344
	csel	w8, w8, w10, hi
	ldr	x11, [x24, x0, lsl #3]
	cmp	x11, x9
	csel	w1, w11, w10, hi
	mov	x0, x8
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core9softfloat10f32_minmax
	b	LBB1_254
LBB1_46:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_441
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_444
	ldrb	w11, [x3, #4]
	ldrb	w25, [x3, #1]
	add	x12, x1, #3104
	ldr	x10, [x12, x8, lsl #3]
	ldr	x8, [x12, x9, lsl #3]
	mov	x20, x1
	mov	x23, x0
	mov	x0, x10
	mov	x1, x8
	cbz	w11, LBB1_394
	cmp	w11, #1
	b.ne	LBB1_395
	bl	__RNvXsi_NtCs5joLtdXDRmI_12wasm_vm_core9softfloatNtB5_3F64NtB5_9SoftFloat2lt
	b	LBB1_398
LBB1_51:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	lsl	w8, w8, w9
	b	LBB1_314
LBB1_53:
	ldrb	w8, [x3, #3]
	ldrb	w9, [x1, #735]
	cmp	w8, #7
	csel	w8, w9, w8, eq
	and	w9, w8, #0xff
	cmp	w9, #5
	b.hs	LBB1_370
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #31
	b.hi	LBB1_442
	ldrb	w21, [x3, #1]
	mov	x22, x1
	add	x24, x1, #3104
	ldr	x0, [x24, x0, lsl #3]
	mov	x1, x8
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core9softfloat10f64_to_f32
	cmp	w21, #32
	b.lo	LBB1_255
	b	LBB1_443
LBB1_56:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldr	x21, [x24, x8, lsl #3]
	tst	x21, #0x3
	b.ne	LBB1_339
	ldrb	w25, [x3, #1]
	ldr	x8, [x1]
	cmp	x8, #1
	b.ne	LBB1_382
	ldr	x8, [x1, #8]
	cmp	x8, x21
	b.ne	LBB1_382
	ldrb	w8, [x3, #3]
	ldrb	w9, [x1, #16]
	str	xzr, [x1]
	cmp	w9, #4
	b.ne	LBB1_383
	cmp	w8, #31
	b.hi	LBB1_437
	mov	x3, x2
	mov	x23, x0
	ldr	x22, [x24, x8, lsl #3]
	add	x0, sp, #8
	mov	x8, x1
	add	x1, x1, #24
	mov	x26, x8
	add	x2, x8, #736
	mov	x4, x21
	mov	x5, x22
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart18cstore32_with_physNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	w8, [sp, #8]
	tbz	w8, #0, LBB1_247
	b	LBB1_286
LBB1_63:
	ldrb	w8, [x1, #642]
	tbz	w8, #5, LBB1_65
	ldrb	w8, [x1, #733]
	cmp	w8, #3
	b.ne	LBB1_370
LBB1_65:
	mov	w25, #0
	mov	x20, #0
	str	xzr, [x1]
	mov	w8, #1
	strb	w8, [x1, #3360]
	b	LBB1_405
LBB1_66:
	mov	w8, #3
	stp	x8, x10, [x0]
	b	LBB1_371
LBB1_67:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	asr	x10, x8, #63
	ldr	x9, [x24, x9, lsl #3]
	umulh	x8, x9, x8
	madd	x20, x9, x10, x8
	mov	x10, x19
	b	LBB1_401
LBB1_70:
	ldrb	w8, [x3, #3]
	ldrb	w9, [x1, #735]
	cmp	w8, #7
	csel	w2, w9, w8, eq
	and	w8, w2, #0xff
	cmp	w8, #5
	b.hs	LBB1_370
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #31
	b.hi	LBB1_440
	mov	x22, x1
	ldrb	w1, [x3, #4]
	ldrb	w21, [x3, #1]
	ldr	x0, [x24, x0, lsl #3]
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core9softfloat12f64_from_int
	cmp	w21, #32
	b.hs	LBB1_443
	mov	x8, x1
	mov	w25, #0
	mov	x20, #0
	mov	x1, x22
	add	x9, x22, x21, lsl #3
	str	x0, [x9, #3104]
	b	LBB1_208
LBB1_74:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldrb	w25, [x3, #1]
	ldr	x11, [x24, x9, lsl #3]
	cbz	x11, LBB1_379
	ldr	x8, [x24, x8, lsl #3]
	mov	x10, x19
	udiv	x20, x8, x11
	b	LBB1_401
LBB1_78:
	mov	x23, x0
	ldrb	w25, [x3, #1]
	cmp	w25, #0
	cset	w5, eq
	ldrb	w9, [x3, #2]
	b	LBB1_299
LBB1_79:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldr	x8, [x24, x8, lsl #3]
	ldrb	w25, [x3, #1]
	ldr	x9, [x24, x9, lsl #3]
	eor	x20, x9, x8
	mov	x10, x19
	b	LBB1_401
LBB1_82:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	ldr	x9, [x24, x9, lsl #3]
	sub	w8, w8, w9
	b	LBB1_314
LBB1_85:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	ldr	x9, [x24, x9, lsl #3]
	b	LBB1_190
LBB1_88:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	ldr	x9, [x24, x9, lsl #3]
	b	LBB1_187
LBB1_91:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldr	x9, [x3, #8]
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	eor	x20, x8, x9
	mov	x10, x19
	b	LBB1_401
LBB1_93:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldr	x9, [x3, #8]
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	add	x20, x8, x9
	mov	x10, x19
	b	LBB1_401
LBB1_95:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldr	x21, [x24, x8, lsl #3]
	tst	x21, #0x7
	b.ne	LBB1_339
	mov	x27, x0
	ldrb	w28, [x3, #4]
	ldrb	w25, [x3, #1]
	ldrb	w22, [x3, #3]
	add	x0, sp, #8
	mov	x8, x1
	add	x1, x1, #24
	mov	x26, x8
	mov	x3, x2
	add	x2, x8, #736
	mov	x23, x3
	mov	x4, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart10camoload64NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x20, [sp, #8]
	cmn	x8, #1
	b.eq	LBB1_420
	mov	x0, x27
	stp	x8, x20, [x27]
	b	LBB1_371
LBB1_99:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldr	x9, [x3, #8]
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	orr	x20, x8, x9
	mov	x10, x19
	b	LBB1_401
LBB1_101:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldr	x8, [x24, x8, lsl #3]
	ldrb	w25, [x3, #1]
	ldr	x9, [x24, x9, lsl #3]
	lsl	x20, x8, x9
	mov	x10, x19
	b	LBB1_401
LBB1_104:
	ldrb	w8, [x3, #1]
	cmp	x8, #32
	b.hs	LBB1_437
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_440
	mov	x9, x2
	ldr	x10, [x3, #8]
	ldr	x8, [x24, x8, lsl #3]
	add	x21, x8, x10
	ldr	x22, [x24, x0, lsl #3]
	add	x0, sp, #8
	mov	x8, x1
	add	x1, x1, #24
	mov	x26, x8
	add	x2, x8, #736
	mov	x3, x9
	mov	x4, x21
	mov	x5, x22
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart17cstore8_with_physNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	w8, [sp, #8]
	tbnz	w8, #0, LBB1_286
	mov	w25, #0
	mov	x20, #0
	mov	w9, #1
	b	LBB1_374
LBB1_108:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldr	x21, [x24, x8, lsl #3]
	tst	x21, #0x7
	b.ne	LBB1_339
	ldrb	w25, [x3, #1]
	ldr	x8, [x1]
	cmp	x8, #1
	b.ne	LBB1_382
	ldr	x8, [x1, #8]
	cmp	x8, x21
	b.ne	LBB1_382
	ldrb	w8, [x3, #3]
	ldrb	w9, [x1, #16]
	str	xzr, [x1]
	cmp	w9, #8
	b.ne	LBB1_383
	cmp	w8, #31
	b.hi	LBB1_437
	mov	x3, x2
	mov	x23, x0
	ldr	x22, [x24, x8, lsl #3]
	add	x0, sp, #8
	mov	x8, x1
	add	x1, x1, #24
	mov	x26, x8
	add	x2, x8, #736
	mov	x4, x21
	mov	x5, x22
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart18cstore64_with_physNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	w8, [sp, #8]
	tbnz	w8, #0, LBB1_286
	b	LBB1_373
LBB1_115:
	ldrb	w8, [x3, #1]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #2]
	cmp	x9, #32
	b.hs	LBB1_439
	ldr	x8, [x24, x8, lsl #3]
	ldr	x9, [x24, x9, lsl #3]
	cmp	x8, x9
	b.lt	LBB1_201
	b	LBB1_202
LBB1_118:
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_440
	mov	x8, x2
	ldrb	w25, [x3, #1]
	ldr	x9, [x3, #8]
	ldr	x10, [x24, x0, lsl #3]
	add	x21, x10, x9
	add	x0, sp, #8
	mov	x9, x1
	add	x1, x1, #24
	mov	x27, x9
	add	x2, x9, #736
	mov	x3, x8
	mov	x4, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart7cload16NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	x8, [sp, #8]
	cmn	x8, #1
	b.ne	LBB1_266
	mov	x22, #0
	mov	w26, #0
	ldrsh	x20, [sp, #16]
	mov	w9, #2
	b	LBB1_326
LBB1_121:
	ldrb	w8, [x3, #1]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #2]
	cmp	x9, #32
	b.hs	LBB1_439
	ldr	x8, [x24, x8, lsl #3]
	ldr	x9, [x24, x9, lsl #3]
	cmp	x8, x9
	b.eq	LBB1_201
	b	LBB1_202
LBB1_124:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	lsr	w8, w8, w9
	b	LBB1_314
LBB1_126:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldr	x8, [x24, x8, lsl #3]
	ldrb	w25, [x3, #1]
	ldr	x9, [x24, x9, lsl #3]
	sub	x20, x8, x9
	mov	x10, x19
	b	LBB1_401
LBB1_129:
	ldrb	w8, [x3, #1]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #2]
	cmp	x9, #32
	b.hs	LBB1_439
	ldr	x8, [x24, x8, lsl #3]
	ldr	x9, [x24, x9, lsl #3]
	cmp	x8, x9
	b.ne	LBB1_201
	b	LBB1_202
LBB1_132:
	ldrb	w8, [x3, #1]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #2]
	cmp	x9, #32
	b.hs	LBB1_439
	ldr	x8, [x24, x8, lsl #3]
	ldr	x9, [x24, x9, lsl #3]
	cmp	x8, x9
	b.ge	LBB1_201
	b	LBB1_202
LBB1_135:
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_440
	mov	x8, x2
	ldrb	w25, [x3, #1]
	ldr	x9, [x3, #8]
	ldr	x10, [x24, x0, lsl #3]
	add	x21, x10, x9
	add	x0, sp, #8
	mov	x9, x1
	add	x1, x1, #24
	mov	x27, x9
	add	x2, x9, #736
	mov	x3, x8
	mov	x4, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart6cload8NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	x8, [sp, #8]
	cmn	x8, #1
	b.ne	LBB1_266
	mov	x22, #0
	mov	w26, #0
	ldrb	w20, [sp, #16]
	b	LBB1_230
LBB1_138:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	ldr	x9, [x24, x9, lsl #3]
	lsl	w8, w8, w9
	b	LBB1_314
LBB1_141:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldrb	w25, [x3, #1]
	ldr	x20, [x24, x8, lsl #3]
	ldr	x8, [x24, x9, lsl #3]
	cbz	x8, LBB1_380
	udiv	x9, x20, x8
	b	LBB1_273
LBB1_145:
	mov	x20, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_440
	mov	x8, x2
	ldrb	w23, [x3, #1]
	ldr	x9, [x3, #8]
	ldr	x10, [x24, x0, lsl #3]
	add	x21, x10, x9
	add	x0, sp, #8
	mov	x9, x1
	add	x1, x1, #24
	mov	x24, x9
	add	x2, x9, #736
	mov	x3, x8
	mov	x4, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart7cload32NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	x8, [sp, #8]
	cmn	x8, #1
	b.eq	LBB1_384
	ldr	x9, [sp, #16]
	mov	x0, x20
	stp	x8, x9, [x20]
	b	LBB1_371
LBB1_148:
	ldrb	w25, [x3, #1]
	ldr	x8, [x3, #8]
	add	x20, x8, x10
	mov	x10, x19
	b	LBB1_401
LBB1_149:
	ldr	x8, [x3, #8]
	add	x10, x8, x10
	tbnz	w10, #0, LBB1_381
	ldrb	w25, [x3, #1]
	mov	x20, x19
	b	LBB1_401
LBB1_151:
	ldrb	w8, [x3, #1]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #2]
	cmp	x9, #32
	b.hs	LBB1_439
	ldr	x8, [x24, x8, lsl #3]
	ldr	x9, [x24, x9, lsl #3]
	cmp	x8, x9
	b.lo	LBB1_201
	b	LBB1_202
LBB1_154:
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_440
	mov	x8, x2
	ldrb	w25, [x3, #1]
	ldr	x9, [x3, #8]
	ldr	x10, [x24, x0, lsl #3]
	add	x21, x10, x9
	add	x0, sp, #8
	mov	x9, x1
	add	x1, x1, #24
	mov	x27, x9
	add	x2, x9, #736
	mov	x3, x8
	mov	x4, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart7cload32NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	x8, [sp, #8]
	cmn	x8, #1
	b.ne	LBB1_266
	mov	x22, #0
	mov	w26, #0
	ldrsw	x20, [sp, #16]
	mov	w9, #4
	b	LBB1_326
LBB1_157:
	ldrb	w10, [x1, #733]
	cbz	w10, LBB1_370
	ldrb	w9, [x3, #1]
	ldrb	w8, [x3, #2]
	cmp	w10, #1
	b.ne	LBB1_160
	ldrb	w10, [x1, #642]
	tbnz	w10, #4, LBB1_370
LBB1_160:
	cbz	w9, LBB1_414
	cmp	w9, #32
	b.hs	LBB1_439
	ldr	x2, [x24, x9, lsl #3]
	mov	w9, #1
	b	LBB1_415
LBB1_163:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldrb	w25, [x3, #1]
	ldr	x9, [x24, x9, lsl #3]
	cbz	w9, LBB1_379
	ldr	x8, [x24, x8, lsl #3]
	mov	w10, #-2147483648
	cmp	w8, w10
	ccmn	w9, #1, #0, eq
	b.eq	LBB1_408
	sdiv	w8, w8, w9
	b	LBB1_314
LBB1_168:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldr	x21, [x24, x8, lsl #3]
	tst	x21, #0x3
	b.ne	LBB1_216
	mov	x23, x0
	ldrb	w25, [x3, #1]
	add	x0, sp, #8
	mov	x8, x1
	add	x1, x1, #24
	mov	x27, x8
	mov	x3, x2
	add	x2, x8, #736
	mov	x4, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart7cload32NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	x8, [sp, #8]
	cmn	x8, #1
	b.ne	LBB1_266
	mov	x22, #0
	mov	w26, #0
	ldrsw	x20, [sp, #16]
	mov	w8, #1
	mov	x1, x27
	stp	x8, x21, [x27]
	mov	w9, #4
	b	LBB1_388
LBB1_172:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	ldr	x9, [x24, x9, lsl #3]
	lsr	w8, w8, w9
	b	LBB1_314
LBB1_175:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldr	x8, [x24, x8, lsl #3]
	ldrb	w25, [x3, #1]
	ldr	x9, [x24, x9, lsl #3]
	orr	x20, x9, x8
	mov	x10, x19
	b	LBB1_401
LBB1_178:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldr	x8, [x24, x8, lsl #3]
	ldrb	w25, [x3, #1]
	ldr	x9, [x3, #8]
	add	x8, x9, x8
	and	x10, x8, #0xfffffffffffffffe
	mov	x20, x19
	b	LBB1_401
LBB1_180:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	ldr	x9, [x24, x9, lsl #3]
	cbz	w9, LBB1_184
	udiv	w10, w8, w9
	msub	w8, w10, w9, w8
LBB1_184:
	b	LBB1_314
LBB1_185:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldr	x9, [x3, #8]
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
LBB1_187:
	cmp	x8, x9
	cset	w20, lo
	mov	x10, x19
	b	LBB1_401
LBB1_188:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldr	x9, [x3, #8]
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
LBB1_190:
	cmp	x8, x9
	cset	w20, lt
	mov	x10, x19
	b	LBB1_401
LBB1_191:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #1]
	cmp	x9, #32
	b.hs	LBB1_445
	mov	w25, #0
	mov	x20, #0
	ldr	x8, [x24, x8, lsl #3]
	orr	x8, x8, #0xffffffff00000000
LBB1_194:
	add	x9, x1, x9, lsl #3
	str	x8, [x9, #3104]
	b	LBB1_435
LBB1_195:
	ldrb	w8, [x3, #3]
	ldrb	w9, [x1, #735]
	cmp	w8, #7
	csel	w8, w9, w8, eq
	and	w9, w8, #0xff
	cmp	w9, #5
	b.hs	LBB1_370
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #31
	b.hi	LBB1_442
	ldrb	w21, [x3, #1]
	mov	x22, x1
	add	x24, x1, #3104
	ldr	x0, [x24, x0, lsl #3]
	mov	x1, x8
	bl	__RNvXsi_NtCs5joLtdXDRmI_12wasm_vm_core9softfloatNtB5_3F64NtB5_9SoftFloat4sqrt
	cmp	w21, #32
	b.lo	LBB1_367
	b	LBB1_443
LBB1_198:
	ldrb	w8, [x3, #1]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #2]
	cmp	x9, #32
	b.hs	LBB1_439
	ldr	x8, [x24, x8, lsl #3]
	ldr	x9, [x24, x9, lsl #3]
	cmp	x8, x9
	b.lo	LBB1_202
LBB1_201:
	ldr	x8, [x3, #8]
	add	x19, x8, x10
	tbnz	w19, #0, LBB1_203
LBB1_202:
	mov	w25, #0
	mov	x20, #0
	b	LBB1_405
LBB1_203:
	stp	xzr, x19, [x0]
	b	LBB1_371
LBB1_204:
	ldrb	w8, [x3, #3]
	ldrb	w9, [x1, #735]
	cmp	w8, #7
	csel	w2, w9, w8, eq
	and	w8, w2, #0xff
	cmp	w8, #5
	b.hs	LBB1_370
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #31
	b.hi	LBB1_440
	mov	x22, x1
	ldrb	w1, [x3, #4]
	ldrb	w21, [x3, #1]
	ldr	x0, [x24, x0, lsl #3]
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core9softfloat12f32_from_int
	cmp	w21, #32
	b.hs	LBB1_443
	mov	x8, x1
	mov	w25, #0
	mov	x20, #0
	orr	x9, x0, #0xffffffff00000000
	mov	x1, x22
	add	x10, x22, x21, lsl #3
	str	x9, [x10, #3104]
LBB1_208:
	and	w8, w8, #0x1f
	b	LBB1_369
LBB1_209:
	mov	x23, x0
	ldrb	w25, [x3, #1]
	cmp	w25, #0
	cset	w5, eq
	ldrb	w9, [x3, #2]
	cmp	x9, #0
	cset	w4, eq
	ldrh	w10, [x3, #4]
	b	LBB1_310
LBB1_210:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldrb	w25, [x3, #1]
	ldr	x9, [x24, x9, lsl #3]
	cbz	w9, LBB1_379
	ldr	x8, [x24, x8, lsl #3]
	udiv	w8, w8, w9
	b	LBB1_314
LBB1_214:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldr	x21, [x24, x8, lsl #3]
	tst	x21, #0x7
	b.eq	LBB1_386
LBB1_216:
	mov	w8, #4
	b	LBB1_340
LBB1_217:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	ldr	x9, [x24, x9, lsl #3]
	cbz	w9, LBB1_314
	cmn	w9, #1
	b.ne	LBB1_413
	mov	w8, #0
	b	LBB1_314
LBB1_222:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	asr	x20, x8, x9
	mov	x10, x19
	b	LBB1_401
LBB1_224:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldr	x8, [x24, x8, lsl #3]
	ldrb	w25, [x3, #1]
	ldr	x9, [x24, x9, lsl #3]
	and	x20, x9, x8
	mov	x10, x19
	b	LBB1_401
LBB1_227:
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_440
	mov	x8, x2
	ldrb	w25, [x3, #1]
	ldr	x9, [x3, #8]
	ldr	x10, [x24, x0, lsl #3]
	add	x21, x10, x9
	add	x0, sp, #8
	mov	x9, x1
	add	x1, x1, #24
	mov	x27, x9
	add	x2, x9, #736
	mov	x3, x8
	mov	x4, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart6cload8NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	x8, [sp, #8]
	cmn	x8, #1
	b.ne	LBB1_266
	mov	x22, #0
	mov	w26, #0
	ldrsb	x20, [sp, #16]
LBB1_230:
	mov	w9, #1
	b	LBB1_326
LBB1_231:
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_440
	mov	x8, x2
	ldrb	w25, [x3, #1]
	ldr	x9, [x3, #8]
	ldr	x10, [x24, x0, lsl #3]
	add	x21, x10, x9
	add	x0, sp, #8
	mov	x9, x1
	add	x1, x1, #24
	mov	x27, x9
	add	x2, x9, #736
	mov	x3, x8
	mov	x4, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart7cload64NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x20, [sp, #8]
	cmn	x8, #1
	b.ne	LBB1_324
	mov	x22, #0
	mov	w26, #0
	mov	w9, #8
	b	LBB1_326
LBB1_234:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	lsr	x20, x8, x9
	mov	x10, x19
	b	LBB1_401
LBB1_236:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldr	x8, [x24, x8, lsl #3]
	ldrb	w25, [x3, #1]
	ldr	x9, [x24, x9, lsl #3]
	add	x20, x9, x8
	mov	x10, x19
	b	LBB1_401
LBB1_239:
	ldrb	w8, [x3, #1]
	cmp	x8, #32
	b.hs	LBB1_437
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_440
	mov	x9, x2
	ldr	x10, [x3, #8]
	ldr	x8, [x24, x8, lsl #3]
	add	x21, x8, x10
	ldr	x22, [x24, x0, lsl #3]
	add	x0, sp, #8
	mov	x8, x1
	add	x1, x1, #24
	mov	x26, x8
	add	x2, x8, #736
	mov	x3, x9
	mov	x4, x21
	mov	x5, x22
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart18cstore16_with_physNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	w8, [sp, #8]
	tbnz	w8, #0, LBB1_286
	mov	w25, #0
	mov	x20, #0
	mov	w9, #2
	b	LBB1_374
LBB1_243:
	ldrb	w8, [x3, #1]
	cmp	x8, #32
	b.hs	LBB1_437
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_440
	mov	x9, x2
	ldr	x10, [x3, #8]
	ldr	x8, [x24, x8, lsl #3]
	add	x21, x8, x10
	ldr	x22, [x24, x0, lsl #3]
	add	x0, sp, #8
	mov	x8, x1
	add	x1, x1, #24
	mov	x26, x8
	add	x2, x8, #736
	mov	x3, x9
	mov	x4, x21
	mov	x5, x22
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart18cstore32_with_physNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	w8, [sp, #8]
	tbnz	w8, #0, LBB1_286
	mov	w25, #0
LBB1_247:
	mov	x20, #0
	mov	w9, #4
	b	LBB1_374
LBB1_248:
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_440
	mov	x8, x2
	ldrb	w25, [x3, #1]
	ldr	x9, [x3, #8]
	ldr	x10, [x24, x0, lsl #3]
	add	x21, x10, x9
	add	x0, sp, #8
	mov	x9, x1
	add	x1, x1, #24
	mov	x27, x9
	add	x2, x9, #736
	mov	x3, x8
	mov	x4, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart7cload16NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	x8, [sp, #8]
	cmn	x8, #1
	b.ne	LBB1_266
	mov	x22, #0
	mov	w26, #0
	ldrh	w20, [sp, #16]
	mov	w9, #2
	b	LBB1_326
LBB1_251:
	ldrb	w8, [x3, #3]
	ldrb	w9, [x1, #735]
	cmp	w8, #7
	csel	w8, w9, w8, eq
	and	w9, w8, #0xff
	cmp	w9, #5
	b.hs	LBB1_370
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #31
	b.hi	LBB1_442
	ldrb	w21, [x3, #1]
	mov	x22, x1
	add	x24, x1, #3104
	ldr	x9, [x24, x0, lsl #3]
	mov	x10, #-4294967297
	cmp	x9, x10
	mov	w10, #2143289344
	csel	w0, w9, w10, hi
	mov	x1, x8
	bl	__RNvXsg_NtCs5joLtdXDRmI_12wasm_vm_core9softfloatNtB5_3F32NtB5_9SoftFloat4sqrt
LBB1_254:
	cmp	w21, #32
	b.hs	LBB1_443
LBB1_255:
	mov	w25, #0
	mov	x20, #0
	orr	x8, x0, #0xffffffff00000000
	str	x8, [x24, x21, lsl #3]
	b	LBB1_368
LBB1_256:
	ldrb	w8, [x3, #5]
	ldrb	w9, [x1, #735]
	cmp	w8, #7
	csel	w8, w9, w8, eq
	and	w9, w8, #0xff
	cmp	w9, #5
	b.hs	LBB1_370
	ldrb	w9, [x3, #2]
	cmp	x9, #31
	b.hi	LBB1_444
	add	x22, x1, #3104
	ldr	x10, [x22, x9, lsl #3]
	ldrb	w9, [x3, #3]
	mov	x12, #-4294967297
	cmp	x10, x12
	mov	w13, #2143289344
	csel	w11, w10, w13, hi
	cmp	w9, #32
	b.hs	LBB1_444
	ldrb	w10, [x3, #4]
	ldr	x9, [x22, x9, lsl #3]
	cmp	x9, x12
	csel	w9, w9, w13, hi
	cmp	w10, #32
	b.hs	LBB1_447
	mov	x23, x0
	ldrb	w12, [x3, #6]
	ldrb	w21, [x3, #1]
	ldr	x10, [x22, x10, lsl #3]
	mov	x13, #-4294967297
	cmp	x10, x13
	mov	w13, #2143289344
	csel	w10, w10, w13, hi
	eor	w13, w11, #0x80000000
	eor	w14, w10, #0x80000000
	cmp	w12, #2
	csel	w15, w10, w14, eq
	mov	w13, w13
	cmp	w12, #0
	csel	w10, w10, w14, eq
	cmp	w12, #1
	csel	w2, w15, w10, gt
	csel	w0, w13, w11, gt
	mov	x24, x1
	mov	x1, x9
	mov	x3, x8
	bl	__RNvXsg_NtCs5joLtdXDRmI_12wasm_vm_core9softfloatNtB5_3F32NtB5_9SoftFloat3fma
	cmp	w21, #31
	b.hi	LBB1_443
	mov	w25, #0
	mov	x20, #0
	orr	x8, x0, #0xffffffff00000000
	str	x8, [x22, x21, lsl #3]
	and	w8, w1, #0x1f
	mov	x1, x24
	ldrb	w9, [x24, #734]
	orr	w8, w9, w8
	strb	w8, [x24, #734]
	ldr	x8, [x24, #640]
	orr	x8, x8, #0x6000
	orr	x8, x8, #0x8000000000000000
	str	x8, [x24, #640]
	mov	x0, x23
	b	LBB1_405
LBB1_262:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	asr	w8, w8, w9
	b	LBB1_314
LBB1_264:
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_440
	mov	x8, x2
	ldrb	w25, [x3, #1]
	ldr	x9, [x3, #8]
	ldr	x10, [x24, x0, lsl #3]
	add	x21, x10, x9
	add	x0, sp, #8
	mov	x9, x1
	add	x1, x1, #24
	mov	x27, x9
	add	x2, x9, #736
	mov	x3, x8
	mov	x4, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart7cload32NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	x8, [sp, #8]
	cmn	x8, #1
	b.eq	LBB1_389
LBB1_266:
	ldr	x9, [sp, #16]
	mov	x0, x23
	stp	x8, x9, [x23]
	b	LBB1_371
LBB1_267:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldrb	w25, [x3, #1]
	ldr	x20, [x24, x8, lsl #3]
	ldr	x8, [x24, x9, lsl #3]
	cbz	x8, LBB1_380
	mov	x9, #-9223372036854775808
	cmp	x20, x9
	ccmn	x8, #1, #0, eq
	b.eq	LBB1_407
	cmn	x8, #1
	b.eq	LBB1_407
	sdiv	x9, x20, x8
LBB1_273:
	msub	x20, x9, x8, x20
	mov	x10, x19
	b	LBB1_401
LBB1_274:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	ldr	x9, [x24, x9, lsl #3]
	mul	w8, w8, w9
	b	LBB1_314
LBB1_277:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldr	x8, [x24, x8, lsl #3]
	ldrb	w25, [x3, #1]
	ldr	x9, [x24, x9, lsl #3]
	asr	x20, x8, x9
	mov	x10, x19
	b	LBB1_401
LBB1_280:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldr	w9, [x3, #8]
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	add	w8, w8, w9
	b	LBB1_314
LBB1_282:
	ldrb	w8, [x3, #1]
	cmp	x8, #32
	b.hs	LBB1_437
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_440
	mov	x9, x2
	ldr	x10, [x3, #8]
	ldr	x8, [x24, x8, lsl #3]
	add	x21, x8, x10
	ldr	x22, [x24, x0, lsl #3]
LBB1_285:
	add	x0, sp, #8
	mov	x8, x1
	add	x1, x1, #24
	mov	x26, x8
	add	x2, x8, #736
	mov	x3, x9
	mov	x4, x21
	mov	x5, x22
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart18cstore64_with_physNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	w8, [sp, #8]
	tbz	w8, #0, LBB1_372
LBB1_286:
	ldur	q0, [sp, #16]
	mov	x0, x23
	str	q0, [x23]
	b	LBB1_371
LBB1_287:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldr	x9, [x3, #8]
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	and	x20, x8, x9
	mov	x10, x19
	b	LBB1_401
LBB1_289:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	lsl	x20, x8, x9
	mov	x10, x19
	b	LBB1_401
LBB1_291:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldr	x8, [x24, x8, lsl #3]
	ldrb	w25, [x3, #1]
	ldr	x9, [x24, x9, lsl #3]
	lsr	x20, x8, x9
	mov	x10, x19
	b	LBB1_401
LBB1_294:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldr	x8, [x24, x8, lsl #3]
	ldrb	w25, [x3, #1]
	ldr	x9, [x24, x9, lsl #3]
	umulh	x20, x9, x8
	mov	x10, x19
	b	LBB1_401
LBB1_297:
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_440
	ldrb	w25, [x3, #1]
	cmp	w25, #0
	cset	w5, eq
	ldr	x9, [x24, x0, lsl #3]
LBB1_299:
	ldrh	w10, [x3, #4]
	add	x8, sp, #8
	mov	x27, x1
	add	x0, x1, #24
	mov	x1, x10
	mov	w2, #0
	mov	x3, x9
	mov	w4, #0
	b	LBB1_323
LBB1_300:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldrb	w25, [x3, #1]
	ldr	x11, [x24, x9, lsl #3]
	cbz	x11, LBB1_379
	ldr	x8, [x24, x8, lsl #3]
	mov	x20, #-9223372036854775808
	cmp	x8, x20
	ccmn	x11, #1, #0, eq
	b.eq	LBB1_380
	mov	x10, x19
	sdiv	x20, x8, x11
	b	LBB1_401
LBB1_305:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldr	x8, [x24, x8, lsl #3]
	ldrb	w25, [x3, #1]
	ldr	x9, [x24, x9, lsl #3]
	smulh	x20, x9, x8
	mov	x10, x19
	b	LBB1_401
LBB1_308:
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	w0, #32
	b.hs	LBB1_440
	ldrb	w25, [x3, #1]
	cmp	w25, #0
	cset	w5, eq
	ldr	x9, [x24, x0, lsl #3]
	ldrh	w10, [x3, #4]
	cmp	w0, #0
	cset	w4, eq
LBB1_310:
	add	x8, sp, #8
	mov	x27, x1
	add	x0, x1, #24
	mov	x1, x10
	mov	w2, #1
	b	LBB1_322
LBB1_311:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_439
	ldrb	w25, [x3, #1]
	ldr	x8, [x24, x8, lsl #3]
	ldr	x9, [x24, x9, lsl #3]
	add	w8, w9, w8
LBB1_314:
	sxtw	x20, w8
	mov	x10, x19
	b	LBB1_401
LBB1_315:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_441
	add	x9, x1, #3104
	ldr	x10, [x9, x8, lsl #3]
	ldrb	w8, [x3, #3]
	mov	x11, #-4294967297
	cmp	x10, x11
	mov	w12, #2143289344
	csel	w10, w10, w12, hi
	cmp	x8, #32
	b.hs	LBB1_441
	ldrb	w13, [x3, #4]
	ldr	x14, [x9, x8, lsl #3]
	ldrb	w8, [x3, #1]
	cmp	x14, x11
	csel	w11, w14, w12, hi
	and	w12, w11, #0x80000000
	mov	w14, #-2147483648
	bic	w14, w14, w11
	eor	w11, w11, w10
	and	w11, w11, #0x80000000
	cmp	w13, #1
	csel	w11, w14, w11, eq
	cmp	w13, #0
	csel	w11, w12, w11, eq
	cmp	w8, #31
	b.hi	LBB1_446
	mov	w25, #0
	mov	x20, #0
	and	w10, w10, #0x7fffffff
	orr	w10, w11, w10
	orr	x10, x10, #0xffffffff00000000
	str	x10, [x9, x8, lsl #3]
	b	LBB1_435
LBB1_319:
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	w0, #32
	b.hs	LBB1_440
	ldrb	w25, [x3, #1]
	cmp	w25, #0
	cset	w5, eq
	ldr	x9, [x24, x0, lsl #3]
	ldrh	w10, [x3, #4]
	cmp	w0, #0
	cset	w4, eq
LBB1_321:
	add	x8, sp, #8
	mov	x27, x1
	add	x0, x1, #24
	mov	x1, x10
	mov	w2, #2
LBB1_322:
	mov	x3, x9
LBB1_323:
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6access
	ldp	x8, x20, [sp, #8]
	cmn	x8, #1
	b.eq	LBB1_325
LBB1_324:
	mov	x0, x23
	stp	x8, x20, [x23]
	b	LBB1_371
LBB1_325:
LBB1_326:
	mov	x10, x19
	mov	x0, x23
	mov	x1, x27
	b	LBB1_401
LBB1_327:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_441
	ldrb	w25, [x3, #1]
	add	x8, x1, x8, lsl #3
	ldr	x20, [x8, #3104]
	mov	x10, x19
	b	LBB1_401
LBB1_329:
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_442
	ldrb	w25, [x3, #1]
	add	x8, x1, x0, lsl #3
	ldr	x0, [x8, #3104]
	mov	x20, x1
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core9softfloat10fclass_f64
	b	LBB1_350
LBB1_331:
	ldrb	w8, [x1, #733]
	cmp	w8, #3
	b.ne	LBB1_370
	mov	x20, x0
	add	x0, x1, #24
	mov	x21, x1
	mov	w1, #833
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs4read
	mov	x19, x0
	add	x0, x21, #24
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs4mret
LBB1_333:
	mov	x1, x21
	mov	x0, x20
	mov	w25, #0
	mov	x20, #0
	str	xzr, [x21]
	b	LBB1_405
LBB1_334:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_441
	mov	x23, x0
	ldrb	w0, [x3, #3]
	cmp	x0, #32
	b.hs	LBB1_442
	ldrb	w2, [x3, #4]
	ldrb	w21, [x3, #1]
	mov	x22, x1
	add	x24, x1, #3104
	ldr	x8, [x24, x8, lsl #3]
	ldr	x1, [x24, x0, lsl #3]
	mov	x0, x8
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core9softfloat10f64_minmax
	cmp	w21, #32
	b.lo	LBB1_367
	b	LBB1_443
LBB1_337:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_437
	ldr	x21, [x24, x8, lsl #3]
	tst	x21, #0x3
	b.eq	LBB1_390
LBB1_339:
	mov	w8, #6
LBB1_340:
	stp	x8, x21, [x0]
	b	LBB1_371
LBB1_341:
	mov	x20, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_440
	mov	x8, x2
	ldrb	w23, [x3, #1]
	ldr	x9, [x3, #8]
	ldr	x10, [x24, x0, lsl #3]
	add	x21, x10, x9
	add	x0, sp, #8
	mov	x9, x1
	add	x1, x1, #24
	mov	x24, x9
	add	x2, x9, #736
	mov	x3, x8
	mov	x4, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart7cload64NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x9, x8, [sp, #8]
	cmn	x9, #1
	b.eq	LBB1_392
	mov	x0, x20
	stp	x9, x8, [x20]
	b	LBB1_371
LBB1_344:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_441
	ldrb	w9, [x3, #3]
	cmp	x9, #32
	b.hs	LBB1_444
	ldrb	w12, [x3, #4]
	add	x10, x1, #3104
	ldr	x11, [x10, x8, lsl #3]
	ldrb	w8, [x3, #1]
	ldr	x9, [x10, x9, lsl #3]
	and	x13, x9, #0x8000000000000000
	cmp	w12, #1
	mov	x14, #-9223372036854775808
	bic	x14, x14, x9
	eor	x9, x9, x11
	and	x9, x9, #0x8000000000000000
	csel	x9, x14, x9, eq
	cmp	w12, #0
	csel	x9, x13, x9, eq
	cmp	w8, #31
	b.hi	LBB1_446
	mov	w25, #0
	mov	x20, #0
	and	x11, x11, #0x7fffffffffffffff
	orr	x9, x9, x11
	str	x9, [x10, x8, lsl #3]
	b	LBB1_435
LBB1_348:
	mov	x23, x0
	ldrb	w0, [x3, #2]
	cmp	x0, #32
	b.hs	LBB1_442
	ldrb	w25, [x3, #1]
	add	x8, x1, x0, lsl #3
	ldr	x8, [x8, #3104]
	mov	x9, #-4294967297
	cmp	x8, x9
	mov	w9, #2143289344
	csel	w0, w8, w9, hi
	mov	x20, x1
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core9softfloat10fclass_f32
LBB1_350:
	mov	x1, x20
	mov	x20, x0
	b	LBB1_399
LBB1_351:
	ldrb	w8, [x3, #2]
	cmp	x8, #32
	b.hs	LBB1_441
	add	x10, x1, #3104
	ldr	x8, [x10, x8, lsl #3]
	ldrb	w9, [x3, #3]
	mov	x11, #-4294967297
	cmp	x8, x11
	mov	w12, #2143289344
	csel	w8, w8, w12, hi
	cmp	x9, #32
	b.hs	LBB1_444
	ldrb	w13, [x3, #4]
	ldrb	w25, [x3, #1]
	ldr	x9, [x10, x9, lsl #3]
	cmp	x9, x11
	csel	w9, w9, w12, hi
	mov	x20, x1
	mov	x23, x0
	mov	x0, x8
	mov	x1, x9
	cbz	w13, LBB1_396
	cmp	w13, #1
	b.ne	LBB1_397
	bl	__RNvXsg_NtCs5joLtdXDRmI_12wasm_vm_core9softfloatNtB5_3F32NtB5_9SoftFloat2lt
	b	LBB1_398
LBB1_356:
	ldrb	w8, [x3, #4]
	ldrb	w9, [x1, #735]
	cmp	w8, #7
	csel	w2, w9, w8, eq
	and	w8, w2, #0xff
	cmp	w8, #5
	b.hs	LBB1_370
	ldrb	w8, [x3, #2]
	cmp	x8, #31
	b.hi	LBB1_441
	ldrb	w10, [x3, #3]
	cmp	w10, #32
	b.hs	LBB1_447
	ldrb	w11, [x3, #5]
	ldrb	w21, [x3, #1]
	add	x22, x1, #3104
	ldr	x9, [x22, x8, lsl #3]
	ldr	x8, [x22, x10, lsl #3]
	mov	x20, x1
	mov	x23, x0
	mov	x0, x9
	mov	x1, x8
	cmp	w11, #1
	b.gt	LBB1_411
	cbnz	w11, LBB1_430
	bl	__RNvXsi_NtCs5joLtdXDRmI_12wasm_vm_core9softfloatNtB5_3F64NtB5_9SoftFloat3add
	b	LBB1_432
LBB1_362:
	ldrb	w8, [x3, #5]
	ldrb	w9, [x1, #735]
	cmp	w8, #7
	csel	w8, w9, w8, eq
	and	w9, w8, #0xff
	cmp	w9, #5
	b.hs	LBB1_370
	ldrb	w9, [x3, #2]
	cmp	x9, #31
	b.hi	LBB1_444
	ldrb	w10, [x3, #3]
	cmp	w10, #32
	b.hs	LBB1_447
	ldrb	w11, [x3, #4]
	cmp	w11, #32
	b.hs	LBB1_449
	mov	x23, x0
	ldrb	w12, [x3, #6]
	ldrb	w21, [x3, #1]
	mov	x22, x1
	add	x24, x1, #3104
	ldr	x9, [x24, x9, lsl #3]
	ldr	x1, [x24, x10, lsl #3]
	ldr	x10, [x24, x11, lsl #3]
	cmp	w12, #2
	eor	x11, x9, #0x8000000000000000
	eor	x13, x10, #0x8000000000000000
	csel	x14, x10, x13, eq
	mov	x11, x11
	cmp	w12, #0
	csel	x10, x10, x13, eq
	cmp	w12, #1
	csel	x2, x14, x10, gt
	csel	x0, x11, x9, gt
	mov	x3, x8
	bl	__RNvXsi_NtCs5joLtdXDRmI_12wasm_vm_core9softfloatNtB5_3F64NtB5_9SoftFloat3fma
	cmp	w21, #31
	b.hi	LBB1_443
LBB1_367:
	mov	w25, #0
	mov	x20, #0
	str	x0, [x24, x21, lsl #3]
LBB1_368:
	and	w8, w1, #0x1f
	mov	x1, x22
LBB1_369:
	ldrb	w9, [x22, #734]
	orr	w8, w9, w8
	strb	w8, [x22, #734]
	ldr	x8, [x22, #640]
	orr	x8, x8, #0x6000
	orr	x8, x8, #0x8000000000000000
	str	x8, [x22, #640]
	mov	x0, x23
	b	LBB1_405
LBB1_370:
	mov	w8, #2
	stp	x8, x6, [x0]
LBB1_371:
	mov	w26, #255
	b	LBB1_406
LBB1_372:
	mov	w25, #0
LBB1_373:
	mov	x20, #0
	mov	w9, #8
LBB1_374:
	mov	x0, x23
LBB1_375:
	mov	x1, x26
	ldr	w8, [x26]
	tbz	w8, #0, LBB1_378
	ldrb	w8, [x1, #16]
	ldr	x10, [x1, #8]
	add	x8, x10, x8
	add	x11, x21, w9, uxtw
	cmp	x10, x11
	ccmp	x21, x8, #2, lo
	b.hs	LBB1_378
	str	xzr, [x1]
LBB1_378:
	mov	w26, #1
	mov	x10, x19
	b	LBB1_401
LBB1_379:
	mov	x20, #-1
LBB1_380:
	mov	x10, x19
	b	LBB1_401
LBB1_381:
	stp	xzr, x10, [x0]
	b	LBB1_371
LBB1_382:
	str	xzr, [x1]
LBB1_383:
	mov	w20, #1
	mov	x10, x19
	b	LBB1_401
LBB1_384:
	cmp	w23, #31
	b.hi	LBB1_448
	mov	x0, x20
	mov	w25, #0
	mov	x20, #0
	mov	w26, #0
	mov	x22, #0
	ldr	w8, [sp, #16]
	orr	x8, x8, #0xffffffff00000000
	mov	x1, x24
	add	x9, x24, x23, lsl #3
	str	x8, [x9, #3104]
	ldr	x8, [x24, #640]
	orr	x8, x8, #0x6000
	orr	x8, x8, #0x8000000000000000
	str	x8, [x24, #640]
	mov	w9, #4
	b	LBB1_405
LBB1_386:
	mov	x23, x0
	ldrb	w25, [x3, #1]
	add	x0, sp, #8
	mov	x8, x1
	add	x1, x1, #24
	mov	x27, x8
	mov	x3, x2
	add	x2, x8, #736
	mov	x4, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart7cload64NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x20, [sp, #8]
	cmn	x8, #1
	b.ne	LBB1_324
	mov	x22, #0
	mov	w26, #0
	mov	w8, #1
	mov	x1, x27
	stp	x8, x21, [x27]
	mov	w9, #8
LBB1_388:
	strb	w9, [x27, #16]
	b	LBB1_400
LBB1_389:
	mov	x22, #0
	mov	w26, #0
	ldr	w20, [sp, #16]
	mov	w9, #4
	b	LBB1_326
LBB1_390:
	mov	x27, x0
	ldrb	w22, [x3, #4]
	ldrb	w25, [x3, #1]
	ldrb	w20, [x3, #3]
	add	x0, sp, #8
	mov	x8, x1
	add	x1, x1, #24
	mov	x26, x8
	mov	x3, x2
	add	x2, x8, #736
	mov	x23, x3
	mov	x4, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart10camoload32NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	x8, [sp, #8]
	cmn	x8, #1
	b.eq	LBB1_423
	ldr	x9, [sp, #16]
	mov	x0, x27
	stp	x8, x9, [x27]
	b	LBB1_371
LBB1_392:
	cmp	w23, #31
	b.hi	LBB1_448
	mov	x0, x20
	mov	w25, #0
	mov	x20, #0
	mov	w26, #0
	mov	x22, #0
	mov	x1, x24
	add	x9, x24, x23, lsl #3
	str	x8, [x9, #3104]
	ldr	x8, [x24, #640]
	orr	x8, x8, #0x6000
	orr	x8, x8, #0x8000000000000000
	str	x8, [x24, #640]
	mov	w9, #8
	b	LBB1_405
LBB1_394:
	bl	__RNvXsi_NtCs5joLtdXDRmI_12wasm_vm_core9softfloatNtB5_3F64NtB5_9SoftFloat2le
	b	LBB1_398
LBB1_395:
	bl	__RNvXsi_NtCs5joLtdXDRmI_12wasm_vm_core9softfloatNtB5_3F64NtB5_9SoftFloat2eq
	b	LBB1_398
LBB1_396:
	bl	__RNvXsg_NtCs5joLtdXDRmI_12wasm_vm_core9softfloatNtB5_3F32NtB5_9SoftFloat2le
	b	LBB1_398
LBB1_397:
	bl	__RNvXsg_NtCs5joLtdXDRmI_12wasm_vm_core9softfloatNtB5_3F32NtB5_9SoftFloat2eq
LBB1_398:
	and	w8, w1, #0x1f
	mov	x1, x20
	ldrb	w9, [x20, #734]
	orr	w8, w8, w9
	strb	w8, [x20, #734]
	ldr	x8, [x20, #640]
	orr	x8, x8, #0x6000
	orr	x8, x8, #0x8000000000000000
	str	x8, [x20, #640]
	and	x20, x0, #0x1
LBB1_399:
LBB1_400:
	mov	x10, x19
	mov	x0, x23
LBB1_401:
	cbz	w25, LBB1_404
	mov	w8, w25
	cmp	w25, #31
	b.hi	LBB1_438
	str	x20, [x24, x8, lsl #3]
	ldr	x8, [x1, #3096]
	add	x8, x8, #1
	str	x8, [x1, #3096]
LBB1_404:
	mov	x19, x10
LBB1_405:
	str	x19, [x1, #3088]
	str	x20, [x0]
	strb	w25, [x0, #8]
	stp	x21, x22, [x0, #16]
	strb	w9, [x0, #32]
LBB1_406:
	strb	w26, [x0, #33]
	.cfi_def_cfa wsp, 128
	ldp	x29, x30, [sp, #112]
	ldp	x20, x19, [sp, #96]
	ldp	x22, x21, [sp, #80]
	ldp	x24, x23, [sp, #64]
	ldp	x26, x25, [sp, #48]
	ldp	x28, x27, [sp, #32]
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	ret
LBB1_407:
	.cfi_restore_state
	mov	x20, #0
	mov	x10, x19
	b	LBB1_401
LBB1_408:
	mov	x20, #-2147483648
	mov	x10, x19
	b	LBB1_401
LBB1_409:
	cmp	w10, #2
	b.ne	LBB1_427
	bl	__RNvXsg_NtCs5joLtdXDRmI_12wasm_vm_core9softfloatNtB5_3F32NtB5_9SoftFloat3mul
	b	LBB1_428
LBB1_411:
	cmp	w11, #2
	b.ne	LBB1_431
	bl	__RNvXsi_NtCs5joLtdXDRmI_12wasm_vm_core9softfloatNtB5_3F64NtB5_9SoftFloat3mul
	b	LBB1_432
LBB1_413:
	sdiv	w10, w8, w9
	msub	w8, w10, w9, w8
	b	LBB1_314
LBB1_414:
	mov	x9, #0
LBB1_415:
	cbz	w8, LBB1_418
	cmp	w8, #32
	b.hs	LBB1_437
	mov	x23, x0
	lsl	x8, x8, #3
	ldrh	w4, [x24, x8]
	mov	w3, #1
	b	LBB1_419
LBB1_418:
	mov	x23, x0
	mov	x3, #0
LBB1_419:
	add	x0, x1, #736
	mov	x20, x1
	mov	x1, x9
	bl	__RNvMs0_NtCs5joLtdXDRmI_12wasm_vm_core3tlbNtB5_3Tlb6sfence
	mov	x1, x20
	mov	w25, #0
	mov	x20, #0
	mov	x0, x23
	b	LBB1_405
LBB1_420:
	cmp	w22, #31
	b.hi	LBB1_450
	ldr	x8, [x24, x22, lsl #3]
	cmp	x20, x8
	csel	x9, x20, x8, gt
	csel	x10, x20, x8, lo
	csel	x11, x20, x8, hi
	cmp	w28, #7
	csel	x10, x10, x11, eq
	cmp	w28, #6
	csel	x9, x9, x10, eq
	orr	x10, x8, x20
	cmp	x20, x8
	csel	x11, x20, x8, lt
	cmp	w28, #4
	csel	x10, x10, x11, eq
	cmp	w28, #5
	csel	x9, x9, x10, gt
	cmp	w28, #2
	eor	x10, x8, x20
	and	x11, x8, x20
	csel	x10, x10, x11, eq
	add	x11, x8, x20
	cmp	w28, #0
	csel	x8, x8, x11, eq
	cmp	w28, #1
	csel	x8, x10, x8, gt
	cmp	w28, #3
	csel	x22, x9, x8, gt
	add	x0, sp, #8
	add	x1, x26, #24
	add	x2, x26, #736
	mov	x3, x23
	mov	x4, x21
	mov	x5, x22
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart18cstore64_with_physNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	w8, [sp, #8]
	tbnz	w8, #0, LBB1_425
	mov	w9, #8
	mov	x0, x27
	b	LBB1_375
LBB1_423:
	cmp	w20, #31
	b.hi	LBB1_451
	ldr	x8, [x24, x20, lsl #3]
	ldrsw	x20, [sp, #16]
	cmp	w20, w8
	csel	w9, w20, w8, gt
	cmp	w20, w8
	csel	w10, w20, w8, lo
	cmp	w20, w8
	csel	w11, w20, w8, hi
	cmp	w22, #7
	csel	w10, w10, w11, eq
	cmp	w22, #6
	csel	w9, w9, w10, eq
	orr	w10, w20, w8
	cmp	w20, w8
	csel	w11, w20, w8, lt
	cmp	w22, #4
	csel	w10, w10, w11, eq
	cmp	w22, #5
	csel	w9, w9, w10, gt
	eor	w10, w20, w8
	and	w11, w20, w8
	cmp	w22, #2
	csel	w10, w10, w11, eq
	add	w11, w20, w8
	cmp	w22, #0
	csel	w8, w8, w11, eq
	cmp	w22, #1
	csel	w8, w10, w8, gt
	cmp	w22, #3
	csel	w22, w9, w8, gt
	add	x0, sp, #8
	add	x1, x26, #24
	add	x2, x26, #736
	mov	x3, x23
	mov	x4, x21
	mov	x5, x22
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart18cstore32_with_physNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	w8, [sp, #8]
	tbz	w8, #0, LBB1_436
LBB1_425:
	ldur	q0, [sp, #16]
	mov	x0, x27
	str	q0, [x27]
	b	LBB1_371
LBB1_426:
	bl	__RNvXsg_NtCs5joLtdXDRmI_12wasm_vm_core9softfloatNtB5_3F32NtB5_9SoftFloat3sub
	b	LBB1_428
LBB1_427:
	bl	__RNvXsg_NtCs5joLtdXDRmI_12wasm_vm_core9softfloatNtB5_3F32NtB5_9SoftFloat3div
LBB1_428:
	mov	x8, x0
	mov	x9, x1
	cmp	w21, #31
	b.hi	LBB1_443
	mov	x0, x23
	mov	x1, x20
	mov	w25, #0
	mov	x20, #0
	orr	x8, x8, #0xffffffff00000000
	b	LBB1_434
LBB1_430:
	bl	__RNvXsi_NtCs5joLtdXDRmI_12wasm_vm_core9softfloatNtB5_3F64NtB5_9SoftFloat3sub
	b	LBB1_432
LBB1_431:
	bl	__RNvXsi_NtCs5joLtdXDRmI_12wasm_vm_core9softfloatNtB5_3F64NtB5_9SoftFloat3div
LBB1_432:
	mov	x8, x0
	mov	x9, x1
	cmp	w21, #31
	b.hi	LBB1_443
	mov	x0, x23
	mov	x1, x20
	mov	w25, #0
	mov	x20, #0
LBB1_434:
	str	x8, [x22, x21, lsl #3]
	and	w8, w9, #0x1f
	ldrb	w9, [x1, #734]
	orr	w8, w9, w8
	strb	w8, [x1, #734]
LBB1_435:
	ldr	x8, [x1, #640]
	orr	x8, x8, #0x6000
	orr	x8, x8, #0x8000000000000000
	str	x8, [x1, #640]
	b	LBB1_405
LBB1_436:
	mov	w9, #4
	mov	x0, x27
	b	LBB1_375
LBB1_437:
Lloh4:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.20@PAGE
Lloh5:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.20@PAGEOFF
	mov	x0, x8
	mov	w1, #32
	bl	__RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check
LBB1_438:
Lloh6:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.24@PAGE
Lloh7:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.24@PAGEOFF
	mov	x0, x8
	mov	w1, #32
	bl	__RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check
LBB1_439:
Lloh8:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.20@PAGE
Lloh9:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.20@PAGEOFF
	mov	x0, x9
	mov	w1, #32
	bl	__RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check
LBB1_440:
Lloh10:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.20@PAGE
Lloh11:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.20@PAGEOFF
	mov	w1, #32
	bl	__RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check
LBB1_441:
Lloh12:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.23@PAGE
Lloh13:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.23@PAGEOFF
	mov	x0, x8
	mov	w1, #32
	bl	__RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check
LBB1_442:
Lloh14:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.23@PAGE
Lloh15:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.23@PAGEOFF
	mov	w1, #32
	bl	__RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check
LBB1_443:
Lloh16:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.22@PAGE
Lloh17:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.22@PAGEOFF
	mov	x0, x21
	mov	w1, #32
	bl	__RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check
LBB1_444:
Lloh18:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.23@PAGE
Lloh19:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.23@PAGEOFF
	mov	x0, x9
	mov	w1, #32
	bl	__RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check
LBB1_445:
Lloh20:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.22@PAGE
Lloh21:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.22@PAGEOFF
	mov	x0, x9
	mov	w1, #32
	bl	__RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check
LBB1_446:
Lloh22:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.22@PAGE
Lloh23:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.22@PAGEOFF
	mov	x0, x8
	mov	w1, #32
	bl	__RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check
LBB1_447:
Lloh24:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.23@PAGE
Lloh25:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.23@PAGEOFF
	mov	x0, x10
	mov	w1, #32
	bl	__RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check
LBB1_448:
Lloh26:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.22@PAGE
Lloh27:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.22@PAGEOFF
	mov	x0, x23
	mov	w1, #32
	bl	__RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check
LBB1_449:
Lloh28:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.23@PAGE
Lloh29:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.23@PAGEOFF
	mov	x0, x11
	mov	w1, #32
	bl	__RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check
LBB1_450:
Lloh30:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.20@PAGE
Lloh31:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.20@PAGEOFF
	mov	x0, x22
	mov	w1, #32
	bl	__RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check
LBB1_451:
Lloh32:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.20@PAGE
Lloh33:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.20@PAGEOFF
	mov	x0, x20
	mov	w1, #32
	bl	__RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpAdd	Lloh16, Lloh17
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpAdd	Lloh20, Lloh21
	.loh AdrpAdd	Lloh22, Lloh23
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdd	Lloh26, Lloh27
	.loh AdrpAdd	Lloh28, Lloh29
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpAdd	Lloh32, Lloh33
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
LJTI1_0:
	.short	(LBB1_3-LBB1_3)>>2
	.short	(LBB1_148-LBB1_3)>>2
	.short	(LBB1_149-LBB1_3)>>2
	.short	(LBB1_178-LBB1_3)>>2
	.short	(LBB1_121-LBB1_3)>>2
	.short	(LBB1_129-LBB1_3)>>2
	.short	(LBB1_115-LBB1_3)>>2
	.short	(LBB1_132-LBB1_3)>>2
	.short	(LBB1_151-LBB1_3)>>2
	.short	(LBB1_198-LBB1_3)>>2
	.short	(LBB1_227-LBB1_3)>>2
	.short	(LBB1_118-LBB1_3)>>2
	.short	(LBB1_154-LBB1_3)>>2
	.short	(LBB1_231-LBB1_3)>>2
	.short	(LBB1_135-LBB1_3)>>2
	.short	(LBB1_248-LBB1_3)>>2
	.short	(LBB1_264-LBB1_3)>>2
	.short	(LBB1_104-LBB1_3)>>2
	.short	(LBB1_239-LBB1_3)>>2
	.short	(LBB1_243-LBB1_3)>>2
	.short	(LBB1_282-LBB1_3)>>2
	.short	(LBB1_93-LBB1_3)>>2
	.short	(LBB1_188-LBB1_3)>>2
	.short	(LBB1_185-LBB1_3)>>2
	.short	(LBB1_91-LBB1_3)>>2
	.short	(LBB1_99-LBB1_3)>>2
	.short	(LBB1_287-LBB1_3)>>2
	.short	(LBB1_289-LBB1_3)>>2
	.short	(LBB1_234-LBB1_3)>>2
	.short	(LBB1_222-LBB1_3)>>2
	.short	(LBB1_236-LBB1_3)>>2
	.short	(LBB1_126-LBB1_3)>>2
	.short	(LBB1_101-LBB1_3)>>2
	.short	(LBB1_85-LBB1_3)>>2
	.short	(LBB1_88-LBB1_3)>>2
	.short	(LBB1_79-LBB1_3)>>2
	.short	(LBB1_291-LBB1_3)>>2
	.short	(LBB1_277-LBB1_3)>>2
	.short	(LBB1_175-LBB1_3)>>2
	.short	(LBB1_224-LBB1_3)>>2
	.short	(LBB1_280-LBB1_3)>>2
	.short	(LBB1_51-LBB1_3)>>2
	.short	(LBB1_124-LBB1_3)>>2
	.short	(LBB1_262-LBB1_3)>>2
	.short	(LBB1_311-LBB1_3)>>2
	.short	(LBB1_82-LBB1_3)>>2
	.short	(LBB1_138-LBB1_3)>>2
	.short	(LBB1_172-LBB1_3)>>2
	.short	(LBB1_40-LBB1_3)>>2
	.short	(LBB1_32-LBB1_3)>>2
	.short	(LBB1_305-LBB1_3)>>2
	.short	(LBB1_67-LBB1_3)>>2
	.short	(LBB1_294-LBB1_3)>>2
	.short	(LBB1_300-LBB1_3)>>2
	.short	(LBB1_74-LBB1_3)>>2
	.short	(LBB1_267-LBB1_3)>>2
	.short	(LBB1_141-LBB1_3)>>2
	.short	(LBB1_274-LBB1_3)>>2
	.short	(LBB1_163-LBB1_3)>>2
	.short	(LBB1_210-LBB1_3)>>2
	.short	(LBB1_217-LBB1_3)>>2
	.short	(LBB1_180-LBB1_3)>>2
	.short	(LBB1_168-LBB1_3)>>2
	.short	(LBB1_214-LBB1_3)>>2
	.short	(LBB1_56-LBB1_3)>>2
	.short	(LBB1_108-LBB1_3)>>2
	.short	(LBB1_337-LBB1_3)>>2
	.short	(LBB1_95-LBB1_3)>>2
	.short	(LBB1_405-LBB1_3)>>2
	.short	(LBB1_31-LBB1_3)>>2
	.short	(LBB1_66-LBB1_3)>>2
	.short	(LBB1_405-LBB1_3)>>2
	.short	(LBB1_297-LBB1_3)>>2
	.short	(LBB1_308-LBB1_3)>>2
	.short	(LBB1_319-LBB1_3)>>2
	.short	(LBB1_78-LBB1_3)>>2
	.short	(LBB1_209-LBB1_3)>>2
	.short	(LBB1_35-LBB1_3)>>2
	.short	(LBB1_331-LBB1_3)>>2
	.short	(LBB1_21-LBB1_3)>>2
	.short	(LBB1_63-LBB1_3)>>2
	.short	(LBB1_157-LBB1_3)>>2
	.short	(LBB1_145-LBB1_3)>>2
	.short	(LBB1_12-LBB1_3)>>2
	.short	(LBB1_4-LBB1_3)>>2
	.short	(LBB1_251-LBB1_3)>>2
	.short	(LBB1_256-LBB1_3)>>2
	.short	(LBB1_315-LBB1_3)>>2
	.short	(LBB1_43-LBB1_3)>>2
	.short	(LBB1_351-LBB1_3)>>2
	.short	(LBB1_348-LBB1_3)>>2
	.short	(LBB1_16-LBB1_3)>>2
	.short	(LBB1_191-LBB1_3)>>2
	.short	(LBB1_36-LBB1_3)>>2
	.short	(LBB1_204-LBB1_3)>>2
	.short	(LBB1_341-LBB1_3)>>2
	.short	(LBB1_25-LBB1_3)>>2
	.short	(LBB1_356-LBB1_3)>>2
	.short	(LBB1_195-LBB1_3)>>2
	.short	(LBB1_362-LBB1_3)>>2
	.short	(LBB1_344-LBB1_3)>>2
	.short	(LBB1_334-LBB1_3)>>2
	.short	(LBB1_46-LBB1_3)>>2
	.short	(LBB1_329-LBB1_3)>>2
	.short	(LBB1_327-LBB1_3)>>2
	.short	(LBB1_28-LBB1_3)>>2
	.short	(LBB1_18-LBB1_3)>>2
	.short	(LBB1_70-LBB1_3)>>2
	.short	(LBB1_53-LBB1_3)>>2
	.short	(LBB1_10-LBB1_3)>>2

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvMs1_NtCs5joLtdXDRmI_12wasm_vm_core4hartNtB6_4Hart9decode_atNtNtB8_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #96
	.cfi_def_cfa_offset 96
	stp	x26, x25, [sp, #16]
	stp	x24, x23, [sp, #32]
	stp	x22, x21, [sp, #48]
	stp	x20, x19, [sp, #64]
	stp	x29, x30, [sp, #80]
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_remember_state
	mov	x23, x3
	mov	x20, x2
	mov	x22, x1
	mov	x19, x0
	ldrb	w21, [x1, #733]
	mov	x0, sp
	add	x1, x1, #24
	add	x2, x22, #736
	mov	x3, x20
	mov	x4, x23
	mov	w5, #0
	mov	x6, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x24, [sp]
	cmn	x8, #1
	b.eq	LBB2_2
LBB2_1:
	mov	x23, x24
	b	LBB2_21
LBB2_2:
	add	x0, x22, #24
	mov	x1, x24
	mov	w2, #2
	mov	w3, #2
	mov	x4, x21
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6pmp_ok
	tbz	w0, #0, LBB2_20
	ldr	x8, [x20, #24]
	subs	x8, x24, x8
	b.lo	LBB2_6
	cmn	x8, #3
	b.hi	LBB2_6
	add	x9, x8, #2
	ldr	x10, [x20, #16]
	cmp	x9, x10
	b.ls	LBB2_27
LBB2_6:
	mov	w8, #1
	lsr	w9, w8, #8
	lsr	w21, w8, #16
	tbz	w8, #0, LBB2_8
LBB2_7:
	tbz	w9, #0, LBB2_34
LBB2_8:
	tbz	w8, #0, LBB2_10
LBB2_9:
	mov	w8, #1
	bic	w8, w8, w9
	b	LBB2_21
LBB2_10:
	mov	w8, #3
	bics	wzr, w8, w21
	b.ne	LBB2_24
	add	x23, x23, #2
	ldrb	w25, [x22, #733]
	mov	x0, sp
	add	x1, x22, #24
	add	x2, x22, #736
	mov	x3, x20
	mov	x4, x23
	mov	w5, #0
	mov	x6, x25
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x24, [sp]
	cmn	x8, #1
	b.ne	LBB2_1
	add	x0, x22, #24
	mov	x1, x24
	mov	w2, #2
	mov	w3, #2
	mov	x4, x25
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6pmp_ok
	tbz	w0, #0, LBB2_20
	ldr	x8, [x20, #24]
	subs	x8, x24, x8
	b.lo	LBB2_16
	cmn	x8, #3
	b.hi	LBB2_16
	add	x9, x8, #2
	ldr	x10, [x20, #16]
	cmp	x9, x10
	b.ls	LBB2_31
LBB2_16:
	mov	w8, #1
	lsr	w9, w8, #8
	lsr	w22, w8, #16
	tbz	w8, #0, LBB2_18
LBB2_17:
	tbz	w9, #0, LBB2_38
LBB2_18:
	tbnz	w8, #0, LBB2_9
	orr	w1, w21, w22, lsl #16
	mov	w20, #4
	mov	x21, x1
	mov	x8, sp
	mov	x0, x1
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core6decode6decode
	ldrb	w8, [sp]
	cmp	w8, #255
	b.ne	LBB2_26
	b	LBB2_29
LBB2_20:
	mov	w8, #1
LBB2_21:
	stp	x8, x23, [x19, #8]
LBB2_22:
	mov	w8, #255
	strb	w8, [x19]
LBB2_23:
	.cfi_def_cfa wsp, 96
	ldp	x29, x30, [sp, #80]
	ldp	x20, x19, [sp, #64]
	ldp	x22, x21, [sp, #48]
	ldp	x24, x23, [sp, #32]
	ldp	x26, x25, [sp, #16]
	add	sp, sp, #96
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	ret
LBB2_24:
	.cfi_restore_state
	mov	x0, x21
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core8decode_c8expand_c
	tbnz	w0, #0, LBB2_29
	mov	w20, #2
	mov	x8, sp
	mov	x0, x1
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core6decode6decode
	ldrb	w8, [sp]
	cmp	w8, #255
	b.eq	LBB2_29
LBB2_26:
	ldr	q0, [sp]
	str	q0, [x19]
	str	w21, [x19, #16]
	strb	w20, [x19, #20]
	b	LBB2_23
LBB2_27:
	tbnz	w24, #0, LBB2_30
	ldr	x9, [x20, #8]
	ldrh	w8, [x9, x8]
	lsl	w8, w8, #16
	lsr	w9, w8, #8
	lsr	w21, w8, #16
	tbnz	w8, #0, LBB2_7
	b	LBB2_8
LBB2_29:
	mov	w8, w21
	mov	w9, #2
	stp	x9, x8, [x19, #8]
	b	LBB2_22
LBB2_30:
	mov	w8, #257
	lsr	w9, w8, #8
	lsr	w21, w8, #16
	tbnz	w8, #0, LBB2_7
	b	LBB2_8
LBB2_31:
	tbnz	w24, #0, LBB2_33
	ldr	x9, [x20, #8]
	ldrh	w8, [x9, x8]
	lsl	w8, w8, #16
	lsr	w9, w8, #8
	lsr	w22, w8, #16
	tbnz	w8, #0, LBB2_17
	b	LBB2_18
LBB2_33:
	mov	w8, #257
	lsr	w9, w8, #8
	lsr	w22, w8, #16
	tbnz	w8, #0, LBB2_17
	b	LBB2_18
LBB2_34:
	ldp	x0, x1, [x20, #40]
	ldr	x8, [x20, #80]
	cbnz	x8, LBB2_36
	mov	x2, #0
	b	LBB2_37
LBB2_36:
	ldr	x3, [x20, #88]
	ldr	x9, [x3, #16]
	sub	x9, x9, #1
	and	x9, x9, #0xfffffffffffffff0
	add	x8, x8, x9
	add	x2, x8, #16
LBB2_37:
	mov	x8, sp
	add	x4, x20, #96
	mov	x5, x24
	mov	w6, #1
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio11load_device
	ldrb	w8, [sp]
	ldrb	w9, [sp, #1]
	ldrh	w10, [sp, #8]
	cmp	w8, #0
	csel	w21, w21, w10, ne
	csel	w9, w9, wzr, ne
	b	LBB2_8
LBB2_38:
	ldp	x0, x1, [x20, #40]
	ldr	x8, [x20, #80]
	cbnz	x8, LBB2_40
	mov	x2, #0
	b	LBB2_41
LBB2_40:
	ldr	x3, [x20, #88]
	ldr	x9, [x3, #16]
	sub	x9, x9, #1
	and	x9, x9, #0xfffffffffffffff0
	add	x8, x8, x9
	add	x2, x8, #16
LBB2_41:
	mov	x8, sp
	add	x4, x20, #96
	mov	x5, x24
	mov	w6, #1
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio11load_device
	ldrb	w8, [sp]
	ldrb	w9, [sp, #1]
	ldrh	w10, [sp, #8]
	cmp	w8, #0
	csel	w22, w22, w10, ne
	csel	w9, w9, wzr, ne
	b	LBB2_18
	.cfi_endproc

	.p2align	2
__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu15walk_leaf_innerNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	stp	x28, x27, [sp, #32]
	stp	x26, x25, [sp, #48]
	stp	x24, x23, [sp, #64]
	stp	x22, x21, [sp, #80]
	stp	x20, x19, [sp, #96]
	stp	x29, x30, [sp, #112]
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_remember_state
	mov	x26, x6
	mov	x22, x5
	mov	x21, x4
	mov	x20, x3
	mov	x23, x2
	mov	x24, x1
	mov	x19, x0
	mov	x0, x1
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs4satp
	cbz	x26, LBB3_35
	str	x21, [sp, #8]
	ubfiz	x25, x0, #12, #44
	sub	x26, x26, #1
	add	x27, x26, x26, lsl #3
	add	w8, w27, #12
	lsr	x8, x20, x8
	bfi	x25, x8, #3, #9
	mov	x0, x24
	mov	x1, x25
	mov	w2, #8
	mov	w3, #0
	mov	x4, x22
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6pmp_ok
	cbz	w0, LBB3_19
	mov	w28, #10
	mov	w21, #208
LBB3_3:
	ldr	x8, [x23, #24]
	subs	x8, x25, x8
	b.lo	LBB3_12
	add	x9, x8, #8
	ldr	x10, [x23, #16]
	cmp	x9, x10
	b.hi	LBB3_12
	ldr	x9, [x23, #8]
	ldr	x8, [x9, x8]
	tbz	w8, #0, LBB3_17
LBB3_6:
	and	x9, x8, #0x6
	cmp	x9, #4
	b.eq	LBB3_17
	lsr	x9, x8, #54
	cbnz	x9, LBB3_17
	lsr	x9, x8, #10
	tst	x8, x28
	b.ne	LBB3_23
	cbz	x26, LBB3_28
	and	x8, x8, x21
	cbnz	x8, LBB3_28
	lsl	x25, x9, #12
	sub	x26, x26, #1
	add	w8, w27, #3
	lsr	x8, x20, x8
	bfi	x25, x8, #3, #9
	mov	x0, x24
	mov	x1, x25
	mov	w2, #8
	mov	w3, #0
	mov	x4, x22
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6pmp_ok
	sub	x27, x27, #9
	tbnz	w0, #0, LBB3_3
	b	LBB3_19
LBB3_12:
	mov	w8, #1
	strh	w8, [sp, #16]
	ldr	x8, [x23, #80]
	cbnz	x8, LBB3_14
	mov	x2, #0
	b	LBB3_15
LBB3_14:
	ldr	x3, [x23, #88]
	ldr	x9, [x3, #16]
	sub	x9, x9, #1
	and	x9, x9, #0xfffffffffffffff0
	add	x8, x8, x9
	add	x2, x8, #16
LBB3_15:
	ldp	x0, x1, [x23, #40]
	add	x8, sp, #16
	add	x4, x23, #96
	mov	x5, x25
	mov	w6, #3
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio11load_device
	ldrb	w8, [sp, #16]
	tbnz	w8, #0, LBB3_34
	ldr	x8, [sp, #24]
	tbnz	w8, #0, LBB3_6
LBB3_17:
	ldr	x8, [sp, #8]
	ands	w8, w8, #0xff
	b.eq	LBB3_31
	cmp	w8, #1
	mov	w8, #13
	mov	w9, #1
	mov	w10, #15
	b	LBB3_21
LBB3_19:
	ldr	x8, [sp, #8]
	ands	w8, w8, #0xff
	b.eq	LBB3_22
	cmp	w8, #1
	mov	w8, #5
	mov	w9, #1
	mov	w10, #7
LBB3_21:
	csel	x8, x8, x10, eq
	csinc	x9, x9, xzr, ne
	b	LBB3_33
LBB3_22:
	mov	w8, #1
	mov	w9, #1
	b	LBB3_33
LBB3_23:
	cbz	x26, LBB3_32
	mov	x10, #-1
	lsl	x10, x10, x27
	bics	xzr, x9, x10
	b.eq	LBB3_32
	ldr	x8, [sp, #8]
	ands	w8, w8, #0xff
	b.eq	LBB3_31
	cmp	w8, #2
	b.ne	LBB3_30
LBB3_27:
	mov	w9, #1
	mov	w8, #15
	b	LBB3_33
LBB3_28:
	ldr	x8, [sp, #8]
	ands	w8, w8, #0xff
	b.eq	LBB3_31
	cmp	w8, #1
	b.ne	LBB3_27
LBB3_30:
	mov	w9, #1
	mov	w8, #13
	b	LBB3_33
LBB3_31:
	mov	w9, #1
	mov	w8, #12
	b	LBB3_33
LBB3_32:
	mov	x9, #0
	mov	x20, x26
LBB3_33:
	stp	x8, x20, [x19, #8]
	str	x9, [x19]
	.cfi_def_cfa wsp, 128
	ldp	x29, x30, [sp, #112]
	ldp	x20, x19, [sp, #96]
	ldp	x22, x21, [sp, #80]
	ldp	x24, x23, [sp, #64]
	ldp	x26, x25, [sp, #48]
	ldp	x28, x27, [sp, #32]
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	ret
LBB3_34:
	.cfi_restore_state
	ldr	x8, [sp, #8]
	and	x8, x8, #0xff
Lloh34:
	adrp	x9, l_switch.table._RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu15walk_leaf_innerNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe@PAGE
Lloh35:
	add	x9, x9, l_switch.table._RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu15walk_leaf_innerNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe@PAGEOFF
	ldr	x8, [x9, x8, lsl #3]
	mov	w9, #1
	b	LBB3_33
LBB3_35:
Lloh36:
	adrp	x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.27@PAGE
Lloh37:
	add	x0, x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.27@PAGEOFF
Lloh38:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.29@PAGE
Lloh39:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.29@PAGEOFF
	mov	w1, #177
	bl	__RNvNtCslWxY2MhVcag_4core9panicking9panic_fmt
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpAdd	Lloh36, Lloh37
	.cfi_endproc

	.p2align	2
__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	stp	x28, x27, [sp, #32]
	stp	x26, x25, [sp, #48]
	stp	x24, x23, [sp, #64]
	stp	x22, x21, [sp, #80]
	stp	x20, x19, [sp, #96]
	stp	x29, x30, [sp, #112]
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_remember_state
	mov	x22, x6
	mov	x23, x5
	mov	x21, x4
	mov	x25, x3
	mov	x27, x2
	mov	x24, x1
	mov	x19, x0
	add	x8, sp, #8
	mov	x0, x1
	mov	x1, x6
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core3mmu11mode_params
	ldr	x8, [sp, #8]
	cmp	x8, #1
	b.ne	LBB4_20
	ldr	w8, [sp, #24]
	mvn	w8, w8
	lsl	x9, x21, x8
	asr	x8, x9, x8
	cmp	x8, x21
	b.ne	LBB4_21
	ldr	x26, [sp, #16]
	ldrb	w28, [sp, #28]
	mov	x0, x24
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs4satp
	ubfx	x20, x0, #44, #16
	ldrb	w8, [x27, #2088]
	cmp	w8, #1
	b.ne	LBB4_22
	mov	x8, #0
	mov	x10, #0
	ubfx	x11, x21, #12, #45
	add	x12, x27, #40
	b	LBB4_5
LBB4_4:
	add	x10, x10, #1
	add	x8, x8, #9
	cmp	x10, #5
	b.eq	LBB4_22
LBB4_5:
	lsr	x9, x11, x8
	lsl	x13, x9, x8
	and	x9, x13, #0xf
	add	x9, x12, x9, lsl #7
	ldp	x15, x14, [x9]
	ldrb	w5, [x9, #24]
	ldrb	w16, [x9, #25]
	cmp	x14, x20
	cset	w14, eq
	cmp	x15, x13
	ccmp	x10, x5, #0, eq
	ccmp	w16, w28, #0, eq
	b.ne	LBB4_8
	ldrb	w15, [x9, #26]
	tbz	w15, #0, LBB4_8
	ldrb	w15, [x9, #27]
	orr	w14, w14, w15
	tbnz	w14, #0, LBB4_33
LBB4_8:
	ldp	x15, x14, [x9, #32]
	ldrb	w5, [x9, #56]
	ldrb	w16, [x9, #57]
	cmp	x14, x20
	cset	w14, eq
	cmp	x15, x13
	ccmp	x10, x5, #0, eq
	ccmp	w16, w28, #0, eq
	b.ne	LBB4_11
	ldrb	w15, [x9, #58]
	tbz	w15, #0, LBB4_11
	ldrb	w15, [x9, #59]
	orr	w14, w14, w15
	tbnz	w14, #0, LBB4_31
LBB4_11:
	ldp	x15, x14, [x9, #64]
	ldrb	w5, [x9, #88]
	ldrb	w16, [x9, #89]
	cmp	x14, x20
	cset	w14, eq
	cmp	x15, x13
	ccmp	x10, x5, #0, eq
	ccmp	w16, w28, #0, eq
	b.ne	LBB4_14
	ldrb	w15, [x9, #90]
	tbz	w15, #0, LBB4_14
	ldrb	w15, [x9, #91]
	orr	w14, w14, w15
	tbnz	w14, #0, LBB4_32
LBB4_14:
	ldp	x15, x14, [x9, #96]
	cmp	x14, x20
	cset	w14, eq
	cmp	x15, x13
	b.ne	LBB4_4
	ldrb	w5, [x9, #120]
	cmp	x10, x5
	b.ne	LBB4_4
	ldrb	w13, [x9, #121]
	cmp	w13, w28
	b.ne	LBB4_4
	ldrb	w13, [x9, #122]
	tbz	w13, #0, LBB4_4
	ldrb	w13, [x9, #123]
	orr	w13, w14, w13
	tbz	w13, #0, LBB4_4
	add	x9, x9, #96
	b	LBB4_33
LBB4_20:
	mov	x8, #-1
	stp	x8, x21, [x19]
	b	LBB4_51
LBB4_21:
	and	x8, x23, #0xff
Lloh40:
	adrp	x9, l_switch.table._RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe@PAGE
Lloh41:
	add	x9, x9, l_switch.table._RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe@PAGEOFF
	ldr	x8, [x9, x8, lsl #3]
	stp	x8, x21, [x19]
	b	LBB4_51
LBB4_22:
	ldr	x8, [x27, #24]
	add	x8, x8, #1
	str	x27, [sp]
	str	x8, [x27, #24]
	mov	x0, x25
	bl	__RNvXs0_NtCs5joLtdXDRmI_12wasm_vm_core4mmioNtB5_9SystemBusNtNtB7_3bus3Bus14prof_timer_now
	cmp	x0, #1
	b.ne	LBB4_29
	mov	x27, x1
	add	x0, sp, #8
	mov	x1, x24
	mov	x2, x25
	mov	x3, x21
	mov	x4, x23
	mov	x5, x22
	mov	x6, x26
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu15walk_leaf_innerNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	mov	x0, x25
	bl	__RNvXs0_NtCs5joLtdXDRmI_12wasm_vm_core4mmioNtB5_9SystemBusNtNtB7_3bus3Bus14prof_timer_now
	subs	x8, x1, x27
	csel	x8, xzr, x8, lo
	tst	w0, #0x1
	csel	x1, x8, xzr, ne
	mov	x0, x25
	bl	__RNvXs0_NtCs5joLtdXDRmI_12wasm_vm_core4mmioNtB5_9SystemBusNtNtB7_3bus3Bus14prof_note_walk
	ldp	x8, x25, [sp, #8]
	ldr	x26, [sp, #24]
	cmp	x8, #1
	ldr	x27, [sp]
	b.eq	LBB4_30
LBB4_24:
	add	x8, sp, #8
	mov	x0, x24
	mov	x1, x21
	mov	x2, x23
	mov	x3, x22
	mov	x4, x25
	mov	x5, x26
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core3mmu11finish_leaf
	ldp	x9, x8, [sp, #8]
	cmn	x9, #1
	b.ne	LBB4_50
	ldrb	w9, [x27, #2088]
	cmp	w9, #1
	b.ne	LBB4_49
	and	w9, w26, #0xff
	ands	x10, x25, #0x20
	cset	w15, ne
	lsr	x11, x21, #12
	add	w12, w26, w26, lsl #3
	lsr	x11, x11, x12
	lsl	x12, x11, x12
	and	x11, x12, #0x1fffffffffff
	and	x13, x12, #0xf
	add	x12, x27, x13, lsl #7
	ldr	x16, [x12, #40]!
	ldrb	w14, [x12, #26]
	ldr	x17, [x12, #8]
	ldrb	w0, [x12, #24]
	ldrb	w1, [x12, #25]
	cmp	x17, x20
	ccmp	x16, x11, #0, eq
	ccmp	w0, w9, #0, eq
	ccmp	w1, w28, #0, eq
	ccmp	w14, #0, #4, eq
	b.eq	LBB4_34
	ldrb	w16, [x12, #27]
	eor	w15, w15, w16
	tbnz	w15, #0, LBB4_34
	mov	x1, x12
	b	LBB4_48
LBB4_29:
	add	x0, sp, #8
	mov	x1, x24
	mov	x2, x25
	mov	x3, x21
	mov	x4, x23
	mov	x5, x22
	mov	x6, x26
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu15walk_leaf_innerNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x25, [sp, #8]
	ldr	x26, [sp, #24]
	cmp	x8, #1
	ldr	x27, [sp]
	b.ne	LBB4_24
LBB4_30:
	stp	x25, x26, [x19]
	b	LBB4_51
LBB4_31:
	add	x9, x9, #32
	b	LBB4_33
LBB4_32:
	add	x9, x9, #64
LBB4_33:
	ldr	x4, [x9, #16]
	ldr	x8, [x27, #16]
	add	x8, x8, #1
	str	x8, [x27, #16]
	mov	x8, x19
	mov	x0, x24
	mov	x1, x21
	mov	x2, x23
	mov	x3, x22
	.cfi_def_cfa wsp, 128
	ldp	x29, x30, [sp, #112]
	ldp	x20, x19, [sp, #96]
	ldp	x22, x21, [sp, #80]
	ldp	x24, x23, [sp, #64]
	ldp	x26, x25, [sp, #48]
	ldp	x28, x27, [sp, #32]
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	b	__RNvNtCs5joLtdXDRmI_12wasm_vm_core3mmu11finish_leaf
LBB4_34:
	.cfi_restore_state
	.cfi_remember_state
	cmp	x10, #0
	cset	w17, ne
	mov	x15, x12
	ldr	x0, [x15, #32]!
	ldrb	w16, [x15, #26]
	ldr	x1, [x15, #8]
	ldrb	w2, [x15, #24]
	ldrb	w3, [x15, #25]
	cmp	x1, x20
	ccmp	x0, x11, #0, eq
	ccmp	w2, w9, #0, eq
	ccmp	w3, w28, #0, eq
	ccmp	w16, #0, #4, eq
	b.eq	LBB4_36
	ldrb	w0, [x15, #27]
	eor	w17, w17, w0
	mov	x1, x15
	tbz	w17, #0, LBB4_48
LBB4_36:
	cmp	x10, #0
	cset	w1, ne
	mov	x17, x12
	ldr	x2, [x17, #64]!
	ldrb	w0, [x17, #26]
	ldr	x3, [x17, #8]
	cmp	x3, x20
	b.ne	LBB4_42
	cmp	x2, x11
	b.ne	LBB4_42
	ldrb	w2, [x17, #24]
	cmp	w2, w9
	b.ne	LBB4_42
	ldrb	w2, [x17, #25]
	cmp	w2, w28
	b.ne	LBB4_42
	cbz	w0, LBB4_42
	ldrb	w2, [x17, #27]
	eor	w2, w1, w2
	mov	x1, x17
	tbz	w2, #0, LBB4_48
LBB4_42:
	cmp	x10, #0
	cset	w3, ne
	mov	x1, x12
	ldr	x4, [x1, #96]!
	ldrb	w2, [x1, #26]
	ldr	x5, [x1, #8]
	cmp	x5, x20
	b.ne	LBB4_52
	cmp	x4, x11
	b.ne	LBB4_52
	ldrb	w4, [x1, #24]
	cmp	w4, w9
	b.ne	LBB4_52
	ldrb	w4, [x1, #25]
	cmp	w4, w28
	b.ne	LBB4_52
	cbz	w2, LBB4_52
	ldrb	w4, [x1, #27]
	eor	w3, w3, w4
	tbnz	w3, #0, LBB4_52
LBB4_48:
	lsr	x10, x10, #5
	stp	x11, x20, [x1]
	str	x25, [x1, #16]
	strb	w9, [x1, #24]
	strb	w28, [x1, #25]
	mov	w9, #1
	strb	w9, [x1, #26]
	strb	w10, [x1, #27]
LBB4_49:
	mov	x9, #-1
LBB4_50:
	stp	x9, x8, [x19]
LBB4_51:
	.cfi_def_cfa wsp, 128
	ldp	x29, x30, [sp, #112]
	ldp	x20, x19, [sp, #96]
	ldp	x22, x21, [sp, #80]
	ldp	x24, x23, [sp, #64]
	ldp	x26, x25, [sp, #48]
	ldp	x28, x27, [sp, #32]
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	ret
LBB4_52:
	.cfi_restore_state
	ands	w16, w16, w14
	b.eq	LBB4_56
	and	w2, w2, w0
	cbz	w2, LBB4_56
	ldrb	w0, [x27, x13]
	cmp	w0, #3
	b.hi	LBB4_57
	add	x12, x12, x0, lsl #5
	stp	x11, x20, [x12]
	lsr	x10, x10, #5
	str	x25, [x12, #16]
	strb	w9, [x12, #24]
	strb	w28, [x12, #25]
	mov	w9, #1
	strb	w9, [x12, #26]
	add	w9, w0, #1
	and	w9, w9, #0x3
	strb	w10, [x12, #27]
	strb	w9, [x27, x13]
	b	LBB4_49
LBB4_56:
	cmp	w14, #0
	mov	w13, #32
	csel	x13, x13, xzr, ne
	csel	x14, x15, x12, ne
	cmp	w0, #0
	mov	w15, #64
	mov	w0, #96
	csel	x15, x0, x15, ne
	csel	x17, x1, x17, ne
	cmp	w16, #0
	csel	x13, x13, x15, eq
	str	x11, [x12, x13]
	csel	x11, x14, x17, eq
	stp	x20, x25, [x11, #8]
	lsr	x10, x10, #5
	strb	w9, [x11, #24]
	strb	w28, [x11, #25]
	mov	w9, #1
	strb	w9, [x11, #26]
	strb	w10, [x11, #27]
	b	LBB4_49
LBB4_57:
Lloh42:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.42@PAGE
Lloh43:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.42@PAGEOFF
	mov	w1, #4
	bl	__RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpAdd	Lloh42, Lloh43
	.cfi_endproc

	.p2align	2
__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart10camoload32NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x24, x23, [sp, #16]
	stp	x22, x21, [sp, #32]
	stp	x20, x19, [sp, #48]
	stp	x29, x30, [sp, #64]
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_remember_state
	mov	x19, x0
	tst	x4, #0x3
	b.eq	LBB5_2
	mov	w8, #6
	b	LBB5_17
LBB5_2:
	ldr	x8, [x1, #616]
	tbnz	w8, #17, LBB5_4
	ldrb	w21, [x1, #709]
	b	LBB5_5
LBB5_4:
	ubfx	x8, x8, #11, #2
	cmp	x8, #1
	cset	w9, eq
	cmp	x8, #3
	mov	w8, #3
	csel	w21, w8, w9, eq
LBB5_5:
	mov	x0, sp
	mov	x22, x1
	mov	x24, x3
	mov	x23, x4
	mov	w5, #2
	mov	x6, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x20, [sp]
	cmn	x8, #1
	b.eq	LBB5_7
	mov	x4, x20
	b	LBB5_17
LBB5_7:
	mov	x0, x22
	mov	x1, x20
	mov	w2, #4
	mov	w3, #0
	mov	x4, x21
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6pmp_ok
	cbz	w0, LBB5_16
	mov	x0, x22
	mov	x1, x20
	mov	w2, #4
	mov	w3, #1
	mov	x4, x21
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6pmp_ok
	tbz	w0, #0, LBB5_16
	mov	x9, x24
	ldr	x8, [x24, #24]
	subs	x10, x20, x8
	mov	x8, x23
	b.lo	LBB5_12
	cmn	x10, #5
	b.hi	LBB5_12
	add	x11, x10, #4
	ldr	x12, [x9, #16]
	cmp	x11, x12
	b.ls	LBB5_20
LBB5_12:
	mov	w10, #1
	lsr	x11, x10, #8
	lsr	x21, x10, #32
	tbz	w10, #0, LBB5_14
LBB5_13:
	tbz	w11, #0, LBB5_23
LBB5_14:
	tbz	w10, #0, LBB5_19
	tst	w11, #0x1
	mov	w9, #6
	cinc	x9, x9, eq
	stp	x9, x8, [x19]
	b	LBB5_18
LBB5_16:
	mov	w8, #7
	mov	x4, x23
LBB5_17:
	stp	x8, x4, [x19]
LBB5_18:
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x24, x23, [sp, #16]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	ret
LBB5_19:
	.cfi_restore_state
	str	w21, [x19, #8]
	mov	x8, #-1
	str	x8, [x19]
	b	LBB5_18
LBB5_20:
	tst	x20, #0x3
	b.eq	LBB5_22
	mov	w10, #257
	lsr	x11, x10, #8
	lsr	x21, x10, #32
	tbnz	w10, #0, LBB5_13
	b	LBB5_14
LBB5_22:
	ldr	x11, [x9, #8]
	ldr	w10, [x11, x10]
	lsl	x10, x10, #32
	lsr	x11, x10, #8
	lsr	x21, x10, #32
	tbnz	w10, #0, LBB5_13
	b	LBB5_14
LBB5_23:
	ldp	x0, x1, [x9, #40]
	ldr	x8, [x9, #80]
	cbnz	x8, LBB5_25
	mov	x2, #0
	b	LBB5_26
LBB5_25:
	ldr	x3, [x24, #88]
	ldr	x9, [x3, #16]
	sub	x9, x9, #1
	and	x9, x9, #0xfffffffffffffff0
	add	x8, x8, x9
	add	x2, x8, #16
LBB5_26:
	mov	x8, sp
	add	x4, x24, #96
	mov	x5, x20
	mov	w6, #2
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio11load_device
	ldrb	w10, [sp]
	ldrb	w8, [sp, #1]
	ldr	x9, [sp, #8]
	cmp	w10, #0
	csel	w11, w8, wzr, ne
	csel	x21, x21, x9, ne
	mov	x8, x23
	b	LBB5_14
	.cfi_endproc

	.p2align	2
__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart10camoload64NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x24, x23, [sp, #16]
	stp	x22, x21, [sp, #32]
	stp	x20, x19, [sp, #48]
	stp	x29, x30, [sp, #64]
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_remember_state
	mov	x19, x0
	tst	x4, #0x7
	b.eq	LBB6_2
	mov	w8, #6
	b	LBB6_16
LBB6_2:
	ldr	x8, [x1, #616]
	tbnz	w8, #17, LBB6_4
	ldrb	w21, [x1, #709]
	b	LBB6_5
LBB6_4:
	ubfx	x8, x8, #11, #2
	cmp	x8, #1
	cset	w9, eq
	cmp	x8, #3
	mov	w8, #3
	csel	w21, w8, w9, eq
LBB6_5:
	mov	x0, sp
	mov	x22, x1
	mov	x24, x3
	mov	x23, x4
	mov	w5, #2
	mov	x6, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x20, [sp]
	cmn	x8, #1
	b.eq	LBB6_7
	mov	x4, x20
	b	LBB6_16
LBB6_7:
	mov	x0, x22
	mov	x1, x20
	mov	w2, #8
	mov	w3, #0
	mov	x4, x21
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6pmp_ok
	cbz	w0, LBB6_15
	mov	x0, x22
	mov	x1, x20
	mov	w2, #8
	mov	w3, #1
	mov	x4, x21
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6pmp_ok
	tbz	w0, #0, LBB6_15
	mov	x9, x24
	ldr	x8, [x24, #24]
	subs	x10, x20, x8
	b.lo	LBB6_21
	cmn	x10, #9
	b.hi	LBB6_21
	add	x11, x10, #8
	ldr	x12, [x9, #16]
	cmp	x11, x12
	b.hi	LBB6_21
	tst	x20, #0x7
	b.eq	LBB6_18
	mov	x8, x23
	mov	w9, #1
	strb	w9, [sp, #1]
LBB6_14:
	ldrb	w9, [sp, #1]
	cmp	w9, #0
	mov	w9, #6
	cinc	x9, x9, eq
	b	LBB6_20
LBB6_15:
	mov	w8, #7
	mov	x4, x23
LBB6_16:
	stp	x8, x4, [x19]
LBB6_17:
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x24, x23, [sp, #16]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	ret
LBB6_18:
	.cfi_restore_state
	ldr	x8, [x9, #8]
	ldr	x8, [x8, x10]
	str	x8, [sp, #8]
LBB6_19:
	mov	x9, #-1
	ldr	x8, [sp, #8]
LBB6_20:
	stp	x9, x8, [x19]
	b	LBB6_17
LBB6_21:
	mov	w8, #1
	strh	w8, [sp]
	ldp	x0, x1, [x9, #40]
	ldr	x8, [x9, #80]
	cbnz	x8, LBB6_23
	mov	x2, #0
	b	LBB6_24
LBB6_23:
	ldr	x3, [x9, #88]
	ldr	x10, [x3, #16]
	sub	x10, x10, #1
	and	x10, x10, #0xfffffffffffffff0
	add	x8, x8, x10
	add	x2, x8, #16
LBB6_24:
	mov	x8, sp
	add	x4, x9, #96
	mov	x5, x20
	mov	w6, #3
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio11load_device
	ldrb	w8, [sp]
	cmp	w8, #1
	mov	x8, x23
	b.eq	LBB6_14
	b	LBB6_19
	.cfi_endproc

	.p2align	2
__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart15misaligned_loadNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #112
	.cfi_def_cfa_offset 112
	stp	x28, x27, [sp, #16]
	stp	x26, x25, [sp, #32]
	stp	x24, x23, [sp, #48]
	stp	x22, x21, [sp, #64]
	stp	x20, x19, [sp, #80]
	stp	x29, x30, [sp, #96]
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_remember_state
	mov	x23, x5
	mov	x20, x4
	mov	x21, x3
	mov	x26, x2
	mov	x24, x1
	mov	x19, x0
	ldr	x8, [x1, #616]
	tbnz	w8, #17, LBB7_2
	ldrb	w25, [x24, #709]
	b	LBB7_3
LBB7_2:
	ubfx	x8, x8, #11, #2
	cmp	x8, #1
	cset	w9, eq
	cmp	x8, #3
	mov	w8, #3
	csel	w25, w8, w9, eq
LBB7_3:
	mov	x0, sp
	mov	x1, x24
	mov	x2, x26
	mov	x3, x21
	mov	x4, x20
	mov	w5, #1
	mov	x6, x25
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	x8, [sp]
	cmn	x8, #1
	b.eq	LBB7_5
	ldr	x9, [sp, #8]
	b	LBB7_6
LBB7_5:
	sub	x27, x23, #1
	ldr	x22, [sp, #8]
	mov	x0, sp
	add	x4, x27, x20
	mov	x1, x24
	mov	x2, x26
	mov	x3, x21
	mov	w5, #1
	mov	x6, x25
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x9, [sp]
	cmn	x8, #1
	b.eq	LBB7_8
LBB7_6:
	stp	x8, x9, [x19]
LBB7_7:
	.cfi_def_cfa wsp, 112
	ldp	x29, x30, [sp, #96]
	ldp	x20, x19, [sp, #80]
	ldp	x22, x21, [sp, #64]
	ldp	x24, x23, [sp, #48]
	ldp	x26, x25, [sp, #32]
	ldp	x28, x27, [sp, #16]
	add	sp, sp, #112
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	ret
LBB7_8:
	.cfi_restore_state
	add	x8, x22, x27
	cmp	x9, x8
	b.ne	LBB7_24
	adds	x8, x22, x23
	b.hs	LBB7_24
	ldr	x9, [x21, #24]
	cmp	x22, x9
	b.lo	LBB7_24
	ldr	x10, [x21, #16]
	add	x9, x10, x9
	cmp	x8, x9
	b.hi	LBB7_24
	mov	x0, x24
	mov	x1, x22
	mov	x2, x23
	mov	w3, #0
	mov	x4, x25
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6pmp_ok
	cbz	w0, LBB7_24
	mov	x25, #0
	mov	x24, #0
	lsl	x23, x23, #3
	b	LBB7_15
LBB7_14:
	ldr	x9, [x21, #8]
	sub	x8, x9, x8
	ldrb	w8, [x8, x22]
	lsl	x8, x8, x25
	orr	x24, x8, x24
	add	x25, x25, #8
	add	x22, x22, #1
	cmp	x23, x25
	b.eq	LBB7_23
LBB7_15:
	ldr	x8, [x21, #24]
	subs	x9, x22, x8
	b.lo	LBB7_18
	cmn	x9, #1
	b.hs	LBB7_18
	ldr	x10, [x21, #16]
	cmp	x9, x10
	b.lo	LBB7_14
LBB7_18:
	ldr	x8, [x21, #80]
	cbnz	x8, LBB7_20
	mov	x2, #0
	b	LBB7_21
LBB7_20:
	ldr	x3, [x21, #88]
	ldr	x9, [x3, #16]
	sub	x9, x9, #1
	and	x9, x9, #0xfffffffffffffff0
	add	x8, x8, x9
	add	x2, x8, #16
LBB7_21:
	ldp	x0, x1, [x21, #40]
	mov	x8, sp
	add	x4, x21, #96
	mov	x5, x22
	mov	w6, #0
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio11load_device
	ldrb	w8, [sp]
	tbnz	w8, #0, LBB7_26
	ldrb	w8, [sp, #8]
	lsl	x8, x8, x25
	orr	x24, x8, x24
	add	x25, x25, #8
	add	x22, x22, #1
	cmp	x23, x25
	b.ne	LBB7_15
LBB7_23:
	mov	x8, #-1
	stp	x8, x24, [x19]
	b	LBB7_7
LBB7_24:
	mov	w8, #5
LBB7_25:
	stp	x8, x20, [x19]
	b	LBB7_7
LBB7_26:
	ldrb	w8, [sp, #1]
	cmp	w8, #0
	mov	w8, #4
	cinc	x8, x8, eq
	b	LBB7_25
	.cfi_endproc

	.p2align	2
__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart16misaligned_storeNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #112
	.cfi_def_cfa_offset 112
	stp	x28, x27, [sp, #16]
	stp	x26, x25, [sp, #32]
	stp	x24, x23, [sp, #48]
	stp	x22, x21, [sp, #64]
	stp	x20, x19, [sp, #80]
	stp	x29, x30, [sp, #96]
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_remember_state
	mov	x21, x6
	mov	x24, x5
	mov	x20, x4
	mov	x22, x3
	mov	x27, x2
	mov	x25, x1
	mov	x19, x0
	ldr	x8, [x1, #616]
	tbnz	w8, #17, LBB8_2
	ldrb	w26, [x25, #709]
	b	LBB8_3
LBB8_2:
	ubfx	x8, x8, #11, #2
	cmp	x8, #1
	cset	w9, eq
	cmp	x8, #3
	mov	w8, #3
	csel	w26, w8, w9, eq
LBB8_3:
	mov	x0, sp
	mov	x1, x25
	mov	x2, x27
	mov	x3, x22
	mov	x4, x20
	mov	w5, #2
	mov	x6, x26
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldr	x8, [sp]
	cmn	x8, #1
	b.eq	LBB8_5
	ldr	x9, [sp, #8]
	b	LBB8_6
LBB8_5:
	sub	x28, x24, #1
	ldr	x23, [sp, #8]
	mov	x0, sp
	add	x4, x28, x20
	mov	x1, x25
	mov	x2, x27
	mov	x3, x22
	mov	w5, #2
	mov	x6, x26
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x9, [sp]
	cmn	x8, #1
	b.eq	LBB8_8
LBB8_6:
	stp	x8, x9, [x19]
LBB8_7:
	.cfi_def_cfa wsp, 112
	ldp	x29, x30, [sp, #96]
	ldp	x20, x19, [sp, #80]
	ldp	x22, x21, [sp, #64]
	ldp	x24, x23, [sp, #48]
	ldp	x26, x25, [sp, #32]
	ldp	x28, x27, [sp, #16]
	add	sp, sp, #112
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	ret
LBB8_8:
	.cfi_restore_state
	add	x8, x23, x28
	cmp	x9, x8
	b.ne	LBB8_14
	adds	x8, x23, x24
	b.hs	LBB8_14
	ldr	x9, [x22, #24]
	cmp	x23, x9
	b.lo	LBB8_14
	ldr	x10, [x22, #16]
	add	x9, x10, x9
	cmp	x8, x9
	b.hi	LBB8_14
	mov	x0, x25
	mov	x1, x23
	mov	x2, x24
	mov	w3, #1
	mov	x4, x26
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6pmp_ok
	cbz	w0, LBB8_14
	mov	x25, #0
	lsl	x26, x24, #3
	mov	x24, x23
	b	LBB8_18
LBB8_14:
	mov	w8, #7
LBB8_15:
	stp	x8, x20, [x19]
	b	LBB8_7
LBB8_16:
	lsr	x8, x24, #12
	ldr	x9, [x22, #64]
	str	x8, [x9, x27, lsl #3]
	add	x8, x27, #1
	str	x8, [x22, #72]
LBB8_17:
	add	x25, x25, #8
	add	x24, x24, #1
	cmp	x26, x25
	b.eq	LBB8_29
LBB8_18:
	lsr	x8, x21, x25
	ldr	x9, [x22, #24]
	subs	x10, x24, x9
	b.lo	LBB8_24
	cmn	x10, #1
	b.hs	LBB8_24
	ldr	x11, [x22, #16]
	cmp	x10, x11
	b.hs	LBB8_24
	ldr	x10, [x22, #8]
	sub	x9, x10, x9
	strb	w8, [x9, x24]
	ldrb	w8, [x22, #192]
	cmp	w8, #1
	b.ne	LBB8_17
	ldr	x27, [x22, #72]
	ldr	x8, [x22, #56]
	cmp	x27, x8
	b.ne	LBB8_16
	add	x0, x22, #56
	bl	__RNvMs4_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVecyE8grow_oneCs5joLtdXDRmI_12wasm_vm_core
	b	LBB8_16
LBB8_24:
	ldr	x9, [x22, #80]
	cbnz	x9, LBB8_26
	mov	x2, #0
	b	LBB8_27
LBB8_26:
	ldr	x3, [x22, #88]
	ldr	x10, [x3, #16]
	sub	x10, x10, #1
	and	x10, x10, #0xfffffffffffffff0
	add	x9, x9, x10
	add	x2, x9, #16
LBB8_27:
	ldp	x0, x1, [x22, #40]
	add	x4, x22, #96
	and	x7, x8, #0xff
	mov	x5, x24
	mov	w6, #0
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio12store_device
	and	w8, w0, #0xff
	cmp	w8, #2
	b.eq	LBB8_17
	mov	w9, #7
	mov	w10, #6
	cmp	w8, #0
	csel	x8, x9, x10, eq
	b	LBB8_15
LBB8_29:
	mov	x8, #-1
	stp	x8, x23, [x19]
	b	LBB8_7
	.cfi_endproc

	.p2align	2
__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart17cstore8_with_physNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #96
	.cfi_def_cfa_offset 96
	stp	x26, x25, [sp, #16]
	stp	x24, x23, [sp, #32]
	stp	x22, x21, [sp, #48]
	stp	x20, x19, [sp, #64]
	stp	x29, x30, [sp, #80]
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x22, x5
	mov	x20, x4
	mov	x21, x3
	mov	x24, x1
	mov	x19, x0
	ldrb	w8, [x1, #708]
	cmp	w8, #1
	b.ne	LBB9_12
	ldr	x8, [x24, #680]
	and	x9, x8, #0xfffffffffffffffe
	and	x9, x9, #0xf000000000000003
	mov	x10, #2
	movk	x10, #8192, lsl #48
	cmp	x9, x10
	b.ne	LBB9_12
	ldrb	w9, [x24, #709]
	cmp	w9, #3
	b.eq	LBB9_5
	cmp	w9, #1
	b.ne	LBB9_7
	and	x9, x8, #0x10
	b	LBB9_8
LBB9_5:
	tbz	w8, #6, LBB9_12
	ldr	x9, [x24, #696]
	and	x9, x9, #0x8
	b	LBB9_8
LBB9_7:
	and	x9, x8, #0x8
LBB9_8:
	mov	w10, #63360
	tst	x8, x10
	b.ne	LBB9_12
	cbz	x9, LBB9_12
	ldr	x8, [x24, #688]
	cmp	x8, x20
	b.ne	LBB9_12
	mov	w26, #1
	mov	w8, #3
	b	LBB9_37
LBB9_12:
	ldr	x8, [x24, #616]
	tbnz	w8, #17, LBB9_14
	ldrb	w25, [x24, #709]
	b	LBB9_15
LBB9_14:
	ubfx	x8, x8, #11, #2
	cmp	x8, #1
	cset	w9, eq
	cmp	x8, #3
	mov	w8, #3
	csel	w25, w8, w9, eq
LBB9_15:
	mov	x0, sp
	mov	x1, x24
	mov	x3, x21
	mov	x4, x20
	mov	w5, #2
	mov	x6, x25
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x23, [sp]
	mov	w26, #1
	cmn	x8, #1
	b.eq	LBB9_17
	mov	x20, x23
	b	LBB9_37
LBB9_17:
	mov	x0, x24
	mov	x1, x23
	mov	w2, #1
	mov	w3, #1
	mov	x4, x25
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6pmp_ok
	tbz	w0, #0, LBB9_36
	ldr	x8, [x21, #24]
	subs	x8, x23, x8
	b.lo	LBB9_29
	cmn	x8, #1
	b.eq	LBB9_29
	ldr	x9, [x21, #16]
	cmp	x8, x9
	b.hs	LBB9_29
	ldr	x9, [x21, #8]
	strb	w22, [x9, x8]
	ldrb	w8, [x21, #192]
	cmp	w8, #1
	b.ne	LBB9_25
	lsr	x20, x23, #12
	mov	x0, x21
	ldr	x8, [x0, #56]!
	ldr	x22, [x0, #16]
	cmp	x22, x8
	b.ne	LBB9_24
	bl	__RNvMs4_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVecyE8grow_oneCs5joLtdXDRmI_12wasm_vm_core
LBB9_24:
	ldr	x8, [x21, #64]
	str	x20, [x8, x22, lsl #3]
	add	x8, x22, #1
	str	x8, [x21, #72]
LBB9_25:
	mov	x8, #0
	cmn	x23, #1
	b.eq	LBB9_28
	ldr	x9, [x21, #24]
	cmp	x23, x9
	b.lo	LBB9_28
	mov	x26, #0
	ldr	x8, [x21, #16]
	add	x8, x8, x9
	cmp	x23, x8
	cset	w8, lo
	mov	x20, x23
	b	LBB9_37
LBB9_28:
	mov	x20, x23
	mov	x26, x8
	b	LBB9_37
LBB9_29:
	ldp	x0, x1, [x21, #40]
	ldr	x8, [x21, #80]
	cbnz	x8, LBB9_31
	mov	x2, #0
	b	LBB9_32
LBB9_31:
	ldr	x3, [x21, #88]
	ldr	x9, [x3, #16]
	sub	x9, x9, #1
	and	x9, x9, #0xfffffffffffffff0
	add	x8, x8, x9
	add	x2, x8, #16
LBB9_32:
	add	x4, x21, #96
	and	x7, x22, #0xff
	mov	x5, x23
	mov	w6, #0
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio12store_device
	ands	w8, w0, #0xff
	b.eq	LBB9_35
	cmp	w8, #2
	b.eq	LBB9_25
	mov	w26, #1
	mov	w8, #6
	b	LBB9_37
LBB9_35:
	mov	w26, #1
LBB9_36:
	mov	w8, #7
LBB9_37:
	stp	x8, x20, [x19, #8]
	str	x26, [x19]
	.cfi_def_cfa wsp, 96
	ldp	x29, x30, [sp, #80]
	ldp	x20, x19, [sp, #64]
	ldp	x22, x21, [sp, #48]
	ldp	x24, x23, [sp, #32]
	ldp	x26, x25, [sp, #16]
	add	sp, sp, #96
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	ret
	.cfi_endproc

	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
lCPI10_0:
	.quad	1
	.quad	3
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart18cstore16_with_physNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #96
	.cfi_def_cfa_offset 96
	stp	x26, x25, [sp, #16]
	stp	x24, x23, [sp, #32]
	stp	x22, x21, [sp, #48]
	stp	x20, x19, [sp, #64]
	stp	x29, x30, [sp, #80]
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_remember_state
	mov	x19, x0
	ldrb	w8, [x1, #708]
	cmp	w8, #1
	b.ne	LBB10_12
	ldr	x8, [x1, #680]
	and	x9, x8, #0xfffffffffffffffe
	and	x9, x9, #0xf000000000000003
	mov	x10, #2
	movk	x10, #8192, lsl #48
	cmp	x9, x10
	b.ne	LBB10_12
	ldrb	w9, [x1, #709]
	cmp	w9, #3
	b.eq	LBB10_5
	cmp	w9, #1
	b.ne	LBB10_7
	and	x9, x8, #0x10
	b	LBB10_8
LBB10_5:
	tbz	w8, #6, LBB10_12
	ldr	x9, [x1, #696]
	and	x9, x9, #0x8
	b	LBB10_8
LBB10_7:
	and	x9, x8, #0x8
LBB10_8:
	mov	w10, #63360
	tst	x8, x10
	b.ne	LBB10_12
	cbz	x9, LBB10_12
	ldr	x8, [x1, #688]
	cmp	x8, x4
	b.ne	LBB10_12
	str	x4, [x19, #16]
Lloh44:
	adrp	x8, lCPI10_0@PAGE
Lloh45:
	ldr	q0, [x8, lCPI10_0@PAGEOFF]
	str	q0, [x19]
	b	LBB10_34
LBB10_12:
	tbnz	w4, #0, LBB10_15
	ldr	x8, [x1, #616]
	tbnz	w8, #17, LBB10_16
	mov	x25, x5
	ldrb	w21, [x1, #709]
	b	LBB10_17
LBB10_15:
	mov	x0, sp
	and	x6, x5, #0xffff
	mov	w5, #2
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart16misaligned_storeNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x9, [sp]
	cmn	x8, #1
	cset	w10, ne
	csinc	x8, x8, xzr, ne
	stp	x8, x9, [x19, #8]
	str	x10, [x19]
	b	LBB10_34
LBB10_16:
	mov	x25, x5
	ubfx	x8, x8, #11, #2
	cmp	x8, #1
	cset	w9, eq
	cmp	x8, #3
	mov	w8, #3
	csel	w21, w8, w9, eq
LBB10_17:
	mov	x0, sp
	mov	x22, x1
	mov	x23, x3
	mov	x24, x4
	mov	w5, #2
	mov	x6, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x20, [sp]
	cmn	x8, #1
	b.ne	LBB10_32
	mov	x0, x22
	mov	x1, x20
	mov	w2, #2
	mov	w3, #1
	mov	x4, x21
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6pmp_ok
	tbz	w0, #0, LBB10_31
	mov	x8, x23
	ldr	x9, [x23, #24]
	subs	x10, x20, x9
	b.lo	LBB10_35
	cmn	x10, #3
	b.hi	LBB10_35
	add	x11, x10, #2
	ldr	x12, [x8, #16]
	cmp	x11, x12
	b.hi	LBB10_35
	tbnz	w20, #0, LBB10_40
	ldr	x9, [x8, #8]
	strh	w25, [x9, x10]
	ldrb	w9, [x8, #192]
	cmp	w9, #1
	b.ne	LBB10_27
	lsr	x21, x20, #12
	mov	x0, x8
	ldr	x9, [x0, #56]!
	ldr	x22, [x0, #16]
	cmp	x22, x9
	b.ne	LBB10_26
	bl	__RNvMs4_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVecyE8grow_oneCs5joLtdXDRmI_12wasm_vm_core
	mov	x8, x23
LBB10_26:
	ldr	x9, [x8, #64]
	str	x21, [x9, x22, lsl #3]
	add	x9, x22, #1
	str	x9, [x8, #72]
LBB10_27:
	mov	x9, #0
	cmn	x20, #3
	b.hi	LBB10_30
	ldr	x10, [x8, #24]
	cmp	x20, x10
	b.lo	LBB10_30
	add	x9, x20, #2
	ldr	x8, [x8, #16]
	add	x8, x8, x10
	cmp	x9, x8
	cset	w9, ls
LBB10_30:
	stp	x9, x20, [x19, #8]
	str	xzr, [x19]
	b	LBB10_34
LBB10_31:
	mov	w8, #7
	mov	x20, x24
LBB10_32:
	str	x20, [x19, #16]
LBB10_33:
	mov	w9, #1
	stp	x9, x8, [x19]
LBB10_34:
	.cfi_def_cfa wsp, 96
	ldp	x29, x30, [sp, #80]
	ldp	x20, x19, [sp, #64]
	ldp	x22, x21, [sp, #48]
	ldp	x24, x23, [sp, #32]
	ldp	x26, x25, [sp, #16]
	add	sp, sp, #96
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	ret
LBB10_35:
	.cfi_restore_state
	ldp	x0, x1, [x8, #40]
	ldr	x9, [x8, #80]
	cbnz	x9, LBB10_37
	mov	x2, #0
	b	LBB10_38
LBB10_37:
	ldr	x3, [x8, #88]
	ldr	x10, [x3, #16]
	sub	x10, x10, #1
	and	x10, x10, #0xfffffffffffffff0
	add	x9, x9, x10
	add	x2, x9, #16
LBB10_38:
	add	x4, x8, #96
	and	x7, x25, #0xffff
	mov	x5, x20
	mov	w6, #1
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio12store_device
	ands	w8, w0, #0xff
	b.eq	LBB10_41
	cmp	w8, #2
	mov	x8, x23
	b.eq	LBB10_27
LBB10_40:
	mov	w8, #6
	str	x24, [x19, #16]
	b	LBB10_33
LBB10_41:
	mov	w8, #7
	str	x24, [x19, #16]
	b	LBB10_33
	.loh AdrpLdr	Lloh44, Lloh45
	.cfi_endproc

	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
lCPI11_0:
	.quad	1
	.quad	3
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart18cstore32_with_physNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #96
	.cfi_def_cfa_offset 96
	stp	x26, x25, [sp, #16]
	stp	x24, x23, [sp, #32]
	stp	x22, x21, [sp, #48]
	stp	x20, x19, [sp, #64]
	stp	x29, x30, [sp, #80]
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_remember_state
	mov	x19, x0
	ldrb	w8, [x1, #708]
	cmp	w8, #1
	b.ne	LBB11_12
	ldr	x8, [x1, #680]
	and	x9, x8, #0xfffffffffffffffe
	and	x9, x9, #0xf000000000000003
	mov	x10, #2
	movk	x10, #8192, lsl #48
	cmp	x9, x10
	b.ne	LBB11_12
	ldrb	w9, [x1, #709]
	cmp	w9, #3
	b.eq	LBB11_5
	cmp	w9, #1
	b.ne	LBB11_7
	and	x9, x8, #0x10
	b	LBB11_8
LBB11_5:
	tbz	w8, #6, LBB11_12
	ldr	x9, [x1, #696]
	and	x9, x9, #0x8
	b	LBB11_8
LBB11_7:
	and	x9, x8, #0x8
LBB11_8:
	mov	w10, #63360
	tst	x8, x10
	b.ne	LBB11_12
	cbz	x9, LBB11_12
	ldr	x8, [x1, #688]
	cmp	x8, x4
	b.ne	LBB11_12
	str	x4, [x19, #16]
Lloh46:
	adrp	x8, lCPI11_0@PAGE
Lloh47:
	ldr	q0, [x8, lCPI11_0@PAGEOFF]
	str	q0, [x19]
	b	LBB11_27
LBB11_12:
	tst	x4, #0x3
	b.eq	LBB11_14
	mov	w6, w5
	mov	x0, sp
	mov	w5, #4
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart16misaligned_storeNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x9, [sp]
	cmn	x8, #1
	cset	w10, ne
	csinc	x8, x8, xzr, ne
	stp	x8, x9, [x19, #8]
	str	x10, [x19]
	b	LBB11_27
LBB11_14:
	ldr	x8, [x1, #616]
	tbnz	w8, #17, LBB11_16
	mov	x25, x5
	ldrb	w21, [x1, #709]
	b	LBB11_17
LBB11_16:
	mov	x25, x5
	ubfx	x8, x8, #11, #2
	cmp	x8, #1
	cset	w9, eq
	cmp	x8, #3
	mov	w8, #3
	csel	w21, w8, w9, eq
LBB11_17:
	mov	x0, sp
	mov	x22, x1
	mov	x23, x3
	mov	x24, x4
	mov	w5, #2
	mov	x6, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x20, [sp]
	cmn	x8, #1
	b.ne	LBB11_25
	mov	x0, x22
	mov	x1, x20
	mov	w2, #4
	mov	w3, #1
	mov	x4, x21
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6pmp_ok
	tbz	w0, #0, LBB11_24
	mov	x8, x23
	ldr	x9, [x23, #24]
	subs	x10, x20, x9
	b.lo	LBB11_36
	cmn	x10, #5
	b.hi	LBB11_36
	add	x11, x10, #4
	ldr	x12, [x8, #16]
	cmp	x11, x12
	b.hi	LBB11_36
	tst	x20, #0x3
	b.eq	LBB11_28
LBB11_23:
	mov	w8, #6
	str	x24, [x19, #16]
	b	LBB11_26
LBB11_24:
	mov	w8, #7
	mov	x20, x24
LBB11_25:
	str	x20, [x19, #16]
LBB11_26:
	mov	w9, #1
	stp	x9, x8, [x19]
LBB11_27:
	.cfi_def_cfa wsp, 96
	ldp	x29, x30, [sp, #80]
	ldp	x20, x19, [sp, #64]
	ldp	x22, x21, [sp, #48]
	ldp	x24, x23, [sp, #32]
	ldp	x26, x25, [sp, #16]
	add	sp, sp, #96
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	ret
LBB11_28:
	.cfi_restore_state
	ldr	x9, [x8, #8]
	str	w25, [x9, x10]
	ldrb	w9, [x8, #192]
	cmp	w9, #1
	b.ne	LBB11_32
	lsr	x21, x20, #12
	mov	x0, x8
	ldr	x9, [x0, #56]!
	ldr	x22, [x0, #16]
	cmp	x22, x9
	b.ne	LBB11_31
	bl	__RNvMs4_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVecyE8grow_oneCs5joLtdXDRmI_12wasm_vm_core
	mov	x8, x23
LBB11_31:
	ldr	x9, [x8, #64]
	str	x21, [x9, x22, lsl #3]
	add	x9, x22, #1
	str	x9, [x8, #72]
LBB11_32:
	mov	x9, #0
	cmn	x20, #5
	b.hi	LBB11_35
	ldr	x10, [x8, #24]
	cmp	x20, x10
	b.lo	LBB11_35
	add	x9, x20, #4
	ldr	x8, [x8, #16]
	add	x8, x8, x10
	cmp	x9, x8
	cset	w9, ls
LBB11_35:
	stp	x9, x20, [x19, #8]
	str	xzr, [x19]
	b	LBB11_27
LBB11_36:
	ldp	x0, x1, [x8, #40]
	ldr	x9, [x8, #80]
	cbnz	x9, LBB11_38
	mov	x2, #0
	b	LBB11_39
LBB11_38:
	ldr	x3, [x8, #88]
	ldr	x10, [x3, #16]
	sub	x10, x10, #1
	and	x10, x10, #0xfffffffffffffff0
	add	x9, x9, x10
	add	x2, x9, #16
LBB11_39:
	mov	w7, w25
	add	x4, x8, #96
	mov	x5, x20
	mov	w6, #2
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio12store_device
	ands	w8, w0, #0xff
	b.eq	LBB11_41
	cmp	w8, #2
	mov	x8, x23
	b.eq	LBB11_32
	b	LBB11_23
LBB11_41:
	mov	w8, #7
	str	x24, [x19, #16]
	b	LBB11_26
	.loh AdrpLdr	Lloh46, Lloh47
	.cfi_endproc

	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
lCPI12_0:
	.quad	1
	.quad	3
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart18cstore64_with_physNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #96
	.cfi_def_cfa_offset 96
	stp	x26, x25, [sp, #16]
	stp	x24, x23, [sp, #32]
	stp	x22, x21, [sp, #48]
	stp	x20, x19, [sp, #64]
	stp	x29, x30, [sp, #80]
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_remember_state
	mov	x20, x5
	mov	x19, x0
	ldrb	w8, [x1, #708]
	cmp	w8, #1
	b.ne	LBB12_12
	ldr	x8, [x1, #680]
	and	x9, x8, #0xfffffffffffffffe
	and	x9, x9, #0xf000000000000003
	mov	x10, #2
	movk	x10, #8192, lsl #48
	cmp	x9, x10
	b.ne	LBB12_12
	ldrb	w9, [x1, #709]
	cmp	w9, #3
	b.eq	LBB12_5
	cmp	w9, #1
	b.ne	LBB12_7
	and	x9, x8, #0x10
	b	LBB12_8
LBB12_5:
	tbz	w8, #6, LBB12_12
	ldr	x9, [x1, #696]
	and	x9, x9, #0x8
	b	LBB12_8
LBB12_7:
	and	x9, x8, #0x8
LBB12_8:
	mov	w10, #63360
	tst	x8, x10
	b.ne	LBB12_12
	cbz	x9, LBB12_12
	ldr	x8, [x1, #688]
	cmp	x8, x4
	b.ne	LBB12_12
	str	x4, [x19, #16]
Lloh48:
	adrp	x8, lCPI12_0@PAGE
Lloh49:
	ldr	q0, [x8, lCPI12_0@PAGEOFF]
	str	q0, [x19]
	b	LBB12_27
LBB12_12:
	tst	x4, #0x7
	b.eq	LBB12_14
	mov	x0, sp
	mov	w5, #8
	mov	x6, x20
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart16misaligned_storeNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x9, [sp]
	cmn	x8, #1
	cset	w10, ne
	csinc	x8, x8, xzr, ne
	stp	x8, x9, [x19, #8]
	str	x10, [x19]
	b	LBB12_27
LBB12_14:
	ldr	x8, [x1, #616]
	tbnz	w8, #17, LBB12_16
	ldrb	w22, [x1, #709]
	b	LBB12_17
LBB12_16:
	ubfx	x8, x8, #11, #2
	cmp	x8, #1
	cset	w9, eq
	cmp	x8, #3
	mov	w8, #3
	csel	w22, w8, w9, eq
LBB12_17:
	mov	x0, sp
	mov	x23, x1
	mov	x24, x3
	mov	x25, x4
	mov	w5, #2
	mov	x6, x22
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x21, [sp]
	cmn	x8, #1
	b.ne	LBB12_25
	mov	x0, x23
	mov	x1, x21
	mov	w2, #8
	mov	w3, #1
	mov	x4, x22
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6pmp_ok
	tbz	w0, #0, LBB12_24
	mov	x8, x24
	ldr	x9, [x24, #24]
	subs	x10, x21, x9
	b.lo	LBB12_36
	cmn	x10, #9
	b.hi	LBB12_36
	add	x11, x10, #8
	ldr	x12, [x8, #16]
	cmp	x11, x12
	b.hi	LBB12_36
	tst	x21, #0x7
	b.eq	LBB12_28
LBB12_23:
	mov	w8, #6
	str	x25, [x19, #16]
	b	LBB12_26
LBB12_24:
	mov	w8, #7
	mov	x21, x25
LBB12_25:
	str	x21, [x19, #16]
LBB12_26:
	mov	w9, #1
	stp	x9, x8, [x19]
LBB12_27:
	.cfi_def_cfa wsp, 96
	ldp	x29, x30, [sp, #80]
	ldp	x20, x19, [sp, #64]
	ldp	x22, x21, [sp, #48]
	ldp	x24, x23, [sp, #32]
	ldp	x26, x25, [sp, #16]
	add	sp, sp, #96
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	ret
LBB12_28:
	.cfi_restore_state
	ldr	x9, [x8, #8]
	str	x20, [x9, x10]
	ldrb	w9, [x8, #192]
	cmp	w9, #1
	b.ne	LBB12_32
	lsr	x20, x21, #12
	mov	x0, x8
	ldr	x9, [x0, #56]!
	ldr	x22, [x0, #16]
	cmp	x22, x9
	b.ne	LBB12_31
	bl	__RNvMs4_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVecyE8grow_oneCs5joLtdXDRmI_12wasm_vm_core
	mov	x8, x24
LBB12_31:
	ldr	x9, [x8, #64]
	str	x20, [x9, x22, lsl #3]
	add	x9, x22, #1
	str	x9, [x8, #72]
LBB12_32:
	mov	x9, #0
	cmn	x21, #9
	b.hi	LBB12_35
	ldr	x10, [x8, #24]
	cmp	x21, x10
	b.lo	LBB12_35
	add	x9, x21, #8
	ldr	x8, [x8, #16]
	add	x8, x8, x10
	cmp	x9, x8
	cset	w9, ls
LBB12_35:
	stp	x9, x21, [x19, #8]
	str	xzr, [x19]
	b	LBB12_27
LBB12_36:
	ldp	x0, x1, [x8, #40]
	ldr	x9, [x8, #80]
	cbnz	x9, LBB12_38
	mov	x2, #0
	b	LBB12_39
LBB12_38:
	ldr	x3, [x8, #88]
	ldr	x10, [x3, #16]
	sub	x10, x10, #1
	and	x10, x10, #0xfffffffffffffff0
	add	x9, x9, x10
	add	x2, x9, #16
LBB12_39:
	add	x4, x8, #96
	mov	x5, x21
	mov	w6, #3
	mov	x7, x20
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio12store_device
	ands	w8, w0, #0xff
	b.eq	LBB12_41
	cmp	w8, #2
	mov	x8, x24
	b.eq	LBB12_32
	b	LBB12_23
LBB12_41:
	mov	w8, #7
	str	x25, [x19, #16]
	b	LBB12_26
	.loh AdrpLdr	Lloh48, Lloh49
	.cfi_endproc

	.p2align	2
__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart6cload8NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x24, x23, [sp, #16]
	stp	x22, x21, [sp, #32]
	stp	x20, x19, [sp, #48]
	stp	x29, x30, [sp, #64]
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_remember_state
	mov	x20, x4
	mov	x21, x3
	mov	x22, x1
	mov	x19, x0
	ldrb	w8, [x1, #708]
	cmp	w8, #1
	b.ne	LBB13_12
	ldr	x8, [x22, #680]
	and	x9, x8, #0xf000000000000001
	mov	x10, #1
	movk	x10, #8192, lsl #48
	cmp	x9, x10
	b.ne	LBB13_12
	ldrb	w9, [x22, #709]
	cmp	w9, #3
	b.eq	LBB13_5
	cmp	w9, #1
	b.ne	LBB13_7
	and	x9, x8, #0x10
	b	LBB13_8
LBB13_5:
	tbz	w8, #6, LBB13_12
	ldr	x9, [x22, #696]
	and	x9, x9, #0x8
	b	LBB13_8
LBB13_7:
	and	x9, x8, #0x8
LBB13_8:
	mov	w10, #63360
	tst	x8, x10
	b.ne	LBB13_12
	cbz	x9, LBB13_12
	ldr	x8, [x22, #688]
	cmp	x8, x20
	b.ne	LBB13_12
	mov	w8, #3
	b	LBB13_24
LBB13_12:
	ldr	x8, [x22, #616]
	tbnz	w8, #17, LBB13_14
	ldrb	w24, [x22, #709]
	b	LBB13_15
LBB13_14:
	ubfx	x8, x8, #11, #2
	cmp	x8, #1
	cset	w9, eq
	cmp	x8, #3
	mov	w8, #3
	csel	w24, w8, w9, eq
LBB13_15:
	mov	x0, sp
	mov	x1, x22
	mov	x3, x21
	mov	x4, x20
	mov	w5, #1
	mov	x6, x24
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x23, [sp]
	cmn	x8, #1
	b.eq	LBB13_17
	mov	x20, x23
	b	LBB13_24
LBB13_17:
	mov	x0, x22
	mov	x1, x23
	mov	w2, #1
	mov	w3, #0
	mov	x4, x24
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6pmp_ok
	tbz	w0, #0, LBB13_23
	ldr	x8, [x21, #24]
	subs	x8, x23, x8
	b.lo	LBB13_26
	cmn	x8, #1
	b.eq	LBB13_26
	ldr	x9, [x21, #16]
	cmp	x8, x9
	b.hs	LBB13_26
	ldr	x9, [x21, #8]
	ldrb	w8, [x9, x8]
LBB13_22:
	strb	w8, [x19, #8]
	mov	x8, #-1
	str	x8, [x19]
	b	LBB13_25
LBB13_23:
	mov	w8, #5
LBB13_24:
	stp	x8, x20, [x19]
LBB13_25:
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x24, x23, [sp, #16]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	ret
LBB13_26:
	.cfi_restore_state
	ldp	x0, x1, [x21, #40]
	ldr	x8, [x21, #80]
	cbnz	x8, LBB13_28
	mov	x2, #0
	b	LBB13_29
LBB13_28:
	ldr	x3, [x21, #88]
	ldr	x9, [x3, #16]
	sub	x9, x9, #1
	and	x9, x9, #0xfffffffffffffff0
	add	x8, x8, x9
	add	x2, x8, #16
LBB13_29:
	mov	x8, sp
	add	x4, x21, #96
	mov	x5, x23
	mov	w6, #0
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio11load_device
	ldrb	w8, [sp]
	cmp	w8, #1
	b.ne	LBB13_31
	ldrb	w8, [sp, #1]
	cmp	w8, #0
	mov	w8, #4
	cinc	x8, x8, eq
	b	LBB13_24
LBB13_31:
	ldrb	w8, [sp, #8]
	b	LBB13_22
	.cfi_endproc

	.p2align	2
__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart7cload16NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x24, x23, [sp, #16]
	stp	x22, x21, [sp, #32]
	stp	x20, x19, [sp, #48]
	stp	x29, x30, [sp, #64]
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_remember_state
	mov	x19, x0
	ldrb	w8, [x1, #708]
	cmp	w8, #1
	b.ne	LBB14_12
	ldr	x8, [x1, #680]
	and	x9, x8, #0xf000000000000001
	mov	x10, #1
	movk	x10, #8192, lsl #48
	cmp	x9, x10
	b.ne	LBB14_12
	ldrb	w9, [x1, #709]
	cmp	w9, #3
	b.eq	LBB14_5
	cmp	w9, #1
	b.ne	LBB14_7
	and	x9, x8, #0x10
	b	LBB14_8
LBB14_5:
	tbz	w8, #6, LBB14_12
	ldr	x9, [x1, #696]
	and	x9, x9, #0x8
	b	LBB14_8
LBB14_7:
	and	x9, x8, #0x8
LBB14_8:
	mov	w10, #63360
	tst	x8, x10
	b.ne	LBB14_12
	cbz	x9, LBB14_12
	ldr	x8, [x1, #688]
	cmp	x8, x4
	b.ne	LBB14_12
	mov	w8, #3
	stp	x8, x4, [x19]
	b	LBB14_30
LBB14_12:
	tbnz	w4, #0, LBB14_15
	ldr	x8, [x1, #616]
	tbnz	w8, #17, LBB14_17
	ldrb	w21, [x1, #709]
	b	LBB14_18
LBB14_15:
	mov	x0, sp
	mov	w5, #2
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart15misaligned_loadNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x9, [sp]
	cmn	x8, #1
	b.eq	LBB14_27
	stp	x8, x9, [x19]
	b	LBB14_30
LBB14_17:
	ubfx	x8, x8, #11, #2
	cmp	x8, #1
	cset	w9, eq
	cmp	x8, #3
	mov	w8, #3
	csel	w21, w8, w9, eq
LBB14_18:
	mov	x0, sp
	mov	x22, x1
	mov	x24, x3
	mov	x23, x4
	mov	w5, #1
	mov	x6, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x20, [sp]
	cmn	x8, #1
	b.ne	LBB14_29
	mov	x0, x22
	mov	x1, x20
	mov	w2, #2
	mov	w3, #0
	mov	x4, x21
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6pmp_ok
	tbz	w0, #0, LBB14_28
	mov	x9, x24
	ldr	x8, [x24, #24]
	subs	x10, x20, x8
	mov	x8, x23
	b.lo	LBB14_23
	cmn	x10, #3
	b.hi	LBB14_23
	add	x11, x10, #2
	ldr	x12, [x9, #16]
	cmp	x11, x12
	b.ls	LBB14_32
LBB14_23:
	mov	w10, #1
	lsr	w11, w10, #8
	lsr	w21, w10, #16
	tbz	w10, #0, LBB14_25
LBB14_24:
	tbz	w11, #0, LBB14_35
LBB14_25:
	tbz	w10, #0, LBB14_31
	tst	w11, #0x1
	mov	w9, #4
	cinc	x9, x9, eq
	stp	x9, x8, [x19]
	b	LBB14_30
LBB14_27:
	strh	w9, [x19, #8]
	str	x8, [x19]
	b	LBB14_30
LBB14_28:
	mov	w8, #5
	mov	x20, x23
LBB14_29:
	stp	x8, x20, [x19]
LBB14_30:
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x24, x23, [sp, #16]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	ret
LBB14_31:
	.cfi_restore_state
	strh	w21, [x19, #8]
	mov	x8, #-1
	str	x8, [x19]
	b	LBB14_30
LBB14_32:
	tbnz	w20, #0, LBB14_34
	ldr	x11, [x9, #8]
	ldrh	w10, [x11, x10]
	lsl	w10, w10, #16
	lsr	w11, w10, #8
	lsr	w21, w10, #16
	tbnz	w10, #0, LBB14_24
	b	LBB14_25
LBB14_34:
	mov	w10, #257
	lsr	w11, w10, #8
	lsr	w21, w10, #16
	tbnz	w10, #0, LBB14_24
	b	LBB14_25
LBB14_35:
	ldp	x0, x1, [x9, #40]
	ldr	x8, [x9, #80]
	cbnz	x8, LBB14_37
	mov	x2, #0
	b	LBB14_38
LBB14_37:
	ldr	x3, [x24, #88]
	ldr	x9, [x3, #16]
	sub	x9, x9, #1
	and	x9, x9, #0xfffffffffffffff0
	add	x8, x8, x9
	add	x2, x8, #16
LBB14_38:
	mov	x8, sp
	add	x4, x24, #96
	mov	x5, x20
	mov	w6, #1
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio11load_device
	ldrb	w10, [sp]
	ldrb	w8, [sp, #1]
	ldr	w9, [sp, #8]
	cmp	w10, #0
	csel	w21, w21, w9, ne
	csel	w11, w8, wzr, ne
	mov	x8, x23
	b	LBB14_25
	.cfi_endproc

	.p2align	2
__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart7cload32NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x24, x23, [sp, #16]
	stp	x22, x21, [sp, #32]
	stp	x20, x19, [sp, #48]
	stp	x29, x30, [sp, #64]
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_remember_state
	mov	x19, x0
	ldrb	w8, [x1, #708]
	cmp	w8, #1
	b.ne	LBB15_12
	ldr	x8, [x1, #680]
	and	x9, x8, #0xf000000000000001
	mov	x10, #1
	movk	x10, #8192, lsl #48
	cmp	x9, x10
	b.ne	LBB15_12
	ldrb	w9, [x1, #709]
	cmp	w9, #3
	b.eq	LBB15_5
	cmp	w9, #1
	b.ne	LBB15_7
	and	x9, x8, #0x10
	b	LBB15_8
LBB15_5:
	tbz	w8, #6, LBB15_12
	ldr	x9, [x1, #696]
	and	x9, x9, #0x8
	b	LBB15_8
LBB15_7:
	and	x9, x8, #0x8
LBB15_8:
	mov	w10, #63360
	tst	x8, x10
	b.ne	LBB15_12
	cbz	x9, LBB15_12
	ldr	x8, [x1, #688]
	cmp	x8, x4
	b.ne	LBB15_12
	mov	w8, #3
	stp	x8, x4, [x19]
	b	LBB15_30
LBB15_12:
	tst	x4, #0x3
	b.eq	LBB15_15
	mov	x0, sp
	mov	w5, #4
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart15misaligned_loadNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x9, [sp]
	cmn	x8, #1
	b.eq	LBB15_17
	stp	x8, x9, [x19]
	b	LBB15_30
LBB15_15:
	ldr	x8, [x1, #616]
	tbnz	w8, #17, LBB15_18
	ldrb	w21, [x1, #709]
	b	LBB15_19
LBB15_17:
	str	w9, [x19, #8]
	str	x8, [x19]
	b	LBB15_30
LBB15_18:
	ubfx	x8, x8, #11, #2
	cmp	x8, #1
	cset	w9, eq
	cmp	x8, #3
	mov	w8, #3
	csel	w21, w8, w9, eq
LBB15_19:
	mov	x0, sp
	mov	x22, x1
	mov	x24, x3
	mov	x23, x4
	mov	w5, #1
	mov	x6, x21
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x20, [sp]
	cmn	x8, #1
	b.ne	LBB15_29
	mov	x0, x22
	mov	x1, x20
	mov	w2, #4
	mov	w3, #0
	mov	x4, x21
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6pmp_ok
	tbz	w0, #0, LBB15_28
	mov	x9, x24
	ldr	x8, [x24, #24]
	subs	x10, x20, x8
	mov	x8, x23
	b.lo	LBB15_24
	cmn	x10, #5
	b.hi	LBB15_24
	add	x11, x10, #4
	ldr	x12, [x9, #16]
	cmp	x11, x12
	b.ls	LBB15_32
LBB15_24:
	mov	w10, #1
	lsr	x11, x10, #8
	lsr	x21, x10, #32
	tbz	w10, #0, LBB15_26
LBB15_25:
	tbz	w11, #0, LBB15_35
LBB15_26:
	tbz	w10, #0, LBB15_31
	tst	w11, #0x1
	mov	w9, #4
	cinc	x9, x9, eq
	stp	x9, x8, [x19]
	b	LBB15_30
LBB15_28:
	mov	w8, #5
	mov	x20, x23
LBB15_29:
	stp	x8, x20, [x19]
LBB15_30:
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x24, x23, [sp, #16]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	ret
LBB15_31:
	.cfi_restore_state
	str	w21, [x19, #8]
	mov	x8, #-1
	str	x8, [x19]
	b	LBB15_30
LBB15_32:
	tst	x20, #0x3
	b.eq	LBB15_34
	mov	w10, #257
	lsr	x11, x10, #8
	lsr	x21, x10, #32
	tbnz	w10, #0, LBB15_25
	b	LBB15_26
LBB15_34:
	ldr	x11, [x9, #8]
	ldr	w10, [x11, x10]
	lsl	x10, x10, #32
	lsr	x11, x10, #8
	lsr	x21, x10, #32
	tbnz	w10, #0, LBB15_25
	b	LBB15_26
LBB15_35:
	ldp	x0, x1, [x9, #40]
	ldr	x8, [x9, #80]
	cbnz	x8, LBB15_37
	mov	x2, #0
	b	LBB15_38
LBB15_37:
	ldr	x3, [x24, #88]
	ldr	x9, [x3, #16]
	sub	x9, x9, #1
	and	x9, x9, #0xfffffffffffffff0
	add	x8, x8, x9
	add	x2, x8, #16
LBB15_38:
	mov	x8, sp
	add	x4, x24, #96
	mov	x5, x20
	mov	w6, #2
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio11load_device
	ldrb	w10, [sp]
	ldrb	w8, [sp, #1]
	ldr	x9, [sp, #8]
	cmp	w10, #0
	csel	w11, w8, wzr, ne
	csel	x21, x21, x9, ne
	mov	x8, x23
	b	LBB15_26
	.cfi_endproc

	.p2align	2
__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart7cload64NtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x24, x23, [sp, #16]
	stp	x22, x21, [sp, #32]
	stp	x20, x19, [sp, #48]
	stp	x29, x30, [sp, #64]
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_remember_state
	ldrb	w8, [x1, #708]
	cmp	w8, #1
	b.ne	LBB16_12
	ldr	x8, [x1, #680]
	and	x9, x8, #0xf000000000000001
	mov	x10, #1
	movk	x10, #8192, lsl #48
	cmp	x9, x10
	b.ne	LBB16_12
	ldrb	w9, [x1, #709]
	cmp	w9, #3
	b.eq	LBB16_5
	cmp	w9, #1
	b.ne	LBB16_7
	and	x9, x8, #0x10
	b	LBB16_8
LBB16_5:
	tbz	w8, #6, LBB16_12
	ldr	x9, [x1, #696]
	and	x9, x9, #0x8
	b	LBB16_8
LBB16_7:
	and	x9, x8, #0x8
LBB16_8:
	mov	w10, #63360
	tst	x8, x10
	b.ne	LBB16_12
	cbz	x9, LBB16_12
	ldr	x8, [x1, #688]
	cmp	x8, x4
	b.ne	LBB16_12
	mov	w8, #3
	stp	x8, x4, [x0]
	b	LBB16_27
LBB16_12:
	tst	x4, #0x7
	b.eq	LBB16_14
	mov	w5, #8
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x24, x23, [sp, #16]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	b	__RINvNtCs5joLtdXDRmI_12wasm_vm_core4hart15misaligned_loadNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
LBB16_14:
	.cfi_restore_state
	.cfi_remember_state
	ldr	x8, [x1, #616]
	tbnz	w8, #17, LBB16_16
	mov	x23, x0
	ldrb	w20, [x1, #709]
	b	LBB16_17
LBB16_16:
	mov	x23, x0
	ubfx	x8, x8, #11, #2
	cmp	x8, #1
	cset	w9, eq
	cmp	x8, #3
	mov	w8, #3
	csel	w20, w8, w9, eq
LBB16_17:
	mov	x0, sp
	mov	x21, x1
	mov	x24, x3
	mov	x22, x4
	mov	w5, #1
	mov	x6, x20
	bl	__RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	ldp	x8, x19, [sp]
	cmn	x8, #1
	b.ne	LBB16_26
	mov	x0, x21
	mov	x1, x19
	mov	w2, #8
	mov	w3, #0
	mov	x4, x20
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs6pmp_ok
	tbz	w0, #0, LBB16_25
	mov	x9, x24
	ldr	x8, [x24, #24]
	subs	x11, x19, x8
	mov	x8, x23
	b.lo	LBB16_31
	cmn	x11, #9
	b.hi	LBB16_31
	add	x12, x11, #8
	ldr	x13, [x9, #16]
	cmp	x12, x13
	b.hi	LBB16_31
	tst	x19, #0x7
	b.eq	LBB16_28
	mov	x10, x22
	mov	w9, #1
	strb	w9, [sp, #1]
LBB16_24:
	ldrb	w9, [sp, #1]
	cmp	w9, #0
	mov	w9, #4
	cinc	x9, x9, eq
	b	LBB16_30
LBB16_25:
	mov	w8, #5
	mov	x19, x22
LBB16_26:
	stp	x8, x19, [x23]
LBB16_27:
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x24, x23, [sp, #16]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	ret
LBB16_28:
	.cfi_restore_state
	ldr	x9, [x9, #8]
	ldr	x9, [x9, x11]
	str	x9, [sp, #8]
LBB16_29:
	mov	x9, #-1
	ldr	x10, [sp, #8]
LBB16_30:
	stp	x9, x10, [x8]
	b	LBB16_27
LBB16_31:
	mov	w10, #1
	strh	w10, [sp]
	ldp	x0, x1, [x9, #40]
	ldr	x10, [x9, #80]
	cbnz	x10, LBB16_33
	mov	x20, x8
	mov	x2, #0
	b	LBB16_34
LBB16_33:
	mov	x20, x8
	ldr	x3, [x9, #88]
	ldr	x8, [x3, #16]
	sub	x8, x8, #1
	and	x8, x8, #0xfffffffffffffff0
	add	x8, x10, x8
	add	x2, x8, #16
LBB16_34:
	mov	x8, sp
	add	x4, x9, #96
	mov	x5, x19
	mov	w6, #3
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio11load_device
	ldrb	w8, [sp]
	cmp	w8, #1
	mov	x8, x20
	mov	x10, x22
	b.eq	LBB16_24
	b	LBB16_29
	.cfi_endproc

	.private_extern	__RINvNtCs7mRY9FNn263_3std2rt10lang_startuECsj7lyy62zRs3_24retirement_capture_probe
	.globl	__RINvNtCs7mRY9FNn263_3std2rt10lang_startuECsj7lyy62zRs3_24retirement_capture_probe
	.p2align	2
__RINvNtCs7mRY9FNn263_3std2rt10lang_startuECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x4, x3
	mov	x3, x2
	mov	x2, x1
	str	x0, [sp, #8]
Lloh50:
	adrp	x1, l_anon.9ed3183efb56324a1c787c8a9029a2a7.30@PAGE
Lloh51:
	add	x1, x1, l_anon.9ed3183efb56324a1c787c8a9029a2a7.30@PAGEOFF
	add	x0, sp, #8
	bl	__RNvNtCs7mRY9FNn263_3std2rt19lang_start_internal
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh50, Lloh51
	.cfi_endproc

	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCs6KVRSXc8uZF_5alloc5boxed3BoxDNtNtCs5joLtdXDRmI_12wasm_vm_core3jit21CompiledBlockExecutorEL_EEECsj7lyy62zRs3_24retirement_capture_probe:
Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception0
	stp	x22, x21, [sp, #-48]!
	.cfi_def_cfa_offset 48
	stp	x20, x19, [sp, #16]
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_remember_state
	cbz	x0, LBB18_5
	mov	x20, x1
	mov	x19, x0
	ldr	x8, [x1]
	cbz	x8, LBB18_3
Ltmp0:
	mov	x0, x19
	blr	x8
Ltmp1:
LBB18_3:
	ldr	x1, [x20, #8]
	cbz	x1, LBB18_5
	ldr	x2, [x20, #16]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	ldp	x20, x19, [sp, #16]
	ldp	x22, x21, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	b	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB18_5:
	.cfi_restore_state
	.cfi_remember_state
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	ldp	x20, x19, [sp, #16]
	ldp	x22, x21, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	ret
LBB18_6:
	.cfi_restore_state
Ltmp2:
	mov	x21, x0
	ldr	x1, [x20, #8]
	cbz	x1, LBB18_8
	ldr	x2, [x20, #16]
	mov	x0, x19
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB18_8:
	mov	x0, x21
	bl	__Unwind_Resume
Lfunc_end0:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table18:
Lexception0:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end0-Lcst_begin0
Lcst_begin0:
	.uleb128 Ltmp0-Lfunc_begin0
	.uleb128 Ltmp1-Ltmp0
	.uleb128 Ltmp2-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp1-Lfunc_begin0
	.uleb128 Lfunc_end0-Ltmp1
	.byte	0
	.byte	0
Lcst_end0:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionNtCs5joLtdXDRmI_12wasm_vm_core20VirtioConsoleServiceEECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	ldr	x8, [x0]
	cmp	x8, #2
	b.eq	LBB19_2
	ldr	x8, [x0, #240]!
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.eq	LBB19_3
LBB19_2:
	ret
LBB19_3:
	b	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio7console12ConsoleStateEE9drop_slowB1m_
	.cfi_endproc

	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev3rtc11GoldfishRtcEENtNtB1S_4plic7IrqLineEEECsj7lyy62zRs3_24retirement_capture_probe:
Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception1
	stp	x20, x19, [sp, #-32]!
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_remember_state
	ldr	x8, [x0]
	cbz	x8, LBB20_4
	mov	x19, x0
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB20_3
Ltmp3:
	mov	x0, x19
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev3rtc11GoldfishRtcEE9drop_slowB1k_
Ltmp4:
LBB20_3:
	ldr	x8, [x19, #8]!
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.eq	LBB20_5
LBB20_4:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
LBB20_5:
	.cfi_restore_state
	.cfi_remember_state
	mov	x0, x19
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	b	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev4plic9PlicStateEE9drop_slowB1k_
LBB20_6:
	.cfi_restore_state
Ltmp5:
	mov	x20, x0
	ldr	x8, [x19, #8]!
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB20_8
Ltmp6:
	mov	x0, x19
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev4plic9PlicStateEE9drop_slowB1k_
Ltmp7:
LBB20_8:
	mov	x0, x20
	bl	__Unwind_Resume
LBB20_9:
Ltmp8:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup
Lfunc_end1:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table20:
Lexception1:
	.byte	255
	.byte	155
	.uleb128 Lttbase0-Lttbaseref0
Lttbaseref0:
	.byte	1
	.uleb128 Lcst_end1-Lcst_begin1
Lcst_begin1:
	.uleb128 Ltmp3-Lfunc_begin1
	.uleb128 Ltmp4-Ltmp3
	.uleb128 Ltmp5-Lfunc_begin1
	.byte	0
	.uleb128 Ltmp4-Lfunc_begin1
	.uleb128 Ltmp6-Ltmp4
	.byte	0
	.byte	0
	.uleb128 Ltmp6-Lfunc_begin1
	.uleb128 Ltmp7-Ltmp6
	.uleb128 Ltmp8-Lfunc_begin1
	.byte	1
	.uleb128 Ltmp7-Lfunc_begin1
	.uleb128 Lfunc_end1-Ltmp7
	.byte	0
	.byte	0
Lcst_end1:
	.byte	127
	.byte	0
	.p2align	2, 0x0
Lttbase0:
	.byte	0
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev9uart165509Uart16550EENtNtB1S_4plic7IrqLineEEECsj7lyy62zRs3_24retirement_capture_probe:
Lfunc_begin2:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception2
	stp	x20, x19, [sp, #-32]!
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_remember_state
	ldr	x8, [x0]
	cbz	x8, LBB21_4
	mov	x19, x0
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB21_3
Ltmp9:
	mov	x0, x19
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev9uart165509Uart16550EE9drop_slowB1k_
Ltmp10:
LBB21_3:
	ldr	x8, [x19, #8]!
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.eq	LBB21_5
LBB21_4:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
LBB21_5:
	.cfi_restore_state
	.cfi_remember_state
	mov	x0, x19
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	b	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev4plic9PlicStateEE9drop_slowB1k_
LBB21_6:
	.cfi_restore_state
Ltmp11:
	mov	x20, x0
	ldr	x8, [x19, #8]!
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB21_8
Ltmp12:
	mov	x0, x19
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev4plic9PlicStateEE9drop_slowB1k_
Ltmp13:
LBB21_8:
	mov	x0, x20
	bl	__Unwind_Resume
LBB21_9:
Ltmp14:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup
Lfunc_end2:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table21:
Lexception2:
	.byte	255
	.byte	155
	.uleb128 Lttbase1-Lttbaseref1
Lttbaseref1:
	.byte	1
	.uleb128 Lcst_end2-Lcst_begin2
Lcst_begin2:
	.uleb128 Ltmp9-Lfunc_begin2
	.uleb128 Ltmp10-Ltmp9
	.uleb128 Ltmp11-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp10-Lfunc_begin2
	.uleb128 Ltmp12-Ltmp10
	.byte	0
	.byte	0
	.uleb128 Ltmp12-Lfunc_begin2
	.uleb128 Ltmp13-Ltmp12
	.uleb128 Ltmp14-Lfunc_begin2
	.byte	1
	.uleb128 Ltmp13-Lfunc_begin2
	.uleb128 Lfunc_end2-Ltmp13
	.byte	0
	.byte	0
Lcst_end2:
	.byte	127
	.byte	0
	.p2align	2, 0x0
Lttbase1:
	.byte	0
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3blk8BlkStateEEIBC_NtNtB1S_5queue9VirtqueueEEEECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	ldr	x8, [x0, #8]
	cmp	x8, #2
	b.eq	LBB22_2
	ldr	x8, [x0]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.eq	LBB22_3
LBB22_2:
	ret
LBB22_3:
	b	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3blk8BlkStateEE9drop_slowB1m_
	.cfi_endproc

	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3gpu8GpuStateEEIBC_NtNtB1S_5queue9VirtqueueEB2O_jEEECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	ldr	x8, [x0]
	cmp	x8, #2
	b.eq	LBB23_2
	ldr	x8, [x0, #80]!
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.eq	LBB23_3
LBB23_2:
	ret
LBB23_3:
	b	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3gpu8GpuStateEE9drop_slowB1m_
	.cfi_endproc

	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3net8NetStateEEIBC_NtNtB1S_5queue9VirtqueueEB2O_EEECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	ldr	x8, [x0]
	cmp	x8, #2
	b.eq	LBB24_2
	ldr	x8, [x0, #40]!
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.eq	LBB24_3
LBB24_2:
	ret
LBB24_3:
	b	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3net8NetStateEE9drop_slowB1m_
	.cfi_endproc

	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3rng8RngStateEEIBC_NtNtB1S_5queue9VirtqueueEEEECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	ldr	x8, [x0, #8]
	cmp	x8, #2
	b.eq	LBB25_2
	ldr	x8, [x0]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.eq	LBB25_3
LBB25_2:
	ret
LBB25_3:
	b	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3rng8RngStateEE9drop_slowB1m_
	.cfi_endproc

	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio5input10InputStateEEIBC_NtNtB1S_5queue9VirtqueueEB2T_EEECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	ldr	x8, [x0]
	cmp	x8, #2
	b.eq	LBB26_2
	ldr	x8, [x0, #40]!
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.eq	LBB26_3
LBB26_2:
	ret
LBB26_3:
	b	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio5input10InputStateEE9drop_slowB1m_
	.cfi_endproc

	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTjINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3snd8SndStateEEIBC_NtNtB1T_5queue9VirtqueueEB2P_B2P_B2P_IB10_DNtB1R_10AudioClockEL_EINtNtB14_5boxed3BoxDNtB1R_9AudioSinkEL_EIB3X_DNtB1R_18AudioCaptureSourceEL_EEEECsj7lyy62zRs3_24retirement_capture_probe:
Lfunc_begin3:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception3
	stp	x22, x21, [sp, #-48]!
	.cfi_def_cfa_offset 48
	stp	x20, x19, [sp, #16]
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_remember_state
	ldr	x8, [x0]
	cmp	x8, #2
	b.eq	LBB27_13
	mov	x19, x0
	ldr	x8, [x0, #160]!
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB27_3
Ltmp15:
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3snd8SndStateEE9drop_slowB1m_
Ltmp16:
LBB27_3:
	mov	x0, x19
	ldr	x8, [x0, #168]!
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB27_5
Ltmp20:
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcDNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3snd10AudioClockEL_E9drop_slowBM_
Ltmp21:
LBB27_5:
	ldp	x21, x20, [x19, #184]
	ldr	x8, [x20]
	cbz	x8, LBB27_7
Ltmp25:
	mov	x0, x21
	blr	x8
Ltmp26:
LBB27_7:
	ldr	x1, [x20, #8]
	cbz	x1, LBB27_9
	ldr	x2, [x20, #16]
	mov	x0, x21
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB27_9:
	ldp	x21, x19, [x19, #208]
	ldr	x8, [x19]
	cbz	x8, LBB27_11
Ltmp31:
	mov	x0, x21
	blr	x8
Ltmp32:
LBB27_11:
	ldr	x1, [x19, #8]
	cbz	x1, LBB27_13
	ldr	x2, [x19, #16]
	mov	x0, x21
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	ldp	x20, x19, [sp, #16]
	ldp	x22, x21, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	b	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB27_13:
	.cfi_restore_state
	.cfi_remember_state
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	ldp	x20, x19, [sp, #16]
	ldp	x22, x21, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	ret
LBB27_14:
	.cfi_restore_state
Ltmp22:
	mov	x20, x0
	b	LBB27_17
LBB27_15:
Ltmp17:
	mov	x20, x0
	mov	x0, x19
	ldr	x8, [x0, #168]!
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB27_17
Ltmp18:
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcDNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3snd10AudioClockEL_E9drop_slowBM_
Ltmp19:
LBB27_17:
	ldp	x0, x1, [x19, #184]
Ltmp23:
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtCs6KVRSXc8uZF_5alloc5boxed3BoxDNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3snd18AudioCaptureSourceEL_EECsj7lyy62zRs3_24retirement_capture_probe
Ltmp24:
	b	LBB27_22
LBB27_18:
Ltmp33:
	mov	x20, x0
	ldr	x1, [x19, #8]
	cbz	x1, LBB27_23
	ldr	x2, [x19, #16]
	mov	x0, x21
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
	mov	x0, x20
	bl	__Unwind_Resume
LBB27_20:
Ltmp27:
	mov	x9, x20
	mov	x20, x0
	ldr	x1, [x9, #8]
	cbz	x1, LBB27_22
	ldr	x2, [x9, #16]
	mov	x0, x21
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB27_22:
	ldp	x0, x1, [x19, #208]
Ltmp28:
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtCs6KVRSXc8uZF_5alloc5boxed3BoxDNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3snd18AudioCaptureSourceEL_EECsj7lyy62zRs3_24retirement_capture_probe
Ltmp29:
LBB27_23:
	mov	x0, x20
	bl	__Unwind_Resume
LBB27_24:
Ltmp30:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup
Lfunc_end3:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table27:
Lexception3:
	.byte	255
	.byte	155
	.uleb128 Lttbase2-Lttbaseref2
Lttbaseref2:
	.byte	1
	.uleb128 Lcst_end3-Lcst_begin3
Lcst_begin3:
	.uleb128 Ltmp15-Lfunc_begin3
	.uleb128 Ltmp16-Ltmp15
	.uleb128 Ltmp17-Lfunc_begin3
	.byte	0
	.uleb128 Ltmp20-Lfunc_begin3
	.uleb128 Ltmp21-Ltmp20
	.uleb128 Ltmp22-Lfunc_begin3
	.byte	0
	.uleb128 Ltmp25-Lfunc_begin3
	.uleb128 Ltmp26-Ltmp25
	.uleb128 Ltmp27-Lfunc_begin3
	.byte	0
	.uleb128 Ltmp31-Lfunc_begin3
	.uleb128 Ltmp32-Ltmp31
	.uleb128 Ltmp33-Lfunc_begin3
	.byte	0
	.uleb128 Ltmp18-Lfunc_begin3
	.uleb128 Ltmp24-Ltmp18
	.uleb128 Ltmp30-Lfunc_begin3
	.byte	1
	.uleb128 Ltmp24-Lfunc_begin3
	.uleb128 Ltmp28-Ltmp24
	.byte	0
	.byte	0
	.uleb128 Ltmp28-Lfunc_begin3
	.uleb128 Ltmp29-Ltmp28
	.uleb128 Ltmp30-Lfunc_begin3
	.byte	1
	.uleb128 Ltmp29-Lfunc_begin3
	.uleb128 Lfunc_end3-Ltmp29
	.byte	0
	.byte	0
Lcst_end3:
	.byte	127
	.byte	0
	.p2align	2, 0x0
Lttbase2:
	.byte	0
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtCs6KVRSXc8uZF_5alloc3vec3VecNtNtCs5joLtdXDRmI_12wasm_vm_core4mmio6WindowEECsj7lyy62zRs3_24retirement_capture_probe:
Lfunc_begin4:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception4
	stp	x24, x23, [sp, #-64]!
	.cfi_def_cfa_offset 64
	stp	x22, x21, [sp, #16]
	stp	x20, x19, [sp, #32]
	stp	x29, x30, [sp, #48]
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_remember_state
	mov	x20, x0
	ldp	x19, x23, [x0, #8]
	cbz	x23, LBB28_7
	add	x24, x19, #48
	b	LBB28_3
LBB28_2:
	add	x24, x24, #40
	subs	x23, x23, #1
	b.eq	LBB28_7
LBB28_3:
	ldp	x22, x21, [x24, #-48]
	ldr	x8, [x21]
	cbz	x8, LBB28_5
Ltmp34:
	mov	x0, x22
	blr	x8
Ltmp35:
LBB28_5:
	ldr	x1, [x21, #8]
	cbz	x1, LBB28_2
	ldr	x2, [x21, #16]
	mov	x0, x22
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
	b	LBB28_2
LBB28_7:
	ldr	x8, [x20]
	cbz	x8, LBB28_9
	add	x8, x8, x8, lsl #2
	lsl	x1, x8, #3
	mov	x0, x19
	mov	w2, #8
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]
	ldp	x20, x19, [sp, #32]
	ldp	x22, x21, [sp, #16]
	ldp	x24, x23, [sp], #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	b	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB28_9:
	.cfi_restore_state
	.cfi_remember_state
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]
	ldp	x20, x19, [sp, #32]
	ldp	x22, x21, [sp, #16]
	ldp	x24, x23, [sp], #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	ret
LBB28_10:
	.cfi_restore_state
Ltmp36:
	mov	x9, x21
	mov	x21, x0
	ldr	x1, [x9, #8]
	cbz	x1, LBB28_12
	ldr	x2, [x9, #16]
	mov	x0, x22
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB28_12:
	subs	x23, x23, #1
	b.eq	LBB28_14
	add	x22, x24, #40
	ldp	x0, x1, [x24, #-8]
Ltmp37:
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtCs6KVRSXc8uZF_5alloc5boxed3BoxDNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3snd18AudioCaptureSourceEL_EECsj7lyy62zRs3_24retirement_capture_probe
Ltmp38:
	mov	x24, x22
	b	LBB28_12
LBB28_14:
	ldr	x8, [x20]
	cbz	x8, LBB28_16
	add	x8, x8, x8, lsl #2
	lsl	x1, x8, #3
	mov	x0, x19
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB28_16:
	mov	x0, x21
	bl	__Unwind_Resume
LBB28_17:
Ltmp39:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup
Lfunc_end4:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table28:
Lexception4:
	.byte	255
	.byte	155
	.uleb128 Lttbase3-Lttbaseref3
Lttbaseref3:
	.byte	1
	.uleb128 Lcst_end4-Lcst_begin4
Lcst_begin4:
	.uleb128 Ltmp34-Lfunc_begin4
	.uleb128 Ltmp35-Ltmp34
	.uleb128 Ltmp36-Lfunc_begin4
	.byte	0
	.uleb128 Ltmp37-Lfunc_begin4
	.uleb128 Ltmp38-Ltmp37
	.uleb128 Ltmp39-Lfunc_begin4
	.byte	1
	.uleb128 Ltmp38-Lfunc_begin4
	.uleb128 Lfunc_end4-Ltmp38
	.byte	0
	.byte	0
Lcst_end4:
	.byte	127
	.byte	0
	.p2align	2, 0x0
Lttbase3:
	.byte	0
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtCs6KVRSXc8uZF_5alloc3vec3VecTINtNtBG_2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3blk8BlkStateEEINtNtB4_6option6OptionNtNtB1M_5queue9VirtqueueEjEEECsj7lyy62zRs3_24retirement_capture_probe:
Lfunc_begin5:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception5
	stp	x24, x23, [sp, #-64]!
	.cfi_def_cfa_offset 64
	stp	x22, x21, [sp, #16]
	stp	x20, x19, [sp, #32]
	stp	x29, x30, [sp, #48]
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_remember_state
	mov	x20, x0
	ldp	x19, x8, [x0, #8]
	cbz	x8, LBB29_5
	mov	x22, #0
	mov	w9, #1
	sub	x21, x9, x8
	b	LBB29_3
LBB29_2:
	add	x22, x22, #56
	add	x21, x21, #1
	cmp	x21, #1
	b.eq	LBB29_5
LBB29_3:
	add	x0, x19, x22
	ldr	x8, [x0, #40]!
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB29_2
Ltmp40:
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3blk8BlkStateEE9drop_slowB1m_
Ltmp41:
	b	LBB29_2
LBB29_5:
	ldr	x8, [x20]
	cbz	x8, LBB29_7
	lsl	x9, x8, #6
	sub	x1, x9, x8, lsl #3
	mov	x0, x19
	mov	w2, #8
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]
	ldp	x20, x19, [sp, #32]
	ldp	x22, x21, [sp, #16]
	ldp	x24, x23, [sp], #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	b	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB29_7:
	.cfi_restore_state
	.cfi_remember_state
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]
	ldp	x20, x19, [sp, #32]
	ldp	x22, x21, [sp, #16]
	ldp	x24, x23, [sp], #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	ret
LBB29_8:
	.cfi_restore_state
Ltmp42:
	mov	x9, x21
	mov	x21, x0
	cbnz	x9, LBB29_12
LBB29_9:
	ldr	x8, [x20]
	cbz	x8, LBB29_11
	lsl	x9, x8, #6
	sub	x1, x9, x8, lsl #3
	mov	x0, x19
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB29_11:
	mov	x0, x21
	bl	__Unwind_Resume
LBB29_12:
	mov	x8, x9
	add	x9, x19, x22
	add	x22, x9, #96
	neg	x23, x8
	b	LBB29_14
LBB29_13:
	add	x22, x22, #56
	subs	x23, x23, #1
	b.eq	LBB29_9
LBB29_14:
	ldr	x8, [x22]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB29_13
Ltmp43:
	mov	x0, x22
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3blk8BlkStateEE9drop_slowB1m_
Ltmp44:
	b	LBB29_13
LBB29_16:
Ltmp45:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup
Lfunc_end5:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table29:
Lexception5:
	.byte	255
	.byte	155
	.uleb128 Lttbase4-Lttbaseref4
Lttbaseref4:
	.byte	1
	.uleb128 Lcst_end5-Lcst_begin5
Lcst_begin5:
	.uleb128 Ltmp40-Lfunc_begin5
	.uleb128 Ltmp41-Ltmp40
	.uleb128 Ltmp42-Lfunc_begin5
	.byte	0
	.uleb128 Ltmp41-Lfunc_begin5
	.uleb128 Ltmp43-Ltmp41
	.byte	0
	.byte	0
	.uleb128 Ltmp43-Lfunc_begin5
	.uleb128 Ltmp44-Ltmp43
	.uleb128 Ltmp45-Lfunc_begin5
	.byte	1
Lcst_end5:
	.byte	127
	.byte	0
	.p2align	2, 0x0
Lttbase4:
	.byte	0
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtCs6KVRSXc8uZF_5alloc3vec3VecTINtNtBG_2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmio10VirtioMmioEENtNtB1O_4plic7IrqLineEEECsj7lyy62zRs3_24retirement_capture_probe:
Lfunc_begin6:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception6
	stp	x24, x23, [sp, #-64]!
	.cfi_def_cfa_offset 64
	stp	x22, x21, [sp, #16]
	stp	x20, x19, [sp, #32]
	stp	x29, x30, [sp, #48]
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_remember_state
	mov	x20, x0
	ldp	x19, x23, [x0, #8]
	cbz	x23, LBB30_7
	mov	x21, x19
	b	LBB30_3
LBB30_2:
	add	x21, x21, #24
	subs	x23, x23, #1
	b.eq	LBB30_7
LBB30_3:
	ldr	x8, [x21]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB30_5
Ltmp46:
	mov	x0, x21
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmio10VirtioMmioEE9drop_slowB1m_
Ltmp47:
LBB30_5:
	mov	x0, x21
	ldr	x8, [x0, #8]!
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB30_2
Ltmp52:
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev4plic9PlicStateEE9drop_slowB1k_
Ltmp53:
	b	LBB30_2
LBB30_7:
	ldr	x8, [x20]
	cbz	x8, LBB30_9
	add	x8, x8, x8, lsl #1
	lsl	x1, x8, #3
	mov	x0, x19
	mov	w2, #8
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]
	ldp	x20, x19, [sp, #32]
	ldp	x22, x21, [sp, #16]
	ldp	x24, x23, [sp], #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	b	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB30_9:
	.cfi_restore_state
	.cfi_remember_state
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]
	ldp	x20, x19, [sp, #32]
	ldp	x22, x21, [sp, #16]
	ldp	x24, x23, [sp], #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	ret
LBB30_10:
	.cfi_restore_state
Ltmp48:
	mov	x22, x0
	mov	x0, x21
	ldr	x8, [x0, #8]!
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB30_14
Ltmp49:
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev4plic9PlicStateEE9drop_slowB1k_
Ltmp50:
	b	LBB30_14
LBB30_12:
Ltmp51:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup
LBB30_13:
Ltmp54:
	mov	x22, x0
LBB30_14:
	add	x0, x21, #24
LBB30_15:
	subs	x23, x23, #1
	b.eq	LBB30_17
Ltmp55:
	add	x21, x0, #24
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueTINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmio10VirtioMmioEENtNtB1y_4plic7IrqLineEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp56:
	mov	x0, x21
	b	LBB30_15
LBB30_17:
	ldr	x8, [x20]
	cbz	x8, LBB30_19
	add	x8, x8, x8, lsl #1
	lsl	x1, x8, #3
	mov	x0, x19
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB30_19:
	mov	x0, x22
	bl	__Unwind_Resume
LBB30_20:
Ltmp57:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup
Lfunc_end6:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table30:
Lexception6:
	.byte	255
	.byte	155
	.uleb128 Lttbase5-Lttbaseref5
Lttbaseref5:
	.byte	1
	.uleb128 Lcst_end6-Lcst_begin6
Lcst_begin6:
	.uleb128 Ltmp46-Lfunc_begin6
	.uleb128 Ltmp47-Ltmp46
	.uleb128 Ltmp48-Lfunc_begin6
	.byte	0
	.uleb128 Ltmp52-Lfunc_begin6
	.uleb128 Ltmp53-Ltmp52
	.uleb128 Ltmp54-Lfunc_begin6
	.byte	0
	.uleb128 Ltmp49-Lfunc_begin6
	.uleb128 Ltmp50-Ltmp49
	.uleb128 Ltmp51-Lfunc_begin6
	.byte	1
	.uleb128 Ltmp55-Lfunc_begin6
	.uleb128 Ltmp56-Ltmp55
	.uleb128 Ltmp57-Lfunc_begin6
	.byte	1
	.uleb128 Ltmp56-Lfunc_begin6
	.uleb128 Lfunc_end6-Ltmp56
	.byte	0
	.byte	0
Lcst_end6:
	.byte	127
	.byte	0
	.p2align	2, 0x0
Lttbase5:
	.byte	0
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtCs6KVRSXc8uZF_5alloc5boxed3BoxDNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3snd18AudioCaptureSourceEL_EECsj7lyy62zRs3_24retirement_capture_probe:
Lfunc_begin7:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception7
	stp	x22, x21, [sp, #-48]!
	.cfi_def_cfa_offset 48
	stp	x20, x19, [sp, #16]
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_remember_state
	mov	x20, x1
	mov	x19, x0
	ldr	x8, [x1]
	cbz	x8, LBB31_2
Ltmp58:
	mov	x0, x19
	blr	x8
Ltmp59:
LBB31_2:
	ldr	x1, [x20, #8]
	cbz	x1, LBB31_4
	ldr	x2, [x20, #16]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	ldp	x20, x19, [sp, #16]
	ldp	x22, x21, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	b	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB31_4:
	.cfi_restore_state
	.cfi_remember_state
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	ldp	x20, x19, [sp, #16]
	ldp	x22, x21, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	ret
LBB31_5:
	.cfi_restore_state
Ltmp60:
	mov	x21, x0
	ldr	x1, [x20, #8]
	cbz	x1, LBB31_7
	ldr	x2, [x20, #16]
	mov	x0, x19
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB31_7:
	mov	x0, x21
	bl	__Unwind_Resume
Lfunc_end7:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table31:
Lexception7:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end7-Lcst_begin7
Lcst_begin7:
	.uleb128 Ltmp58-Lfunc_begin7
	.uleb128 Ltmp59-Ltmp58
	.uleb128 Ltmp60-Lfunc_begin7
	.byte	0
	.uleb128 Ltmp59-Lfunc_begin7
	.uleb128 Lfunc_end7-Ltmp59
	.byte	0
	.byte	0
Lcst_end7:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtNtCs6KVRSXc8uZF_5alloc11collections9vec_deque8VecDequeNtNtCs5joLtdXDRmI_12wasm_vm_core8dispatch18TranslationRequestEECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	stp	x26, x25, [sp, #-80]!
	.cfi_def_cfa_offset 80
	stp	x24, x23, [sp, #16]
	stp	x22, x21, [sp, #32]
	stp	x20, x19, [sp, #48]
	stp	x29, x30, [sp, #64]
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_remember_state
	mov	x19, x0
	ldr	x22, [x0, #24]
	ldr	x20, [x0]
	cbz	x22, LBB32_9
	ldp	x23, x8, [x19, #8]
	cmp	x8, x20
	csel	x9, xzr, x20, lo
	sub	x10, x8, x9
	sub	x24, x20, x10
	add	x11, x10, x22
	subs	x12, x22, x24
	csel	x21, xzr, x12, lo
	cmp	x24, x22
	csel	x11, x20, x11, lo
	subs	x25, x11, x10
	b.ne	LBB32_12
LBB32_2:
	cmp	x24, x22
	b.hs	LBB32_9
	add	x22, x23, #32
	b	LBB32_5
LBB32_4:
	add	x22, x22, #72
	subs	x21, x21, #1
	b.eq	LBB32_9
LBB32_5:
	ldur	x1, [x22, #-32]
	cbz	x1, LBB32_7
	ldur	x0, [x22, #-24]
	mov	w2, #1
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB32_7:
	ldur	x1, [x22, #-8]
	cbz	x1, LBB32_4
	ldr	x0, [x22]
	mov	w2, #1
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
	b	LBB32_4
LBB32_9:
	cbz	x20, LBB32_11
	ldr	x0, [x19, #8]
	add	x8, x20, x20, lsl #3
	lsl	x1, x8, #3
	mov	w2, #8
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x24, x23, [sp, #16]
	ldp	x26, x25, [sp], #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	b	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB32_11:
	.cfi_restore_state
	.cfi_remember_state
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x24, x23, [sp, #16]
	ldp	x26, x25, [sp], #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	ret
LBB32_12:
	.cfi_restore_state
	mov	w10, #72
	mul	x8, x8, x10
	msub	x8, x9, x10, x8
	add	x8, x8, x23
	add	x26, x8, #32
	b	LBB32_14
LBB32_13:
	add	x26, x26, #72
	subs	x25, x25, #1
	b.eq	LBB32_2
LBB32_14:
	ldur	x1, [x26, #-32]
	cbz	x1, LBB32_16
	ldur	x0, [x26, #-24]
	mov	w2, #1
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB32_16:
	ldur	x1, [x26, #-8]
	cbz	x1, LBB32_13
	ldr	x0, [x26]
	mov	w2, #1
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
	b	LBB32_13
	.cfi_endproc

	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtNtNtCs6KVRSXc8uZF_5alloc11collections5btree3map8BTreeMapyNtNtCs5joLtdXDRmI_12wasm_vm_core8dispatch8NomStateEECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #112
	.cfi_def_cfa_offset 112
	stp	x29, x30, [sp, #96]
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x9, [x0]
	cbz	x9, LBB33_2
	ldp	x10, x8, [x0, #8]
	stp	xzr, x9, [sp, #8]
	str	x10, [sp, #24]
	stp	xzr, x9, [sp, #40]
	str	x10, [sp, #56]
	mov	w9, #1
	b	LBB33_3
LBB33_2:
	mov	x8, #0
LBB33_3:
	str	x9, [sp]
	str	x9, [sp, #32]
	str	x8, [sp, #64]
LBB33_4:
	sub	x0, x29, #24
	mov	x1, sp
	bl	__RNvMsz_NtNtNtCs6KVRSXc8uZF_5alloc11collections5btree3mapINtB5_8IntoIteryNtNtCs5joLtdXDRmI_12wasm_vm_core8dispatch8NomStateE10dying_nextCsj7lyy62zRs3_24retirement_capture_probe
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB33_4
	.cfi_def_cfa wsp, 112
	ldp	x29, x30, [sp, #96]
	add	sp, sp, #112
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtNtNtCs6KVRSXc8uZF_5alloc11collections5btree3map8BTreeMapymEECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #112
	.cfi_def_cfa_offset 112
	stp	x29, x30, [sp, #96]
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x9, [x0]
	cbz	x9, LBB34_2
	ldp	x10, x8, [x0, #8]
	stp	xzr, x9, [sp, #8]
	str	x10, [sp, #24]
	stp	xzr, x9, [sp, #40]
	str	x10, [sp, #56]
	mov	w9, #1
	b	LBB34_3
LBB34_2:
	mov	x8, #0
LBB34_3:
	str	x9, [sp]
	str	x9, [sp, #32]
	str	x8, [sp, #64]
LBB34_4:
	sub	x0, x29, #24
	mov	x1, sp
	bl	__RNvMsz_NtNtNtCs6KVRSXc8uZF_5alloc11collections5btree3mapINtB5_8IntoIterymE10dying_nextCsj7lyy62zRs3_24retirement_capture_probe
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB34_4
	.cfi_def_cfa wsp, 112
	ldp	x29, x30, [sp, #96]
	add	sp, sp, #112
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtCs5joLtdXDRmI_12wasm_vm_core7MachineECsj7lyy62zRs3_24retirement_capture_probe:
Lfunc_begin8:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception8
	stp	x22, x21, [sp, #-48]!
	.cfi_def_cfa_offset 48
	stp	x20, x19, [sp, #16]
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_remember_state
	mov	x19, x0
	ldr	x8, [x0, #24]
	cbz	x8, LBB35_2
	ldr	x0, [x19, #32]
	lsl	x1, x8, #4
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB35_2:
	mov	w8, #5416
Ltmp61:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCs5joLtdXDRmI_12wasm_vm_core4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
Ltmp62:
	ldr	x8, [x19, #6776]
	cbz	x8, LBB35_6
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_6
Ltmp66:
	mov	w8, #6776
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev5clint10ClintStateEE9drop_slowB1k_
Ltmp67:
LBB35_6:
	ldr	x21, [x19, #6800]
	cbz	x21, LBB35_11
	ldr	x20, [x19, #6808]
	ldr	x8, [x20]
	cbz	x8, LBB35_9
Ltmp71:
	mov	x0, x21
	blr	x8
Ltmp72:
LBB35_9:
	ldr	x1, [x20, #8]
	cbz	x1, LBB35_11
	ldr	x2, [x20, #16]
	mov	x0, x21
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB35_11:
	ldr	x8, [x19, #6816]
	cbz	x8, LBB35_14
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_14
Ltmp76:
	mov	w8, #6816
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev4plic9PlicStateEE9drop_slowB1k_
Ltmp77:
LBB35_14:
Ltmp81:
	add	x0, x19, #3408
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCs5joLtdXDRmI_12wasm_vm_core3sbi8SbiStateECsj7lyy62zRs3_24retirement_capture_probe
Ltmp82:
	ldr	x8, [x19, #6824]
	cbz	x8, LBB35_20
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_18
Ltmp86:
	mov	w8, #6824
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev9uart165509Uart16550EE9drop_slowB1k_
Ltmp87:
LBB35_18:
	ldr	x8, [x19, #6832]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_20
Ltmp92:
	mov	w8, #6832
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev4plic9PlicStateEE9drop_slowB1k_
Ltmp93:
LBB35_20:
	ldr	x8, [x19, #6848]
	cbz	x8, LBB35_25
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_23
Ltmp97:
	mov	w8, #6848
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev3rtc11GoldfishRtcEE9drop_slowB1k_
Ltmp98:
LBB35_23:
	ldr	x8, [x19, #6856]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_25
Ltmp103:
	mov	w8, #6856
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev4plic9PlicStateEE9drop_slowB1k_
Ltmp104:
LBB35_25:
	ldr	x1, [x19, #3560]
	cmp	x1, #1
	b.lt	LBB35_27
	ldr	x0, [x19, #3568]
	mov	w2, #1
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB35_27:
	ldr	x8, [x19, #5616]
	cbz	x8, LBB35_29
	ldr	x0, [x19, #5624]
	lsl	x1, x8, #4
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB35_29:
	ldr	x8, [x19, #6872]
	cbz	x8, LBB35_32
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_32
Ltmp108:
	mov	w8, #6872
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcDNtNtNtCs5joLtdXDRmI_12wasm_vm_core4prof5clock9HostTimerEL_E9drop_slowBK_
Ltmp109:
LBB35_32:
	ldr	x8, [x19, #6896]
	cbz	x8, LBB35_35
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_35
Ltmp113:
	mov	w8, #6896
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellINtNtBI_6option6OptionNtCs5joLtdXDRmI_12wasm_vm_core10ExitReasonEEE9drop_slowB1C_
Ltmp114:
LBB35_35:
	mov	w8, #6192
Ltmp118:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtCs6KVRSXc8uZF_5alloc3vec3VecTINtNtBG_2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmio10VirtioMmioEENtNtB1O_4plic7IrqLineEEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp119:
	ldr	x8, [x19, #4392]
	cmp	x8, #2
	b.eq	LBB35_39
	ldr	x8, [x19, #4472]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_39
Ltmp123:
	mov	w8, #4472
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3gpu8GpuStateEE9drop_slowB1m_
Ltmp124:
LBB35_39:
	ldr	x8, [x19, #5328]
	cmp	x8, #2
	b.eq	LBB35_42
	mov	w8, #5320
	ldr	x9, [x19, x8]
	ldr	x10, [x9]
	subs	x10, x10, #1
	str	x10, [x9]
	b.ne	LBB35_42
Ltmp128:
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3blk8BlkStateEE9drop_slowB1m_
Ltmp129:
LBB35_42:
	mov	w8, #6216
Ltmp133:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtCs6KVRSXc8uZF_5alloc3vec3VecTINtNtBG_2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3blk8BlkStateEEINtNtB4_6option6OptionNtNtB1M_5queue9VirtqueueEjEEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp134:
	ldr	x8, [x19, #4488]
	cmp	x8, #2
	b.eq	LBB35_46
	ldr	x8, [x19, #4528]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_46
Ltmp138:
	mov	w8, #4528
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3net8NetStateEE9drop_slowB1m_
Ltmp139:
LBB35_46:
	ldr	x8, [x19, #6904]
	cbz	x8, LBB35_49
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_49
Ltmp143:
	mov	w8, #6904
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellINtNtB7_5boxed3BoxDNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3net10NetBackendEL_EEE9drop_slowB1F_
Ltmp144:
LBB35_49:
	ldr	x8, [x19, #5376]
	cmp	x8, #2
	b.eq	LBB35_52
	mov	w8, #5368
	ldr	x9, [x19, x8]
	ldr	x10, [x9]
	subs	x10, x10, #1
	str	x10, [x9]
	b.ne	LBB35_52
Ltmp148:
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3rng8RngStateEE9drop_slowB1m_
Ltmp149:
LBB35_52:
	ldr	x8, [x19, #4576]
	cmp	x8, #2
	b.eq	LBB35_55
	ldr	x8, [x19, #4616]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_55
Ltmp153:
	mov	w8, #4616
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio5input10InputStateEE9drop_slowB1m_
Ltmp154:
LBB35_55:
	ldr	x8, [x19, #6912]
	cbz	x8, LBB35_58
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_58
Ltmp158:
	mov	w8, #6912
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio5input8keyboard16KeyboardLedStateEE9drop_slowB1o_
Ltmp159:
LBB35_58:
	ldr	x8, [x19, #4664]
	cmp	x8, #2
	b.eq	LBB35_61
	ldr	x8, [x19, #4704]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_61
Ltmp163:
	mov	w8, #4704
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio5input10InputStateEE9drop_slowB1m_
Ltmp164:
LBB35_61:
	ldr	x8, [x19, #4752]
	cmp	x8, #2
	b.eq	LBB35_64
	ldr	x8, [x19, #4792]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_64
Ltmp168:
	mov	w8, #4792
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio5input10InputStateEE9drop_slowB1m_
Ltmp169:
LBB35_64:
	mov	w8, #4840
Ltmp173:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTjINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3snd8SndStateEEIBC_NtNtB1T_5queue9VirtqueueEB2P_B2P_B2P_IB10_DNtB1R_10AudioClockEL_EINtNtB14_5boxed3BoxDNtB1R_9AudioSinkEL_EIB3X_DNtB1R_18AudioCaptureSourceEL_EEEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp174:
	ldr	x8, [x19, #5064]
	cmp	x8, #2
	b.eq	LBB35_68
	ldr	x8, [x19, #5304]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_68
Ltmp178:
	mov	w8, #5304
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio7console12ConsoleStateEE9drop_slowB1m_
Ltmp179:
LBB35_68:
	ldr	x8, [x19, #6752]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_70
Ltmp183:
	mov	w8, #6752
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtCs5joLtdXDRmI_12wasm_vm_core15desktop_restore23DesktopRestoreHostStateEE9drop_slowB1i_
Ltmp184:
LBB35_70:
	mov	w8, #6240
Ltmp188:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCs5joLtdXDRmI_12wasm_vm_core8dispatch10BlockCacheECsj7lyy62zRs3_24retirement_capture_probe
Ltmp189:
	mov	w8, #6328
Ltmp193:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCs5joLtdXDRmI_12wasm_vm_core8dispatch14BlockDiscoveryECsj7lyy62zRs3_24retirement_capture_probe
Ltmp194:
	ldr	x21, [x19, #7016]
	cbz	x21, LBB35_77
	ldr	x20, [x19, #7024]
	ldr	x8, [x20]
	cbz	x8, LBB35_75
Ltmp199:
	mov	x0, x21
	blr	x8
Ltmp200:
LBB35_75:
	ldr	x1, [x20, #8]
	cbz	x1, LBB35_77
	ldr	x2, [x20, #16]
	mov	x0, x21
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB35_77:
	mov	w8, #6568
	add	x0, x19, x8
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	ldp	x20, x19, [sp, #16]
	ldp	x22, x21, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	b	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCs5joLtdXDRmI_12wasm_vm_core13compile_queue12CompileQueueECsj7lyy62zRs3_24retirement_capture_probe
LBB35_78:
	.cfi_restore_state
Ltmp180:
	mov	x20, x0
	b	LBB35_109
LBB35_79:
Ltmp170:
	mov	x20, x0
	b	LBB35_153
LBB35_80:
Ltmp165:
	mov	x20, x0
	b	LBB35_152
LBB35_81:
Ltmp155:
	mov	x20, x0
	b	LBB35_148
LBB35_82:
Ltmp150:
	mov	x20, x0
	b	LBB35_147
LBB35_83:
Ltmp140:
	mov	x20, x0
	b	LBB35_143
LBB35_84:
Ltmp130:
	mov	x20, x0
	b	LBB35_141
LBB35_85:
Ltmp125:
	mov	x20, x0
	b	LBB35_140
LBB35_86:
Ltmp160:
	mov	x20, x0
	b	LBB35_151
LBB35_87:
Ltmp145:
	mov	x20, x0
	b	LBB35_146
LBB35_88:
Ltmp115:
	mov	x20, x0
	b	LBB35_138
LBB35_89:
Ltmp110:
	mov	x20, x0
	b	LBB35_135
LBB35_90:
Ltmp105:
	mov	x20, x0
	b	LBB35_128
LBB35_91:
Ltmp99:
	mov	x20, x0
	ldr	x8, [x19, #6856]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_128
Ltmp100:
	mov	w8, #6856
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev4plic9PlicStateEE9drop_slowB1k_
Ltmp101:
	b	LBB35_128
LBB35_93:
Ltmp102:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup
LBB35_94:
Ltmp94:
	mov	x20, x0
	b	LBB35_127
LBB35_95:
Ltmp88:
	mov	x20, x0
	ldr	x8, [x19, #6832]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_127
Ltmp89:
	mov	w8, #6832
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev4plic9PlicStateEE9drop_slowB1k_
Ltmp90:
	b	LBB35_127
LBB35_97:
Ltmp91:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup
LBB35_98:
Ltmp78:
	mov	x20, x0
	b	LBB35_125
LBB35_99:
Ltmp68:
	mov	x20, x0
	b	LBB35_121
LBB35_100:
Ltmp185:
	mov	x20, x0
	b	LBB35_111
LBB35_101:
Ltmp201:
	mov	x9, x20
	mov	x20, x0
	ldr	x1, [x9, #8]
	cbz	x1, LBB35_114
	ldr	x2, [x9, #16]
	mov	x0, x21
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
	mov	w8, #6568
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCs5joLtdXDRmI_12wasm_vm_core13compile_queue12CompileQueueECsj7lyy62zRs3_24retirement_capture_probe
	mov	x0, x20
	bl	__Unwind_Resume
LBB35_103:
Ltmp73:
	mov	x9, x20
	mov	x20, x0
	ldr	x1, [x9, #8]
	cbz	x1, LBB35_122
	ldr	x2, [x9, #16]
	mov	x0, x21
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
	b	LBB35_122
LBB35_105:
Ltmp195:
	mov	x20, x0
	b	LBB35_113
LBB35_106:
Ltmp190:
	mov	x20, x0
	b	LBB35_112
LBB35_107:
Ltmp175:
	mov	x20, x0
LBB35_108:
	mov	w8, #5064
Ltmp176:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionNtCs5joLtdXDRmI_12wasm_vm_core20VirtioConsoleServiceEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp177:
LBB35_109:
	ldr	x8, [x19, #6752]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_111
Ltmp181:
	mov	w8, #6752
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtCs5joLtdXDRmI_12wasm_vm_core15desktop_restore23DesktopRestoreHostStateEE9drop_slowB1i_
Ltmp182:
LBB35_111:
	mov	w8, #6240
Ltmp186:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCs5joLtdXDRmI_12wasm_vm_core8dispatch10BlockCacheECsj7lyy62zRs3_24retirement_capture_probe
Ltmp187:
LBB35_112:
	mov	w8, #6328
Ltmp191:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCs5joLtdXDRmI_12wasm_vm_core8dispatch14BlockDiscoveryECsj7lyy62zRs3_24retirement_capture_probe
Ltmp192:
LBB35_113:
	ldr	x0, [x19, #7016]
	ldr	x1, [x19, #7024]
Ltmp196:
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCs6KVRSXc8uZF_5alloc5boxed3BoxDNtNtCs5joLtdXDRmI_12wasm_vm_core3jit21CompiledBlockExecutorEL_EEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp197:
LBB35_114:
	mov	w8, #6568
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCs5joLtdXDRmI_12wasm_vm_core13compile_queue12CompileQueueECsj7lyy62zRs3_24retirement_capture_probe
	mov	x0, x20
	bl	__Unwind_Resume
LBB35_115:
Ltmp135:
	mov	x20, x0
	b	LBB35_142
LBB35_116:
Ltmp120:
	mov	x20, x0
	b	LBB35_139
LBB35_117:
Ltmp83:
	mov	x20, x0
	b	LBB35_126
LBB35_118:
Ltmp63:
	mov	x20, x0
	ldr	x8, [x19, #6776]
	cbz	x8, LBB35_121
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_121
Ltmp64:
	mov	w8, #6776
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev5clint10ClintStateEE9drop_slowB1k_
Ltmp65:
LBB35_121:
	ldr	x0, [x19, #6800]
	ldr	x1, [x19, #6808]
Ltmp69:
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCs6KVRSXc8uZF_5alloc5boxed3BoxDNtNtCs5joLtdXDRmI_12wasm_vm_core3jit21CompiledBlockExecutorEL_EEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp70:
LBB35_122:
	ldr	x8, [x19, #6816]
	cbz	x8, LBB35_125
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_125
Ltmp74:
	mov	w8, #6816
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev4plic9PlicStateEE9drop_slowB1k_
Ltmp75:
LBB35_125:
Ltmp79:
	add	x0, x19, #3408
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCs5joLtdXDRmI_12wasm_vm_core3sbi8SbiStateECsj7lyy62zRs3_24retirement_capture_probe
Ltmp80:
LBB35_126:
	mov	w8, #6824
Ltmp84:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev9uart165509Uart16550EENtNtB1S_4plic7IrqLineEEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp85:
LBB35_127:
	mov	w8, #6848
Ltmp95:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev3rtc11GoldfishRtcEENtNtB1S_4plic7IrqLineEEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp96:
LBB35_128:
	ldr	x1, [x19, #3560]
	cmp	x1, #1
	b.ge	LBB35_131
	ldr	x8, [x19, #5616]
	cbnz	x8, LBB35_132
LBB35_130:
	ldr	x8, [x19, #6872]
	cbnz	x8, LBB35_133
	b	LBB35_135
LBB35_131:
	ldr	x0, [x19, #3568]
	mov	w2, #1
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
	ldr	x8, [x19, #5616]
	cbz	x8, LBB35_130
LBB35_132:
	ldr	x0, [x19, #5624]
	lsl	x1, x8, #4
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
	ldr	x8, [x19, #6872]
	cbz	x8, LBB35_135
LBB35_133:
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_135
Ltmp106:
	mov	w8, #6872
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcDNtNtNtCs5joLtdXDRmI_12wasm_vm_core4prof5clock9HostTimerEL_E9drop_slowBK_
Ltmp107:
LBB35_135:
	ldr	x8, [x19, #6896]
	cbz	x8, LBB35_138
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_138
Ltmp111:
	mov	w8, #6896
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellINtNtBI_6option6OptionNtCs5joLtdXDRmI_12wasm_vm_core10ExitReasonEEE9drop_slowB1C_
Ltmp112:
LBB35_138:
	mov	w8, #6192
Ltmp116:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtCs6KVRSXc8uZF_5alloc3vec3VecTINtNtBG_2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmio10VirtioMmioEENtNtB1O_4plic7IrqLineEEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp117:
LBB35_139:
	mov	w8, #4392
Ltmp121:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3gpu8GpuStateEEIBC_NtNtB1S_5queue9VirtqueueEB2O_jEEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp122:
LBB35_140:
	mov	w8, #5320
Ltmp126:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3blk8BlkStateEEIBC_NtNtB1S_5queue9VirtqueueEEEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp127:
LBB35_141:
	mov	w8, #6216
Ltmp131:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtCs6KVRSXc8uZF_5alloc3vec3VecTINtNtBG_2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3blk8BlkStateEEINtNtB4_6option6OptionNtNtB1M_5queue9VirtqueueEjEEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp132:
LBB35_142:
	mov	w8, #4488
Ltmp136:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3net8NetStateEEIBC_NtNtB1S_5queue9VirtqueueEB2O_EEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp137:
LBB35_143:
	ldr	x8, [x19, #6904]
	cbz	x8, LBB35_146
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_146
Ltmp141:
	mov	w8, #6904
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellINtNtB7_5boxed3BoxDNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3net10NetBackendEL_EEE9drop_slowB1F_
Ltmp142:
LBB35_146:
	mov	w8, #5368
Ltmp146:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3rng8RngStateEEIBC_NtNtB1S_5queue9VirtqueueEEEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp147:
LBB35_147:
	mov	w8, #4576
Ltmp151:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio5input10InputStateEEIBC_NtNtB1S_5queue9VirtqueueEB2T_EEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp152:
LBB35_148:
	ldr	x8, [x19, #6912]
	cbz	x8, LBB35_151
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB35_151
Ltmp156:
	mov	w8, #6912
	add	x0, x19, x8
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio5input8keyboard16KeyboardLedStateEE9drop_slowB1o_
Ltmp157:
LBB35_151:
	mov	w8, #4664
Ltmp161:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio5input10InputStateEEIBC_NtNtB1S_5queue9VirtqueueEB2T_EEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp162:
LBB35_152:
	mov	w8, #4752
Ltmp166:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio5input10InputStateEEIBC_NtNtB1S_5queue9VirtqueueEB2T_EEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp167:
LBB35_153:
	mov	w8, #4840
Ltmp171:
	add	x0, x19, x8
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtB4_6option6OptionTjINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3snd8SndStateEEIBC_NtNtB1T_5queue9VirtqueueEB2P_B2P_B2P_IB10_DNtB1R_10AudioClockEL_EINtNtB14_5boxed3BoxDNtB1R_9AudioSinkEL_EIB3X_DNtB1R_18AudioCaptureSourceEL_EEEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp172:
	b	LBB35_108
LBB35_154:
Ltmp198:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup
Lfunc_end8:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table35:
Lexception8:
	.byte	255
	.byte	155
	.uleb128 Lttbase6-Lttbaseref6
Lttbaseref6:
	.byte	1
	.uleb128 Lcst_end8-Lcst_begin8
Lcst_begin8:
	.uleb128 Ltmp61-Lfunc_begin8
	.uleb128 Ltmp62-Ltmp61
	.uleb128 Ltmp63-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp66-Lfunc_begin8
	.uleb128 Ltmp67-Ltmp66
	.uleb128 Ltmp68-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp71-Lfunc_begin8
	.uleb128 Ltmp72-Ltmp71
	.uleb128 Ltmp73-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp76-Lfunc_begin8
	.uleb128 Ltmp77-Ltmp76
	.uleb128 Ltmp78-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp81-Lfunc_begin8
	.uleb128 Ltmp82-Ltmp81
	.uleb128 Ltmp83-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp86-Lfunc_begin8
	.uleb128 Ltmp87-Ltmp86
	.uleb128 Ltmp88-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp92-Lfunc_begin8
	.uleb128 Ltmp93-Ltmp92
	.uleb128 Ltmp94-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp97-Lfunc_begin8
	.uleb128 Ltmp98-Ltmp97
	.uleb128 Ltmp99-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp103-Lfunc_begin8
	.uleb128 Ltmp104-Ltmp103
	.uleb128 Ltmp105-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp108-Lfunc_begin8
	.uleb128 Ltmp109-Ltmp108
	.uleb128 Ltmp110-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp113-Lfunc_begin8
	.uleb128 Ltmp114-Ltmp113
	.uleb128 Ltmp115-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp118-Lfunc_begin8
	.uleb128 Ltmp119-Ltmp118
	.uleb128 Ltmp120-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp123-Lfunc_begin8
	.uleb128 Ltmp124-Ltmp123
	.uleb128 Ltmp125-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp128-Lfunc_begin8
	.uleb128 Ltmp129-Ltmp128
	.uleb128 Ltmp130-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp133-Lfunc_begin8
	.uleb128 Ltmp134-Ltmp133
	.uleb128 Ltmp135-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp138-Lfunc_begin8
	.uleb128 Ltmp139-Ltmp138
	.uleb128 Ltmp140-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp143-Lfunc_begin8
	.uleb128 Ltmp144-Ltmp143
	.uleb128 Ltmp145-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp148-Lfunc_begin8
	.uleb128 Ltmp149-Ltmp148
	.uleb128 Ltmp150-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp153-Lfunc_begin8
	.uleb128 Ltmp154-Ltmp153
	.uleb128 Ltmp155-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp158-Lfunc_begin8
	.uleb128 Ltmp159-Ltmp158
	.uleb128 Ltmp160-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp163-Lfunc_begin8
	.uleb128 Ltmp164-Ltmp163
	.uleb128 Ltmp165-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp168-Lfunc_begin8
	.uleb128 Ltmp169-Ltmp168
	.uleb128 Ltmp170-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp173-Lfunc_begin8
	.uleb128 Ltmp174-Ltmp173
	.uleb128 Ltmp175-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp178-Lfunc_begin8
	.uleb128 Ltmp179-Ltmp178
	.uleb128 Ltmp180-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp183-Lfunc_begin8
	.uleb128 Ltmp184-Ltmp183
	.uleb128 Ltmp185-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp188-Lfunc_begin8
	.uleb128 Ltmp189-Ltmp188
	.uleb128 Ltmp190-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp193-Lfunc_begin8
	.uleb128 Ltmp194-Ltmp193
	.uleb128 Ltmp195-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp199-Lfunc_begin8
	.uleb128 Ltmp200-Ltmp199
	.uleb128 Ltmp201-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp100-Lfunc_begin8
	.uleb128 Ltmp101-Ltmp100
	.uleb128 Ltmp102-Lfunc_begin8
	.byte	1
	.uleb128 Ltmp89-Lfunc_begin8
	.uleb128 Ltmp90-Ltmp89
	.uleb128 Ltmp91-Lfunc_begin8
	.byte	1
	.uleb128 Ltmp90-Lfunc_begin8
	.uleb128 Ltmp176-Ltmp90
	.byte	0
	.byte	0
	.uleb128 Ltmp176-Lfunc_begin8
	.uleb128 Ltmp197-Ltmp176
	.uleb128 Ltmp198-Lfunc_begin8
	.byte	1
	.uleb128 Ltmp197-Lfunc_begin8
	.uleb128 Ltmp64-Ltmp197
	.byte	0
	.byte	0
	.uleb128 Ltmp64-Lfunc_begin8
	.uleb128 Ltmp172-Ltmp64
	.uleb128 Ltmp198-Lfunc_begin8
	.byte	1
Lcst_end8:
	.byte	127
	.byte	0
	.p2align	2, 0x0
Lttbase6:
	.byte	0
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCs5joLtdXDRmI_12wasm_vm_core13compile_queue12CompileQueueECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	stp	x22, x21, [sp, #-48]!
	.cfi_def_cfa_offset 48
	stp	x20, x19, [sp, #16]
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_remember_state
	mov	x19, x0
	ldp	x20, x21, [x0, #8]
	cbz	x21, LBB36_7
	add	x22, x20, #32
	b	LBB36_3
LBB36_2:
	add	x22, x22, #80
	subs	x21, x21, #1
	b.eq	LBB36_7
LBB36_3:
	ldur	x1, [x22, #-32]
	cbz	x1, LBB36_5
	ldur	x0, [x22, #-24]
	mov	w2, #1
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB36_5:
	ldur	x1, [x22, #-8]
	cbz	x1, LBB36_2
	ldr	x0, [x22]
	mov	w2, #1
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
	b	LBB36_2
LBB36_7:
	ldr	x8, [x19]
	cbz	x8, LBB36_9
	add	x8, x8, x8, lsl #2
	lsl	x1, x8, #4
	mov	x0, x20
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB36_9:
	ldr	x8, [x19, #24]
	cbz	x8, LBB36_11
	ldr	x0, [x19, #32]
	lsl	x1, x8, #3
	mov	w2, #8
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	ldp	x20, x19, [sp, #16]
	ldp	x22, x21, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	b	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB36_11:
	.cfi_restore_state
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	ldp	x20, x19, [sp, #16]
	ldp	x22, x21, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	ret
	.cfi_endproc

	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCs5joLtdXDRmI_12wasm_vm_core3sbi8SbiStateECsj7lyy62zRs3_24retirement_capture_probe:
Lfunc_begin9:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception9
	stp	x22, x21, [sp, #-48]!
	.cfi_def_cfa_offset 48
	stp	x20, x19, [sp, #16]
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_remember_state
	mov	x19, x0
	ldr	x20, [x0, #48]
	cbz	x20, LBB37_5
	ldr	x21, [x19, #56]
	ldr	x8, [x21]
	cbz	x8, LBB37_3
Ltmp202:
	mov	x0, x20
	blr	x8
Ltmp203:
LBB37_3:
	ldr	x1, [x21, #8]
	cbz	x1, LBB37_5
	ldr	x2, [x21, #16]
	mov	x0, x20
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB37_5:
	ldr	x1, [x19, #16]
	cbz	x1, LBB37_7
	ldr	x0, [x19, #24]
	mov	w2, #1
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	ldp	x20, x19, [sp, #16]
	ldp	x22, x21, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	b	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB37_7:
	.cfi_restore_state
	.cfi_remember_state
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	ldp	x20, x19, [sp, #16]
	ldp	x22, x21, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	ret
LBB37_8:
	.cfi_restore_state
Ltmp204:
	mov	x9, x21
	mov	x21, x0
	ldr	x1, [x9, #8]
	cbnz	x1, LBB37_11
	ldr	x1, [x19, #16]
	cbnz	x1, LBB37_12
LBB37_10:
	mov	x0, x21
	bl	__Unwind_Resume
LBB37_11:
	ldr	x2, [x9, #16]
	mov	x0, x20
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
	ldr	x1, [x19, #16]
	cbz	x1, LBB37_10
LBB37_12:
	ldr	x0, [x19, #24]
	mov	w2, #1
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
	mov	x0, x21
	bl	__Unwind_Resume
Lfunc_end9:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table37:
Lexception9:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end9-Lcst_begin9
Lcst_begin9:
	.uleb128 Ltmp202-Lfunc_begin9
	.uleb128 Ltmp203-Ltmp202
	.uleb128 Ltmp204-Lfunc_begin9
	.byte	0
	.uleb128 Ltmp203-Lfunc_begin9
	.uleb128 Lfunc_end9-Ltmp203
	.byte	0
	.byte	0
Lcst_end9:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCs5joLtdXDRmI_12wasm_vm_core4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
Lfunc_begin10:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception10
	stp	x20, x19, [sp, #-32]!
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_remember_state
	mov	x19, x0
	ldr	x1, [x0]
	cbz	x1, LBB38_2
	ldr	x0, [x19, #8]
	mov	w2, #1
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB38_2:
Ltmp205:
	add	x0, x19, #32
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtCs6KVRSXc8uZF_5alloc3vec3VecNtNtCs5joLtdXDRmI_12wasm_vm_core4mmio6WindowEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp206:
	mov	x0, x19
	ldr	x8, [x0, #80]!
	cbz	x8, LBB38_6
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB38_6
Ltmp211:
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcDNtNtNtCs5joLtdXDRmI_12wasm_vm_core4prof5clock9HostTimerEL_E9drop_slowBK_
Ltmp212:
LBB38_6:
	ldr	x8, [x19, #56]
	cbz	x8, LBB38_8
	ldr	x0, [x19, #64]
	lsl	x1, x8, #3
	mov	w2, #8
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	b	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB38_8:
	.cfi_restore_state
	.cfi_remember_state
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
LBB38_9:
	.cfi_restore_state
Ltmp213:
	mov	x20, x0
	b	LBB38_13
LBB38_10:
Ltmp207:
	mov	x20, x0
	mov	x0, x19
	ldr	x8, [x0, #80]!
	cbz	x8, LBB38_13
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB38_13
Ltmp208:
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcDNtNtNtCs5joLtdXDRmI_12wasm_vm_core4prof5clock9HostTimerEL_E9drop_slowBK_
Ltmp209:
LBB38_13:
	ldr	x8, [x19, #56]
	cbz	x8, LBB38_15
	ldr	x0, [x19, #64]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB38_15:
	mov	x0, x20
	bl	__Unwind_Resume
LBB38_16:
Ltmp210:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup
Lfunc_end10:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table38:
Lexception10:
	.byte	255
	.byte	155
	.uleb128 Lttbase7-Lttbaseref7
Lttbaseref7:
	.byte	1
	.uleb128 Lcst_end10-Lcst_begin10
Lcst_begin10:
	.uleb128 Ltmp205-Lfunc_begin10
	.uleb128 Ltmp206-Ltmp205
	.uleb128 Ltmp207-Lfunc_begin10
	.byte	0
	.uleb128 Ltmp211-Lfunc_begin10
	.uleb128 Ltmp212-Ltmp211
	.uleb128 Ltmp213-Lfunc_begin10
	.byte	0
	.uleb128 Ltmp208-Lfunc_begin10
	.uleb128 Ltmp209-Ltmp208
	.uleb128 Ltmp210-Lfunc_begin10
	.byte	1
	.uleb128 Ltmp209-Lfunc_begin10
	.uleb128 Lfunc_end10-Ltmp209
	.byte	0
	.byte	0
Lcst_end10:
	.byte	127
	.byte	0
	.p2align	2, 0x0
Lttbase7:
	.byte	0
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCs5joLtdXDRmI_12wasm_vm_core8dispatch10BlockCacheECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	stp	x22, x21, [sp, #96]
	stp	x20, x19, [sp, #112]
	stp	x29, x30, [sp, #128]
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldp	x20, x21, [x0, #8]
	cbz	x21, LBB39_5
	add	x22, x20, #8
	b	LBB39_3
LBB39_2:
	add	x22, x22, #56
	subs	x21, x21, #1
	b.eq	LBB39_5
LBB39_3:
	ldur	x8, [x22, #-8]
	cmp	x8, #1
	b.lt	LBB39_2
	ldr	x0, [x22]
	add	x8, x8, x8, lsl #1
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
	b	LBB39_2
LBB39_5:
	ldr	x8, [x19]
	cbz	x8, LBB39_7
	lsl	x9, x8, #6
	sub	x1, x9, x8, lsl #3
	mov	x0, x20
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB39_7:
	ldr	x9, [x19, #40]
	cbz	x9, LBB39_9
	ldp	x10, x8, [x19, #48]
	stp	xzr, x9, [sp, #8]
	str	x10, [sp, #24]
	stp	xzr, x9, [sp, #40]
	str	x10, [sp, #56]
	mov	w9, #1
	b	LBB39_10
LBB39_9:
	mov	x8, #0
LBB39_10:
	str	x9, [sp]
	str	x9, [sp, #32]
	str	x8, [sp, #64]
LBB39_11:
	sub	x0, x29, #56
	mov	x1, sp
	bl	__RNvMsz_NtNtNtCs6KVRSXc8uZF_5alloc11collections5btree3mapINtB5_8IntoIteryNtNtB7_7set_val9SetValZSTE10dying_nextCsj7lyy62zRs3_24retirement_capture_probe
	ldur	x8, [x29, #-56]
	cbnz	x8, LBB39_11
	.cfi_def_cfa wsp, 144
	ldp	x29, x30, [sp, #128]
	ldp	x20, x19, [sp, #112]
	ldp	x22, x21, [sp, #96]
	add	sp, sp, #144
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	ret
	.cfi_endproc

	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCs5joLtdXDRmI_12wasm_vm_core8dispatch14BlockDiscoveryECsj7lyy62zRs3_24retirement_capture_probe:
Lfunc_begin11:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception11
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	stp	x20, x19, [sp, #96]
	stp	x29, x30, [sp, #112]
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_remember_state
	mov	x19, x0
	ldr	x9, [x0, #40]
	cbz	x9, LBB40_2
	ldp	x10, x8, [x19, #48]
	stp	xzr, x9, [sp, #8]
	str	x10, [sp, #24]
	stp	xzr, x9, [sp, #40]
	str	x10, [sp, #56]
	mov	w9, #1
	b	LBB40_3
LBB40_2:
	mov	x8, #0
LBB40_3:
	str	x9, [sp]
	str	x9, [sp, #32]
	str	x8, [sp, #64]
Ltmp214:
	sub	x0, x29, #40
	mov	x1, sp
	bl	__RNvMsz_NtNtNtCs6KVRSXc8uZF_5alloc11collections5btree3mapINtB5_8IntoIterymE10dying_nextCsj7lyy62zRs3_24retirement_capture_probe
Ltmp215:
LBB40_4:
	ldur	x8, [x29, #-40]
	cbz	x8, LBB40_6
Ltmp217:
	sub	x0, x29, #40
	mov	x1, sp
	bl	__RNvMsz_NtNtNtCs6KVRSXc8uZF_5alloc11collections5btree3mapINtB5_8IntoIterymE10dying_nextCsj7lyy62zRs3_24retirement_capture_probe
Ltmp218:
	b	LBB40_4
LBB40_6:
	ldr	x9, [x19, #64]
	cbz	x9, LBB40_8
	ldp	x10, x8, [x19, #72]
	stp	xzr, x9, [sp, #8]
	str	x10, [sp, #24]
	stp	xzr, x9, [sp, #40]
	str	x10, [sp, #56]
	mov	w9, #1
	b	LBB40_9
LBB40_8:
	mov	x8, #0
LBB40_9:
	str	x9, [sp]
	str	x9, [sp, #32]
	str	x8, [sp, #64]
Ltmp222:
	sub	x0, x29, #40
	mov	x1, sp
	bl	__RNvMsz_NtNtNtCs6KVRSXc8uZF_5alloc11collections5btree3mapINtB5_8IntoIteryNtNtCs5joLtdXDRmI_12wasm_vm_core8dispatch8NomStateE10dying_nextCsj7lyy62zRs3_24retirement_capture_probe
Ltmp223:
LBB40_10:
	ldur	x8, [x29, #-40]
	cbz	x8, LBB40_12
Ltmp225:
	sub	x0, x29, #40
	mov	x1, sp
	bl	__RNvMsz_NtNtNtCs6KVRSXc8uZF_5alloc11collections5btree3mapINtB5_8IntoIteryNtNtCs5joLtdXDRmI_12wasm_vm_core8dispatch8NomStateE10dying_nextCsj7lyy62zRs3_24retirement_capture_probe
Ltmp226:
	b	LBB40_10
LBB40_12:
	ldr	x9, [x19, #88]
	cbz	x9, LBB40_14
	ldp	x10, x8, [x19, #96]
	stp	xzr, x9, [sp, #8]
	str	x10, [sp, #24]
	stp	xzr, x9, [sp, #40]
	str	x10, [sp, #56]
	mov	w9, #1
	b	LBB40_15
LBB40_14:
	mov	x8, #0
LBB40_15:
	str	x9, [sp]
	str	x9, [sp, #32]
	str	x8, [sp, #64]
Ltmp231:
	sub	x0, x29, #40
	mov	x1, sp
	bl	__RNvMsz_NtNtNtCs6KVRSXc8uZF_5alloc11collections5btree3mapINtB5_8IntoIterymE10dying_nextCsj7lyy62zRs3_24retirement_capture_probe
Ltmp232:
LBB40_16:
	ldur	x8, [x29, #-40]
	cbz	x8, LBB40_18
Ltmp234:
	sub	x0, x29, #40
	mov	x1, sp
	bl	__RNvMsz_NtNtNtCs6KVRSXc8uZF_5alloc11collections5btree3mapINtB5_8IntoIterymE10dying_nextCsj7lyy62zRs3_24retirement_capture_probe
Ltmp235:
	b	LBB40_16
LBB40_18:
	mov	x0, x19
	.cfi_def_cfa wsp, 128
	ldp	x29, x30, [sp, #112]
	ldp	x20, x19, [sp, #96]
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	b	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtNtCs6KVRSXc8uZF_5alloc11collections9vec_deque8VecDequeNtNtCs5joLtdXDRmI_12wasm_vm_core8dispatch18TranslationRequestEECsj7lyy62zRs3_24retirement_capture_probe
LBB40_19:
	.cfi_restore_state
Ltmp233:
	mov	x20, x0
	mov	x0, x19
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtNtCs6KVRSXc8uZF_5alloc11collections9vec_deque8VecDequeNtNtCs5joLtdXDRmI_12wasm_vm_core8dispatch18TranslationRequestEECsj7lyy62zRs3_24retirement_capture_probe
	mov	x0, x20
	bl	__Unwind_Resume
LBB40_20:
Ltmp224:
	b	LBB40_24
LBB40_21:
Ltmp216:
	b	LBB40_26
LBB40_22:
Ltmp236:
	mov	x20, x0
	mov	x0, x19
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtNtCs6KVRSXc8uZF_5alloc11collections9vec_deque8VecDequeNtNtCs5joLtdXDRmI_12wasm_vm_core8dispatch18TranslationRequestEECsj7lyy62zRs3_24retirement_capture_probe
	mov	x0, x20
	bl	__Unwind_Resume
LBB40_23:
Ltmp227:
LBB40_24:
	mov	x20, x0
	b	LBB40_27
LBB40_25:
Ltmp219:
LBB40_26:
	mov	x20, x0
Ltmp220:
	add	x0, x19, #64
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtNtNtCs6KVRSXc8uZF_5alloc11collections5btree3map8BTreeMapyNtNtCs5joLtdXDRmI_12wasm_vm_core8dispatch8NomStateEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp221:
LBB40_27:
Ltmp228:
	add	x0, x19, #88
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtNtNtCs6KVRSXc8uZF_5alloc11collections5btree3map8BTreeMapymEECsj7lyy62zRs3_24retirement_capture_probe
Ltmp229:
	mov	x0, x19
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtNtCs6KVRSXc8uZF_5alloc11collections9vec_deque8VecDequeNtNtCs5joLtdXDRmI_12wasm_vm_core8dispatch18TranslationRequestEECsj7lyy62zRs3_24retirement_capture_probe
	mov	x0, x20
	bl	__Unwind_Resume
LBB40_29:
Ltmp230:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup
Lfunc_end11:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table40:
Lexception11:
	.byte	255
	.byte	155
	.uleb128 Lttbase8-Lttbaseref8
Lttbaseref8:
	.byte	1
	.uleb128 Lcst_end11-Lcst_begin11
Lcst_begin11:
	.uleb128 Ltmp214-Lfunc_begin11
	.uleb128 Ltmp215-Ltmp214
	.uleb128 Ltmp216-Lfunc_begin11
	.byte	0
	.uleb128 Ltmp217-Lfunc_begin11
	.uleb128 Ltmp218-Ltmp217
	.uleb128 Ltmp219-Lfunc_begin11
	.byte	0
	.uleb128 Ltmp222-Lfunc_begin11
	.uleb128 Ltmp223-Ltmp222
	.uleb128 Ltmp224-Lfunc_begin11
	.byte	0
	.uleb128 Ltmp225-Lfunc_begin11
	.uleb128 Ltmp226-Ltmp225
	.uleb128 Ltmp227-Lfunc_begin11
	.byte	0
	.uleb128 Ltmp231-Lfunc_begin11
	.uleb128 Ltmp232-Ltmp231
	.uleb128 Ltmp233-Lfunc_begin11
	.byte	0
	.uleb128 Ltmp234-Lfunc_begin11
	.uleb128 Ltmp235-Ltmp234
	.uleb128 Ltmp236-Lfunc_begin11
	.byte	0
	.uleb128 Ltmp235-Lfunc_begin11
	.uleb128 Ltmp220-Ltmp235
	.byte	0
	.byte	0
	.uleb128 Ltmp220-Lfunc_begin11
	.uleb128 Ltmp229-Ltmp220
	.uleb128 Ltmp230-Lfunc_begin11
	.byte	1
	.uleb128 Ltmp229-Lfunc_begin11
	.uleb128 Lfunc_end11-Ltmp229
	.byte	0
	.byte	0
Lcst_end11:
	.byte	127
	.byte	0
	.p2align	2, 0x0
Lttbase8:
	.byte	0
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueTINtNtCs6KVRSXc8uZF_5alloc2rc2RcINtNtB4_4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmio10VirtioMmioEENtNtB1y_4plic7IrqLineEECsj7lyy62zRs3_24retirement_capture_probe:
Lfunc_begin12:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception12
	stp	x20, x19, [sp, #-32]!
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_remember_state
	mov	x19, x0
	ldr	x8, [x0]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB41_2
Ltmp237:
	mov	x0, x19
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmio10VirtioMmioEE9drop_slowB1m_
Ltmp238:
LBB41_2:
	ldr	x8, [x19, #8]!
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.eq	LBB41_4
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
LBB41_4:
	.cfi_restore_state
	.cfi_remember_state
	mov	x0, x19
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	b	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev4plic9PlicStateEE9drop_slowB1k_
LBB41_5:
	.cfi_restore_state
Ltmp239:
	mov	x20, x0
	ldr	x8, [x19, #8]!
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB41_7
Ltmp240:
	mov	x0, x19
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev4plic9PlicStateEE9drop_slowB1k_
Ltmp241:
LBB41_7:
	mov	x0, x20
	bl	__Unwind_Resume
LBB41_8:
Ltmp242:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup
Lfunc_end12:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table41:
Lexception12:
	.byte	255
	.byte	155
	.uleb128 Lttbase9-Lttbaseref9
Lttbaseref9:
	.byte	1
	.uleb128 Lcst_end12-Lcst_begin12
Lcst_begin12:
	.uleb128 Ltmp237-Lfunc_begin12
	.uleb128 Ltmp238-Ltmp237
	.uleb128 Ltmp239-Lfunc_begin12
	.byte	0
	.uleb128 Ltmp238-Lfunc_begin12
	.uleb128 Ltmp240-Ltmp238
	.byte	0
	.byte	0
	.uleb128 Ltmp240-Lfunc_begin12
	.uleb128 Ltmp241-Ltmp240
	.uleb128 Ltmp242-Lfunc_begin12
	.byte	1
	.uleb128 Ltmp241-Lfunc_begin12
	.uleb128 Lfunc_end12-Ltmp241
	.byte	0
	.byte	0
Lcst_end12:
	.byte	127
	.byte	0
	.p2align	2, 0x0
Lttbase9:
	.byte	0
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtNtCs7mRY9FNn263_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	blr	x0
	; InlineAsm Start
	; InlineAsm End
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.p2align	2
__RNCINvNtCs7mRY9FNn263_3std2rt10lang_startuE0Csj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0]
	bl	__RINvNtNtCs7mRY9FNn263_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsj7lyy62zRs3_24retirement_capture_probe
	mov	w0, #0
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.p2align	2
__RNSNvYNCINvNtCs7mRY9FNn263_3std2rt10lang_startuE0INtNtNtCslWxY2MhVcag_4core3ops8function6FnOnceuE9call_once6vtableCsj7lyy62zRs3_24retirement_capture_probe:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0]
	bl	__RINvNtNtCs7mRY9FNn263_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsj7lyy62zRs3_24retirement_capture_probe
	mov	w0, #0
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.private_extern	__RNvCsj7lyy62zRs3_24retirement_capture_probe4main
	.globl	__RNvCsj7lyy62zRs3_24retirement_capture_probe4main
	.p2align	2
__RNvCsj7lyy62zRs3_24retirement_capture_probe4main:
Lfunc_begin13:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception13
	stp	x28, x27, [sp, #-80]!
	.cfi_def_cfa_offset 80
	stp	x24, x23, [sp, #16]
	stp	x22, x21, [sp, #32]
	stp	x20, x19, [sp, #48]
	stp	x29, x30, [sp, #64]
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_remember_state
	sub	sp, sp, #1, lsl #12
	str	xzr, [sp]
	sub	sp, sp, #1, lsl #12
	str	xzr, [sp]
	sub	sp, sp, #2512
	str	xzr, [sp]
	add	x8, sp, #3568
	mov	w0, #65536
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3ramNtB2_3Ram3new
	ldr	x8, [sp, #3568]
	cmn	x8, #1
	b.eq	LBB45_47
	ldr	q0, [sp, #3568]
	ldr	q1, [sp, #3584]
	stp	q0, q1, [sp]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #96]
	stp	q0, q0, [sp, #128]
	str	q0, [sp, #160]
	stp	xzr, xzr, [sp, #176]
	mov	w8, #8
	stp	xzr, x8, [sp, #32]
	stp	xzr, xzr, [sp, #72]
	strb	wzr, [sp, #192]
	stp	xzr, xzr, [sp, #48]
	str	x8, [sp, #64]
Ltmp243:
	add	x8, sp, #200
	bl	__RNvMs1_NtCs5joLtdXDRmI_12wasm_vm_core4hartNtB5_4Hart3new
Ltmp244:
	mov	x8, sp
	mov	w19, #4
	movk	w19, #32768, lsl #16
	mov	w9, #19
	str	w9, [sp, #3568]
	add	x9, sp, #3568
	; InlineAsm Start
	; InlineAsm End
	ldr	w7, [sp, #3568]
	ldr	x9, [sp, #24]
	mov	w10, #-2147483648
	cmp	x9, x10
	b.hi	LBB45_4
	ldr	x10, [sp, #16]
	sub	x11, x19, x9
	cmp	x11, x10
	b.ls	LBB45_32
LBB45_4:
	ldp	x0, x1, [sp, #40]
	ldr	x9, [sp, #80]
	cbz	x9, LBB45_6
	ldr	x3, [sp, #88]
	ldr	x10, [x3, #16]
	sub	x10, x10, #1
	and	x10, x10, #0xfffffffffffffff0
	add	x9, x9, x10
	add	x2, x9, #16
	b	LBB45_7
LBB45_6:
	mov	x2, #0
LBB45_7:
Ltmp248:
	add	x4, x8, #96
	mov	w5, #-2147483648
	mov	w6, #2
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio12store_device
Ltmp249:
	and	w8, w0, #0xff
	cmp	w8, #2
	b.ne	LBB45_45
LBB45_9:
	mov	w20, #-2147483648
	str	x20, [sp, #3288]
	mov	x0, sp
	add	x1, sp, #200
	bl	_capture_hart_unit_probe
	str	x20, [sp, #3288]
	mov	x0, sp
	add	x1, sp, #200
	bl	_capture_hart_record_probe
	str	x0, [sp, #3568]
	add	x20, sp, #3568
	; InlineAsm Start
	; InlineAsm End
Ltmp253:
	add	x8, sp, #3568
	mov	w0, #65536
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine3new
Ltmp254:
	mov	w23, #5608
	mov	w22, #5472
	mov	w21, #5512
	mov	w8, #19
	stur	w8, [x29, #-80]
	sub	x8, x29, #80
	; InlineAsm Start
	; InlineAsm End
	ldur	w7, [x29, #-80]
	ldr	x8, [sp, #9008]
	mov	w9, #-2147483648
	cmp	x8, x9
	b.hi	LBB45_12
	ldr	x9, [sp, #9000]
	sub	x10, x19, x8
	cmp	x10, x9
	b.ls	LBB45_36
LBB45_12:
	ldr	x0, [sp, #9024]
	ldr	x1, [sp, #9032]
	ldr	x8, [sp, #9064]
	cbz	x8, LBB45_14
	ldr	x3, [sp, #9072]
	ldr	x9, [x3, #16]
	sub	x9, x9, #1
	and	x9, x9, #0xfffffffffffffff0
	add	x8, x8, x9
	add	x2, x8, #16
	b	LBB45_15
LBB45_14:
	mov	x2, #0
LBB45_15:
Ltmp257:
	add	x4, x20, x21
	mov	w5, #-2147483648
	mov	w6, #2
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio12store_device
Ltmp258:
	and	w8, w0, #0xff
	cmp	w8, #2
	b.ne	LBB45_44
LBB45_17:
Ltmp259:
	add	x0, sp, #3568
	mov	w1, #0
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine15set_block_cache
Ltmp260:
	mov	w24, #-2147483648
	str	x24, [sp, #6656]
	add	x0, sp, #3568
	mov	w1, #1
	bl	_capture_machine_unit_probe
	str	x24, [sp, #6656]
	add	x0, sp, #3568
	mov	w1, #1
	bl	_capture_machine_record_probe
	stur	x0, [x29, #-80]
	sub	x8, x29, #80
	; InlineAsm Start
	; InlineAsm End
Ltmp261:
	add	x0, sp, #3568
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtCs5joLtdXDRmI_12wasm_vm_core7MachineECsj7lyy62zRs3_24retirement_capture_probe
Ltmp262:
Ltmp263:
	add	x8, sp, #3568
	mov	w0, #65536
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine3new
Ltmp264:
	mov	w8, #19
	stur	w8, [x29, #-80]
	sub	x8, x29, #80
	; InlineAsm Start
	; InlineAsm End
	ldur	w7, [x29, #-80]
	ldr	x8, [sp, #9008]
	mov	w9, #-2147483648
	cmp	x8, x9
	b.hi	LBB45_22
	ldr	x9, [sp, #9000]
	sub	x10, x19, x8
	cmp	x10, x9
	b.ls	LBB45_40
LBB45_22:
	ldr	x0, [sp, #9024]
	ldr	x1, [sp, #9032]
	ldr	x8, [sp, #9064]
	cbz	x8, LBB45_24
	ldr	x3, [sp, #9072]
	ldr	x9, [x3, #16]
	sub	x9, x9, #1
	and	x9, x9, #0xfffffffffffffff0
	add	x8, x8, x9
	add	x2, x8, #16
	b	LBB45_25
LBB45_24:
	mov	x2, #0
LBB45_25:
Ltmp267:
	add	x4, x20, x21
	mov	w5, #-2147483648
	mov	w6, #2
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio12store_device
Ltmp268:
	and	w8, w0, #0xff
	cmp	w8, #2
	b.ne	LBB45_44
LBB45_27:
Ltmp272:
	add	x0, sp, #3568
	mov	w1, #1
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine15set_block_cache
Ltmp273:
	mov	w19, #-2147483648
	str	x19, [sp, #6656]
	add	x0, sp, #3568
	mov	w1, #1
	bl	_capture_machine_unit_probe
	str	x19, [sp, #6656]
	add	x0, sp, #3568
	mov	w1, #1
	bl	_capture_machine_record_probe
	stur	x0, [x29, #-80]
	sub	x8, x29, #80
	; InlineAsm Start
	; InlineAsm End
Ltmp277:
	add	x0, sp, #3568
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtCs5joLtdXDRmI_12wasm_vm_core7MachineECsj7lyy62zRs3_24retirement_capture_probe
Ltmp278:
	ldr	x8, [sp, #224]
	cbz	x8, LBB45_31
	ldr	x0, [sp, #232]
	lsl	x1, x8, #4
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB45_31:
	mov	x0, sp
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCs5joLtdXDRmI_12wasm_vm_core4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
	add	sp, sp, #2, lsl #12
	add	sp, sp, #2512
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x24, x23, [sp, #16]
	ldp	x28, x27, [sp], #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w27
	.cfi_restore w28
	ret
LBB45_32:
	.cfi_restore_state
	ldr	x10, [sp, #8]
	sub	x9, x10, x9
	mov	w10, #-2147483648
	str	w7, [x9, x10]
	ldrb	w9, [sp, #192]
	tbz	w9, #0, LBB45_9
	ldr	x20, [sp, #72]
	ldr	x9, [sp, #56]
	cmp	x20, x9
	b.ne	LBB45_35
Ltmp246:
	add	x0, x8, #56
	bl	__RNvMs4_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVecyE8grow_oneCs5joLtdXDRmI_12wasm_vm_core
Ltmp247:
LBB45_35:
	ldr	x8, [sp, #64]
	mov	w9, #524288
	str	x9, [x8, x20, lsl #3]
	add	x8, x20, #1
	str	x8, [sp, #72]
	b	LBB45_9
LBB45_36:
	ldr	x9, [sp, #8992]
	sub	x8, x9, x8
	mov	w9, #-2147483648
	str	w7, [x8, x9]
	ldrb	w8, [x20, x23]
	cmp	w8, #1
	b.ne	LBB45_17
	ldr	x24, [sp, #9056]
	ldr	x8, [sp, #9040]
	cmp	x24, x8
	b.ne	LBB45_39
Ltmp255:
	add	x0, x20, x22
	bl	__RNvMs4_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVecyE8grow_oneCs5joLtdXDRmI_12wasm_vm_core
Ltmp256:
LBB45_39:
	ldr	x8, [sp, #9048]
	mov	w9, #524288
	str	x9, [x8, x24, lsl #3]
	add	x8, x24, #1
	str	x8, [sp, #9056]
	b	LBB45_17
LBB45_40:
	ldr	x9, [sp, #8992]
	sub	x8, x9, x8
	mov	w9, #-2147483648
	str	w7, [x8, x9]
	ldrb	w8, [x20, x23]
	cmp	w8, #1
	b.ne	LBB45_27
	ldr	x19, [sp, #9056]
	ldr	x8, [sp, #9040]
	cmp	x19, x8
	b.ne	LBB45_43
Ltmp265:
	add	x0, x20, x22
	bl	__RNvMs4_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVecyE8grow_oneCs5joLtdXDRmI_12wasm_vm_core
Ltmp266:
LBB45_43:
	ldr	x8, [sp, #9048]
	mov	w9, #524288
	str	x9, [x8, x19, lsl #3]
	add	x8, x19, #1
	str	x8, [sp, #9056]
	b	LBB45_27
LBB45_44:
	sturb	w8, [x29, #-80]
Ltmp269:
Lloh52:
	adrp	x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.38@PAGE
Lloh53:
	add	x0, x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.38@PAGEOFF
Lloh54:
	adrp	x3, l_anon.9ed3183efb56324a1c787c8a9029a2a7.40@PAGE
Lloh55:
	add	x3, x3, l_anon.9ed3183efb56324a1c787c8a9029a2a7.40@PAGEOFF
Lloh56:
	adrp	x4, l_anon.9ed3183efb56324a1c787c8a9029a2a7.37@PAGE
Lloh57:
	add	x4, x4, l_anon.9ed3183efb56324a1c787c8a9029a2a7.37@PAGEOFF
	sub	x2, x29, #80
	mov	w1, #43
	bl	__RNvNtCslWxY2MhVcag_4core6result13unwrap_failed
Ltmp270:
	b	LBB45_46
LBB45_45:
	strb	w8, [sp, #3568]
Ltmp250:
Lloh58:
	adrp	x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.38@PAGE
Lloh59:
	add	x0, x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.38@PAGEOFF
Lloh60:
	adrp	x3, l_anon.9ed3183efb56324a1c787c8a9029a2a7.40@PAGE
Lloh61:
	add	x3, x3, l_anon.9ed3183efb56324a1c787c8a9029a2a7.40@PAGEOFF
Lloh62:
	adrp	x4, l_anon.9ed3183efb56324a1c787c8a9029a2a7.36@PAGE
Lloh63:
	add	x4, x4, l_anon.9ed3183efb56324a1c787c8a9029a2a7.36@PAGEOFF
	add	x2, sp, #3568
	mov	w1, #43
	bl	__RNvNtCslWxY2MhVcag_4core6result13unwrap_failed
Ltmp251:
LBB45_46:
	brk	#0x1
LBB45_47:
Lloh64:
	adrp	x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.38@PAGE
Lloh65:
	add	x0, x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.38@PAGEOFF
Lloh66:
	adrp	x3, l_anon.9ed3183efb56324a1c787c8a9029a2a7.39@PAGE
Lloh67:
	add	x3, x3, l_anon.9ed3183efb56324a1c787c8a9029a2a7.39@PAGEOFF
Lloh68:
	adrp	x4, l_anon.9ed3183efb56324a1c787c8a9029a2a7.35@PAGE
Lloh69:
	add	x4, x4, l_anon.9ed3183efb56324a1c787c8a9029a2a7.35@PAGEOFF
	sub	x2, x29, #65
	mov	w1, #43
	bl	__RNvNtCslWxY2MhVcag_4core6result13unwrap_failed
LBB45_48:
Ltmp245:
	mov	x19, x0
	b	LBB45_57
LBB45_49:
Ltmp274:
	b	LBB45_54
LBB45_50:
Ltmp279:
	b	LBB45_52
LBB45_51:
Ltmp252:
LBB45_52:
	mov	x19, x0
	b	LBB45_55
LBB45_53:
Ltmp271:
LBB45_54:
	mov	x19, x0
Ltmp275:
	add	x0, sp, #3568
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtCs5joLtdXDRmI_12wasm_vm_core7MachineECsj7lyy62zRs3_24retirement_capture_probe
Ltmp276:
LBB45_55:
	ldr	x8, [sp, #224]
	cbz	x8, LBB45_57
	ldr	x0, [sp, #232]
	lsl	x1, x8, #4
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB45_57:
Ltmp280:
	mov	x0, sp
	bl	__RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCs5joLtdXDRmI_12wasm_vm_core4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
Ltmp281:
	mov	x0, x19
	bl	__Unwind_Resume
LBB45_59:
Ltmp282:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup
	.loh AdrpAdd	Lloh56, Lloh57
	.loh AdrpAdd	Lloh54, Lloh55
	.loh AdrpAdd	Lloh52, Lloh53
	.loh AdrpAdd	Lloh62, Lloh63
	.loh AdrpAdd	Lloh60, Lloh61
	.loh AdrpAdd	Lloh58, Lloh59
	.loh AdrpAdd	Lloh68, Lloh69
	.loh AdrpAdd	Lloh66, Lloh67
	.loh AdrpAdd	Lloh64, Lloh65
Lfunc_end13:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table45:
Lexception13:
	.byte	255
	.byte	155
	.uleb128 Lttbase10-Lttbaseref10
Lttbaseref10:
	.byte	1
	.uleb128 Lcst_end13-Lcst_begin13
Lcst_begin13:
	.uleb128 Lfunc_begin13-Lfunc_begin13
	.uleb128 Ltmp243-Lfunc_begin13
	.byte	0
	.byte	0
	.uleb128 Ltmp243-Lfunc_begin13
	.uleb128 Ltmp244-Ltmp243
	.uleb128 Ltmp245-Lfunc_begin13
	.byte	0
	.uleb128 Ltmp248-Lfunc_begin13
	.uleb128 Ltmp249-Ltmp248
	.uleb128 Ltmp252-Lfunc_begin13
	.byte	0
	.uleb128 Ltmp253-Lfunc_begin13
	.uleb128 Ltmp254-Ltmp253
	.uleb128 Ltmp279-Lfunc_begin13
	.byte	0
	.uleb128 Ltmp257-Lfunc_begin13
	.uleb128 Ltmp260-Ltmp257
	.uleb128 Ltmp274-Lfunc_begin13
	.byte	0
	.uleb128 Ltmp261-Lfunc_begin13
	.uleb128 Ltmp264-Ltmp261
	.uleb128 Ltmp279-Lfunc_begin13
	.byte	0
	.uleb128 Ltmp267-Lfunc_begin13
	.uleb128 Ltmp273-Ltmp267
	.uleb128 Ltmp274-Lfunc_begin13
	.byte	0
	.uleb128 Ltmp277-Lfunc_begin13
	.uleb128 Ltmp278-Ltmp277
	.uleb128 Ltmp279-Lfunc_begin13
	.byte	0
	.uleb128 Ltmp278-Lfunc_begin13
	.uleb128 Ltmp246-Ltmp278
	.byte	0
	.byte	0
	.uleb128 Ltmp246-Lfunc_begin13
	.uleb128 Ltmp247-Ltmp246
	.uleb128 Ltmp252-Lfunc_begin13
	.byte	0
	.uleb128 Ltmp255-Lfunc_begin13
	.uleb128 Ltmp266-Ltmp255
	.uleb128 Ltmp274-Lfunc_begin13
	.byte	0
	.uleb128 Ltmp269-Lfunc_begin13
	.uleb128 Ltmp270-Ltmp269
	.uleb128 Ltmp271-Lfunc_begin13
	.byte	0
	.uleb128 Ltmp250-Lfunc_begin13
	.uleb128 Ltmp251-Ltmp250
	.uleb128 Ltmp252-Lfunc_begin13
	.byte	0
	.uleb128 Ltmp251-Lfunc_begin13
	.uleb128 Ltmp275-Ltmp251
	.byte	0
	.byte	0
	.uleb128 Ltmp275-Lfunc_begin13
	.uleb128 Ltmp281-Ltmp275
	.uleb128 Ltmp282-Lfunc_begin13
	.byte	1
	.uleb128 Ltmp281-Lfunc_begin13
	.uleb128 Lfunc_end13-Ltmp281
	.byte	0
	.byte	0
Lcst_end13:
	.byte	127
	.byte	0
	.p2align	2, 0x0
Lttbase10:
	.byte	0
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs4mret:
	.cfi_startproc
	mov	x8, #-6281
	movk	x8, #65533, lsl #16
	ldr	x9, [x0, #616]
	ubfx	x10, x9, #11, #2
	mov	w11, #3
	mov	x12, #-6281
	cmp	x10, #3
	csel	x12, x8, x12, ne
	csel	w11, wzr, w11, ne
	cmp	x10, #1
	csel	x8, x8, x12, eq
	csinc	w10, w11, wzr, ne
	mvn	w11, w9
	and	w8, w9, w8
	lsr	x9, x9, #4
	and	x9, x9, #0x8
	mov	w12, #24866
	movk	w12, #126, lsl #16
	and	x8, x8, x12
	orr	x8, x9, x8
	tst	x11, #0x6000
	mov	x9, #42949672960
	mov	x11, #42949672960
	movk	x11, #32768, lsl #48
	csel	x9, x11, x9, eq
	orr	x8, x8, x9
	orr	x8, x8, #0x80
	str	x8, [x0, #616]
	strb	w10, [x0, #709]
	ret
	.cfi_endproc

	.p2align	2
__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs4sret:
	.cfi_startproc
	ldr	x8, [x0, #616]
	ubfx	w9, w8, #8, #1
	mov	w10, #30856
	movk	w10, #124, lsl #16
	and	x10, x8, x10
	lsr	x11, x8, #4
	and	x11, x11, #0x2
	orr	x10, x10, x11
	orr	x10, x10, #0x20
	and	x8, x8, #0x1800
	and	x11, x10, #0xffffffffffffe7ff
	cmp	x8, #1, lsl #12
	csel	x8, x11, x10, eq
	mvn	w10, w8
	tst	x10, #0x6000
	mov	x10, #42949672960
	mov	x11, #42949672960
	movk	x11, #32768, lsl #48
	csel	x10, x11, x10, eq
	orr	x8, x10, x8
	str	x8, [x0, #616]
	strb	w9, [x0, #709]
	ret
	.cfi_endproc

	.p2align	2
__RNvMsz_NtNtNtCs6KVRSXc8uZF_5alloc11collections5btree3mapINtB5_8IntoIteryNtNtB7_7set_val9SetValZSTE10dying_nextCsj7lyy62zRs3_24retirement_capture_probe:
Lfunc_begin14:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception14
	stp	x26, x25, [sp, #-80]!
	.cfi_def_cfa_offset 80
	stp	x24, x23, [sp, #16]
	stp	x22, x21, [sp, #32]
	stp	x20, x19, [sp, #48]
	stp	x29, x30, [sp, #64]
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_remember_state
	mov	x19, x0
	ldr	x8, [x1, #64]
	cbz	x8, LBB48_8
	sub	x8, x8, #1
	str	x8, [x1, #64]
	ldr	x8, [x1]
	cmp	x8, #1
	b.ne	LBB48_30
	ldr	x0, [x1, #8]
	cbz	x0, LBB48_11
	ldp	x8, x20, [x1, #16]
	ldrh	w9, [x0, #98]
	cmp	x20, x9
	b.hs	LBB48_14
LBB48_4:
	mov	x22, x8
	mov	x21, x0
	cbz	x8, LBB48_18
LBB48_5:
	add	x8, x21, x20, lsl #3
	add	x9, x8, #112
	mov	x10, x22
LBB48_6:
	ldr	x8, [x9]
	add	x9, x8, #104
	subs	x10, x10, #1
	b.ne	LBB48_6
	mov	x9, #0
	b	LBB48_19
LBB48_8:
	ldp	x10, x9, [x1]
	ldp	x20, x8, [x1, #16]
	str	xzr, [x1]
	cmp	x10, #1
	b.ne	LBB48_26
	cbz	x9, LBB48_20
	mov	x21, x20
	mov	x20, x9
	ldr	x8, [x9]
	cbnz	x8, LBB48_23
	b	LBB48_25
LBB48_11:
	ldp	x0, x8, [x1, #16]
	cbz	x8, LBB48_13
LBB48_12:
	ldr	x0, [x0, #104]
	subs	x8, x8, #1
	b.ne	LBB48_12
LBB48_13:
	mov	x20, #0
	mov	x8, #0
	mov	w9, #1
	str	x9, [x1]
	ldrh	w9, [x0, #98]
	cmp	x20, x9
	b.lo	LBB48_4
LBB48_14:
	mov	x23, x1
	mov	w24, #200
	mov	w25, #104
LBB48_15:
	ldr	x21, [x0]
	cbz	x21, LBB48_28
	add	x22, x8, #1
	ldrh	w20, [x0, #96]
	cmp	x8, #0
	csel	x1, x25, x24, eq
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
	ldrh	w9, [x21, #98]
	mov	x0, x21
	mov	x8, x22
	cmp	w20, w9
	b.hs	LBB48_15
	mov	x1, x23
	cbnz	x22, LBB48_5
LBB48_18:
	add	x9, x20, #1
	mov	x8, x21
LBB48_19:
	stp	x8, xzr, [x1, #8]
	str	x9, [x1, #24]
	stp	x21, x22, [x19]
	str	x20, [x19, #16]
	b	LBB48_27
LBB48_20:
	cbz	x8, LBB48_22
LBB48_21:
	ldr	x20, [x20, #104]
	subs	x8, x8, #1
	b.ne	LBB48_21
LBB48_22:
	mov	x21, #0
	ldr	x8, [x20]
	cbz	x8, LBB48_25
LBB48_23:
	mov	w22, #200
	mov	w23, #104
	mov	x0, x20
LBB48_24:
	mov	x9, x21
	mov	x20, x8
	add	x21, x21, #1
	cmp	x9, #0
	csel	x1, x23, x22, eq
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
	ldr	x8, [x20]
	mov	x0, x20
	cbnz	x8, LBB48_24
LBB48_25:
	mov	w8, #200
	mov	w9, #104
	cmp	x21, #0
	csel	x1, x9, x8, eq
	mov	x0, x20
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB48_26:
	str	xzr, [x19]
LBB48_27:
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x24, x23, [sp, #16]
	ldp	x26, x25, [sp], #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	ret
LBB48_28:
	.cfi_restore_state
	mov	w9, #200
	mov	w10, #104
	cmp	x8, #0
	csel	x1, x10, x9, eq
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
Ltmp283:
Lloh70:
	adrp	x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.33@PAGE
Lloh71:
	add	x0, x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.33@PAGEOFF
	bl	__RNvNtCslWxY2MhVcag_4core6option13unwrap_failed
Ltmp284:
	brk	#0x1
LBB48_30:
Lloh72:
	adrp	x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.26@PAGE
Lloh73:
	add	x0, x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.26@PAGEOFF
	bl	__RNvNtCslWxY2MhVcag_4core6option13unwrap_failed
LBB48_31:
Ltmp285:
	brk	#0x1
	.loh AdrpAdd	Lloh70, Lloh71
	.loh AdrpAdd	Lloh72, Lloh73
Lfunc_end14:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table48:
Lexception14:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end14-Lcst_begin14
Lcst_begin14:
	.uleb128 Ltmp283-Lfunc_begin14
	.uleb128 Ltmp284-Ltmp283
	.uleb128 Ltmp285-Lfunc_begin14
	.byte	0
	.uleb128 Ltmp284-Lfunc_begin14
	.uleb128 Lfunc_end14-Ltmp284
	.byte	0
	.byte	0
Lcst_end14:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RNvMsz_NtNtNtCs6KVRSXc8uZF_5alloc11collections5btree3mapINtB5_8IntoIteryNtNtCs5joLtdXDRmI_12wasm_vm_core8dispatch8NomStateE10dying_nextCsj7lyy62zRs3_24retirement_capture_probe:
Lfunc_begin15:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception15
	stp	x26, x25, [sp, #-80]!
	.cfi_def_cfa_offset 80
	stp	x24, x23, [sp, #16]
	stp	x22, x21, [sp, #32]
	stp	x20, x19, [sp, #48]
	stp	x29, x30, [sp, #64]
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_remember_state
	mov	x19, x0
	ldr	x8, [x1, #64]
	cbz	x8, LBB49_8
	sub	x8, x8, #1
	str	x8, [x1, #64]
	ldr	x8, [x1]
	cmp	x8, #1
	b.ne	LBB49_30
	ldr	x0, [x1, #8]
	cbz	x0, LBB49_11
	ldp	x8, x20, [x1, #16]
	ldrh	w9, [x0, #98]
	cmp	x20, x9
	b.hs	LBB49_14
LBB49_4:
	mov	x22, x8
	mov	x21, x0
	cbz	x8, LBB49_18
LBB49_5:
	add	x8, x21, x20, lsl #3
	add	x9, x8, #120
	mov	x10, x22
LBB49_6:
	ldr	x8, [x9]
	add	x9, x8, #112
	subs	x10, x10, #1
	b.ne	LBB49_6
	mov	x9, #0
	b	LBB49_19
LBB49_8:
	ldp	x10, x9, [x1]
	ldp	x20, x8, [x1, #16]
	str	xzr, [x1]
	cmp	x10, #1
	b.ne	LBB49_26
	cbz	x9, LBB49_20
	mov	x21, x20
	mov	x20, x9
	ldr	x8, [x9]
	cbnz	x8, LBB49_23
	b	LBB49_25
LBB49_11:
	ldp	x0, x8, [x1, #16]
	cbz	x8, LBB49_13
LBB49_12:
	ldr	x0, [x0, #112]
	subs	x8, x8, #1
	b.ne	LBB49_12
LBB49_13:
	mov	x20, #0
	mov	x8, #0
	mov	w9, #1
	str	x9, [x1]
	ldrh	w9, [x0, #98]
	cmp	x20, x9
	b.lo	LBB49_4
LBB49_14:
	mov	x23, x1
	mov	w24, #208
	mov	w25, #112
LBB49_15:
	ldr	x21, [x0]
	cbz	x21, LBB49_28
	add	x22, x8, #1
	ldrh	w20, [x0, #96]
	cmp	x8, #0
	csel	x1, x25, x24, eq
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
	ldrh	w9, [x21, #98]
	mov	x0, x21
	mov	x8, x22
	cmp	w20, w9
	b.hs	LBB49_15
	mov	x1, x23
	cbnz	x22, LBB49_5
LBB49_18:
	add	x9, x20, #1
	mov	x8, x21
LBB49_19:
	stp	x8, xzr, [x1, #8]
	str	x9, [x1, #24]
	stp	x21, x22, [x19]
	str	x20, [x19, #16]
	b	LBB49_27
LBB49_20:
	cbz	x8, LBB49_22
LBB49_21:
	ldr	x20, [x20, #112]
	subs	x8, x8, #1
	b.ne	LBB49_21
LBB49_22:
	mov	x21, #0
	ldr	x8, [x20]
	cbz	x8, LBB49_25
LBB49_23:
	mov	w22, #208
	mov	w23, #112
	mov	x0, x20
LBB49_24:
	mov	x9, x21
	mov	x20, x8
	add	x21, x21, #1
	cmp	x9, #0
	csel	x1, x23, x22, eq
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
	ldr	x8, [x20]
	mov	x0, x20
	cbnz	x8, LBB49_24
LBB49_25:
	mov	w8, #208
	mov	w9, #112
	cmp	x21, #0
	csel	x1, x9, x8, eq
	mov	x0, x20
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB49_26:
	str	xzr, [x19]
LBB49_27:
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x24, x23, [sp, #16]
	ldp	x26, x25, [sp], #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	ret
LBB49_28:
	.cfi_restore_state
	mov	w9, #208
	mov	w10, #112
	cmp	x8, #0
	csel	x1, x10, x9, eq
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
Ltmp286:
Lloh74:
	adrp	x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.33@PAGE
Lloh75:
	add	x0, x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.33@PAGEOFF
	bl	__RNvNtCslWxY2MhVcag_4core6option13unwrap_failed
Ltmp287:
	brk	#0x1
LBB49_30:
Lloh76:
	adrp	x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.26@PAGE
Lloh77:
	add	x0, x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.26@PAGEOFF
	bl	__RNvNtCslWxY2MhVcag_4core6option13unwrap_failed
LBB49_31:
Ltmp288:
	brk	#0x1
	.loh AdrpAdd	Lloh74, Lloh75
	.loh AdrpAdd	Lloh76, Lloh77
Lfunc_end15:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table49:
Lexception15:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end15-Lcst_begin15
Lcst_begin15:
	.uleb128 Ltmp286-Lfunc_begin15
	.uleb128 Ltmp287-Ltmp286
	.uleb128 Ltmp288-Lfunc_begin15
	.byte	0
	.uleb128 Ltmp287-Lfunc_begin15
	.uleb128 Lfunc_end15-Ltmp287
	.byte	0
	.byte	0
Lcst_end15:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RNvMsz_NtNtNtCs6KVRSXc8uZF_5alloc11collections5btree3mapINtB5_8IntoIterymE10dying_nextCsj7lyy62zRs3_24retirement_capture_probe:
Lfunc_begin16:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception16
	stp	x26, x25, [sp, #-80]!
	.cfi_def_cfa_offset 80
	stp	x24, x23, [sp, #16]
	stp	x22, x21, [sp, #32]
	stp	x20, x19, [sp, #48]
	stp	x29, x30, [sp, #64]
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_remember_state
	mov	x19, x0
	ldr	x8, [x1, #64]
	cbz	x8, LBB50_8
	sub	x8, x8, #1
	str	x8, [x1, #64]
	ldr	x8, [x1]
	cmp	x8, #1
	b.ne	LBB50_30
	ldr	x0, [x1, #8]
	cbz	x0, LBB50_11
	ldp	x8, x20, [x1, #16]
	ldrh	w9, [x0, #142]
	cmp	x20, x9
	b.hs	LBB50_14
LBB50_4:
	mov	x22, x8
	mov	x21, x0
	cbz	x8, LBB50_18
LBB50_5:
	add	x8, x21, x20, lsl #3
	add	x9, x8, #152
	mov	x10, x22
LBB50_6:
	ldr	x8, [x9]
	add	x9, x8, #144
	subs	x10, x10, #1
	b.ne	LBB50_6
	mov	x9, #0
	b	LBB50_19
LBB50_8:
	ldp	x10, x9, [x1]
	ldp	x20, x8, [x1, #16]
	str	xzr, [x1]
	cmp	x10, #1
	b.ne	LBB50_26
	cbz	x9, LBB50_20
	mov	x21, x20
	mov	x20, x9
	ldr	x8, [x9]
	cbnz	x8, LBB50_23
	b	LBB50_25
LBB50_11:
	ldp	x0, x8, [x1, #16]
	cbz	x8, LBB50_13
LBB50_12:
	ldr	x0, [x0, #144]
	subs	x8, x8, #1
	b.ne	LBB50_12
LBB50_13:
	mov	x20, #0
	mov	x8, #0
	mov	w9, #1
	str	x9, [x1]
	ldrh	w9, [x0, #142]
	cmp	x20, x9
	b.lo	LBB50_4
LBB50_14:
	mov	x23, x1
	mov	w24, #240
	mov	w25, #144
LBB50_15:
	ldr	x21, [x0]
	cbz	x21, LBB50_28
	add	x22, x8, #1
	ldrh	w20, [x0, #140]
	cmp	x8, #0
	csel	x1, x25, x24, eq
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
	ldrh	w9, [x21, #142]
	mov	x0, x21
	mov	x8, x22
	cmp	w20, w9
	b.hs	LBB50_15
	mov	x1, x23
	cbnz	x22, LBB50_5
LBB50_18:
	add	x9, x20, #1
	mov	x8, x21
LBB50_19:
	stp	x8, xzr, [x1, #8]
	str	x9, [x1, #24]
	stp	x21, x22, [x19]
	str	x20, [x19, #16]
	b	LBB50_27
LBB50_20:
	cbz	x8, LBB50_22
LBB50_21:
	ldr	x20, [x20, #144]
	subs	x8, x8, #1
	b.ne	LBB50_21
LBB50_22:
	mov	x21, #0
	ldr	x8, [x20]
	cbz	x8, LBB50_25
LBB50_23:
	mov	w22, #240
	mov	w23, #144
	mov	x0, x20
LBB50_24:
	mov	x9, x21
	mov	x20, x8
	add	x21, x21, #1
	cmp	x9, #0
	csel	x1, x23, x22, eq
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
	ldr	x8, [x20]
	mov	x0, x20
	cbnz	x8, LBB50_24
LBB50_25:
	mov	w8, #240
	mov	w9, #144
	cmp	x21, #0
	csel	x1, x9, x8, eq
	mov	x0, x20
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
LBB50_26:
	str	xzr, [x19]
LBB50_27:
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x24, x23, [sp, #16]
	ldp	x26, x25, [sp], #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	ret
LBB50_28:
	.cfi_restore_state
	mov	w9, #240
	mov	w10, #144
	cmp	x8, #0
	csel	x1, x10, x9, eq
	mov	w2, #8
	bl	__RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc
Ltmp289:
Lloh78:
	adrp	x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.33@PAGE
Lloh79:
	add	x0, x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.33@PAGEOFF
	bl	__RNvNtCslWxY2MhVcag_4core6option13unwrap_failed
Ltmp290:
	brk	#0x1
LBB50_30:
Lloh80:
	adrp	x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.26@PAGE
Lloh81:
	add	x0, x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.26@PAGEOFF
	bl	__RNvNtCslWxY2MhVcag_4core6option13unwrap_failed
LBB50_31:
Ltmp291:
	brk	#0x1
	.loh AdrpAdd	Lloh78, Lloh79
	.loh AdrpAdd	Lloh80, Lloh81
Lfunc_end16:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table50:
Lexception16:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end16-Lcst_begin16
Lcst_begin16:
	.uleb128 Ltmp289-Lfunc_begin16
	.uleb128 Ltmp290-Ltmp289
	.uleb128 Ltmp291-Lfunc_begin16
	.byte	0
	.uleb128 Ltmp290-Lfunc_begin16
	.uleb128 Lfunc_end16-Ltmp290
	.byte	0
	.byte	0
Lcst_end16:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RNvNtCs5joLtdXDRmI_12wasm_vm_core9softfloat10fclass_f32:
	.cfi_startproc
	and	w8, w0, #0x7fffff
	ubfx	w9, w0, #23, #8
	cmn	w0, #1
	mov	w10, #3
	cinc	x10, x10, gt
	mov	w11, #2
	mov	w12, #5
	csel	x11, x12, x11, gt
	cmp	w8, #0
	csel	x10, x10, x11, eq
	cmn	w0, #1
	mov	w11, #6
	csinc	x11, x11, xzr, gt
	tst	w0, #0x400000
	mov	w12, #8
	cinc	x12, x12, ne
	cmn	w0, #1
	mov	w13, #7
	csel	x13, x13, xzr, gt
	cmp	w8, #0
	csel	x8, x12, x13, ne
	cmp	w9, #255
	csel	x8, x11, x8, ne
	cmp	w9, #0
	csel	x8, x10, x8, eq
	mov	w9, #1
	lsl	x0, x9, x8
	ret
	.cfi_endproc

	.p2align	2
__RNvNtCs5joLtdXDRmI_12wasm_vm_core9softfloat10fclass_f64:
	.cfi_startproc
	ubfx	x8, x0, #52, #11
	and	x9, x0, #0xfffffffffffff
	cmn	x0, #1
	mov	w10, #3
	cinc	x10, x10, gt
	mov	w11, #2
	mov	w12, #5
	csel	x11, x12, x11, gt
	cmp	x9, #0
	csel	x10, x10, x11, eq
	cmn	x0, #1
	mov	w11, #6
	csinc	x11, x11, xzr, gt
	tst	x0, #0x8000000000000
	mov	w12, #8
	cinc	x12, x12, ne
	mov	w13, #7
	cmp	x0, #0
	csel	x13, xzr, x13, mi
	cmp	x9, #0
	csel	x9, x12, x13, ne
	cmp	x8, #2047
	csel	x9, x11, x9, ne
	cmp	x8, #0
	csel	x8, x10, x9, eq
	mov	w9, #1
	lsl	x0, x9, x8
	ret
	.cfi_endproc

	.p2align	2
__RNvXNtCs5joLtdXDRmI_12wasm_vm_core3busNtB2_8BusFaultNtNtCslWxY2MhVcag_4core3fmt5Debug3fmt:
	.cfi_startproc
	mov	x8, x1
	ldrb	w9, [x0]
	cmp	w9, #0
	mov	w9, #6
	mov	w10, #10
	csel	x2, x10, x9, ne
Lloh82:
	adrp	x9, l_anon.9ed3183efb56324a1c787c8a9029a2a7.45@PAGE
Lloh83:
	add	x9, x9, l_anon.9ed3183efb56324a1c787c8a9029a2a7.45@PAGEOFF
Lloh84:
	adrp	x10, l_anon.9ed3183efb56324a1c787c8a9029a2a7.46@PAGE
Lloh85:
	add	x10, x10, l_anon.9ed3183efb56324a1c787c8a9029a2a7.46@PAGEOFF
	csel	x1, x10, x9, ne
	mov	x0, x8
	b	__RNvMsa_NtCslWxY2MhVcag_4core3fmtNtB5_9Formatter9write_str
	.loh AdrpAdd	Lloh84, Lloh85
	.loh AdrpAdd	Lloh82, Lloh83
	.cfi_endproc

	.p2align	2
__RNvXs1_NtCs5joLtdXDRmI_12wasm_vm_core3ramNtB5_11OutOfMemoryNtNtCslWxY2MhVcag_4core3fmt5Debug3fmt:
	.cfi_startproc
	mov	x0, x1
Lloh86:
	adrp	x1, l_anon.9ed3183efb56324a1c787c8a9029a2a7.47@PAGE
Lloh87:
	add	x1, x1, l_anon.9ed3183efb56324a1c787c8a9029a2a7.47@PAGEOFF
	mov	w2, #11
	b	__RNvMsa_NtCslWxY2MhVcag_4core3fmtNtB5_9Formatter9write_str
	.loh AdrpAdd	Lloh86, Lloh87
	.cfi_endproc

	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
lCPI55_0:
	.quad	-3750763034362895579
	.quad	0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_capture_hart_record_probe
	.p2align	2
_capture_hart_record_probe:
Lfunc_begin17:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception17
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #48]
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	mov	x8, x0
Lloh88:
	adrp	x9, lCPI55_0@PAGE
Lloh89:
	ldr	q0, [x9, lCPI55_0@PAGEOFF]
	str	q0, [sp, #16]
Ltmp292:
	add	x2, sp, #16
	mov	x0, x1
	mov	x1, x8
	bl	__RINvMs1_NtCs5joLtdXDRmI_12wasm_vm_core4hartNtB6_4Hart11step_tracedNtNtB8_5trace8HashSinkNtNtB8_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
Ltmp293:
	stp	x0, x1, [x29, #-16]
	sub	x8, x29, #16
	; InlineAsm Start
	; InlineAsm End
	ldr	x8, [sp, #16]
	str	x8, [sp, #8]
	add	x8, sp, #8
	; InlineAsm Start
	; InlineAsm End
	ldr	x0, [sp, #8]
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
LBB55_2:
	.cfi_restore_state
Ltmp294:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking19panic_cannot_unwind
	.loh AdrpLdr	Lloh88, Lloh89
Lfunc_end17:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table55:
Lexception17:
	.byte	255
	.byte	155
	.uleb128 Lttbase11-Lttbaseref11
Lttbaseref11:
	.byte	1
	.uleb128 Lcst_end17-Lcst_begin17
Lcst_begin17:
	.uleb128 Ltmp292-Lfunc_begin17
	.uleb128 Ltmp293-Ltmp292
	.uleb128 Ltmp294-Lfunc_begin17
	.byte	1
Lcst_end17:
	.byte	127
	.byte	0
	.p2align	2, 0x0
Lttbase11:
	.byte	0
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.globl	_capture_hart_unit_probe
	.p2align	2
_capture_hart_unit_probe:
Lfunc_begin18:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception18
	sub	sp, sp, #96
	.cfi_def_cfa_offset 96
	stp	x20, x19, [sp, #64]
	stp	x29, x30, [sp, #80]
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_remember_state
	mov	x19, x1
	mov	x20, x0
	strh	wzr, [x1, #728]
	ldr	x3, [x1, #3088]
	ldrb	w8, [x1, #732]
	cmp	w8, #1
	b.ne	LBB56_12
	ldr	x8, [x19, #704]
	and	x9, x8, #0xfffffffffffffffc
	and	x9, x9, #0xf000000000000007
	mov	x10, #4
	movk	x10, #8192, lsl #48
	cmp	x9, x10
	b.ne	LBB56_12
	ldrb	w9, [x19, #733]
	cmp	w9, #3
	b.eq	LBB56_5
	cmp	w9, #1
	b.ne	LBB56_7
	and	x9, x8, #0x10
	b	LBB56_8
LBB56_5:
	tbz	w8, #6, LBB56_12
	ldr	x9, [x19, #720]
	and	x9, x9, #0x8
	b	LBB56_8
LBB56_7:
	and	x9, x8, #0x8
LBB56_8:
	mov	w10, #63360
	tst	x8, x10
	b.ne	LBB56_12
	cbz	x9, LBB56_12
	ldr	x8, [x19, #712]
	cmp	x8, x3
	b.ne	LBB56_12
	mov	w8, #3
	dup.2d	v0, x8
	mov.d	v0[1], x3
	b	LBB56_22
LBB56_12:
Ltmp295:
	mov	x0, sp
	mov	x1, x19
	mov	x2, x20
	bl	__RINvMs1_NtCs5joLtdXDRmI_12wasm_vm_core4hartNtB6_4Hart9decode_atNtNtB8_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
Ltmp296:
	ldrb	w8, [sp]
	cmp	w8, #255
	b.eq	LBB56_20
	ldr	q0, [sp]
	stur	q0, [x29, #-32]
	ldrb	w4, [sp, #20]
	ldr	w5, [sp, #16]
Ltmp297:
	mov	x0, sp
	sub	x3, x29, #32
	mov	x1, x19
	mov	x2, x20
	bl	__RINvMs1_NtCs5joLtdXDRmI_12wasm_vm_core4hartNtB6_4Hart7executeNtNtB8_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
Ltmp298:
	ldrb	w8, [sp, #33]
	cmp	w8, #255
	b.eq	LBB56_21
	ldrb	w8, [x19, #728]
	tbnz	w8, #0, LBB56_18
	ldr	x8, [x19, #656]
	add	x8, x8, #1
	str	x8, [x19, #656]
LBB56_18:
	ldrb	w8, [x19, #729]
	movi.2d	v0, #0xffffffffffffffff
	tbnz	w8, #0, LBB56_22
	ldr	x8, [x19, #664]
	add	x8, x8, #1
	str	x8, [x19, #664]
	b	LBB56_22
LBB56_20:
	ldur	q0, [sp, #8]
	b	LBB56_22
LBB56_21:
	ldr	q0, [sp]
LBB56_22:
	str	q0, [sp]
	mov	x8, sp
	; InlineAsm Start
	; InlineAsm End
	.cfi_def_cfa wsp, 96
	ldp	x29, x30, [sp, #80]
	ldp	x20, x19, [sp, #64]
	add	sp, sp, #96
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
LBB56_23:
	.cfi_restore_state
Ltmp299:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking19panic_cannot_unwind
Lfunc_end18:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table56:
Lexception18:
	.byte	255
	.byte	155
	.uleb128 Lttbase12-Lttbaseref12
Lttbaseref12:
	.byte	1
	.uleb128 Lcst_end18-Lcst_begin18
Lcst_begin18:
	.uleb128 Ltmp295-Lfunc_begin18
	.uleb128 Ltmp298-Ltmp295
	.uleb128 Ltmp299-Lfunc_begin18
	.byte	1
Lcst_end18:
	.byte	127
	.byte	0
	.p2align	2, 0x0
Lttbase12:
	.byte	0
	.p2align	2, 0x0

	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
lCPI57_0:
	.quad	-3750763034362895579
	.quad	0
lCPI57_1:
	.quad	12
	.quad	0
lCPI57_2:
	.quad	22
	.quad	4
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI57_3:
	.long	1
	.long	4987
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_capture_machine_record_probe
	.p2align	2
_capture_machine_record_probe:
Lfunc_begin19:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception19
	sub	sp, sp, #400
	.cfi_def_cfa_offset 400
	stp	d9, d8, [sp, #288]
	stp	x28, x27, [sp, #304]
	stp	x26, x25, [sp, #320]
	stp	x24, x23, [sp, #336]
	stp	x22, x21, [sp, #352]
	stp	x20, x19, [sp, #368]
	stp	x29, x30, [sp, #384]
	add	x29, sp, #384
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_remember_state
	mov	x19, x0
	add	x9, x0, #1, lsl #12
Lloh90:
	adrp	x8, lCPI57_0@PAGE
Lloh91:
	ldr	q0, [x8, lCPI57_0@PAGEOFF]
	str	q0, [sp, #128]
	str	x1, [sp, #144]
	add	x8, sp, #144
	; InlineAsm Start
	; InlineAsm End
	ldr	x24, [sp, #144]
	add	x21, x0, #1, lsl #12
	ldrb	w8, [x9, #3014]
	cmp	w8, #1
	b.ne	LBB57_4
	ldr	x8, [x19, #6872]
	cbz	x8, LBB57_4
	ldr	x9, [x19, #6880]
	ldp	x10, x9, [x9, #16]
	sub	x10, x10, #1
	and	x10, x10, #0xfffffffffffffff0
	add	x8, x8, x10
Ltmp300:
	add	x0, x8, #16
	blr	x9
	str	x0, [sp, #40]
Ltmp301:
	str	wzr, [sp, #108]
	ldrb	w20, [x21, #3017]
	tbz	w20, #0, LBB57_5
	b	LBB57_6
LBB57_4:
	mov	w8, #1
	str	w8, [sp, #108]
	ldrb	w20, [x21, #3017]
	tbnz	w20, #0, LBB57_6
LBB57_5:
Ltmp302:
	mov	x0, x19
	mov	w1, #0
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine26begin_cooperative_run_mode
Ltmp303:
LBB57_6:
	ldrb	w8, [x21, #3015]
	tbz	w8, #0, LBB57_8
Ltmp304:
	mov	x0, x19
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine25sync_pmp_code_permissions
Ltmp305:
LBB57_8:
Ltmp306:
	mov	x0, x19
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine17drain_code_writes
Ltmp307:
	str	w20, [sp, #104]
	cbz	x24, LBB57_207
	mov	w8, #5416
	add	x21, x19, x8
Lloh92:
	adrp	x8, lCPI57_1@PAGE
Lloh93:
	ldr	q0, [x8, lCPI57_1@PAGEOFF]
	str	q0, [sp, #64]
Lloh94:
	adrp	x8, lCPI57_2@PAGE
Lloh95:
	ldr	q0, [x8, lCPI57_2@PAGEOFF]
	str	q0, [sp, #48]
Lloh96:
	adrp	x8, lCPI57_3@PAGE
Lloh97:
	ldr	d8, [x8, lCPI57_3@PAGEOFF]
	add	x8, sp, #176
	orr	x9, x8, #0x1
	add	x8, sp, #160
	orr	x8, x8, #0x1
	stp	x8, x9, [sp, #88]
	mov	w22, #24
	mov	x20, #9223372036854775807
	mov	x23, #-1
	b	LBB57_13
LBB57_11:
	ldr	x8, [x19, #3088]
	add	x8, x8, #4
	str	x8, [x19, #3088]
LBB57_12:
	ldr	x24, [sp, #112]
	subs	x24, x24, #1
	b.eq	LBB57_207
LBB57_13:
	ldr	x8, [x19, #6896]
	cbz	x8, LBB57_16
	ldr	x9, [x8, #16]
	mov	x10, #9223372036854775806
	cmp	x9, x10
	b.hi	LBB57_228
	ldrh	w9, [x8, #24]
	mov	w10, #65535
	cmp	w9, w10
	b.ne	LBB57_210
LBB57_16:
	str	x24, [sp, #112]
	add	x9, x19, #1, lsl #12
	ldrb	w8, [x9, #3015]
	ldrb	w9, [x9, #3016]
	cmp	w9, #1
	b.ne	LBB57_22
	tbz	w8, #0, LBB57_22
Ltmp308:
	mov	x0, x19
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine17at_block_boundary
Ltmp309:
	add	x8, x19, #1, lsl #12
	ldrb	w8, [x8, #3015]
	and	w8, w0, w8
	tbnz	w8, #0, LBB57_23
	tbnz	w0, #0, LBB57_24
	ldr	x25, [x19, #3088]
	b	LBB57_125
LBB57_22:
	tbz	w8, #0, LBB57_24
LBB57_23:
Ltmp310:
	mov	x0, x19
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine25sync_pmp_code_permissions
Ltmp311:
LBB57_24:
	ldr	x8, [x19, #6208]
	cbz	x8, LBB57_29
	ldr	x24, [x19, #6200]
	add	x8, x8, x8, lsl #1
	lsl	x25, x8, #3
LBB57_26:
	ldr	x8, [x24], #24
	mov	x26, x8
	ldr	x9, [x26, #16]!
	cbnz	x9, LBB57_220
	str	x23, [x8, #16]
Ltmp312:
	add	x0, x8, #24
	bl	__RNvMNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmioNtB2_10VirtioMmio23sync_backend_config_irq
Ltmp313:
	ldr	x8, [x26]
	add	x8, x8, #1
	str	x8, [x26]
	subs	x25, x25, #24
	b.ne	LBB57_26
LBB57_29:
Ltmp315:
	mov	x0, x19
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine17sample_wall_clock
Ltmp316:
Ltmp317:
	mov	x0, x19
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine10sync_clint
Ltmp318:
	ldr	x8, [x19, #6824]
	cbz	x8, LBB57_40
	mov	x26, x8
	ldr	x9, [x26, #16]!
	cbnz	x9, LBB57_229
	str	x23, [x8, #16]
	ldr	x9, [x8, #48]
	cbz	x9, LBB57_37
	ldrb	w9, [x8, #86]
	tbnz	w9, #0, LBB57_37
	ldr	w9, [x8, #80]
	adds	w9, w9, #1
	csinv	w9, w9, wzr, lo
	str	w9, [x8, #80]
	cmp	w9, #1024
	b.lo	LBB57_37
	mov	w9, #1
	strb	w9, [x8, #86]
LBB57_37:
Ltmp319:
	add	x0, x8, #24
	bl	__RNvMs0_NtNtCs5joLtdXDRmI_12wasm_vm_core3dev9uart16550NtB5_9Uart165509irq_level
	mov	x1, x0
Ltmp320:
Ltmp321:
	mov	w8, #6832
	add	x0, x19, x8
	bl	__RNvMs2_NtNtCs5joLtdXDRmI_12wasm_vm_core3dev4plicNtB5_7IrqLine3set
Ltmp322:
	ldr	x8, [x26]
	add	x8, x8, #1
	str	x8, [x26]
LBB57_40:
	ldr	x8, [x19, #6848]
	cbz	x8, LBB57_45
	mov	x26, x8
	ldr	x9, [x26, #16]!
	cbnz	x9, LBB57_230
	str	x23, [x8, #16]
Ltmp326:
	add	x0, x8, #24
	bl	__RNvMs0_NtNtCs5joLtdXDRmI_12wasm_vm_core3dev3rtcNtB5_11GoldfishRtc4poll
	mov	x1, x0
Ltmp327:
Ltmp328:
	mov	w8, #6856
	add	x0, x19, x8
	bl	__RNvMs2_NtNtCs5joLtdXDRmI_12wasm_vm_core3dev4plicNtB5_7IrqLine3set
Ltmp329:
	ldr	x8, [x26]
	add	x8, x8, #1
	str	x8, [x26]
LBB57_45:
	mov	w8, #5328
	ldr	x8, [x19, x8]
	cmp	x8, #2
	b.eq	LBB57_51
	ldr	x8, [x19, #6208]
	cbz	x8, LBB57_237
	ldr	x8, [x19, #6200]
	ldr	x9, [x8]
	ldr	x10, [x9]
	adds	x10, x10, #1
	str	x10, [x9]
	b.hs	LBB57_236
	ldr	x8, [x8]
	str	x8, [sp, #176]
Ltmp331:
	add	x0, sp, #176
	mov	w8, #5328
	add	x1, x19, x8
	mov	w8, #5320
	add	x2, x19, x8
	mov	x3, x21
	bl	__RNvNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3blk7service
Ltmp332:
	ldr	x8, [sp, #176]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB57_51
Ltmp334:
	add	x0, sp, #176
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmio10VirtioMmioEE9drop_slowB1m_
Ltmp335:
LBB57_51:
	ldr	x24, [x19, #6232]
	cbz	x24, LBB57_61
	mov	x26, #0
	mov	x25, #0
	b	LBB57_54
LBB57_53:
	add	x25, x25, #1
	add	x26, x26, #56
	cmp	x24, x25
	b.eq	LBB57_61
LBB57_54:
	ldr	x1, [x19, #6232]
	cmp	x25, x1
	b.hs	LBB57_233
	ldr	x8, [x19, #6224]
	add	x8, x8, x26
	ldr	x8, [x8, #48]
	ldr	x1, [x19, #6208]
	cmp	x8, x1
	b.hs	LBB57_232
	ldr	x9, [x19, #6200]
	madd	x8, x8, x22, x9
	ldr	x9, [x8]
	ldr	x10, [x9]
	adds	x10, x10, #1
	str	x10, [x9]
	b.hs	LBB57_236
	ldr	x8, [x8]
	str	x8, [sp, #176]
	ldr	x1, [x19, #6232]
	cmp	x25, x1
	b.hs	LBB57_235
	ldr	x8, [x19, #6224]
	add	x1, x8, x26
Ltmp339:
	add	x0, sp, #176
	add	x2, x1, #40
	mov	x3, x21
	bl	__RNvNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3blk7service
Ltmp340:
	ldr	x8, [sp, #176]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB57_53
Ltmp342:
	add	x0, sp, #176
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmio10VirtioMmioEE9drop_slowB1m_
Ltmp343:
	b	LBB57_53
LBB57_61:
	mov	w8, #4488
	ldr	x8, [x19, x8]
	cmp	x8, #2
	b.eq	LBB57_67
	ldr	x1, [x19, #6208]
	cmp	x1, #1
	b.ls	LBB57_238
	ldr	x8, [x19, #6200]
	ldr	x9, [x8, #24]
	ldr	x10, [x9]
	adds	x10, x10, #1
	str	x10, [x9]
	b.hs	LBB57_236
	ldr	x8, [x8, #24]
	str	x8, [sp, #176]
Ltmp345:
	add	x0, sp, #176
	mov	w8, #4488
	add	x1, x19, x8
	mov	w8, #4536
	add	x2, x19, x8
	mov	w8, #4528
	add	x3, x19, x8
	mov	x4, x21
	bl	__RNvNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3net7service
Ltmp346:
	ldr	x8, [sp, #176]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB57_67
Ltmp348:
	add	x0, sp, #176
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmio10VirtioMmioEE9drop_slowB1m_
Ltmp349:
LBB57_67:
	mov	w8, #5376
	ldr	x8, [x19, x8]
	cmp	x8, #2
	b.eq	LBB57_73
	ldr	x1, [x19, #6208]
	cmp	x1, #2
	b.ls	LBB57_239
	ldr	x8, [x19, #6200]
	ldr	x9, [x8, #48]
	ldr	x10, [x9]
	adds	x10, x10, #1
	str	x10, [x9]
	b.hs	LBB57_236
	ldr	x8, [x8, #48]
	str	x8, [sp, #176]
Ltmp350:
	add	x0, sp, #176
	mov	w8, #5376
	add	x1, x19, x8
	mov	w8, #5368
	add	x2, x19, x8
	mov	x3, x21
	bl	__RNvNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3rng7service
Ltmp351:
	ldr	x8, [sp, #176]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB57_73
Ltmp353:
	add	x0, sp, #176
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmio10VirtioMmioEE9drop_slowB1m_
Ltmp354:
LBB57_73:
	mov	w8, #4576
	ldr	x8, [x19, x8]
	cmp	x8, #2
	b.eq	LBB57_79
	ldr	x1, [x19, #6208]
	cmp	x1, #3
	b.ls	LBB57_240
	ldr	x8, [x19, #6200]
	ldr	x9, [x8, #72]
	ldr	x10, [x9]
	adds	x10, x10, #1
	str	x10, [x9]
	b.hs	LBB57_236
	ldr	x8, [x8, #72]
	str	x8, [sp, #176]
Ltmp355:
	add	x0, sp, #176
	mov	w8, #4576
	add	x1, x19, x8
	mov	w8, #4624
	add	x2, x19, x8
	mov	w8, #4616
	add	x3, x19, x8
	mov	x4, x21
	bl	__RNvNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio5input7service
Ltmp356:
	ldr	x8, [sp, #176]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB57_79
Ltmp358:
	add	x0, sp, #176
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmio10VirtioMmioEE9drop_slowB1m_
Ltmp359:
LBB57_79:
	mov	w8, #4664
	ldr	x8, [x19, x8]
	cmp	x8, #2
	b.eq	LBB57_85
	ldr	x1, [x19, #6208]
	cmp	x1, #4
	b.ls	LBB57_241
	ldr	x8, [x19, #6200]
	ldr	x9, [x8, #96]
	ldr	x10, [x9]
	adds	x10, x10, #1
	str	x10, [x9]
	b.hs	LBB57_236
	ldr	x8, [x8, #96]
	str	x8, [sp, #176]
Ltmp360:
	add	x0, sp, #176
	mov	w8, #4664
	add	x1, x19, x8
	mov	w8, #4712
	add	x2, x19, x8
	mov	w8, #4704
	add	x3, x19, x8
	mov	x4, x21
	bl	__RNvNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio5input7service
Ltmp361:
	ldr	x8, [sp, #176]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB57_85
Ltmp363:
	add	x0, sp, #176
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmio10VirtioMmioEE9drop_slowB1m_
Ltmp364:
LBB57_85:
	mov	w8, #4752
	ldr	x8, [x19, x8]
	cmp	x8, #2
	b.eq	LBB57_91
	ldr	x1, [x19, #6208]
	cmp	x1, #5
	b.ls	LBB57_242
	ldr	x8, [x19, #6200]
	ldr	x9, [x8, #120]
	ldr	x10, [x9]
	adds	x10, x10, #1
	str	x10, [x9]
	b.hs	LBB57_236
	ldr	x8, [x8, #120]
	str	x8, [sp, #176]
Ltmp365:
	add	x0, sp, #176
	mov	w8, #4752
	add	x1, x19, x8
	mov	w8, #4800
	add	x2, x19, x8
	mov	w8, #4792
	add	x3, x19, x8
	mov	x4, x21
	bl	__RNvNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio5input7service
Ltmp366:
	ldr	x8, [sp, #176]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB57_91
Ltmp368:
	add	x0, sp, #176
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmio10VirtioMmioEE9drop_slowB1m_
Ltmp369:
LBB57_91:
	mov	w8, #4392
	ldr	x8, [x19, x8]
	cmp	x8, #2
	b.eq	LBB57_97
	ldr	x25, [x19, #4480]
	ldr	x1, [x19, #6208]
	cmp	x25, x1
	b.hs	LBB57_243
	ldr	x8, [x19, #6200]
	madd	x8, x25, x22, x8
	ldr	x9, [x8]
	ldr	x10, [x9]
	adds	x10, x10, #1
	str	x10, [x9]
	b.hs	LBB57_236
	ldr	x8, [x8]
	str	x8, [sp, #176]
Ltmp370:
	add	x0, sp, #176
	mov	w8, #4392
	add	x1, x19, x8
	mov	w8, #4432
	add	x2, x19, x8
	mov	w8, #4472
	add	x3, x19, x8
	mov	x4, x21
	bl	__RNvNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3gpu19service_with_cursor
Ltmp371:
	ldr	x8, [sp, #176]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB57_97
Ltmp373:
	add	x0, sp, #176
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmio10VirtioMmioEE9drop_slowB1m_
Ltmp374:
LBB57_97:
	mov	w8, #4840
	ldr	x8, [x19, x8]
	cmp	x8, #2
	b.eq	LBB57_103
	ldr	x25, [x19, #5040]
	ldr	x1, [x19, #6208]
	cmp	x25, x1
	b.hs	LBB57_244
	ldr	x8, [x19, #6200]
	madd	x8, x25, x22, x8
	ldr	x9, [x8]
	ldr	x10, [x9]
	adds	x10, x10, #1
	str	x10, [x9]
	b.hs	LBB57_236
	ldr	x8, [x8]
	str	x8, [sp, #160]
	ldr	x4, [x19, #5048]
	ldr	x5, [x19, #5056]
	ldr	x8, [x19, #5008]
	ldr	x9, [x19, #5016]
	ldr	x10, [x9, #16]
	sub	x10, x10, #1
	and	x10, x10, #0xfffffffffffffff0
	add	x8, x8, x10
	add	x10, x8, #16
	ldr	x11, [x19, #5024]
	ldr	x12, [x19, #5032]
Ltmp375:
	stp	x12, x21, [sp, #24]
	add	x8, sp, #176
	add	x0, sp, #160
	stp	x9, x11, [sp, #8]
	mov	w11, #4840
	add	x1, x19, x11
	mov	w11, #4880
	add	x2, x19, x11
	mov	w11, #4920
	add	x3, x19, x11
	mov	w11, #4960
	add	x6, x19, x11
	mov	w11, #5000
	add	x7, x19, x11
	str	x10, [sp]
	bl	__RNvNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio3snd39service_with_control_eventq_and_capture
Ltmp376:
	ldr	x8, [sp, #160]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB57_103
Ltmp378:
	add	x0, sp, #160
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmio10VirtioMmioEE9drop_slowB1m_
Ltmp379:
LBB57_103:
	mov	w8, #5064
	ldr	x8, [x19, x8]
	cmp	x8, #2
	b.eq	LBB57_109
	ldr	x25, [x19, #5312]
	ldr	x1, [x19, #6208]
	cmp	x25, x1
	b.hs	LBB57_245
	ldr	x8, [x19, #6200]
	madd	x8, x25, x22, x8
	ldr	x9, [x8]
	ldr	x10, [x9]
	adds	x10, x10, #1
	str	x10, [x9]
	b.hs	LBB57_236
	ldr	x8, [x8]
	str	x8, [sp, #176]
Ltmp380:
	str	x21, [sp]
	add	x0, sp, #176
	mov	w8, #5064
	add	x1, x19, x8
	mov	w8, #5104
	add	x2, x19, x8
	mov	w8, #5144
	add	x3, x19, x8
	mov	w8, #5184
	add	x4, x19, x8
	mov	w8, #5224
	add	x5, x19, x8
	mov	w8, #5264
	add	x6, x19, x8
	mov	w8, #5304
	add	x7, x19, x8
	bl	__RNvNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio7console7service
Ltmp381:
	ldr	x8, [sp, #176]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB57_109
Ltmp386:
	add	x0, sp, #176
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmio10VirtioMmioEE9drop_slowB1m_
Ltmp387:
LBB57_109:
	ldr	x9, [x19, #6208]
	cbz	x9, LBB57_114
	ldr	x8, [x19, #6200]
	madd	x24, x9, x22, x8
LBB57_111:
	ldr	x9, [x8]
	mov	x26, x9
	ldr	x10, [x26, #16]!
	cmp	x10, x20
	b.hs	LBB57_222
	add	x10, x10, #1
	str	x10, [x9, #16]
	ldr	w9, [x9, #336]
	cmp	w9, #0
	cset	w1, ne
	add	x25, x8, #8
Ltmp388:
	mov	x0, x25
	bl	__RNvMs2_NtNtCs5joLtdXDRmI_12wasm_vm_core3dev4plicNtB5_7IrqLine3set
Ltmp389:
	ldr	x8, [x26]
	sub	x8, x8, #1
	str	x8, [x26]
	add	x8, x25, #16
	cmp	x8, x24
	b.ne	LBB57_111
LBB57_114:
Ltmp391:
	mov	x0, x19
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine9sync_plic
Ltmp392:
Ltmp393:
	mov	x0, x19
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine14sync_sbi_timer
Ltmp394:
Ltmp395:
	mov	x0, x19
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine17drain_code_writes
Ltmp396:
	add	x8, x19, #1, lsl #12
	ldrb	w8, [x8, #3019]
	cmp	w8, #1
	b.ne	LBB57_123
	ldr	x8, [x19, #7032]
	cbz	x8, LBB57_123
	ldr	x8, [x19, #6584]
	ldr	x9, [x19, #7040]
	orr	x8, x8, x9
	cbz	x8, LBB57_123
	ldr	w8, [x19, #7104]
	add	w8, w8, #1
	str	w8, [x19, #7104]
	cmp	w8, #63
	b.hi	LBB57_122
	ldr	x8, [x19, #6352]
	cmp	x8, #32
	b.lo	LBB57_123
LBB57_122:
	str	wzr, [x19, #7104]
Ltmp397:
	mov	x0, x19
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine21pump_jit_translations
Ltmp398:
LBB57_123:
Ltmp399:
	add	x0, x19, #24
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs14next_interrupt
Ltmp400:
	and	w8, w1, #0xff
	ldr	x25, [x19, #3088]
	cmp	w8, #2
	b.ne	LBB57_131
LBB57_125:
	add	x8, x19, #1, lsl #12
	ldrb	w8, [x8, #3015]
	tbz	w8, #0, LBB57_133
	strh	wzr, [x19, #728]
	ldrb	w8, [x19, #732]
	cmp	w8, #1
	b.ne	LBB57_142
	ldr	x8, [x19, #704]
	mov	x9, #4
	movk	x9, #61440, lsl #48
	and	x9, x8, x9
	mov	x10, #4
	movk	x10, #8192, lsl #48
	cmp	x9, x10
	b.ne	LBB57_142
	ldrb	w9, [x19, #733]
	cmp	w9, #3
	b.eq	LBB57_135
	cmp	w9, #1
	b.ne	LBB57_137
	and	x9, x8, #0x10
	b	LBB57_138
LBB57_131:
Ltmp401:
	mov	x26, x0
	and	w2, w1, #0x1
	mov	x0, x19
	mov	x1, x26
	mov	x3, x25
	bl	__RNvMs1_NtCs5joLtdXDRmI_12wasm_vm_core4hartNtB5_4Hart14take_interrupt
Ltmp402:
	and	x8, x26, #0xf
	add	x10, x19, #3720
	ldr	x9, [x10, x8, lsl #3]
	add	x9, x9, #1
	str	x9, [x10, x8, lsl #3]
	ldr	x8, [x19, #4112]
	add	x8, x8, #1
	str	x8, [x19, #4112]
Ltmp403:
	mov	x0, x19
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine11storm_check
Ltmp404:
	b	LBB57_12
LBB57_133:
Ltmp405:
	add	x2, sp, #128
	mov	x0, x19
	mov	x1, x21
	bl	__RINvMs1_NtCs5joLtdXDRmI_12wasm_vm_core4hartNtB6_4Hart11step_tracedNtNtB8_5trace8HashSinkNtNtB8_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
Ltmp406:
	mov	x26, x0
	mov	x27, x1
	b	LBB57_155
LBB57_135:
	tbz	w8, #6, LBB57_142
	ldr	x9, [x19, #720]
	and	x9, x9, #0x8
	b	LBB57_138
LBB57_137:
	and	x9, x8, #0x8
LBB57_138:
	mov	w10, #63360
	tst	x8, x10
	b.ne	LBB57_142
	cbz	x9, LBB57_142
	ldr	x8, [x19, #712]
	cmp	x8, x25
	b.ne	LBB57_142
	mov	x27, x25
	mov	w26, #3
	b	LBB57_155
LBB57_142:
Ltmp407:
	add	x8, sp, #176
	mov	x0, x19
	mov	x1, x25
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine13next_micro_op
Ltmp408:
	ldrb	w24, [sp, #176]
	cmp	w24, #255
	b.ne	LBB57_145
	ldp	x26, x27, [sp, #184]
	b	LBB57_155
LBB57_145:
	ldp	x10, x9, [sp, #88]
	ldr	w8, [x9]
	str	w8, [x10]
	ldur	w8, [x9, #3]
	stur	w8, [x10, #3]
	ldp	x8, x9, [sp, #184]
	ubfx	x4, x9, #32, #8
	mov	w28, w9
	strb	w24, [sp, #160]
	str	x8, [sp, #168]
Ltmp409:
	add	x0, sp, #176
	add	x3, sp, #160
	mov	x1, x19
	mov	x2, x21
	mov	x5, x28
	bl	__RINvMs1_NtCs5joLtdXDRmI_12wasm_vm_core4hartNtB6_4Hart7executeNtNtB8_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe
Ltmp410:
	ldrb	w8, [sp, #209]
	ldp	x26, x27, [sp, #176]
	cmp	w8, #255
	b.eq	LBB57_155
	ldrb	w9, [x19, #728]
	tbnz	w9, #0, LBB57_149
	ldr	x9, [x19, #656]
	add	x9, x9, #1
	str	x9, [x19, #656]
LBB57_149:
	ldrb	w9, [x19, #729]
	tbnz	w9, #0, LBB57_151
	ldr	x9, [x19, #664]
	add	x9, x9, #1
	str	x9, [x19, #664]
LBB57_151:
	ldp	x9, x10, [sp, #192]
	ldp	x11, x12, [sp, #128]
	eor	x11, x11, x25
	mov	x15, #435
	movk	x15, #256, lsl #32
	mul	x11, x11, x15
	eor	x11, x11, x28
	ldrb	w13, [sp, #208]
	ands	x14, x27, #0xff
	mul	x11, x11, x15
	orr	x14, x14, #0x100000000000000
	eor	x14, x11, x14
	eor	x11, x11, #0x200000000000000
	mul	x14, x14, x15
	eor	x14, x14, x26
	csel	x11, x11, x14, eq
	mul	x11, x11, x15
	cmp	w8, #2
	eor	x14, x11, #0x400000000000000
	eor	x9, x11, x9
	mul	x9, x9, x15
	orr	x8, x8, x13, lsl #1
	eor	x8, x9, x8
	mul	x8, x8, x15
	eor	x8, x8, x10
	csel	x8, x14, x8, eq
	mul	x8, x8, x15
	add	x9, x12, #1
	stp	x8, x9, [sp, #128]
	cmp	w24, #71
	b.ne	LBB57_153
	ldr	x8, [x19, #6320]
	adds	x8, x8, #1
	csinv	x8, x8, xzr, lo
	str	x8, [x19, #6320]
	str	xzr, [x19, #3488]
LBB57_153:
Ltmp411:
	mov	x0, x19
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine17drain_code_writes
Ltmp412:
	mov	x26, #-1
LBB57_155:
	cmn	x26, #1
	b.eq	LBB57_163
	cmp	x26, #9
	b.ne	LBB57_170
	add	x8, x19, #1, lsl #12
	ldrb	w8, [x8, #3012]
	tbz	w8, #0, LBB57_170
	ldr	x25, [x19, #2968]
	ldr	x4, [x19, #2960]
	ldr	q0, [x19, #2912]
	ldr	q1, [x19, #2928]
	stp	q0, q1, [sp, #176]
	ldr	q0, [x19, #2944]
	str	q0, [sp, #208]
Ltmp423:
	add	x0, x19, #3408
	add	x5, sp, #176
	mov	x1, x21
	mov	x2, x19
	mov	x3, x25
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core3sbi6handle
Ltmp424:
	add	x8, x19, #3408
	ldr	w8, [x8]
	tbnz	w8, #0, LBB57_224
	ldrb	w8, [x19, #3480]
	tbnz	w8, #0, LBB57_227
	str	x0, [x19, #2912]
	ldr	x8, [x19, #3096]
	add	x9, x8, #1
	str	x9, [x19, #3096]
	cmp	x25, #16
	b.lo	LBB57_11
	str	x1, [x19, #2920]
	add	x8, x8, #2
	str	x8, [x19, #3096]
	b	LBB57_11
LBB57_163:
Ltmp425:
	mov	x0, x19
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine13advance_clock
Ltmp426:
	ldr	x8, [x19, #3584]
	add	x8, x8, #1
	str	x8, [x19, #3584]
	add	x8, x19, #1, lsl #12
	ldrb	w8, [x8, #3014]
	tbz	w8, #0, LBB57_181
	ldr	w8, [x19, #7096]
	cmp	w8, #0
	cset	w9, ne
	sub	w9, w8, w9
	str	w9, [x19, #7096]
	cmp	w8, #1
	b.hi	LBB57_181
	ldr	x8, [x19, #5640]
	add	x8, x8, #1
	str	x8, [x19, #5640]
	lsr	x8, x25, #6
	mov	x9, #31765
	movk	x9, #32586, lsl #16
	movk	x9, #31161, lsl #32
	movk	x9, #40503, lsl #48
	mul	x9, x8, x9
	lsr	x25, x9, #51
	ldr	x1, [x19, #5632]
	cmp	x25, x1
	b.hs	LBB57_246
	ldr	x9, [x19, #5624]
	add	x9, x9, x25, lsl #4
	ldr	w10, [x9, #8]
	cbz	w10, LBB57_178
	ldr	x11, [x9]
	cmp	x11, x8
	b.ne	LBB57_177
	adds	w8, w10, #1
	csinv	w8, w8, wzr, lo
	str	w8, [x9, #8]
	b	LBB57_180
LBB57_170:
Ltmp413:
	add	x0, x19, #24
	mov	x1, x26
	mov	w2, #0
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs14delegates_to_s
Ltmp414:
	tbz	w0, #0, LBB57_173
Ltmp417:
	add	x0, x19, #24
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs10stvec_base
Ltmp418:
	b	LBB57_174
LBB57_173:
Ltmp415:
	add	x0, x19, #24
	bl	__RNvMNtCs5joLtdXDRmI_12wasm_vm_core3csrNtB2_4Csrs10mtvec_base
Ltmp416:
LBB57_174:
	cbz	x0, LBB57_226
	ldr	x3, [x19, #3088]
Ltmp419:
	mov	x0, x19
	mov	x1, x26
	mov	x2, x27
	bl	__RNvMs1_NtCs5joLtdXDRmI_12wasm_vm_core4hartNtB5_4Hart9take_trap
Ltmp420:
	and	x8, x26, #0xf
	add	x10, x19, #3592
	ldr	x9, [x10, x8, lsl #3]
	add	x9, x9, #1
	str	x9, [x10, x8, lsl #3]
	ldr	x8, [x19, #4112]
	add	x8, x8, #1
	str	x8, [x19, #4112]
Ltmp421:
	mov	x0, x19
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine11storm_check
Ltmp422:
	b	LBB57_186
LBB57_177:
	cmp	w10, #3
	b.hs	LBB57_179
LBB57_178:
	str	x8, [x9]
	mov	w8, #1
	str	w8, [x9, #8]
	b	LBB57_180
LBB57_179:
	ldr	x8, [x19, #5648]
	add	x8, x8, #1
	str	x8, [x19, #5648]
LBB57_180:
	ldr	x8, [x19, #5744]
	add	x8, x8, #1
	str	x8, [x19, #5744]
	ldr	w8, [x19, #7100]
	mov	w9, #26125
	movk	w9, #25, lsl #16
	mov	w10, #62303
	movk	w10, #15470, lsl #16
	madd	w8, w8, w9, w10
	str	w8, [x19, #7100]
	ubfx	w8, w8, #24, #7
	add	w8, w8, #1021
	str	w8, [x19, #7096]
LBB57_181:
	ldrb	w8, [x19, #3360]
	tbz	w8, #0, LBB57_186
	ldr	x8, [x19, #4104]
	add	x8, x8, #1
	str	x8, [x19, #4104]
	strb	wzr, [x19, #3360]
Ltmp429:
	mov	x0, x19
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine18wfi_watchdog_check
Ltmp430:
Ltmp431:
	mov	x0, x19
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine23external_net_io_pending
Ltmp432:
	tbnz	w0, #0, LBB57_186
Ltmp433:
	mov	x0, x19
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine16wfi_fast_forward
Ltmp434:
LBB57_186:
	ldr	w8, [x19, #3368]
	tbz	w8, #0, LBB57_12
	ldr	x5, [x19, #3376]
	ldr	x8, [x19, #5440]
	subs	x8, x5, x8
	b.lo	LBB57_190
	cmn	x8, #9
	b.hi	LBB57_190
	add	x9, x8, #8
	ldr	x10, [x19, #5432]
	cmp	x9, x10
	b.ls	LBB57_198
LBB57_190:
	mov	w8, #1
	strh	w8, [sp, #176]
	ldr	x8, [x19, #5496]
	cbz	x8, LBB57_192
	ldr	x3, [x19, #5504]
	ldr	x9, [x3, #16]
	sub	x9, x9, #1
	and	x9, x9, #0xfffffffffffffff0
	add	x8, x8, x9
	add	x2, x8, #16
	b	LBB57_193
LBB57_192:
	mov	x2, #0
LBB57_193:
Ltmp435:
	ldr	x0, [x19, #5456]
	ldr	x1, [x19, #5464]
	add	x8, sp, #176
	mov	w9, #5512
	add	x4, x19, x9
	mov	w6, #3
	bl	__RNvNtCs5joLtdXDRmI_12wasm_vm_core4mmio11load_device
Ltmp436:
	ldrb	w8, [sp, #176]
	tbnz	w8, #0, LBB57_199
	ldr	x9, [sp, #184]
	cbz	x9, LBB57_199
LBB57_196:
	and	x8, x9, #0x1
	lsr	x8, x9, x8
	tbz	w9, #0, LBB57_200
	mov	w9, #1
	orr	x8, x9, x8, lsl #1
	b	LBB57_200
LBB57_198:
	tst	x5, #0x7
	b.eq	LBB57_206
LBB57_199:
	mov	x8, #0
LBB57_200:
	ldr	x9, [x19, #6760]
	cmp	x8, x9
	b.eq	LBB57_12
	str	x8, [x19, #6760]
	and	x9, x8, #0x1
	mov	w10, #2
	sub	x10, x10, x9
	cmp	x8, #0
	csel	x10, xzr, x10, eq
	cbz	x10, LBB57_12
	lsr	x8, x8, x9
	cmp	x10, #2
	b.ne	LBB57_225
	str	x8, [sp, #152]
Lloh98:
	adrp	x8, __RNvCshOcPfIOZNXR_3log20MAX_LOG_LEVEL_FILTER@GOTPAGE
Lloh99:
	ldr	x8, [x8, __RNvCshOcPfIOZNXR_3log20MAX_LOG_LEVEL_FILTER@GOTPAGEOFF]
Lloh100:
	ldr	x8, [x8]
	cmp	x8, #4
	b.lo	LBB57_205
	add	x8, sp, #152
	str	x8, [sp, #160]
Lloh101:
	adrp	x8, __RNvXsC_NtNtCslWxY2MhVcag_4core3fmt3numyNtB7_8LowerHex3fmt@GOTPAGE
Lloh102:
	ldr	x8, [x8, __RNvXsC_NtNtCslWxY2MhVcag_4core3fmt3numyNtB7_8LowerHex3fmt@GOTPAGEOFF]
	stp	x8, xzr, [sp, #168]
Lloh103:
	adrp	x9, l_anon.9ed3183efb56324a1c787c8a9029a2a7.15@PAGE
Lloh104:
	add	x9, x9, l_anon.9ed3183efb56324a1c787c8a9029a2a7.15@PAGEOFF
	mov	w8, #12
	stp	x9, x8, [sp, #232]
Lloh105:
	adrp	x8, l_anon.9ed3183efb56324a1c787c8a9029a2a7.14@PAGE
Lloh106:
	add	x10, x8, l_anon.9ed3183efb56324a1c787c8a9029a2a7.14@PAGEOFF
	add	x8, sp, #160
	stp	x10, x8, [sp, #256]
	str	x9, [sp, #184]
	ldp	q0, q1, [sp, #48]
	str	q1, [sp, #192]
Lloh107:
	adrp	x8, l_anon.9ed3183efb56324a1c787c8a9029a2a7.0@PAGE
Lloh108:
	add	x8, x8, l_anon.9ed3183efb56324a1c787c8a9029a2a7.0@PAGEOFF
	str	x8, [sp, #208]
	stur	q0, [sp, #216]
	str	d8, [sp, #248]
Ltmp437:
	sub	x0, x29, #105
	add	x1, sp, #176
	bl	__RNvXs0_NtCshOcPfIOZNXR_3log13___private_apiNtB5_12GlobalLoggerNtB7_3Log3log
Ltmp438:
LBB57_205:
	ldr	x8, [x19, #6768]
	add	x8, x8, #1
	str	x8, [x19, #6768]
	b	LBB57_12
LBB57_206:
	ldr	x9, [x19, #5424]
	ldr	x9, [x9, x8]
	cbnz	x9, LBB57_196
	b	LBB57_199
LBB57_207:
	ldr	x8, [x19, #6896]
	cbz	x8, LBB57_212
	ldr	x9, [x8, #16]
	mov	x10, #9223372036854775806
	cmp	x9, x10
	b.hi	LBB57_231
	ldrh	w9, [x8, #24]
	mov	w10, #65535
	cmp	w9, w10
	b.eq	LBB57_212
LBB57_210:
	ldrh	w8, [x8, #26]
	strh	w9, [sp, #168]
	strh	w8, [sp, #170]
LBB57_211:
	mov	w8, #19
	b	LBB57_213
LBB57_212:
	mov	w8, #18
LBB57_213:
	str	x8, [sp, #160]
LBB57_214:
	ldr	x8, [x19, #6872]
	cmp	x8, #0
	ldp	w21, w9, [sp, #104]
	csinc	w9, w9, wzr, ne
	tbnz	w9, #0, LBB57_217
	ldr	x20, [x19, #6888]
	ldr	x9, [x19, #6880]
	ldp	x10, x9, [x9, #16]
	sub	x10, x10, #1
	and	x10, x10, #0xfffffffffffffff0
	add	x8, x8, x10
Ltmp442:
	add	x0, x8, #16
	blr	x9
Ltmp443:
	ldr	x8, [sp, #40]
	subs	x8, x0, x8
	csel	x8, xzr, x8, lo
	adds	x8, x20, x8
	csinv	x8, x8, xzr, lo
	str	x8, [x19, #6888]
LBB57_217:
	tbnz	w21, #0, LBB57_219
Ltmp444:
	add	x1, sp, #160
	mov	x0, x19
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine19end_cooperative_run
Ltmp445:
LBB57_219:
	ldr	q0, [sp, #160]
	str	q0, [sp, #176]
	add	x8, sp, #176
	; InlineAsm Start
	; InlineAsm End
	ldr	x8, [sp, #128]
	str	x8, [sp, #120]
	add	x8, sp, #120
	; InlineAsm Start
	; InlineAsm End
	ldr	x0, [sp, #120]
	.cfi_def_cfa wsp, 400
	ldp	x29, x30, [sp, #384]
	ldp	x20, x19, [sp, #368]
	ldp	x22, x21, [sp, #352]
	ldp	x24, x23, [sp, #336]
	ldp	x26, x25, [sp, #320]
	ldp	x28, x27, [sp, #304]
	ldp	d9, d8, [sp, #288]
	add	sp, sp, #400
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore b8
	.cfi_restore b9
	ret
LBB57_220:
	.cfi_restore_state
Lloh109:
	adrp	x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.1@PAGE
Lloh110:
	add	x0, x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.1@PAGEOFF
LBB57_221:
Ltmp324:
	bl	__RNvNtCslWxY2MhVcag_4core4cell22panic_already_borrowed
Ltmp325:
	b	LBB57_236
LBB57_222:
Lloh111:
	adrp	x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.13@PAGE
Lloh112:
	add	x0, x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.13@PAGEOFF
LBB57_223:
Ltmp440:
	bl	__RNvNtCslWxY2MhVcag_4core4cell30panic_already_mutably_borrowed
Ltmp441:
	b	LBB57_236
LBB57_224:
	ldr	x8, [x19, #3416]
LBB57_225:
	mov	w9, #16
	stp	x9, x8, [sp, #160]
	b	LBB57_214
LBB57_226:
	stp	x26, x27, [sp, #160]
	b	LBB57_214
LBB57_227:
	mov	w8, #1
	strh	w8, [sp, #168]
	b	LBB57_211
LBB57_228:
Lloh113:
	adrp	x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.31@PAGE
Lloh114:
	add	x0, x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.31@PAGEOFF
	b	LBB57_223
LBB57_229:
Lloh115:
	adrp	x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.2@PAGE
Lloh116:
	add	x0, x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.2@PAGEOFF
	b	LBB57_221
LBB57_230:
Lloh117:
	adrp	x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.3@PAGE
Lloh118:
	add	x0, x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.3@PAGEOFF
	b	LBB57_221
LBB57_231:
Lloh119:
	adrp	x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.32@PAGE
Lloh120:
	add	x0, x0, l_anon.9ed3183efb56324a1c787c8a9029a2a7.32@PAGEOFF
	b	LBB57_223
LBB57_232:
	mov	x25, x8
Lloh121:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.17@PAGE
Lloh122:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.17@PAGEOFF
	b	LBB57_234
LBB57_233:
Lloh123:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.16@PAGE
Lloh124:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.16@PAGEOFF
LBB57_234:
Ltmp427:
	mov	x0, x25
	bl	__RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check
Ltmp428:
	b	LBB57_236
LBB57_235:
Ltmp336:
Lloh125:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.18@PAGE
Lloh126:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.18@PAGEOFF
	mov	x0, x25
	bl	__RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check
Ltmp337:
LBB57_236:
	brk	#0x1
LBB57_237:
	mov	x25, #0
	mov	x1, #0
Lloh127:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.4@PAGE
Lloh128:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.4@PAGEOFF
	b	LBB57_234
LBB57_238:
	mov	w25, #1
Lloh129:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.5@PAGE
Lloh130:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.5@PAGEOFF
	b	LBB57_234
LBB57_239:
	mov	w25, #2
Lloh131:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.6@PAGE
Lloh132:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.6@PAGEOFF
	b	LBB57_234
LBB57_240:
	mov	w25, #3
Lloh133:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.7@PAGE
Lloh134:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.7@PAGEOFF
	b	LBB57_234
LBB57_241:
	mov	w25, #4
Lloh135:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.8@PAGE
Lloh136:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.8@PAGEOFF
	b	LBB57_234
LBB57_242:
	mov	w25, #5
Lloh137:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.9@PAGE
Lloh138:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.9@PAGEOFF
	b	LBB57_234
LBB57_243:
Lloh139:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.10@PAGE
Lloh140:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.10@PAGEOFF
	b	LBB57_234
LBB57_244:
Lloh141:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.11@PAGE
Lloh142:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.11@PAGEOFF
	b	LBB57_234
LBB57_245:
Lloh143:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.12@PAGE
Lloh144:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.12@PAGEOFF
	b	LBB57_234
LBB57_246:
Lloh145:
	adrp	x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.44@PAGE
Lloh146:
	add	x2, x2, l_anon.9ed3183efb56324a1c787c8a9029a2a7.44@PAGEOFF
	b	LBB57_234
LBB57_247:
Ltmp382:
	b	LBB57_264
LBB57_248:
Ltmp377:
	ldr	x8, [sp, #160]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB57_270
	add	x0, sp, #160
	b	LBB57_266
LBB57_250:
Ltmp372:
	b	LBB57_264
LBB57_251:
Ltmp367:
	b	LBB57_264
LBB57_252:
Ltmp362:
	b	LBB57_264
LBB57_253:
Ltmp357:
	b	LBB57_264
LBB57_254:
Ltmp352:
	b	LBB57_264
LBB57_255:
Ltmp347:
	b	LBB57_264
LBB57_256:
Ltmp333:
	b	LBB57_264
LBB57_257:
Ltmp330:
	mov	w8, #1
	ldr	x9, [x26]
	add	x8, x9, x8
	str	x8, [x26]
	bl	__RNvNtCslWxY2MhVcag_4core9panicking19panic_cannot_unwind
LBB57_258:
Ltmp323:
	mov	w8, #1
	ldr	x9, [x26]
	add	x8, x9, x8
	str	x8, [x26]
	bl	__RNvNtCslWxY2MhVcag_4core9panicking19panic_cannot_unwind
LBB57_259:
Ltmp344:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking19panic_cannot_unwind
LBB57_260:
Ltmp439:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking19panic_cannot_unwind
LBB57_261:
Ltmp390:
	mov	x8, #-1
	ldr	x9, [x26]
	add	x8, x9, x8
	str	x8, [x26]
	bl	__RNvNtCslWxY2MhVcag_4core9panicking19panic_cannot_unwind
LBB57_262:
Ltmp338:
	b	LBB57_264
LBB57_263:
Ltmp341:
LBB57_264:
	ldr	x8, [sp, #176]
	ldr	x9, [x8]
	subs	x9, x9, #1
	str	x9, [x8]
	b.ne	LBB57_270
	add	x0, sp, #176
LBB57_266:
Ltmp383:
	bl	__RNvMs6_NtCs6KVRSXc8uZF_5alloc2rcINtB5_2RcINtNtCslWxY2MhVcag_4core4cell7RefCellNtNtNtNtCs5joLtdXDRmI_12wasm_vm_core3dev6virtio4mmio10VirtioMmioEE9drop_slowB1m_
Ltmp384:
	b	LBB57_270
LBB57_267:
Ltmp385:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup
LBB57_268:
Ltmp314:
	mov	w8, #1
	ldr	x9, [x26]
	add	x8, x9, x8
	str	x8, [x26]
	bl	__RNvNtCslWxY2MhVcag_4core9panicking19panic_cannot_unwind
LBB57_269:
Ltmp446:
LBB57_270:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking19panic_cannot_unwind
	.loh AdrpLdr	Lloh90, Lloh91
	.loh AdrpLdr	Lloh96, Lloh97
	.loh AdrpAdrp	Lloh94, Lloh96
	.loh AdrpLdr	Lloh94, Lloh95
	.loh AdrpAdrp	Lloh92, Lloh94
	.loh AdrpLdr	Lloh92, Lloh93
	.loh AdrpLdrGotLdr	Lloh98, Lloh99, Lloh100
	.loh AdrpAdd	Lloh107, Lloh108
	.loh AdrpAdd	Lloh105, Lloh106
	.loh AdrpAdd	Lloh103, Lloh104
	.loh AdrpLdrGot	Lloh101, Lloh102
	.loh AdrpAdd	Lloh109, Lloh110
	.loh AdrpAdd	Lloh111, Lloh112
	.loh AdrpAdd	Lloh113, Lloh114
	.loh AdrpAdd	Lloh115, Lloh116
	.loh AdrpAdd	Lloh117, Lloh118
	.loh AdrpAdd	Lloh119, Lloh120
	.loh AdrpAdd	Lloh121, Lloh122
	.loh AdrpAdd	Lloh123, Lloh124
	.loh AdrpAdd	Lloh125, Lloh126
	.loh AdrpAdd	Lloh127, Lloh128
	.loh AdrpAdd	Lloh129, Lloh130
	.loh AdrpAdd	Lloh131, Lloh132
	.loh AdrpAdd	Lloh133, Lloh134
	.loh AdrpAdd	Lloh135, Lloh136
	.loh AdrpAdd	Lloh137, Lloh138
	.loh AdrpAdd	Lloh139, Lloh140
	.loh AdrpAdd	Lloh141, Lloh142
	.loh AdrpAdd	Lloh143, Lloh144
	.loh AdrpAdd	Lloh145, Lloh146
Lfunc_end19:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table57:
Lexception19:
	.byte	255
	.byte	155
	.uleb128 Lttbase13-Lttbaseref13
Lttbaseref13:
	.byte	1
	.uleb128 Lcst_end19-Lcst_begin19
Lcst_begin19:
	.uleb128 Ltmp300-Lfunc_begin19
	.uleb128 Ltmp307-Ltmp300
	.uleb128 Ltmp446-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp308-Lfunc_begin19
	.uleb128 Ltmp311-Ltmp308
	.uleb128 Ltmp439-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp312-Lfunc_begin19
	.uleb128 Ltmp313-Ltmp312
	.uleb128 Ltmp314-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp315-Lfunc_begin19
	.uleb128 Ltmp318-Ltmp315
	.uleb128 Ltmp439-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp319-Lfunc_begin19
	.uleb128 Ltmp322-Ltmp319
	.uleb128 Ltmp323-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp326-Lfunc_begin19
	.uleb128 Ltmp329-Ltmp326
	.uleb128 Ltmp330-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp331-Lfunc_begin19
	.uleb128 Ltmp332-Ltmp331
	.uleb128 Ltmp333-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp334-Lfunc_begin19
	.uleb128 Ltmp335-Ltmp334
	.uleb128 Ltmp439-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp339-Lfunc_begin19
	.uleb128 Ltmp340-Ltmp339
	.uleb128 Ltmp341-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp342-Lfunc_begin19
	.uleb128 Ltmp343-Ltmp342
	.uleb128 Ltmp344-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp345-Lfunc_begin19
	.uleb128 Ltmp346-Ltmp345
	.uleb128 Ltmp347-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp348-Lfunc_begin19
	.uleb128 Ltmp349-Ltmp348
	.uleb128 Ltmp439-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp350-Lfunc_begin19
	.uleb128 Ltmp351-Ltmp350
	.uleb128 Ltmp352-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp353-Lfunc_begin19
	.uleb128 Ltmp354-Ltmp353
	.uleb128 Ltmp439-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp355-Lfunc_begin19
	.uleb128 Ltmp356-Ltmp355
	.uleb128 Ltmp357-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp358-Lfunc_begin19
	.uleb128 Ltmp359-Ltmp358
	.uleb128 Ltmp439-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp360-Lfunc_begin19
	.uleb128 Ltmp361-Ltmp360
	.uleb128 Ltmp362-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp363-Lfunc_begin19
	.uleb128 Ltmp364-Ltmp363
	.uleb128 Ltmp439-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp365-Lfunc_begin19
	.uleb128 Ltmp366-Ltmp365
	.uleb128 Ltmp367-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp368-Lfunc_begin19
	.uleb128 Ltmp369-Ltmp368
	.uleb128 Ltmp439-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp370-Lfunc_begin19
	.uleb128 Ltmp371-Ltmp370
	.uleb128 Ltmp372-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp373-Lfunc_begin19
	.uleb128 Ltmp374-Ltmp373
	.uleb128 Ltmp439-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp375-Lfunc_begin19
	.uleb128 Ltmp376-Ltmp375
	.uleb128 Ltmp377-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp378-Lfunc_begin19
	.uleb128 Ltmp379-Ltmp378
	.uleb128 Ltmp439-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp380-Lfunc_begin19
	.uleb128 Ltmp381-Ltmp380
	.uleb128 Ltmp382-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp386-Lfunc_begin19
	.uleb128 Ltmp387-Ltmp386
	.uleb128 Ltmp439-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp388-Lfunc_begin19
	.uleb128 Ltmp389-Ltmp388
	.uleb128 Ltmp390-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp391-Lfunc_begin19
	.uleb128 Ltmp438-Ltmp391
	.uleb128 Ltmp439-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp442-Lfunc_begin19
	.uleb128 Ltmp428-Ltmp442
	.uleb128 Ltmp446-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp336-Lfunc_begin19
	.uleb128 Ltmp337-Ltmp336
	.uleb128 Ltmp338-Lfunc_begin19
	.byte	1
	.uleb128 Ltmp383-Lfunc_begin19
	.uleb128 Ltmp384-Ltmp383
	.uleb128 Ltmp385-Lfunc_begin19
	.byte	1
Lcst_end19:
	.byte	127
	.byte	0
	.p2align	2, 0x0
Lttbase13:
	.byte	0
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.globl	_capture_machine_unit_probe
	.p2align	2
_capture_machine_unit_probe:
Lfunc_begin20:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception20
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	str	x1, [sp]
	mov	x8, sp
	; InlineAsm Start
	; InlineAsm End
	ldr	x1, [sp]
Ltmp447:
	add	x8, sp, #16
	bl	__RNvMCs5joLtdXDRmI_12wasm_vm_coreNtB2_7Machine3run
Ltmp448:
	ldr	q0, [sp, #16]
	str	q0, [sp]
	mov	x8, sp
	; InlineAsm Start
	; InlineAsm End
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
LBB58_2:
	.cfi_restore_state
Ltmp449:
	bl	__RNvNtCslWxY2MhVcag_4core9panicking19panic_cannot_unwind
Lfunc_end20:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table58:
Lexception20:
	.byte	255
	.byte	155
	.uleb128 Lttbase14-Lttbaseref14
Lttbaseref14:
	.byte	1
	.uleb128 Lcst_end20-Lcst_begin20
Lcst_begin20:
	.uleb128 Ltmp447-Lfunc_begin20
	.uleb128 Ltmp448-Ltmp447
	.uleb128 Ltmp449-Lfunc_begin20
	.byte	1
Lcst_end20:
	.byte	127
	.byte	0
	.p2align	2, 0x0
Lttbase14:
	.byte	0
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.globl	_main
	.p2align	2
_main:
	.cfi_startproc
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x3, x1
	sxtw	x2, w0
Lloh147:
	adrp	x8, __RNvCsj7lyy62zRs3_24retirement_capture_probe4main@PAGE
Lloh148:
	add	x8, x8, __RNvCsj7lyy62zRs3_24retirement_capture_probe4main@PAGEOFF
	str	x8, [sp, #8]
Lloh149:
	adrp	x1, l_anon.9ed3183efb56324a1c787c8a9029a2a7.30@PAGE
Lloh150:
	add	x1, x1, l_anon.9ed3183efb56324a1c787c8a9029a2a7.30@PAGEOFF
	add	x0, sp, #8
	mov	w4, #0
	bl	__RNvNtCs7mRY9FNn263_3std2rt19lang_start_internal
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	ret
	.loh AdrpAdd	Lloh149, Lloh150
	.loh AdrpAdd	Lloh147, Lloh148
	.cfi_endproc

	.section	__TEXT,__cstring,cstring_literals
l_anon.9ed3183efb56324a1c787c8a9029a2a7.0:
	.asciz	"crates/core/src/lib.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.1:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.0
	.asciz	"\026\000\000\000\000\000\000\000:\022\000\000\032\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.2:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.0
	.asciz	"\026\000\000\000\000\000\000\000D\022\000\000&\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.3:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.0
	.asciz	"\026\000\000\000\000\000\000\000K\022\000\000\"\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.4:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.0
	.asciz	"\026\000\000\000\000\000\000\000P\022\000\000A\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.5:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.0
	.asciz	"\026\000\000\000\000\000\000\000^\022\000\000A\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.6:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.0
	.asciz	"\026\000\000\000\000\000\000\000d\022\000\000A\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.7:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.0
	.asciz	"\026\000\000\000\000\000\000\000k\022\000\000%\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.8:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.0
	.asciz	"\026\000\000\000\000\000\000\000t\022\000\000%\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.9:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.0
	.asciz	"\026\000\000\000\000\000\000\000z\022\000\000%\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.10:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.0
	.asciz	"\026\000\000\000\000\000\000\000\202\022\000\000A\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.11:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.0
	.asciz	"\026\000\000\000\000\000\000\000\222\022\000\000A\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.12:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.0
	.asciz	"\026\000\000\000\000\000\000\000\244\022\000\000A\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.13:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.0
	.asciz	"\026\000\000\000\000\000\000\000\263\022\000\000#\000\000"

	.section	__TEXT,__const
l_anon.9ed3183efb56324a1c787c8a9029a2a7.14:
	.asciz	"\035HTIF command ignored: tohost=\303 \000\200i\022\000"

l_anon.9ed3183efb56324a1c787c8a9029a2a7.15:
	.ascii	"wasm_vm_core"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.16:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.0
	.asciz	"\026\000\000\000\000\000\000\000W\022\000\000P\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.17:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.0
	.asciz	"\026\000\000\000\000\000\000\000W\022\000\000A\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.18:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.0
	.asciz	"\026\000\000\000\000\000\000\000X\022\000\000=\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_anon.9ed3183efb56324a1c787c8a9029a2a7.19:
	.asciz	"crates/core/src/hart/regs.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.20:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.19
	.asciz	"\034\000\000\000\000\000\000\0001\000\000\000\t\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_anon.9ed3183efb56324a1c787c8a9029a2a7.21:
	.asciz	"crates/core/src/hart/fregs.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.22:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.21
	.asciz	"\035\000\000\000\000\000\000\000 \000\000\000\t\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.23:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.21
	.asciz	"\035\000\000\000\000\000\000\000\031\000\000\000\t\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.24:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.19
	.asciz	"\034\000\000\000\000\000\000\000:\000\000\000\r\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_anon.9ed3183efb56324a1c787c8a9029a2a7.25:
	.asciz	"/rustc/88d9e12ae178fab0fb5cc050a94da85685d449ea/library/alloc/src/collections/btree/navigate.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.26:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.25
	.asciz	"_\000\000\000\000\000\000\000\306\000\000\000'\000\000"

	.section	__TEXT,__const
l_anon.9ed3183efb56324a1c787c8a9029a2a7.27:
	.ascii	"internal error: entered unreachable code: the level-0 pointer case returns a fault above"

	.section	__TEXT,__cstring,cstring_literals
l_anon.9ed3183efb56324a1c787c8a9029a2a7.28:
	.asciz	"crates/core/src/mmu.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.29:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.28
	.asciz	"\026\000\000\000\000\000\000\000\362\000\000\000\005\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.30:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNSNvYNCINvNtCs7mRY9FNn263_3std2rt10lang_startuE0INtNtNtCslWxY2MhVcag_4core3ops8function6FnOnceuE9call_once6vtableCsj7lyy62zRs3_24retirement_capture_probe
	.quad	__RNCINvNtCs7mRY9FNn263_3std2rt10lang_startuE0Csj7lyy62zRs3_24retirement_capture_probe
	.quad	__RNCINvNtCs7mRY9FNn263_3std2rt10lang_startuE0Csj7lyy62zRs3_24retirement_capture_probe

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.31:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.0
	.asciz	"\026\000\000\000\000\000\000\000\032\022\000\000H\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.32:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.0
	.asciz	"\026\000\000\000\000\000\000\000\207\023\000\000D\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.33:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.25
	.asciz	"_\000\000\000\000\000\000\000X\002\000\0000\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_anon.9ed3183efb56324a1c787c8a9029a2a7.34:
	.asciz	"crates/core/examples/retirement_capture_probe.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.35:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.34
	.asciz	"0\000\000\000\000\000\000\000(\000\000\0006\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.36:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.34
	.asciz	"0\000\000\000\000\000\000\000*\000\000\0004\000\000"

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.37:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.34
	.asciz	"0\000\000\000\000\000\000\0004\000\000\000\016\000\000"

	.section	__TEXT,__const
l_anon.9ed3183efb56324a1c787c8a9029a2a7.38:
	.ascii	"called `Result::unwrap()` on an `Err` value"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.39:
	.asciz	"\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000"
	.quad	__RNvXs1_NtCs5joLtdXDRmI_12wasm_vm_core3ramNtB5_11OutOfMemoryNtNtCslWxY2MhVcag_4core3fmt5Debug3fmt

	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.40:
	.asciz	"\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\001\000\000\000\000\000\000"
	.quad	__RNvXNtCs5joLtdXDRmI_12wasm_vm_core3busNtB2_8BusFaultNtNtCslWxY2MhVcag_4core3fmt5Debug3fmt

	.section	__TEXT,__cstring,cstring_literals
l_anon.9ed3183efb56324a1c787c8a9029a2a7.41:
	.asciz	"crates/core/src/tlb.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.42:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.41
	.asciz	"\026\000\000\000\000\000\000\000\305\000\000\000\t\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_anon.9ed3183efb56324a1c787c8a9029a2a7.43:
	.asciz	"crates/core/src/prof/histogram.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.9ed3183efb56324a1c787c8a9029a2a7.44:
	.quad	l_anon.9ed3183efb56324a1c787c8a9029a2a7.43
	.asciz	"!\000\000\000\000\000\000\000^\000\000\000#\000\000"

	.section	__TEXT,__const
l_anon.9ed3183efb56324a1c787c8a9029a2a7.45:
	.ascii	"Access"

l_anon.9ed3183efb56324a1c787c8a9029a2a7.46:
	.ascii	"Misaligned"

l_anon.9ed3183efb56324a1c787c8a9029a2a7.47:
	.ascii	"OutOfMemory"

	.p2align	3, 0x0
l_switch.table._RINvMs1_NtCs5joLtdXDRmI_12wasm_vm_core4hartNtB6_4Hart7executeNtNtB8_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.quad	8
	.quad	9
	.space	8
	.quad	11

	.p2align	3, 0x0
l_switch.table._RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu15walk_leaf_innerNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.quad	1
	.quad	5
	.quad	7

	.p2align	3, 0x0
l_switch.table._RINvNtCs5joLtdXDRmI_12wasm_vm_core3mmu16translate_cachedNtNtB4_4mmio9SystemBusECsj7lyy62zRs3_24retirement_capture_probe:
	.quad	12
	.quad	13
	.quad	15

.subsections_via_symbols
