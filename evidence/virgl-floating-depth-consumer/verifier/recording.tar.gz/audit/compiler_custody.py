"""Count physical compiler response records separately from draw associations."""
import collections
import hashlib
import json
from pathlib import Path

S = Path('/tmp/d40-fresh-critic')
result = dict(schema='D40-actual-compiler-response-accounting-v1', status='passed', audits={})
for prefix in ['hot', 'cold']:
    records = []
    for file in sorted((S/'unpacked'/prefix).glob('hardware-*/report.json')):
        envelope = json.loads(file.read_text())
        e = envelope['browserResult']['result']
        actual = collections.Counter()
        matched = 0
        for run in e['runs']:
            for request in run['requests']:
                assert request['result']['ok']
                assert request['method'] in ['stage', 'pair']
                actual[request['method']] += 1
            matched += len(run['draws'])
        values = json.loads((file.parent/'value-audit.json').read_text())
        assert values['counts']['compilerResponses'] == matched
        records.append(dict(path=prefix+'/'+file.relative_to(S/'unpacked'/prefix).as_posix(),
                            reportSha256=hashlib.sha256(file.read_bytes()).hexdigest(),
                            actualPairResponses=actual['pair'], actualStageResponses=actual['stage'],
                            perDrawMatchedResponses=matched))
    counts = {key: sum(row[key] for row in records) for key in ['actualPairResponses', 'actualStageResponses', 'perDrawMatchedResponses']}
    assert counts == dict(actualPairResponses=86, actualStageResponses=172, perDrawMatchedResponses=144)
    result['audits'][prefix] = dict(records=records, **counts, actualResponses=258)
(S/'compiler-custody.json').write_text(json.dumps(result, indent=2)+'\n')
predictions = json.loads((S/'predictions.json').read_text())
predictions['compilerAccountingCorrection'] = dict(workerWord='144 actual compiler responses',
                                                  actualPairResponses=86, actualStageResponses=172,
                                                  actualResponses=258, perDrawMatchedResponses=144,
                                                  anchor='compiler-custody.json complete source-pinned hot/cold requests arrays')
(S/'predictions.json').write_text(json.dumps(predictions, indent=2)+'\n')
print(json.dumps({key:{k:v[k] for k in ['actualPairResponses','actualStageResponses','actualResponses','perDrawMatchedResponses']} for key,v in result['audits'].items()}))
