import json,hashlib,tarfile,subprocess,gzip,posixpath
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=Path('/tmp/d40-fresh-critic');HEAD='1f8cb8c7ccdf8d58e78944a51156453a22fc5b5a';BASE='50b98a3ab6652e9d23f3eaac5eb1095023f9898d'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def git_raw(ref,name):return subprocess.check_output(['git','show',ref+':'+name],cwd=ROOT)
def reopen(folder,extract=False):
    folder=ROOT/folder;idxraw=(folder/'records.json').read_bytes();mraw=(folder/'manifest.json').read_bytes();manifest=json.loads(mraw);index=json.loads(idxraw);araw=(folder/'recording.tar.gz').read_bytes()
    assert manifest['archiveSha256']==sha(araw) and manifest['recordIndexSha256']==sha(idxraw)
    rows=index['records'];wanted={r['path']:r for r in rows};assert len(wanted)==len(rows);seen=set();total=0
    with tarfile.open(folder/'recording.tar.gz','r:gz') as t:
        for member in t:
            name=member.name;assert name in wanted and name not in seen and member.isfile() and posixpath.normpath(name)==name and not name.startswith('/') and '..' not in name.split('/')
            seen.add(name);raw=t.extractfile(member).read();row=wanted[name];assert len(raw)==row['bytes']==member.size and sha(raw)==row['sha256'],name;total+=len(raw)
            if extract:
                dest=OUT/'unpacked'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
    assert set(wanted)==seen and (manifest.get('members') or manifest['records'])==len(seen)
    return dict(path=str(folder.relative_to(ROOT)),members=len(seen),uncompressedBytes=total,archiveBytes=len(araw),digests={'archive':sha(araw),'index':sha(idxraw),'manifest':sha(mraw)},manifest=manifest)
d40=reopen('evidence/virgl-floating-depth-consumer/worker',True)
assert d40['digests']=={'archive':'44697cfa945b3ea306d44eb9fefef1e8505a56ac7aec37f538471c374f5ecba6','index':'4e1bf3fc407ec86d2897ccc1279a82d401d9061d1873d55125575a036fefd22a','manifest':'0bd79d028035888c9f7c6d3876c0c03de3b44b5fb108d035b4f7b802377bbeb5'}
source=OUT/'unpacked/source';sourcecount=0
# Single Git batch reopens every source from the claimed frozen object.
p=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for file in sorted(source.rglob('*')):
    if not file.is_file():continue
    name=file.relative_to(source).as_posix();p.stdin.write((HEAD+':'+name+'\n').encode());p.stdin.flush();header=p.stdout.readline().decode().split();assert len(header)==3 and header[1]=='blob',name
    raw=p.stdout.read(int(header[2]));assert p.stdout.read(1)==b'\n' and raw==file.read_bytes(),name;sourcecount+=1
p.stdin.close();p.wait();assert p.returncode==0
receipt_rows=[]
for prefix in ['hot','cold']:
    receipt=json.loads((OUT/'unpacked'/prefix/'receipt.json').read_text());assert receipt['gitHead']==HEAD and receipt['status']=='passed'
    for name,digest in receipt['files'].items():assert sha((OUT/'unpacked'/prefix/name).read_bytes())==digest,(prefix,name)
    for name,digest in receipt['sources'].items():
        assert sha(git_raw(HEAD,name))==digest,name
        if not name.startswith('evidence/'):assert sha((source/name).read_bytes())==digest,name
    for name,digest in receipt['generated'].items():assert sha((OUT/'unpacked'/(prefix+'-generated')/name).read_bytes())==digest
    receipt_rows.append(dict(prefix=prefix,sha256=sha((OUT/'unpacked'/prefix/'receipt.json').read_bytes()),files=len(receipt['files']),sources=len(receipt['sources']),generated=receipt['generated']))
cold=json.loads((OUT/'unpacked/cold/report.json').read_text());assert cold['status']=='passed' and cold['cloneHead']==cold['gitHead']==HEAD and cold['statusBefore']==cold['statusAfter']=='' and cold['exitCode']==0 and cold['receiptSha256']==receipt_rows[1]['sha256']
assert sha((OUT/'unpacked/cold/cold.log').read_bytes())==cold['logSha256']
d39=[]
for role in ['worker','verifier']:
    name='evidence/virgl-standard-floating-depth-images/'+role
    for file in ['recording.tar.gz','records.json','manifest.json']:assert (ROOT/name/file).read_bytes()==git_raw(BASE,name+'/'+file)
    d39.append(reopen(name))
held=json.loads((OUT/'unpacked/hot/predecessor-audit.json').read_text())
for name,digest in held['unchangedBoundaries'].items():assert sha(git_raw(BASE,name))==sha(git_raw(HEAD,name))==sha((ROOT/name).read_bytes())==digest
negative=json.loads((ROOT/'evidence/virgl-production-readiness/standard-floating-depth-consumer-gap.json').read_text());assert negative['gitHead']==BASE and len(negative['records'])==6 and not negative['nativeExecuted']
for r in negative['sources']:assert sha(git_raw(BASE,r['path']))==r['sha256'] and len(git_raw(BASE,r['path']))==r['bytes']
for r in negative['records']:assert not r['result']['ok'] and r['result']['error']['code']=='unsupported-feature'
result=dict(schema='D40-independent-complete-custody-v1',status='passed',predictionsPrecededEvidence=True,d40=d40,sourceBodiesReopened=sourcecount,receipts=receipt_rows,cold=cold,d39=d39,heldBoundaries=len(held['unchangedBoundaries']),negativeOriginalRefusals=len(negative['records']))
(OUT/'authentication.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','sourceBodiesReopened','heldBoundaries','negativeOriginalRefusals']}));print(json.dumps({'d40':{k:d40[k] for k in ['members','uncompressedBytes','archiveBytes','digests']},'d39Members':sum(r['members'] for r in d39)}))
