"""Exact additional points for each recorded D40 acceptance boundary."""
import json
from pathlib import Path

S = Path('/tmp/d40-fresh-critic')
namespace = {}
exec((S/'citations.py').read_text().split('points=[]\n')[0], namespace)
locations = namespace['locations']
U = S/'unpacked/hot'
points = []

wire = U/'wire/report.json'
points += locations(wire, [('wire', 'records', 0, 'hex'),
                          ('wire', 'records', 0, 'result', 'commands', 0, 'fields'),
                          ('wire', 'records', 0, 'refusals', 0, 'result', 'error', 'code'),
                          ('wire', 'records', 3, 'result', 'commands', 0, 'fields')])

file = U/'hardware-samples/report.json'
e = json.loads(file.read_text())['browserResult']['result']
p = ('browserResult', 'result')
pair = next(i for i, q in enumerate(e['runs'][1]['requests']) if q['method'] == 'pair')
points += locations(file, [p+('runs', 1, 'requests', pair, 'request'),
                          p+('runs', 1, 'draws', 0, 'samplers', 0),
                          p+('runs', 1, 'cache', 0, 'work', 'programLinks'),
                          p+('runs', 1, 'cache', 1, 'work', 'programLinks'),
                          p+('frames', e['runs'][1]['frames'][1], 'native'),
                          p+('frames', e['runs'][1]['frames'][1], 'backing'),
                          p+('runs', 1, 'final', 'renderer', 'budgets')])

file = U/'hardware-surfaces/report.json'
e = json.loads(file.read_text())['browserResult']['result']
points += locations(file, [p+('runs', 16, 'draws', 0, 'native', 'depth'),
                          p+('runs', 16, 'depthClear', 'depths', 0, 'planes', 0, 'native'),
                          p+('runs', 16, 'switches', 0, 'native', 'depth'),
                          p+('runs', 16, 'switches', 1, 'native', 'depth'),
                          p+('runs', 16, 'switches', 2, 'native', 'depth'),
                          p+('runs', 34, 'draws', 0, 'native', 'colors', 0, 'componentType'),
                          p+('runs', 35, 'draws', 0, 'native', 'colors', 0, 'componentType')])

file = U/'hardware-boundaries-0x13579bdf/report.json'
e = json.loads(file.read_text())['browserResult']['result']
history = e['runs'][0]['history']
requests = []
for needle in ['alias-view', 'linear-min', 'linear-mag', 'linear-mip', 'return', 'feedback']:
    selected = [(i,h) for i,h in enumerate(history) if needle in h['label'] and not h['result']['ok']]
    if selected:
        requests += [p+('runs', 0, 'history', selected[0][0], 'result')]
resources = e['runs'][0]['pending']['resources']['resources']
old = next(i for i,r in enumerate(resources) if r['id']==6 and r['generation']==e['runs'][0]['sourceGeneration'])
new = next(i for i,r in enumerate(resources) if r['id']==6 and r['public'])
requests += [p+('runs', 0, 'pending', 'resources', 'resources', old),
             p+('runs', 0, 'pending', 'resources', 'resources', new),
             p+('runs', 0, 'pending', 'renderer', 'jobs', 'status'),
             p+('runs', 0, 'pending', 'images', 'holds'),
             p+('runs', 0, 'retiredPlanes', 0, 'completion'),
             p+('runs', 0, 'retiredPlanes', 0, 'native')]
points += locations(file, requests)

for name in ['fault-sample-plane', 'fault-depth-attachment', 'fault-completed-output', 'fault-completed-depth']:
    file = U/name/'report.json'
    if 'completed-' in name:
        requests = [('partial', 'runs', 0, 'corruption')]
    else:
        requests = [('partial', 'runs', 0, 'faultEvents')]
    requests += [('partial', 'sabotage')]
    points += locations(file, requests)

(S/'acceptance-points.json').write_text(json.dumps(dict(schema='D40-acceptance-native-point-citations-v1', points=points), indent=2)+'\n')
for point in points:
    print(point['path'].split('/')[-2], point['line'], point['pointer'])
