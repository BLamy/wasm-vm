Fresh E6-T11d40 critic evidence

The records.json index lists every complete archive member and SHA256/byte count.
All 17 predictions were written before evidence inspection; predictions.json preserves their original falsifiable text and records HELD results. The seal retains all seven fresh full browser recordings, including both earlier harness qualification recordings, original input/native/public compressed bodies, physical events, screenshots, full V8 counters/source bodies, command lines, served source copies, the frozen source closure, generated compiler bytes, and audit programs/results.

Archive prefixes:
- fresh/: complete new recordings at each report's gitHead, including all seven report.json bodies.
- source-frozen/: complete outer worker source closure pinned to 1f8cb8c7ccdf8d58e78944a51156453a22fc5b5a.
- generated-frozen/: actual generated C/Wasm identities held from that frozen source.
- source-harness/: new critic test, recorder and Makefile at 05a2511cc58ba1f3bac7c649f0fc4c17728ed7c6.
- audit/: independent full-member authentication, innermost V8 counter reconstruction, state/generation/physical-custody audit, original input inverse results, source extracts, predictions, exact point citations, scoped checks and the sealer itself.

Original worker full archive and both D39 full archives remain separately committed. Their exact digests are dependencies in manifest.json; authentication.json proves reopening every one of their members. No historical evidence is reduced to a report or synopsis. Absolute scratch/report paths in audit records identify the locations used during this critic session; map fresh paths to fresh/ in this archive and /tmp/d40-fresh-critic/unpacked/{hot,cold} paths to {hot,cold}/ in the worker archive. citations.json also supplies exact JSON pointers, one-based lines and full report digests.

The unchanged independent inverse is source-frozen/tools/virgl-floating-depth-consumer/values.py; in the repository run it on any direct recording directory, adding --control for the completed-stencil control. The promoted recurring gate is make verify-E6-T11d40-critic. It requires the real native S8 corruption run to fail and requires the unchanged Python inverse to refute its full completed native body. No implementation, production/demo, guest or throughput claim is made.

Fence accounting distinguishes owned sync objects, physically consumed completion and terminal disposal without polling. All CPU collection must follow consumed completion. A disposal-only fence never authorizes a CPU read.
