#!/usr/bin/env python3
"""Independently authenticate and seal the complete fresh D40 critic recordings."""
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

ROOT = Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
SCRATCH = Path('/tmp/d40-fresh-critic')
FRESH = ROOT/'target/evidence/virgl-standard-floating-depth-consumer-critic'
OUTPUT = ROOT/'evidence/virgl-floating-depth-consumer/verifier'
FROZEN = '1f8cb8c7ccdf8d58e78944a51156453a22fc5b5a'
HARNESS = '05a2511cc58ba1f3bac7c649f0fc4c17728ed7c6'
GENERATED = {
    'renderer/virgl-shader/build/wasm/virgl-shader.mjs': '6bb07a0b2a056d21ae52b22d7700ce10577854c1cdcf0877dd80be938e30e0fa',
    'renderer/virgl-shader/build/wasm/virgl-shader.wasm': 'acbe036afcdc4f1d8aa8cfb0fb107f48ba27759a6af4a7b9d6c83e3aa679d6cc',
}
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def pinned_batch(head, rows):
    requests = b''.join((head+':'+name+'\n').encode() for name in rows)
    result = subprocess.run(['git', 'cat-file', '--batch'], input=requests,
                            stdout=subprocess.PIPE, check=True, cwd=ROOT).stdout
    at = 0
    for name in rows:
        end = result.index(b'\n', at)
        identity, kind, size = result[at:end].split()
        assert kind == b'blob', (head, name, result[at:end])
        size = int(size)
        body = result[end+1:end+1+size]
        assert result[end+1+size:end+2+size] == b'\n'
        at = end+2+size
        yield name, body
    assert at == len(result)


def tree(prefix, directory):
    for file in sorted(directory.rglob('*')):
        assert not file.is_symlink(), file
        if file.is_file():
            yield prefix+'/'+file.relative_to(directory).as_posix(), file


def main():
    assert git('rev-parse', 'HEAD').decode().strip() == HARNESS
    assert not git('diff', '--name-only', 'HEAD').strip()
    authenticated = json.loads((SCRATCH/'authentication.json').read_text())
    assert authenticated['status'] == 'passed'
    entries = dict(tree('fresh', FRESH))
    entries.update(tree('source-frozen', SCRATCH/'unpacked/source'))
    entries.update(tree('generated-frozen', SCRATCH/'unpacked/hot-generated'))
    for file in sorted(SCRATCH.iterdir()):
        if file.is_file():
            entries['audit/'+file.name] = file
    for name in ['Makefile', 'renderer/virgl-command/tests/standard-floating-depth-consumer-critic.mjs',
                 'tools/verify-virgl-standard-floating-depth-consumer-critic.mjs']:
        entries['source-harness/'+name] = ROOT/name
    for prefix in ['source-frozen', 'source-harness']:
        rows = {name[len(prefix)+1:]: file for name, file in entries.items() if name.startswith(prefix+'/')}
        for name, original in pinned_batch(FROZEN if prefix == 'source-frozen' else HARNESS, rows):
            assert rows[name].read_bytes() == original, (prefix, name)

    records = []
    for file in sorted(FRESH.rglob('report.json')):
        report = json.loads(file.read_text())
        if report.get('task') != 'E6-T11d40' or 'browserResult' not in report:
            continue
        head = report['gitHead']
        rows = {row['path']: row for row in report['sources'] if row['path'] not in GENERATED}
        assert len(rows)+len(GENERATED) == len(report['sources'])
        for name, original in pinned_batch(head, rows):
            row = rows[name]
            assert len(original) == row['bytes'] and sha(original) == row['sha256']
            assert (file.parent/'source'/name).read_bytes() == original
        for row in report['sources']:
            if row['path'] in GENERATED:
                assert row['sha256'] == GENERATED[row['path']]
                original = (file.parent/'source'/row['path']).read_bytes()
                assert len(original) == row['bytes'] and sha(original) == row['sha256']
        for name in ['browserCoverage', 'screenshot']:
            row = report[name]
            assert sha((file.parent/row['path']).read_bytes()) == row['sha256']
        assert report['browserErrors'] == {'console': [], 'page': [], 'requests': []}
        evidence = report.get('partial') or report['browserResult']['result']
        keys = set()
        for blob in evidence['blobs']:
            assert blob['key'] not in keys
            keys.add(blob['key'])
            compressed = (file.parent/blob['path']).read_bytes()
            assert sha(compressed) == blob['gzipSha256']
            raw = gzip.decompress(compressed)
            assert len(raw) == blob['bytes'] and sha(raw) == blob['sha256']
        value = json.loads((file.parent/'value-audit.json').read_text())
        fault = 'fault-completed-stencil' in file.parts
        assert report['status'] == ('failed' if fault else 'passed')
        assert value['status'] == ('refuted' if fault else 'passed')
        records.append(dict(path='fresh/'+file.relative_to(FRESH).as_posix(), sourceHead=head,
                            sha256=sha(file.read_bytes()), status=report['status'],
                            inverseStatus=value['status'], inverseSha256=sha((file.parent/'value-audit.json').read_bytes()),
                            counts=value['counts'], blobs=len(keys)))
    assert len(records) == 7
    for name, digest in GENERATED.items():
        assert sha(entries['generated-frozen/'+name].read_bytes()) == digest
    state = json.loads((SCRATCH/'state-audit.json').read_text())
    assert state['status'] == 'passed' and len(state['records']) == 25
    totals = {key: sum(row['counts'][key] for row in state['records']) for key in state['records'][0]['counts']}
    for directory in [ROOT/'evidence/virgl-floating-depth-consumer/worker',
                      ROOT/'evidence/virgl-standard-floating-depth-images/worker',
                      ROOT/'evidence/virgl-standard-floating-depth-images/verifier']:
        expected = authenticated['d40'] if directory.name == 'worker' and 'virgl-floating-depth-consumer' in directory.parts else next(r for r in authenticated['d39'] if r['path'] == directory.relative_to(ROOT).as_posix())
        for name, key in [('recording.tar.gz', 'archive'), ('records.json', 'index'), ('manifest.json', 'manifest')]:
            assert sha((directory/name).read_bytes()) == expected['digests'][key]
    indexed = []
    for name, file in sorted(entries.items()):
        path = PurePosixPath(name)
        assert not path.is_absolute() and '..' not in path.parts
        raw = file.read_bytes()
        indexed.append(dict(path=name, bytes=len(raw), sha256=sha(raw)))
    assert len(indexed) == len(entries)
    index = (json.dumps(dict(schema='fresh-d40-critic-records-v1', task='E6-T11d40',
                             frozenRuntimeHead=FROZEN, verifierHarnessHead=HARNESS,
                             records=indexed), indent=2)+'\n').encode()
    OUTPUT.mkdir(parents=True, exist_ok=True)
    (OUTPUT/'records.json').write_bytes(index)
    archive_path = OUTPUT/'recording.tar.gz'
    with archive_path.open('wb') as output:
        with gzip.GzipFile(filename='', fileobj=output, mode='wb', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for row in indexed:
                    raw = entries[row['path']].read_bytes()
                    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
                    info = tarfile.TarInfo(row['path'])
                    info.size, info.mtime, info.mode = len(raw), 0, 0o644
                    archive.addfile(info, io.BytesIO(raw))
    assert archive_path.stat().st_size < 100*1024*1024
    by_name = {row['path']: row for row in indexed}
    reopened = set()
    with tarfile.open(archive_path, 'r:gz') as archive:
        for entry in archive:
            assert entry.isfile() and entry.name not in reopened and entry.name in by_name
            reopened.add(entry.name)
            raw = archive.extractfile(entry).read()
            row = by_name[entry.name]
            assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    assert reopened == set(by_name)
    manifest = dict(schema='fresh-d40-critic-seal-v1', task='E6-T11d40',
                    frozenRuntimeHead=FROZEN, verifierHarnessHead=HARNESS,
                    archiveSha256=sha(archive_path.read_bytes()), archiveBytes=archive_path.stat().st_size,
                    recordIndexSha256=sha(index), members=len(indexed), reopenedMembers=len(reopened),
                    fullUncompressedBytes=sum(row['bytes'] for row in indexed),
                    workerDependency=authenticated['d40']['digests'],
                    heldD39Dependencies=[dict(path=row['path'], members=row['members'], digests=row['digests']) for row in authenticated['d39']],
                    records=records, stateAuditRecordings=25, stateAuditTotals=totals,
                    stateAuditCounterUnits={'compilerPairs': 'draw associations with an actual original-TGSI pair response; cached responses may serve multiple draws'},
                    workerAccountingPerPositiveReceipt=dict(ownedSyncs=2485, consumedSyncs=2479,
                                                            disposalRetiredUnconsumedSyncs=6,
                                                            actualPairResponses=86, actualStageResponses=172,
                                                            actualCompilerResponses=258, perDrawMatchedResponses=144),
                    sourceClosureIncluded=True, generated=GENERATED, predictionsHeld=17,
                    implementationEdits=False, coldCloneRepeated=False,
                    guestExecution=False, productionNegotiation=False, productionDrawAuthority=False,
                    authority='isolated-original-floating-depth-consumers')
    (OUTPUT/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(json.dumps({key: manifest[key] for key in ['members', 'reopenedMembers', 'fullUncompressedBytes', 'archiveBytes', 'archiveSha256', 'recordIndexSha256', 'stateAuditTotals']}))
    print('manifestSha256='+sha((OUTPUT/'manifest.json').read_bytes()))


if __name__ == '__main__':
    main()
