import json,bisect,hashlib
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');U=Path('/tmp/d40-fresh-critic/unpacked');F=ROOT/'target/evidence/virgl-standard-floating-depth-consumer-critic';OUT=Path('/tmp/d40-fresh-critic');sha=lambda x:hashlib.sha256(x).hexdigest()
def locations(file,wanted):
 text=file.read_text();newlines=[i for i,c in enumerate(text) if c=='\n'];decoder=json.JSONDecoder();found={};wanted={tuple(v) for v in wanted}
 def white(i):
  while i<len(text) and text[i].isspace():i+=1
  return i
 def visit(i,path):
  i=white(i)
  if path in wanted:found[path]=dict(line=bisect.bisect_left(newlines,i)+1,value=decoder.raw_decode(text,i)[0])
  if not any(p[:len(path)]==path for p in wanted):return decoder.raw_decode(text,i)[1]
  if text[i]=='{':
   i=white(i+1)
   while text[i]!='}':
    key,i=decoder.raw_decode(text,i);i=white(i);assert text[i]==':';i=white(visit(i+1,path+(key,)));assert text[i] in ',}'
    if text[i]==',':i=white(i+1)
   return i+1
  if text[i]=='[':
   i=white(i+1);index=0
   while text[i]!=']':
    i=white(visit(i,path+(index,)));index+=1;assert text[i] in ',]'
    if text[i]==',':i=white(i+1)
   return i+1
  return decoder.raw_decode(text,i)[1]
 visit(0,());assert set(found)==wanted
 return [dict(path=str(file),sha256=sha(file.read_bytes()),pointer='/'+'/'.join(map(str,p)),**v) for p,v in found.items()]
points=[]
for prefix in ['hot','cold']:
 for file in sorted((U/prefix).glob('hardware-boundaries-*/report.json')):
  e=json.loads(file.read_text())['browserResult']['result'];wanted=[]
  for i,r in enumerate(e['runs']):
   for j,s in enumerate(r['fenceObjects']):
    if 'completed' not in s:wanted += [('browserResult','result','runs',i,'fenceObjects',j)]
  points+=locations(file,wanted)
positive=F/'promoted/report.json';control=F/'fault-completed-stencil/report.json'
points+=locations(positive,[('browserResult','result','runs',0,'boundaries',1,'result','error','code'),('browserResult','result','runs',0,'sourceGeneration'),('browserResult','result','runs',0,'clearEvents',0),('browserResult','result','frames',3,'native')])
points+=locations(control,[('partial','runs',0,'corruption'),('partial','frames',3,'depths',1,'planes',2,'native'),('partial','sabotage'),('partial','runs',0,'fenceObjects',55)])
(OUT/'citations.json').write_text(json.dumps(dict(schema='D40-reopenable-native-evidence-points-v1',points=points),indent=2)+'\n')
for p in points:print(p['path'].split('/')[-2],p['line'],p['pointer'],str(p['value'])[:160])
