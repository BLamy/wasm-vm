import json,re,struct,hashlib,gzip
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');U=Path('/tmp/d40-fresh-critic/unpacked');F=ROOT/'target/evidence/virgl-standard-floating-depth-consumer-critic';OUT=Path('/tmp/d40-fresh-critic');sha=lambda raw:hashlib.sha256(raw).hexdigest()
def packets(text):
 raw=bytes.fromhex(text);at=0
 while at<len(raw):
  header=struct.unpack_from('<I',raw,at)[0];end=at+4*((header>>16)+1);assert end<=len(raw)
  yield header&255,header>>8&255,list(struct.unpack_from('<'+'I'*(header>>16),raw,at+4)),raw[at:end]
  at=end
 assert at==len(raw)
def audit(file):
 envelope=json.loads(file.read_text());e=envelope.get('partial') or envelope['browserResult']['result'];assert envelope['browserErrors']==dict(console=[],page=[],requests=[])
 assert 'M4 Max' in e['gpu'] and 'Metal' in e['gpu'];assert envelope['browser']['headless'] is False and envelope['browser']['gpu']['featureStatus'].get('webgl2',envelope['browser']['gpu']['featureStatus'].get('webgl'))=='enabled'
 assert not any(re.search(r'swiftshader|llvmpipe|softpipe|lavapipe|--disable-gpu(?:$|=)',s,re.I) for s in envelope['browser']['commandLine'])
 counts=dict(runs=0,draws=0,refusals=0,queued=0,cpuReads=0,ownedSyncs=0,consumedSyncs=0,disposalRetiredUnconsumedSyncs=0,nativeObjects=0,compilerPairs=0,privateNativeBindings=0);points=[]
 for ri,r in enumerate(e['runs']):
  counts['runs']+=1;source=next(a for a in r['allocations'] if a['metadata']['id']==6);target=next(a for a in r['allocations'] if a['metadata']['id']==1);draws={d['label']:d for d in r['draws']};contexts={}
  for hi,h in enumerate(r['history']):
   ctx=contexts.setdefault(h['ctx'],dict(shader={},stage={},view={},bound={},surfaces={},colors={},depth=None))
   if 'refuse-' in h['label'] or h['label']=='critic-inclusive-last-level-feedback' or 'historical-refusal' in h['label']:
    assert not h['result']['ok'];assert not h['result'].get('draws',[])
    forbidden=[ev for ev in r['events'] if ev['label']==h['label'] and (ev['name']=='blitFramebuffer' or re.match('draw(?:Arrays|Elements)',ev['name']))]
    assert not forbidden,(h['label'],forbidden);counts['refusals']+=1
   for ci,(op,kind,w,raw) in enumerate(packets(h['hex'])):
    if ci>=h['result'].get('appliedCommands',h.get('appliedBeforeDispose',0)):continue
    if op==1 and kind==4:ctx['shader'][w[0]]=raw[24:24+w[2]-1].decode('ascii')
    elif op==31:ctx['stage'][w[1]]=ctx['shader'][w[0]]
    elif op==1 and kind==6:ctx['view'][w[0]]=dict(resource=w[1],format=w[2]&0xffffff,first=w[4]&255,last=w[4]>>8&255,swizzle=[w[5]>>(3*i)&7 for i in range(4)])
    elif op==10:
     for slot,handle in enumerate(w[2:],w[1]):ctx['bound'][w[0],slot]=ctx['view'].get(handle)
    elif op==1 and kind==8:ctx['surfaces'][w[0]]=dict(resource=w[1],format=w[2],level=w[3])
    elif op==5:ctx['depth']=ctx['surfaces'].get(w[1]);ctx['colors']={i:ctx['surfaces'][v] for i,v in enumerate(w[2:]) if v}
    elif op==8:
     counts['draws']+=1;d=draws[h['label']];pairs=[q for q in r['requests'] if q['method']=='pair' and q['result']['ok'] and q['request']['vertexText']==ctx['stage'][0] and q['request']['fragmentText']==ctx['stage'][1]];assert pairs;counts['compilerPairs']+=1
     # Compiler-pair original TGSI is authority; native GLSL may contain checked raster/interface lowering.
     for sh in d['shaders']:assert any(ev['name']=='shaderSource' and ev['args'][1]==sh['glsl'] for ev in r['events'])
     if r['kind']=='sample':
      stage,text=next((s,t) for s,t in ctx['stage'].items() if re.search(r'\b(TXF|TXL|TEX|TXD|TXB|TXQ)\b',t));slot=int(re.search(r'DCL SAMP\[(\d+)\]',text)[1]);view=ctx['bound'][stage,slot];sm=d['samplers'][0];m=sm['metadata'];assert len(d['samplers'])==1 and sm['unit']==(16 if stage==0 else 0)+slot and sm['type']==35678
      if not envelope.get('fault'):
       assert m['id']==6 and m['format']==r['format'];assert m['width']==max(1,source['metadata']['width']>>view['first']) and m['height']==max(1,source['metadata']['height']>>view['first']) and m['lastLevel']==view['last']-view['first']
       assert sm['base']==0 and sm['last']==view['last']-view['first'];assert (sm['texture']==source['texture'])==(view['first']==0 and view['last']==source['metadata']['lastLevel'])
       counts['privateNativeBindings']+=sm['texture']!=source['texture']
     if h['label'].startswith('floating-queued-'):
      counts['queued']+=1;p=r['pending'];old=next(x for x in p['resources']['resources'] if x['id']==6 and x['generation']==r['sourceGeneration']);fresh=next(x for x in p['resources']['resources'] if x['id']==6 and x['public']);assert not old['public'] and old['references']>0 and fresh['format']!=old['format'] and fresh['generation']>old['generation']
      assert p['renderer']['jobs']['status']=='finishing' and p['images']['holds']>=2 and p['resources']['budgets']['imageHolds']>=2
      assert d['native']['colors'][0]['attachment']==target['texture'];assert d['samplers'][0]['metadata']['format']==old['format']
      if r['terminalMode'] in ['complete','cancel']:
       retired=next(x for x in r['retiredPlanes'] if x['texture']==target['texture']);assert retired['completion']['sequence']>d['sequence'];points.append(dict(run=ri,kind='queued',label=h['label'],oldSourceGeneration=old['generation'],freshSourceGeneration=fresh['generation'],targetTexture=target['texture'],drawSequence=d['sequence'],retiredNativeCompletion=retired['completion'],nativeBlob=retired['native']))
   if 'cache' in r:assert r['cache'][0]['work']['programLinks']==r['cache'][1]['work']['programLinks']
  syncs={s['id']:s for s in r['fenceObjects']};assert len(syncs)==len(r['fenceObjects']);writer=0
  for ev in r['events']:
   if ev['name'] in ['drawArrays','drawElements','drawArraysInstanced','drawElementsInstanced','clearBufferiv','clearBufferuiv','clearBufferfv','clear','texSubImage2D','bufferSubData','copyBufferSubData']:writer=ev['sequence']
   if ev['name'] in ['readPixels','getBufferSubData'] and ev['cpu']:
    c=ev['completion'];s=syncs[c['sync']];assert ev['sequence']>c['sequence']>writer and s['createdSequence']>writer and c['actual'] in [37146,37148] and c['delivered'] in [37146,37148];assert any(p['sequence']==c['sequence'] and p['actual']==c['actual'] and p['delivered']==c['delivered'] for p in s['polls']);counts['cpuReads']+=1
  for s in syncs.values():
   assert s['identity']=='WebGLSync' and s['deleted']==1;counts['ownedSyncs']+=1
   if 'completed' in s:
    assert s['completed']['actual'] in [37146,37148];counts['consumedSyncs']+=1
   else:
    assert r.get('terminalMode') in ['renderer-dispose','resource-dispose'] and not s['polls'];counts['disposalRetiredUnconsumedSyncs']+=1
    points.append(dict(run=ri,kind='terminal-disposal-retires-unpolled-fence',terminalMode=r['terminalMode'],fence=s))
  assert all(obj['deleted']==1 for obj in r['nativeObjects']);counts['nativeObjects']+=len(r['nativeObjects'])
  assert all(n==0 for key in ['renderer','resources'] for n in r['final'][key]['budgets'].values());assert r['final']['images']['views']==r['final']['images']['allocations']==r['final']['images']['holds']==0 and r['final']['renderer']['jobs']['active']==0
  if 'corruption' in r:
   c=r['corruption'];assert c['after']['sync']!=c['before']['sync'] and c['after']['sequence']>c['before']['sequence'] and c['after']['actual'] in [37146,37148];assert syncs[c['after']['sync']]['createdSequence']>c['before']['sequence'];points.append(dict(run=ri,kind='actual-completed-native-corruption',corruption=c))
 return dict(path=str(file),sha256=sha(file.read_bytes()),status='passed',counts=counts,points=points)
files=[]
for prefix in ['hot','cold']:files+=sorted((U/prefix).glob('hardware-*/report.json'))+sorted((U/prefix).glob('fault-*/report.json'))
files+=sorted(F.glob('boundaries-*/report.json'))+[F/'promoted/report.json',F/'fault-completed-stencil/report.json']
files+=sorted((F/'initial-qualified-harness').glob('*/report.json'))
result=dict(schema='D40-independent-original-state-generation-and-physical-custody-v1',status='passed',records=[audit(f) for f in files]);(OUT/'state-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'passed','recordings':len(result['records']),'counts':{k:sum(r['counts'][k] for r in result['records']) for k in result['records'][0]['counts']}}))
