import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');U=Path('/tmp/d40-fresh-critic/unpacked');OUT=Path('/tmp/d40-fresh-critic');BASE='50b98a3ab6652e9d23f3eaac5eb1095023f9898d';HEAD='1f8cb8c7ccdf8d58e78944a51156453a22fc5b5a'
sha=lambda raw:hashlib.sha256(raw).hexdigest();added={};name=None;line=0
for row in subprocess.check_output(['git','diff','--unified=0',BASE,HEAD,'--','renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs'],cwd=ROOT,text=True).splitlines():
 if row.startswith('+++ b/'):name=row[6:]
 elif row.startswith('@@'):line=int(re.search(r'\+(\d+)',row)[1])
 elif row.startswith('+') and name:added.setdefault(name,[]).append(line);line+=1
 elif row.startswith(' '):line+=1
waivers=json.loads((U/'source/tools/virgl-floating-depth-consumer/coverage-waivers.json').read_text())['waivers'];known={(r['source'],r['startOffset'],r['endOffset']):r for r in waivers};assert len(known)==len(waivers)
result={'schema':'D40-independent-innermost-coverage-v1','frozenHead':HEAD,'baseHead':BASE,'audits':{}}
for prefix in ['hot','cold']:
 D=U/prefix;scripts=[]
 for file in sorted(D.glob('*/browser-coverage.json')):
  if file.parent.name.startswith('fault-'):continue
  for row in json.loads(file.read_text())['scripts']:
   if row['source'] not in added:continue
   raw=(U/'source'/row['source']).read_bytes();assert sha(raw)==row['sha256'];assert row.get('sourceBody',raw.decode()).encode()==raw
   report=json.loads((file.parent/'report.json').read_text());assert any(s['path']==row['source'] and s['sha256']==sha(raw) for s in report['sources']);assert any(s['path']=='/'+row['source'] and s['sha256']==sha(raw) for s in report['servedFiles'])
   scripts.append(dict(record=file.relative_to(U).as_posix(),**row))
 for file in sorted((D/'node-coverage').glob('*.json')):
  for row in json.loads(file.read_text())['result']:
   for name in added:
    if row['url'].endswith('/'+name):scripts.append(dict(record=file.relative_to(U).as_posix(),source=name,sha256=sha((U/'source'/name).read_bytes()),coverage=row))
 partitions=[];pinned=[];positive=0;unproven=[]
 for name,lines in added.items():
  text=(U/'source'/name).read_text();u=text.encode('utf-16-le');offsets=[0]
  for row in text.splitlines(keepends=True):offsets.append(offsets[-1]+len(row.encode('utf-16-le'))//2)
  old=subprocess.check_output(['git','show',BASE+':'+name],cwd=ROOT);oldu=old.decode().encode('utf-16-le')
  observed=[s for s in scripts if s['source']==name]
  for line in lines:
   start,end=offsets[line-1],offsets[line];points={start,end}
   for script in observed:
    for fn in script['coverage']['functions']:
     for r in fn['ranges']:
      points.update(v for v in [r['startOffset'],r['endOffset']] if start<v<end)
   points=sorted(points)
   for a,b in zip(points,points[1:]):
    counters=[]
    for script in observed:
     ranges=[r for fn in script['coverage']['functions'] for r in fn['ranges'] if r['startOffset']<=a and b<=r['endOffset']]
     if ranges:counters.append(dict(record=script['record'],**min(ranges,key=lambda r:r['endOffset']-r['startOffset'])))
    text=u[a*2:b*2].decode('utf-16-le');part=dict(source=name,line=line,startOffset=a,endOffset=b,text=text,counters=counters,executed=any(c['count']>0 for c in counters));partitions.append(part)
    if part['executed']:positive+=1;continue
    w=known.get((name,a,b));assert w and w['text']==text and w['sha256']==sha(text.encode()),part
    assert w['classification']=='unchanged-operand' and w['predecessorSourceSha256']==sha(old) and oldu[w['predecessorStartOffset']*2:w['predecessorEndOffset']*2].decode('utf-16-le')==text and not re.search('floatingDepth(?:Format)?',text),w
    pinned.append(dict(**part,waiver=w))
 advertised=json.loads((D/'coverage-audit.json').read_text());assert positive==advertised['positive'] and len(pinned)==len(advertised['waived']) and not advertised['zero']
 assert len(partitions)==positive+len(pinned) and positive==305 and len(pinned)==24
 result['audits'][prefix]=dict(positive=positive,exactPinnedUnchangedOperands=len(pinned),unproven=unproven,partitions=partitions,pinned=pinned,scripts=[dict(source=s['source'],record=s['record'],sha256=s['sha256']) for s in scripts])
(OUT/'coverage-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:{n:v[n] for n in ['positive','exactPinnedUnchangedOperands','unproven']} for k,v in result['audits'].items()}))
