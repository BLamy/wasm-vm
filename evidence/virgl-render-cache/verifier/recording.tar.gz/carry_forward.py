import json,hashlib,subprocess
from pathlib import Path
O=Path('evidence/virgl-render-cache/verifier');U=O/'unpacked';BASE='bc2c619f72c0bb13ced896411829cd19954ba163';HEAD='6ec98cebea12fc9551e333746d9616999be1e5d2'
unchanged=['renderer/virgl-shader','renderer/virgl-command/resources.mjs','renderer/virgl-command/decoder.mjs','renderer/virgl-command/constant-domain.mjs','renderer/virgl-command/tests/raster-depth.mjs','renderer/virgl-command/tests/inline-uploads.mjs','renderer/virgl-command/tests/state-acceptance.mjs','renderer/virgl-command/tests/async-acceptance.mjs','renderer/virgl-command/tests/draw-acceptance.mjs']
for path in unchanged:assert subprocess.check_output(['git','diff','--name-only',BASE,HEAD,'--',path])==b''
rows=[]
for env in ['hot','cold']:
 rpath=U/env/'regression/regression/regression/views/report.json';r=json.loads(rpath.read_bytes());x=r['browserResult']['result'];assert r['status']=='passed';assert all(q['held'] for q in x['assertions'])
 failures=x['flat']['faults'];held=0
 for z in failures:
  f=z['failure'];a=f['before'];b=f['after'];assert a['contexts']==b['contexts'];native=lambda s:{k:v for k,v in s['budgets'].items() if k!='cacheBytes'};assert native(a)==native(b);assert f['liveBefore']==f['liveAfter'];assert b['work']['failedSubmissions']==a['work']['failedSubmissions']+1;held+=1
 assert len(x['budgets']['failures'])==len(failures)==12 and len(x['checkedOutput'])==6
 assert [(p['short'],p['result']['ok']) for p in x['budgets']['pressure']]==[(0,True),(1,False)]
 named=[q for q in x['assertions'] if any(s in q['prediction'] for s in ['exact native charge rollback','exact native name rollback','one program pressure','no partial charge','no temporary native names'])]
 assert named and all(q['held'] for q in named)
 rows.append({'record':str(rpath.relative_to(U)),'sha256':hashlib.sha256(rpath.read_bytes()).hexdigest(),'flatFailureBeforeAfterChecks':held,'formatNativeFaults':12,'uncachedOutputGuards':6,'namedQuotaRollbackPredicates':named})
h=json.loads(Path('evidence/virgl-raster-depth/worker/manifest.json').read_bytes());assert hashlib.sha256(Path('evidence/virgl-raster-depth/worker/recording.tar.gz').read_bytes()).hexdigest()==h['archiveSha256'];assert hashlib.sha256(Path('evidence/virgl-raster-depth/worker/records.json').read_bytes()).hexdigest()==h['recordIndexSha256']
hrecords=json.loads(Path('evidence/virgl-raster-depth/worker/records.json').read_bytes())['records'];hg={r['path'].split('/renderer/',1)[-1]:r['sha256'] for r in hrecords if r['path'].startswith('hot-generated/')};i=json.loads((U/'hot/receipt.json').read_bytes())['generated']
compiler=[]
for key,d in i.items():
 suffix=key.split('renderer/',1)[-1];assert hg[suffix]==d;compiler.append({'path':key,'sha256':d,'unchangedFromH':True})
result={'status':'HELD','base':BASE,'source':HEAD,'unchangedBoundaries':unchanged,'unchangedGeneratedCompiler':compiler,'predecessorHArchiveSha256':h['archiveSha256'],'predecessorHIndexSha256':h['recordIndexSha256'],'retainedChecks':rows,'waiver':'Wrapper changes outside affected execution only add cache.mjs to transport/source or coverage module lists. They introduce no additional runtime branch. Types/docs/queue/target declarations have direct syntax/policy gates; runtime added comments/punctuation are waived individually in coverage ledger. No Rust/compiler numerical changes are present.'};(O/'carry-forward.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'unchangedBoundaryPaths':len(unchanged),'unchangedCompiler':compiler,'nativeFailureChecks':[(r['flatFailureBeforeAfterChecks'],r['formatNativeFaults'],r['uncachedOutputGuards']) for r in rows]},indent=2))
