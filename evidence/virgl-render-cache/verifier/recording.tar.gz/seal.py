import hashlib,gzip,io,json,tarfile
from pathlib import Path
O=Path('evidence/virgl-render-cache/verifier');HEAD='6ec98cebea12fc9551e333746d9616999be1e5d2';sha=lambda x:hashlib.sha256(x).hexdigest()
for name in ['authentication.json','recording-audit.json','coverage-audit.json','carry-forward.json','novel-audit.json','final-audits.json']:assert json.loads((O/name).read_text())['status']=='HELD'
names=['predictions.json','authentication.json','recording-audit.json','coverage-audit.json','carry-forward.json','novel-audit.json','final-audits.json','final-audits.log','task-diff.patch','authenticate.py','audit_recording.py','audit_coverage.py','carry_forward.py','final_audits.py','seal.py','cache-boundaries.mjs','run-boundaries.mjs']
members={name:(O/name).read_bytes() for name in names};members['promoted-source.mjs']=Path('renderer/virgl-command/tests/cache-boundaries.mjs').read_bytes()
for directory in ['independent-hardware','independent-hash-collision','independent-fault-blend','independent-fault-text','novel-physical-final','sabotage-scissor','promoted-physical','promoted-sabotage']:
 for p in sorted((O/directory).rglob('*')):
  if p.is_file():members[p.relative_to(O).as_posix()]=p.read_bytes()
index={'schema':'virgl-cache-critic-records-v1','task':'E6-T12i','sourceHead':HEAD,'workerArchiveSha256':'ad9165fcca40cca50382079c4df648d37525951bbae2e0b17012c236e9b097b7','records':[{'path':name,'bytes':len(raw),'sha256':sha(raw)} for name,raw in sorted(members.items())]};iraw=(json.dumps(index,indent=2)+'\n').encode();(O/'records.json').write_bytes(iraw)
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0) as zip:
 with tarfile.open(fileobj=zip,mode='w') as tar:
  for name,raw in sorted(members.items()):
   info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(raw))
packed=buffer.getvalue();(O/'recording.tar.gz').write_bytes(packed)
with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as tar:
 assert len(tar.getmembers())==len(members)
 for m in tar.getmembers():assert m.isfile() and sha(tar.extractfile(m).read())==sha(members[m.name])
manifest={'schema':'virgl-cache-critic-seal-v1','task':'E6-T12i','sourceHead':HEAD,'verdict':'verified','records':len(members),'archiveBytes':len(packed),'archiveSha256':sha(packed),'recordIndexSha256':sha(iraw),'workerArchiveSha256':index['workerArchiveSha256'],'coverageAuditSha256':sha(members['coverage-audit.json']),'finalAuditSha256':sha(members['final-audits.json']),'promotedModuleSha256':sha(members['promoted-source.mjs']),'authority':'isolated-bounded-render-caches','guestExecution':False,'productionDrawAuthority':False,'predictionResults':{f'P{i}':'HELD' for i in range(9)}};(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
