import json,hashlib,subprocess
from pathlib import Path
O=Path('evidence/virgl-render-cache/verifier');HEAD='6ec98cebea12fc9551e333746d9616999be1e5d2'
def sha(b):return hashlib.sha256(b).hexdigest()
def original(name):return subprocess.check_output(['git','show',HEAD+':'+name])
checks=[]
for name in ['independent-hardware','independent-hash-collision','independent-fault-blend','independent-fault-text','promoted-physical','promoted-sabotage']:
 at=O/name;r=json.loads((at/'report.json').read_bytes());served={x['path']:x for x in r['servedFiles']}
 for x in r['sources']:
  expected=sha((Path.cwd()/x['path']).read_bytes()) if '/build/wasm/' in x['path'] else sha(original(x['path']))
  assert expected==x['sha256'],name+' source mismatch'
  if '/'+x['path'] in served:
   fault=r.get('mutation',r.get('sabotage',{}));wanted=fault['servedSha256'] if fault.get('path')==x['path'] else x['sha256'];assert served['/'+x['path']]['sha256']==wanted
 assert r['browserErrors']=={'console':[],'page':[],'requests':[]};assert r['browser']['headless'] is False and r['browser']['gpu']['featureStatus'].get('webgl2',r['browser']['gpu']['featureStatus'].get('webgl'))=='enabled';assert not any(any(s in a.lower() for s in ['swiftshader','llvmpipe','softpipe','lavapipe','--disable-gpu']) for a in r['browser']['commandLine'])
 for s in json.loads((at/'browser-coverage.json').read_text())['scripts']:assert s['sha256']==served['/'+s['source']]['sha256']
 result=r.get('result',r.get('browserResult'))
 pixel_bytes=0
 if name.startswith('independent-') and 'fault' not in name:
  assert r['status']==result['status']=='passed';x=result['result'];assert all(p['held'] for p in x['assertions']);b=(at/'toggles.rgba').read_bytes();assert len(b)==10240000 and sha(b)==r['physicalPixels']['sha256'];patterns=[bytes([255,0,0,64])*256,bytes([64,0,191,255])*256]
  for i in range(10000):assert b[i*1024:(i+1)*1024]==patterns[i%2]
  pixel_bytes=len(b);assert len(x['toggles']['calls'])==10000
  if name.endswith('hash-collision'):assert x['pressure']['final']['caches']['program']['collisions']>0
 elif name=='promoted-physical':
  assert r['status']==result['status']=='passed';assert r['promotedModule']['sha256']==sha(Path('renderer/virgl-command/tests/cache-boundaries.mjs').read_bytes());assert all(p['held'] for p in result['assertions']) and len(result['assertions'])==4593
  for pr,s in zip(r['pixelRecords'],result['schedules']):
   b=(at/pr['path']).read_bytes();assert len(b)==49152 and sha(b)==pr['sha256']==s['pixelsSha256'];pixel_bytes+=len(b)
   for i,f in enumerate(s['frames']):
    wanted=bytearray();rect=f['rect']
    for y in range(16):
     for x in range(16):wanted.extend([int(v*255) for v in f['color']] if rect[0]<=x<rect[0]+rect[2] and rect[1]<=y<rect[1]+rect[3] else [0,0,0,255])
    observed=b[i*1024:(i+1)*1024];assert observed==wanted and sha(observed)==f['sha256']
   assert s['state']['work']['draws']==49 and s['state']['caches']['program']['evictions']==19
 else:
  assert r['status']==result['status']=='failed';literal={'independent-fault-blend':'blend toggle 1 literal physical pixels','independent-fault-text':'pressure shader 0 literal physical pixels','promoted-sabotage':'novel changing scissor literal rectangle pixels 0/1'}[name];assert literal in result['error']['message'];m=r.get('mutation',r.get('sabotage'));raw=original(m['path']);changed=(at/('mutation-source.mjs' if 'mutation' in r else 'fault-source.mjs')).read_bytes();assert raw.count(m['needle'].encode())==1 and raw.replace(m['needle'].encode(),m['replacement'].encode())==changed and sha(changed)==m['servedSha256']
 checks.append({'record':name+'/report.json','sha256':sha((at/'report.json').read_bytes()),'result':r['status'],'expected':'failed' if ('fault' in name or 'sabotage' in name) else 'passed','independentRawBytesChecked':pixel_bytes,'literalFault':result['error']['message'] if r['status']=='failed' else None})
assert subprocess.check_output(['git','diff',HEAD,'--','renderer/virgl-command/state.mjs','renderer/virgl-command/cache.mjs','renderer/virgl-shader'])==b''
result={'status':'HELD','sourceHead':HEAD,'freshRuns':checks,'runtimeUnchanged':True};(O/'final-audits.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
