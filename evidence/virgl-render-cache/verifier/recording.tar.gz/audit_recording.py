import json, hashlib, struct
from pathlib import Path
OUT=Path('evidence/virgl-render-cache/verifier'); BASE=OUT/'unpacked'
def sha(x):return hashlib.sha256(x).hexdigest()
def need(c,s):
 if not c:raise AssertionError(s)
def load(p):return json.loads(p.read_bytes())
ledger=[]
for env in ['hot','cold']:
 for name in ['hardware','hash-collision']:
  at=BASE/env/name;r=load(at/'report.json');x=r['browserResult']['result'];need(r['status']==x['status']=='passed','good status')
  raw=(at/'toggles.rgba').read_bytes();need(len(raw)==10240000 and sha(raw)==r['physicalPixels']['sha256']==x['toggles']['rawSha256'],'pixel custody')
  patterns=[bytes([255,0,0,64])*256,bytes([64,0,191,255])*256]
  for i in range(10000):need(raw[i*1024:(i+1)*1024]==patterns[i%2],f'{env}/{name} mismatch at draw{i}')
  t=x['toggles'];need(len(t['calls'])==10000,'real calls missing')
  for i,c in enumerate(t['calls']):need(c['op']=='drawArrays' and c['args']==[5,0,4] and c['blend']==bool(i%2),'draw/state metadata')
  need(t['final']['work']['programLinks']==t['baseline']['work']['programLinks'] and t['final']['work']['translations']==t['baseline']['work']['translations'],'warm native calls')
  native=r['native'];need(len(native['assertions'])==33 and all(v['held'] for v in native['assertions']),'native predicates');need(native['assertions']==r['browserResult']['native']['assertions'],'browser native predicates')
  need(native['stats']['evictions']==2 and native['stats']['entries']==native['stats']['bytes']==0,'LRU native residency')
  assertions=x['assertions'];need(all(v['held'] for v in assertions),'false browser predicate')
  p=x['pressure'];o=x['ownership'];d=x['diagnostics'];snapshots=[t['baseline'],t['final'],p['final'],o['final'],d['final'],*p['observations'],*o['cycles'],*[j['final'] for j in x['jobs']]]
  for s in snapshots:
   need(s['work']['draws']==s['work']['drawCalls'],'lost draw error')
   for cache in s['caches'].values():need(cache['requests']==cache['hits']+cache['misses'] and cache['bytes']<=cache['limits']['bytes'] and cache['entries']<=cache['limits']['entries'],'bounds or denominator')
   need(s['budgets']['cacheBytes']==sum(c['bytes'] for c in s['caches'].values()),'cache total')
   need(s['budgets']['programs']==s['caches']['program']['entries'] and s['budgets']['uniformBytes']==656*s['budgets']['programs'],'native charges')
   need(s['work']['submissions']==s['work']['completedSubmissions']+s['work']['failedSubmissions'],'lost submission')
  for budget in ['objects','programs','shaderBytes','uniformBytes','cacheBytes','leases']:need(o['final']['budgets'][budget]==0,'owner leak')
  need(len(o['cycles'])==20,'cycle count')
  need(p['final']['caches']['program']['evictions']>8 and p['final']['caches']['translation']['evictions']>0 and p['final']['caches']['state']['evictions']>0,'pressure missing')
  for f in [*p['frames'],*[j['dump'] for j in x['jobs']]]:
   need(f['authority']=='host-labelled-frame' and f['presented'] is False and f['complete'] is True,'capture authority')
   need(f['end']['work']['draws']-f['start']['work']['draws']==len(f['draws']),'capture real draw delta')
   bykey={z['key']:z for z in f['programs']}
   for z in f['submissions']:
    b=bytes.fromhex(z['hex']);need(len(b)==z['byteLength'],'capture extent');atbyte=0;cmds=[]
    while atbyte<len(b):
     header=struct.unpack_from('<I',b,atbyte)[0];op=header&255;length=header>>16;need(atbyte+4+length*4<=len(b),'raw decoded bounds');cmds.append((atbyte,op,length));atbyte+=4+length*4
    need(len(cmds)==z['commandCount'],'capture count')
   for z in f['draws']:
    need(z['programKey'] in bykey,'missing emitted program');ss=json.loads(z['stateKey']);need(ss['program']==z['programGeneration'] and ss['programKey']==z['programKey'] and ss['drawingNow'] is True,'state native generation');need(ss['constants']==z['bindings']['constants'],'captured live uniform bank');need(ss['scissor']==z['bindings']['scissor'],'captured scissor');need(ss['viewport']==z['bindings']['viewport'],'captured viewport')
   if f in p['frames']:
    for z in f['programs']:
     matched=[e for e in p['emissions'] if sorted(s['text'] for s in e['stages'])==sorted([z['vertexESSL300'],z['fragmentESSL300']])];need(matched,'dump ESSL differs from real attached source')
   need(all(v['ok'] for v in f['outcomes']),'normal capture hidden failure')
  frames=p['frames'];need([f['number'] for f in frames]==[42,43],'frame labels');layout=frames[1]['draws'];need(len(layout)==len(set(v['stateKey'] for v in layout))==4 and len(set(v['programKey'] for v in layout))==1,'dynamic state/program ownership')
  need([json.loads(v['stateKey'])['targets'][0]['metadata']['format'] for v in layout]==[2,233,67,67],'format keys')
  overflow=d['dump'];need(overflow['complete'] is False and sum(overflow['dropped'].values())>0 and overflow['end']['work']['draws']-overflow['start']['work']['draws']==100 and d['final']['budgets']['debugBytes']<=16384,'overflow honesty')
  for j in x['jobs']:
   need(j['dump']['outcomes'][0]['gpuComplete'] is True and len(j['dump']['draws'])==2,'fence proof');need(j['closed']['work']['failedSubmissions']==j['final']['work']['failedSubmissions']+1,'disposed job lost');need(j['closed']['work']['submissions']==j['closed']['work']['completedSubmissions']+j['closed']['work']['failedSubmissions'],'disposed denominator')
  if name=='hash-collision':need(p['final']['caches']['program']['collisions']>0,'collision did not happen')
  ledger.append({'record':f'{env}/{name}/report.json','sha256':sha((BASE/env/name/'report.json').read_bytes()),'pixelsSha256':sha(raw),'rawBytesChecked':len(raw),'draws':len(t['calls']),'assertions':len(assertions),'nativePredicates':len(native['assertions']),'pressureEvictions':{k:v['evictions'] for k,v in p['final']['caches'].items()},'ownerFinal':o['final']['budgets'],'overflowDropped':overflow['dropped'],'warmWorkDelta':{k:t['final']['work'][k]-t['baseline']['work'][k] for k in t['final']['work']}})
 for fault,literal in [('blend-key','blend toggle 1 literal physical pixels'),('translation-text','pressure shader 0 literal physical pixels')]:
  r=load(BASE/env/('fault-'+fault)/'report.json');need(r['status']==r['browserResult']['status']=='failed' and literal in r['browserResult']['error']['message'],'fault wrong reason');ledger.append({'record':f'{env}/fault-{fault}/report.json','error':r['browserResult']['error']['message'],'status':'EXPECTED FAILURE'})
result={'predictions':['P1','P2','P3','P4','P5','P6'],'status':'HELD','records':ledger};(OUT/'recording-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
