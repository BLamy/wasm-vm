import json, re, hashlib, subprocess
from pathlib import Path
OUT=Path('evidence/virgl-render-cache/verifier');BASE=OUT/'unpacked';HEAD='6ec98cebea12fc9551e333746d9616999be1e5d2';PRE='bc2c619f72c0bb13ced896411829cd19954ba163'
summary=[]
for name in ['cache','state']:
 source='renderer/virgl-command/'+name+'.mjs';raw=subprocess.check_output(['git','show',HEAD+':'+source]);text=raw.decode();digest=hashlib.sha256(raw).hexdigest();lines=text.splitlines(True);line_starts=[];pos=0
 for line in lines:line_starts.append(pos);pos+=len(line.encode('utf-16-le'))//2
 recordings=[]
 for p in sorted([*BASE.rglob('*coverage.json'), * (OUT/'novel-physical-final').rglob('*coverage.json'), * (OUT/'promoted-physical').rglob('*coverage.json'), * (OUT/'independent-hardware').rglob('*coverage.json'), * (OUT/'independent-hash-collision').rglob('*coverage.json')]):
  blob=json.loads(p.read_text());scripts=blob.get('scripts',[])
  for s in scripts:
   if s.get('source',s.get('path'))==source and s.get('sha256')==digest:
    cov=s.get('coverage',s)
    ranges=[r|{'name':f['functionName']} for f in cov['functions'] for r in f['ranges']]
    recordings.append((str(p.relative_to(OUT)),ranges))
 if not recordings:raise AssertionError('no original coverage '+source)
 diff=subprocess.check_output(['git','diff','--unified=0',PRE,HEAD,'--',source],text=True);added=set();nextline=0
 for line in diff.splitlines():
  if line.startswith('@@'):nextline=int(re.search(r'\+(\d+)',line).group(1))
  elif line.startswith('+') and not line.startswith('+++'):added.add(nextline);nextline+=1
  elif not line.startswith('-') and not line.startswith('\\'):nextline+=1
 ledger=[];missing=[]
 for n in sorted(added):
  line=lines[n-1];start=line_starts[n-1];meaning=line.split('//')[0]
  if not re.search(r'[A-Za-z0-9_$]',meaning):ledger.append({'line':n,'code':line.rstrip(),'classification':'WAIVED punctuation/comment'});continue
  tokens=[(m.start(),m.end()) for m in re.finditer(r'[A-Za-z_$][A-Za-z0-9_$]*|\d+|[?=!+<>&|]',meaning)]
  positions=[start+a for a,b in tokens]
  witnesses=[];uncovered=[]
  for off in positions:
   held=None
   for record,ranges in recordings:
    candidates=[r for r in ranges if r['startOffset']<=off<r['endOffset']]
    if candidates:
     innermost=min(candidates,key=lambda r:r['endOffset']-r['startOffset'])
     if innermost['count']>0:held={'record':record,'function':innermost['name'],'startOffset':innermost['startOffset'],'endOffset':innermost['endOffset'],'count':innermost['count']};break
   if held:
    if held not in witnesses:witnesses.append(held)
   else:uncovered.append(off)
  entry={'line':n,'code':line.rstrip(),'classification':'EXECUTED' if not uncovered else 'PARTIAL' if witnesses else 'UNEXECUTED','witnesses':witnesses,'uncoveredOffsets':uncovered};ledger.append(entry)
  if uncovered:missing.append(entry)
 summary.append({'source':source,'sha256':digest,'matchingRecordings':len(recordings),'addedLines':len(added),'executedLines':sum(e['classification']=='EXECUTED' for e in ledger),'uncoveredLines':missing,'ledger':ledger})
result={'prediction':'P7','status':'OPEN' if any(s['uncoveredLines'] for s in summary) else 'HELD','sources':summary};(OUT/'coverage-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'sources':[{k:v for k,v in s.items() if k!='ledger'} for s in summary]},indent=2))
