import io, json, hashlib, subprocess, tarfile
from pathlib import Path, PurePosixPath
ROOT=Path.cwd(); W=ROOT/'evidence/virgl-render-cache/worker'; OUT=ROOT/'evidence/virgl-render-cache/verifier'; DEST=OUT/'unpacked'
HEAD='6ec98cebea12fc9551e333746d9616999be1e5d2'
def sha(x):return hashlib.sha256(x).hexdigest()
def need(c,s):
 if not c:raise AssertionError(s)
def original(name):return subprocess.check_output(['git','show',HEAD+':'+name])
manifest=json.loads((W/'manifest.json').read_bytes()); indexraw=(W/'records.json').read_bytes(); index=json.loads(indexraw); packed=(W/'recording.tar.gz').read_bytes()
need(sha(packed)==manifest['archiveSha256']=='ad9165fcca40cca50382079c4df648d37525951bbae2e0b17012c236e9b097b7','archive custody')
need(sha(indexraw)==manifest['recordIndexSha256']=='68a61aac2fc646cf0ae26ab71b7a7bf94de8affe77c539181d800b79b448593b','index custody')
need(manifest['sourceHead']==index['sourceHead']==HEAD,'source head')
records={r['path']:r for r in index['records']};need(len(records)==len(index['records'])==manifest['records']==168,'record cardinality')
with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as tf:
 members=tf.getmembers();need(len(members)==len(records),'archive count');need({m.name for m in members}==set(records),'archive names')
 for m in members:
  need(m.isfile() and not m.issym() and not m.islnk() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts,'unsafe member')
  raw=tf.extractfile(m).read();r=records[m.name];need(len(raw)==r['bytes'] and sha(raw)==r['sha256'],m.name+' index mismatch');p=DEST/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
source_digests={}; authentic=[]
for kind in ['hot','cold']:
 receipt=json.loads((DEST/kind/'receipt.json').read_bytes());need(receipt['gitHead']==HEAD and receipt['status']=='passed','receipt')
 for name,digest in receipt['files'].items():need(sha((DEST/kind/name).read_bytes())==digest,name+' receipt digest')
 for name,digest in receipt['sources'].items():
  need(sha(original(name))==digest,name+' frozen source');need(name not in source_digests or source_digests[name]==digest,'source disagreement');source_digests[name]=digest
 for name,digest in receipt['generated'].items():need(sha((DEST/(kind+'-generated')/name).read_bytes())==digest,'generated custody')
 for mode in ['hardware','hash-collision','fault-blend-key','fault-translation-text']:
  at=DEST/kind/mode; report=json.loads((at/'report.json').read_bytes()); need(report['gitHead']==HEAD,'cache exact source')
  for src in report['sources']:
   raw=(DEST/(kind+'-generated')/src['path']).read_bytes() if '/build/wasm/' in src['path'] else original(src['path']);need(sha(raw)==src['sha256'] and len(raw)==src['bytes'],'report source '+src['path'])
  mut=report.get('mutation');served={s['path']:s for s in report['servedFiles']}
  if mut:
   raw=original(mut['path']);changed=(at/'mutation-source.mjs').read_bytes();need(raw.count(mut['needle'].encode())==1 and raw.replace(mut['needle'].encode(),mut['replacement'].encode())==changed and sha(changed)==mut['servedSha256'],'exact mutation')
  for src in report['sources']:
   if '/'+src['path'] in served:need(served['/'+src['path']]['sha256']==(mut['servedSha256'] if mut and src['path']==mut['path'] else src['sha256']),'served source')
  cov=json.loads((at/'browser-coverage.json').read_bytes());need(sha((at/'browser-coverage.json').read_bytes())==report['browserCoverage']['sha256'],'coverage digest')
  for s in cov['scripts']:need(s['sha256']==served['/'+s['source']]['sha256'],'coverage served source')
  need(sha((at/'browser.png').read_bytes())==report['screenshot']['sha256'],'screenshot digest')
  need(report['browserErrors']=={'console':[],'page':[],'requests':[]},'browser errors')
  need(report['browser']['headless'] is False,'not headed');need(report['browser']['gpu']['featureStatus'].get('webgl2',report['browser']['gpu']['featureStatus'].get('webgl'))=='enabled','disabled GPU');need(not any(any(s in arg.lower() for s in ['swiftshader','llvmpipe','softpipe','lavapipe','--disable-gpu']) for arg in report['browser']['commandLine']),'software GPU')
  need('Metal' in report.get('browserResult',{}).get('result',{}).get('gpu','Metal'),'not Metal physical')
  authentic.append({'record':str(at.relative_to(DEST))+'/report.json','sha256':sha((at/'report.json').read_bytes()),'status':report['status']})
cold=json.loads((DEST/'cold/report.json').read_bytes());need(cold['gitHead']==cold['cloneHead']==HEAD and cold['statusBefore']==cold['statusAfter']=='' and cold['exitCode']==0 and cold['status']=='passed','cold provenance');need(sha((DEST/'cold/cold.log').read_bytes())==cold['logSha256'],'cold log');need(sha((DEST/'cold/receipt.json').read_bytes())==cold['receiptSha256']==manifest['coldReceiptSha256'],'cold receipt seal')
need(sha((DEST/'hot/receipt.json').read_bytes())==manifest['hotReceiptSha256'],'hot receipt seal');need(sha((DEST/'cold/report.json').read_bytes())==manifest['coldReportSha256'],'cold report seal')
clone=Path(cold['clone']);need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==HEAD,'retained clone head');need(subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=clone,text=True)=='','retained clone dirty')
for path in source_digests:need(sha((clone/path).read_bytes())==source_digests[path],'retained clone source')
result={'prediction':'P0','status':'HELD','archiveSha256':sha(packed),'indexSha256':sha(indexraw),'records':len(records),'sourceHead':HEAD,'sourceFilesAuthenticated':len(source_digests),'reports':authentic,'cold':cold}
(OUT/'authentication.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['cold','reports']},indent=2));print('removed environment:',cold['removedEnvironmentNames'])
