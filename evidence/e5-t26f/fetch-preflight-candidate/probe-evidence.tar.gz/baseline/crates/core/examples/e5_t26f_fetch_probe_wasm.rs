//! E5-T26f isolated upper-bound probe: all JIT probes miss after a warm cache/TLB.
//! This is experiment-only and intentionally uses the public Machine API.

use std::cell::Cell;
use std::rc::Rc;

use sha2::{Digest, Sha256};
use wasm_vm_core::bus::mmap::DRAM_BASE;
use wasm_vm_core::bus::Bus;
use wasm_vm_core::csr::{CsrOp, Priv, SATP, MINSTRET};
use wasm_vm_core::dispatch::DecodedBlock;
use wasm_vm_core::hart::Hart;
use wasm_vm_core::jit::{CompiledBlockExecutor, JitExit};
use wasm_vm_core::mmio::SystemBus;
use wasm_vm_core::RunOutcome;
use wasm_vm_core::Machine;

const RAM_BYTES: usize = 64 * 1024 * 1024;
const ROOT: u64 = DRAM_BASE + 0x20_0000;
const PCODE: u64 = DRAM_BASE + 0x30_0000;
const VCODE: u64 = 0x1000_0000;
const WARMUP: u64 = 10_000;
const BUDGET: u64 = 12_000_000;

const V: u64 = 1;
const R: u64 = 1 << 1;
const X: u64 = 1 << 3;
const A: u64 = 1 << 6;

fn pte(pa: u64, perms: u64) -> u64 {
    ((pa >> 12) << 10) | perms
}

fn enc_addi(rd: u32, rs1: u32, imm: i32) -> u32 {
    ((imm as u32 & 0xfff) << 20) | (rs1 << 15) | (rd << 7) | 0x13
}

fn enc_bne(rs1: u32, rs2: u32, off: i32) -> u32 {
    let o = off as u32;
    (((o >> 12) & 1) << 31)
        | (((o >> 5) & 0x3f) << 25)
        | (rs2 << 20)
        | (rs1 << 15)
        | (1 << 12)
        | (((o >> 1) & 0xf) << 8)
        | (((o >> 11) & 1) << 7)
        | 0x63
}

fn set_csr(m: &mut Machine, addr: u16, value: u64) {
    m.hart_mut()
        .csr
        .access(addr, CsrOp::Write, value, false, false, 0)
        .unwrap();
}

struct PageTables {
    root: u64,
    next: u64,
}

impl PageTables {
    fn new(root: u64) -> Self {
        Self {
            root,
            next: root + 0x1000,
        }
    }

    fn map_4k(&mut self, m: &mut Machine, va: u64, pa: u64, perms: u64) {
        let mut table = self.root;
        for level in (1..=2usize).rev() {
            let vpn = (va >> (12 + level * 9)) & 0x1ff;
            let old = m.bus_mut().load64(table + vpn * 8).unwrap();
            table = if old & V != 0 {
                (old >> 10) << 12
            } else {
                let child = self.next;
                self.next += 0x1000;
                m.bus_mut().store64(table + vpn * 8, pte(child, V)).unwrap();
                child
            };
        }
        let vpn0 = (va >> 12) & 0x1ff;
        m.bus_mut()
            .store64(table + vpn0 * 8, pte(pa, perms))
            .unwrap();
    }

    fn satp(&self) -> u64 {
        (8u64 << 60) | (self.root >> 12)
    }
}

/// Executor that can never compile or execute a block, but counts the public JIT probes.
struct AllMissExecutor {
    probes: Rc<Cell<u64>>,
}

impl CompiledBlockExecutor for AllMissExecutor {
    fn max_translation_attempts_per_run(&self) -> usize {
        0
    }

    fn max_staged_nominations_per_run(&self) -> usize {
        0
    }

    fn install(&mut self, _block: &DecodedBlock) {}

    fn install_batch(&mut self, _blocks: &[DecodedBlock], _intra: &[[Option<usize>; 2]]) {}

    fn is_compiled(&self, _phys_pc: u64) -> bool {
        self.probes.set(self.probes.get() + 1);
        false
    }

    fn execute(
        &mut self,
        _phys_pc: u64,
        _hart: &mut Hart,
        _bus: &mut SystemBus,
    ) -> Option<JitExit> {
        panic!("all-miss executor must never execute a compiled block")
    }

    fn invalidate_all(&mut self) {}
    fn invalidate_page(&mut self, _frame: u64) {}
    fn compiled_count(&self) -> usize { 0 }
    fn executed_blocks(&self) -> u64 { 0 }
    fn retired_via_jit(&self) -> u64 { 0 }
}

fn checksum(m: &mut Machine) -> String {
    let mut h = Sha256::new();
    h.update(m.hart().regs.pc.to_le_bytes());
    for r in 0..32u8 {
        h.update(m.hart().regs.read(r).to_le_bytes());
    }
    h.update(m.hart_mut().csr.read(MINSTRET).to_le_bytes());
    format!("{:x}", h.finalize())
}

fn machine(jit_enabled: bool, probes: Rc<Cell<u64>>) -> Machine {
    let mut m = Machine::new(RAM_BYTES);
    m.hart_mut().csr.pmp.allow_all();
    let mut pt = PageTables::new(ROOT);
    pt.map_4k(&mut m, VCODE, PCODE, V | R | X | A);
    m.bus_mut()
        .store32(PCODE, enc_addi(5, 5, 1))
        .unwrap();
    m.bus_mut()
        .store32(PCODE + 4, enc_bne(5, 6, -4))
        .unwrap();
    set_csr(&mut m, SATP, pt.satp());
    m.hart_mut().csr.mode = Priv::S;
    m.hart_mut().regs.write(6, u64::MAX);
    m.hart_mut().regs.pc = VCODE;
    m.set_block_cache(true);
    m.set_interrupt_batching(true);
    if jit_enabled {
        m.set_executor(Box::new(AllMissExecutor { probes }));
        m.set_hotness_threshold(u32::MAX);
        m.set_jit(true);
    }
    m
}

// Scratch-only WASM adapter. Fixture/setup/checksum above are copied unchanged from
// e5_t26f_fetch_probe.rs (apart from removing native-only timing/observation items).
// The checksum covers only integer registers, PC, and MINSTRET.
struct Probe {
    machine: Machine,
    probes: Rc<Cell<u64>>,
    before: u64,
    checksum: String,
}

// SAFETY: the single-process runner only passes live pointers returned by prepare;
// each probe is finished/read outside timing and dropped exactly once.
#[unsafe(no_mangle)]
pub extern "C" fn probe_prepare(jit_enabled: u32) -> *mut std::ffi::c_void {
    assert!(jit_enabled <= 1);
    let probes = Rc::new(Cell::new(0));
    let mut m = machine(jit_enabled != 0, Rc::clone(&probes));
    assert_eq!(m.run(WARMUP), RunOutcome::MaxInstrs);
    let before = m.hart_mut().csr.read(MINSTRET);
    probes.set(0);
    Box::into_raw(Box::new(Probe {
        machine: m,
        probes,
        before,
        checksum: String::new(),
    })).cast()
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn probe_run(handle: *mut std::ffi::c_void) {
    let p = unsafe { &mut *handle.cast::<Probe>() };
    assert_eq!(p.machine.run(BUDGET), RunOutcome::MaxInstrs);
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn probe_retired(handle: *mut std::ffi::c_void) -> u64 {
    let p = unsafe { &mut *handle.cast::<Probe>() };
    let retired = p.machine.hart_mut().csr.read(MINSTRET) - p.before;
    assert_eq!(retired, BUDGET);
    retired
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn probe_misses(handle: *mut std::ffi::c_void) -> u64 {
    unsafe { &*handle.cast::<Probe>() }.probes.get()
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn probe_checksum(handle: *mut std::ffi::c_void) -> *const u8 {
    let p = unsafe { &mut *handle.cast::<Probe>() };
    assert_eq!(p.machine.hart().regs.pc, VCODE);
    assert_eq!(p.machine.hart().regs.read(5), (WARMUP + BUDGET) / 2);
    p.checksum = checksum(&mut p.machine);
    assert_eq!(p.checksum.len(), 64);
    p.checksum.as_ptr()
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn probe_drop(handle: *mut std::ffi::c_void) {
    drop(unsafe { Box::from_raw(handle.cast::<Probe>()) });
}

