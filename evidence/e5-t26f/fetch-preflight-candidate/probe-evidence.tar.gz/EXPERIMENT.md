# E5-T26 fetch-probe scratch experiment

Non-acceptance upper-bound experiment only. The baseline runtime is the supplied immutable
archive at `SHA9e2d235163d528112ab0375886e2bdf4e602c0dbdceaf7e486abad0b6d78b053`;
candidate differs only in the private source delta below. No main workspace files, guest image,
browser, profile, checkpoint, or repository metadata were used.

## Commands

Both trees used the pinned `rust-toolchain.toml` (`+1.96.0`) and these exact commands, with
`RUSTFLAGS`, `CARGO_BUILD_RUSTFLAGS`, `CARGO_TARGET_DIR`, and `CARGO_INCREMENTAL` unset:

```text
env -u RUSTFLAGS -u CARGO_BUILD_RUSTFLAGS -u CARGO_TARGET_DIR -u CARGO_INCREMENTAL cargo +1.96.0 check -p wasm-vm-core --example e5_t26f_fetch_probe
env -u RUSTFLAGS -u CARGO_BUILD_RUSTFLAGS -u CARGO_TARGET_DIR -u CARGO_INCREMENTAL cargo +1.96.0 build --release -p wasm-vm-core --example e5_t26f_fetch_probe
env -u RUSTFLAGS -u CARGO_BUILD_RUSTFLAGS -u CARGO_TARGET_DIR -u CARGO_INCREMENTAL ./target/release/examples/e5_t26f_fetch_probe
```

The harness is identical in both trees: Sv39 maps the loop VA through three page-table levels to
RX physical code, permissive PMP checks are active, the executor always reports a miss, the
executor miss counter is asserted nonzero, and each ABBA quartet is checked for equal retired
count and SHA-256 architectural checksum. JIT-disabled is the negative control.

## Exact candidate change

`candidate/crates/core/src/lib.rs` only:

* `RunCapture::step` (lines 87-111) and the cached-step call carry
  `preflight_phys: Option<u64>`.
* `Machine::next_micro_op` (lines 4013-4048) drains code writes as before, then uses the
  successful preflight physical key when present; translation faults carry no hint and retry the
  existing `fetch_phys` path.
* `Machine::try_jit_block` (lines 4304-4314) stores the physical key only after translation/PMP
  succeeds and `is_compiled` returns false.
* The run loop (lines 4914-4932) creates the per-dispatch hint, passes it through the failed-JIT
  fallback, and leaves the zicsr-stub path explicitly `None`.

No budgets, clocks, JIT policy, cache sizes, identity fences, or executor behavior changed.
`is_compiled` receives no machine/bus callback, and the synchronous fallback has no intervening
guest-visible mutation; this was the semantic pre-run check. The code-write drain remains before
hint use.

## Raw measured output

All rows retired `12000000`; all rows used checksum
`96fe1c05f4f3e8d052066f6477c891088ca6a0b8d081c62b7edc1f22c63b8c6d`.

```text
tree      round case  nanos       probes
baseline  0     off   191595667   0
baseline  0     miss  236794667   6000000
baseline  0     miss  235494709   6000000
baseline  0     off   194450792   0
baseline  1     off   194005083   0
baseline  1     miss  228753000   6000000
baseline  1     miss  233976333   6000000
baseline  1     off   193079958   0
baseline  2     off   191307750   0
baseline  2     miss  235439417   6000000
baseline  2     miss  230603750   6000000
baseline  2     off   193045459   0
baseline  3     off   191370417   0
baseline  3     miss  231608708   6000000
baseline  3     miss  228012959   6000000
baseline  3     off   187899417   0
candidate 0     off   206600458   0
candidate 0     miss  182970834   6000000
candidate 0     miss  183420958   6000000
candidate 0     off   186778542   0
candidate 1     off   187671875   0
candidate 1     miss  183598584   6000000
candidate 1     miss  182542417   6000000
candidate 1     off   187698958   0
candidate 2     off   186327125   0
candidate 2     miss  185362584   6000000
candidate 2     miss  183814708   6000000
candidate 2     off   189051584   0
candidate 3     off   188785209   0
candidate 3     miss  187833167   6000000
candidate 3     miss  185914708   6000000
candidate 3     off   188976125   0
```

Means across eight rows per case: baseline off `192094318 ns`, baseline miss `232585443 ns`;
candidate off `190236235 ns`, candidate miss `184432245 ns`. The candidate miss arm is
`20.7%` below baseline miss in this workload; that is an optimistic all-miss bound, not a
whole-boot or 2-second claim. The sample profile does not localize inlined cost or prove this
benefit transfers to the authenticated WASM run.

