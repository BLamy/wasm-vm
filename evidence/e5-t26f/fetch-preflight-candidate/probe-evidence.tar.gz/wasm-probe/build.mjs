// Scratch-only build driver: emits records to stdout; compilers write only to
// explicit scratch output directories. Run from the preserved scratch root.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const env = Object.fromEntries(Object.entries(process.env).filter(([key]) =>
  !key.startsWith('CARGO_') && !key.startsWith('RUST') &&
  !['NODE_OPTIONS', 'NODE_PATH'].includes(key)));
env.TMPDIR = join(root, 'wasm-probe/tmp');
const removed = Object.keys(process.env).filter(key => !(key in env)).sort();
const hash = file => createHash('sha256').update(readFileSync(file)).digest('hex');
const source = 'crates/core/examples/e5_t26f_fetch_probe_wasm.rs';
const original = 'crates/core/examples/e5_t26f_fetch_probe.rs';
const cargo = '/Users/blamy/.cargo/bin/cargo';
const rustc = '/Users/blamy/.cargo/bin/rustc';
function emit(value) { console.log(JSON.stringify(value)); }
function command(cwd, bin, args) {
  emit({ type: 'command', cwd, argv: [bin, ...args] });
  const r = spawnSync(bin, args, { cwd, env, encoding: 'utf8', maxBuffer: 8 * 1024 * 1024 });
  emit({ type: 'command_result', exit: r.status, signal: r.signal,
    error: r.error?.message ?? null, stdout: r.stdout, stderr: r.stderr });
  assert.equal(r.status, 0, 'build command failed');
}
emit({ type: 'environment', root, removedVariables: removed, tmpdir: env.TMPDIR,
  node: process.version, v8: process.versions.v8 });
command(root, rustc, ['+1.96.0', '-Vv']);
command(root, cargo, ['+1.96.0', '-V']);
for (const file of ['Cargo.lock', 'rust-toolchain.toml', '.cargo/config.toml',
  'Cargo.toml', 'crates/core/Cargo.toml', original, source]) {
  const a = hash(join(root, 'baseline', file));
  const b = hash(join(root, 'candidate', file));
  assert.equal(a, b, 'paired source/config mismatch: ' + file);
  emit({ type: 'identical_input', file, sha256: a });
}
assert.equal(hash(join(root, 'baseline/crates/core/src/lib.rs')),
  '9e2d235163d528112ab0375886e2bdf4e602c0dbdceaf7e486abad0b6d78b053');
emit({ type: 'preserved_native_result', file: 'EXPERIMENT.md', sha256: hash(join(root, 'EXPERIMENT.md')) });
for (const version of ['baseline', 'candidate']) {
  const cwd = join(root, version);
  const target = join(root, 'wasm-probe/build', version);
  command(cwd, cargo, ['+1.96.0', 'build', '--offline', '--locked', '--release',
    '--target', 'wasm32-unknown-unknown', '--target-dir', target, '-p', 'wasm-vm-core', '--lib']);
  const deps = join(target, 'wasm32-unknown-unknown/release/deps');
  const sha = readdirSync(deps).filter(file => /^libsha2-.*\.rlib$/.test(file));
  assert.equal(sha.length, 1);
  const output = join(root, 'wasm-probe', version + '.wasm');
  command(cwd, rustc, ['+1.96.0', '--edition=2024', '--crate-name', 'e5_t26f_fetch_probe_wasm',
    '--crate-type', 'cdylib', '--target', 'wasm32-unknown-unknown',
    '-C', 'opt-level=3', '-C', 'debuginfo=2', '-C', 'codegen-units=16',
    '-C', 'debug-assertions=off', '-C', 'overflow-checks=off',
    '--extern', 'wasm_vm_core=' + join(target, 'wasm32-unknown-unknown/release/libwasm_vm_core.rlib'),
    '--extern', 'sha2=' + join(deps, sha[0]), '-L', 'dependency=' + deps, source, '-o', output]);
  emit({ type: 'module', version, file: output, sha256: hash(output),
    runtimeLibSha256: hash(join(cwd, 'crates/core/src/lib.rs')) });
}

