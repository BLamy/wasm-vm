# Actual-WASM fetch preflight probe — bounded scratch result

The existing candidate showed a measurable benefit on this synthetic all-JIT-miss
fixture in actual WASM: mean elapsed time decreased 12.602%, from 422.539 ms to
369.292 ms per 12 million retired instructions. The JIT-off control changed +0.164%,
from 325.013 ms to 325.548 ms. Each of the three interleaved quartets favored the
candidate in the miss case (12.881%, 10.665%, 14.228% reductions).

| Case | Baseline mean ms | Candidate mean ms | Candidate elapsed change |
| --- | ---: | ---: | ---: |
| JIT off | 325.013 | 325.548 | +0.164% |
| JIT enabled, all misses | 422.539 | 369.292 | -12.602% |

These are six samples per version/case, 24 total. Raw rows, including exact order,
are preserved verbatim in [timings.jsonl](timings.jsonl). Setup and execution succeeded;
no build failure, trap, or assertion failure occurred in this resumed probe.

## Scope and interpretation

This executes the emulator core compiled to wasm32-unknown-unknown, inside one
Node/V8 process (PID 40695). It is a synthetic warm branch loop using the public
Machine API, S-mode Sv39 translation, permissive active PMP, a warm decoded cache/TLB,
and a counting executor that always returns a miss and never compiles/executes code.
The two-instruction loop, fixture construction, budgets, hotness setting, and
checksum function are copied from the preserved native probe. The timed guest
budget is 12,000,000 instructions; each fresh machine first warms for 10,000.

This does not use BrowserExecutor, an Omarchy image, a browser boot, or a production
release artifact. No F/2-second or clean-release acceptance claim follows.
The prior native numbers in ../EXPERIMENT.md remain untouched and are separate
measurements; their "architectural checksum" wording is too broad. The old runs also
ran both native executables concurrently, with off/miss ABBA within each executable;
they were not sequential baseline/candidate pairing. This WASM run uses sequential
cross-version pairing in one engine.

The SHA-256 checksum covers PC, x0 through x31, and MINSTRET only, serialized in
that order as little-endian u64 values. It excludes other CSRs, RAM, devices,
floating-point state, and other architectural state. All 24 samples matched:

```text
96fe1c05f4f3e8d052066f6477c891088ca6a0b8d081c62b7edc1f22c63b8c6d
```

All samples checked exactly 12,000,000 retired instructions; all miss samples checked
exactly 6,000,000 executor queries returning false; all off samples checked zero.
The wrapper additionally checks the final PC and x5 against the loop's expected values.
There are no TLB-hit counters or new semantic-matrix tests here. The independent
critic's focused TLB/semantic matrix remains an adoption prerequisite, outside scope.
The authenticated profile does not localize inlined cost or prove benefit from this
change. Timing demonstrates a local synthetic benefit, not portability to a guest boot.

## Minimal approach and pinned execution

Read-only discovery inspected archived/current retirement_capture_baseline.rs
WASM wrappers, crate manifests, .cargo/config.toml, rust-toolchain.toml, and the
current Node steady-state compute runner. The existing pattern executes a public
Machine fixture as WASM and verifies host-visible output. Instead of adding a
wasm-bindgen test dependency or browser runner, this adapter exposes six plain C ABI
functions (prepare/run/retired/misses/checksum/drop) and uses the installed Node
WebAssembly API. Both modules have WASM magic and zero imports: guest CPU execution
and miss counting are inside WASM, with no per-operation JS/native callbacks.

Core dependencies: archived Cargo.lock unchanged; cargo +1.96.0 build --release
--offline --locked --target wasm32-unknown-unknown -p wasm-vm-core --lib.
The default core std feature matches the original native probe. The adapter is
linked using the same rustc 1.96.0/LLVM 22.1.2, opt-level=3, codegen-units=16,
debuginfo=2, debug assertions off, overflow checks off for both arms. No wasm-opt
packaging pass was used. Cargo and rustc arguments, paths, outputs, and input hashes
are recorded in [build.jsonl](build.jsonl).

Node: v24.20.0; V8: 13.6.233.17-node.53.
Executable: /Users/blamy/.nvm/versions/node/v24.20.0/bin/node.
Executable SHA-256: 9d050fd455b56426e25d4d603c7c501cbb2630348e836cf221dcce748e90588a.
Engine flags: --no-liftoff --no-wasm-lazy-compilation, to select the optimizing
compiler eagerly and keep baseline tiering/compilation outside timed samples.
Both modules are synchronously compiled and instantiated before timing. Both retain
the same engine checks and optimization settings. The process checks the exact
Node/V8 versions and flags, and uses performance.now around probe_run only.
Preparation, checksum construction, validation, allocation, and drop are outside timing.

Each round uses baseline/candidate/candidate/baseline, with JIT off and all-miss
cases at each slot. Control/miss order reverses on odd slots/rounds. The modules
remain loaded in one engine throughout. There are three rounds and no parallel
benchmark, build, or profile launched by this worker during measurement.

Exact entry commands, from /private/tmp/e5-t26f-fetch-probe.83cUcL:

```sh
/Users/blamy/.nvm/versions/node/v24.20.0/bin/node wasm-probe/build.mjs
env -u NODE_OPTIONS -u NODE_PATH /Users/blamy/.nvm/versions/node/v24.20.0/bin/node --no-liftoff --no-wasm-lazy-compilation wasm-probe/run.mjs
```

The build driver removes all inherited CARGO_* and RUST* variables plus NODE_OPTIONS
and NODE_PATH from compiler children, pins +1.96.0 explicitly, and sets TMPDIR
and both target directories within this scratch root. It makes no direct file writes:
Cargo/rustc produce build artifacts, and all authored files/logs were added with apply_patch.
The raw timing log and module hashes were retained after successful completion.
No processes or command sessions from this probe remain running.

## Exact module identities

```text
dad5ef710880bab481d9679601c11c8397627a598280a16f290d2cb679ebaaad  baseline.wasm
4eabd93506b2dc778a1a7276854b351d1abd87a4aa6c8fe9b9188a289d0bfcee  candidate.wasm
```

Both adapter files have SHA-256
eea983152b6241544bcfe583680e67dc78a8b64b067ecb0cd1b2310dfb3a51d3.
Baseline core lib.rs remained
9e2d235163d528112ab0375886e2bdf4e602c0dbdceaf7e486abad0b6d78b053;
candidate core lib.rs remained
a63eb5b34305c4554ddc87b36bc0c9821df414b915ddbccd83b6c654daf655ce.
The existing candidate delta is preserved in [candidate.patch](candidate.patch);
it was not changed or re-reviewed in this resumed probe.
[SHA256SUMS](SHA256SUMS) records module, adapter, runner, lock/config, runtime source,
raw output, and old native result hashes.

## Files added in this resumed probe

All paths are relative to /private/tmp/e5-t26f-fetch-probe.83cUcL:

- baseline/crates/core/examples/e5_t26f_fetch_probe_wasm.rs
- candidate/crates/core/examples/e5_t26f_fetch_probe_wasm.rs
- wasm-probe/build.mjs
- wasm-probe/run.mjs
- wasm-probe/tmp/.keep
- wasm-probe/build.jsonl
- wasm-probe/timings.jsonl
- wasm-probe/candidate.patch
- wasm-probe/SHA256SUMS
- wasm-probe/README.md
- Generated: wasm-probe/baseline.wasm, wasm-probe/candidate.wasm, and Cargo outputs
  under wasm-probe/build/{baseline,candidate}/.

No pre-existing source/result files were edited. The old core candidate patch,
both native examples, old EXPERIMENT.md, archived pins/configs and native target
artifacts remain in place. No main-repo write, task activation, git mutation,
image change, production build, deployment, or additional candidate was performed.
