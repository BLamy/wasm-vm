// One Node/V8 process, sequential B/C/C/B quartets, both JIT settings.
// Prints complete raw JSONL; no browser, filesystem writes, or native timing.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { performance } from 'node:perf_hooks';
const here = dirname(fileURLToPath(import.meta.url));
const emit = value => console.log(JSON.stringify(value));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
assert.equal(process.version, 'v24.20.0');
assert.equal(process.versions.v8, '13.6.233.17-node.53');
assert.deepEqual(process.execArgv, ['--no-liftoff', '--no-wasm-lazy-compilation']);
assert.equal(process.env.NODE_OPTIONS, undefined);
const expected = '96fe1c05f4f3e8d052066f6477c891088ca6a0b8d081c62b7edc1f22c63b8c6d';
emit({ type: 'engine', node: process.version, v8: process.versions.v8,
  executable: process.execPath, executableSha256: hash(readFileSync(process.execPath)),
  argv: process.argv, execArgv: process.execArgv, pid: process.pid,
  timing: 'performance.now around probe_run only; preparation, hashing, checking and drop excluded',
  checksumScope: 'x0..x31, PC, MINSTRET only; not full architectural state',
  budget: 12000000, guestWarmup: 10000, rounds: 3 });
const modules = {};
for (const version of ['baseline', 'candidate']) {
  const bytes = readFileSync(join(here, version + '.wasm'));
  assert.equal(bytes.subarray(0, 4).toString('hex'), '0061736d');
  const module = new WebAssembly.Module(bytes);
  assert.deepEqual(WebAssembly.Module.imports(module), []);
  const instance = new WebAssembly.Instance(module, {});
  modules[version] = instance.exports;
  emit({ type: 'module', version, sha256: hash(bytes), bytes: bytes.length,
    imports: WebAssembly.Module.imports(module), exports: WebAssembly.Module.exports(module) });
}
const observations = [];
let sequence = 0;
for (let round = 0; round < 3; round++) {
  for (const [slot, version] of ['baseline', 'candidate', 'candidate', 'baseline'].entries()) {
    // Reverse control/miss order on odd slots/rounds to balance within each quartet.
    const cases = (slot + round) % 2 ? [1, 0] : [0, 1];
    for (const jit of cases) {
      const e = modules[version];
      const handle = e.probe_prepare(jit);
      assert.ok(handle);
      const start = performance.now();
      e.probe_run(handle);
      const elapsedMs = performance.now() - start;
      const retired = e.probe_retired(handle);
      const probes = e.probe_misses(handle);
      const address = e.probe_checksum(handle);
      const checksum = new TextDecoder().decode(new Uint8Array(e.memory.buffer, address, 64));
      assert.equal(retired, 12000000n);
      assert.equal(probes, jit ? 6000000n : 0n);
      assert.equal(checksum, expected);
      e.probe_drop(handle);
      const row = { type: 'sample', sequence: sequence++, round, slot, version,
        case: jit ? 'miss' : 'off', elapsedMs, retired: String(retired), probes: String(probes), checksum };
      observations.push(row);
      emit(row);
    }
  }
}
for (const version of ['baseline', 'candidate']) {
  for (const mode of ['off', 'miss']) {
    const values = observations.filter(r => r.version === version && r.case === mode).map(r => r.elapsedMs);
    const sorted = [...values].sort((a, b) => a - b);
    emit({ type: 'summary', version, case: mode, n: values.length,
      meanMs: values.reduce((a, b) => a + b, 0) / values.length,
      medianMs: (sorted[2] + sorted[3]) / 2, minMs: sorted[0], maxMs: sorted.at(-1) });
  }
}
emit({ type: 'complete', samples: observations.length, allChecksHeld: true });

