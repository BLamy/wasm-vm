# Fetch-preflight critic predictions

Recorded before inspecting baseline or candidate source/state.

Scope: only the `core/src/lib.rs` baseline/candidate diff in this scratch candidate. These are falsifiable predictions, not findings.

1. **Physical-address provenance.** The candidate will reuse a physical address only when a successful instruction fetch/translation occurred for the current architectural PC in the same dispatch iteration, and only when `try_jit_block` returns the specific uncompiled/miss outcome (`is_compiled == false`). Any PMP, page-table, alignment, or access fault will return before a reusable address can reach `next_micro_op`.
2. **No stale translation window.** Between producing the physical-address hint and consuming it in the cached interpreter path, there will be no guest-visible mutation, interrupt/trap transition, code-write drain, TLB/PMP invalidation, privilege/translation CSR change, breakpoint callback, or externally supplied hook capable of changing PC-to-PA translation or executable bytes.
3. **Refusal-path isolation.** JIT outcomes other than the ordinary uncompiled miss—including disabled/ineligible compilation, breakpoint-related refusal, code-write invalidation, and fetch/decode faults—will not route a speculative or stale PA into the interpreter.
4. **Ordering preservation.** Breakpoint checks, retired/instruction counters, CSR/time effects, capture/tracing, and exception delivery will retain baseline ordering and cardinality. In particular, removing the second translation will not remove an architecturally/test-observable fetch event expected by existing tracing routes.
5. **Invalidation coherence.** TLB invalidation, PMP/config changes, executable-memory writes, and JIT cache invalidation will either occur before the successful preflight fetch or after the interpreter consumes it; no invalidation-producing operation will be interposed between those points.
6. **Consumer contract.** `next_micro_op` (or its immediate helper) will distinguish a trusted same-dispatch PA from absence without expanding a public/legacy API, and all pre-existing callers will retain baseline behavior when no hint is supplied.
7. **Bounded payoff.** The diff will be narrowly limited to passing and consuming this hint, with no unrelated compatibility layer or architectural semantics changes. The worker's separate actual-WASM benchmark remains the authority for performance; this review will not reproduce it.

Decision rule: **GO** only if every prediction is supported by concrete control-flow/source evidence and a small deterministic test matrix can directly distinguish one translation from two without broadening public APIs. Otherwise **NO-GO**, citing exact source lines and the smallest follow-up needed.
