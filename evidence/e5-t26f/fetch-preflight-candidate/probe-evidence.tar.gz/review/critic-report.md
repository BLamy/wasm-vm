# Independent critic report — fetch-preflight candidate

## Decision

**GO — bounded implementation task, with the focused tests below required before adoption.**

This is a source-level design decision only. It is **not VERIFIED**, does not adopt the candidate, and does not make a performance claim. The worker's separate actual-WASM benchmark remains the performance authority.

No source-level semantic blocker was found in the scoped `baseline/crates/core/src/lib.rs` → `candidate/crates/core/src/lib.rs` change.

## Scope and identity

- Baseline SHA-256: `9e2d235163d528112ab0375886e2bdf4e602c0dbdceaf7e486abad0b6d78b053` — matches the supplied hash.
- Candidate SHA-256: `a63eb5b34305c4554ddc87b36bc0c9821df414b915ddbccd83b6c654daf655ce`.
- Reviewed only the scoped core-library change and the unchanged definitions needed to interpret its control flow. No benchmark, build, test, network, browser, task-state, Git, or main-repository operation was performed.

## Prediction results and source audit

### P1 — successful PA provenance: HELD

`try_jit_block` obtains `phys` from a successful `fetch_phys` at candidate `crates/core/src/lib.rs:4311`. The only assignment to the out-parameter is inside the exact `!is_compiled(phys)` branch at lines 4312–4314. A translation/PMP failure is converted to `None` by `.ok()?` before the assignment. Therefore a fault cannot produce a hint.

The run loop creates a fresh `None` every iteration at lines 4914–4918, so no hint can survive a prior PC or dispatch.

### P2 — literal preregistered prediction: FAILED

The original P2 explicitly predicted no interposed "code-write drain" between hint production and consumption. `next_micro_op` calls `drain_code_writes` at line 4035 before consuming the hint at lines 4045–4047. That contradicts the literal prediction. The original preregistered prediction remains unchanged and FAILED; it must not be relabeled HELD after inspection.

**Refined semantic claim — no guest-state or translation mutation in that interval: HELD by source.** This is a refinement made after inspection, not a successful preregistered prediction.

After `try_jit_block` returns `None`, the run loop immediately calls `capture.step` at lines 4923–4929. Dispatch merely selects the cached step at lines 85–106. The cached step then:

1. arms counter-write suppression at line 3916;
2. performs the read-only execute-trigger predicate at lines 3917–3923, returning a breakpoint before consuming the hint at lines 3924–3927 if it fires; and
3. calls `next_micro_op` at line 3933.

There is no guest instruction execution, trap entry, interrupt delivery, architectural CSR write, PC change, sink callback, or bus write in that interval. `arm_counters` changes only per-instruction suppression bookkeeping; it does not affect address translation. The boundary drain at `next_micro_op` line 4035 can mutate decoded/JIT cache metadata, but not guest architectural state or translation. It processes already-recorded physical-frame writes, removing affected cached code before lookup at lines 4053–4059; a resulting miss decodes current bytes at line 4064. The drain therefore leaves the successful PA translation valid and preserves code coherence. Its presence refutes the literal prediction but is not a semantic blocker. GO rests on this refined source argument, not on all original predictions having held.

### P3 — uncompiled miss is isolated from every other refusal: HELD

- **Uncompiled:** only lines 4312–4314 set the hint.
- **Initial fetch/PMP fault:** line 4311 returns `None` with the hint untouched; fallback reaches the ordinary fetch at line 4047.
- **No executor:** the `as_ref()?` at line 4312 exits before assignment.
- **Compiled block with short-tail, decoded-metadata, or executor-metadata refusal:** those exits occur later through `run_one_jit_block` at lines 4325–4339. Since `is_compiled` was true, the assignment at line 4313 was skipped, and fallback again uses line 4047.
- **Compiled execution or compiled trap:** returns `Some(JitProgress)` through lines 4343–4360 and never enters interpreter fallback.

Thus the optimization is narrower than “any JIT refusal”: it applies only to a successful translation followed by `is_compiled == false`.

### P4 — PMP/TLB invalidation ordering: HELD

PMP coherence is synchronized at each effective block boundary before device service, interrupt delivery, and JIT preflight at lines 4713–4720. A taken interrupt changes privilege/PC and immediately continues at lines 4891–4899, so no pre-interrupt hint reaches the handler. SFENCE.VMA, PMP CSR writes, and privilege-changing terminators complete in the preceding instruction and force the next dispatch to a boundary before the preflight.

The optimization deliberately removes one redundant `fetch_phys` call, so the non-architectural TLB hit counter will decrease by exactly one on its positive path. That is the behavior the focused positive test must assert; walks/flushes and architectural results must otherwise retain baseline meaning.

### P5 — code-write drain: HELD

Device/DMA writes are drained before preflight at line 4864. `next_micro_op` also drains at lines 4031–4035 after receiving the hint but before consulting the physically keyed decoded cache at lines 4053–4059. The drain invalidates the decoded page and matching compiled page at lines 3986–4004. Consequently, even a conservatively pending write cannot make the consumer reuse a stale decoded block: a touched code page is removed before lookup, after which the miss path decodes current bytes at line 4064.

No operation between the preflight at line 4918 and fallback call at line 4926 can create a new guest/DMA write-log entry.

### P6 — breakpoint, counters, capture, and CSR ordering: HELD

The candidate does not move the cached-step sequence: counter arming remains line 3916; execute-trigger check remains lines 3917–3927; execute remains lines 3934–3940; retire counter and capture remain lines 3941–3942; code-write drain remains line 3959; outer clock/IRQ accounting remains lines 4939–4942.

A sink returning `wants_records() == true` prevents the JIT attempt at line 4917, so it receives no hint and continues through the established interpreter/capture route. Returning `wants_records() == false` permits JIT admission only when `jit_active()` and `sample_boundary` are also true. That flag does not elide retirement callbacks or metadata for interpreted instructions: public `run_traced` retains `RunCapture::Traced`, constructs `RecordingCapture` on cached fallback at lines 100–104, and invokes the retirement callback at line 3942 after each successful interpreted instruction, including an uncompiled fallback that consumed the PA hint. This preserves the held E5-T26p contract. No public API is added: all changed signatures (`RunCapture::step`, `step_cached_with_capture`, `next_micro_op`, and `try_jit_block`) are private.

### P7 — bounded diff/no compatibility expansion: HELD

The diff only threads an `Option<u64>` through private dispatch and consumes it at the existing translation point. It adds no public compatibility layer and does not alter the existing public interpreter or tracing routes.

## Required minimal deterministic test matrix

Create one focused integration target, for example `crates/core/tests/fetch_preflight.rs`, and run only:

`cargo test -p wasm-vm-core --test fetch_preflight`

Use the existing public `Machine`/`Hart`/`Tlb` observations and public traced interpreter route; do not add a public fetch-count API.

| Case | Exact setup | Required assertions |
|---|---|---|
| Successful uncompiled entry | Warm an Sv39 executable mapping and decoded entry; install a deterministic executor whose `is_compiled(PA)` is false; JIT on; put PC at that entry; snapshot `hart().tlb.hits()` and run one instruction. | TLB hits increase by **1**, not 2; walks do not increase; one instruction retires; PC/register/memory/counter result equals an otherwise identical `run_traced` interpreter oracle. |
| Translation fault and PMP denial | Two subcases at an entry: unmapped Sv39 VA, then mapped VA denied execute by effective PMP. Executor still reports uncompiled for successful queries. | Each produces the exact expected instruction page/access fault and `tval`; no instruction retires and no capture record appears. The unmapped case performs two failed walks (preflight plus ordinary fallback), proving no fault hint was exported. |
| Other JIT refusal | Two subcases with `is_compiled(PA) == true`: decoded block larger than `remaining_work`, and executor metadata call returning `None` before execution. | Interpreter fallback executes exactly one instruction; TLB hits increase by **2** (preflight plus ordinary fallback), proving these refusals do not receive the uncompiled hint; architectural state/counters equal the interpreter oracle. |
| Invalidation before use | Three compact subcases after warming mapping/cache: remap + guest SFENCE.VMA; effective PMP execute revoke; host/code-page write before the bounded run. | Remap executes bytes from the new PA; PMP revoke traps; code write executes newly written bytes. No stale decoded/compiled entry is used; results match the public traced interpreter oracle. |
| Trigger/capture ordering | Arm an execute trigger on the entry for a normal `run(1)`, then separately run one successful instruction through an observing traced sink. | Trigger case takes breakpoint after only the preflight translation, with no retire/counter increment or sink record. Observing traced case emits exactly one retirement record and matches PC/register/memory/counters, confirming the hint path is excluded for record-requiring capture. |

This matrix is intentionally narrow. It directly distinguishes one translation from two, attacks all hint-export boundaries, and checks the ordering surfaces named in the review request without a broad gauntlet, cold clone, browser boot, benchmark duplication, or API expansion.

## Bounded task acceptance

The implementation task may adopt this private same-dispatch hint shape if and only if the focused matrix passes and the worker's separate actual-WASM benchmark demonstrates a material benefit. Keep the hint local to one dispatch iteration and to `is_compiled == false`; do not generalize it to compiled short-tail/metadata refusals without a separate proof.
