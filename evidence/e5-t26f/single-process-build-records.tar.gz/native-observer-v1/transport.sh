set -eu
/bin/busybox | head -n 1
/work/observer-tests
. /work/transport-helper.sh
e5_pid=111 e5_parent=$$
exec 3>/tmp/e5t26f-parent-writer
e5_observe
test "$e5_seen" = '111/777/4/0100000/5/0100002/|rchar:	100|wchar: 89 |syscr: 19|syscw: 5'
printf 'parent-retained' >&3
exec 3>&-
test "$(cat /tmp/e5t26f-parent-writer)" = parent-retained
printf 'PASS: actual observer_main getppid/FD3 under BusyBox exec substitution; controlled proc only\n'
