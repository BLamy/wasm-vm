// Finish the authenticated companion's summary, retaining browser bridge frames verbatim.
// run.mjs and its failed extra frame-shape assertion remain byte-identical in the audit trail.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import * as fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { bindNames, summarize } from '../../../tools/verify/e5-t22c-symbolize-cpu.mjs';

const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const target = 'target/e5-t26f/single-process-symbols';
const output = 'evidence/e5-t26f/single-process-cpu-symbols';
const postprocess = `${output}/postprocess-01`;
const recordingRoot = 'evidence/e5-t26f/single-process-observer-05b82bc6/cpu';
const profilePath = `${recordingRoot}/record/interaction-cpu.json`;
const releasePath = 'web/pkg/wasm_vm_wasm_bg.wasm';
const head = '05b82bc688a34e6a1abef7b6c761c01bf4a3f7c6';
const releaseSha = '39c674d0707a1a0d4348df078128b8a83cd9bec0b5fe943239f25497b3bf127c';
const profileSha = '1ca58077d82dda63ab722e9a58d12da102f7ac215669fee43b6433cfafa70b9a';
const runtimeSha = 'f897f34951ca3ab59909f0ce6bbe2e8a68a6620cdace4d1e4eca617cbd601ce8';
const abs = p => path.resolve(repo, p);
const sha = b => createHash('sha256').update(b).digest('hex');
const read = p => fs.readFile(abs(p));
const readJson = async p => JSON.parse(await read(p));
const json = v => `${JSON.stringify(v, null, 2)}\n`;
const write = (p, v) => fs.writeFile(abs(`${postprocess}/${p}`), v, { flag: 'wx' });

async function record(p) {
  const realpath = await fs.realpath(abs(p));
  assert.equal(realpath, abs(p), `symlink: ${p}`);
  const stat = await fs.lstat(realpath);
  assert.ok(stat.isFile());
  const bytes = await read(p);
  assert.equal(bytes.length, stat.size);
  return { path: p, realpath, size: bytes.length, sha256: sha(bytes) };
}

async function runtimeTree() {
  const entries = [];
  async function visit(relative) {
    for (const name of (await fs.readdir(abs(path.join('web', relative)))).sort()) {
      const next = path.join(relative, name);
      if (!(['src', 'pkg', 'bench'].includes(next.split(path.sep)[0]) ||
        (!next.includes(path.sep) && /\.(?:js|mjs|html|css|json)$/u.test(next)))) continue;
      const stat = await fs.lstat(abs(path.join('web', next)));
      assert.ok(!stat.isSymbolicLink());
      if (stat.isDirectory()) await visit(next);
      else { assert.ok(stat.isFile()); entries.push([next, stat.size, sha(await read(path.join('web', next)))]); }
    }
  }
  await visit('');
  return { sha256: sha(JSON.stringify(entries)), entries };
}

const startedAt = new Date().toISOString();
// Exclusive mkdir preserves the failed first driver's records and refuses in-place retries.
await fs.mkdir(abs(postprocess));
await fs.mkdir(abs(`${postprocess}/logs`));
// Marker first: neither this continuation nor run.mjs reads an unclosed profile.
const closure = await readJson(`${recordingRoot}/exit.json`);
assert.deepEqual(closure, { code: 1, signal: null });
const original = await readJson(`${output}/inputs-before.json`);
const previous = await readJson(`${output}/failure.json`);
assert.equal(previous.originalInputsUnchanged, true);
assert.equal(previous.error, 'AssertionError [ERR_ASSERTION]: all release module frames must carry an index');
const precheck = {
  files: await Promise.all(original.files.map(f => record(f.path))), runtime: await runtimeTree(),
};
assert.deepEqual(precheck, original, 'an original input changed before continuation');
const selfBefore = await record(path.relative(repo, fileURLToPath(import.meta.url)));
const nodeBefore = await record(process.execPath);
const bindingProof = await readJson(`${output}/section-binding.json`);
assert.equal(bindingProof.release.sha256, releaseSha);
assert.equal(bindingProof.named.sha256, '44ee774b2c8bca1bfc82426944f01e6c79b85dffcccdd6488d953342f7e6eba0');
assert.deepEqual(await record(bindingProof.named.path), bindingProof.named);

// Reauthenticate all noncustom section ids and bytes before reading names or calculating ranks.
const binding = bindNames(await read(releasePath), await read(bindingProof.named.path));
assert.equal(binding.releaseSha256, releaseSha);
assert.equal(binding.namedSha256, bindingProof.named.sha256);
assert.deepEqual(binding.sections, bindingProof.sections);
assert.equal(binding.names.size, bindingProof.names);

const recording = await readJson(profilePath);
const post = await readJson(`${recordingRoot}/record/post-restore.json`);
const invocation = await readJson(`${recordingRoot}/invocation.json`);
assert.equal(sha(await read(profilePath)), profileSha);
assert.equal(post.milestones.cpuProfile.sha256, profileSha);
assert.equal(post.milestones.cpuProfile.status, 'saved');
for (const value of [recording.head, post.head, invocation.head, post.milestones.run.binding.head]) assert.equal(value, head);
for (const value of [recording.runtimeSha256, original.runtime.sha256, post.milestones.run.binding.runtimeSha256]) assert.equal(value, runtimeSha);
assert.equal(recording.acceptance, false);
assert.equal(recording.diagnostic, true);
assert.equal(post.milestones.run.diagnostic.cpu, true);
assert.equal(post.milestones.run.diagnostic.latency, false);
const moduleUrl = new URL('./pkg/wasm_vm_wasm_bg.wasm', recording.url).href;
const moduleNodes = recording.profile.nodes.filter(n => n.callFrame.url === moduleUrl);
const indexedNodes = moduleNodes.filter(n => /^wasm-function\[(\d+)\]$/.test(n.callFrame.functionName));
const bridgeNodes = moduleNodes.filter(n => !indexedNodes.includes(n));
assert.equal(moduleNodes.length, 237);
assert.equal(indexedNodes.length, 234);
assert.equal(bridgeNodes.length, 3);
assert.ok(bridgeNodes.every(n => n.callFrame.functionName.startsWith('js-to-wasm:')));
const indices = [...new Set(indexedNodes.map(n => Number(/^wasm-function\[(\d+)\]$/.exec(n.callFrame.functionName)[1])))].sort((a, b) => a - b);
assert.ok(indices.every(index => binding.names.has(index)), 'unresolved indexed release frame');
const ids = new Set(recording.profile.nodes.map(n => n.id)), children = new Set();
assert.equal(ids.size, recording.profile.nodes.length);
for (const n of recording.profile.nodes) for (const child of n.children ?? []) {
  assert.ok(ids.has(child) && !children.has(child), 'existing child and single parent');
  children.add(child);
}
assert.equal(ids.size - children.size, 1, 'one root');
const summary = summarize(recording, binding.names);
assert.equal(summary.samples, post.milestones.cpuProfile.samples);
assert.equal(summary.self.reduce((total, row) => total + row.us, 0), summary.totalUs);
assert.ok(summary.inclusive.every(row => row.us <= summary.totalUs));
const nodesById = new Map(recording.profile.nodes.map(n => [n.id, n]));
const categories = new Map();
for (let i = 0; i < recording.profile.samples.length; ++i) {
  const frame = nodesById.get(recording.profile.samples[i]).callFrame;
  const category = frame.url === moduleUrl ? (/^wasm-function\[(\d+)\]$/.test(frame.functionName)
    ? 'authenticated-indexed-release' : 'literal-release-bridge') : frame.url.startsWith('wasm://')
    ? 'unmapped-generated-wasm' : frame.url ? 'literal-javascript-or-other-url' : 'literal-runtime-or-synthetic';
  const value = categories.get(category) ?? { samples: 0, us: 0 };
  value.samples += 1; value.us += recording.profile.timeDeltas[i]; categories.set(category, value);
}
const selfCategories = [...categories].map(([category, value]) => ({ category, ...value,
  percent: 100 * value.us / summary.totalUs })).sort((a, b) => b.us - a.us);
assert.equal(selfCategories.reduce((sum, row) => sum + row.us, 0), summary.totalUs);

const after = {
  files: await Promise.all(original.files.map(f => record(f.path))), runtime: await runtimeTree(),
};
assert.deepEqual(after, original, 'original inputs changed during continuation');
assert.deepEqual(await record(bindingProof.named.path), bindingProof.named);
assert.deepEqual(await record(selfBefore.path), selfBefore);
assert.deepEqual(await record(nodeBefore.path), nodeBefore);
const command = {
  executable: process.execPath, argv: [selfBefore.path], cwd: repo,
  startedAt, finishedAt: new Date().toISOString(), code: 0, signal: null,
  action: 'All-section reauthentication and offline summary only; companion reused after successful authentication.',
  script: selfBefore, node: { ...nodeBefore, version: process.version },
};
const versions = {
  bindgen: (await read(`${output}/logs/01-wasm-bindgen-version.stdout.log`)).toString().trim(),
  optimizer: (await read(`${output}/logs/02-wasm-opt-version.stdout.log`)).toString().trim(),
};
const result = {
  schema: 'wasm-vm.e5-t26f.single-process-cpu-symbols.v1',
  acceptance: false, head, runtimeSha256: runtimeSha,
  releaseSha256: binding.releaseSha256, namedSha256: binding.namedSha256,
  namedPath: bindingProof.named.path, sections: binding.sections, names: Object.fromEntries(binding.names),
  originalInputsUnchanged: true,
  authentication: {
    allNoncustomSectionsEqual: true, runtimeAggregateMatches: true, profileMatchesSavedCaptureSha: true,
    closure, profile: original.files.find(f => f.path === profilePath),
    rawInput: original.files.find(f => f.path === 'target/wasm32-unknown-unknown/release/wasm_vm_wasm.wasm'),
    tools: original.files.filter(f => f.path.includes('/.wasm-pack/')), versions,
    originalInputManifest: `${output}/inputs-before.json`, preservedInputManifest: `${postprocess}/inputs-after.json`,
    initialDriverNote: 'The additional assertion that all module-URL frames carry function indices failed after successful section equality. Chrome js-to-wasm bridges are now kept verbatim; the recorded failed driver is preserved.',
  },
  commands: [...previous.commands, command],
  coverage: {
    moduleUrl, moduleNodes: moduleNodes.length, indexedNodes: indexedNodes.length,
    distinctFunctionIndices: indices.length, resolvedFunctionIndices: indices, unresolvedFunctionIndices: [],
    selfCategories,
    unmappedBridgeFrames: bridgeNodes.map(n => ({ nodeId: n.id, ...n.callFrame })),
    otherWasmUrls: [...new Set(recording.profile.nodes.map(n => n.callFrame.url).filter(url => url.startsWith('wasm://')))].sort(),
    note: 'Names map only indexed frames at the exact served-module URL. JS, js-to-wasm bridges and generated wasm:// frames retain their original labels and URLs.',
  },
  measurement: {
    intervalUs: recording.intervalUs, startTime: recording.profile.startTime, endTime: recording.profile.endTime,
    profileDurationUs: recording.profile.endTime - recording.profile.startTime,
    timeDeltaSumUs: summary.totalUs, samplingOnly: true,
    selfDefinition: 'Sum of timeDeltas for samples with this leaf label.',
    inclusiveDefinition: 'Sum of timeDeltas when this label appears on the sampled parent chain, counted once per sample.',
    limitations: [
      'Inclusive rows overlap across ancestors and descendants and must not be added as disjoint costs.',
      'Ranks merge equal labels, and percentages use the complete sampled timeDelta sum as denominator.',
      'Profile duration and sample-weighted times are not an unprofiled interaction benchmark; sampling can perturb execution.',
      'Generated Wasm modules and bridge frames have no authenticated Rust symbol mapping here.',
      'The diagnostic supplies sampled attribution only, with no performance improvement or causal claim.',
    ],
  },
  profiles: { 'interaction-cpu.json': { sha256: profileSha, ...summary } },
};
await write('inputs-after.json', json(after));
await write('commands.json', json(result.commands));
await write('logs/06-finish.command.json', json(command));
await write('cpu-summary.json', json(result));
const digest = sha(Buffer.from(json(result)));
const report = {
  status: 'authenticated', originalInputsUnchanged: true, summarySha256: digest,
  releaseSha256: releaseSha, namedSha256: binding.namedSha256,
  allNoncustomSections: binding.sections.length, names: binding.names.size,
  indexedNodes: indexedNodes.length, uniqueIndices: indices.length, bridgeNodes: bridgeNodes.length,
  selfCategories,
  totalUs: summary.totalUs, samples: summary.samples, profileDurationUs: result.measurement.profileDurationUs,
  selfTop10: summary.self.slice(0, 10), inclusiveTop12: summary.inclusive.slice(0, 12),
};
await write('logs/06-finish.stdout.log', json(report));
await write('logs/06-finish.exit.json', json({ code: 0, signal: null }));
const artifacts = [];
async function collect(directory) {
  for (const name of (await fs.readdir(abs(directory))).sort()) {
    const filename = path.join(directory, name), stat = await fs.lstat(abs(filename));
    assert.ok(!stat.isSymbolicLink());
    if (stat.isDirectory()) await collect(filename);
    else artifacts.push(await record(filename));
  }
}
await collect(target);
await collect(output);
await write('artifact-hashes.json', json(artifacts));
console.log(json(report));
