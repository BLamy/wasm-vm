// Package verified output with exclusive writes and keep every failed-run record intact.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { constants } from 'node:fs';
import * as fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { gzipSync, gunzipSync } from 'node:zlib';

const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const target = 'target/e5-t26f/single-process-symbols';
const output = 'evidence/e5-t26f/single-process-cpu-symbols';
const abs = p => path.resolve(repo, p);
const sha = b => createHash('sha256').update(b).digest('hex');
const json = v => `${JSON.stringify(v, null, 2)}\n`;
const read = p => fs.readFile(abs(p));
const write = (p, b) => fs.writeFile(abs(p), b, { flag: 'wx' });
async function record(p) {
  assert.equal(await fs.realpath(abs(p)), abs(p));
  const stat = await fs.lstat(abs(p)); assert.ok(stat.isFile());
  const bytes = await read(p); assert.equal(bytes.length, stat.size);
  return { path: p, realpath: abs(p), size: bytes.length, sha256: sha(bytes) };
}
const before = JSON.parse(await read(`${output}/inputs-before.json`));
const originals = await Promise.all(before.files.map(f => record(f.path)));
assert.deepEqual(originals, before.files);
const summary = await read(`${output}/postprocess-01/cpu-summary.json`);
assert.equal(sha(summary), 'da4e6f6eddaa18ce5d0200cdc65c7ed72b9bd6bc05b5536f2c48f01aae2d3100');
const info = JSON.parse(summary), named = await read(info.namedPath);
assert.equal(sha(named), info.namedSha256);
assert.equal(info.originalInputsUnchanged, true);
assert.equal(info.authentication.allNoncustomSectionsEqual, true);
const archivePath = `${target}/named.wasm.gz`;
const archive = gzipSync(named, { level: 9 });
assert.deepEqual(gunzipSync(archive), named);
await write(archivePath, archive);
await fs.copyFile(abs(`${output}/postprocess-01/cpu-summary.json`), abs(`${output}/cpu-summary.json`), constants.COPYFILE_EXCL);
assert.deepEqual(await read(`${output}/cpu-summary.json`), summary);
const after = await Promise.all(before.files.map(f => record(f.path)));
assert.deepEqual(after, before.files, 'original input changed while packaging');
const recordJson = {
  schema: 'wasm-vm.e5-t26f.single-process-cpu-symbols-seal.v1', acceptance: false,
  command: { executable: process.execPath, argv: [path.relative(repo, fileURLToPath(import.meta.url))], cwd: repo, code: 0 },
  summary: await record(`${output}/cpu-summary.json`),
  sourceSummary: await record(`${output}/postprocess-01/cpu-summary.json`),
  named: await record(info.namedPath), archive: await record(archivePath),
  archiveRoundtripEqualsNamed: true, originalInputsUnchanged: true,
  originalInputCount: after.length, runtimePreservationRecord: `${output}/postprocess-01/inputs-after.json`,
};
await write(`${output}/seal.json`, json(recordJson));
const artifacts = [];
async function collect(directory) {
  for (const name of (await fs.readdir(abs(directory))).sort()) {
    const filename = path.join(directory, name), stat = await fs.lstat(abs(filename));
    assert.ok(!stat.isSymbolicLink());
    if (stat.isDirectory()) await collect(filename);
    else artifacts.push(await record(filename));
  }
}
await collect(target); await collect(output);
await write(`${output}/SHA256SUMS`, artifacts.map(f => `${f.sha256}  ${f.path}\n`).join(''));
for (const artifact of artifacts) assert.deepEqual(await record(artifact.path), artifact);
console.log(json({ status: 'sealed', artifacts: artifacts.length, ...recordJson }));
