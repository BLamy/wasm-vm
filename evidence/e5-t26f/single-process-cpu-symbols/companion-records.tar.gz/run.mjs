// One frozen offline symbolization. All generated artifacts stay in the two assigned roots.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFile } from 'node:child_process';
import * as fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { bindNames, summarize } from '../../../tools/verify/e5-t22c-symbolize-cpu.mjs';

const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const target = path.join(repo, 'target/e5-t26f/single-process-symbols');
const evidence = path.join(repo, 'evidence/e5-t26f/single-process-cpu-symbols');
const companion = path.join(target, 'companion-01');
const recordingRoot = 'evidence/e5-t26f/single-process-observer-05b82bc6/cpu';
const raw = 'target/wasm32-unknown-unknown/release/wasm_vm_wasm.wasm';
const release = 'web/pkg/wasm_vm_wasm_bg.wasm';
const distRelease = 'web/dist/pkg/wasm_vm_wasm_bg.wasm';
const profileFile = `${recordingRoot}/record/interaction-cpu.json`;
const postFile = `${recordingRoot}/record/post-restore.json`;
const exitFile = `${recordingRoot}/exit.json`;
const invocationFile = `${recordingRoot}/invocation.json`;
const symbolizerFile = 'tools/verify/e5-t22c-symbolize-cpu.mjs';
const symbolizerTests = 'tools/verify/e5-t22c-symbolize-cpu.test.mjs';
const bindgen = '/Users/blamy/Library/Caches/.wasm-pack/wasm-bindgen-cargo-install-0.2.126/wasm-bindgen';
const optimizer = '/Users/blamy/Library/Caches/.wasm-pack/wasm-opt-50385c9e73ccee70/bin/wasm-opt';
const binaryen = '/Users/blamy/Library/Caches/.wasm-pack/wasm-opt-50385c9e73ccee70/lib/libbinaryen.dylib';
const head = '05b82bc688a34e6a1abef7b6c761c01bf4a3f7c6';
const releaseSha = '39c674d0707a1a0d4348df078128b8a83cd9bec0b5fe943239f25497b3bf127c';
const profileSha = '1ca58077d82dda63ab722e9a58d12da102f7ac215669fee43b6433cfafa70b9a';
const runtimeSha = 'f897f34951ca3ab59909f0ce6bbe2e8a68a6620cdace4d1e4eca617cbd601ce8';
const hash = b => createHash('sha256').update(b).digest('hex');
const abs = p => path.resolve(repo, p);
const relative = p => path.relative(repo, p);
const exec = promisify(execFile);
const json = value => `${JSON.stringify(value, null, 2)}\n`;
const write = (filename, bytes) => fs.writeFile(filename, bytes, { flag: 'wx' });
let commandNumber = 0;
let before;
const commands = [];

async function fileRecord(filename) {
  const filenameAbs = abs(filename);
  assert.equal(await fs.realpath(filenameAbs), filenameAbs, `symlink input: ${filename}`);
  const stat = await fs.lstat(filenameAbs);
  assert.ok(stat.isFile() && stat.size > 0, `nonempty regular input: ${filename}`);
  const bytes = await fs.readFile(filenameAbs);
  assert.equal(bytes.length, stat.size);
  return { path: filename, realpath: filenameAbs, size: bytes.length, sha256: hash(bytes) };
}

// Same sorted path/size/digest tuples and inclusion predicate as the recorder's
// diagnosticBinding()/treeDigest(). This ties the individual served Wasm to its aggregate.
async function runtimeTree() {
  const entries = [];
  async function visit(relativePath) {
    for (const name of (await fs.readdir(path.join(repo, 'web', relativePath))).sort()) {
      const next = path.join(relativePath, name);
      if (!(['src', 'pkg', 'bench'].includes(next.split(path.sep)[0]) ||
        (!next.includes(path.sep) && /\.(?:js|mjs|html|css|json)$/u.test(next)))) continue;
      const filename = path.join(repo, 'web', next), stat = await fs.lstat(filename);
      assert.ok(!stat.isSymbolicLink(), `symlink in runtime: ${next}`);
      if (stat.isDirectory()) await visit(next);
      else {
        assert.ok(stat.isFile());
        entries.push([next, stat.size, hash(await fs.readFile(filename))]);
      }
    }
  }
  await visit('');
  return { sha256: hash(JSON.stringify(entries)), entries };
}

const inputPaths = [exitFile, invocationFile, profileFile, postFile,
  `${recordingRoot}/record/failure-post-restore-interaction-checks.json`, `${recordingRoot}/run.log`,
  raw, release, distRelease, bindgen, optimizer, binaryen, symbolizerFile, symbolizerTests,
  'tools/verify/e5-t26f-browser-roundtrip.mjs', 'tools/build-web-dist.sh', 'crates/wasm/Cargo.toml',
  'evidence/e5-t26f/cpu-560c6743/README.md', relative(fileURLToPath(import.meta.url))];

async function snapshot() {
  return { files: await Promise.all(inputPaths.map(fileRecord)), runtime: await runtimeTree() };
}

async function command(label, executable, argv) {
  const prefix = `${String(++commandNumber).padStart(2, '0')}-${label}`;
  const env = { PATH: '/usr/bin:/bin', LANG: 'C', LC_ALL: 'C', TZ: 'UTC', TMPDIR: path.join(companion, 'tmp') };
  const record = { executable, argv, cwd: repo, env, startedAt: new Date().toISOString() };
  await write(path.join(evidence, 'logs', `${prefix}.command.json`), json(record));
  console.log(`Running ${label}`);
  let result, error;
  try { result = await exec(executable, argv, { cwd: repo, env, timeout: 240_000, maxBuffer: 4 * 1024 * 1024 }); }
  catch (caught) { error = caught; result = caught; }
  await write(path.join(evidence, 'logs', `${prefix}.stdout.log`), result.stdout ?? '');
  await write(path.join(evidence, 'logs', `${prefix}.stderr.log`), result.stderr ?? '');
  const exit = { code: error ? error.code ?? null : 0, signal: error?.signal ?? null, finishedAt: new Date().toISOString() };
  await write(path.join(evidence, 'logs', `${prefix}.exit.json`), json(exit));
  commands.push({ ...record, ...exit, logPrefix: relative(path.join(evidence, 'logs', prefix)) });
  if (error) throw error;
  return result.stdout.trim();
}

// Read the closure marker before touching the CPU profile. Exit 1 is a closed diagnostic
// with an acceptance failure, not an open/incomplete CPU recording.
const closure = JSON.parse(await fs.readFile(abs(exitFile), 'utf8'));
assert.ok(Number.isInteger(closure.code) && closure.signal === null, 'recording must be closed');
for (const directory of [companion, evidence]) {
  const stat = await fs.lstat(directory).catch(error => { if (error.code !== 'ENOENT') throw error; return null; });
  assert.equal(stat, null, `fresh output required: ${directory}`);
}
await fs.mkdir(companion);
await fs.mkdir(evidence);
await fs.mkdir(path.join(evidence, 'logs'));
await fs.mkdir(path.join(companion, 'tmp'));

try {
  before = await snapshot();
  await write(path.join(evidence, 'inputs-before.json'), json(before));
  const byPath = new Map(before.files.map(f => [f.path, f]));
  for (const p of [release, distRelease]) assert.equal(byPath.get(p).sha256, releaseSha, p);
  assert.equal(byPath.get(raw).sha256, '49da07b51a507a453704bb3698a217d8f1cbd9474f26816bfe79d397c167d336');
  assert.equal(byPath.get(bindgen).sha256, '41e7ae3a0f1db74ebbfbbd65b0271f44afcc3b3b1bb1a1f893c8ab5033bddad5');
  assert.equal(byPath.get(optimizer).sha256, 'e541f303219f9b6caa1661daea44510249da278736b7f2e320910051e7bbd4cd');
  assert.equal(byPath.get(profileFile).sha256, profileSha);
  assert.equal(before.runtime.sha256, runtimeSha, 'served runtime aggregate differs');
  assert.deepEqual(before.runtime.entries.find(([p]) => p === 'pkg/wasm_vm_wasm_bg.wasm'),
    ['pkg/wasm_vm_wasm_bg.wasm', byPath.get(release).size, releaseSha]);

  const recording = JSON.parse(await fs.readFile(abs(profileFile), 'utf8'));
  const post = JSON.parse(await fs.readFile(abs(postFile), 'utf8'));
  const invocation = JSON.parse(await fs.readFile(abs(invocationFile), 'utf8'));
  for (const h of [recording.head, post.head, invocation.head, post.milestones.run.binding.head]) assert.equal(h, head);
  assert.equal(recording.runtimeSha256, runtimeSha);
  assert.equal(post.milestones.run.binding.runtimeSha256, runtimeSha);
  assert.equal(post.milestones.cpuProfile.status, 'saved');
  assert.equal(post.milestones.cpuProfile.sha256, profileSha);
  assert.equal(post.milestones.cpuProfile.samples, recording.profile.samples.length);
  assert.equal(post.milestones.cpuProfile.path, abs(profileFile));
  assert.equal(recording.acceptance, false);
  assert.equal(recording.diagnostic, true);
  assert.equal(recording.url, 'http://127.0.0.1:61637/linux-worker.js');
  assert.equal(recording.reason, 'interaction-observed');
  assert.equal(post.milestones.run.diagnostic.cpu, true);
  assert.equal(post.milestones.run.diagnostic.latency, false);
  assert.equal(invocation.config.E5_T26F_DIAGNOSTIC_CPU, '1');
  assert.equal(invocation.config.E5_T26F_DIAGNOSTIC_LATENCY, undefined);
  assert.equal(byPath.get('tools/verify/e5-t26f-browser-roundtrip.mjs').sha256,
    invocation.sourceBindings['tools/verify/e5-t26f-browser-roundtrip.mjs']);

  const versions = {
    bindgen: await command('wasm-bindgen-version', bindgen, ['--version']),
    optimizer: await command('wasm-opt-version', optimizer, ['--version']),
  };
  assert.equal(versions.bindgen, 'wasm-bindgen 0.2.126');
  await command('symbolizer-tests', process.execPath, ['--test', symbolizerTests]);
  await command('wasm-bindgen', bindgen, ['--target', 'web', '--out-dir', companion,
    '--out-name', 'wasm_vm_wasm', raw]);
  const namedFile = path.join(companion, 'named.wasm');
  await command('wasm-opt-names', optimizer, ['-O', '-g', path.join(companion, 'wasm_vm_wasm_bg.wasm'), '-o', namedFile]);

  // This comparison is mandatory and precedes every access to the name mapping.
  // A mismatch throws and exits; no alternate source, flags or old named artifacts are tried.
  const binding = bindNames(await fs.readFile(abs(release)), await fs.readFile(namedFile));
  assert.equal(binding.releaseSha256, releaseSha);
  await write(path.join(evidence, 'section-binding.json'), json({
    algorithm: 'bindNames: ordered id+payload equality for ALL noncustom sections',
    symbolizer: byPath.get(symbolizerFile),
    release: byPath.get(release), named: await fileRecord(relative(namedFile)),
    sections: binding.sections, names: binding.names.size, allNoncustomSectionsEqual: true,
  }));
  console.log(`Authenticated ${binding.sections.length} noncustom sections; ${binding.names.size} names`);

  const moduleUrl = new URL('./pkg/wasm_vm_wasm_bg.wasm', recording.url).href;
  const moduleNodes = recording.profile.nodes.filter(n => n.callFrame.url === moduleUrl);
  const indexed = moduleNodes.map(n => /^wasm-function\[(\d+)\]$/.exec(n.callFrame.functionName));
  assert.ok(moduleNodes.length > 0);
  assert.ok(indexed.every(Boolean), 'all release module frames must carry an index');
  const indices = [...new Set(indexed.map(m => Number(m[1])))].sort((a, b) => a - b);
  assert.ok(indices.every(index => binding.names.has(index)), 'an observed module frame is unnamed');
  const ids = new Set(recording.profile.nodes.map(n => n.id));
  assert.equal(ids.size, recording.profile.nodes.length, 'duplicate profile node');
  const childIds = new Set();
  for (const n of recording.profile.nodes) for (const child of n.children ?? []) {
    assert.ok(ids.has(child) && !childIds.has(child), 'profile tree child must exist and have one parent');
    childIds.add(child);
  }
  assert.equal(ids.size - childIds.size, 1, 'one CPU profile root required');
  const summary = summarize(recording, binding.names);
  assert.equal(summary.self.reduce((total, row) => total + row.us, 0), summary.totalUs);
  assert.ok(summary.inclusive.every(row => row.us <= summary.totalUs));

  const after = await snapshot();
  await write(path.join(evidence, 'inputs-after.json'), json(after));
  assert.deepEqual(after, before, 'original inputs changed during offline symbolization');
  const coverage = {
    moduleUrl, releaseNodes: moduleNodes.length, distinctReleaseFunctionIndices: indices.length,
    resolvedFunctionIndices: indices, unresolvedFunctionIndices: [],
    otherWasmUrls: [...new Set(recording.profile.nodes.map(n => n.callFrame.url).filter(url => url.startsWith('wasm://')))].sort(),
    note: 'Only the exact served-module URL is mapped. Other wasm:// frames retain their original labels and URLs.',
  };
  const result = {
    schema: 'wasm-vm.e5-t26f.single-process-cpu-symbols.v1',
    acceptance: false, head, runtimeSha256: runtimeSha,
    releaseSha256: binding.releaseSha256, namedSha256: binding.namedSha256,
    namedPath: relative(namedFile), sections: binding.sections, names: Object.fromEntries(binding.names),
    originalInputsUnchanged: true,
    authentication: { allNoncustomSectionsEqual: true, runtimeAggregateMatches: true,
      profileMatchesSavedCaptureSha: true, closure, profile: byPath.get(profileFile),
      invocation: byPath.get(invocationFile), capture: byPath.get(postFile),
      rawInput: byPath.get(raw), tools: [byPath.get(bindgen), byPath.get(optimizer), byPath.get(binaryen)], versions },
    commands, coverage,
    measurement: { intervalUs: recording.intervalUs, startTime: recording.profile.startTime,
      endTime: recording.profile.endTime, profileDurationUs: recording.profile.endTime - recording.profile.startTime,
      timeDeltaSumUs: summary.totalUs, samplingOnly: true,
      selfDefinition: 'Sum of timeDeltas for samples with this leaf label.',
      inclusiveDefinition: 'Sum of timeDeltas when this label appears on the sampled parent chain, counted once per sample.',
      limitations: [
        'Inclusive rows overlap across ancestors and descendants and must not be added as disjoint costs.',
        'Ranks merge equal labels, and percentages use the complete sampled timeDelta sum as denominator.',
        'Profile durations and sample-weighted times are not an unprofiled interaction benchmark.',
        'Other generated Wasm modules have no authenticated Rust symbol mapping here.',
        'This diagnostic establishes sampled attribution only; it makes no performance improvement or causal claim.',
      ] },
    profiles: { 'interaction-cpu.json': { sha256: profileSha, ...summary } },
  };
  await write(path.join(evidence, 'commands.json'), json(commands));
  await write(path.join(evidence, 'cpu-summary.json'), json(result));
  const manifest = [];
  async function collect(directory) {
    for (const name of (await fs.readdir(directory)).sort()) {
      const filename = path.join(directory, name), stat = await fs.lstat(filename);
      assert.ok(!stat.isSymbolicLink());
      if (stat.isDirectory()) await collect(filename);
      else manifest.push(await fileRecord(relative(filename)));
    }
  }
  await collect(companion);
  await collect(evidence);
  await write(path.join(evidence, 'artifact-hashes.json'), json(manifest));
  console.log(json({ status: 'authenticated', inputPreserved: true, releaseSha256: releaseSha,
    namedSha256: binding.namedSha256, sections: binding.sections.length, names: binding.names.size,
    coverage: { releaseNodes: moduleNodes.length, distinctIndices: indices.length },
    totalUs: summary.totalUs, samples: summary.samples,
    selfTop10: summary.self.slice(0, 10), inclusiveTop12: summary.inclusive.slice(0, 12) }));
} catch (error) {
  let preserved = null;
  if (before) {
    try { const after = await snapshot(); preserved = JSON.stringify(after) === JSON.stringify(before);
      await write(path.join(evidence, 'failure-inputs-after.json'), json(after)); }
    catch (checkError) { preserved = String(checkError).slice(0, 2000); }
  }
  await write(path.join(evidence, 'failure.json'), json({ acceptance: false, originalInputsUnchanged: preserved,
    error: String(error).slice(0, 8000), commands }));
  console.error(String(error).slice(0, 4000));
  process.exitCode = 1;
}
