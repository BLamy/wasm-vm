from pathlib import Path
import hashlib,json,re,subprocess
R=Path.cwd();O=R/'evidence/virgl-sine/verifier';U=O/'unpacked';sha=lambda b:hashlib.sha256(b).hexdigest()
paths=['renderer/virgl-shader/raw_bits.c','renderer/virgl-shader/bridge.c','renderer/virgl-shader/raw_bits.h','renderer/virgl-command/constant-domain.mjs']
patch=subprocess.check_output(['git','diff','--unified=0','322bb56e..c6e56fa8','--',*paths],text=True);added={};file=None;line=0
for s in patch.splitlines():
 if s.startswith('+++ b/'):file=s[6:];added[file]=[]
 elif s.startswith('@@'):line=int(re.search(r'\+(\d+)',s)[1])
 elif s.startswith('+')and not s.startswith('+++'):added[file].append((line,s[1:]));line+=1
 elif not s.startswith('-')and not s.startswith(('diff','index','---','\\')):line+=1
exports={label:json.loads((O/(label+'-coverage-export.json')).read_bytes())for label in ['hot','cold']}
# Line counts are intrinsic to the ORIGINAL profraw and matching archived
# binaries. LLVM textual show records each expansion; comments/types waive.
counts={}
for label in ['hot','cold']:
 for p in paths[:2]:
  seen={}
  for s in (O/(label+'-coverage-'+Path(p).name+'.txt')).read_text().splitlines():
   m=re.match(r'\s*(\d+)\|\s*([0-9.]+[kMGT]?)\|',s)
   if m:
    x=m[2];scale={'k':1000,'M':10**6,'G':10**9,'T':10**12}.get(x[-1],1);n=float(x[:-1]if scale!=1 else x)*scale;seen[int(m[1])]=max(seen.get(int(m[1]),0),n)
  counts[(label,p)]=seen
runtime=[];waivers=[]
for p in paths[:2]:
 for line,text in added[p]:
  c={label:counts[(label,p)].get(line,0)for label in ['hot','cold']}
  if any(c.values()):runtime.append(dict(path=p,line=line,source=text,originalProfileCounts=c,status='executed'))
  else:
   assert not text.strip()or text.strip().startswith(('/*','*','//','{','}'))or text.strip().startswith('static void sine_contract')or text.strip().startswith('static bool sine_domain_proved'),(p,line,text)
   waivers.append(dict(path=p,line=line,source=text,status='waived',reason='Nonexecuting function signature, brace or documentation; the adjacent function body is exercised in both original source-bound profiles.'))
for line,text in added[paths[2]]:waivers.append(dict(path=paths[2],line=line,source=text,status='waived',reason='Declarative opcode55, masks and compile-time separation assertion; no independent runtime behavior. Both recorded native/Wasm binaries execute SIN decoding/routing/emission and actual pinned opcodes retain FLOAT/REPL.'))
# Exact original V8 script offsets are bound to current immutable consumer code.
jspath=paths[3];js=(R/jspath).read_text();bindings=[]
for checkout in ['hot','cold/acceptance']:
 for seed in [389793865,2135058973,3399354483]:
  dir=U/checkout/f'gpu-{seed}';report=json.loads((dir/'report.json').read_bytes());raw=(dir/'browser-coverage.json').read_bytes();assert sha(raw)==report['browserCoverage']['sha256']
  script=next(s for s in json.loads(raw)['scripts']if s['source']==jspath);assert script['sha256']==sha((R/jspath).read_bytes());bindings.append(dict(label=checkout+'-'+str(seed),sha256=sha(raw),functions=script['coverage']['functions']))
# The original browser SIN probes do not exercise every delegated conversion
# bank checker; independent replay of the authenticated complete consumer table
# supplies source-bound Node V8 counts for that exact wrapper path.
for f in sorted((O/'node-consumer-coverage').glob('*.json')):
 j=json.loads(f.read_bytes())
 for script in j['result']:
  if script['url'].endswith('/'+jspath):bindings.append(dict(label='critic-node-owned-consumer',sha256=sha(f.read_bytes()),functions=script['functions']))
def effective(functions,offset):
 ranges=[r for f in functions for r in f['ranges']if r['startOffset']<=offset<r['endOffset']]
 if not ranges:return 0
 r=min(ranges,key=lambda r:r['endOffset']-r['startOffset']);return r['count']
for line,text in added[jspath]:
 if not text.strip():waivers.append(dict(path=jspath,line=line,status='waived',reason='Blank separation.'));continue
 # JavaScript source is ASCII at the changed region, so UTF16 and text offsets agree.
 offset=sum(len(s)+1 for s in js.splitlines()[:line-1])+len(text)-len(text.lstrip())
 c={b['label']:effective(b['functions'],offset)for b in bindings}
 assert any(c.values()),(line,text,c)
 runtime.append(dict(path=jspath,line=line,source=text,V8Counts=c,status='executed'))
# New opcode case labels inherit shared line mapping counts. Shared ternary
# metadata constants are additionally audited by whole old+adjacent-SIN results.
legacy=json.loads((U/'hot/legacy.json').read_bytes());profiles=sorted({c['added']['metadata']['sineBaseProfile']for c in legacy['cases']if c['ok']});consumer=json.loads((U/'hot/consumer.json').read_bytes());assert len(consumer['combined'])==4
out=dict(status='passed',changedRuntimeLines=runtime,waivers=waivers,nativeBindings=json.loads((O/'native-replays.json').read_bytes()),V8Bindings=[{k:v for k,v in b.items()if k!='functions'}for b in bindings],legacyWrapperBases=profiles,simultaneousWrapperBases=4,scope='Every changed C/mjs runtime line; every declaration individually waived with evidence for use. Full prior unrelated branch coverage is carried forward.');(O/'coverage-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(len(runtime),'changed runtime lines exercised;',len(waivers),'sound declarative waivers')
