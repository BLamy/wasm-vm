from pathlib import Path
import hashlib,json,subprocess,os
R=Path.cwd();O=R/'evidence/virgl-sine/verifier';U=O/'unpacked';sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for label,prefix,gprefix in [('hot','hot','generated'),('cold','cold/acceptance','cold-generated')]:
 b=U/gprefix/'sine-sanitize/sine-test';b.chmod(0o700);n=U/prefix/'native';env=dict(os.environ,LLVM_PROFILE_FILE=str(O/(label+'-replay.profraw')),ASAN_OPTIONS='abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
 run=subprocess.run([str(b)],input=(n/'cases.bin').read_bytes(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
 (O/(label+'-native-replay.log')).write_bytes(run.stdout);(O/(label+'-native-replay.stderr')).write_bytes(run.stderr)
 assert run.returncode==0 and run.stderr==b'' and run.stdout==(n/'native.log').read_bytes(),label+' exact recorded binary replay'
 profile=O/(label+'-original-merged.profdata');subprocess.run(['xcrun','llvm-profdata','merge','-sparse',str(n/'native.profraw'),'-o',str(profile)],check=True)
 export=subprocess.check_output(['xcrun','llvm-cov','export',str(b),'-instr-profile='+str(profile)])
 j=json.loads(export)
 for d in j['data']:
  d['files']=[f for f in d['files'] if any(f['filename'].endswith('/'+s) for s in ['bridge.c','raw_bits.c','native_tests/sine.c'])]
  d['functions']=[f for f in d['functions'] if any(any(p.endswith('/'+s) for s in ['bridge.c','raw_bits.c','native_tests/sine.c']) for p in f['filenames'])]
 (O/(label+'-coverage-export.json')).write_text(json.dumps(j,indent=2)+'\n');assert j==json.loads((n/'coverage.json').read_bytes()),label+' original profile reexport'
 for path in ['bridge.c','raw_bits.c','native_tests/sine.c']:
  text=subprocess.check_output(['xcrun','llvm-cov','show',str(b),'-instr-profile='+str(profile),'-show-line-counts-or-regions','-name-regex=.*','-path-equivalence='+str(Path(json.loads((n/'coverage.json').read_bytes())['data'][0]['files'][0]['filename']).parents[0])+','+str(R/'renderer/virgl-shader'),str(R/'renderer/virgl-shader'/path)],stderr=subprocess.STDOUT)
  (O/(label+'-coverage-'+path.replace('/','_')+'.txt')).write_bytes(text)
 rows.append(dict(label=label,binarySha256=sha(b.read_bytes()),fixtureSha256=sha((n/'cases.bin').read_bytes()),originalProfileSha256=sha((n/'native.profraw').read_bytes()),replayedLogSha256=sha(run.stdout),stderrSha256=sha(run.stderr),originalProfileExportSha256=sha((O/(label+'-coverage-export.json')).read_bytes()),originalProfileExportEqualsWorker=True,cases=1006,sourceBoundToRecordedBinary=True))
(O/'native-replays.json').write_text(json.dumps(dict(status='passed',records=rows),indent=2)+'\n');print(json.dumps(rows,indent=2))
