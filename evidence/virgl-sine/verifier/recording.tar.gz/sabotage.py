from pathlib import Path
import subprocess,json,hashlib,shutil
R=Path.cwd();O=R/'evidence/virgl-sine/verifier';rows=[];sha=lambda b:hashlib.sha256(b).hexdigest();src=R/'renderer/virgl-shader/raw_bits.c';original=src.read_text();files=subprocess.check_output(['git','ls-files','renderer/virgl-shader'],text=True).splitlines()
def replace_once(s,needle,replace):assert s.count(needle)==1,needle;return s.replace(needle,replace,1)
faults={
 'domain':replace_once(original,'return safe_raw_float(value) && (~value.zero & UINT32_C(0x7fffffff)) <= UINT32_C(0x41000000);','(void)value; return true;'),
 'broadcast':replace_once(original,'''      emit(w, " float_rhs = vec4(/* sine:SIN */ sin(");
      float_operand(w, p, instruction, 0, 0);
      emit(w, "));\\n");''','''      emit(w, " float_rhs = /* sine:SIN */ sin(vec4(");
      for (unsigned lane = 0; lane < 4; ++lane) {
         if (lane) emit(w, ", ");
         float_operand(w, p, instruction, 0, lane);
      }
      emit(w, "));\\n");'''),
 'result-facts':replace_once(original,'      case RAW_SIN:\n      case RAW_TEX:','      case RAW_SIN:\n         result[lane] = known_word(0);\n         result[lane].origin = RAW_FLOAT_SHADOW | RAW_OUTPUT | dependency;\n         break;\n      case RAW_TEX:')}
for fault,changed in faults.items():
 scratch=O/'sabotage'/fault;scratch.mkdir(parents=True,exist_ok=True)
 for name in files:
  p=scratch/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/name,p)
 (scratch/'renderer/virgl-shader/raw_bits.c').write_text(changed)
 with (O/('sabotage-'+fault+'-build.log')).open('wb')as log:subprocess.run(['bash','renderer/virgl-shader/build.sh','native'],cwd=scratch,stdout=log,stderr=subprocess.STDOUT,check=True)
 binary=scratch/'renderer/virgl-shader/build/native/virgl-shader';out=O/('sabotage-'+fault+'-guards.json');cmd=['node','renderer/virgl-shader/tests/sine-regressions.mjs','--native',str(binary),'--native-only','--output',str(out)]
 with (O/('sabotage-'+fault+'-guards.log')).open('wb')as log:result=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 assert result.returncode!=0 and json.loads(out.read_bytes())['status']=='failed','fault must contradict promoted native guards'
 rows.append(dict(fault=fault,source='renderer/virgl-shader/raw_bits.c',sourceSha256=sha(src.read_bytes()),mutatedSourceSha256=sha(changed.encode()),binarySha256=sha(binary.read_bytes()),guardSha256=sha((R/'renderer/virgl-shader/tests/sine-regressions.mjs').read_bytes()),exit=result.returncode,reportSha256=sha(out.read_bytes()),counterexample=json.loads(out.read_bytes())['failure']['counterexample']))
 assert src.read_text()==original,'production source remains frozen'
(O/'sabotage-regressions.json').write_text(json.dumps(dict(status='passed',records=rows),indent=2)+'\n');print('Domain removal, component broadcast and invented output facts all caught by promoted guards; originals untouched.')
