from pathlib import Path
import json,subprocess,struct,os,hashlib,importlib.util
R=Path.cwd();O=R/'evidence/virgl-sine/verifier';U=O/'unpacked';seed=1834637033
sha=lambda b:hashlib.sha256(b).hexdigest();P=R/'renderer/virgl-shader/tests/sine-capture-regressions.py';spec=importlib.util.spec_from_file_location('critic_sine',P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base=json.loads((U/'generated/sine-primary.json').read_bytes());have={r['text']for r in base}
source="""import {vectors,carrier,bytesFragment}from './tools/virgl-sine/cases.mjs';let cases=[];for(const v of vectors('SIN',1834637033))for(const variant of ['direct','swizzle-xxxx']){cases.push({name:v.name+'-'+variant,stage:'vertex',text:carrier('SIN',v,variant)});for(let i=0;i<4;i++)cases.push({name:v.name+'-'+variant+'-'+i,stage:'fragment',text:bytesFragment('SIN',v,i,variant)});}console.log(JSON.stringify(cases));"""
cases=[r for r in json.loads(subprocess.check_output(['node','--input-type=module','-e',source])) if r['text']not in have]
u=lambda n:struct.pack('<I',n);fixture=b'VSN1'+u(len(cases))+b''.join(u(int(c['stage']=='fragment'))+u(1)+u(1)+u(len(c['text'].encode()))+c['text'].encode()for c in cases);(O/'fourth-cases.bin').write_bytes(fixture)
binary=U/'generated/sine-sanitize/sine-test';env=dict(os.environ,LLVM_PROFILE_FILE=str(O/'fourth-native.profraw'),ASAN_OPTIONS='abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1');run=subprocess.run([str(binary)],input=fixture,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env);(O/'fourth-native.log').write_bytes(run.stdout);(O/'fourth-native.stderr').write_bytes(run.stderr);assert run.returncode==0 and not run.stderr
for line in run.stdout.decode().splitlines():
 if line.startswith('PRIMARY '):
  _,i,body=line.split(' ',2);c=cases[int(i)];base.append(dict(name=c['name'],stage=c['stage'],text=c['text'],primary=json.loads(body)))
 assert not line.startswith('CASE ') or json.loads(line.split(' ',2)[2])['ok']is True
assert len(base)==970+len(cases)
primary=R/'renderer/virgl-shader/build/sine-primary.json';reference=R/'renderer/virgl-shader/build/sine-reference.json';saved={p:p.read_bytes()for p in (primary,reference)}
primary_raw=(json.dumps(base,indent=2)+'\n').encode();primary.write_bytes(primary_raw);(O/'fourth-primary.json').write_bytes(primary_raw)
plan=json.loads(subprocess.check_output(['node','--input-type=module','-e',"import fs from 'node:fs';import {physicalPlan}from './tools/virgl-sine/plan.mjs';process.stdout.write(JSON.stringify(physicalPlan(1834637033,JSON.parse(fs.readFileSync('renderer/virgl-shader/build/sine-primary.json')))));"],cwd=R));(O/'fourth-plan.json').write_text(json.dumps(plan,indent=2)+'\n');keys=set()
# Derive reference operands from original TGSI, independently of plan.selected.
for v in plan['vertices']:
 for x in v['vectors']:
  bank=[0]*184;bank[:4]=v['input']['a'];bank[180:184]=v['input']['b'];bank[172]=x['condition']
  truth,_=m.execute(v['text'],bank,v['backend']);keys.update(r['word']for r in truth if 'op'in r)
for f in plan['fragments']:
 bank=[0]*184;bank[:4]=f['input']['a'];bank[180:184]=f['input']['b'];truth,_=m.execute(f['text'],bank,f['backend']);r=truth[f['lane']]
 if 'op'in r:keys.add(r['word'])
ref=dict(schema='virgl-sine-critic-reference-v1',primaryFileSha256=sha(primary_raw),referenceSourceSha256=sha(P.read_bytes()),referenceMethod='independent Machin pi 192-bit enclosure, quadrant reduction, rational 240-bit sin/cos tails',rows=[m.prediction(w)for w in sorted(keys)])
refraw=(json.dumps(ref,indent=2)+'\n').encode();reference.write_bytes(refraw);(O/'fourth-reference.json').write_bytes(refraw)
try:
 command=['node','tools/virgl-sine/browser.mjs','--output',str(O/f'gpu-{seed}'),'--seed',str(seed)];(O/'fourth-command.json').write_text(json.dumps(dict(command=command,seed=seed,nativeCases=len(cases),nativeBinarySha256=sha(binary.read_bytes()),fixtureSha256=sha(fixture),primarySha256=sha(primary_raw),referenceSha256=sha(refraw),oracleSourceSha256=sha(P.read_bytes())),indent=2)+'\n')
 with (O/'fourth-seed.log').open('wb')as log:subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
 output=O/f'gpu-{seed}/report.json';report=json.loads(output.read_bytes());assert report['acceptance']['primaryFile']['sha256']==sha(primary_raw)and report['acceptance']['referenceFile']['sha256']==sha(refraw)
 result=m.inspect(output);(O/'fourth-seed-semantics.json').write_text(json.dumps(dict(status='passed',testSha256=sha(P.read_bytes()),physical=result),indent=2)+'\n');print(result['words'],result['pixels'],result['maximumObservedError'])
finally:
 for p,b in saved.items():p.write_bytes(b)
