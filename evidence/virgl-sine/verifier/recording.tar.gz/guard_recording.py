from pathlib import Path
import json,subprocess,struct,os,hashlib
R=Path.cwd();O=R/'evidence/virgl-sine/verifier';U=O/'unpacked';sha=lambda b:hashlib.sha256(b).hexdigest();u=lambda n:struct.pack('<I',n)
raw=subprocess.check_output(['node','--input-type=module','-e',"import {getSineRegressions}from './renderer/virgl-shader/tests/sine-regressions.mjs';console.log(JSON.stringify(getSineRegressions()));"]);cases=json.loads(raw);(O/'critic-native-predictions.json').write_bytes(raw)
fixture=b'VSN1'+u(len(cases))+b''.join(u(int(c['stage']=='fragment'))+u(int(c['ok']))+u(0)+u(len(c['text'].encode()))+c['text'].encode()for c in cases);(O/'critic-native-cases.bin').write_bytes(fixture)
b=U/'generated/sine-sanitize/sine-test';env=dict(os.environ,LLVM_PROFILE_FILE=str(O/'critic-native.profraw'),ASAN_OPTIONS='abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1');run=subprocess.run([str(b)],input=fixture,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env);(O/'critic-native.log').write_bytes(run.stdout);(O/'critic-native.stderr').write_bytes(run.stderr);assert run.returncode==0 and not run.stderr
profile=O/'critic-native.profdata';subprocess.run(['xcrun','llvm-profdata','merge','-sparse',str(O/'critic-native.profraw'),'-o',str(profile)],check=True);coverage=subprocess.check_output(['xcrun','llvm-cov','export',str(b),'-instr-profile='+str(profile)]);(O/'critic-native-coverage.json').write_bytes(coverage)
responses={}
for s in run.stdout.decode().splitlines():
 if s.startswith('CASE '):_,i,r=s.split(' ',2);responses[int(i)]=json.loads(r)
for i,c in enumerate(cases):assert responses[i]['ok']==c['ok']
selector=[dict(name=c['name'],expectedBaseProfile=c['expectedBaseProfile'],observed=responses[i]['metadata'])for i,c in enumerate(cases)if c.get('expectedBaseProfile')]
for s in selector:assert s['observed']['sineBaseProfile']==s['expectedBaseProfile']
result=dict(status='passed',cases=len(cases),predictionsSha256=sha(raw),fixtureSha256=sha(fixture),binarySha256=sha(b.read_bytes()),profileSha256=sha((O/'critic-native.profraw').read_bytes()),logSha256=sha(run.stdout),stderrSha256=sha(run.stderr),coverageSha256=sha(coverage),wrapperSelectorArms=selector,sourceFrozen=True,recordingScope='Original archived sanitizer binary; critic independently predicted 520 guards and all ten metadata selector arms. No rebuilt runtime or cached worker oracle.')
(O/'critic-native-recording.json').write_text(json.dumps(result,indent=2)+'\n');print(len(cases),'critic independently predicted cases recorded on original sanitizer binary; all ten wrapper-selector arms covered.')
