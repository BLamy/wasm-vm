from pathlib import Path
import json,struct,hashlib,importlib.util,subprocess
R=Path.cwd();O=R/'evidence/virgl-sine/verifier';U=O/'unpacked';P=R/'renderer/virgl-shader/tests/sine-capture-regressions.py';spec=importlib.util.spec_from_file_location('sine_guard',P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);records=[]
for checkout in ('hot','cold/acceptance'):
 for fault in ('function','argument','broadcast'):
  p=U/checkout/('fault-'+fault)/'report.json';r=json.loads(p.read_bytes());a=r['acceptance'];v=next(v for v in a['vertices']if v['mutation']);vi=a['vertices'].index(v);mutation=v['mutation'];assert mutation['kind']==fault and mutation['served']==mutation['original'].replace(mutation['needle'],mutation['replacement'],1)and mutation['served']in [e['source']for e in a['events']if e['call']=='shaderSource']
  contradictions=[]
  for xi,x in enumerate(v['vectors']):
   truth,_=m.execute(v['text'],m.bank(v,x),v['backend']);actual=list(struct.unpack('<12I',bytes(x['bytes'])));words=[((actual[8+i]&511)<<23)|(actual[4+i]&0x7fffff)for i in range(4)]
   for lane,(t,w)in enumerate(zip(truth,words)):
    if not m.allowed(t,w):contradictions.append(dict(vertex=vi,vector=xi,lane=lane,sourceWord=t.get('word'),observedWord=w,errorApprox=float(m.error_bound(t,w)),sourceSha256=v['textSha256'],captureSha256=x['sha256']))
  assert contradictions,'actual physical fault must violate independent mathematical budget'
  try:m.inspect(p)
  except AssertionError as e:assert isinstance(e.args[0],dict)and'point'in e.args[0],'failure must be an independent numeric point, not outcome or fixture validation';caught=True
  else:raise AssertionError('physical fault escaped independent guard')
  records.append(dict(checkout=checkout,fault=fault,reportSha256=m.sha(p.read_bytes()),actualServedSha256=m.sha(mutation['served'].encode()),independentContradictions=contradictions,promotedSourceGuardCaught=caught))
# Sabotage all redundant capture fields AND the worker's stored oracle. An
# integrity-only checker or self-derived oracle would accept this forgery.
p=U/'hot/gpu-389793865/report.json';j=json.loads(p.read_bytes());x=j['acceptance']['vertices'][0]['vectors'][0];w=0x3f800000;x['reconstructed'][0]=w;x['observed'][4]=(w&0x7fffff)|0x3f000000;x['observed'][8]=(w>>23)|0x3f000000;x['bytes']=list(struct.pack('<12I',*x['observed']));x['sha256']=m.sha(bytes(x['bytes']));x['oracles'][0]['allowedLower']=dict(n='-100',d='1');x['oracles'][0]['allowedUpper']=dict(n='100',d='1');forged=O/'forged-capture.json';forged.write_text(json.dumps(j,indent=2)+'\n')
assert m.allowed(x['oracles'][0],w),'self-derived stored oracle was deliberately poisoned to accept'
cmd=['python3',str(P),'--report',str(forged),'--output',str(O/'forged-capture-guards.json')];result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(O/'forged-capture-guards.log').write_bytes(result.stdout);assert result.returncode!=0;g=json.loads((O/'forged-capture-guards.json').read_bytes());assert g['status']=='failed'and"'point':"in g['failure']['message'],'source oracle must fail numerical prediction'
(O/'sensitivity.json').write_text(json.dumps(dict(status='passed',physicalFaults=records,forgedCapture=dict(reportSha256=m.sha(forged.read_bytes()),exit=result.returncode,guardOutputSha256=m.sha((O/'forged-capture-guards.json').read_bytes()),observedWord=w,cachedWorkerOracleWouldAccept=True,independentSourceOracleRejects=True)),indent=2)+'\n');print('All six actual source faults rejected independently; capture forgery with matching hashes and poisoned cached oracle rejected.')
