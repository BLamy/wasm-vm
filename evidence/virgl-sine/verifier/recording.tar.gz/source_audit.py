from pathlib import Path
import json,hashlib,importlib.util,subprocess
R=Path.cwd();O=R/'evidence/virgl-sine/verifier';U=O/'unpacked';P=R/'renderer/virgl-shader/tests/sine-capture-regressions.py';spec=importlib.util.spec_from_file_location('independent_sine',P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
rows=[];primary={c['text']:c['primary']for c in json.loads((U/'generated/sine-primary.json').read_bytes())}
for checkout in ('hot','cold/acceptance'):
 for seed in (389793865,2135058973,3399354483):
  path=U/checkout/f'gpu-{seed}/report.json';j=json.loads(path.read_bytes());a=j['acceptance']
  for v in a['vertices']+a['fragments']:
   if v['backend']=='mesa':assert v['primary']==primary[v['text']],'actual unmodified pinned GLSL from original parser/converter execution'
  result=m.inspect(path);output=O/(checkout.split('/')[0]+f'-source-semantics-{seed}-final.json');output.write_text(json.dumps(dict(status='passed',testSha256=m.sha(P.read_bytes()),physical=result),indent=2)+'\n')
  rows.append(dict(checkout=checkout,seed=seed,reportSha256=m.sha(path.read_bytes()),resultSha256=m.sha(output.read_bytes()),words=result['words'],pixels=result['pixels'],deviations=len(result['deviations']),originalCaptures=len(result['captures']),maximumObservedError=result['maximumObservedError']))
  print(checkout,seed,result['words'],result['pixels'],len(result['deviations']),flush=True)
(O/'source-semantics.json').write_text(json.dumps(dict(status='passed',oracle='independent Machin pi enclosure with rational quadrant reduction and sin/cos tails; original TGSI operand execution',testSha256=m.sha(P.read_bytes()),records=rows),indent=2)+'\n')
