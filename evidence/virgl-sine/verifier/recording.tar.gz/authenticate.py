from pathlib import Path,PurePosixPath
import hashlib,json,tarfile,subprocess
R=Path.cwd();O=R/'evidence/virgl-sine/verifier';W=R/'evidence/virgl-sine/worker'
sha=lambda b:hashlib.sha256(b).hexdigest()
def readj(p):return json.loads(p.read_bytes())
def check(v,label):
 if not v:raise ValueError(label)
m=readj(W/'manifest.json');rawindex=(W/m['recordIndex']['path']).read_bytes();rawarchive=(W/m['archive']['path']).read_bytes()
check(sha(rawindex)==m['recordIndex']['sha256'] and len(rawindex)==m['recordIndex']['bytes'],'index')
check(sha(rawarchive)==m['archive']['sha256'] and len(rawarchive)==m['archive']['bytes'],'archive')
index=json.loads(rawindex);declared={r['path']:r for r in index['records']};check(len(declared)==len(index['records']),'unique index')
U=O/'unpacked';U.mkdir(exist_ok=True)
with tarfile.open(W/m['archive']['path']) as t:
 members=t.getmembers();check(len({r.name for r in members})==len(members),'unique tar')
 check(set(r.name for r in members)==set(declared),'whole actual member inventory')
 for r in members:
  q=PurePosixPath(r.name);check(r.isfile() and not q.is_absolute() and '..' not in q.parts,'regular safe member '+r.name)
  b=t.extractfile(r).read();e=declared[r.name];check(len(b)==e['bytes']==r.size and sha(b)==e['sha256'],'member '+r.name)
  p=U/r.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
for name,field in [('hot/receipt.json','hotReceiptSha256'),('cold/report.json','coldReportSha256'),('cold/acceptance/receipt.json','coldReceiptSha256')]:check(sha((U/name).read_bytes())==m[field],'manifest '+field)
check(len(members)==m['records']==135,'actual size')
sourcehead=m['sourceHead'];frozen='ad31839ebc55e5f853c9d9853a44c9922767e7da';changes=subprocess.check_output(['git','diff','--name-only',frozen,sourcehead],text=True).splitlines();check(set(changes)=={'tools/virgl-sine/receipt.py','tools/virgl-sine/cold.py'},'only collector repair')
sources=[]
for prefix,gprefix in [('hot','generated'),('cold/acceptance','cold-generated')]:
 receipt=readj(U/prefix/'receipt.json');check(receipt['gitHead']==sourcehead and receipt['status']=='passed','receipt head/outcome')
 for row in receipt['records']:
  b=(U/prefix/row['path']).read_bytes();check(len(b)==row['bytes'] and sha(b)==row['sha256'],'receipt artifact '+prefix+'/'+row['path'])
 for row in receipt['sources']:
  p=row['path'];b=(U/gprefix/p.removeprefix('renderer/virgl-shader/build/')).read_bytes() if p.startswith('renderer/virgl-shader/build/') else subprocess.check_output(['git','show',sourcehead+':'+p])
  check(sha(b)==row['sha256'] and len(b)==row['bytes'],'source '+p)
  if not p.startswith('renderer/virgl-shader/build/'):check((R/p).read_bytes()==b,'current source unchanged '+p)
  sources.append(dict(checkout=prefix,**row))
 cold=readj(U/'cold/report.json')
check(cold['gitHead']==cold['cloneHead']==sourcehead and cold['status']=='passed' and cold['exitCode']==0 and cold['statusBefore']==cold['statusAfter']=='','pristine final')
check(sha((U/'cold/cold.log').read_bytes())==cold['logSha256'] and sha((U/'cold/acceptance/receipt.json').read_bytes())==cold['receiptSha256'],'cold complete log')
failed=readj(U/'hot/cold-output-path-failure/report.json');completed=readj(U/'hot/cold-output-path-failure/acceptance-receipt.json');check(failed['status']=='failed' and failed['exitCode']==0 and failed['statusBefore']==failed['statusAfter']=='' and completed['status']=='passed' and completed['gitHead']==frozen,'original collection failure qualification')
check(sha((U/'hot/cold-output-path-failure/cold.log').read_bytes())==failed['logSha256'],'initial failed collector log')
original=readj(U/'hot/receipt-before-path-repair.json');check(original['gitHead']==frozen and original['status']=='passed','original hot receipt preserved')
result=dict(schema='virgl-sine-critic-authentication-v1',status='passed',actualMembers=len(members),totalBytes=sum(r.size for r in members),sourceBindings=len(sources),manifestSha256=sha((W/'manifest.json').read_bytes()),indexSha256=sha(rawindex),archiveSha256=sha(rawarchive),sourceHead=sourcehead,frozenRuntime=frozen,collectorOnlyChangedFiles=changes,cold=cold,failedInitialCollector=failed,originalHotReceiptSha256=sha((U/'hot/receipt-before-path-repair.json').read_bytes()),members=index['records'],sources=sources)
(O/'authentication.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['members','sources']},indent=2))
