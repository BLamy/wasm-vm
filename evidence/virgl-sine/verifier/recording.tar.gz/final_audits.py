from pathlib import Path
import json,hashlib,subprocess,importlib.util
R=Path.cwd();O=R/'evidence/virgl-sine/verifier';U=O/'unpacked';sha=lambda b:hashlib.sha256(b).hexdigest();seed=1834637033
# Frozen worker runtime has no semantic or dependency changes in critic commits.
changed=subprocess.check_output(['git','diff','--name-only','c6e56fa8','HEAD'],text=True).splitlines();assert set(changed)=={'renderer/virgl-shader/tests/sine-regressions.mjs','renderer/virgl-shader/tests/sine-capture-regressions.py','tools/verify-virgl-sine.sh'},changed
for p in ['renderer/virgl-shader/bridge.c','renderer/virgl-shader/raw_bits.c','renderer/virgl-shader/raw_bits.h','renderer/virgl-command/constant-domain.mjs','renderer/virgl-shader/build.sh','renderer/virgl-shader/index.mjs']:
 assert (R/p).read_bytes()==subprocess.check_output(['git','show','ad31839e:'+p]),'runtime source frozen '+p
# The fourth seed reads actual freshly converted vendor GLSL and the critic's
# independently predicted references. Audit every served/V8/source binding.
r=json.loads((O/f'gpu-{seed}/report.json').read_bytes());assert r['gitHead']==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()and r['status']=='passed'and not r['trackedChanges'];fourth_sources=[]
special={'renderer/virgl-shader/build/sine-primary.json':O/'fourth-primary.json','renderer/virgl-shader/build/sine-reference.json':O/'fourth-reference.json'}
for s in r['sources']:
 p=special.get(s['path'],R/s['path']);raw=p.read_bytes();assert sha(raw)==s['sha256']and len(raw)==s.get('size',s.get('bytes')),'fourth source '+s['path'];fourth_sources.append(s)
for s in r['servedFiles']:
 p=special.get(s['path'],R/s['path']);raw=p.read_bytes();assert sha(raw)==s['sha256']and len(raw)==s['size'],'served fourth source '+s['path']
raw=(O/f'gpu-{seed}/browser-coverage.json').read_bytes();assert sha(raw)==r['browserCoverage']['sha256']
for s in json.loads(raw)['scripts']:assert s['sha256']==sha((R/s['source']).read_bytes())
assert not any(__import__('re').search('swiftshader|llvmpipe|softpipe|lavapipe|--disable-gpu(?:$|=)',a,__import__('re').I)for a in r['browser']['actualCommandLine'])
assert r['browserErrors']==dict(console=[],page=[],requests=[])
assert sha((O/f'gpu-{seed}/browser.png').read_bytes())==r['screenshot']['sha256']
base=json.loads((U/'generated/sine-primary.json').read_bytes());fresh=json.loads((O/'fourth-primary.json').read_bytes());assert fresh[:len(base)]==base and len(fresh)-len(base)==80
primary_by_text={p['text']:p['primary']for p in fresh}
for v in r['acceptance']['vertices']+r['acceptance']['fragments']:
 if v['backend']=='mesa':assert v['primary']==primary_by_text[v['text']],'unchanged actual primary converter GLSL'
assert (R/'renderer/virgl-shader/build/sine-primary.json').read_bytes()==(U/'generated/sine-primary.json').read_bytes()and (R/'renderer/virgl-shader/build/sine-reference.json').read_bytes()==(U/'generated/sine-reference.json').read_bytes(),'original generated inputs restored'
checks=[]
for command in [['node','--check','renderer/virgl-shader/tests/sine-regressions.mjs'],['python3','-m','py_compile','renderer/virgl-shader/tests/sine-capture-regressions.py'],['bash','-n','tools/verify-virgl-sine.sh'],['git','diff','--check'],['python3','tools/check_task_policy.py']]:
 q=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);checks.append(dict(command=command,exit=q.returncode,output=q.stdout.decode()));assert q.returncode==0
worker=json.loads((O/'authentication.json').read_bytes());assert worker['actualMembers']==135 and worker['sourceBindings']==727
for f in ['native-replays.json','source-semantics.json','independent-regressions-final.json','consumer-attacks.json','consumer-boundary-attacks.json','coverage-audit.json','carry-forward.json','fourth-seed-semantics.json','critic-native-recording.json','sabotage-regressions.json','sensitivity.json']:assert json.loads((O/f).read_bytes())['status']=='passed',f
cov=json.loads((O/'coverage-audit.json').read_bytes());assert len(cov['changedRuntimeLines'])==50 and len(cov['waivers'])==12
pred=O/'predictions.json';assert sha(pred.read_bytes())=='5bf80923ce61ba481a1773d94ed5eedaa1e2552cd0da59560c0b1b6fe938c5c1','original pre-inspection predictions intact'
result=dict(status='passed',criticHead=r['gitHead'],frozenRuntime='ad31839ebc55e5f853c9d9853a44c9922767e7da',criticOnlyChangedFiles=changed,workerManifestSha256=worker['manifestSha256'],originalPredictionSha256=sha(pred.read_bytes()),fourthSourceBindings=fourth_sources,fourthServedFiles=r['servedFiles'],fourthReportSha256=sha((O/f'gpu-{seed}/report.json').read_bytes()),fourthCoverageSha256=sha(raw),fourthScreenshotSha256=r['screenshot']['sha256'],freshActualPrimaryWitnesses=80,independentGuards=520,metadataAttacks=580+274,coverage=dict(executedRuntimeLines=50,declarativeWaivers=12),checks=checks,qualification='Worker initial collector failed after acceptance succeeded; corrected pristine final clone is sealed. First critic GPU run passed, then capture audit rejected the two new untracked guard files; original capture/failure retained; final fourth run at clean critic head passes. No runtime refutation and no cold rerun after tests-only promotion.')
(O/'final-checks.json').write_text(json.dumps(result,indent=2)+'\n');print('Final original/current/served/V8 bindings, source freeze, promoted guard checks, policy and fourth hardware recording passed.')
