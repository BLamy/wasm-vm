from pathlib import Path
import json,hashlib,tarfile,subprocess
R=Path.cwd();O=R/'evidence/virgl-sine/verifier';U=O/'unpacked';sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
def seal(base):
 p=R/base;m=json.loads((p/'manifest.json').read_bytes());idx=(p/'records.json').read_bytes();a=p/m['archive']['path'];assert sha(idx)==m['recordIndex']['sha256'] and sha(a.read_bytes())==m['archive']['sha256'];return m,{r['path']:r for r in json.loads(idx)['records']},a
def extract(binding):
 m,i,a=seal(str(Path(binding['sealPath']).parent));e=binding['member'];assert e==i[e['path']]
 with tarfile.open(a)as t:b=t.extractfile(e['path']).read()
 assert len(b)==e['bytes']and sha(b)==e['sha256'];return b
for name in ('saturation','exponent'):
 p=U/'hot'/('held-'+name);r=json.loads((p/'report.json').read_bytes());assert r['status']=='passed' and r['faultExit']!=0
 for key,file in [('capture','capture.json'),('fault','fault.json')]:assert extract(r[key])==(p/file).read_bytes()
 guard='renderer/virgl-shader/tests/'+('saturation'if name=='saturation'else'exponent-logarithm')+'-capture-regressions.py'
 assert not subprocess.check_output(['git','diff','322bb56e..c6e56fa8','--',guard]),'unchanged promoted source oracle'
 rows.append(dict(boundary=name,status='HELD',guard=guard,guardSha256=sha((R/guard).read_bytes()),capture=r['capture'],fault=r['fault'],guardOutputSha256=sha((p/'guards.json').read_bytes()),faultOutputSha256=sha((p/'fault-guards.json').read_bytes()),physicalWords=r['physicalWords'],reason='Original independently verified source equations, actual capture/fault bytes and promoted oracle are unchanged and digest-bound; worker re-execution retained. Runtime changed only adjacent SIN admission with full predecessor response equality below.'))
legacy=json.loads((U/'hot/legacy.json').read_bytes());assert len(legacy['cases'])==5861 and legacy['status']=='passed'
for c in legacy['cases']:
 assert c['old']==c['parent']and c['old']['ok']==c['ok']==c['added']['ok']
 if c['ok']:
  m=dict(c['added']['metadata']);m['profile']=m.pop('sineBaseProfile');m.pop('sineContract');b=dict(c['parent']['metadata'])
  if c['baseTransition']:b['profile']='virgl-webgl2-raw-bits-v1'
  assert m==b,'whole inherited obligations'
 else:assert not any(k in c['added']for k in ('glsl','metadata'))
_,idx,a=seal('evidence/virgl-exponent-logarithm/worker');e=idx['hot/native/report.json']
with tarfile.open(a)as t:b=t.extractfile(e['path']).read()
assert sha(b)==e['sha256'];original=json.loads(b);old_sin=[c for c in original['cases']if c['name'].endswith('-unsupported-SIN')];assert len(old_sin)==2
for c,x in zip(old_sin,legacy['extensions']):assert x['name']==c['name']and x['text']==c['text']and x['parent']==c['result']and x['parent']['ok']is False and x['current']['ok']is True and x['transition']=='declared-new-bounded-SIN-admission'
# FRC's full archived lineage and all currently promoted native/Wasm outcomes are carried by digest.
fseal,_,_=seal('evidence/virgl-precise-fraction/verifier');guard=R/'renderer/virgl-shader/tests/precise-fraction-regressions.mjs';assert not subprocess.check_output(['git','diff','322bb56e..c6e56fa8','--',str(guard.relative_to(R))]);r=json.loads((U/'hot/independent-fraction-guards.json').read_bytes());assert r['status']=='passed'and r['cases']==len(r['native'])==len(r['wasm'])==4469
rows.append(dict(boundary='precise-fraction',status='HELD',verifierSealSha256=sha((R/'evidence/virgl-precise-fraction/verifier/manifest.json').read_bytes()),archiveSha256=fseal['archive']['sha256'],guardSha256=sha(guard.read_bytes()),recordSha256=sha((U/'hot/independent-fraction-guards.json').read_bytes()),cases=4469,reason='Sealed prior oracle/trace digest remains unchanged; all 4469 current native/Wasm guards plus complete legacy outcomes retain the earlier exact arithmetic boundary.'))
retained=json.loads((U/'hot/retained/report.json').read_bytes());assert sum(x['native']['ok']for x in retained['originals'])==23 and sum(x['native']['ok']for x in retained['historical'])==5
out=dict(status='passed',held=rows,wholePredecessorResponses=5861,predecessorRecordSha256=sha((U/'hot/legacy.json').read_bytes()),priorSINExtensionBinding=e,declaredExtensions=legacy['extensions'],originalBodies=dict(originals=len(retained['originals']),historical=len(retained['historical']),recordSha256=sha((U/'hot/retained/report.json').read_bytes())))
(O/'carry-forward.json').write_text(json.dumps(out,indent=2)+'\n');print('HELD SAT/EX/FRC original seals and faults; 5861 predecessor responses; exactly two bounded plain-SIN admission extensions. Original full bodies remain gated.')
