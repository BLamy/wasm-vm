from pathlib import Path
import hashlib,json,tarfile,gzip,io,subprocess
R=Path.cwd();O=R/'evidence/virgl-sine/verifier';sha=lambda b:hashlib.sha256(b).hexdigest();verdict=json.loads((O/'verdict.json').read_bytes());assert verdict['verdict']=='verified' and all(r['status']=='HELD'for r in verdict['predictions'])
# The immutable worker seal is referenced by authenticated index/digest, never
# duplicated or silently replaced. Include ORIGINAL critic outputs and actual
# sabotage binaries/mutations; unchanged scratch sources bind the git head.
members={};skip={'recording.tar.gz','records.json','manifest.json','README.md','seal.log'}
for p in sorted(O.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(O);parts=rel.parts
 if parts[0]=='unpacked' or '__pycache__'in parts or p.name in skip or '.dSYM'in str(rel):continue
 if parts[0]=='sabotage' and not (str(rel).endswith('/renderer/virgl-shader/raw_bits.c')or str(rel).endswith('/renderer/virgl-shader/build/native/virgl-shader')):continue
 members[str(rel)]=p.read_bytes()
index=dict(schema='virgl-sine-critic-records-v1',task='E6-T12g6j1',criticHead=verdict['criticGuardHead'],workerArchiveSha256=json.loads((O/'authentication.json').read_bytes())['archiveSha256'],records=[dict(path=n,bytes=len(b),sha256=sha(b))for n,b in sorted(members.items())]);idx=(json.dumps(index,indent=2)+'\n').encode();(O/'records.json').write_bytes(idx)
b=io.BytesIO()
with gzip.GzipFile(fileobj=b,mode='wb',mtime=0)as z:
 with tarfile.open(fileobj=z,mode='w')as t:
  for n,raw in sorted(members.items()):
   i=tarfile.TarInfo(n);i.size=len(raw);i.mtime=0;i.mode=0o755 if n.endswith('/build/native/virgl-shader')else 0o644;t.addfile(i,io.BytesIO(raw))
raw=b.getvalue();(O/'recording.tar.gz').write_bytes(raw)
manifest=dict(schema='virgl-sine-critic-seal-v1',task='E6-T12g6j1',verdict='verified',workerSubmission='c6e56fa8',workerEvidenceHead=verdict['workerEvidenceHead'],frozenRuntime=verdict['frozenRuntime'],criticHead=verdict['criticGuardHead'],records=len(members),archive=dict(path='recording.tar.gz',bytes=len(raw),sha256=sha(raw)),recordIndex=dict(path='records.json',bytes=len(idx),sha256=sha(idx)),verdictSha256=sha((O/'verdict.json').read_bytes()),predictionsSha256=sha((O/'predictions.json').read_bytes()),workerManifestSha256=sha((R/'evidence/virgl-sine/worker/manifest.json').read_bytes()),workerArchiveSha256=index['workerArchiveSha256'],independentGuards=520,independentMetadataAttacks=274,originalWorkerMetadataAttacks=580,fourthSeed=1834637033,fourthWords=8160,fourthPixels=20352,changedRuntimeLines=50,declarativeWaivers=12,productionNegotiation=False,guestExecution=False)
(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Authenticate the ACTUAL emitted inventory immediately after writing it.
with tarfile.open(O/'recording.tar.gz')as t:
 actual=t.getmembers();assert len(actual)==len(members) and len(set(r.name for r in actual))==len(actual)
 for r in actual:
  value=t.extractfile(r).read();assert value==members[r.name] and sha(value)==next(e['sha256']for e in index['records']if e['path']==r.name)
print(json.dumps(manifest,indent=2))
