# E6-T12f6 fresh verifier predictions (before opening submitted evidence)

Source base: a80ba9e929698c6d582589856822c18aad8c513c.
Submission: bd26d254da04ae56f9ac6866057a8adc5e927118.
Frozen recording source: b961c772d0c79141c0c7050f9deb0c1cb94905f4.

P1. The 19 manifest body SHA-256 values and byte counts will equal the complete prior captured original inventory, with no body or production compiler/renderer changes in this task. The worker/cold tar members and inventories will agree byte-for-byte and source identities will name the frozen source.
P2. Every single and compatible pair will preserve the complete literal declarations and required constant/indirect/count/radial/raster/PRECISE contract inventory. Independent interface derivation will yield 57 compatible and 31 incompatible pairs. Only consumer-requested interpolation may change in the outgoing pair vertex metadata.
P3. Raw native stdout and instrumented C execution will account for 19 singles, 88 pairs, 361 attacks and all recoveries/repeats (2046 calls / 1578 recoveries); the 2198 actual Wasm calls will equal their native complete results, retain output ownership and the 16 MiB backing buffer. A fresh replay will agree.
P4. Each physically linked compatible pair will use its exact emitted original GLSL and each original vertex/fragment path will have raw hardware output observations within the stated numerical budgets. The independent original equations/interpreter will agree with the literal captured instructions, not compiler IR. Defined lighting xyz only will be counted, and all three seeds will reconstruct 1536 words / 155648 pixels each.
P5. Erased/forged/accessor contracts, short/nonfinite banks, signed count greater than 18, radial magnitude below 0x3727c5ac and copied-alpha subnormals will fail without getters or GPU effects, while admitted signed count and alpha zeros will survive. Combined pair domains will remain enforced.
P6. Only the four named hashed historical fixtures will migrate to admission; their final full MOV position must produce all 512 separately counted identity words per schedule. The retained scene will exercise all112 fixtures, 108 rejections / 4 admissions, 1792 recoveries and 768 independently expected pixels.
P7. The actual MAX_PRECISE selector source fault will alter exercised compiled GLSL and physical lighting lane4 beyond its prediction, rather than failing for generic compile/browser reasons. A fresh bounded semantic/input attack and a sabotage of the new checker must be detected.
P8. Every changed runtime harness hunk will execute or receive an explicit nonbehavior/failure-only waiver. Existing compiler/shared-renderer boundaries and unchanged predecessor evidence remain HELD; no desktop offload/performance/format claim is inferred.
