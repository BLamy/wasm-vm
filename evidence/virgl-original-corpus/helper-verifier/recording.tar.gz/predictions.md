# Incremental P8 predictions, before opening repair evidence

Submission f2568918db8f2050c4a54925154c835b6964fdb5; frozen repair8ace8d34e1e5791564411b41de85b4d311a66980; prior verdict15f8917e.

R1. Production compiler/consumer, original-body inventory, original observations and both promoted verifier scripts will remain byte-identical, so P1–P7 HELD claims/digests carry forward. The sole helper semantic change will use access.count when no finite domain exists.
R2. Lossless repair archive and every inventory/source/tool/module/GPU-input binding will agree. A final scrubbed detached clone will execute the unchanged promoted scripts with the recorded immutable Wasm/module setup, clean before/after.
R3. Before repair the genuine v10 fixture will reproduce the original TypeError; after repair its valid184-word bank will be owned, and all473 model cases,25 forgeries,19 originals,57 pairs,4 supplemental bases and0 getters will pass. Actual V8 counters will hit the new access-only return.
R4. A fresh bounded v10 attack will require complete declared extent despite activeCount=0, reject malformed u32 words while permitting all exact u32 encodings without a finite domain, and preserve owned snapshots. Changing the exercised count authority back will falsify this regression.
R5. Canonical gate additions will invoke exactly the unchanged promoted programs. Their three retained hash-bound physical reports will yield1536 defined words/155648 pixels/512 separate migration words each with ordered actual-source checks; no new original/GPU/runtime feature or performance claim is introduced.
