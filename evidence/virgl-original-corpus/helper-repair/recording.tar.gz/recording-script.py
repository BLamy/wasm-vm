from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile
import tempfile

ROOT = Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
OUT = ROOT / 'target/evidence/virgl-original-corpus-helper-repair'
FROZEN = '8ace8d34e1e5791564411b41de85b4d311a66980'
BASE = '15f8917ed3fef4cca4114fea5871edfa8b531dd3'
DEST = ROOT / 'evidence/virgl-original-corpus/helper-repair'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def binding(path, base):
    raw = path.read_bytes()
    return {'path': str(path.relative_to(base)), 'bytes': len(raw), 'sha256': sha(raw)}

env = dict(os.environ)
prefixes = ('CARGO_', 'RUST', 'VIRGL_', 'npm_config_', 'NPM_CONFIG_', 'GIT_', 'EMCC_')
names = {'NODE_OPTIONS','NODE_PATH','NODE_V8_COVERAGE','PYTHONPATH','PYTHONHOME',
         'CHROME','CC','CXX','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','AR','RANLIB',
         'EMCC','EMSDK','EMSDK_NODE','EMSDK_PYTHON','EM_CONFIG','EM_CACHE',
         'MAKEFLAGS','MFLAGS','MAKEOVERRIDES','BASH_ENV','ENV'}
removed = sorted(k for k in env if k.startswith(prefixes) or k in names)
for key in removed:
    del env[key]

def git(*args, cwd=ROOT):
    return subprocess.check_output(['git',*args],cwd=cwd,env=env,text=True).strip()

assert git('rev-parse','HEAD') == FROZEN
assert not DEST.exists()
clone = Path(tempfile.mkdtemp(prefix='wasm-vm-original-helper-cold-')).resolve() / 'wasm-vm'
report = {'schema':'original-corpus-helper-repair-v1','task':'E6-T12f6',
          'gitHead':FROZEN,'previousVerdictHead':BASE,'clone':str(clone),
          'removedEnvironmentNames':removed,'status':'running','commands':[],
          'carriedHeldPredictions':['P1','P2','P3','P4','P5','P6','P7']}
with (OUT/'clone.log').open('w') as log:
    subprocess.run(['git','clone','--shared','--no-checkout',str(ROOT),str(clone)],env=env,
                   stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    subprocess.run(['git','checkout','--detach',FROZEN],cwd=clone,env=env,
                   stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
report['statusBefore'] = git('status','--porcelain','--untracked-files=all',cwd=clone)
assert not report['statusBefore']
report['diffFiles'] = git('diff','--name-only',BASE,FROZEN,cwd=clone).splitlines()
assert set(report['diffFiles']) == {
    'renderer/virgl-shader/tests/original-corpus.mjs',
    'tools/verify-virgl-original-corpus.sh','tools/virgl-original-corpus/README.md'}
source_paths = report['diffFiles'] + [
    'tools/virgl-original-corpus/verifier-regressions.mjs',
    'tools/virgl-original-corpus/verifier.py',
    'renderer/virgl-command/constant-domain.mjs',
    'renderer/virgl-shader/tests/indirect-constant-cases.json',
    'renderer/virgl-shader/tests/original-corpus.json',
    'evidence/virgl-original-corpus/artifacts/worker/virgl-shader.wasm',
    'evidence/virgl-original-corpus/artifacts/worker/virgl-shader.mjs']
report['sources'] = [binding(clone/path,clone) for path in source_paths]
for entry in report['sources']:
    assert sha(subprocess.check_output(['git','show',FROZEN+':'+entry['path']],cwd=ROOT,env=env)) == entry['sha256']
generated = clone/'renderer/virgl-shader/build/wasm'
generated.mkdir(parents=True)
report['sealedReplaySetup'] = []
for name in ('virgl-shader.mjs','virgl-shader.wasm'):
    artifact = clone/'evidence/virgl-original-corpus/artifacts/worker'/name
    shutil.copy2(artifact,generated/name)
    assert (generated/name).read_bytes() == artifact.read_bytes()
    report['sealedReplaySetup'].append(binding(generated/name,clone))
report['runtimeDiff'] = git('diff','--name-only',BASE,FROZEN,'--',
    'renderer/virgl-shader/src','renderer/virgl-shader/index.mjs',
    'renderer/virgl-command/constant-domain.mjs',cwd=clone)
assert not report['runtimeDiff']
old = clone/'evidence/virgl-original-corpus'
old_manifest = json.loads((old/'manifest.json').read_text())
archive = old/'cold.tar.gz'
expected_archive = next(x for x in old_manifest['archives'] if x['path']=='cold.tar.gz')
assert binding(archive,old) == expected_archive
report['retainedArchive'] = binding(archive,clone)
records = {r['path']:r for r in json.loads((old/'cold-records.json').read_text())}
input_dir = clone/'target/evidence/original-helper-retained-inputs'
input_dir.mkdir(parents=True)
report['retainedInputs'] = []
with tarfile.open(archive,'r:gz') as tar:
    for suffix in ('gpu','gpu-430670705','gpu-2480340481'):
        member = 'acceptance/'+suffix+'/report.json'
        raw = tar.extractfile(member).read()
        assert len(raw)==records[member]['bytes'] and sha(raw)==records[member]['sha256']
        path = input_dir/suffix/'report.json'
        path.parent.mkdir()
        path.write_bytes(raw)
        report['retainedInputs'].append({'archiveMember':member,**binding(path,clone)})
node = Path(shutil.which('node',path=env.get('PATH'))).resolve()
report['node'] = {'absolutePath':str(node),'bytes':node.stat().st_size,'sha256':sha(node.read_bytes()),
                  'version':subprocess.check_output([str(node),'--version'],env=env,text=True).strip()}
commands = [
    (['git','diff','--check',BASE,FROZEN],'diff-check.log'),
    (['bash','-n','tools/verify-virgl-original-corpus.sh'],'shell-check.log'),
    ([str(node),'--check','renderer/virgl-shader/tests/original-corpus.mjs'],'helper-check.log'),
    ([str(node),'--check','tools/virgl-original-corpus/verifier-regressions.mjs'],'regression-check.log'),
    (['python3','-m','py_compile','tools/virgl-original-corpus/verifier.py'],'python-check.log'),
    ([str(node),'tools/virgl-original-corpus/verifier-regressions.mjs'],'admission.json'),
    (['python3','tools/virgl-original-corpus/verifier.py',
      *[str(input_dir/suffix/'report.json') for suffix in ('gpu','gpu-430670705','gpu-2480340481')]],'literal-audit.jsonl')]
for command, name in commands:
    with (OUT/name).open('w') as stdout, (OUT/(name+'.stderr')).open('w') as stderr:
        run = subprocess.run(command,cwd=clone,env=env,stdout=stdout,stderr=stderr,timeout=120)
    report['commands'].append({'command':command,'exitCode':run.returncode,
                              'stdout':binding(OUT/name,OUT),'stderr':binding(OUT/(name+'.stderr'),OUT)})
    assert run.returncode==0, (command,run.returncode)
admission = json.loads((OUT/'admission.json').read_text())
assert admission['status']=='passed' and 'helperFault' not in admission
assert len(admission['banks'])==473 and len(admission['forgeries'])==25 and len(admission['pairs'])==57
assert len(admission['originals'])==19 and len(admission['bases'])==4 and admission['getters']==0
assert any(x['name']=='supplemental-existing-indirect' and x['expected'] is True
           and x['result']['ok'] is True and len(x['result']['words'])==184 for x in admission['banks'])
report['admission'] = {key:len(admission[key]) for key in ('originals','pairs','banks','forgeries','bases')}
report['statusAfter'] = git('status','--porcelain','--untracked-files=all',cwd=clone)
report['cloneHeadAfter'] = git('rev-parse','HEAD',cwd=clone)
assert not report['statusAfter'] and report['cloneHeadAfter']==FROZEN
for entry in report['sources']:
    assert binding(clone/entry['path'],clone)==entry
report['status'] = 'passed'
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
shutil.copy2(__file__,OUT/'recording-script.py')
DEST.mkdir()
inventory = [binding(p,OUT) for p in sorted(OUT.rglob('*')) if p.is_file()]
with (DEST/'recording.tar.gz').open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT) as tar:
            for entry in inventory:
                path = OUT/entry['path']; info = tar.gettarinfo(str(path),arcname=entry['path'])
                info.uid=info.gid=0; info.uname=info.gname=''; info.mtime=0
                with path.open('rb') as content:
                    tar.addfile(info,content)
with tarfile.open(DEST/'recording.tar.gz','r:gz') as tar:
    members = tar.getmembers()
    assert len(members)==len(inventory)
    for member, entry in zip(members,inventory):
        raw = tar.extractfile(member).read()
        assert member.name==entry['path'] and len(raw)==entry['bytes'] and sha(raw)==entry['sha256']
assert inventory==[binding(p,OUT) for p in sorted(OUT.rglob('*')) if p.is_file()]
(DEST/'records.json').write_text(json.dumps(inventory,indent=2)+'\n')
manifest = {'schema':'original-corpus-helper-repair-lossless-v1','task':'E6-T12f6',
            'gitHead':FROZEN,'previousVerdictHead':BASE,'status':'passed',
            'archive':binding(DEST/'recording.tar.gz',DEST),'files':len(inventory),
            'rawBytes':sum(x['bytes'] for x in inventory),'sources':report['sources'],
            'carriedHeldPredictions':report['carriedHeldPredictions'],
            'retainedArchive':report['retainedArchive'],'retainedInputs':report['retainedInputs'],
            'boundary':'Only access-only helper count authority and promoted gate integration changed. Prior P1-P7 and production code/toolchain/artifact digests carry forward unchanged. Narrow final exact-head pristine clone exercises all promoted helper cases and both new gate commands.'}
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'status':report['status'],'gitHead':FROZEN,'clone':str(clone),
                  'admission':report['admission'],'archive':manifest['archive']}))
