import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
BASE='d64b2f5e782fee2090f7a0f435bdb0ea7a0a1081';HEAD='eda91e2569c38de3f56b92fd38b5326b2c6ae3fd'
OUT=Path('/tmp/wasmvm-d41-fresh-critic-20261011-eda91');OUT.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
PINS={'recording.tar.gz':'c04d93daf4f37cca8b9f9423fbe4776fe88d63c6a006709345691f9bcbc31afe','records.json':'1d86135fbe288343f0d67d15cf7b355956e53400ea343324d3dae789a0e8d609','manifest.json':'3b35c81a5d67ecbc8d781ad94acef91c2dadf656f950c7be8855637de72820ec'}
def reopen(folder,extract=False):
    p=ROOT/folder;physical={};logical={};audit=[];digests={n:sha((p/n).read_bytes()) for n in ['recording.tar.gz','records.json','manifest.json']}
    if folder.endswith('unorm-depth-images/worker'):assert digests==PINS
    m=json.loads((p/'manifest.json').read_text());idx=json.loads((p/'records.json').read_text());indexed={r['path']:r for r in idx['records']}
    assert len(indexed)==len(idx['records']) and m['archiveSha256']==digests['recording.tar.gz'] and m['recordIndexSha256']==digests['records.json']
    raw=gzip.decompress((p/'recording.tar.gz').read_bytes())
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as tar:
        for entry in tar:
            name=entry.name;assert name in indexed and name not in logical and not name.startswith('/') and '..' not in Path(name).parts
            if entry.islnk():assert entry.linkname in physical;body=physical[entry.linkname]
            else:assert entry.isfile();body=tar.extractfile(entry).read();physical[name]=body
            expected=indexed[name];assert len(body)==expected['bytes'] and sha(body)==expected['sha256'],name
            logical[name]=body;audit.append(dict(path=name,bytes=len(body),sha256=sha(body),physical=entry.linkname if entry.islnk() else name,tarHeaderOffset=entry.offset))
            if extract and name.startswith(('hot/','cold/')):
                dest=OUT/'worker-full'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(body)
    assert set(logical)==set(indexed) and len(logical)==(m['records'] if isinstance(m['records'],int) else m['members'])==m['reopenedMembers']
    return logical,dict(folder=folder,digests=digests,members=len(logical),physicalMembers=len(physical),logicalBytes=sum(len(v) for v in logical.values()),tarBytes=len(raw),fullMembership=audit)
worker,a=reopen('evidence/virgl-unorm-depth-images/worker',False)
assert len(worker)==37121
claims={};sources={}
for prefix in ['hot','cold']:
    receipt=json.loads(worker[prefix+'/receipt.json']);assert receipt['gitHead']==HEAD and receipt['status']=='passed'
    assert receipt['predecessor']==BASE and not receipt['guestExecution'] and not receipt['productionNegotiation'] and not receipt['productionDrawAuthority']
    for name,digest in receipt['files'].items():assert sha(worker[prefix+'/'+name])==digest
    for name,digest in receipt['sources'].items():
        if name not in sources:sources[name]=git('show',HEAD+':'+name)
        assert sha(sources[name])==digest,name
        if not name.startswith('evidence/'):assert worker['source/'+name]==sources[name]
    for name,digest in receipt['generated'].items():assert sha(worker[prefix+'-generated/'+name])==digest
    claims[prefix]=dict(receiptSha256=sha(worker[prefix+'/receipt.json']),files=len(receipt['files']),sources=len(receipt['sources']),generated=receipt['generated'])
report=json.loads(worker['cold/report.json']);assert report['status']=='passed' and report['gitHead']==report['cloneHead']==HEAD and report['statusBefore']==report['statusAfter']=='' and report['receiptSha256']==sha(worker['cold/receipt.json'])
neg=json.loads(sources['evidence/virgl-production-readiness/standard-unorm-depth-image-gap.json']);assert neg['gitHead']==BASE and len(neg['rows'])==16 and not neg['nativeExecuted']
assert sum(not row['result']['ok'] for row in neg['rows'])==13 and sum(row['legacy'] and row['result']['ok'] for row in neg['rows'])==3
for row in neg['sources']:b=git('show',BASE+':'+row['path']);assert len(b)==row['bytes'] and sha(b)==row['sha256']
primary=json.loads(sources['tools/virgl-unorm-depth/primary.json'])
for row in primary['sources']:b=sources[row['path']];assert len(b)==row['bytes'] and sha(b)==row['sha256']
boundaries={}
for name,digest in json.loads(worker['hot/predecessor-audit.json'])['unchangedBoundaries'].items():assert sources[name]==git('show',BASE+':'+name) and sha(sources[name])==digest;boundaries[name]=digest
held=[]
for role in ['worker','verifier']:
    folder='evidence/virgl-floating-depth-consumer/'+role
    for n in ['manifest.json','records.json','recording.tar.gz']:assert (ROOT/folder/n).read_bytes()==git('show',BASE+':'+folder+'/'+n)
    _,h=reopen(folder);held.append(h);print(folder,h['members'],flush=True)
assert sum(h['members'] for h in held)==40703
result=dict(status='HELD',predictions=['P01','P02'],sourceHead=HEAD,worker=a,held=held,receipts=claims,coldReport=report,originalRefusalRows=neg['rows'],primary=primary,unchangedBoundaries=boundaries)
(OUT/'custody.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status='HELD',workerMembers=a['members'],physical=a['physicalMembers'],heldMembers=sum(h['members'] for h in held),receipts=claims,custodySha256=sha((OUT/'custody.json').read_bytes()))))
