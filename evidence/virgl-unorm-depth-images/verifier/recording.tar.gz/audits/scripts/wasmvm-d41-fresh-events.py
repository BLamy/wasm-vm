import gzip,hashlib,json,struct,sys
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=Path('/tmp/wasmvm-d41-fresh-critic-20261011-eda91');sha=lambda b:hashlib.sha256(b).hexdigest()
WRITERS={'drawArrays','drawElements','drawArraysInstanced','drawElementsInstanced','clearBufferiv','clearBufferuiv','clearBufferfv','clearBufferfi','clear','texSubImage2D','bufferSubData','copyBufferSubData','blitFramebuffer'}
def audit(path):
    report=json.loads(path.read_text());e=report.get('partial') or report['browserResult']['result'];refs={r['key']:r for r in e['blobs']};cache={};rows=[]
    def body(ref):
        if ref['key'] not in cache:
            r=refs[ref['key']];z=(path.parent/r['path']).read_bytes();assert sha(z)==r['gzipSha256'];b=gzip.decompress(z);assert len(b)==r['bytes'] and sha(b)==r['sha256'];cache[ref['key']]=b
        assert refs[ref['key']]['sha256']==ref['sha256'];return cache[ref['key']]
    totals=dict(runs=len(e['runs']),frames=len(e['frames']),ownedSyncs=0,consumedSyncs=0,disposalOnlySyncs=0,nativeObjects=0,cpuReads=0,fencedCPUReads=0,synchronousCPUReads=0,actualPairResponses=0,actualStageResponses=0,guestDraws=0,physicalNativeReferences=0,physicalUn16InputPlanes=0)
    for ri,r in enumerate(e['runs']):
        events=r['events'];assert [v['sequence'] for v in events]==list(range(1,len(events)+1));byseq={v['sequence']:v for v in events};syncs={f['id']:f for f in r['fenceObjects']};assert len(syncs)==len(r['fenceObjects'])
        writer=0;reads=[];consumed=set()
        for event in events:
            name=event['name'];seq=event['sequence']
            if name in WRITERS or name=='readPixels' and not event['cpu']:writer=seq
            if name=='fenceSync':f=syncs[event['sync']];assert f['createdSequence']==seq and event['identity']==f['identity']=='WebGLSync'
            if name=='clientWaitSync':
                f=syncs[event['sync']];assert seq>f['createdSequence'] and any(v==event for v in f['polls'])
                if event['delivered'] in [37146,37148]:assert event['actual'] in [37146,37148];consumed.add(f['id'])
            if name in ['readPixels','getBufferSubData'] and event['cpu']:
                totals['cpuReads']+=1;record=next(v for v in r['readbacks'] if v['sequence']==seq);raw=body(record['bytes']);assert len(raw)==event['bytes']>0 and record['name']==name and record['args']==event['args']
                if event.get('synchronousReadback'):
                    assert name=='readPixels' and event['nativeReadReturned'] and event['type']=='Uint8Array' and event['args'][4:6]==[6408,5121] and event['target'] is not None
                    totals['synchronousCPUReads']+=1;completion='driver-synchronized readPixels return'
                else:
                    c=event['completion'];f=syncs[c['sync']];poll=byseq[c['sequence']]
                    assert seq>c['sequence']>writer and f['createdSequence']>writer,(str(path),ri,seq,writer,c)
                    assert poll['name']=='clientWaitSync' and poll['sync']==c['sync'] and poll['actual']==c['actual'] in [37146,37148] and poll['delivered']==c['delivered'] in [37146,37148]
                    totals['fencedCPUReads']+=1;completion=c
                reads.append(dict(sequence=seq,lastWriter=writer,completion=completion,bytes=len(raw),sha256=sha(raw),sourceBlob=record['bytes']['key']))
        for f in syncs.values():
            assert f['deleted']==1 and sum(v['name']=='deleteSync' and v['sync']==f['id'] for v in events)==1
            assert ('completed' in f)==(f['id'] in consumed)
            if f['id'] not in consumed:assert not f['polls'],'unconsumed fence had a timed-out poll'
        totals['ownedSyncs']+=len(syncs);totals['consumedSyncs']+=len(consumed);totals['disposalOnlySyncs']+=len(syncs)-len(consumed)
        nativeObjects=r['nativeObjects'];assert len({v['id'] for v in nativeObjects})==len(nativeObjects) and all(v['deleted']==1 for v in nativeObjects);totals['nativeObjects']+=len(nativeObjects)
        assert all(n==0 for q in [r['final']['renderer']['budgets'],r['final']['resources']['budgets']] for n in q.values()) and r['final']['async']['stagingBytes']==r['final']['async']['reads']==r['final']['async']['transfers']==0 and r['final']['images']['views']==r['final']['images']['holds']==0
        totals['actualPairResponses']+=sum(q['method']=='pair' for q in r['requests']);totals['actualStageResponses']+=sum(q['method']=='stage' for q in r['requests']);totals['guestDraws']+=len(r['draws'])
        returned={sha(body(v['bytes'])):body(v['bytes']) for v in r['readbacks'] if v['cpu']}
        def visit(value):
            if isinstance(value,list):
                for v in value:visit(v)
            elif isinstance(value,dict):
                if isinstance(value.get('native'),dict) and 'key' in value['native']:
                    b=body(value['native']);physical=sha(b) in returned
                    if not physical and len(b)%20==0:
                        n=len(b)//20;physical=sha(b[:n*16]) in returned and (b[n*16:]==bytes(n*4) or sha(b[n*16:]) in returned)
                    assert physical,('native result lacks full returned physical bytes',str(path),ri,value['native'])
                    totals['physicalNativeReferences']+=1
                for k,v in value.items():
                    if k not in ['readbacks','uploads','events','nativeObjects','history','requests']:visit(v)
        visit(r)
        for fi in r.get('frames',[]):visit(e['frames'][fi])
        inputs=[]
        if r.get('format')==16:
            sourceTexture=next((a['texture'] for a in r['allocations'] if a['metadata']['id']==6 and a['metadata']['format']==16),None)
            for p in r.get('planes',[]):
                if 'input' not in p:continue
                wanted=body(p['input']);physical=[v for v in r['uploads'] if v.get('texture')==sourceTexture and v['args'][1]==p['level'] and v['bytes'] is not None and body(v['bytes'])==wanted]
                assert physical,('original UN16 input never physically uploaded',str(path),ri,p['level']);inputs.append(dict(level=p['level'],sequence=physical[0]['sequence'],sha256=sha(wanted)));totals['physicalUn16InputPlanes']+=1
        rows.append(dict(run=ri,name=r['name'],reads=reads,inputs=inputs,ownedSyncs=len(syncs),consumedSyncs=len(consumed),disposalOnlySyncs=len(syncs)-len(consumed),nativeObjects=len(nativeObjects)))
    return dict(record=str(path),reportSha256=sha(path.read_bytes()),totals=totals,runs=rows)

records=[]
for prefix in ['hot','cold']:
    for path in sorted((OUT/'worker-full'/prefix).glob('hardware-*/report.json')):records.append(audit(path))
for path in sorted((ROOT/'target/evidence/virgl-standard-unorm-depth-critic').glob('*/report.json')):records.append(audit(path))
aggregates={}
for prefix in ['hot','cold']:
    selected=[r for r in records if '/worker-full/'+prefix+'/' in r['record']];total={k:sum(r['totals'][k] for r in selected) for k in selected[0]['totals']};aggregates[prefix]=total
    assert all(total[k]==v for k,v in dict(runs=62,frames=133,ownedSyncs=1716,consumedSyncs=1710,disposalOnlySyncs=6,nativeObjects=6993,cpuReads=1648,fencedCPUReads=1586,synchronousCPUReads=62,actualPairResponses=56,actualStageResponses=112,guestDraws=101).items()),total
    transfer=next(r for r in selected if '/hardware-transfers/' in r['record']);assert transfer['totals']['consumedSyncs']==310
result=dict(status='HELD',predictions=['P05','P07','P08','P09','P10'],completionOrderIncludesBlitsAndPboWrites=True,physicalBytesNotCounterSummaries=True,aggregates=aggregates,records=records)
(OUT/'events.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status='HELD',records=len(records),aggregates=aggregates)))
