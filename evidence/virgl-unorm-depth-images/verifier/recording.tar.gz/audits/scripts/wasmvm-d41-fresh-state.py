import collections,gzip,hashlib,json,re,struct
from pathlib import Path
OUT=Path('/tmp/wasmvm-d41-fresh-critic-20261011-eda91');sha=lambda b:hashlib.sha256(b).hexdigest()
def packets(text):
 data=bytes.fromhex(text);at=0
 while at<len(data):
  h,=struct.unpack_from('<I',data,at);count=h>>16;end=at+(count+1)*4;assert end<=len(data)
  yield h&255,(h>>8)&255,list(struct.unpack_from('<'+'I'*count,data,at+4)),data[at:end];at=end
rows=[]
for prefix in ['hot','cold']:
 folder=OUT/'worker-full'/prefix
 for path in sorted(folder.glob('hardware-*/report.json')):
  r=json.loads(path.read_text());e=r['browserResult']['result'];refs={q['key']:q for q in e['blobs']}
  def load(ref):
   q=refs[ref['key']];z=(path.parent/q['path']).read_bytes();assert sha(z)==q['gzipSha256'];b=gzip.decompress(z);assert sha(b)==q['sha256'] and len(b)==q['bytes'];return b
  totals=dict(runs=len(e['runs']),storage16=0,originalRefusals=0,depthFunctions=[],testMasks=[],generationReuse=0,terminalModes=[],uniformAllowedClears=0,preservedStencilPixels=0,allocationRollbacks=0,budgetRefusals=0)
  for ri,a in enumerate(e['runs']):
   alloc16=[q for q in a['allocations'] if q['metadata']['format']==16]
   native16=[q['args'] for q in a['events'] if q['name']=='texStorage2D' and q['args'][2]==33189]
   expected=[]
   for q in alloc16:
    m=q['metadata'];assert m['unormDepth'] is True and m['bind'] in [1,8,9] and m['target']==2 and m['depth']==m['arraySize']==1 and m['flags']==m['nrSamples']==0
    cost=sum(max(1,m['width']>>level)*max(1,m['height']>>level)*2 for level in range(m['lastLevel']+1));assert m['byteLength']==m['gpuByteLength']==cost and q['atAllocation']['gpuBytes']>=cost
    assert [(v['width'],v['height'],v['byteLength'],v['gpuByteLength']) for v in m['levels']]==[(max(1,m['width']>>level),max(1,m['height']>>level),max(1,m['width']>>level)*max(1,m['height']>>level)*2,max(1,m['width']>>level)*max(1,m['height']>>level)*2) for level in range(m['lastLevel']+1)]
    expected.append([3553,m['lastLevel']+1,33189,m['width'],m['height']]);totals['storage16']+=1
   assert collections.Counter(map(tuple,native16))==collections.Counter(map(tuple,expected))
   for h in a['history']:
    if h['label'].startswith('floating-refuse-'):
     assert not h['result']['ok'];assert not any(v['label']==h['label'] and (v['name'] in {'drawArrays','drawElements','drawArraysInstanced','drawElementsInstanced','blitFramebuffer'}) for v in a['events']);totals['originalRefusals']+=1
   if a.get('kind')=='surface':
    dsas={};boundDsa=None;surfaces={};colors={};depth=None;stages={};shaders={};clear=None;first=None
    for hi,h in enumerate(a['history']):
     for op,kind,w,raw in packets(h['hex']):
      if op==1 and kind==3:dsas[w[0]]=dict(enabled=bool(w[1]&1),write=bool(w[1]&2),func=w[1]>>2&7)
      elif op==2 and kind==3:boundDsa=dsas[w[0]]
      elif op==1 and kind==8:surfaces[w[0]]=dict(id=w[1],format=w[2],level=w[3])
      elif op==5:depth=surfaces.get(w[1]);colors={i:surfaces[v] for i,v in enumerate(w[2:]) if v}
      elif op==1 and kind==4:shaders[w[0]]=raw[24:24+w[2]-1].decode('ascii')
      elif op==31:stages[w[1]]=shaders[w[0]]
      elif op==7 and w[0]&4:clear=w[1:5]
      elif op==8:first=(hi,boundDsa,depth,colors,stages,clear);break
     if first:break
    hi,dsa,depth,colors,stages,clear=first;assert depth['format']==16 and depth['id']==6 and 'MOV OUT[0], IN[0]' in stages[0]
    imm=re.search(r'IMM\[0\] UINT32 \{([^}]+)\}',stages[1]);assert imm;output=list(map(int,imm[1].split(',')))
    p=next(p for p in a['planes'] if p['level']==depth['level']);width,height=p['width'],p['height'];input=load(p['input']);depthWanted=bytearray(input);colorWanted=[]
    for i in range(width*height):
     old,=struct.unpack_from('<H',input,i*2);incoming=32768;passed=not dsa['enabled'] or [False,incoming<old,incoming==old,incoming<=old,incoming>old,incoming!=old,incoming>=old,True][dsa['func']]
     colorWanted+=output if passed else clear
     if passed and dsa['enabled'] and dsa['write']:struct.pack_into('<H',depthWanted,i*2,incoming)
    frame=next(e['frames'][i] for i in a['frames'] if e['frames'][i]['historyIndex']==hi);assert load(frame['native'])==struct.pack('<'+'I'*len(colorWanted),*colorWanted)
    nativePlane=next(q for bind in frame['depths'] for q in bind['planes'] if q['original']==depth['level']);raw=load(nativePlane['native'])
    for i in range(width*height):
     z,=struct.unpack_from('<H',depthWanted,i*2);bits,=struct.unpack('<I',struct.pack('<f',z/65535));assert abs(struct.unpack_from('<I',raw,i*16)[0]-bits)<=1
    totals['depthFunctions'].append(dsa['func']);totals['testMasks'].append([dsa['enabled'],dsa['write']])
   for clear in a.get('clears',[]):
    allowed={int(clear['depth']*65535),int(clear['depth']*65535)+1};raw=load(clear['native']);n=len(raw)//20;words=[int(struct.unpack_from('<f',raw,i*16)[0]*65535+.5) for i in range(n)];assert len(set(words))==1 and words[0] in allowed and words[0]==clear['chosenNativeWord'];assert set(clear['allowedOriginalWords'])==allowed;totals['uniformAllowedClears']+=1
   for s in a.get('switchDepths',[])+([a['switchPreserved']] if 'switchPreserved' in a else []):
    if s['format']!=126:continue
    old=load(s['input']);raw=load(s['native']);n=s['width']*s['height'];assert raw[n*16:]==b''.join(bytes([old[i*8+4],0,0,0]) for i in range(n));totals['preservedStencilPixels']+=n
   for action in a.get('boundaries',[]):
    if action.get('kind')=='source-id-reuse':
     assert action['old']==a['sourceGeneration'] and action['fresh']>action['old'];fresh=next(v for v in a['created'] if v['generation']==action['fresh']);assert fresh['metadata']['id']==6 and fresh['metadata']['format']==126;assert load(a['replacementBackingAfter'])==load(action['backing']);totals['generationReuse']+=1
   if 'terminalMode' in a:
    totals['terminalModes'].append(a['terminalMode']);assert a['pending']['resources']['budgets']['imageHolds']>=2
   if a.get('kind')=='allocation-failure':
    last=a['allocations'][-1];assert last['atAllocation']['gpuBytes']==a['before']['gpuBytes']+last['metadata']['gpuByteLength'] and a['before']==a['after'];assert not a['result']['ok'] and a['result']['error']['code']=='backend-error';totals['allocationRollbacks']+=1
   if a.get('kind')=='budget-refusal':
    assert not a['result']['ok'] and a['result']['error']['code']=='limit-exceeded' and a['before']==a['after']
    assert a['nativeObjectsBefore']==a['nativeObjectsAfter'] and a['allocationsBefore']==a['allocationsAfter'] and a['readsBefore']==a['readsAfter']
    m=a['source'];native=sum(max(1,m['width']>>i)*max(1,m['height']>>i)*2 for i in range(m['lastLevel']+1))
    if a['phase']=='resource':assert a['limits']['gpuBytes']==native-1
    elif a['phase']=='view':assert a['limits']['gpuBytes']==a['before']['gpuBytes']+sum(max(1,m['width']>>i)*max(1,m['height']>>i)*2 for i in [1,2])-1
    elif a['phase']=='scratch':assert a['limits']['scratchBytes']==m['width']*m['height']*4-1
    elif a['phase']=='staging':assert a['limits']['gpuBytes']==a['before']['gpuBytes']+m['width']*m['height']*8-1
    else:raise AssertionError(a['phase'])
    totals['budgetRefusals']+=1
  if path.parent.name=='hardware-transfers':assert totals['allocationRollbacks']==2 and totals['budgetRefusals']==4 and totals['uniformAllowedClears']==8
  if path.parent.name=='hardware-surfaces':assert set(totals['depthFunctions'])==set(range(8)) and set(map(tuple,totals['testMasks']))=={(True,True),(True,False),(False,True),(False,False)} and totals['preservedStencilPixels']>0
  if path.parent.name.startswith('hardware-boundaries-'):assert set(totals['terminalModes'])=={'complete','cancel','resource-dispose','renderer-dispose'} and totals['generationReuse']==4 and totals['originalRefusals']==60
  rows.append(dict(record=str(path),sha256=sha(path.read_bytes()),totals=totals))
result=dict(status='HELD',predictions=['P03','P06','P07','P08'],originalWireAndFullNativeBytesAreAuthority=True,records=rows);(OUT/'state.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status='HELD',records=len(rows))))
