import ast,hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=Path('/tmp/wasmvm-d41-fresh-critic-20261011-eda91');HEAD='2073205506d408d2800b1e65bf112123e9869b34';FROZEN='eda91e2569c38de3f56b92fd38b5326b2c6ae3fd'
sha=lambda b:hashlib.sha256(b).hexdigest();cache={};rows=[]
def gitbody(name):
 if name not in cache:cache[name]=subprocess.check_output(['git','show',HEAD+':'+name],cwd=ROOT)
 return cache[name]
exe=Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');exeSha=sha(exe.read_bytes())
for p in sorted((ROOT/'target/evidence/virgl-standard-unorm-depth-critic').glob('*/report.json')):
 r=json.loads(p.read_bytes());assert r['gitHead']==HEAD and r['status']==('failed' if p.parent.name.startswith('fault-') else 'passed') and not r['guestExecution'] and not r['productionNegotiation']
 assert all(not v for v in r['browserErrors'].values());b=r['browser'];assert not b['headless'] and b['executable']==str(exe) and b['sha256']==exeSha and 'Metal' in b['gpu']['auxAttributes']['glRenderer'] and 'M4 Max' in b['gpu']['auxAttributes']['glRenderer']
 assert not any(any(v in arg.lower() for v in ['swiftshader','software-gl','disable-gpu','headless']) for arg in b['commandLine'])
 sources={}
 for v in r['sources']:
  data=(p.parent/'source'/v['path']).read_bytes();assert len(data)==v['bytes'] and sha(data)==v['sha256'];sources[v['path']]=data
  if '/build/wasm/' not in v['path']:assert data==gitbody(v['path'])
  else:assert data==(ROOT/v['path']).read_bytes()
 wrapper='tools/verify-virgl-standard-unorm-depth-critic.mjs' if p.parent.name=='promoted' else 'tools/verify-virgl-standard-unorm-depth.mjs'
 htmlmatch=re.search(r"const html = Buffer.from\(('.*?')\);",sources[wrapper].decode());assert htmlmatch
 html=ast.literal_eval(htmlmatch.group(1)).encode();(p.parent/'browser.html').write_bytes(html)
 served={v['path']:v for v in r['servedFiles']};assert len(served)==len(r['servedFiles'])
 for name,v in served.items():
  data=html if name=='/' else sources[name[1:]];assert len(data)==v['bytes'] and sha(data)==v['sha256']
 cov=(p.parent/r['browserCoverage']['path']).read_bytes();assert sha(cov)==r['browserCoverage']['sha256'];scripts=json.loads(cov)['scripts']
 for q in scripts:
  data=sources[q['source']];assert q['sourceBody'].encode()==data and sha(data)==q['sha256'];assert served['/'+q['source']]['sha256']==q['sha256']
  u=len(q['sourceBody'].encode('utf-16-le'))//2
  for f in q['coverage']['functions']:
   for a in f['ranges']:assert 0<=a['startOffset']<a['endOffset']<=u and a['count']>=0
 pic=(p.parent/r['screenshot']['path']).read_bytes();assert sha(pic)==r['screenshot']['sha256'] and pic.startswith(b'\x89PNG\r\n\x1a\n')
 for name in ['renderer/virgl-command/resources.mjs','renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs','renderer/virgl-command/unorm-depth-images.mjs']:
  assert sources[name]==subprocess.check_output(['git','show',FROZEN+':'+name],cwd=ROOT)
 for name in ['tools/virgl-unorm-depth/values.py','tools/virgl-unorm-depth/transfers.py','tools/virgl-unorm-depth/lifetimes.py']:
  assert (ROOT/name).read_bytes()==subprocess.check_output(['git','show',FROZEN+':'+name],cwd=ROOT)
 rows.append(dict(record=str(p),sha256=sha(p.read_bytes()),status=r['status'],gitHead=r['gitHead'],sourceBodies=len(sources),servedBodies=len(served),fullCoverageBodies=len(scripts),browserHtmlSha256=sha(html),coverageSha256=sha(cov),screenshotSha256=sha(pic),chromeSha256=exeSha,nativeRenderer=b['gpu']['auxAttributes']['glRenderer'],browserErrors=r['browserErrors']))
result=dict(status='HELD',predictions=['P12','P13','P14','P15'],sourceHead=HEAD,runtimeHead=FROZEN,records=rows);(OUT/'browser.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status='HELD',records=len(rows),sourceBodies=sum(v['sourceBodies'] for v in rows))))
