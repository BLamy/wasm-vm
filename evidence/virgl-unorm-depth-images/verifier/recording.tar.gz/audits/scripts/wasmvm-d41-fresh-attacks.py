import gzip,hashlib,json,struct
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=Path('/tmp/wasmvm-d41-fresh-critic-20261011-eda91');FRESH=ROOT/'target/evidence/virgl-standard-unorm-depth-critic';sha=lambda b:hashlib.sha256(b).hexdigest()
p=FRESH/'fault-completed-depth/report.json';report=json.loads(p.read_bytes());e=report['partial'];a=e['runs'][0];refs={q['key']:q for q in e['blobs']}
def body(ref):
 q=refs[ref['key']];z=(p.parent/q['path']).read_bytes();assert sha(z)==q['gzipSha256'];b=gzip.decompress(z);assert len(b)==q['bytes'] and sha(b)==q['sha256'];return b
before,after=a['corruption']['before'],a['corruption']['after'];events={q['sequence']:q for q in a['events']};fences={q['id']:q for q in a['fenceObjects']}
assert before['sync']!=after['sync'] and before['sequence']<after['sequence']
for c in [before,after]:
 q=events[c['sequence']];assert q['name']=='clientWaitSync' and q['sync']==c['sync'] and q['actual']==c['actual']==q['delivered']==c['delivered']==37148
 assert fences[c['sync']]['deleted']==1
writes=[q for q in a['events'] if before['sequence']<q['sequence']<after['sequence']]
clear=next(q for q in writes if q['name']=='clear' and q['args']==[256]);depthValue=next(q for q in writes if q['name']=='clearDepth');assert depthValue['args']==[.0625] and fences[after['sync']]['createdSequence']>clear['sequence']
original=body(a['planes'][0]['input']);assert len(original)==9*7*2
positions=struct.unpack('<24f',body(a['positions']));assert all(positions[i+2]==0 and positions[i+3]==1 for i in range(0,24,4))
dsas={};bound=None;firstDraw=False
for h in a['history']:
 wire=bytes.fromhex(h['hex']);at=0
 while at<len(wire):
  header,=struct.unpack_from('<I',wire,at);count=header>>16;op=header&255;kind=header>>8&255;w=struct.unpack_from('<'+'I'*count,wire,at+4);at+=(count+1)*4
  if op==1 and kind==3:dsas[w[0]]=w[1]
  elif op==2 and kind==3:bound=dsas[w[0]]
  elif op==8:firstDraw=True;break
 if firstDraw:break
assert firstDraw and bound&1 and bound&2 and (bound>>2&7)==7
plane=e['frames'][1]['depths'][0]['planes'][0];raw=body(plane['native']);assert len(raw)==63*20
expected=struct.unpack('<I',struct.pack('<f',32768/65535))[0];observed=struct.unpack_from('<I',raw)[0];assert expected==1056964736 and observed==1031794944 and abs(expected-observed)>1
nativeRead=next(q for q in a['readbacks'] if q['cpu'] and body(q['bytes'])==raw[:63*16]);assert nativeRead['sequence']>after['sequence']
audit=json.loads((p.parent/'value-audit.json').read_bytes());assert audit['status']=='refuted' and not audit['oracleImportsProductCode'] and audit['differences'][0]['where']=='0/1/depths/mip0' and audit['differences'][0]['misses'][0]['observed']==observed and audit['differences'][0]['misses'][0]['expected']==expected
schedules=[]
for folder in sorted(FRESH.glob('boundaries-*')):
 r=json.loads((folder/'report.json').read_bytes());v=json.loads((folder/'value-audit.json').read_bytes());assert r['status']==v['status']=='passed';assert v['counts']['runs']==4 and v['counts']['frames']==18 and v['counts']['consumedSyncs']==238 and v['counts']['disposalOnlySyncs']==2 and not v['differences'];schedules.append(dict(seed=r['browserResult']['result']['seed'],report=folder.name+'/report.json',reportSha256=sha((folder/'report.json').read_bytes()),inverseSha256=sha((folder/'value-audit.json').read_bytes()),counts=v['counts']))
assert len(schedules)==3 and len({q['seed'] for q in schedules})==3
novel=json.loads((FRESH/'promoted/critic-audit.json').read_bytes());assert novel['status']=='passed' and len(novel['comparisons'])==7 and novel['staleSourceBeforeCPU'] and novel['oldGenerationPreserved'] and not novel['oracleImportsProductCode']
result=dict(status='HELD',predictions=['P12','P13'],schedules=schedules,novel=novel,physicalSabotage=dict(report='fresh/fault-completed-depth/report.json',sha256=sha(p.read_bytes()),before=before,after=after,nativeWrite=clear,nativeClearValue=depthValue,nativeReadSequence=nativeRead['sequence'],nativeReturnedSha256=sha(raw[:63*16]),wholeDiagnosticSha256=sha(raw),originalInputSha256=sha(original),observedFirstWord=observed,expectedFirstWord=expected,wholeDiagnosticBytes=len(raw),unchangedInverseSha256=sha((ROOT/'tools/virgl-unorm-depth/values.py').read_bytes()),inverseAuditSha256=sha((p.parent/'value-audit.json').read_bytes()),inverseStatus=audit['status'],note='The inverse physicalControl.recordedPhysicalEvents field counts wrapper binding faults, not the native clear; direct clear341 and consumed345 are authoritative.'))
(OUT/'attacks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status='HELD',schedules=len(schedules),fullNovelPlanes=len(novel['comparisons']),actualNativeClearSequence=clear['sequence'],nativeReadSequence=nativeRead['sequence'])))
