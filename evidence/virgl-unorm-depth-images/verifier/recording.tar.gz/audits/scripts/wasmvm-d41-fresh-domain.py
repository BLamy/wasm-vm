import gzip,hashlib,json,struct
from pathlib import Path
OUT=Path('/tmp/wasmvm-d41-fresh-critic-20261011-eda91');sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for prefix in ['hot','cold']:
 folder=OUT/'worker-full'/prefix/'hardware-domain';report=json.loads((folder/'report.json').read_text());e=report['browserResult']['result'];assert len(e['runs'])==1;r=e['runs'][0];refs={v['key']:v for v in e['blobs']}
 def load(ref):
  row=refs[ref['key']];z=(folder/row['path']).read_bytes();assert sha(z)==row['gzipSha256'];b=gzip.decompress(z);assert sha(b)==row['sha256'] and len(b)==row['bytes'];return b
 assert r['domain'] and r['source']['format']==16 and r['source']['width']==r['source']['height']==256 and len(r['planes'])==1
 p=r['planes'][0];original=struct.pack('<65536H',*range(65536));assert load(p['input'])==original
 expected=b''.join(struct.pack('<fIII',n/65535,0,0,0x3f800000) for n in range(65536));expectedFloat=b''.join(struct.pack('<f',n/65535) for n in range(65536))
 assert '0: TEX TEMP[0], IN[0], SAMP[0], 2D' in r['fragment'] and 'DCL SVIEW[0], 2D, FLOAT' in r['fragment'] and 'PERSPECTIVE' in r['fragment']
 originalTexture=next(a['texture'] for a in r['allocations'] if a['metadata']['id']==6 and a['metadata']['format']==16)
 sent=next(v for v in r['uploads'] if v.get('texture')==originalTexture and v['name']=='texSubImage2D');assert load(sent['bytes'])==original and sent['args']==[3553,0,0,0,256,256,6402,5123]
 drawFrames=[e['frames'][i] for i in r['frames'] if e['frames'][i]['kind']=='draw'];assert len(drawFrames)==2
 for frame in drawFrames:
  assert load(frame['native'])==expected
  read=next(v for v in r['readbacks'] if v['cpu'] and v['bytes']['sha256']==frame['native']['sha256']);assert load(read['bytes'])==expected
 action=next(a for a in r['actions'] if a['kind']=='depth-public');assert len(action['reads'])==1;public=action['reads'][0]
 wire=bytes.fromhex(r['history'][public['historyIndex']]['hex']);header,=struct.unpack_from('<I',wire);w=struct.unpack_from('<13I',wire,4);assert header&255==43 and w[0:3]==(6,0,0) and w[5:11]==(0,0,0,256,256,1) and w[12]==2
 wanted=bytearray(load(action['backingBefore']))
 for y in range(256):wanted[w[11]+y*w[3]:w[11]+y*w[3]+512]=original[y*512:(y+1)*512]
 assert load(public['backing'])==wanted
 label=r['history'][public['historyIndex']]['label'];actual=next(v for v in r['readbacks'] if v['label']==label and v['name']=='getBufferSubData' and v['cpu']);raw=load(actual['bytes']);assert raw==expectedFloat
 canonical=struct.pack('<65536H',*[int(struct.unpack_from('<f',raw,i*4)[0]*65535+.5) for i in range(65536)]);assert canonical==original
 rows.append(dict(prefix=prefix,record='hardware-domain/report.json',reportSha256=sha((folder/'report.json').read_bytes()),values=65536,originalSha256=sha(original),physicalUploadSequence=sent['sequence'],drawFrames=len(drawFrames),everyNativeFloatDepthExactlyPredicted=True,everyPublicUn16AndPaddingByteExact=True,physicalPackCollectionSequence=actual['sequence'],physicalPackSha256=sha(raw),completion=actual['completion']))
result=dict(status='HELD',prediction='P04',independentPureArithmeticOracle=True,rows=rows);(OUT/'domain.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
