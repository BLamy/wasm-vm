import hashlib,json
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=Path('/tmp/wasmvm-d41-fresh-critic-20261011-eda91');FRESH=ROOT/'target/evidence/virgl-standard-unorm-depth-critic';sha=lambda b:hashlib.sha256(b).hexdigest()
def locate(text,pointer):
 dec=json.JSONDecoder();positions={};n=len(text)
 def ws(i):
  while i<n and text[i].isspace():i+=1
  return i
 def parse(i,path):
  i=ws(i);positions[path]=i
  if text[i]=='{':
   i=ws(i+1)
   if text[i]=='}':return i+1
   while True:
    key,j=dec.raw_decode(text,i);i=ws(j);assert text[i]==':';i=parse(i+1,path+'/'+key.replace('~','~0').replace('/','~1'));i=ws(i)
    if text[i]=='}':return i+1
    assert text[i]==',';i=ws(i+1)
  elif text[i]=='[':
   i=ws(i+1);index=0
   if text[i]==']':return i+1
   while True:
    i=parse(i,path+'/'+str(index));index+=1;i=ws(i)
    if text[i]==']':return i+1
    assert text[i]==',';i=ws(i+1)
  else:return dec.raw_decode(text,i)[1]
 parse(0,'');return text.count('\n',0,positions[pointer])+1
cache={}
def cite(scope,name,pointer):
 path=(OUT if scope=='audits' else OUT/'worker-full' if scope=='worker' else FRESH if scope=='fresh' else ROOT)/name
 if path not in cache:cache[path]=path.read_text()
 text=cache[path];return dict(seal=('worker' if scope=='worker' else 'verifier' if scope in ['audits','fresh'] else 'repository'),file=(scope+'/'+name if scope in ['audits','fresh'] else name),jsonPointer=pointer,line=locate(text,pointer),sha256=sha(text.encode()))
def a(name,pointer):return cite('audits',name,pointer)
def w(name,pointer):return cite('worker',name,pointer)
def f(name,pointer):return cite('fresh',name,pointer)
original=Path('/tmp/wasmvm-d41-fresh-critic-20261011-eda91-predictions.json').read_bytes();assert sha(original)=='20ceb3c68d578649472a36d136fde0878293bd0d2e453c95a8f83d9a36fe27fb';pred=json.loads(original)
observations={
'P01':('Every37121 logical worker member resolved to an earlier real physical body;1937 physical bodies; all SHA/length/source/receipt pins hold. Final cold clone is exact eda91 with clean status before/after.',[a('custody.json','/worker/members'),a('custody.json','/coldReport/statusAfter')]),
'P02':('Complete unchanged D40 worker33662 and critic7041 members reopened; actual C/Wasm compiler and native GPU copy/pack helper unchanged; whole primary pins and original UN16 mapping hold.',[a('custody.json','/held/0/members'),a('custody.json','/held/1/members'),a('custody.json','/unchangedBoundaries')]),
'P03':('Original13 readiness refusals and3 legacy successes remain authenticated. Actual format16 native roles/mips/costs match original descriptors. Every boundary schedule refuses60 original bad aliases/returns/filters/roles/feedback before actual draw/copy; drawBuffers is framebuffer setup, not a guest draw.',[a('custody.json','/originalRefusalRows/0'),a('state.json','/records/0/totals/originalRefusals'),w('hot/hardware-boundaries-0x13579bdf/report.json','/browserResult/result/runs/0/source')]),
'P04':('All65536 original words are physically uploaded at event4. Both actual original TEX draws produce exact f32(word/65535) depth; exact public canonical UN16/padding and complete raw pack collection595 after actual consumed594 hold, maximum0ULP.',[a('domain.json','/rows/0/values'),w('hot/hardware-domain/report.json','/browserResult/result/runs/0/events/3'),a('domain.json','/rows/0/completion')]),
'P05':('Unchanged independent original TGSI/packet/input inverses pass both shader stages, slots0/15 and all six supported operations/swizzles/constants/query/private ranges/nonzero outputs. All full diagnostic bodies match actual returned native bytes; full original UN16 uploads independently confirmed.',[w('hot/hardware-samples/report.json','/browserResult/result/runs/0/vertex'),a('hot-original-inverses.json','/summaries/4/1'),a('events.json','/aggregates/hot/physicalNativeReferences')]),
'P06':('Original DSA packets independently derive all eight functions and test/write masks across20 surface runs; full native color/depth bytes hold.126 old S8 pixels remain exact through switches. All8 clear cases uniformly choose allowed24575; public bytes exactly match that validated native word, no independent public tolerance.',[a('state.json','/records/5/totals/depthFunctions'),a('state.json','/records/5/totals/preservedStencilPixels'),w('hot/hardware-transfers/report.json','/browserResult/result/runs/0/clears/0/chosenNativeWord')]),
'P07':('18 transfer cases hold full original/native/public/padding inverses, including native-only refresh. Exact reserved2-byte native mip costs precede texStorage2D.2 allocated failure rollbacks and4 one-byte-short resource/view/scratch/staging refusals preserve budgets and native object/allocation/read counts.',[a('state.json','/records/6/totals/allocationRollbacks'),a('state.json','/records/6/totals/budgetRefusals'),w('hot/hardware-transfers/report.json','/browserResult/result/runs/12/allocations/0/atAllocation/gpuBytes')]),
'P08':('All four terminal modes and old-range/opposite-format126 ID reuse hold from original physical generation/bodies; all6993 positive native objects retire exactly once, every terminal resource/renderer/async/image charge zero. Novel stale source also keeps old private1..2 generation correct while replacement bytes remain exact.',[a('state.json','/records/0/totals/terminalModes'),a('events.json','/aggregates/hot/nativeObjects'),f('promoted/report.json','/browserResult/result/runs/0/view/resolvedGeneration')]),
'P09':('Full native events own1716 syncs with1710 actual consumed and6 disposal-only. CPU1648 splits1586 post-writer-fenced and62 driver-synchronized readPixels returns. Transfer summary omission does not count as zero:310 transfer completions are independently included. Blits/PBO writes and conversion draws participate in writer ordering.',[a('events.json','/aggregates/hot/consumedSyncs'),a('hot-original-inverses.json','/completionAccounting/transferActualConsumedSyncs'),a('events.json','/aggregates/hot/fencedCPUReads'),a('events.json','/aggregates/hot/synchronousCPUReads')]),
'P10':('Both hot/cold independently reconstruct62 positive runs,133frames,801576output words,280776depth pixels+2732transfer pixels,10866784public bytes,56 actual pair/112 actual stage responses vs101 actual draw associations. Controls and legacy are separate.',[a('hot-original-inverses.json','/counts'),a('cold-original-inverses.json','/counts'),a('events.json','/aggregates/hot/actualPairResponses')]),
'P11':('Both full finest governing UTF16/V8 audits reconstruct602executed/25waived/0unproven. All29 exact predecessor source/offset/operand bodies authenticate; four listed waivers now execute, no new UN16 semantics waived. All25 recorder whole bodies differ by only one dependency literal, original legacy hardware recorder passes hot/cold.',[a('coverage.json','/audits/0/counts'),a('coverage.json','/audits/1/counts'),a('coverage.json','/all29WaiversAuthenticated/0'),a('coverage.json','/audits/0/legacyReportSha256')]),
'P12':('New schedules0x6a09e667,0xbb67ae85,0x3c6ef372 all pass unchanged full inverses; each4runs/18frames/238actual completions/2disposal-only and terminalzero. Novel13x11 oddstride7 offset5 nine-word mip1 subrectangle, retained1..2 range and pending opposite-format source reuse passes7 full native plane inversions; stale transfer refuses before CPU collection and destination bytes unchanged.',[a('attacks.json','/schedules'),f('promoted/report.json','/browserResult/result/runs/0/pending/refusal/error/code'),f('promoted/critic-audit.json','/comparisons/4'),f('promoted/critic-audit.json','/staleSourceBeforeCPU')]),
'P13':('Actual completed depth draw334 consumes sync3 at337; native clear(.0625)341 follows; new sync4 is created342 and actually consumed345. Actual full diagnostic return378 differs at first word1031794944 vs original prediction1056964736; unchanged full original-input inverse refutes the sabotage.',[f('fault-completed-depth/report.json','/partial/runs/0/events/340'),f('fault-completed-depth/report.json','/partial/runs/0/events/344'),f('fault-completed-depth/value-audit.json','/differences/0/misses/0'),a('attacks.json','/physicalSabotage/nativeReadSequence')]),
'P14':('42 worker browser recordings and5 fresh full recordings authenticate whole served source/coverage/screenshot bodies; all headed actual Metal M4 WebGL2, no software flags, zero console/page/request errors. Fresh2472source bodies match20732055; runtime and unchanged inverses remain byteidentical eda91. Fresh root HTML is reconstructed from whole recorder literal and exactly matches its served SHA.',[a('worker-browser.json','/records/0'),a('browser.json','/records/0'),f('promoted/report.json','/browserErrors')]),
'P15':('Verified isolated original UN16 factory only. Recorded guestExecution and productionNegotiation false. Production guest/compositor/worker/scanout/demo offload, complete API/caps and300MIPS remain unproven; no merge/push/deploy/successor by critic.',[f('promoted/report.json','/guestExecution'),f('promoted/report.json','/productionNegotiation'),a('browser.json','/runtimeHead')])}
rows=[]
for q in pred['predictions']:
 observation,citations=observations[q['id']];rows.append(dict(id=q['id'],prediction=q['prediction'],status='HELD',observed=observation,citations=citations))
result=dict(schema='d41-fresh-critic-prediction-results-v1',verdict='verified',predictionsWrittenBeforeEvidenceSha256=sha(original),frozenRuntimeHead=pred['frozenSourceHead'],freshSourceHead='2073205506d408d2800b1e65bf112123e9869b34',originalFileUnmodified=True,results=rows)
(OUT/'prediction-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(verdict='verified',held=len(rows),citations=sum(len(r['citations']) for r in rows))))
