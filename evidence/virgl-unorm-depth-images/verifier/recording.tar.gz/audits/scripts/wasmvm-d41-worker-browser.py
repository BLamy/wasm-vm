import hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=Path('/tmp/wasmvm-d41-fresh-critic-20261011-eda91');HEAD='eda91e2569c38de3f56b92fd38b5326b2c6ae3fd';sha=lambda b:hashlib.sha256(b).hexdigest();cache={};rows=[];index={q['path']:q for q in json.loads((ROOT/'evidence/virgl-unorm-depth-images/worker/records.json').read_bytes())['records']}
for prefix in ['hot','cold']:
 for p in sorted((OUT/'worker-full'/prefix).glob('*/report.json')):
  r=json.loads(p.read_bytes())
  if 'browser' not in r:continue
  assert r['gitHead']==HEAD and r['browserErrors']==dict(console=[],page=[],requests=[])
  b=r['browser'];assert b['headless'] is False and 'Metal' in b['gpu']['auxAttributes']['glRenderer'] and 'M4' in b['gpu']['auxAttributes']['glRenderer'] and b['gpu']['featureStatus']['webgl']=='enabled'
  assert not any(any(v in a.lower() for v in ['swiftshader','llvmpipe','softpipe','lavapipe','disable-gpu','headless']) for a in b['commandLine'])
  sources={}
  for q in r['sources']:
   name=q['path'];local=p.parent/'source'/name
   if local.is_file():data=local.read_bytes()
   elif '/build/wasm/' not in name:
    if name not in cache:cache[name]=subprocess.check_output(['git','show',HEAD+':'+name],cwd=ROOT)
    data=cache[name];assert index['source/'+name]['sha256']==sha(data)
   else:
    data=(ROOT/name).read_bytes();assert index[prefix+'-generated/'+name]['sha256']==sha(data)
   assert len(data)==q['bytes'] and sha(data)==q['sha256'];sources[name]=data
   if '/build/wasm/' not in name:
    if name not in cache:cache[name]=subprocess.check_output(['git','show',HEAD+':'+name],cwd=ROOT)
    assert data==cache[name]
  served={q['path']:q for q in r['servedFiles']}
  for name,q in served.items():
   if name=='/':continue
   data=(OUT/'legacy-reconstructed-fixtures.json').read_bytes() if name=='/fixtures.json' else sources[name.lstrip('/')];assert len(data)==q['bytes'] and sha(data)==q['sha256']
   if name=='/fixtures.json':
    for v in r['inputs']:assert sha((ROOT/v['path']).read_bytes())==v['sha256']
  cov=(p.parent/r['browserCoverage']['path']).read_bytes();assert sha(cov)==r['browserCoverage']['sha256'];scripts=json.loads(cov)['scripts']
  for q in scripts:
   data=sources[q['source']];assert sha(data)==q['sha256'] and served['/'+q['source']]['sha256']==q['sha256']
   if 'sourceBody' in q:assert q['sourceBody'].encode()==data
  pic=(p.parent/r['screenshot']['path']).read_bytes();assert sha(pic)==r['screenshot']['sha256'] and pic.startswith(b'\x89PNG\r\n\x1a\n')
  rows.append(dict(record=prefix+'/'+p.parent.name+'/report.json',sha256=sha(p.read_bytes()),status=r['status'],sources=len(sources),served=len(served),completeCoverageBodies=len(scripts),screenshotSha256=sha(pic),coverageSha256=sha(cov),browserSha256=b['sha256'],nativeRenderer=b['gpu']['auxAttributes']['glRenderer']))
assert len(rows)>40
result=dict(status='HELD',prediction='P14',frozenHead=HEAD,records=rows);(OUT/'worker-browser.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status='HELD',records=len(rows),fullSourceBodies=sum(q['sources'] for q in rows))))
