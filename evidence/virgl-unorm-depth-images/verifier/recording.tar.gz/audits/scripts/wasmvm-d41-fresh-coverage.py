import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=Path('/tmp/wasmvm-d41-fresh-critic-20261011-eda91');BASE='d64b2f5e782fee2090f7a0f435bdb0ea7a0a1081';HEAD='eda91e2569c38de3f56b92fd38b5326b2c6ae3fd'
sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
NAMES=['renderer/virgl-command/'+n+'.mjs' for n in ['resources','decoder','state','unorm-depth-images']];bodies={n:git('show',HEAD+':'+n) for n in NAMES};added={};name=None;line=0
for row in git('diff','--unified=0',BASE,HEAD,'--',*NAMES).decode().splitlines():
    if row.startswith('+++ b/'):name=row[6:]
    elif row.startswith('@@'):line=int(re.search(r'\+(\d+)',row)[1])
    elif row.startswith('+') and name:added.setdefault(name,[]).append(line);line+=1
    elif row.startswith(' '):line+=1
waivers=json.loads(git('show',HEAD+':tools/virgl-unorm-depth/coverage-waivers.json'))['waivers'];assert len(waivers)==29
verifiedWaivers=[]
for r in waivers:
    raw=bodies[r['source']].decode().encode('utf-16-le')[r['startOffset']*2:r['endOffset']*2].decode('utf-16-le')
    assert raw==r['text'] and sha(raw.encode())==r['sha256']
    if r['classification']=='whitespace':assert not raw.strip()
    else:
        assert r['classification']=='unchanged-operand' and 'unormDepth' not in raw
        old=git('show',BASE+':'+r['source']);assert sha(old)==r['predecessorSourceSha256']
        assert old.decode().encode('utf-16-le')[r['predecessorStartOffset']*2:r['predecessorEndOffset']*2].decode('utf-16-le')==raw
    verifiedWaivers.append(r)
waiverMap={(r['source'],r['startOffset'],r['endOffset']):r for r in waivers};audits=[]
for prefix in ['hot','cold']:
    folder=OUT/'worker-full'/prefix;scripts=[]
    for p in sorted(folder.glob('*/browser-coverage.json')):
        if p.parent.name.startswith('fault-'):continue
        for s in json.loads(p.read_text()).get('scripts',[]):
            if s['source'] in NAMES:
                assert s['sha256']==sha(bodies[s['source']])
                if 'sourceBody' in s:assert s['sourceBody'].encode()==bodies[s['source']]
                else:
                    report=json.loads((p.parent/'report.json').read_text());served={v['path']:v['sha256'] for v in report['servedFiles']};assert served['/'+s['source']]==s['sha256']
                scripts.append(dict(record=p.relative_to(folder).as_posix(),**s))
    for p in sorted((folder/'node-coverage').glob('coverage-*.json')):
        for s in json.loads(p.read_text())['result']:
            name=next((n for n in NAMES if s['url'].endswith('/'+n)),None)
            if name:scripts.append(dict(record=p.relative_to(folder).as_posix(),source=name,coverage=s))
    partitions=[]
    for name,lines in added.items():
        source=bodies[name].decode();offsets=[0]
        for text in source.splitlines(keepends=True):offsets.append(offsets[-1]+len(text.encode('utf-16-le'))//2)
        observed=[s for s in scripts if s['source']==name]
        for line in lines:
            start,end=offsets[line-1],offsets[line];points={start,end}
            for script in observed:
                for fn in script['coverage']['functions']:
                    for r in fn['ranges']:
                        points.update(k for k in (r['startOffset'],r['endOffset']) if start<k<end)
            points=sorted(points)
            for a,b in zip(points,points[1:]):
                hits=[]
                for s in observed:
                    ranges=[r for f in s['coverage']['functions'] for r in f['ranges'] if r['startOffset']<=a and b<=r['endOffset']]
                    if ranges:
                        smallest=min(ranges,key=lambda r:r['endOffset']-r['startOffset']);hits.append(dict(record=s['record'],**smallest))
                positive=max((v['count'] for v in hits),default=0)>0;waiver=waiverMap.get((name,a,b)) if not positive else None
                assert positive or waiver,(prefix,name,line,a,b)
                partitions.append(dict(source=name,line=line,startOffset=a,endOffset=b,classification='HELD' if positive else 'WAIVED',hits=hits,waiver=waiver))
    counts=dict(positive=sum(p['classification']=='HELD' for p in partitions),waived=sum(p['classification']=='WAIVED' for p in partitions),unproven=0)
    assert counts==dict(positive=602,waived=25,unproven=0),counts
    worker=json.loads((folder/'coverage-audit.json').read_text());assert worker['positive']==counts['positive'] and len(worker['waived'])==counts['waived'] and not worker['zero'];assert [(p['source'],p['line'],p['startOffset'],p['endOffset']) for p in worker['partitions']]==[(p['source'],p['line'],p['startOffset'],p['endOffset']) for p in partitions]
    closure=json.loads((folder/'recorder-closure.json').read_text());assert closure['status']=='passed' and len(closure['configs'])==25
    marker=b", 'renderer/virgl-command/unorm-depth-images.mjs'"
    for r in closure['configs']:
        new=git('show',HEAD+':'+r['path']);old=git('show',BASE+':'+r['path']);assert new.replace(marker,b'',1)==old and sha(old)==r['predecessorSha256'] and sha(new)==r['sha256']
        assert (folder/'recorder-source'/r['path']).read_bytes()==new
    legacy=json.loads((folder/'retained-z16-consumer/report.json').read_text());assert legacy['status']=='passed' and legacy['browserErrors']==dict(console=[],page=[],requests=[])
    assert any(r['path']=='/renderer/virgl-command/unorm-depth-images.mjs' and r['sha256']==sha(bodies[NAMES[-1]]) for r in legacy['servedFiles'])
    audits.append(dict(prefix=prefix,counts=counts,fullScripts=len(scripts),partitions=partitions,recorderClosureSha256=sha((folder/'recorder-closure.json').read_bytes()),legacyReportSha256=sha((folder/'retained-z16-consumer/report.json').read_bytes())))
result=dict(status='HELD',prediction='P11',frozenHead=HEAD,all29WaiversAuthenticated=verifiedWaivers,completeRuntimeSources={n:sha(b) for n,b in bodies.items()},audits=audits)
(OUT/'coverage.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status='HELD',counts=[a['counts'] for a in audits],waiverOperands=29,importInventories=25)))
