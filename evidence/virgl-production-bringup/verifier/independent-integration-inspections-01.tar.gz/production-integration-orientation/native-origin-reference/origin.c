#include <epoxy/gl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/uio.h>
#include "virglrenderer.h"
#include "virgl_hw.h"

static void fence(void *cookie, uint32_t id) { (void)cookie; (void)id; }
static void check(int value, const char *step) {
    if (value) { fprintf(stderr, "%s failed: %d\n", step, value); exit(1); }
}
static void read_file(const char *name, void *bytes, size_t size) {
    FILE *f = fopen(name, "rb");
    if (!f || fread(bytes, 1, size, f) != size) exit(2);
    fclose(f);
}
int main(int argc, char **argv) {
    if (argc != 2) return 2;
    unsigned flags = (unsigned)atoi(argv[1]);
    struct virgl_renderer_callbacks callbacks = {.version = 1, .write_fence = fence};
    check(virgl_renderer_init(&callbacks, VIRGL_RENDERER_USE_EGL | VIRGL_RENDERER_USE_SURFACELESS, &callbacks), "init");
    check(virgl_renderer_context_create(1, 6, "origin"), "context");
    struct virgl_renderer_resource_create_args color = {
        .handle=1, .target=2, .format=67, .bind=2, .width=12, .height=12,
        .depth=1, .array_size=1, .flags=flags
    }, vertex = {.handle=5, .target=0, .format=64, .bind=16, .width=384, .height=1, .depth=1, .array_size=1};
    check(virgl_renderer_resource_create(&color, NULL, 0), "color resource");
    unsigned char vertices[384]; read_file("vertices.bin", vertices, sizeof(vertices));
    struct iovec iov = {.iov_base=vertices, .iov_len=sizeof(vertices)};
    check(virgl_renderer_resource_create(&vertex, &iov, 1), "vertex resource");
    virgl_renderer_ctx_attach_resource(1, 1); virgl_renderer_ctx_attach_resource(1, 5);
    struct virgl_box box = {.x=0,.y=0,.z=0,.w=384,.h=1,.d=1};
    check(virgl_renderer_transfer_write_iov(5, 1, 0, 0, 0, &box, 0, &iov, 1), "vertex upload");
    char file[64]; snprintf(file,sizeof(file),"commands-%u.bin",flags);
    FILE *f=fopen(file,"rb"); if (!f) return 2;
    fseek(f,0,SEEK_END); long size=ftell(f); fclose(f);
    void *commands=malloc((size_t)size); read_file(file,commands,(size_t)size);
    check(virgl_renderer_submit_cmd(commands,1,(int)(size/4)), "original submission"); free(commands);
    virgl_renderer_force_ctx_0();
    struct virgl_renderer_resource_info info; memset(&info,0,sizeof(info));
    check(virgl_renderer_resource_get_info(1,&info), "resource info");
    GLuint fb; glGenFramebuffers(1,&fb);glBindFramebuffer(GL_FRAMEBUFFER,fb);
    glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,info.tex_id,0);
    if(glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE) return 3;
    unsigned char pixels[12*12*4];glReadPixels(0,0,12,12,GL_RGBA,GL_UNSIGNED_BYTE,pixels);
    if(glGetError()!=GL_NO_ERROR)return 4;
    unsigned mismatches=0;
    for(unsigned y=0;y<12;y++)for(unsigned x=0;x<12;x++) {
        const unsigned char *p=pixels+(y*12+x)*4;
        const unsigned char want[4]={y<6?255:0,y<6?0:255,0,255};
        if(memcmp(p,want,4))mismatches++;
    }
    printf("ORIGINAL_NATIVE_ORIGIN flags=%u resource_flags=%u raw_bottom=%u,%u,%u,%u raw_top=%u,%u,%u,%u mismatches=%u renderer=%s\n",
        flags,info.flags,pixels[0],pixels[1],pixels[2],pixels[3],pixels[11*12*4],pixels[11*12*4+1],pixels[11*12*4+2],pixels[11*12*4+3],mismatches,glGetString(GL_RENDERER));
    /* QEMU v7.2 SDL scanout calls egl_fb_blit(dst,src,!y0_top).
     * Execute those original GL coordinates on a real destination framebuffer,
     * then inspect its top screen row (GL row height-1). */
    GLuint screen, screen_fb; glGenTextures(1,&screen);glBindTexture(GL_TEXTURE_2D,screen);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,12,12,0,GL_RGBA,GL_UNSIGNED_BYTE,NULL);
    glGenFramebuffers(1,&screen_fb);glBindFramebuffer(GL_DRAW_FRAMEBUFFER,screen_fb);
    glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,screen,0);
    if(glCheckFramebufferStatus(GL_DRAW_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE)return 5;
    glBindFramebuffer(GL_READ_FRAMEBUFFER,fb);
    glBlitFramebuffer(0,flags?0:12,12,flags?12:0,0,0,12,12,GL_COLOR_BUFFER_BIT,GL_LINEAR);
    glBindFramebuffer(GL_READ_FRAMEBUFFER,screen_fb);
    glReadPixels(0,0,12,12,GL_RGBA,GL_UNSIGNED_BYTE,pixels);
    if(glGetError()!=GL_NO_ERROR)return 6;
    unsigned scanout_mismatches=0;
    for(unsigned y=0;y<12;y++)for(unsigned x=0;x<12;x++) {
        const unsigned char *p=pixels+((11-y)*12+x)*4;
        unsigned red_top=flags==0;
        const unsigned char want[4]={((y<6)==red_top)?255:0,((y<6)==red_top)?0:255,0,255};
        if(memcmp(p,want,4))scanout_mismatches++;
    }
    printf("QEMU_NATIVE_SCANOUT flags=%u screen_top=%u,%u,%u,%u screen_bottom=%u,%u,%u,%u mismatches=%u\n",
        flags,pixels[11*12*4],pixels[11*12*4+1],pixels[11*12*4+2],pixels[11*12*4+3],pixels[0],pixels[1],pixels[2],pixels[3],scanout_mismatches);
    glDeleteFramebuffers(1,&screen_fb);glDeleteTextures(1,&screen);
    glDeleteFramebuffers(1,&fb);virgl_renderer_context_destroy(1);
    virgl_renderer_resource_unref(5);virgl_renderer_resource_unref(1);virgl_renderer_cleanup(&callbacks);
    return mismatches||scanout_mismatches?1:0;
}
