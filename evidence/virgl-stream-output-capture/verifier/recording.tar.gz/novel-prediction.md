# Chosen bounded novel regression, before evidence

Use three original buffer resources, each4096 bytes of0xa7, all selected role2160.
The TGSI vertex body remains identical across all layout generations: POSITION
comes from CONST[0] words[0,0,0,0x3f800000], OUT[1] from CONST[1] words
[0x7faabcd1,0x80000000,0xffffffff,0x3f800001]. Vertex elements are empty; discard is
true. Target40 initially retains resource1,offset16,size512; target41 retains
resource2,offset32,size512. Bind the complete tuple[40,41] with opaque mask0.

Phase A: original layout strides[8,0,0,0], one OUT[1].xyzw output to buffer0,
destination2; draw three POINTS. Resource1 has the four CONST[1] words at byte
offsets24,56,88; resource2/3 remain0xa7. Tuple byte cursors[96,0,0,0].

Phase B: replace public vertex shader10 and bind it, with exactly the same TGSI
body, original layout strides[0,12,0,0], OUT[1].xyzw to buffer1,destination5;
draw two POINTS. Resource2 receives four CONST[1] words at offsets52,100.
Resource1 remains Phase A. Tuple byte cursors[96,96,0,0].

Phase C: destroy public target40 and recreate40 over resource3,offset256,size256,
without changing the bound tuple. Replace public shader10 with the same body and
layout strides[5,0,0,0], OUT[1].y to buffer0,destination1; draw one POINT. The old
target generation remains bound: resource1 receives word0x80000000 at116;
resource3 remains entirely0xa7. Tuple byte cursors[116,96,0,0]. Native reflection
changes from uvec4 to uint and packed stride from16 to4. No previous layout key
or publicly replaced target may redirect this write.

Phase D: explicitly bind complete tuple[40,41], which now contains the new target40
generation, and draw one POINT with Phase C's layout. The new tuple starts all byte
cursors at0. Resource3 receives word0x80000000 at260; old resource1 and resource2
stay unchanged. New tuple cursors[20,0,0,0]. Every other destination byte and every
eight-byte original SG guard retain their initial byte. All resources are collected
with original206, after replacing their guest RAM with0x6b.

Independent physical control: repeat the case with a deliberately incorrect native
COPY_WRITE_BUFFER binding in Phase C only, redirecting the real captured packed
source from old resource1 to resource3 (all offsets/ranges remain legal). Let the
actual feedback and all original206/DMA reads complete. The oracle must refute the
control at resource1 byte116 (predicted00 00 00 80; observeda7 a7 a7 a7) and resource3
byte116 (predicteda7 a7 a7 a7; observed00 00 00 80). Failures before actual native
capture/readback or changing expected data do not count as the physical control.

This is one combined generation/layout regression. It does not expand D66 into
production qualification, capset negotiation or actual guest worker/scanout.
