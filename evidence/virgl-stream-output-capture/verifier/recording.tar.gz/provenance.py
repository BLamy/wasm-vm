"""Authenticate reopened source bodies and connect real GPU reads to original DMA."""
import gzip, hashlib, importlib.util, json, subprocess
from pathlib import Path

REPO = Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
ROOT = REPO / 'target/evidence/stream-output-capture-verifier'
WORK = ROOT / 'reopened/worker/cold/recording'
DEPLOY = ROOT / 'reopened/deployment'
RUNTIME = '75c3a664a0df8f0fb3ce4ff1c248a4167411c09d'
PROOF = '985a9ad1e9c8645429851f695ad486b779b96270'
SUBMITTED = '4a01d7a3d26a41a33435ef4b392696b2ccb5834e'
sha = lambda body: hashlib.sha256(body).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=REPO)

def pin(body, entry):
    assert len(body) == entry['bytes'] and sha(body) == entry['sha256'], entry

def main():
    receipt = json.loads((WORK / 'receipt.json').read_bytes())
    held = WORK / 'held-cold/recording'
    carried = receipt['carried']
    assert carried['runtimeHead'] == RUNTIME and carried['proofHead'] == PROOF
    assert sha((held.parent / 'report.json').read_bytes()) == carried['heldColdReportSha256']
    assert sha((held / 'commands.json').read_bytes()) == carried['commandsSha256']
    held_commands = json.loads((held / 'commands.json').read_bytes())
    assert carried['heldCommands'] == [r for r in held_commands if r['exitCode'] == r['expected']]
    assert [r for r in held_commands if r['exitCode'] != r['expected']] == [carried['earlierFailure']]
    assert carried['earlierFailure']['name'] == 'default-demo' and carried['earlierFailure']['exitCode'] == 1
    tracked = set(git('ls-tree', '-r', '--name-only', PROOF).decode().splitlines())
    source_pins = []
    for name, entry in receipt['sources'].items():
        body = (WORK / 'sources' / name).read_bytes()
        pin(body, entry)
        assert name in tracked
        assert body == git('show', PROOF + ':' + name), name
        source_pins.append(dict(path=name, **entry, matchesProofHead=True))
    runtime_names = [n for n in tracked if n.startswith(('crates/', 'renderer/'))
                     and '/tests/' not in n and not n.endswith(('.md', '_tests.rs'))]
    runtime_pins = []
    for name in sorted(runtime_names):
        a, b, c = (git('show', head + ':' + name) for head in [RUNTIME, PROOF, SUBMITTED])
        assert a == b == c, name
        runtime_pins.append(dict(path=name, bytes=len(a), sha256=sha(a)))
    records = []
    for group in ['layouts', 'primitives', 'retirement', 'scatter-fault', 'selected-regression']:
        folder = WORK / group
        report = json.loads((folder / 'report.json').read_bytes())
        for entry in report['sources']:
            body = (folder / 'source' / entry['path']).read_bytes()
            pin(body, entry)
            if entry['path'] in tracked:
                assert body == git('show', PROOF + ':' + entry['path']), (group, entry['path'])
        for entry in report['servedFiles']:
            name = entry['path'].lstrip('/')
            body = (folder / entry['bodyPath']).read_bytes() if entry.get('bodyPath') else (folder / 'source' / name).read_bytes()
            pin(body, entry)
        for entry in report['runs']:
            packed = (folder / entry['path']).read_bytes()
            assert sha(packed) == entry['gzipSha256']
            body = gzip.decompress(packed)
            pin(body, entry)
            row = json.loads(body)
            reads = [c for c in row['calls'] if c.get('method', c.get('name')) == 'getBufferSubData']
            outputs = []
            for index, exchange in enumerate(row['exchanges']):
                if exchange['kind'] != 'output':
                    continue
                matches = [c for c in reads if c.get('after', [None, None, {}])[2].get('bytes') == exchange['bytes']]
                assert matches, (group, entry['path'], index)
                outputs.append(dict(exchange=index, nativeReadCalls=[c.get('number', c.get('sequence')) for c in matches],
                                    bytes=len(exchange['bytes']) // 2, sha256=sha(bytes.fromhex(exchange['bytes']))))
            records.append(dict(group=group, path=entry['path'], sha256=entry['sha256'], nativeOriginalOutputs=outputs))
    metadata = WORK / 'metadata-supplement'
    meta_receipt = json.loads((metadata / 'receipt.json').read_bytes())
    assert meta_receipt['exitCode'] == 0 and meta_receipt['runtimeHead'] == RUNTIME
    assert sha((metadata / 'stdout.json').read_bytes()) == meta_receipt['stdoutSha256']
    for entry in meta_receipt['sources']:
        pin((metadata / 'source' / entry['path']).read_bytes(), entry)
    stage = DEPLOY / 'publication'
    stage_index = json.loads((stage / 'staging-index.json').read_bytes())
    assert sha((stage / 'frozen-web-dist.tar').read_bytes()) == stage_index['sourceArchiveSha256']
    custody_spec = importlib.util.spec_from_file_location('custody', REPO / 'tools/virgl-dimensional-depth-surfaces/custody.py')
    custody = importlib.util.module_from_spec(custody_spec)
    custody_spec.loader.exec_module(custody)
    inherited_auth, inherited = custody.reopen(REPO / 'evidence/virgl-stream-output-shaders/deployment',
        '94011feafe8720006fea2c4eab4e529c5d7b826d76cb590c86034001a673d8a0',
        lambda name: name == 'publication/staging-index.json' or name.startswith('publication/web/dist/artifacts') and name.endswith('.json'))
    assert inherited_auth == stage_index['authority']
    assert inherited['publication/staging-index.json'] == (stage / 'held-staging-index.json').read_bytes()
    inherited_index = json.loads(inherited['publication/staging-index.json'])
    assert stage_index['carriedBootManifests'] == inherited_index['carriedBootManifests']
    boot_names = set()
    for entry in stage_index['carriedBootManifests']:
        name = entry['path']; boot_names.add(name)
        assert sha(git('show', PROOF + ':web/dist/' + name)) == entry['sourceSha256']
        staged_body = (stage / 'web/dist' / name).read_bytes()
        assert staged_body == inherited['publication/web/dist/' + name] and sha(staged_body) == entry['stagedSha256']
    for entry in stage_index['records']:
        pin((stage / 'web/dist' / entry['path']).read_bytes(), entry)
        assert entry['bytes'] < 25 * 1024 * 1024
    demos = []
    live = DEPLOY / 'live'
    for folder in [WORK / 'default-demo', live]:
        report = json.loads((folder / 'report.json').read_bytes())
        assert report['status'] == 'passed' and (report['passed'], report['failed']) == (127, 0)
        assert report['errors'] == [] and report.get('httpErrors', []) == [] and report['proofExportAbsent'] is True
        assert report['gitHead'] == PROOF and report['graphicsRoadmapPip'] == 'cap-pip partial'
        image = (folder / report['screenshot']['path']).read_bytes()
        assert sha(image) == report['screenshot']['sha256']
        if folder == live:
            for entry in report['served']:
                name = entry['path'].lstrip('/')
                body = (live / 'bodies' / ('app' if name == 'app.html' else name)).read_bytes()
                pin(body, entry)
                staged_name = 'app.html' if name == 'app' else name
                assert body == (DEPLOY / 'publication/web/dist' / staged_name).read_bytes(), name
                if 'web/dist/' + staged_name in tracked and staged_name not in boot_names:
                    assert body == git('show', PROOF + ':web/dist/' + staged_name), name
            wasm = (live / 'bodies/pkg/wasm_vm_wasm_bg.wasm').read_bytes()
            assert sha(wasm) == report['servedWasmSha256']
            assert wasm == git('show', SUBMITTED + ':web/dist/pkg/wasm_vm_wasm_bg.wasm')
        demos.append(dict(path=str(folder.relative_to(ROOT)), reportSha256=sha((folder / 'report.json').read_bytes()),
                          passed=127, failed=0, errors=0, screenshotSha256=sha(image),
                          proofExportAbsent=True, wasmSha256=report['servedWasmSha256']))
    result = dict(schema='independent-source-native-and-deployment-provenance-v1', runtimeHead=RUNTIME,
                  proofHead=PROOF, submittedHead=SUBMITTED, sources=source_pins, unchangedRuntime=runtime_pins,
                  nativeOutputs=records, metadataSupplement=dict(receiptSha256=sha((metadata / 'receipt.json').read_bytes()), status='passed'),
                  demos=demos, carriedBootManifests=stage_index['carriedBootManifests'], inheritedDeployment=inherited_auth)
    (ROOT / 'provenance.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(sourceBodies=len(source_pins), unchangedRuntimeBodies=len(runtime_pins),
                          nativeRows=len(records), nativeOriginalOutputs=sum(len(r['nativeOriginalOutputs']) for r in records), demos=demos)))

if __name__ == '__main__':
    main()
