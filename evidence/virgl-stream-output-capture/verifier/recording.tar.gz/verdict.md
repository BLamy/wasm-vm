VERDICT: verified

Fresh independent critic for E6-T11d66; no implementation changes. Predictions P01–P17,
N1/S1, retirement R1–R6 and supplements C1–C8 were written before their respective
recordings were opened or run. Runtime is frozen at
75c3a664a0df8f0fb3ce4ff1c248a4167411c09d, proof continuation at
985a9ad1e9c8645429851f695ad486b779b96270, and submitted source at
4a01d7a3d26a41a33435ef4b392696b2ccb5834e. D65 compiler/dependency boundary and
Cargo.lock are byte-identical to verified predecessor 967826b1539c3099b2da5952a553c282b0428d35.

Citation aliases: `worker:` names full bodies in the committed worker seal;
`deployment:` names full bodies in its committed deployment seal; all other paths
name this verifier archive. JSON pointers identify concrete captured state.
`independent-audit.json` and `provenance.json` contain per-row/per-output hashes and
native call points, not worker expected arrays.

- P01 exact provenance — HELD. Both seals reopened every member/hardlink through
  the gzip trailer: worker 3218 and deployment 857 members. 1576 source bodies match
  the proof Git head; 414 runtime bodies match freeze, proof and submission. All
  browser sources/served bytes and rows authenticate. Actual headed Apple M4 Max
  WebGL2 is recorded, with no software-renderer/disabled-GPU flags or browser errors.
  Cite `reopened/worker-authentication.json`, `reopened/deployment-authentication.json`,
  `provenance.json /sources,/unchangedRuntime,/nativeOutputs`, and
  `promoted-positive/report.json /browser,/browserErrors`.
- P02 selected admission — HELD. Actual native test output lists role2048/2064/
  2080/2112/2160 at logical/native4096 bytes, legacy refusal, and exact byte-budget
  neighbor tests. Native 3/0 metadata, 13/0 control and25/0 submit tests have original
  wire/rings/digests/guest traces. Selected original browser creates/queues execute
  the new four-stage Rust/Wasm constructor; C8 executes legacy Wasm raster.
  Cite `worker:cold/recording/held-cold/recording/native-metadata.{stdout,stderr}`,
  `native-virtio_gpu_{control3d,submit3d}.{stdout,stderr}` and
  `promoted-positive/run-0008.json.gz /records,/guestTrace,/visible`.
- P03 checked layout/compiler boundary — HELD. Actual pinned C compiler outputs
  and raw original words normalize without rewriting. Invalid metadata and actual
  stage/pair compiler failures return typed refusals. A generic vertex/fragment pair
  and native reflection execute; all capture reflection uses the declared uint/uvec
  varying order. Cite `worker:cold/recording/{cases.stdout,metadata-supplement/stdout.json}`
  and `promoted-positive/run-0006.json.gz /phases/0/snap/renderer`.
- P04–P05 complete destination words and maximum layouts — HELD. Independently
  decoded original wire, uploads, TGSI MOV/UIF/alias/partial lanes and component layouts
  reproduce all480 layout rows, including 64 components,128 entries/four buffers,
  offsets/strides65535 and holes. Every original206 output and eight-byte SG guard
  matches; expected arrays from the worker are never read by the independent oracle.
  Cite `independent-audit.py`, `independent-audit.json /rows` for group layouts, and
  `worker:cold/recording/layouts/run-0000.json.gz /exchanges/5,/calls/6198/after`.
- P06–P07 primitive/instance/count/capacity — HELD. Three schedules reproduce complete
  primitive groups, strip winding/restart, divisor2/instance and original vertex IDs,
  literal nonindexed count/start0, ignored indexed count, whole-stride capacity and
  overflow holes. C1/C2 add u8/u16 restart indices with exact order7,3,9,4,6,2.
  Cite `worker:cold/recording/primitives/run-0000.json.gz /phases/0..32`, digest
  6ef9f51fd7e06486a916269aef7891632c3338f23332d33e41ba0969c2463bb3,
  `independent-audit.json` primitive rows, and `critic-audit.json` index-u8/index-u16 rows.
- P08–P09 retained tuple/resource generations and changing shader layouts — HELD.
  Mask0 and15 resume the same complete tuple; empty binding pauses. Still-bound
  target/resource generations remain on old storage after public-name replacement.
  N1 changes only original layout over the same TGSI body and observes byte cursors
  [96,0] → [96,96] → [116,96]; rebinding a new target generation starts [20,0].
  Full original old/new buffer words and holes match independently. Pinned upstream
  has UNUSED append_bitmask and literal count/start, not an invented mask0 reset.
  Cite `promoted-positive/run-0000.json.gz /phases/0..3`, body SHA256
  0c4574648046ac233c7d2f450d9ba638ec70322d0f411b6a0a237e1b7629c23e,
  `original-primary/vrend_renderer.c:10339-10390,6091-6095`, and retirement row3.
- P10 later vertex/index/uniform roles and aliases — HELD. Original captured words
  feed actual later GPU vertex/index/uniform draws. Active feedback/input conflict
  and duplicate storage refuse before capture. C4 captures the same raw UBO generation
  through two native programs and releases both range owners. Cite
  `worker:cold/recording/primitives/run-0000.json.gz /phases/33..35,/records` and
  `promoted-positive/run-0003.json.gz /phases/0,/after/store/budgets`.
- P11 native custody — HELD. The worker capture oracle audits955 original DMA
  readbacks,838 actual transform-feedback captures and11052 native scatter copies.
  A separate provenance audit links985 original outputs (including30 visible
  regression outputs) to actual native getBufferSubData bytes. Captures use legal
  POINTS drawArrays; no indexed draw runs during feedback and no CPU buffer upload
  manufactures packed capture storage. Created/deleted feedback objects and final
  native ownership match. Cite `independent-audit.json /counts,/rows/*/native`,
  `provenance.json /nativeOutputs`, and `critic-audit.json /summary,/positive`.
  The worker's931 figure omitted24 retirement readbacks;955 is the accurate total.
- P12–P13 retirement/cancellation/failure — HELD for the changed capture boundary.
  Real pending packed storage/TF/fence owners remain charged; reset, queue cancellation,
  active disposal and subcontext destruction retire exactly once. Partial native
  scatter modifies only the first actual four words and invalidates the tuple; a new
  tuple recovers. Detached membership and recycled public resource IDs keep old/native
  words at24/56/88/120/152 while the fresh4096-byte resource stays d3; a separate
  signaled-fence physical old-buffer read verifies it. C6 disposes a real outstanding
  packed buffer and checks revoked release once; C7 errors after a real active draw,
  ends feedback in finally, preserves destination, refuses stale tuple and recovers.
  Cite retirement runs0..11, especially
  `worker:cold/recording/retirement/run-0003.json.gz /phases,/physicalOldRead`, body
  SHA256 0526d0f141c847dab14df30e14aa5ba8b8cb93305f24d904518832fa555eb5a3,
  and `promoted-positive/run-0004.json.gz /calls,/phases,/failed` plus run7.
  Context-loss-specific browser recovery is not an acceptance claim of this selected
  consumer; no new physical context-loss or production recovery claim is inferred.
- P14 discard/visible compatibility — HELD. Original discard captures need no guest
  fragment or framebuffer; all prior color/depth/stencil paths survive the selected
  regression. C3 captures actual vertex texture sample words1,0,1,1. C5 records
  captured generic GREEN raw words and a safely interior original RGBA8 green pixel;
  C8 observes the same pixel through the historical constructor with zero feedback.
  Cite `worker:cold/recording/selected-regression/run-0000..0029.json.gz`,
  `promoted-positive/run-0005,0006,0008.json.gz /phases,/visible`, and coverage counters.
- P15 budgets/bounded work — HELD. Complete-primitive capacity bounds all output
  slots; charged packed/resource/native ticket budgets drain, recoverable native
  allocation refusal leaves its tuple reusable, uncertain failure invalidates it.
  Three independent schedules192734/314159/271828 (different withholding patterns)
  produce identical semantic words and zero final objects/syncs. Cite native budget
  test transcript, primitive refusal records, retirement pending/reset snapshots,
  `critic-audit.json /positive`, and concrete bounded loops/guards in the inspected diff.
- P16, N1/S1 physical oracle — HELD. Promoted N1 detects a deliberately wrong actual
  COPY_WRITE_BUFFER binding at native call12473, after actual feedback ended and before
  legal native copy/readback. Delivered buffer14 replaces buffer10. Three full original
  readbacks complete before failure: resource1 byte116 stays a7a7a7a7 (expected00000080),
  resource3 byte116 becomes00000080 (expecteda7a7a7a7); all other words match the precise
  injected misbinding. The oracle fails `expected [], got [1,3]`, and cleanup reaches0.
  Cite `promoted-wrong-binding/run-0000.json.gz /calls/12473,/phases/2`, body SHA256
  9bf8140ed9665ca9bc650a4ff92a7c58983ce2695eaa46e1b384093f19f62e72,
  and `critic-audit.json /sabotage/0`. This is the expected negative test, not a product refutation.
- P17 sufficiency/pristine clone/demo — HELD. Combined nested V8 ledger has1033
  positive partitions,5 static punctuation/comment partitions and36 explicit zero
  waivers; no dead or needs-evidence capture hunk remains. Zeros are not labeled as
  executions: each names an exact predecessor operand/fixed configuration or concrete
  type/error invariant. Rust field/parameter/cfg declarations and unchanged false
  constructor operands are waived; actual masks/queues/constructor bodies execute.
  All170 task hunks are enumerated. The final scrubbed clone freshly rebuilds proof
  Wasm/compiler, authenticates unchanged held gates and passes touched tests/demo.
  Default and canonical live records both pass127/0, zero errors, partial graphics
  marker and absent proof exports. Staged boot URL rewrites are byte-identical to the
  authenticated predecessor deployment and retain content identities.
  Cite `combined-coverage/coverage-audit.json`, `coverage-verdict.json`,
  `hunk-ledger.json`, `provenance.json /demos,/carriedBootManifests`, and
  worker cold report/receipt SHA256 7cb52f5ae78edb41164ee3aaac9c8b31e893f6241375fcbca43866a94f8eeabe.

SUITE: promoted renderer/virgl-command/tests/native-stream-output-critic.mjs
(SHA256 cd6ddfb09456164e8d2b5d3f8c6045d2b622ed6e598660d6b24793113425c281)
and tools/virgl-stream-output-capture/critic-browser.mjs
(SHA256 419492566a7d0a34ab7fcdc4a5b965fee3d8639201b61f338372535452591a09).
The nine deterministic scenes run27 times with213269 assertions and36 real captures;
their permanent negative mode physically misbinds a native destination and must fail
after readback. No runtime, production negotiation, Git stack, PR or merge was changed.

Commands: custody.reopen(worker/deployment/D65 seals); independent-audit.py;
provenance.py; coverage-combine.py; classify-coverage.py; hunk-ledger.py;
node --check promoted fixture and driver;
node tools/virgl-stream-output-capture/critic-browser.mjs --output
target/evidence/stream-output-capture-verifier/promoted-positive --authority
target/evidence/stream-output-capture-verifier/reopened/worker/cold/recording/layouts
--seeds 192734,314159,271828; the same driver with --seeds 192734 --fault true
for promoted-wrong-binding (expected exit1); critic-audit.py.

This verifies only the selected original stream-output component. Production
qualification, real Mesa/Hyprland worker/scanout, recovery and deployment remain
the user's successor objective, and no positive production capset follows.
