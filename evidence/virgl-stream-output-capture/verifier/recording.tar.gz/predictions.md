# E6-T11d66 independent verifier predictions

Prepared 2026-10-13 before opening any worker recording. Oriented from AGENTS.md,
the task acceptance/attack list, and the diff 967826b1539c3099b2da5952a553c282b0428d35
to runtime freeze 75c3a664a0df8f0fb3ce4ff1c248a4167411c09d. This verifier did not
implement D66. Source/build/browser/Git leases remain with the worker until handoff.

P01 — Exact provenance: every source byte served to the recorded browser must equal
the frozen runtime or authenticated unchanged D65 compiler; each decompressed run,
guest command trace, native log, screenshot and source pin must match its seal.
Selected Wasm construction must be standardStreamOutput, with productionAuthority
and actualLinuxGuest false, zero page/console/request errors and actual headed
Apple hardware WebGL2, never software rendering.

P02 — Selected admission: original target0/format64 buffer roles 2048,2064,2080,
2112,2160 retain width bytes logical/native cost; 0 width, invalid shape/format,
role2049 and resourceBytes+1 fail before resource publication. Historical selectors
must still refuse SO roles, object10, nonempty opcode25, discard and count override.

P03 — Checked layout boundary: preserved original count/stride/entry words roundtrip
unchanged through the typed C/Wasm compiler and normalizer. Invalid profile,
unknown/accessor keys, output component/mask/range/overlap/stream, varying name/type/
order/offset and packed size must be rejected. Native varying reflection must agree
with the selected uint/uvec components and ordered raw words before capture.

P04 — Destination words: for layout specimens, initialize every destination byte to
0xa7. At offset16 + vertex*strideBytes + destinationOffset*4, capture exactly the
selected TGSI register lanes; all other bytes remain0xa7. MOV retains original bits,
including NaN payloads, signed zero and all ones. Partial writes preserve zero on
unwritten lanes; alias xy swaps the previous x/y; conditional zw changes only when
the input word is nonzero; a wholly unwritten declared output remains zero. Original
206 DMA must overwrite prior guest0x6b with the complete GPU backing and preserve
all eight-byte SG guards0xa3. A separate verifier oracle will decode original wire,
without consuming row.expected.

P05 — Maximum layouts: 64 captured components in one buffer and128 entries over
four buffers produce all raw words without exceeding interleaved64; slots1..3 use
their own selected native program varying list. Nonzero maximum strides65535 and
destination65531 preserve all holes and stay within the original target range.

P06 — Primitive and instance ordering: points [1,2,3,4,5,6]; incomplete lines
[1,2,3,4,5,6]; loop [1,2,2,3,3,4,4,1]; line strip [1,2,2,3,3,4]; incomplete triangles
[1,2,3,4,5,6]; triangle strip [1,2,3,3,2,4,3,4,5]; fan [1,2,3,1,3,4,1,4,5]. Indexed
restart119 partitions the strip into [3,1,4,6,2,5,5,2,8] and loop into
[3,1,1,4,4,3,6,2,2,5,5,8,8,6]. Repeat that complete order for instances0,1,2;
divisor2 reads instance attributes floor(instance/2). VERTEXID/INSTANCEID remain
original uint identities even though capture uses legal native POINTS drawArrays.

P07 — Count/capacity: literal count override3 resets nonindexed start to0 and emits
[0,1,2]; indexed override99 still emits source[7,3,2]. Across active output slots,
the smallest whole-stride capacity limits all slots; only complete primitive groups
fit. Cursor after a phase is previous cursor + capturedVertices*strideBytes. Overflow
never writes an incomplete primitive or destination/SG guard.

P08 — Cursor identity: an existing complete tuple resumes for both opaque mask0 and
mask15. Empty binding pauses and retains its cursor. Recreating a public target name
does not change the still-bound old target generation/resource/offset; rebinding the
new target generation starts at its offset. Resource public-name recycling likewise
cannot retarget a retained target to new storage. Tuple/subcontext identities isolate
their cursors, even if public object numbers coincide.

P09 — Shader-layout mutation: changing an active shader's layout cannot reuse an
old varying list/program. The same complete target tuple retains its byte cursor
while the new legal stride and destination lanes apply to subsequent captures.
Novel regression: same TGSI body with a new original layout selecting a different
output buffer/stride while another old target generation remains bound; predict all
old/new buffers independently before capture and verify public-name reuse/detachment
cannot transfer output ownership.

P10 — Later roles: completed capture supplies original vertex words, original index7,
and original uniform words without stale reads or changed bit patterns. Content
revision increments before scatter invalidate materialized index/UBO readers. Active
feedback/input aliases and duplicate active output storage fail before capture or
packed allocation and publish no resource owner.

P11 — Actual native custody: each packed buffer is allocated/charged before
beginTransformFeedback(POINTS), bound as TF output, populated by real drawArrays and
copied by real copyBufferSubData into a distinct retained destination. Indexed native
draws never occur while feedback is active. No CPU shader evaluation or CPU target
bufferSubData manufactures captured bytes. Each original206 result is linked to its
native getBufferSubData and original writable SG segments.

P12 — Completion/retirement: packed storage, TF objects, target/resource leases,
uniform/image holds and syncs survive until GPU completion or explicit failure drain.
During a pending fence they remain charged; cancellation/reset/disposal invalidate
late work exactly once and never write a new target/backing/public generation. After
the final completion/disposal all native live objects/syncs and charged capture/hold
counts reach0, including recoverable null packed-buffer allocation and context loss.

P13 — Uncertain failure: a native failure after capture/scatter starts invalidates
the tuple; reusing it fails stale-capture until replacement/reset. Failure before
capture (packed allocation null) leaves the live tuple reusable after the fence.

P14 — Discard and visible compatibility: discard permits no guest fragment,
viewport, surface or depth attachment and never changes visible guest color/stencil.
With discard disabled the D64 dimensional-depth raster path still produces the
independently declared visible pixels/aspects; all capture-only state is restored
before raster draw. Vertex/capture-only generic attributes and typed integer inputs
survive program pruning with their correct locations.

P15 — Bounded work and budgets: no draw can exceed the declared source/instance,
expanded vertex, per-submission draw/call/copy, native scratch/resource/ticket limits.
Overflow and refusal paths drain owner accounting; budgets cannot go negative or
silently forget outstanding native storage. Independent schedule seeds produce
identical semantic words and final accounting.

P16 — Physical sabotage after native work: deliberately shift a valid scatter
destination by one dword or bind an incorrect native destination, let actual
begin/endTransformFeedback and original206/DMA readback complete, then require the
full-word oracle to fail at a known original word. A thrown setup error or altered
expected array does not satisfy this prediction.

P17 — Sufficiency and reproducibility: each changed executable hunk is executed in
recorded browser/native/decoder cases or receives an explicit scoped static waiver.
Acceptance passes once from a pristine scrubbed checkout with freshly rebuilt
generated compiler/proof Wasm, no inherited RUST/CARGO/NODE/EMCC overrides. The partial
demo stays partial, has zero browser errors and127 passed0 failed, with no positive
production capset.
The deployed partial marker/source bodies authenticate to the final unchanged head.

No verdict until each prediction has a concrete evidence citation and changed-hunk
classification. PREDICTIONS RECORDED BEFORE EVIDENCE.

Orientation correction before any recording was opened: P17 initially used the
historical AGENTS.md example total126. Direct source inspection of
tools/verify-virgl-default-demo.mjs lines53-57 defines the current suite total127.
The corrected concrete prediction is127 passed,0 failed. No recorded program state
has been inspected for this correction.
