# Additional predictions before the bounded supplementary runs

The sealed coverage ledger has now been opened. Prior predictions remain unchanged.
The following identify specific unexecuted new bodies before observing their state.

C6 — Direct host capability revocation: allocate one real native packed buffer
through createStandardStreamOutputResourceStore's returned streamOutputAccess.
store.dispose while its token is outstanding must destroy the storage, reduce
gpuBytes/packedCaptures to zero, and preserve one revoked token. A subsequent
streamOutputAccess.release(token) succeeds exactly once; a second release rejects
invalid-capture. This exercises the new revoked-capture disposal/release bodies.

C7 — Active feedback failure: inject a trusted INVALID_OPERATION immediately after
an actual drawArrays while real transform feedback is active. The finally block
must issue real endTransformFeedback, detach the native feedback buffer, disable
discard, fence/drain the packed buffer and invalidate the tuple. No destination
scatter occurred, so full original206 remains all 0xa7. The same tuple is refused;
a replacement tuple captures normally. This executes the new active=true cleanup
guard/body left unexercised by the worker's post-scatter fault.

C5 clarification — The non-discard visible case uses ordinary floating positions
and an additional stride-zero vertex attribute containing green [0,1,0,1]. The
same generic value is captured and rendered. The allConstants Map callback must
execute and deduplicate the shared guest attribute by its semantic index while
each native program retains its own location.

C8 — Historical renderer admission: repeat the finite green stride-zero generic
raster scene using the unchanged dimensional-depth Wasm selector and its original
dimensional-shadow compiler/bridge, with zero stream-output words and ordinary
vertex-role resources. An original empty opcode25 remains admitted. The real
raster draw produces the same interior green pixel, issues no transform feedback,
and disposes every native object. This directly executes the new historical
no-op/release guards and the absent capturePlans fallbacks without granting old
selectors any stream-output feature.
