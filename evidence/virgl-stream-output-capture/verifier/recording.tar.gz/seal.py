"""Seal critic bodies with full trailer reopening and pinned worker dependencies."""
import gzip, hashlib, importlib.util, io, json, tarfile
from pathlib import Path
REPO = Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
ROOT = REPO / 'target/evidence/stream-output-capture-verifier'
OUTPUT = REPO / 'evidence/virgl-stream-output-capture/verifier'
sha = lambda body: hashlib.sha256(body).hexdigest()
assert not OUTPUT.exists()
OUTPUT.mkdir(parents=True)
assert json.loads((ROOT / 'coverage-verdict.json').read_bytes())['needsEvidence'] == []
assert json.loads((ROOT / 'critic-audit.json').read_bytes())['summary']['sabotageCaught'] is True
assert (ROOT / 'provenance.json').is_file()
files = {}
for name in ['promoted-positive', 'promoted-wrong-binding', 'original-primary']:
    for path in (ROOT / name).rglob('*'):
        if path.is_file(): files[path.relative_to(ROOT).as_posix()] = path
for name in ['predictions.md', 'novel-prediction.md', 'retirement-predictions.md',
             'coverage-predictions.md', 'remaining-predictions.md', 'verdict.md',
             'independent-audit.py', 'independent-audit.json', 'provenance.py', 'provenance.json',
             'critic-audit.py', 'critic-audit.json', 'coverage-combine.py', 'coverage-summary.json',
             'classify-coverage.py', 'coverage-verdict.json', 'hunk-ledger.py', 'hunk-ledger.json',
             'runtime.diff', 'proof-only.diff', 'state.diff', 'predecessor-authentication.json', 'seal.py']:
    files[name] = ROOT / name
files['combined-coverage/coverage-audit.json'] = ROOT / 'combined-coverage/coverage-audit.json'
for role in ['worker', 'deployment']:
    files['reopened/' + role + '-authentication.json'] = ROOT / 'reopened' / (role + '-authentication.json')
for name in ['renderer/virgl-command/tests/native-stream-output-critic.mjs',
             'tools/virgl-stream-output-capture/critic-browser.mjs']:
    files['promoted-source/' + name] = REPO / name
rows, seen = [], {}
for name, path in sorted(files.items()):
    body = path.read_bytes(); digest = sha(body)
    row = dict(path=name, bytes=len(body), sha256=digest)
    if digest in seen: row['target'] = seen[digest]
    else: seen[digest] = name
    rows.append(row)
index = (json.dumps(rows, indent=2) + '\n').encode()
(OUTPUT / 'records.json').write_bytes(index)
archive = OUTPUT / 'recording.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0, compresslevel=9) as compressed, tarfile.open(fileobj=compressed, mode='w|') as packed:
    for row in rows:
        info = tarfile.TarInfo(row['path']); info.mode = 0o644; info.mtime = 0
        if 'target' in row:
            info.type = tarfile.LNKTYPE; info.linkname = row['target']; packed.addfile(info)
        else:
            body = files[row['path']].read_bytes()
            assert len(body) == row['bytes'] and sha(body) == row['sha256']
            info.size = len(body); packed.addfile(info, io.BytesIO(body))
manifest = dict(schema='independent-stream-output-capture-verifier-seal-v1', task='E6-T11d66', verdict='verified',
                runtimeHead='75c3a664a0df8f0fb3ce4ff1c248a4167411c09d',
                proofHead='985a9ad1e9c8645429851f695ad486b779b96270',
                submittedHead='4a01d7a3d26a41a33435ef4b392696b2ccb5834e',
                recordIndexSha256=sha(index), archiveSha256=sha(archive.read_bytes()),
                archiveBytes=archive.stat().st_size, records=len(rows), logicalBytes=sum(r['bytes'] for r in rows),
                dependencies=[dict(role=role, path='evidence/virgl-stream-output-capture/' + role,
                                   **json.loads((ROOT / 'reopened' / (role + '-authentication.json')).read_bytes()))
                              for role in ['worker', 'deployment']],
                unchangedPredecessor=json.loads((ROOT / 'predecessor-authentication.json').read_bytes()),
                summary=json.loads((ROOT / 'critic-audit.json').read_bytes())['summary'],
                originalCaptureAudit=json.loads((ROOT / 'independent-audit.json').read_bytes())['counts'],
                coverage=dict(positivePartitions=1033, staticPunctuationComments=5, explicitZeroWaivers=36, needsEvidence=0, dead=0),
                actualLinuxGuest=False, productionAuthority=False, implementationEdits=False)
if archive.stat().st_size >= 50 * 1024 * 1024:
    parts = []
    with archive.open('rb') as stream:
        while True:
            body = stream.read(16 * 1024 * 1024)
            if not body: break
            name = 'recording.tar.gz.part-' + str(len(parts)).zfill(4)
            (OUTPUT / name).write_bytes(body); parts.append(dict(path=name, bytes=len(body), sha256=sha(body)))
    manifest['archiveParts'] = parts; archive.unlink()
(OUTPUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
digest = sha((OUTPUT / 'manifest.json').read_bytes())
spec = importlib.util.spec_from_file_location('custody', REPO / 'tools/virgl-dimensional-depth-surfaces/custody.py')
custody = importlib.util.module_from_spec(spec); spec.loader.exec_module(custody)
authentication, _ = custody.reopen(OUTPUT, digest)
assert authentication['reopenedMembers'] == len(rows) and authentication['gzipEofChecked']
(ROOT / 'seal-authentication.json').write_text(json.dumps(authentication, indent=2) + '\n')
print(json.dumps(authentication))
