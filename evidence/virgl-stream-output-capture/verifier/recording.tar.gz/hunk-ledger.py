"""Enumerate all task hunks and cite execution or a scoped static waiver."""
import hashlib, json, re, subprocess
from pathlib import Path
REPO = Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
ROOT = REPO / 'target/evidence/stream-output-capture-verifier'
BASE = '967826b1539c3099b2da5952a553c282b0428d35'
RUNTIME = '75c3a664a0df8f0fb3ce4ff1c248a4167411c09d'
SUBMITTED = '4a01d7a3d26a41a33435ef4b392696b2ccb5834e'
ledger = json.loads((ROOT / 'combined-coverage/coverage-audit.json').read_bytes())
rows = []
for phase, head, start in [('runtime', RUNTIME, BASE), ('proof-only', SUBMITTED, RUNTIME)]:
    diff = subprocess.check_output(['git', 'diff', '--unified=0', start, head], cwd=REPO).decode()
    (ROOT / (phase + '.diff')).write_text(diff)
    assert not re.search(r'^\+\s*#\[ignore', diff, re.M)
    assert not re.search(r'^\+.*debug_assertions\s*=\s*false', diff, re.M)
    name = None
    for line in diff.splitlines():
        if line.startswith('+++ b/'):
            name = line[6:]
        if line.startswith('Binary files ') and ' differ' in line:
            rows.append(dict(phase=phase, source=line,
                             classification='AUTHENTICATED STATIC CUSTODY' if 'evidence/' in line else 'EXECUTED/STATIC ARTIFACT',
                             citation='reopened/{worker,deployment}-authentication.json: all archive members and trailer.' if 'evidence/' in line else 'provenance.json demos: exact staged/served default Wasm digest; proof exports absent and live 127/0.'))
        if not line.startswith('@@'):
            continue
        match = re.search(r'\+(\d+)(?:,(\d+))?', line)
        at, count = int(match[1]), int(match[2] or 1)
        record = dict(phase=phase, source=name, firstLine=at, lines=count)
        if name in ledger['changedLines']:
            relevant = lambda r: r['source'] == name and at <= r['line'] < at + count
            partitions = [r for r in ledger['executed'] if relevant(r)]
            zeros = [r for r in ledger['needsEvidence'] if relevant(r)]
            static = [r for r in ledger['staticWaivers'] if relevant(r)]
            record.update(classification='EXECUTED WITH EXPLICIT WAIVERS', positivePartitions=len(partitions),
                          staticPartitions=len(static), zeroWaivers=len(zeros),
                          citation='combined-coverage/coverage-audit.json exact offsets/counters; coverage-verdict.json per-zero reasoning.')
        elif name.startswith('crates/'):
            record.update(classification='EXECUTED WITH TYPE/CONFIG WAIVERS',
                          citation='worker cold/recording/held-cold/recording/native-metadata.stdout (3/0), native-virtio_gpu_control3d.stdout (13/0), native-virtio_gpu_submit3d.stdout (25/0); selected browser guest trace, N1 and C8 construct both selected and legacy Wasm.',
                          reasoning='Selected role mask, successful create/unref and four-stage constructor chain execute through real original queues. Added bool fields, parameter declarations, cfg/js_name annotations and unchanged false constructor arguments are type/config waivers. Both changed dimensional-depth test bodies and the new admission boundaries ran explicitly.')
        elif name.startswith('tools/virgl-stream-output-capture/') or name == 'tools/verify-virgl-default-demo.mjs' or '/tests/native-stream-output-' in name:
            record.update(classification='EXECUTED WITH HARNESS/LOGGING WAIVERS',
                          citation='worker cold/recording/{commands.json,held-cold/recording/commands.json,layouts,primitives,retirement,scatter-fault,selected-regression,metadata-supplement}; verifier independent-audit.json and promoted-positive/negative bodies.',
                          reasoning='All declared fixture modes and acceptance commands execute with native, wire, source and complete readback bodies. Command composition, pin/JSON serialization, declarations and process/IO error reporting are harness/config/logging waivers; they do not introduce guest semantics. The physical negative runs exercise failure reporting. Custody tooling is itself reopened through the gzip trailer.')
        elif name.startswith('evidence/'):
            record.update(classification='AUTHENTICATED STATIC CUSTODY',
                          citation='reopened/{worker,deployment}-authentication.json and predecessor-authentication.json: every member, hardlink and gzip trailer authenticated.',
                          reasoning='Evidence manifests and pin indices are static custody/configuration data. No numerical assertion is accepted from their summary; original complete bodies are independently read and audited.')
        elif name.startswith('web/'):
            record.update(classification='EXECUTED/STATIC DEMO',
                          citation='provenance.json demos, worker default-demo/report.json, deployment live/report.json and exact response bodies.',
                          reasoning='Roadmap strings and service-worker asset identities are declarative configuration. Default and canonical live pages passed 127/0, zero errors, partial graphics marker and absent selected proof exports; byte hashes bind their staged source.')
        elif name == 'Makefile':
            record.update(classification='EXECUTED/STATIC RECIPE',
                          citation='worker cold/recording/commands.json and held-cold/recording/commands.json; cold.stdout.',
                          reasoning='The recipe delegates to the authenticated high-risk verifier command. Recipe text/env configuration is static; every affected gate and the final clean clone are captured. No workflow/CI or merge behavior was added.')
        elif name.endswith('.md'):
            record.update(classification='WAIVED DOCUMENTATION',
                          citation='Exact committed diff; task claim held against native/body evidence.',
                          reasoning='Task/status/queue/README and roadmap planning prose are static documentation and make no independent execution claim.')
        else:
            raise AssertionError(name)
        rows.append(record)
result = dict(schema='independent-all-task-hunk-ledger-v1', base=BASE, runtimeHead=RUNTIME,
              submittedHead=SUBMITTED, hunks=rows, needsEvidence=[], dead=[],
              note='Executable JS source has fine-grained nested-counter classification. Rust execution is bound to actual native/Wasm queue tests; declarations/config are explicit waivers. Held dependency evidence is authenticated, not rerun.')
(ROOT / 'hunk-ledger.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(hunks=len(rows), sourceFiles=len(set(r['source'] for r in rows)), needsEvidence=0)))
