"""Independent original-wire/data oracle; never reads the worker's expected arrays."""
import gzip,hashlib,json,re,struct,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
WORK=BASE/'reopened/worker/cold/recording'
sha=lambda b:hashlib.sha256(b).hexdigest()
u32=lambda b,at=0:struct.unpack_from('<I',b,at)[0]

def packets(body):
    at=0
    while at<len(body):
        h=u32(body,at);n=h>>16;end=at+4*(n+1)
        assert end<=len(body)
        yield h&255,h>>8&255,list(struct.unpack_from('<'+'I'*n,body,at+4)),body[at:end]
        at=end

def primitive_order(values,mode,restart=None):
    # Separate reference construction, including literal last-vertex strip winding.
    groups=[];part=[]
    for n in [*values,restart if restart is not None else None]:
        if n is None or restart is not None and n==restart:
            if mode==0:groups.extend([[v] for v in part])
            elif mode in (1,4):groups.extend([part[i:i+(2 if mode==1 else 3)] for i in range(0,len(part)-(2 if mode==1 else 3)+1,2 if mode==1 else 3)])
            elif mode in (2,3):
                groups.extend([[part[i],part[i+1]] for i in range(len(part)-1)])
                if mode==2 and len(part)>1:groups.append([part[-1],part[0]])
            elif mode==5:
                for i in range(len(part)-2):groups.append([part[i+(i%2)],part[i+1-(i%2)],part[i+2]])
            else:groups.extend([[part[0],part[i],part[i+1]] for i in range(1,len(part)-1)])
            part=[]
        else:part.append(n)
    return groups

def sub():return dict(names={},vs=None,ve=[],vb=[],ib=None,ubo={},bank=[],tuple=None,tuples={})

def evaluate(shader,state,vertex,instance):
    outs={};temps={};imms={}
    def source(token):
        token=token.strip();m=re.fullmatch(r'(OUT|TEMP|IMM|IN|SV|CONST)\[(\d+)\](?:\[(\d+)\])?(?:\.([xyzw]{1,4}))?',token);assert m,token
        kind,index,indirect,swizzle=m.groups();index=int(index)
        if kind=='OUT':v=outs.setdefault(index,[0]*4)
        elif kind=='TEMP':v=temps.setdefault(index,[0]*4)
        elif kind=='IMM':v=imms[index]
        elif kind=='SV':v=[vertex if index==0 else instance,0,0,0]
        elif kind=='CONST':
            if indirect is None:v=(state['bank']+[0]*2048)[index*4:index*4+4]
            else:
                binding=state['ubo'][index];v=list(struct.unpack_from('<4I',binding['res']['data'],binding['offset']+int(indirect)*16))
        else:
            elem=state['ve'][index];vb=state['vb'][elem[2]];fetch=instance//elem[1] if elem[1] else vertex;at=vb['offset']+elem[0]+fetch*vb['stride'];v=list(struct.unpack_from('<4I',vb['res']['data'],at))
        return [v['xyzw'.index(lane)] for lane in (swizzle or 'xyzw')],kind,index
    active=True
    for line in shader['text'].splitlines():
        m=re.match(r'DCL OUT\[(\d+)\]',line)
        if m:outs.setdefault(int(m[1]),[0]*4)
        m=re.match(r'IMM\[(\d+)\] FLT32 \{([^}]*)\}',line)
        if m:imms[int(m[1])]=[u32(struct.pack('<f',float(v))) for v in m[2].split(',')]
        m=re.match(r'\d+: (.*)',line)
        if not m:continue
        instruction=m[1]
        if instruction.startswith('UIF '):active=source(instruction[4:])[0][0]!=0;continue
        if instruction=='ENDIF':active=True;continue
        if instruction=='END':break
        if not active:continue
        assert instruction.startswith('MOV '),instruction
        dst,src=instruction[4:].split(', ',1);values,_,_=source(src);values=(values*4)[:4]
        m=re.fullmatch(r'(OUT|TEMP)\[(\d+)\](?:\.([xyzw]{1,4}))?',dst);assert m,dst
        kind,index,mask=m.groups();target=(outs if kind=='OUT' else temps).setdefault(int(index),[0]*4)
        for lane in mask or 'xyzw':target['xyzw'.index(lane)]=values['xyzw'.index(lane)]
    return outs

def native_audit(row):
    bindings={};packed=set();feedback=set();deleted=set();active=False;draws=copies=0;native_copies=[]
    for call in row['calls']:
        method=call['method'];args=call.get('delivered',call['args']);result=call.get('result')
        ident=lambda value:value.get('object') if isinstance(value,dict) else None
        if method=='createTransformFeedback' and result:feedback.add(ident(result))
        if method=='deleteTransformFeedback' and args[0]:deleted.add(ident(args[0]))
        if method=='bindBuffer':bindings[args[0]]=ident(args[1])
        if method=='bindBufferBase' and args[0]==0x8c8e and args[2]:packed.add(ident(args[2]))
        if method=='beginTransformFeedback':assert not active and args==[0];active=True;draws+=1
        if method=='endTransformFeedback':assert active;active=False
        if active and method.startswith('draw'):assert method=='drawArrays' and args[0]==0 and args[1]>=0 and args[2]>0
        if method in ('bufferSubData','bufferData') and bindings.get(args[0]) in packed:
            assert method=='bufferData' and isinstance(args[1],int),'CPU manufacture of capture storage'
        if method=='copyBufferSubData' and bindings.get(args[0]) in packed:
            assert not active and bindings.get(args[1]) not in packed and args[4]>0
            copies+=1;native_copies.append(dict(call=call['number'],source=bindings[args[0]],destination=bindings[args[1]],sourceOffset=args[2],destinationOffset=args[3],bytes=args[4]))
    assert not active and feedback==deleted
    assert row['cleaned']['liveObjects']==row['cleaned']['liveSyncs']==0
    assert len(row['machineDigest'])==64
    return dict(nativeCaptures=draws,nativeCopies=copies,copies=native_copies)

def model(row,mode):
    resources={};subs={0:sub()};current=0;generation=0;epoch=None;readbacks=[];captured=0;commands=0;physical_expected=None
    inputs={(x['args'][0],x['args'][1]):x for x in row['exchanges'] if x['kind'].endswith('input')}
    outputs={(x['args'][0],x['args'][1]):x for x in row['exchanges'] if x['kind'].endswith('output')}
    error_labels={}
    for record in row['records']:
        b=bytes.fromhex(record['request'])
        for kind in ['transport','submit']:
            if record.get(kind+'Canonical'):assert sha(bytes.fromhex(record[kind+'Canonical']))==record[kind+'Digest']
        error_labels.setdefault(b,[]).append((u32(bytes.fromhex(record['response'])),record['case']))
        if u32(b)==0x207:assert u32(b,24)==len(b)-32
        trace=record['ring'];ds=bytes.fromhex(trace['descriptors']);assert u32(ds,8)==len(b) and struct.unpack_from('<H',ds,12)[0]==1
    for event in row['events']:
        if epoch!=event.get('epoch'):
            epoch=event.get('epoch');resources={};subs={0:sub()};current=0
        if event['type']=='createResource':
            meta=event['metadata'];assert meta['target']==0 and meta['format']==64
            resources[meta['id']]=dict(id=meta['id'],generation=event['resource']['generation'],data=bytearray(meta['width']))
        elif event['type']=='unrefResource':resources.pop(event['resource']['id'],None)
        elif event['type']=='beginJob':
            key=(event['epoch'],event['sequence'])
            if event['kind']=='transfer':
                x=inputs.get(key) or outputs.get(key)
                assert x,key
                res=resources[x['args'][3]];assert res['generation']==x['args'][4]
                start=int(x['args'][6],16);body=bytes.fromhex(x['bytes']);assert len(body)==x['args'][7]
                if x['kind'].endswith('input'):res['data'][start:start+len(body)]=body
                else:
                    wanted=bytes(res['data'][start:start+len(body)]);different=[i for i,(a,b) in enumerate(zip(body,wanted)) if a!=b]
                    readbacks.append(dict(resource=res['id'],generation=res['generation'],sequence=event['sequence'],bytes=len(body),expectedSha256=sha(wanted),actualSha256=sha(body),differentBytes=different[:12],differences=len(different)))
                    if mode!='scatter-fault':assert body==wanted,(mode,event['sequence'],res['id'],different[:12])
                continue
            body=bytes(event['commands']);commands+=1
            # Original response labels are only used to identify deliberately injected faults.
            req=bytearray(32+len(body));struct.pack_into('<I',req,0,0x207);struct.pack_into('<I',req,16,event['context']['id']);struct.pack_into('<I',req,24,len(body));req[32:]=body
            matches=[v for k,vs in error_labels.items() if k[0:4]==req[0:4] and k[16:20]==req[16:20] and k[24:]==req[24:] for v in vs]
            label=next((label for code,label in matches if code!=0x1100),'');failed=('conflict' in label or 'allocation refusal' in label or 'failed native tuple' in label)
            for op,typ,p,raw in packets(body):
                state=subs[current]
                if op==29:subs[p[0]]=sub();current=p[0];continue
                if op==28:current=p[0];continue
                if op==30:subs.pop(p[0]);continue
                if op==1:
                    generation+=1;obj=dict(generation=generation)
                    if typ==4:
                        extra=4+2*p[4] if p[4] else 0;text=raw[24+extra*4:24+extra*4+p[2]-1].decode();obj.update(text=text,stage=p[1],so=[p[4],*p[5:5+extra]])
                    elif typ==10:obj.update(res=resources[p[1]],offset=p[2],size=p[3])
                    elif typ==5:obj['elements']=[p[i:i+4] for i in range(1,len(p),4)]
                    state['names'][(typ,p[0])]=obj
                elif op==3:state['names'].pop((typ,p[0]),None)
                elif op==2 and typ==5:state['ve']=state['names'][(5,p[0])]['elements']
                elif op==31 and p[1]==0:state['vs']=state['names'][(4,p[0])]
                elif op==12 and p[0]==0:
                    at=p[1]*4;state['bank']+=(at+len(p)-2-len(state['bank']))*[0];state['bank'][at:at+len(p)-2]=p[2:]
                elif op==6:state['vb']=[dict(stride=p[i],offset=p[i+1],res=resources[p[i+2]]) for i in range(0,len(p),3)]
                elif op==11:state['ib']=dict(res=resources[p[0]],width=p[1],offset=p[2]) if p[0] else None
                elif op==27 and p[0]==0:
                    if p[4]:state['ubo'][p[1]]=dict(res=resources[p[4]],offset=p[2],length=p[3])
                    else:state['ubo'].pop(p[1],None)
                elif op==25:
                    targets=[state['names'].get((10,h)) if h else None for h in p[1:]]
                    if not any(targets):state['tuple']=None;continue
                    token=tuple(t['generation'] if t else 0 for t in targets)
                    state['tuple']=state['tuples'].setdefault(token,dict(targets=targets,cursors=[0]*4))
                elif op==8 and not failed:
                    so=state['vs']['so'];tup=state['tuple']
                    if not so[0] or not tup:continue
                    indexed=bool(p[3]);count=p[11] if not indexed and p[11] else p[1];start=0 if p[11] and not indexed else p[0];instances=max(1,p[4])
                    if indexed:
                        ib=state['ib'];width=ib['width'];values=list(struct.unpack_from('<'+{1:'B',2:'H',4:'I'}[width]*count,ib['res']['data'],ib['offset']))
                    else:values=list(range(start,start+count))
                    groups=primitive_order(values,p[2],p[8] if indexed and p[7] else None);prim=1 if p[2]==0 else 2 if p[2]<4 else 3;entries=[];used=set()
                    for i in range(so[0]):
                        w=so[5+2*i];e=dict(reg=w&255,start=w>>8&3,count=w>>10&7,buffer=w>>13&7,destination=w>>16);entries.append(e);used.add(e['buffer'])
                    cap=min([(tup['targets'][b]['size']-tup['cursors'][b])//(so[1+b]*4) for b in used]);fit=min(len(groups)*instances,cap//prim);ordered=[(vertex,instance) for instance in range(instances) for group in groups for vertex in group][:fit*prim]
                    partial='actual partial native scatter' in label
                    for b in sorted(used):
                        target=tup['targets'][b];first=True
                        for number,(vertex,instance) in enumerate(ordered):
                            registers=evaluate(state['vs'],state,vertex,instance)
                            for entry in [e for e in entries if e['buffer']==b]:
                                if partial and not first:continue
                                at=target['offset']+tup['cursors'][b]+number*so[1+b]*4+entry['destination']*4
                                struct.pack_into('<'+'I'*entry['count'],target['res']['data'],at,*registers[entry['reg']][entry['start']:entry['start']+entry['count']]);first=False
                        if not partial:tup['cursors'][b]+=len(ordered)*so[1+b]*4
                    captured+=len(ordered)
    if row.get('physicalOldRead'):
        # Independent explicit detached/recycled-resource prediction, no recorded expected value.
        wanted=bytearray([0xa7]*4096);data=[0x7fa12345,0x80000000,0xffffffff,0x3f800007]
        for at in [24,56,88]:struct.pack_into('<4I',wanted,at,*data)
        for at in [120,152]:struct.pack_into('<4I',wanted,at,data[0]^1,*data[1:])
        assert bytes.fromhex(row['physicalOldRead']['actual'])==wanted
        assert row['physicalOldRead']['fence'] in (0x911a,0x911c)
    return dict(commands=commands,capturedVertices=captured,readbacks=readbacks)

def main():
    result=dict(schema='independent-original-word-audit-v1',rows=[],counts=dict(layouts=0,primitives=0,retirement=0,readbacks=0,nativeCaptures=0,nativeCopies=0))
    receipt=json.loads((WORK/'receipt.json').read_bytes());assert sha((WORK/'receipt.json').read_bytes())=='7cb52f5ae78edb41164ee3aaac9c8b31e893f6241375fcbca43866a94f8eeabe'
    assert json.loads((WORK.parent/'report.json').read_bytes())['cleanBefore']==json.loads((WORK.parent/'report.json').read_bytes())['cleanAfter']==''
    for folder in [WORK,WORK/'held-cold/recording']:
        for cmd in json.loads((folder/'commands.json').read_bytes()):
            for stream in ['stdout','stderr']:assert sha((folder/(cmd['name']+'.'+stream)).read_bytes())==cmd[stream+'Sha256']
            assert cmd['exitCode']==cmd['expected'] or cmd['name']=='default-demo' and cmd['exitCode']==1
    for group in ['layouts','primitives','retirement','scatter-fault']:
        report=json.loads((WORK/group/'report.json').read_bytes());assert not any(report['browserErrors'].values());assert report['browser']['headless'] is False
        assert 'Apple M4 Max' in str(report['browser']['gpu']['devices']);assert not any(re.search('swiftshader|llvmpipe|softpipe|lavapipe|--disable-gpu',a,re.I) for a in report['browser']['commandLine'])
        for pin in report['runs']:
            packed=(WORK/group/pin['path']).read_bytes();assert sha(packed)==pin['gzipSha256'];body=gzip.decompress(packed);assert sha(body)==pin['sha256'] and len(body)==pin['bytes'];row=json.loads(body)
            native=native_audit(row);semantic=model(row,group);result['rows'].append(dict(group=group,path=pin['path'],sha256=pin['sha256'],native=native,semantic=semantic))
            if group in result['counts']:result['counts'][group]+=1
            result['counts']['readbacks']+=len(semantic['readbacks']);result['counts']['nativeCaptures']+=native['nativeCaptures'];result['counts']['nativeCopies']+=native['nativeCopies']
    assert result['counts']['layouts']==480 and result['counts']['primitives']==3 and result['counts']['retirement']==12
    (BASE/'independent-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['counts']))
if __name__=='__main__':main()
