"""Each zero governing V8 partition gets an explicit predecessor or type waiver."""
import hashlib, json, re, subprocess
from pathlib import Path
REPO = Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
ROOT = REPO / 'target/evidence/stream-output-capture-verifier'
ledger = json.loads((ROOT / 'combined-coverage/coverage-audit.json').read_bytes())
base = ledger['base']
sha = lambda b: hashlib.sha256(b).hexdigest()
old = {}
waivers = []
normalize = lambda s: re.sub(r'\s+', ' ', s.strip())
for entry in ledger['needsEvidence']:
    name, line, text = entry['source'], entry['line'], entry['text']
    if name not in old:
        old[name] = subprocess.check_output(['git', 'show', base + ':' + name], cwd=REPO).decode()
    predecessor = normalize(text) in normalize(old[name])
    reason = None
    if name.endswith('constant-domain.mjs') and line in [1611, 1619, 1630, 1634]:
        category = 'type/error propagation'
        reason = ('The admitted record/array contract and checked compiler responses convert malformed metadata to DomainFault; '
                  'the recorded metadata supplement exercises those refusals. This bare rethrow propagates an unexpected '
                  'programmer or engine exception, not an admitted guest branch. The four wrappers add no recovery semantics. '
                  'The record/array and DomainFault definitions, and typed compiler refusal bodies, are retained in the seal.')
    elif name.endswith('resources.mjs') and line == 1020:
        category = 'type/error aggregation'
        reason = ('C6 executes disposal of an actual outstanding native packed buffer and one revoked release. '
                  'The concrete closed-factory destroy at resources.mjs:1737-1741 deletes a valid owned WebGLBuffer '
                  'without a throwing GL check; this catch only aggregates a foreign or engine exception. '
                  'Normal native deletion and zero budget/map are directly captured, rather than inferred from this zero counter.')
    elif name.endswith('resources.mjs') and line == 1318:
        category = 'type invariant'
        reason = ('The concrete allocator at resources.mjs:1790-1803 returns a frozen kind=buffer for this fixed '
                  'standard-buffer metadata, or throws and destroys it; it never successfully returns null or a texture. '
                  'This validation of a hypothetical foreign backend result is a static type boundary. Real allocation '
                  'failure, charging, disposal and revoked release have separate executed evidence.')
    elif name.endswith('state.mjs') and line == 519:
        category = 'type/default invariant'
        reason = ('Both admitted checked decoders assign an explicit streamOutputWords array, including [0], '
                  'and internalFragment initializes [0]. C8 exercises the historical zero-output array and C1-C7/N1 '
                  'exercise selected capture arrays. The null-coalescing default is initialization protection for an '
                  'absent internal field, not a reachable wire alternative.')
    else:
        assert predecessor, (name, line, text)
        category = 'unchanged predecessor/configuration'
        if name.endswith('control-bridge.mjs'):
            reason = ('This exact operand exists in the verified predecessor. The selected factory fixes its facet '
                      'flags and resource limits; the old dimensional-depth factory is exercised independently by C8. '
                      'The remaining historical factories and caller-supplied configuration inherit their unchanged D65 boundary.')
        elif name.endswith('decoder.mjs'):
            reason = ('This exact operand exists in D65 and belongs to a historical nonstandard/default draw or shader '
                      'profile. D66 adds its selected branch while retaining the original profile operand; the selected '
                      'restart/index/draw wire paths and C8 legacy raster path are executed.')
        elif name.endswith('resources.mjs'):
            reason = ('This exact role/facet operand exists in D65. The selected stream-output store fixes the enabled '
                      'image/uniform facets and uses the new buffer role path; this residual historical role/configuration '
                      'operand is carried with the unchanged dependency. Selected mixed buffer roles and real image leases execute.')
        elif name.endswith('state.mjs'):
            reason = ('This exact profile/facet/compiler/interface operand exists in D65. Selected stream-output and '
                      'historical dimensional-depth factories fix their flags and exercise the changed branches. '
                      'Unselected older profile alternatives and their original data contracts retain the verified predecessor semantics.')
        else:
            raise AssertionError((name, line))
    waivers.append(dict(**entry, classification='WAIVED', category=category, reason=reason,
                        predecessorExactTextPresent=predecessor, predecessorBodySha256=sha(old[name].encode())))
result = dict(schema='independent-stream-output-coverage-classification-v1', runtimeHead=ledger['runtimeHead'],
              predecessor=base, positivePartitions=len(ledger['executed']),
              staticPunctuationComments=ledger['staticWaivers'], waivedZeroPartitions=waivers,
              needsEvidence=[], dead=[], note='Zero counters are not claimed as executions. Waivers are scoped to the closed selected factory and unchanged operands.')
assert len(waivers) == 36
(ROOT / 'coverage-verdict.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(positive=result['positivePartitions'], static=len(result['staticPunctuationComments']),
                      zeroWaivers=len(waivers), exactPredecessorOperands=sum(w['predecessorExactTextPresent'] for w in waivers),
                      needsEvidence=0, dead=0)))
