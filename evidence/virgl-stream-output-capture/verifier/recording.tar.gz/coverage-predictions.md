# Bounded coverage supplements chosen before opening recordings

The worker reported new zero V8 partitions in indexed capture, capture samplers,
duplicate uniform holds, and generic interface handling. These are predictions
from source review, before opening the worker coverage ledger or recordings.

C1/C2: Original u8 and u16 index arrays [7,3,9,119,4,6,2], TRIANGLES with restart119,
produce complete vertex order [7,3,9,4,6,2]. A system-only vertex shader moves original
VERTEXID to OUT[1].x; layout buffer0 stride4,destination1 and target offset16 writes
u32 words 7,3,9,4,6,2 at byte offsets20,36,52,68,84,100. Every other original byte
remains 0xa7. Native capture remains legal POINTS arrays, while original index width
is preserved in the queued read and decoded draw. Original206/SG guards prove all
destination bytes. The two actual widths must execute the new u8/u16 ternary arms.

C3: A vertex sampler2D reads an original nearest-filtered 2x2 RGBA8 texture filled
with [255,0,255,255]. Capturing all four returned OUT[1] components must produce
raw words [0x3f800000,0,0x3f800000,0x3f800000] at every captured vertex. Image-range
holds remain live until the final native fence and reach zero afterwards. No guest
fragment work is needed for this discard capture.

C4: A single original UBO bank supplies raw words
[0x7faabcd1,0x80000000,0xffffffff,0x3f800001] to OUT[1] and OUT[2], captured into two
independent original buffers. Program-specific range tokens for the same retained
resource generation may be released when an earlier hold already owns that
generation; one held range survives the fence and all ranges reach zero after
completion. Both buffers receive exact identical raw words, with independently
specified offset/stride/destination holes preserved.

C5: A checked C/Wasm shader pair actually passes GENERIC[0] from vertex to fragment.
Its generic input/output type and interpolation agree. A real non-discard TRIANGLES
draw on original RGBA8 storage, combined with original capture of constant green
OUT[1], produces captured words [0,0x3f800000,0,0x3f800000] and a safely interior
pixel [0,255,0,255]. The capture-only program and raster program must each restore
their own framebuffer, feedback, discard, shader and attribute state.

The exact residual coverage partitions will be classified after opening the sealed
ledger. Closed historical selector operands, types/configuration and guards outside
the task's admitted consumer receive reasoned waivers; genuine new executable paths
require bounded recording. These cases exercise D66's stated boundary only.
