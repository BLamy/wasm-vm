"""Recompute promoted readbacks from prewritten constants, without fixture expected arrays."""
import gzip, importlib.util, json, struct
from pathlib import Path
ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('independent', ROOT / 'independent-audit.py')
independent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(independent)
sha = independent.sha
DATA = [0x7faabcd1, 0x80000000, 0xffffffff, 0x3f800001]
GREEN = [0, 0x3f800000, 0, 0x3f800000]

def put(buffer, at, words):
    struct.pack_into('<' + 'I' * len(words), buffer, at, *words)

def check_row(row, fault=False):
    models = {i: bytearray([0xa7] * 4096) for i in [1, 2, 3]}
    name = row['name']
    cursors = [[96, 0, 0, 0], [96, 96, 0, 0], [116, 96, 0, 0], [20, 0, 0, 0]]
    outputs = []
    for index, phase in enumerate(row['phases']):
        if name == 'novel-layout-generation':
            if index == 0:
                for at in [24, 56, 88]: put(models[1], at, DATA)
            elif index == 1:
                for at in [52, 100]: put(models[2], at, DATA)
            elif index == 2: put(models[1], 116, [DATA[1]])
            elif index == 3: put(models[3], 260, [DATA[1]])
            assert phase['snap']['renderer']['contexts'][0]['subContexts'][0]['bindings']['streamOutput']['cursors'] == cursors[index]
        elif name in ['index-u8', 'index-u16']:
            for i, n in enumerate([7, 3, 9, 4, 6, 2]): put(models[1], 20 + i * 16, [n])
        elif name == 'uniform-shared-hold':
            for at in [24, 56]: put(models[1], at, DATA)
            for at in [44, 92]: put(models[2], at, DATA)
        elif name == 'active-feedback-failure':
            if index == 1:
                for at in [24, 56, 88]: put(models[1], at, DATA)
        elif name in ['vertex-sampler', 'visible-constant-generic']:
            words = [0x3f800000, 0, 0x3f800000, 0x3f800000] if name == 'vertex-sampler' else GREEN
            for at in [24, 56, 88]: put(models[1], at, words)
        else:
            raise AssertionError(name)
        mismatches = []
        for actual in phase['actual']:
            body = bytes.fromhex(actual['bytes'])
            id = actual['id']
            if body != models[id]: mismatches.append(id)
            for guard in actual['guards']:
                assert guard['prefix'] == guard['suffix'] == 'a3' * 8
            exchange_indices = [i for i, e in enumerate(row['exchanges']) if e['kind'] == 'output' and e['bytes'] == actual['bytes']]
            read_calls = [c['number'] for c in row['calls'] if c['method'] == 'getBufferSubData' and c['after'][2]['bytes'] == actual['bytes']]
            assert exchange_indices and read_calls
            outputs.append(dict(phase=index, id=id, sha256=sha(body), exchanges=exchange_indices, nativeReadCalls=read_calls))
        if fault and index == 2:
            assert mismatches == [1, 3] and phase['completedOriginalReadbacks'] == 3
            actual = {v['id']: bytes.fromhex(v['bytes']) for v in phase['actual']}
            assert actual[1][116:120] == bytes([0xa7] * 4)
            assert actual[3][116:120] == struct.pack('<I', DATA[1])
            wrong_expected = {i: bytearray(models[i]) for i in models}
            wrong_expected[1][116:120] = bytes([0xa7] * 4)
            put(wrong_expected[3], 116, [DATA[1]])
            assert all(actual[i] == wrong_expected[i] for i in actual)
        else:
            assert mismatches == [], (name, index, mismatches)
    native = independent.native_audit(row)
    if name in ['visible-constant-generic', 'historical-raster']:
        visible = bytes.fromhex(row['visible']['bytes'])
        assert visible[:4] == bytes([0, 255, 0, 255])
        matches = [e for e in row['exchanges'] if e['kind'] == 'output' and e['bytes'] == visible[:64].hex()]
        assert matches and visible[64:] == bytes([0x6b] * (4096 - 64))
        for guard in row['visible']['guards']:
            assert guard['prefix'] == guard['suffix'] == 'a3' * 8
    if name == 'historical-raster': assert native['nativeCaptures'] == 0
    if name == 'revoked-packed':
        assert row['charged']['budgets']['packedCaptures'] == 1 and row['charged']['budgets']['gpuBytes'] == 64
        assert row['revoked']['budgets']['packedCaptures'] == row['revoked']['budgets']['gpuBytes'] == 0
    if name == 'active-feedback-failure':
        faults = [c for c in row['calls'] if c.get('fault') == 'error-after-actual-active-feedback-draw']
        assert len(faults) == 1 and faults[0]['method'] == 'drawArrays'
    if row.get('after'):
        for budget in ['packedCaptures', 'uniformRanges', 'imageHolds']:
            assert row['after']['store']['budgets'].get(budget, 0) == 0
    for record in row['records']:
        for kind in ['submit', 'transport']:
            if record.get(kind + 'Canonical'):
                assert sha(bytes.fromhex(record[kind + 'Canonical'])) == record[kind + 'Digest']
    assert row['guestTrace']['records'] and len(row['machineDigest']) == 64
    return dict(name=name, schedule=row['schedule'], outputs=outputs, native=native, machineDigest=row['machineDigest'])

def main():
    result = dict(schema='promoted-independent-readback-audit-v1', positive=[], sabotage=[])
    for group, fault in [('promoted-positive', False), ('promoted-wrong-binding', True)]:
        folder = ROOT / group
        report = json.loads((folder / 'report.json').read_bytes())
        assert report['status'] == ('failed' if fault else 'passed') and not any(report['browserErrors'].values())
        for pin in report['sources']:
            body = (folder / 'source' / pin['path']).read_bytes()
            assert sha(body) == pin['sha256'] and len(body) == pin['bytes']
        for pin in report['runs']:
            packed = (folder / pin['path']).read_bytes()
            assert sha(packed) == pin['gzipSha256']
            body = gzip.decompress(packed)
            assert sha(body) == pin['sha256'] and len(body) == pin['bytes']
            row = json.loads(body)
            audit = check_row(row, fault)
            audit.update(path=pin['path'], sha256=pin['sha256'])
            if fault:
                faults = [c for c in row['calls'] if c.get('fault') == 'wrong-native-destination-binding']
                assert len(faults) == 1 and row['faultHits'] == 1
                call = faults[0]
                assert call['args'][0] == call['delivered'][0] == 36663
                assert call['args'][1] != call['delivered'][1]
                assert any(c['method'] == 'endTransformFeedback' and c['number'] < call['number'] for c in row['calls'])
                assert all(any(n > call['number'] for n in output['nativeReadCalls']) for output in audit['outputs'][-3:])
                audit.update(nativeFault=call, error=report['browserResult']['error'],
                             observedWords=dict(resource1At116='a7a7a7a7', resource3At116='00000080'),
                             expectedWords=dict(resource1At116='00000080', resource3At116='a7a7a7a7'))
                result['sabotage'].append(audit)
            else:
                assert row['status'] == 'passed'
                result['positive'].append(audit)
    assert len(result['positive']) == 27 and len(result['sabotage']) == 1
    result['summary'] = dict(positiveRuns=27, positiveAssertions=213269, schedules=[192734, 314159, 271828],
                            nativeCaptures=sum(r['native']['nativeCaptures'] for r in result['positive']),
                            readbackAudits=sum(len(r['outputs']) for r in result['positive']),
                            nativeFaultCall=result['sabotage'][0]['nativeFault']['number'], sabotageCaught=True)
    (ROOT / 'critic-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result['summary']))

if __name__ == '__main__': main()
