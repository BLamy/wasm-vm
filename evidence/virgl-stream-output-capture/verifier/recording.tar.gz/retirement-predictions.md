# Final retirement supplement predictions, before evidence

Oriented from native-stream-output-retirement.mjs only. Neither inner nor final
worker recordings have been opened. Runtime freeze remains 75c3a664.

R1: The actual three-POINT capture pending its final fence has packedCaptures=1,
renderer.work.draws=1 and pending.status=waiting-gpu. Reset or queue cancellation
must retire that allocation/TF object/sync exactly once. The old used ring and
64-byte response body stay unchanged when a late old-epoch completion is attempted.
Fresh epoch capture writes only the fresh allocation and all final native/charged
owners reach zero at disposal, under schedules 0, 1 and 2.

R2: Injected INVALID_OPERATION occurs immediately after the first real native
scatter copy, after all three native vertices were captured. Original destination
bytes 24..39 hold [0x7fa12345,0x80000000,0xffffffff,0x3f800007]; every other original
byte remains 0xa7. gpuComplete=true and packedCaptures=0 after failure drain. The
same tuple fails stale-capture with no subsequent beginTransformFeedback. A new
target tuple recovers by writing those four words at 24,56,88.

R3: Destroying subcontext 7 after its draw, within the same original submission,
preserves captured bytes and job-owned target/resource references until the final
fence, then collects every subcontext owner. Default subcontext 0 has an independent
tuple cursor and writes its own first three vertices at 24,56,88.

R4: Default target size 320 leaves capacity after the first three vertices. While
its original context membership is detached, a one-POINT draw with first constant
word XOR 1 writes [0x7fa12344,0x80000000,0xffffffff,0x3f800007] at byte 120 in the
retained old resource, with all previous words/padding preserved. Reattach plus
full original206 must prove all 4096 bytes and the unchanged SG guards.

R5: Recycle public resource ID 1 and upload 0xd3 into its fresh generation. The still
bound old target's next one-POINT draw writes the changed four words at byte 152 of
the old native allocation. Full original206 of the new public generation must still
be 4096 bytes of 0xd3. A separate actual signaled-fence native read of the retained
old buffer must contain old DATA at 24,56,88 and changed DATA at 120,152, with every
other byte 0xa7. The new public generation must differ from the old one.

R6: Binding a new target object over the new public generation starts its cursor at
the original offset 16. Three POINTS write changed DATA at 24,56,88 against the
new 0xd3 backing. Old target/resource ownership remains independent until context
disposal; all zero-count and exhausted-target claims must be checked against actual
native captured vertex/copy counts rather than accepted as byte-only witnesses.
