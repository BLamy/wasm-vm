#!/usr/bin/env python3
"""Fresh custody audit; the worker's receipt is an input, never a verdict."""
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
WORKER = HERE.parent / 'worker'
HEAD = '2ba17ed3d5373eea3991225c8cd8160920928499'
PARENT = 'bcdb820620092aaf869aa0574ffce6de793dd5fe'
ARCHIVE = 'b435606f2147094639d1bdf9018c3ef9c2a3ad0aa9dd7ef3a9661fd2fde34395'
INDEX = 'f70fe5fc912d7523c4e624bcb25fb245a99ceb2d027957f2c3aac03da79f49c4'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def main():
    manifest = json.loads((WORKER / 'manifest.json').read_text())
    archive, index = [(WORKER / name).read_bytes() for name in ['recording.tar.gz', 'records.json']]
    assert sha(archive) == manifest['archiveSha256'] == ARCHIVE
    assert sha(index) == manifest['recordIndexSha256'] == INDEX
    assert len(archive) == manifest['archiveBytes'] == 5834228
    records = json.loads(index)
    assert records['sourceHead'] == manifest['sourceHead'] == HEAD
    members = {}
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tar:
        for member in tar:
            path = PurePosixPath(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts
            assert member.name not in members
            members[member.name] = tar.extractfile(member).read()
    assert len(members) == len(records['records']) == manifest['records'] == 196
    assert set(members) == {r['path'] for r in records['records']}
    for record in records['records']:
        raw = members[record['path']]
        assert len(raw) == record['bytes'] and sha(raw) == record['sha256'], record
        destination = HERE / 'unpacked' / record['path']
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)
    reports = []
    source_map = {}
    for prefix in ['hot', 'cold']:
        receipt = json.loads(members[prefix + '/receipt.json'])
        assert receipt['status'] == 'passed' and receipt['gitHead'] == HEAD
        assert not receipt['guestExecution'] and not receipt['productionNegotiation']
        assert sha(members[prefix + '/receipt.json']) == manifest[prefix + 'ReceiptSha256']
        for name, digest in receipt['files'].items():
            assert sha(members[prefix + '/' + name]) == digest, (prefix, name)
        for name, digest in receipt['generated'].items():
            assert sha(members[prefix + '-generated/' + name]) == digest, (prefix, name)
        for name, digest in receipt['sources'].items():
            if name in source_map:
                assert source_map[name] == digest, name
            source_map[name] = digest
        for name in ['hardware', 'fault-scalar', 'fault-rgba', 'fault-perspective']:
            report = json.loads(members[prefix + '/' + name + '/report.json'])
            assert report['gitHead'] == HEAD
            assert report['status'] == ('passed' if name == 'hardware' else 'failed')
            assert report['browserErrors'] == {'console': [], 'page': [], 'requests': []}
            assert not report['browser']['headless']
            assert report['browser']['gpu']['featureStatus'].get('webgl2', report['browser']['gpu']['featureStatus'].get('webgl')) == 'enabled'
            assert all(not any(bad in flag.lower() for bad in ['swiftshader', 'llvmpipe', 'softpipe', 'lavapipe', '--disable-gpu']) for flag in report['browser']['commandLine'])
            served = {r['path']: r for r in report['servedFiles']}
            mutation = report.get('mutation')
            if mutation:
                original = git('show', HEAD + ':' + mutation['path'])
                changed = members[prefix + '/' + name + '/mutation-source.mjs']
                assert sha(original) == mutation['originalSha256']
                assert sha(changed) == mutation['servedSha256']
                assert original.count(mutation['needle'].encode()) == 1
                assert original.replace(mutation['needle'].encode(), mutation['replacement'].encode()) == changed
            for item in report['sources']:
                if '/build/' in item['path']:
                    assert sha(members[prefix + '-generated/' + item['path']]) == item['sha256']
                else:
                    assert source_map[item['path']] == item['sha256']
                if '/' + item['path'] in served:
                    expected = mutation['servedSha256'] if mutation and item['path'] == mutation['path'] else item['sha256']
                    assert served['/' + item['path']]['sha256'] == expected
            coverage = json.loads(members[prefix + '/' + name + '/' + report['browserCoverage']['path']])
            assert sha(members[prefix + '/' + name + '/' + report['browserCoverage']['path']]) == report['browserCoverage']['sha256']
            for item in coverage['scripts']:
                assert item['sha256'] == served['/' + item['source']]['sha256']
            assert sha(members[prefix + '/' + name + '/' + report['screenshot']['path']]) == report['screenshot']['sha256']
            reports.append({'record': prefix + '/' + name, 'sha256': sha(members[prefix + '/' + name + '/report.json']), 'status': report['status'], 'gpu': report['browser']['gpu']['devices']})
    with tarfile.open(fileobj=io.BytesIO(git('archive', HEAD, *sorted(source_map))), mode='r:') as tar:
        blobs = {member.name: tar.extractfile(member).read() for member in tar if member.isfile()}
    assert set(blobs) == set(source_map)
    for name, digest in source_map.items():
        assert sha(blobs[name]) == digest, name
        assert sha((ROOT / name).read_bytes()) == digest, name
    cold = json.loads(members['cold/report.json'])
    assert sha(members['cold/report.json']) == manifest['coldReportSha256']
    assert cold['gitHead'] == cold['cloneHead'] == HEAD and cold['status'] == 'passed'
    assert cold['statusBefore'] == cold['statusAfter'] == '' and cold['exitCode'] == 0
    assert cold['command'] == ['make', 'verify-E6-T11d3']
    assert cold['receiptSha256'] == sha(members['cold/receipt.json'])
    assert cold['logSha256'] == sha(members['cold/cold.log'])
    assert 'RUST_LOG' in cold['removedEnvironmentNames']
    clone = Path(cold['clone'])
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clone).decode().strip() == HEAD
    assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=clone)
    carry = sorted(name for name in source_map if name.startswith('renderer/virgl-shader/') or name in [
        'renderer/virgl-command/resources.mjs', 'renderer/virgl-command/cache.mjs', 'renderer/virgl-command/constant-domain.mjs',
        'renderer/virgl-command/tests/blend-equations.mjs', 'renderer/virgl-command/tests/blend-boundaries.mjs'])
    assert not git('diff', PARENT, HEAD, '--', *carry)
    log_facts = {}
    for name in ['hot/acceptance.log', 'cold/acceptance.log', 'cold/cold.log']:
        log = members[name].decode(errors='replace')
        assert 'make verify-E6-T12h' in log and 'Authenticated 57 physical vertex frames' in log
        assert not any(marker in log for marker in ['AddressSanitizer:ERROR', 'ERROR: AddressSanitizer', 'runtime error:', 'panicked at', 'ERROR: scalar escaped', 'ERROR: rgba escaped', 'ERROR: perspective escaped'])
        log_facts[name] = sha(members[name])
    result = {'schema': 1, 'task': 'E6-T11d3', 'status': 'HELD', 'predictions': ['P1', 'P11'], 'sourceHead': HEAD,
        'archiveSha256': ARCHIVE, 'indexSha256': INDEX, 'records': len(members), 'frozenSources': len(source_map),
        'reports': reports, 'coldClone': str(clone), 'carryUnchangedSources': carry, 'logDigests': log_facts}
    (HERE / 'authentication.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'records': len(members), 'sources': len(source_map), 'unchangedCarriedSources': len(carry), 'cold': 'passed/pristine/exact-head'}))


if __name__ == '__main__':
    main()
