#!/usr/bin/env python3
"""Re-derive fresh varying-W pixels with general triangle cross products."""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import struct
import subprocess
from recording_audit import cmds, quantize

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
HEAD = '2ba17ed3d5373eea3991225c8cd8160920928499'
WIDTHS = {28:4,29:8,30:12,31:16}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def cross(a,b):
    return a[0]*b[1]-a[1]*b[0]


def subtract(a,b):
    return [a[0]-b[0],a[1]-b[1]]


def barycentric(point, triangle):
    a,b,c = triangle
    denominator = cross(subtract(b,a),subtract(c,a))
    assert denominator != 0
    second = cross(subtract(point,a),subtract(c,a))/denominator
    third = cross(subtract(b,a),subtract(point,a))/denominator
    return [1-second-third,second,third]


def state(frame):
    objects, buffers, shaders, active = {}, [], {}, {}
    bound = index = draw = viewport = None
    for submission in frame['history']:
        if submission['contextId'] != frame['contextId']:
            continue
        commands = cmds(submission['packetHex'])
        if frame['delay'] and submission['result']['ok']:
            assert submission['result']['gpuComplete'] is True
        count = len(commands) if submission['result']['ok'] else submission['result'].get('appliedCommands',0)
        assert 0 <= count <= len(commands)
        if not submission['result']['ok']:
            failure = submission['result']['error']
            assert [failure['opcode'],failure['byteOffset']] == [commands[count][0],commands[count][4]]
        for op, kind, words, raw, at in commands[:count]:
            if op == 1 and kind == 5:
                objects[words[0]] = [words[i:i+4] for i in range(1,len(words),4)]
            elif op == 2 and kind == 5:
                bound = words[0]
            elif op == 6:
                buffers = [words[i:i+3] for i in range(0,len(words),3)]
            elif op == 11:
                index = words
            elif op == 4:
                viewport = [F(struct.unpack('<f',struct.pack('<I',word))[0]) for word in words[1:]]
            elif op == 8:
                draw = words
            elif op == 31:
                active[words[1]] = words[0]
            elif op == 1 and kind == 4:
                assert raw[24+words[2]-1] == 0
                shaders[words[0]] = raw[24:24+words[2]-1].decode('ascii')
    assert objects[bound][0][3] == 31 and objects[bound][1][3] == frame['format']
    assert objects[bound][2] == [0,0,15,31]
    assert viewport == [8,8,F(1,2),8,8,F(1,2)]
    assert draw[1:3] == [4,5] and draw[4:10] == [1,0,0,0,0,0]
    assert draw[10] == 0
    assert '0: MOV OUT[0], IN[0]\n1: MOV OUT[1], IN[1]' in shaders[active[0]]
    coordinates = '0: MOV OUT[0], IN[0].wwww' in shaders[active[1]]
    assert coordinates == frame['coordinates']
    native, dump = frame['native'], frame['dump']
    assert dump['complete'] and len(dump['draws']) == 1 and all(v==0 for v in dump['dropped'].values())
    capture = dump['draws'][0]
    program = next(p for p in dump['programs'] if p['generation'] == capture['programGeneration'])
    assert program['vertexTGSI'] == shaders[active[0]] and program['fragmentTGSI'] == shaders[active[1]]
    state_key = json.loads(capture['stateKey'])
    assert [[e[k] for k in ['sourceOffset','instanceDivisor','vertexBufferIndex','sourceFormat']] for e in state_key['vertexElements']['elements']] == objects[bound]
    if draw[3]:
        assert index[1:] == [2,2]
        indices = list(struct.unpack_from('<4H',bytes.fromhex(native['index']['bufferHex']),index[2]))
        assert native['index']['resourceId'] == index[0]
        assert [native['op'],native['args']] == ['drawElements',[5,4,5123,2]]
    else:
        indices = list(range(draw[0],draw[0]+4))
        assert [native['op'],native['args']] == ['drawArrays',[5,draw[0],4]]
    assert indices == list(range(frame['start'],frame['start']+4))
    command = capture['command']
    assert [command['actualMinIndex'],command['actualMaxIndex']] == [min(indices),max(indices)]
    assert command['contextId'] == frame['contextId']
    values, extents = {}, []
    for attr in native['attributes']:
        number = int(attr['name'].split('_')[-1])
        source_offset, divisor, slot, fmt = objects[bound][number]
        stride, buffer_offset, resource = buffers[slot]
        assert divisor == 0 and fmt in WIDTHS
        width = WIDTHS[fmt]
        offset = source_offset+buffer_offset
        assert stride > 0 and stride <= 252 and all(n%4==0 for n in [stride,offset,source_offset,buffer_offset])
        data = bytes.fromhex(attr['bufferHex'])
        assert len(data) == attr['byteLength'] and resource == attr['resourceId']
        values[number] = []
        for vertex in indices:
            begin = offset+vertex*stride
            assert begin+width <= len(data)
            read = [F(v) for v in struct.unpack_from('<'+'f'*(width//4),data,begin)]
            values[number].append(read+[F(0),F(0),F(0),F(1)][width//4:])
        binding = state_key['vertexBuffers'][slot]
        assert binding['generation'] == attr['generation'] and binding['metadata']['byteLength'] == len(data)
        assert [binding['fields'][k] for k in ['stride','offset','resourceHandle']] == buffers[slot]
        fetch = next(f for f in command['vertexFetches'] if f['attributeIndex']==number)
        extent = {'attribute':number,'format':fmt,'width':width,'firstByte':offset+min(indices)*stride,'requiredEnd':offset+max(indices)*stride+width,'resourceId':resource,'generation':attr['generation'],'storageBytes':len(data)}
        assert [fetch[k] for k in ['components','firstByte','requiredEnd','resourceId','resourceGeneration']] == [width//4,extent['firstByte'],extent['requiredEnd'],resource,attr['generation']]
        extent['nativeComponents'] = attr['components']
        extents.append(extent)
    positions = values[0]
    assert [[p[0]/p[3],p[1]/p[3]] for p in positions] == [[F(-3,4),F(-3,4)],[F(-3,4),F(3,4)],[F(3,4),F(-3,4)],[F(3,4),F(3,4)]]
    assert [p[3] for p in positions] == [1,2,4,8] and all(p[2]==0 for p in positions)
    if 1 in values:
        for vertex,value in enumerate(values[1]):
            assert value[:WIDTHS[frame['format']]//4] == [F(v) for v in frame['colors'][vertex][:WIDTHS[frame['format']]//4]]
    return positions,values.get(1),coordinates,extents


def expected_pixels(positions, colors, coordinates):
    projected = [[p[0]/p[3],p[1]/p[3]] for p in positions]
    expected = []
    for y in range(16):
        for x in range(16):
            point = [F(2*x+1,16)-1,F(2*y+1,16)-1]
            selected = None
            for indices in [[0,1,2],[2,1,3]]:
                weights = barycentric(point,[projected[i] for i in indices])
                if all(w>=0 for w in weights):
                    selected = indices,weights
                    break
            if selected is None:
                expected += [0,0,0,0]
                continue
            indices,weights = selected
            reciprocal = sum(weights[j]/positions[i][3] for j,i in enumerate(indices))
            if coordinates:
                color = [reciprocal]*4
            else:
                color = [sum(weights[j]*colors[i][lane]/positions[i][3] for j,i in enumerate(indices))/reciprocal for lane in range(4)]
            expected += [quantize(v) for v in color]
    return expected


def audit(directory, fault=False):
    base = HERE/directory
    report_bytes = (base/'report.json').read_bytes()
    report = json.loads(report_bytes)
    assert report['status'] == ('failed' if fault else 'passed')
    assert report['sourceHead'] == HEAD and report['browserErrors']=={'console':[],'page':[],'requests':[]}
    assert not report['browser']['headless']
    served = {r['path']:r['sha256'] for r in report['servedFiles']}
    mutation = report.get('mutation')
    for source in report['sources']:
        original = (ROOT/source['path']).read_bytes()
        assert sha(original) == source['sha256']
        if '/build/' not in source['path'] and not source['path'].endswith('float-vertex-boundaries.mjs'):
            assert sha(subprocess.check_output(['git','show',HEAD+':'+source['path']],cwd=ROOT)) == source['sha256']
        if '/'+source['path'] in served:
            target = mutation['servedSha256'] if mutation and mutation['path']==source['path'] else source['sha256']
            assert served['/'+source['path']] == target
    if fault:
        original = (ROOT/mutation['path']).read_bytes()
        changed = (base/'mutation-source.mjs').read_bytes()
        assert sha(original)==mutation['originalSha256'] and sha(changed)==mutation['servedSha256']
        assert original.count(mutation['needle'].encode())==1 and original.replace(mutation['needle'].encode(),mutation['replacement'].encode())==changed
    result = report['partial'] if fault else report['browserResult']['result']
    raw = (base/'pixels.bin').read_bytes()
    assert sha(raw)==report['pixels']['sha256'] and len(raw)==len(result['frames'])*1024
    if not fault:
        assert len(result['frames'])==96 and len(result['rejections'])==144
        assert all(row['held'] for row in result['assertions'])
        for rejection in result['rejections']:
            assert not rejection['result']['ok'] and not rejection['dump']['draws']
        assert sorted(set(job['delay'] for job in result['jobs']))==[0,2,5]
        assert all(job['waits']>0 and job['fences']>0 for job in result['jobs'] if job['delay'])
    rows,failed = [],[]
    for number,frame in enumerate(result['frames']):
        positions,colors,coordinates,extents = state(frame)
        expected = expected_pixels(positions,colors,coordinates)
        observed = list(raw[number*1024:(number+1)*1024])
        mismatches = [{'pixel':[at//4%16,at//4//16],'lane':at%4,'expected':a,'observed':b} for at,(a,b) in enumerate(zip(expected,observed)) if abs(a-b)>1]
        if mismatches:
            failed.append(frame['name'])
        if not fault:
            assert all(e['nativeComponents']==e['width']//4 for e in extents)
        source_line = next(i+1 for i,line in enumerate(report_bytes.decode().splitlines()) if line.strip()=='"name": '+json.dumps(frame['name'])+',')
        rows.append({'name':frame['name'],'status':'FAILED-AS-PREDICTED' if mismatches else 'HELD','record':str((base/'report.json').relative_to(ROOT)),'recordLine':source_line,
            'recordSha256':sha(report_bytes),'rawSha256':sha(raw),'rawOffset':number*1024,'extents':extents,'pixel8x8':observed[(8*16+8)*4:(8*16+8)*4+4],
            'predicted8x8':expected[(8*16+8)*4:(8*16+8)*4+4],'mismatches':mismatches[:4]})
    target = 'seed1831565813-format31 perspective'
    assert failed == ([target] if fault else [])
    if fault:
        assert target+' critic varying-W physical pixels' in report['browserResult']['error']['message']
        assert all(m['lane']==3 and m['observed']==255 for m in rows[-1]['mismatches'])
        color = next(e for e in rows[-1]['extents'] if e['attribute']==1)
        assert color['format']==31 and color['nativeComponents']==3 and color['width']==16
    audit_path = HERE/(directory+'-audit.jsonl')
    audit_path.write_text(''.join(json.dumps(row)+'\n' for row in rows))
    return {'status':'HELD','frames':len(rows),'pixels':len(rows)*256,'rejections':len(result['rejections']),'failedAsPredicted':failed,
        'auditPath':str(audit_path.relative_to(ROOT)),'auditSha256':sha(audit_path.read_bytes()),'reportSha256':sha(report_bytes),'rawSha256':sha(raw)}


def main():
    wire = json.loads((HERE/'fresh-wire/report.json').read_text())
    assert wire['status']=='passed' and all(row['held'] for row in wire['wire']['assertions']) and len(wire['wire']['assertions'])==3132
    report = {'schema':1,'task':'E6-T11d3','status':'HELD','prediction':'P12','sourceHead':HEAD,
        'wirePredicates':3132,'hardware':audit('fresh-hardware'),'sabotage':audit('sabotage-promoted',True),
        'harnessCorrection':'Async beginSubmission rejects malformed packets before allocating a job; the critic records that returned rejection directly. No runtime change or product refutation.'}
    (HERE/'fresh-audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))


if __name__=='__main__':
    main()
