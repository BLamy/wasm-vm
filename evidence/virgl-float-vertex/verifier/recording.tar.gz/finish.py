#!/usr/bin/env python3
"""Save the critic verdict and a self-contained deterministic evidence seal."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
HEAD = '2ba17ed3d5373eea3991225c8cd8160920928499'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(name):
    return sha((HERE/name).read_bytes())


def main():
    assert not subprocess.check_output(['git','diff',HEAD,'--','renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs'],cwd=ROOT)
    predictions = json.loads((HERE/'predictions.json').read_text())
    assert predictions['madeBeforeEvidenceInspection']
    for name in ['authentication.json','recording-audit.json','fresh-audit.json','carry-forward.json']:
        assert json.loads((HERE/name).read_text())['status']=='HELD'
    entries = [
        ('P1','196 seal members,382 exact-head sources,generated modules,served scripts and pristine final cold clone authenticate.','authentication.json'),
        ('P2','Fresh native and ASan/UBSan pinned C enum/layout oracles match widths4/8/12/16; admitted formats are exactly28..31.','enum-audit.json'),
        ('P3','Aligned u32 last offsets,remainders,overflows,divisors and slot bounds hold,including3132 fresh seeded wire predicates.','fresh-wire/report.json'),
        ('P4','Every scalar/RG/RGB recorded pixel derives from actual GPU bytes and independent missing lanes; no padding leakage.','hot-hardware-audit.jsonl'),
        ('P5','Fourth color alpha64 and clip reciprocal W128/64/32 agree at pixel8,8 and every recorded pixel.','hot-hardware-audit.jsonl'),
        ('P6','First and actual-last fetch bounds,offsets,252/overlapping strides,actual u16 maxima,exact ends and short rejection/recovery hold.','recording-audit.json'),
        ('P7','Inactive slot15,A/B/A,public unref/ID reuse,old-generation retention,rebind and current transfer match native bytes and pixels.','fresh-hardware-audit.jsonl'),
        ('P8','Owned async input,real read/completion fences and varied delays0/1/3 plus fresh0/2/5 hold; short cases issue no draw.','fresh-audit.json'),
        ('P9','All three sealed physical source-size faults contradict their named pixel predictions,without unrelated failures.','recording-audit.json'),
        ('P10','Every changed runtime predicate/lane expression and all its extent/native-pointer consumers execute; zero runtime waivers.','recording-audit.json'),
        ('P11','257 unchanged compiler/private/cache sources and parent D2 HELD results carry; current H/nine original draws and promoted22 blend frames authenticate.','carry-forward.json'),
        ('P12','96 fresh varying-W/partial-color frames,24576 independently derived pixels and144 rejections hold; real RGBA-size3 sabotage produces alpha255 instead of203 at2,2.','fresh-audit.json')]
    verdict = {'schema':1,'task':'E6-T11d3','verdict':'verified','sourceHead':HEAD,'submissionHead':'aaaf3565',
        'verifiedParent':'bcdb820620092aaf869aa0574ffce6de793dd5fe',
        'predictions':[{'id':identifier,'status':'HELD','result':message,'citation':name,'sha256':digest(name)} for identifier,message,name in entries],
        'runtimeChanged':False,'runtimeWaivers':[],
        'scope':'Isolated per-vertex float-fetch boundary. Production negotiation,guest execution,complete API and performance are not certified.',
        'promotedTest':'renderer/virgl-command/tests/float-vertex-boundaries.mjs',
        'commands':[
            'python3 evidence/virgl-float-vertex/verifier/authenticate.py',
            'clang -std=gnu11 -Wall -Wextra -Werror -Irenderer/virgl-shader/vendor/src tools/virgl-command/float-vertex-enums.c -o evidence/virgl-float-vertex/verifier/abi/native; native execution',
            'Same pinned C oracle compiled/executed with -fsanitize=address,undefined -fno-omit-frame-pointer; commands and outputs in enum-audit.json',
            'python3 evidence/virgl-float-vertex/verifier/recording_audit.py',
            'node --check renderer/virgl-command/tests/float-vertex-boundaries.mjs',
            'node renderer/virgl-command/tests/float-vertex-boundaries.mjs --output evidence/virgl-float-vertex/verifier/fresh-wire --node-only true',
            'node renderer/virgl-command/tests/float-vertex-boundaries.mjs --output evidence/virgl-float-vertex/verifier/fresh-hardware',
            'node renderer/virgl-command/tests/float-vertex-boundaries.mjs --output evidence/virgl-float-vertex/verifier/sabotage-promoted --mutation rgba (expected exit1 at the named physical pixel)',
            'python3 evidence/virgl-float-vertex/verifier/fresh_audit.py',
            'python3 evidence/virgl-float-vertex/verifier/carry_forward.py']}
    (HERE/'verdict.json').write_text(json.dumps(verdict,indent=2)+'\n')
    members = {}
    for file in sorted(HERE.rglob('*')):
        if not file.is_file() or '__pycache__' in file.parts:
            continue
        relative = file.relative_to(HERE).as_posix()
        if relative in ['manifest.json','records.json','recording.tar.gz']:
            continue
        members[relative] = file.read_bytes()
    promoted = ROOT/verdict['promotedTest']
    members['promoted/float-vertex-boundaries.mjs'] = promoted.read_bytes()
    index = {'schema':'virgl-float-vertex-critic-records-v1','task':'E6-T11d3','sourceHead':HEAD,
        'records':[{'path':name,'bytes':len(raw),'sha256':sha(raw)} for name,raw in sorted(members.items())]}
    encoded = (json.dumps(index,indent=2)+'\n').encode()
    (HERE/'records.json').write_bytes(encoded)
    archive = io.BytesIO()
    with gzip.GzipFile(fileobj=archive,mode='wb',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for name,raw in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size,info.mtime,info.mode = len(raw),0,0o644
                tar.addfile(info,io.BytesIO(raw))
    packed = archive.getvalue()
    (HERE/'recording.tar.gz').write_bytes(packed)
    manifest = {'schema':'virgl-float-vertex-critic-seal-v1','task':'E6-T11d3','verdict':'verified','sourceHead':HEAD,
        'submissionHead':'aaaf3565','verifiedParent':verdict['verifiedParent'],'archive':'recording.tar.gz','recordIndex':'records.json',
        'records':len(members),'archiveBytes':len(packed),'archiveSha256':sha(packed),'recordIndexSha256':sha(encoded),
        'workerArchiveSha256':'b435606f2147094639d1bdf9018c3ef9c2a3ad0aa9dd7ef3a9661fd2fde34395',
        'workerIndexSha256':'f70fe5fc912d7523c4e624bcb25fb245a99ceb2d027957f2c3aac03da79f49c4',
        'verdictSha256':sha((HERE/'verdict.json').read_bytes()),'predictionsSha256':digest('predictions.json'),
        'promotedTest':verdict['promotedTest'],'promotedTestSha256':sha(promoted.read_bytes()),
        'allMembersReopenedAndAuthenticated':True,'runtimeChanged':False,'executedChangedRuntimeLines':4,
        'freshPhysicalFrames':96,'freshPixels':24576,'freshWirePredicates':3132,'freshRejectedSubmissions':144,
        'scope':verdict['scope']}
    # Authenticate our own seal before calling it complete.
    with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as tar:
        recovered = {entry.name:tar.extractfile(entry).read() for entry in tar if entry.isfile()}
    assert recovered==members and len(recovered)==manifest['records']
    (HERE/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(manifest))


if __name__=='__main__':
    main()
