#!/usr/bin/env python3
"""Carry established HELD boundaries and authenticate affected current runs."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    out = {}
    for prefix in ['hot','cold']:
        out[prefix] = {}
        for name in ['regression/hardware','regression/regression/regression/draw','promoted-blend']:
            raw = (HERE/'unpacked'/prefix/name/'report.json').read_bytes()
            report = json.loads(raw)
            result = report['browserResult']['result']
            assert report['status']=='passed' and report['browserErrors']=={'console':[],'page':[],'requests':[]}
            predicates = result.get('assertions',[])
            if isinstance(predicates,list):
                assert all(row['held'] for row in predicates)
            facts = {'task':report['task'],'reportSha256':sha(raw),'assertions':len(predicates) if isinstance(predicates,list) else predicates}
            if name=='regression/hardware':
                facts['originalDraws'] = [(x['workload'],len(x['calls'])) for x in result['originals']]
                assert facts['originalDraws']==[('kmscube',6),('es2gears',3)]
                assert all(x['held'] for x in report['native']['assertions'])
                facts['nativeAssertions'] = len(report['native']['assertions'])
            if name.endswith('/draw'):
                assert result['primaryDrawReplay'] is True and result['status']=='passed'
            if name=='promoted-blend':
                assert result['frames']==22
                facts['frames'] = result['frames']
                pixels = (HERE/'unpacked'/prefix/name/'blend-pixels.bin').read_bytes()
                assert sha(pixels)==report['physicalPixels']['sha256']==result['rawSha256']
                facts['rawSha256'] = sha(pixels)
            out[prefix][name] = facts
    old = ROOT/'evidence/virgl-blend/verifier'
    manifest = json.loads((old/'manifest.json').read_text())
    assert manifest['verdict']=='verified'
    assert sha((old/'recording.tar.gz').read_bytes())==manifest['archiveSha256']
    assert sha((old/'records.json').read_bytes())==manifest['recordIndexSha256']
    out['D2'] = {'verifiedParent':'bcdb820620092aaf869aa0574ffce6de793dd5fe','manifest':manifest,
        'instruction':'Carry HELD compiler/private/cache/blend results unchanged; no whole compiler suite or cache stress wall restarted.'}
    out['unchangedSourcesCitation'] = 'authentication.json carryUnchangedSources'
    out['status'] = 'HELD'
    (HERE/'carry-forward.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ['D2']}))


if __name__=='__main__':
    main()
