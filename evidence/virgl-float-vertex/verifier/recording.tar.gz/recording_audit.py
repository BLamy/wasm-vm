#!/usr/bin/env python3
"""Independently interpret original packets, actual GPU storage and V8 ranges."""
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import struct

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
WIDTHS = {28: 4, 29: 8, 30: 12, 31: 16}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def cmds(encoded):
    raw = bytes.fromhex(encoded)
    at = 0
    rows = []
    while at < len(raw):
        header = int.from_bytes(raw[at:at+4], 'little')
        n, kind, op = header >> 16, header >> 8 & 255, header & 255
        end = at + 4 + n * 4
        assert end <= len(raw)
        rows.append((op, kind, list(struct.unpack('<' + 'I'*n, raw[at+4:end])), raw[at:end], at))
        at = end
    assert at == len(raw)
    return rows


def quantize(value):
    q = max(Fraction(0), min(Fraction(1), value)) * 255
    return int(q + Fraction(1, 2))


def interpret(row):
    objects, buffers, bound, index, shaders, active, draw = {}, [], None, None, {}, {}, None
    for submission in row['history']:
        if submission['contextId'] != row['contextId']:
            continue
        commands = cmds(submission['packetHex'])
        count = len(commands) if submission['result']['ok'] else submission['result']['appliedCommands']
        assert 0 <= count <= len(commands)
        if not submission['result']['ok']:
            error = submission['result']['error']
            assert [error['opcode'], error['byteOffset']] == [commands[count][0], commands[count][4]]
        for op, kind, words, raw, at in commands[:count]:
            if op == 1 and kind == 5:
                assert (len(words)-1) % 4 == 0
                objects[words[0]] = [words[i:i+4] for i in range(1, len(words), 4)]
            if op == 2 and kind == 5:
                bound = words[0]
            if op == 6:
                buffers = [words[i:i+3] for i in range(0, len(words), 3)]
            if op == 11:
                index = words
            if op == 1 and kind == 4:
                assert raw[24 + words[2] - 1] == 0
                shaders[words[0]] = raw[24:24+words[2]-1].decode('ascii')
            if op == 31:
                active[words[1]] = words[0]
            if op == 8:
                draw = words
    assert draw and bound in objects and draw[1:3] == [4, 5]
    native = row['native']
    if draw[3]:
        assert index[1:] == [2, 2] and draw[0] == 0
        assert native['index']['resourceId'] == index[0]
        selected = list(struct.unpack_from('<4H', bytes.fromhex(native['index']['bufferHex']), index[2]))
        assert 65535 not in selected
        assert [native['op'], native['args']] == ['drawElements', [5, 4, 5123, 2]]
    else:
        selected = list(range(draw[0], draw[0]+4))
        assert [native['op'], native['args']] == ['drawArrays', [5, draw[0], 4]]
    assert row['dump']['complete'] and len(row['dump']['draws']) == 1
    assert all(value == 0 for value in row['dump']['dropped'].values())
    capture = row['dump']['draws'][0]
    command = capture['command']
    assert [command['actualMinIndex'], command['actualMaxIndex']] == [min(selected), max(selected)]
    assert command['contextId'] == row['contextId'] and command['count'] == draw[1]
    program = next(p for p in row['dump']['programs'] if p['generation'] == capture['programGeneration'])
    assert program['vertexTGSI'] == shaders[active[0]] and program['fragmentTGSI'] == shaders[active[1]]
    assert '0: MOV OUT[0], IN[0]\n1: MOV OUT[1], IN[1]' in shaders[active[0]]
    coordinates = '0: MOV OUT[0], IN[0].wwww' in shaders[active[1]]
    assert coordinates or '0: MOV OUT[0], IN[0]\n1: END' in shaders[active[1]]
    state = json.loads(capture['stateKey'])
    elements = objects[bound]
    assert [[e[k] for k in ['sourceOffset', 'instanceDivisor', 'vertexBufferIndex', 'sourceFormat']]
            for e in state['vertexElements']['elements']] == elements
    lanes, extents = {}, []
    for attr in native['attributes']:
        number = int(attr['name'].split('_')[-1])
        source_offset, divisor, slot, fmt = elements[number]
        stride, buffer_offset, resource = buffers[slot]
        assert divisor == 0 and fmt in WIDTHS and stride > 0 and stride <= 252
        assert all(value % 4 == 0 for value in [stride, buffer_offset, source_offset])
        offset = source_offset + buffer_offset
        width = WIDTHS[fmt]
        data = bytes.fromhex(attr['bufferHex'])
        assert len(data) == attr['byteLength'] and resource == attr['resourceId']
        values = []
        for vertex in selected:
            begin = offset + stride * vertex
            assert begin + width <= len(data)
            v = [Fraction(f) for f in struct.unpack_from('<'+'f'*(width//4), data, begin)]
            values.append(v + [Fraction(0), Fraction(0), Fraction(0), Fraction(1)][width//4:])
        lanes[number] = values
        extents.append({'attribute': number, 'format': fmt, 'width': width, 'stride': stride, 'offset': offset,
                        'firstByte': offset+stride*min(selected), 'requiredEnd': offset+stride*max(selected)+width,
                        'storageBytes': len(data), 'resourceId': resource, 'generation': attr['generation']})
        binding = state['vertexBuffers'][slot]
        assert binding['generation'] == attr['generation'] and binding['metadata']['byteLength'] == len(data)
        assert [binding['fields'][key] for key in ['stride', 'offset', 'resourceHandle']] == buffers[slot]
        reflection = next(a for a in program['reflection']['attributes'] if a['index'] == number)
        assert reflection['location'] == attr['location'] and reflection['name'] == attr['name']
    position = lanes[0]
    assert [[v[0]/v[3], v[1]/v[3]] for v in position] == [[-1,-1],[-1,1],[1,-1],[1,1]]
    assert all(v[3] == position[0][3] and v[3] > 0 and v[2] == 0 for v in position)
    if coordinates:
        color = [1/position[0][3]] * 4
    else:
        assert all(value == lanes[1][0] for value in lanes[1])
        color = lanes[1][0]
    return [quantize(c) for c in color], extents, command


def audit_physical(prefix, name, fault=False):
    base = HERE/'unpacked'/prefix/name
    source = (base/'report.json').read_bytes()
    report = json.loads(source)
    result = report['partial'] if fault else report['browserResult']['result']
    frames = result['frames'] if fault else result['records']
    raw = (base/('fault-pixels.bin' if fault else 'vertex-pixels.bin')).read_bytes()
    assert len(raw) == len(frames)*1024
    lines, failed = [], []
    width_counts = Counter()
    report_lines = source.decode().splitlines()
    for number, row in enumerate(frames):
        expected, extents, command = interpret(row)
        assert row['expected'] == expected
        pixel_data = raw[number*1024:(number+1)*1024]
        mismatches = []
        for at in range(256):
            actual = list(pixel_data[at*4:at*4+4])
            if any(abs(a-e)>1 for a,e in zip(actual, expected)):
                mismatches.append({'pixel': at, 'expected': expected, 'observed': actual})
        if mismatches:
            failed.append(row['name'])
        for extent in extents:
            width_counts[extent['width']] += 1
            if not fault:
                attr = next(a for a in row['native']['attributes'] if a['name'] == 'in_'+str(extent['attribute']))
                assert [attr['components'],attr['enabled'],attr['type'],attr['stride'],attr['offset'],attr['defaults']] == [extent['width']//4,True,5126,extent['stride'],extent['offset'],[0,0,0,1]]
                captured = next(f for f in command['vertexFetches'] if f['attributeIndex'] == extent['attribute'])
                assert [captured[key] for key in ['resourceId','resourceGeneration','components','stride','offset','firstByte','requiredEnd']] == [
                    extent['resourceId'],extent['generation'],extent['width']//4,extent['stride'],extent['offset'],extent['firstByte'],extent['requiredEnd']]
        reference_line = next(i+1 for i,line in enumerate(report_lines) if line.strip() == '"name": '+json.dumps(row['name'])+',')
        lines.append({'name': row['name'], 'record': base.relative_to(ROOT).as_posix()+'/report.json', 'recordLine': reference_line,
            'recordSha256': sha(source), 'rawSha256': sha(raw), 'rawOffset': number*1024, 'pixelsChecked': 256,
            'pixel8x8': list(pixel_data[(8*16+8)*4:(8*16+8)*4+4]), 'predicted': expected,
            'extents': extents, 'status': 'FAILED-AS-PREDICTED' if mismatches else 'HELD', 'mismatches': mismatches[:2]})
    faults = {'fault-scalar': 'scalar-format28', 'fault-rgba': 'rgba-format31', 'fault-perspective': 'clip-w2'}
    assert failed == ([faults[name]] if fault else [])
    if fault:
        assert faults[name]+' independent physical pixels' in report['browserResult']['error']['message']
    else:
        assert len(frames) == 57 and len(result['assertions']) == 4128 and all(row['held'] for row in result['assertions'])
        assert len(result['rejections']) == 23
        for r in result['rejections']:
            assert not r['result']['ok'] and r['result']['draws'] == [] and r['dump']['draws'] == []
            decoded = cmds(r['packetHex'])
            assert [r['result']['error']['opcode'],r['result']['error']['byteOffset']] == [decoded[r['result']['appliedCommands']][0],decoded[r['result']['appliedCommands']][4]]
        generations = {r['name']: next(a for a in r['native']['attributes'] if a['name']=='in_1')['generation'] for r in frames if r['name'] in ['restore-1-44','restore-1-46','bound-old-generation','rebind-new-generation','transfer-current-generation']}
        assert generations['restore-1-44'] == generations['restore-1-46'] == generations['bound-old-generation']
        assert generations['rebind-new-generation'] == generations['transfer-current-generation'] != generations['bound-old-generation']
        jobs = result['jobs']
        assert [j['delay'] for j in jobs] == [0,1,3] and all(j['gpuComplete'] and j['fences']==3 for j in jobs)
        assert jobs[0]['waits'] < jobs[1]['waits'] < jobs[2]['waits'] and jobs[0]['polls'] < jobs[1]['polls'] < jobs[2]['polls']
    output = HERE/(prefix+'-'+name+'-audit.jsonl')
    output.write_text(''.join(json.dumps(row)+'\n' for row in lines))
    return {'record': str(output.relative_to(ROOT)), 'sha256': sha(output.read_bytes()), 'frames': len(frames), 'pixels': len(frames)*256, 'failures': failed, 'widthCounts': dict(width_counts)}


def audit_coverage(prefix):
    base = HERE/'unpacked'/prefix/'hardware'
    coverage = json.loads((base/'browser-coverage.json').read_text())
    rows = []
    targets = {'renderer/virgl-command/decoder.mjs': [246,247,248], 'renderer/virgl-command/state.mjs': [18,594,710,852,859]}
    for item in coverage['scripts']:
        if item['source'] not in targets:
            continue
        raw = (ROOT/item['source']).read_bytes()
        assert sha(raw) == item['sha256']
        text = raw.decode()
        for number in targets[item['source']]:
            start = sum(len(line)+1 for line in text.splitlines()[:number-1])
            line = text.splitlines()[number-1]
            position = start + len(line)-len(line.lstrip())
            if item['source'] == 'renderer/virgl-command/state.mjs' and number == 18:
                position = start + line.index('element.sourceFormat')
            ranges = [r for f in item['coverage']['functions'] for r in f['ranges'] if r['startOffset'] <= position < r['endOffset']]
            precise = min(ranges, key=lambda r:r['endOffset']-r['startOffset'])
            assert precise['count'] > 0, (number, precise, line)
            rows.append({'source': item['source'], 'line': number, 'sha256': item['sha256'], 'text': line.strip(), 'range': precise, 'status': 'HELD'})
    assert len(rows) == 8
    return rows


def main():
    physical, coverage = {}, {}
    for prefix in ['hot','cold']:
        for mode in ['hardware','fault-scalar','fault-rgba','fault-perspective']:
            physical[prefix+'/'+mode] = audit_physical(prefix,mode,mode!='hardware')
        coverage[prefix] = audit_coverage(prefix)
        wire = json.loads((HERE/'unpacked'/prefix/'wire/report.json').read_text())['native']
        assert len(wire['assertions']) == 630 and all(r['held'] for r in wire['assertions'])
        assert wire['admitted']==4 and wire['rejected']==252
        for name in ['regression/hardware', 'regression/regression/regression/draw', 'promoted-blend']:
            report = json.loads((HERE/'unpacked'/prefix/name/'report.json').read_text())
            assert report['status']=='passed' and report['browserErrors']=={'console':[],'page':[],'requests':[]}
        for mode in ['native','sanitize']:
            assert json.loads((HERE/'unpacked'/prefix/'abi'/ (mode+'.json')).read_text()) == {
                'objectType':5,'formats':[28,29,30,31],'byteWidths':[4,8,12,16],'wordCounts':[5,65],'firstFields':[2,3,4,5]}
    result = {'schema':1,'task':'E6-T11d3','status':'HELD','predictions':['P2','P3','P4','P5','P6','P7','P8','P9','P10','P11'],
              'physical':physical,'changedRuntimeCoverage':coverage,'runtimeWaivers':[],
              'nonRuntimeWaivers': ['README prose and task/queue metadata cannot execute; direct scope inspected.',
                  'Make recipe and recording scripts are directly named in authenticated final hot/cold logs; evidence sealing is authenticated by all196 independently checked members.',
                  'Aligned acceptance/raster fixtures execute in final affected H and decoder runs; only the new contract/prediction changes.']}
    (HERE/'recording-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'HELD','physicalAudits':physical,'runtimeCoverage':coverage}))


if __name__=='__main__':
    main()
