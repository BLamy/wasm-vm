#!/usr/bin/env python3
import os, subprocess, sys
original = '/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm/target/evidence/virgl-known-arithmetic-critic-supplement/unpacked/hot/original/known-test'
run = subprocess.run([original], input=sys.stdin.buffer.read(), capture_output=True, env=os.environ)
assert run.returncode == 0 and not run.stderr
before, after = b'/* known:word */ raw_rhs.x = 1069547520u;', b'/* known:word */ raw_rhs.x = 1069547521u;'
assert run.stdout.count(before) > 0
sys.stdout.buffer.write(run.stdout.replace(before, after, 1))
sys.stderr.buffer.write(run.stderr)
