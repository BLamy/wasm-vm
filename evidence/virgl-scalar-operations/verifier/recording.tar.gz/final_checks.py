from pathlib import Path
import hashlib,json,os,subprocess
ROOT=Path(__file__).resolve().parents[3];p=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
report=json.loads((p/'gpu-2718281828/report.json').read_bytes())
allowed=['?? renderer/virgl-shader/tests/scalar-operation-regressions.mjs'];assert report['trackedChanges']==allowed
assert report['browserErrors']==dict(console=[],page=[],requests=[])
assert report['browser']['gpu']['featureStatus'][report['browser']['webglFeature']]=='enabled'
assert not any(e['path']=='renderer/virgl-shader/tests/scalar-operation-regressions.mjs'for e in report['servedFiles'])
assert not any(e['source']=='renderer/virgl-shader/tests/scalar-operation-regressions.mjs'for e in json.loads((p/'gpu-2718281828/browser-coverage.json').read_bytes())['scripts'])
head=report['gitHead'];diff=subprocess.check_output(['git','diff','--name-only','ad0bf026',head],cwd=ROOT,text=True).splitlines();assert not any(x.startswith(('renderer/','tools/','web/','crates/'))for x in diff)
for e in report['sources']:
 raw=(p/'gpu-critic-guard-snapshot.mjs').read_bytes()if e['path']=='renderer/virgl-shader/tests/scalar-operation-regressions.mjs'else(ROOT/e['path']).read_bytes();assert sha(raw)==e['sha256'],e['path']
profile=json.loads((p/'independent-regressions.json').read_bytes());assert profile['status']=='passed'and profile['cases']==len(profile['native'])==len(profile['wasm'])==1427
assert profile['testSha256']==sha((ROOT/'renderer/virgl-shader/tests/scalar-operation-regressions.mjs').read_bytes())
processes=[]
for line in subprocess.check_output(['ps','-axo','pid=,ppid=,args='],text=True).splitlines():
 words=line.strip().split(None,2)
 if len(words)<3:continue
 pid,ppid,args=words
 if int(pid)in [os.getpid(),os.getppid()]:continue
 if args.startswith('node tools/virgl-scalar-operations/browser.mjs')or('gpu-2718281828'in args and args.startswith(('node ','/Applications/Google Chrome'))):processes.append(line.strip())
cleanup={'schema':1,'matchingOwnedProcesses':processes,'physicalLiveObjects':report['acceptance']['objects']['live'],'stateBudgets':[c['finalBudgets']for c in report['acceptance']['consumers']],'drawBudgets':[c['finalBudgets']for c in report['acceptance']['bankDraws']]};assert not processes
(p/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
source={'schema':1,'scope':'finite inputs to the private TRUNC/SSG boundary','TGSI':{'path':'renderer/virgl-shader/tests/mesa-24.2.8-tgsi.rst','sha256':sha((ROOT/'renderer/virgl-shader/tests/mesa-24.2.8-tgsi.rst').read_bytes()),'SSGLine':673,'TRUNCLine':898},'GLSLES300':{'url':'https://registry.khronos.org/OpenGL/specs/es/3.0/GLSL_ES_Specification_3.00.pdf','section':'4.5.1 Range and Precision; common functions page94','independentlyRead':'Official Khronos source retrieved through web search; section4.5.1 expressly permits interchange of positive and negative zero and flushing of subnormals. Common trunc/sign definitions describe mathematical results.','ownedZeroAllowance':False,'ordinaryPrimaryZeroAllowance':'only sign bit of a mathematical zero'},'fourthSeed':{'sourceHead':head,'runtimeDiffSinceFreeze':diff,'sha256':sha((p/'gpu-2718281828/report.json').read_bytes()),'servedSourcesAuthenticated':True,'hardwareFeatureEnabled':True,'reportedChanges':allowed,'changeWaiver':'The only extra source is the fresh critic guard at its earlier1425case snapshot, untracked and never served/imported by this GPU run. That exact snapshot is preserved as gpu-critic-guard-snapshot.mjs and matches its inventoried SHA. Every served compiler/consumer/probe/wasm byte still matches the frozen source. The later two-case guard addition has its separate complete1427case native/Wasm proof.'},'scopeExclusions':['nonfinite scalar inputs','production caps/imports','complete captured compositor admission','guest boot','MIPS/FPS']}
(p/'source-semantics-policy.json').write_text(json.dumps(source,indent=2)+'\n')
commands=[['git','diff','--check'],['node','--check','renderer/virgl-shader/tests/scalar-operation-regressions.mjs']]
checks=[]
for cmd in commands:
 r=subprocess.run(cmd,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);assert r.returncode==0;checks.append({'command':cmd,'exitCode':r.returncode,'output':r.stdout})
for file in p.glob('*.py'):
 r=subprocess.run(['python3','-m','py_compile',str(file)],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);assert r.returncode==0
(p/'final-checks.json').write_text(json.dumps({'schema':1,'status':'passed','checks':checks,'pythonSyntax':'all verifier .py','promotedCases':1427,'testSha256':profile['testSha256'],'taskBoundaryFrozen':True,'fourthSeedSourceBinding':True,'ownedCleanup':True},indent=2)+'\n')
print('Final guard, fourth-seed source bindings, syntax and owned process cleanup passed.')
