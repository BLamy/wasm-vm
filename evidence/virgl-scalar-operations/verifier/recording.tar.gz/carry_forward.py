import hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;UNPACK=OUT/'unpacked'
def sha(b):return hashlib.sha256(b).hexdigest()
def check(v,m):
 if not v:raise AssertionError(m)
rows=[]
for name,source,count in [('independent-joins.json','compiler-bounds-joins.mjs',402),('independent-hex-guards.json','hex-literal-regressions.mjs',49),('independent-signed-guards.json','signed-integer-regressions.mjs',108),('independent-conversion-guards.json','signed-conversion-regressions.mjs',1575)]:
 path='renderer/virgl-shader/tests/'+source;raw=(ROOT/path).read_bytes();check(raw==subprocess.check_output(['git','show','58601f91:'+path],cwd=ROOT),'unchangedguard')
 for prefix in ['hot','cold/acceptance']:
  p=UNPACK/prefix/name;r=json.loads(p.read_bytes());check(r['status']=='passed'and type(r['cases'])is int and r['cases']==len(r['native'])==len(r['wasm'])==count,'fullguardarray')
  for a,b in zip(r['native'],r['wasm']):
   check(a['result']==b['result']or(a['result'].get('error',{}).get('code')==b['result'].get('error',{}).get('code')=='invalid-input'),'guardparity')
  if 'testSha256'in r:check(r['testSha256']==sha(raw),'guardtesthash')
  rows.append({'path':str(p.relative_to(OUT)),'sha256':sha(p.read_bytes()),'cases':count,'testPath':path,'testSha256':sha(raw),'unchangedSince':'58601f91','exactParity':True})
retained=[]
for prefix in ['hot','cold/acceptance']:
 p=UNPACK/prefix/'retained/report.json';r=json.loads(p.read_bytes());check(len(r['originals'])==25 and sum(x['native']['ok']for x in r['originals'])==23,'literalpartition')
 for x in r['originals']:
  raw=(ROOT/x['path']).read_bytes();check(sha(raw)==x['sha256']and len(raw)==x['bytes'],'actual originalsource');check(x['native']==x['wasm'],'originalparity')
  if x['sha256'].startswith('92cb866a'):check(x['native']['ok']is False,'largecapturedcompositorgated')
  else:check(x['native']==x['old'],'byteidenticaloriginalresult')
 check(len(r['historical'])==112 and sum(x['native']['ok']for x in r['historical'])==5,'historicalgrammar')
 retained.append({'path':str(p.relative_to(OUT)),'sha256':sha(p.read_bytes()),'originals':25,'admitted':23,'bodyHashes':[x['sha256']for x in r['originals']],'historical':112,'historicalAdmitted':5})
unchanged=['renderer/virgl-command/state.mjs','renderer/virgl-command/decoder.mjs','renderer/virgl-command/resources.mjs','renderer/virgl-shader/raw_binary32.h','renderer/virgl-shader/raw_conversions.h']
boundaries=[]
for path in unchanged:
 b=(ROOT/path).read_bytes();check(b==subprocess.check_output(['git','show','58601f91:'+path],cwd=ROOT),'unchangeddependency '+path);boundaries.append({'path':path,'sha256':sha(b)})
report={'schema':'virgl-scalar-operations-carry-forward-v1','status':'passed','base':'58601f91','heldVerifier':'evidence/virgl-signed-conversions/verifier/manifest.json','unchangedBoundaries':boundaries,'guards':rows,'retained':retained,'coldProof':'unpacked/cold/report.json','duplicateColdCloneRun':False,'guestExecution':False,'productionNegotiation':False,'rrWaiver':'AGENTS.md Evidence policy2026-09-01'}
(OUT/'carry-forward.json').write_text(json.dumps(report,indent=2)+'\n');print('All previous guard sources, full native/Wasm arrays and25literal originals carry forward.')
