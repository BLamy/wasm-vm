import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {parseConstantDomain,checkConversionBank,checkIndirectBank,checkRasterBank,checkRadialBank,checkLoopBank} from '../../../renderer/virgl-command/constant-domain.mjs';
const out=path.dirname(fileURLToPath(import.meta.url)),hash=b=>createHash('sha256').update(b).digest('hex');
const worker=JSON.parse(fs.readFileSync(path.join(out,'unpacked/hot/consumer.json'))),rows=[],banks=[],ownership=[];let getterCalls=0;
const deny=(name,m,stage)=>{const predicted=false,result=parseConstantDomain(m,stage);assert.equal(result.ok,predicted,name);assert.equal(result.error.code,'shader-domain-error',name);rows.push({name,predicted,observed:result});};
const unique=new Map();for(const c of worker.contracts)unique.set(JSON.stringify(c.metadata),c);
for(const c of unique.values()){
 const original=c.metadata,stage=original.stage,key=c.name;
 for(const [field,badValues]of [
  ['scalarBaseProfile',[null,undefined,true,31,{},[],'virgl-webgl2-raw-bits-v31','virgl-webgl2-raw-bits-v32','virgl-webgl2-straight-line-v5']],
  ...['kind','stage','domain','truncation','sign','result'].map(field=>[field,[null,undefined,true,31,{},[],'wrong']])])
  for(let i=0;i<badValues.length;i++){const m=structuredClone(original);if(field==='scalarBaseProfile')m[field]=badValues[i];else m.scalarWordContract[field]=badValues[i];deny(`${key}/type-${field}-${i}`,m,stage);}
 for(const [label,operations]of [['empty',[]],['duplicate',['SSG','SSG']],['reverse',['SSG','TRUNC']],['too-many',['TRUNC','SSG','SSG']],['integer',[0]],['object',[{}]],['boxed',[new String('TRUNC')]],['null',[null]],['nested',[['TRUNC']]],['sparse',Array(1)],['extra',Object.assign(['TRUNC'],{extra:1})]]){
  const m=structuredClone(original);m.scalarWordContract.operations=operations;deny(`${key}/operations-${label}`,m,stage);
 }
 for(const field of ['scalarBaseProfile','scalarWordContract']){const m=structuredClone(original);Object.defineProperty(m,field,{enumerable:true,get(){getterCalls++;throw new Error('accessor must not run');}});deny(`${key}/metadata-getter-${field}`,m,stage);}
 for(const field of ['kind','stage','operations','domain','truncation','sign','result']){const m=structuredClone(original);Object.defineProperty(m.scalarWordContract,field,{enumerable:true,get(){getterCalls++;throw new Error('accessor must not run');}});deny(`${key}/policy-getter-${field}`,m,stage);}
 {const m=structuredClone(original);const ops=['TRUNC'];Object.defineProperty(ops,'0',{get(){getterCalls++;return 'TRUNC';}});m.scalarWordContract.operations=ops;deny(`${key}/operation-entry-getter`,m,stage);}
 for(const target of ['metadata','policy','operations']){const m=structuredClone(original),object=target==='metadata'?m:target==='policy'?m.scalarWordContract:m.scalarWordContract.operations;object[Symbol('hostile')]=true;deny(`${key}/symbol-${target}`,m,stage);}
 {const m=structuredClone(original),policy=m.scalarWordContract;delete policy.kind;Object.setPrototypeOf(policy,{get kind(){getterCalls++;return 'tgsi-finite-scalar-binary32-v1';}});deny(`${key}/inherited-kind`,m,stage);}
 for(const field of ['constantDomains','constantAccesses','constantConstraints','constantRadialDomains','constantRasterDomains','rasterBaseProfile','preciseWordContract','arithmeticBaseProfile','preciseArithmeticContract','constantConversionDomains','conversionBaseProfile','signedConversionContract'])
  if(Object.hasOwn(original,field)){const m=structuredClone(original);delete m[field];deny(`${key}/erased-base-${field}`,m,stage);}
 {const m=structuredClone(original),contract=parseConstantDomain(m,stage),before=JSON.stringify(contract);assert.equal(contract.ok,true);m.scalarWordContract.operations.length=0;m.scalarWordContract.domain='all-private-words';m.scalarBaseProfile='v31';assert.equal(JSON.stringify(contract),before);assert.ok(Object.isFrozen(contract.scalar)&&Object.isFrozen(contract.scalar.operations));ownership.push({name:key,contractSha256:hash(before),unchangedAfterMutation:true});}
}
for(const [name,p]of [['throwing-reflection',new Proxy({}, {ownKeys(){throw new Error('poison');}})],['revoked',(()=>{const p=Proxy.revocable({},{});p.revoke();return p.proxy;})()]])deny(name,p,'fragment');
const view=new DataView(new ArrayBuffer(4)),float=w=>{view.setUint32(0,w,true);return view.getFloat32(0,true);};
const expected=(words,c)=>{
 if(words.length>184||words.length%4!==0||Object.keys(words).length!==words.length)return false;
 if(words.length<Math.min((c.domain??c.conversionDomain).count,46)*4)return false;
 if(!words.every(w=>Number.isInteger(w)&&w>=0&&w<=0xffffffff))return false;
 if(c.domain&&!words.every(w=>Number.isFinite(float(w))))return false;
 if(c.constraint&&!(words[36]>=0x80000000||words[36]<=18))return false;
 if(c.radialDomain&&Math.abs(float(words[16]))<float(0x3727c5ac))return false;
 if(c.rasterDomain)for(const e of c.rasterDomain.components)for(let lane=0;lane<4;lane++)if(e.mask&(1<<lane)){
  const w=words[e.register*4+lane],n=Math.abs(float(w));if(!(n===0||Number.isFinite(n)&&n>=2**-126))return false;
 }
 if(c.conversionDomain)for(const e of c.conversionDomain.components)for(let lane=0;lane<4;lane++)if(e.mask&(1<<lane)){
  const n=float(words[e.register*4+lane]);if(!(Number.isFinite(n)&&n>=-(2**31)&&n<2**31))return false;
 }
 return true;
};
for(const row of worker.banks){
 const c=row.contract,count=(c.domain??c.conversionDomain).count;
 const checked=words=>c.conversionDomain?checkConversionBank(words,c.conversionDomain,c):c.rasterDomain?checkRasterBank(words,c.rasterDomain,!!c.constraint,!!c.radialDomain):c.radialDomain?checkRadialBank(words,count,!!c.constraint):c.constraint?checkLoopBank(words,count):checkIndirectBank(words,count,!!c.domain);
 for(const at of [0,1,16,36,180,183])for(const word of [0,0x80000000,1,0x80000001,0x007fffff,0x00800000,0x3fc00000,0xbfc00000,0x4effffff,0xceffffff,0x4f000000,0xcf000000,0xcf000001,0x7f7fffff,0xff7fffff,0x7f800000,0xff800000,0x7fc12345]){
  const words=row.safe.slice();words[at]=word;const predicted=expected(words,c),result=checked(words);assert.equal(result.ok,predicted,row.name+'/'+at+'/'+word);
  if(result.ok){const before=JSON.stringify(result.words);words.fill(0xdeadbeef);assert.equal(JSON.stringify(result.words),before);assert.ok(Object.isFrozen(result.words));}
  banks.push({name:row.name,index:at,word,predicted,result});
 }
 const short=row.safe.slice(0,-4);assert.equal(checked(short).ok,false);banks.push({name:row.name,index:'missing-last-register',predicted:false,result:checked(short)});
}
assert.equal(getterCalls,0);
const report={schema:'virgl-scalar-operations-consumer-attacks-v1',status:'passed',workerConsumerSha256:hash(fs.readFileSync(path.join(out,'unpacked/hot/consumer.json'))),uniqueContracts:unique.size,metadata:rows,banks,ownership,getterCalls};
fs.writeFileSync(path.join(out,'consumer-attacks.json'),JSON.stringify(report,null,2)+'\n');console.log(`${rows.length} metadata attacks,${banks.length} word/prefix attacks,${ownership.length} snapshots; zero getters.`);
