import hashlib,json,struct
from pathlib import Path
from replay_sources import interpret
OUT=Path(__file__).resolve().parent;UNPACK=OUT/'unpacked'
def sha(b):return hashlib.sha256(b).hexdigest()
def check(v,m):
 if not v:raise AssertionError(m)
rows=[]
for prefix in ['hot','cold/acceptance']:
 for mode in ['truncate','sign']:
  path=UNPACK/prefix/('fault-'+mode)/'report.json';raw=path.read_bytes();r=json.loads(raw);a=r['acceptance'];check(r['status']=='failed'and a['status']=='failed','deliberatefaultfailed')
  mutations=[(i,x)for i,x in enumerate(a['vertices'])if x['mutation']];check(len(mutations)==1,'one realmutation');vi,v=mutations[0];mutation=v['mutation']
  check(mutation['original']==v['pair']['vertex']['glsl'] and mutation['served']==mutation['original'].replace(mutation['needle'],mutation['replacement'],1),'actual changed emittedsource')
  check(any(e.get('source')==mutation['served']for e in a['events']if e['call']=='shaderSource'),'mutatedphysicalshaderSource')
  xi,x=next((i,x)for i,x in enumerate(v['vectors'])if'failure'in x)
  inputs={0:[struct.unpack('<I',struct.pack('<f',p))[0]for p in x['position']]};expected,points=interpret(v['text'],inputs,[]);predicted=expected[0]+expected[1]+expected[2]
  actual=list(struct.unpack('<12I',bytes(x['bytes'])));failure=x['failure'];lane=failure['lane'];check(predicted[lane]==failure['expected'] and actual[lane]==failure['actual'] and predicted[lane]!=actual[lane],'source independentphysicalcounterexample')
  rows.append({'path':str(path.relative_to(OUT)),'reportSha256':sha(raw),'point':f'acceptance.vertices[{vi}].vectors[{xi}].failure','operation':v['op'],'lane':lane,'predicted':predicted[lane],'observed':actual[lane],'input':x['input'],'sourceSha256':v['textSha256'],'servedSourceSha256':sha(mutation['served'].encode()),'physicalSha256':sha(bytes(x['bytes'])),'scalarInstructions':points})
sabotage=json.loads((OUT/'sabotage-regressions.json').read_bytes());c=sabotage['failure']['counterexample']
check(sabotage['status']=='failed'and c['name']=='TRUNC-known-result-2147483648-bit-31'and c['ok']is False and c['result']['ok']is True,'actual source sabotagecaught')
report={'schema':'virgl-scalar-operations-sensitivity-v1','status':'passed','physicalFaults':rows,'sabotage':{'reportSha256':sha((OUT/'sabotage-regressions.json').read_bytes()),'sourceMutation':json.loads((OUT/'sabotage-source.json').read_bytes())['mutation'],'nativeBinary':sabotage['nativeBinary'],'testSha256':sabotage['testSha256'],'point':'sabotage-regressions.json#failure.counterexample','case':{'name':c['name'],'sourceWord':c['sourceWord'],'predictedWord':c['expectedWord'],'plane':c['plane'],'predictedBit':c['expectedBit'],'predictedAdmission':c['ok'],'actualAdmission':c['result']['ok']}}}
(OUT/'sensitivity.json').write_text(json.dumps(report,indent=2)+'\n');print('4 actual shader-source word contradictions and promoted negativezero C-helper sabotage caught.')
