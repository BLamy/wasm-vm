#!/usr/bin/env python3
import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;UNPACK=OUT/'unpacked'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n')
def check(v,m):
 if not v:raise AssertionError(m)
exports={};bindings={}
for label,prefix,gen in [('hot','hot','generated'),('cold','cold/acceptance','cold-generated')]:
 binary=UNPACK/gen/'scalar-operations-sanitize/scalar-operations-test';profile=UNPACK/prefix/'native/native.profdata'
 cmd=['xcrun','llvm-cov','export',str(binary),'-instr-profile='+str(profile)]
 value=json.loads(subprocess.check_output(cmd))
 selected={'bridge.c','raw_bits.c','native_tests/scalar_operations.c','raw_scalar.h'}
 for data in value['data']:
  data['files']=[f for f in data['files']if any(f['filename'].endswith('/'+s)for s in selected)]
  data['functions']=[f for f in data['functions']if any(any(n.endswith('/'+s)for s in selected)for n in f['filenames'])]
 recorded=json.loads((UNPACK/prefix/'native/coverage.json').read_bytes());check(recorded==value,'actual sanitizer/profile exact re-export:'+label)
 exports[label]=value;bindings[label]={'binarySha256':sha(binary.read_bytes()),'profileSha256':sha(profile.read_bytes()),'workerCoverageSha256':sha((UNPACK/prefix/'native/coverage.json').read_bytes()),'command':cmd};dump(label+'-coverage-export.json',value)
files={Path(f['filename']).name:f for d in exports['hot']['data']for f in d['files']}
helper=files['raw_scalar.h'];check(all(helper['summary'][s]['covered']==helper['summary'][s]['count']for s in ['lines','branches','regions']),'allscalarhelperlines/branches/regions')
def cppcount(file,line):
 f=files.get(Path(file).name)
 if not f:return None
 seg=f['segments'];best=0
 # A counted source segment remains active until its successor. Record each
 # intersecting interval, excluding gaps and no-count structure.
 for a,b in zip(seg,seg[1:]+[[10**9,1,0,False,False,False]]):
  if a[3]and not a[5]and a[0]<=line<=b[0]:best=max(best,a[2])
 return best
v8=[]
for prefix in ['hot','cold/acceptance']:
 for directory in (UNPACK/prefix).glob('gpu-*'):
  for script in json.loads((directory/'browser-coverage.json').read_bytes())['scripts']:
   name=script['source'];check(sha((ROOT/name).read_bytes())==script['sha256'],'recordedV8source')
   if name=='renderer/virgl-command/constant-domain.mjs':v8.append({'point':str((directory/'browser-coverage.json').relative_to(OUT)),'functions':script['coverage']['functions']})
for p in (OUT/'node-consumer-coverage').glob('*.json'):
 for script in json.loads(p.read_bytes())['result']:
  if script['url'].endswith('/renderer/virgl-command/constant-domain.mjs'):v8.append({'point':str(p.relative_to(OUT)),'functions':script['functions']})
js=(ROOT/'renderer/virgl-command/constant-domain.mjs').read_text();lines=js.splitlines(keepends=True);offsets=[0]
for line in lines:offsets.append(offsets[-1]+len(line))
def jscount(line):
 lo,hi=offsets[line-1],offsets[line];points=[]
 for record in v8:
  best=0
  for x in range(lo,hi):
   if not js[x].isspace():
    ranges=[r for f in record['functions']for r in f['ranges']if r['startOffset']<=x<r['endOffset']]
    if ranges:best=max(best,min(ranges,key=lambda r:r['endOffset']-r['startOffset'])['count'])
  if best:points.append({'point':record['point'],'count':best})
 return points
paths=['renderer/virgl-shader/raw_bits.c','renderer/virgl-shader/bridge.c','renderer/virgl-shader/raw_bits.h','renderer/virgl-shader/raw_scalar.h','renderer/virgl-command/constant-domain.mjs']
diff=subprocess.check_output(['git','diff','--unified=0','58601f91','ad0bf026','--',*paths],cwd=ROOT,text=True)
file=None;line=0;added=[];hunks=[];hunk=None
for text in diff.splitlines():
 if text.startswith('+++ b/'):file=text[6:]
 elif text.startswith('@@ '):
  m=re.search(r'\+(\d+)(?:,(\d+))?',text);line=int(m[1]);hunk={'file':file,'header':text,'addedLines':[]};hunks.append(hunk)
 elif text.startswith('+')and not text.startswith('+++'):
  entry={'file':file,'line':line,'text':text[1:]};added.append(entry);hunk['addedLines'].append(line);line+=1
 elif text.startswith(' ')and not text.startswith('diff '):line+=1
for row in added:
 file,line,text=row['file'],row['line'],row['text'].strip()
 if not text or text in ['{','}','};']or text.startswith(('/*','*','//','#'))or file.endswith('raw_bits.h')or text.startswith(('_Static_assert','"bounded numeric scalar','"scalar opcode/feature separation')):
  row.update(classification='waived',reason='Static declarations, comment/preprocessor or structural punctuation; no executable semantic path is added.')
 elif file.endswith('raw_scalar.h')and (text.startswith(('static const char','"'))or line in [19,20,21,22,23,24,25,26,27]):
  row.update(classification='waived',reason='Static emitted GLSL data; both exact helper strings are present in actual physical shaderSource and exercised by the independent word/plane replay.')
 elif file.endswith('.mjs'):
  points=jscount(line);row.update(classification='executed'if points else'needs-evidence',v8=points)
 else:
  count=cppcount(file,line)
  if not count and text.startswith(('static void ', 'static uint32_t ')):
   name=re.search(r'\b([A-Za-z_][A-Za-z_0-9]*)\(',text).group(1)
   functions=[f for d in exports['hot']['data']for f in d['functions']if f['name'].endswith(':'+name)]
   if functions:
    count=max(f['count']for f in functions);row['functionEntry']=[{'name':f['name'],'bodyLine':f['regions'][0][0],'count':f['count']}for f in functions]
  row.update(classification='executed'if count else'needs-evidence',llvmCount=count)
needs=[r for r in added if r['classification']=='needs-evidence']
for h in hunks:h['classifications']={r['line']:r['classification']for r in added if r['file']==h['file']and r['line']in h['addedLines']}
report={'schema':'virgl-scalar-operations-coverage-audit-v1','status':'passed'if not needs else'needs-evidence','sourceHead':'ad0bf0267ce7a53e2e5ab6a2f6a5b2ee0a2383f4','binaryBindings':bindings,'helperCoverage':helper['summary'],'helperFunctions':[f for d in exports['hot']['data']for f in d['functions']if any(n.endswith('/raw_scalar.h')for n in f['filenames'])],'hunks':hunks,'runtimeAddedLines':added,'needsEvidence':needs,'dead':[],'v8Sources':[{k:v for k,v in r.items()if k!='functions'}for r in v8]}
dump('coverage-audit.json',report)
print(json.dumps({'status':report['status'],'hunks':len(hunks),'runtimeAddedLines':len(added),'helper':helper['summary'],'missing':needs}))
