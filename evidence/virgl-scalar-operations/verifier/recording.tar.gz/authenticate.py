#!/usr/bin/env python3
import hashlib,json,subprocess,tarfile
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
WORKER=OUT.parent/'worker';FREEZE='ad0bf0267ce7a53e2e5ab6a2f6a5b2ee0a2383f4'
def sha(b):return hashlib.sha256(b).hexdigest()
def check(v,m):
 if not v:raise AssertionError(m)
def dump(name,v):(OUT/name).write_text(json.dumps(v,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
m=json.loads((WORKER/'manifest.json').read_bytes());i=json.loads((WORKER/'records.json').read_bytes())
check(m['sourceHead']==i['sourceHead']==FREEZE,'frozen source head')
for k in ['archive','recordIndex']:
 raw=(WORKER/m[k]['path']).read_bytes();check(len(raw)==m[k]['bytes'] and sha(raw)==m[k]['sha256'],k+' digest')
check(m['archive']['sha256']=='619627d6ed0a2f3f62d461e0f3699bc1da7c04cfa4a9f1f2d18dd0a2e1fdbb68','named archive')
check(m['recordIndex']['sha256']=='65f3c277eb411b162186fed14447a80a30b07c41d02daef5ae018312a9099959','named index')
unpacked=OUT/'unpacked';unpacked.mkdir(exist_ok=True);rows=[]
with tarfile.open(WORKER/'recording.tar.gz','r:gz') as t:
 members=t.getmembers();check(len(members)==m['records']==81,'81members')
 check([x.name for x in members]==[x['path'] for x in i['records']],'unique ordered member index')
 for entry,member in zip(i['records'],members):
  rel=PurePosixPath(member.name);check(not rel.is_absolute() and '..' not in rel.parts and member.isfile(),'safe regular member')
  raw=t.extractfile(member).read();check(len(raw)==entry['bytes']==member.size and sha(raw)==entry['sha256'],entry['path'])
  p=unpacked/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
  rows.append(entry)
def load(n):return json.loads((unpacked/n).read_bytes())
source_sets={};receipt_sets={}
for label,prefix,gprefix,rd in [('hot','hot','generated',m['hotReceiptSha256']),('cold','cold/acceptance','cold-generated',m['coldReceiptSha256'])]:
 receipt=load(prefix+'/receipt.json');check(sha((unpacked/prefix/'receipt.json').read_bytes())==rd,label+'receipt seal')
 check(receipt['gitHead']==FREEZE and receipt['status']=='passed',label+' exact head')
 source_rows=[]
 for entry in receipt['sources']:
  name=entry['path']
  if name.startswith('renderer/virgl-shader/build/'):
   p=unpacked/gprefix/name.removeprefix('renderer/virgl-shader/build/');raw=p.read_bytes()
  else:
   raw=git('show',FREEZE+':'+name);check(raw==(ROOT/name).read_bytes(),'current source drift: '+name)
  check(sha(raw)==entry['sha256'] and len(raw)==entry['bytes'],'frozen '+label+': '+name)
  source_rows.append(entry)
 for e in receipt['records']:
  raw=(unpacked/prefix/e['path']).read_bytes();check(len(raw)==e['bytes'] and sha(raw)==e['sha256'],label+'receipt member '+e['path'])
 recording_heads=[]
 for p in [prefix+'/native/report.json',prefix+'/wasm/report.json',prefix+'/consumer.json']+[prefix+'/gpu-'+str(s)+'/report.json' for s in [1369979863,2804203833,3781791491]]+[prefix+'/fault-'+s+'/report.json' for s in ['truncate','sign']]:
  v=load(p);rh=v['gitHead'];check(subprocess.run(['git','merge-base','--is-ancestor',rh,FREEZE],cwd=ROOT,stdout=subprocess.DEVNULL).returncode==0,'report ancestor')
  changed=git('diff','--name-only',rh,FREEZE).decode().splitlines();check(set(changed)<= {'tools/virgl-scalar-operations/receipt.py'},'runtime/harness changed since report: '+p)
  recording_heads.append({'path':p,'recordingHead':rh,'incrementalDiff':changed})
 native=load(prefix+'/native/report.json');binary=unpacked/gprefix/'scalar-operations-sanitize/scalar-operations-test'
 check(sha(binary.read_bytes())==native['binary']['sha256'],'actual recorded sanitizer')
 binary.chmod(0o755)
 (unpacked/gprefix/'native/virgl-shader').chmod(0o755)
 source_sets[label]=source_rows;receipt_sets[label]={'sha256':rd,'recordingHeads':recording_heads,'binary':native['binary'],'recordCount':len(receipt['records']),'checkedWords':receipt['checkedWords'],'checkedPixels':receipt['checkedPixels']}
c=load('cold/report.json');check(c['status']=='passed' and c['cloneHead']==c['gitHead']==FREEZE and c['exitCode']==0 and c['statusBefore']==c['statusAfter']=='','cold pristine')
check(sha((unpacked/'cold/report.json').read_bytes())==m['coldReportSha256'],'coldreportseal')
check(c['receiptSha256']==m['coldReceiptSha256'] and sha((unpacked/'cold/cold.log').read_bytes())==c['logSha256'],'coldreceipt/log binding')
# Carry previous verifier seals forward, checking sealed hashes rather than repeating their runs.
previous={}
for directory in ['virgl-signed-conversions','virgl-signed-integers','virgl-hex-literals','virgl-compiler-bounds']:
 p=ROOT/'evidence'/directory/'verifier'/'manifest.json'
 if not p.exists():continue
 v=json.loads(p.read_bytes());related={}
 for key in ['archive','recordIndex','verdict']:
  entry=v.get(key)
  if isinstance(entry,dict) and 'path'in entry and (p.parent/entry['path']).exists():
   raw=(p.parent/entry['path']).read_bytes();check(sha(raw)==entry['sha256'],'carry '+directory+':'+key);related[key]=entry
 previous[directory]={'manifestSha256':sha(p.read_bytes()),'seal':v,'authenticated':related}
report={'schema':'virgl-scalar-operations-authentication-v1','task':'E6-T12g6f','status':'passed','sourceHead':FREEZE,'workerManifestSha256':sha((WORKER/'manifest.json').read_bytes()),'workerArchive':m['archive'],'workerIndex':m['recordIndex'],'members':rows,'sources':source_sets,'receipts':receipt_sets,'coldReport':c,'carryForward':previous}
dump('authentication.json',report)
print(json.dumps({'status':'passed','members':len(rows),'sourceRows':{k:len(v)for k,v in source_sets.items()},'binaryBindings':{k:v['binary']['sha256']for k,v in receipt_sets.items()},'carryForward':list(previous)}))
