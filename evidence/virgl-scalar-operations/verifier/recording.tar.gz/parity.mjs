import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {createVirglShaderBridge} from '../../../renderer/virgl-shader/index.mjs';
const out=path.dirname(fileURLToPath(import.meta.url)),unpacked=path.join(out,'unpacked'),hash=b=>createHash('sha256').update(b).digest('hex');
const load=name=>JSON.parse(fs.readFileSync(path.join(unpacked,name)));
const native=load('hot/native/report.json'),wasm=load('hot/wasm/report.json'),primary=load('generated/scalar-operations-primary.json');
for(const name of ['wasm/virgl-shader.mjs','wasm/virgl-shader.wasm'])assert.equal(hash(fs.readFileSync(path.join('renderer/virgl-shader/build',name))),hash(fs.readFileSync(path.join(unpacked,'generated',name))));
const actualLog=fs.readFileSync(path.join(unpacked,'hot/native/native.log'),'utf8').trim().split('\n'),actualPrimary=new Map(),actualCases=new Map();
for(const line of actualLog){const m=/^(CASE|PRIMARY) (\d+) (.*)$/.exec(line);if(m)(m[1]==='PRIMARY'?actualPrimary:actualCases).set(+m[2],JSON.parse(m[3]));else assert.equal(line,'STATUS passed');}
const rows=[],bySource=new Map(),pairSources=new Map();
for(let i=0;i<native.cases.length;i++){
 const c=native.cases[i],w=wasm.cases[i],p=wasm.pairs[i];assert.equal(c.index,i);assert.deepEqual(c.result,actualCases.get(i));assert.deepEqual(c.result,w.result);assert.equal(p.result.ok,c.ok);
 assert.equal(hash(c.text),c.textSha256);assert.equal(typeof c.result.ok,'boolean');assert.equal(c.result.ok,c.ok);
 if(!c.ok)for(const key of ['glsl','metadata','vertex','fragment']){assert.equal(Object.hasOwn(c.result,key),false);assert.equal(Object.hasOwn(p.result,key),false);}
 if(c.primary){assert.deepEqual(c.primaryResult,actualPrimary.get(i));for(const op of c.primaryResult.scalarInstructions){assert.equal(op.sourceType,4);assert.equal(op.destinationType,4);assert.equal(c.text.includes(op.opcode+' '),true);}}
 bySource.set(c.stage+'\0'+c.text,c.result);pairSources.set(c.stage+'\0'+c.text,p.result);
 rows.push({index:i,name:c.name,textSha256:c.textSha256,admission:c.ok,nativeResultSha256:hash(JSON.stringify(c.result)),wasmResultSha256:hash(JSON.stringify(w.result)),pairSha256:hash(JSON.stringify(p.result)),primaryResultSha256:c.primary?hash(JSON.stringify(c.primaryResult)):null});
}
assert.deepEqual(primary,native.cases.filter(c=>c.primary).map(c=>({name:c.name,stage:c.stage,text:c.text,primary:c.primaryResult})));
const primaryByText=new Map(primary.map(c=>[c.text,c.primary])),bridge=await createVirglShaderBridge(),unique=new Map(),gpu=[];
for(const prefix of ['hot','cold/acceptance'])for(const seed of [1369979863,2804203833,3781791491]){
 const name=prefix+'/gpu-'+seed+'/report.json',report=load(name),a=report.acceptance;
 const available=new Set(a.events.filter(x=>x.call==='shaderSource').map(x=>x.source)),bindings=[];
 for(const [stage,probes]of [['vertex',a.vertices],['fragment',a.fragments]])for(let i=0;i<probes.length;i++){
  const p=probes[i],key=stage+'\0'+p.text;if(!unique.has(key)){
   const nativeResult=JSON.parse(execFileSync(path.join(unpacked,'generated/native/virgl-shader'),[stage],{input:p.text,maxBuffer:4e6}));
   const wasmResult=bridge.translate({stage,text:p.text});assert.equal(nativeResult.ok,true);assert.deepEqual(wasmResult,nativeResult);
   if(bySource.has(key))assert.deepEqual(nativeResult,bySource.get(key));
   // Pair stage payloads do not retain TGSI; use the fixed explicit partner in
   // the physical fixture and the probe's original stage source instead.
   const partner=stage==='vertex'?'FRAG\nDCL IN[0], GENERIC[0], PERSPECTIVE\nDCL IN[1], GENERIC[1], PERSPECTIVE\nDCL OUT[0], COLOR\nMOV OUT[0], IN[0]\nEND\n':
     'VERT\nDCL IN[0]\nDCL OUT[0], POSITION\nDCL OUT[1], GENERIC[0]\nDCL OUT[2], GENERIC[1]\nMOV OUT[0], IN[0]\nMOV OUT[1], IN[0]\nMOV OUT[2], IN[0]\nEND\n';
   const pair=bridge.translatePair(stage==='vertex'?{vertexText:p.text,fragmentText:partner}:{vertexText:partner,fragmentText:p.text});
   assert.deepEqual(pair,p.pair);unique.set(key,{stage,textSha256:hash(p.text),nativeResultSha256:hash(JSON.stringify(nativeResult)),pairSha256:hash(JSON.stringify(pair)),pair});
  }else assert.deepEqual(unique.get(key).pair,p.pair);
  if(p.backend==='mesa'){assert.deepEqual(primaryByText.get(p.text),p.primary);assert.ok(available.has(p.primary.glsl));}
  else assert.ok(available.has(p.pair[stage].glsl));
  bindings.push({stage,index:i,backend:p.backend,textSha256:hash(p.text),servedSha256:hash(p.backend==='mesa'?p.primary.glsl:p.pair[stage].glsl)});
 }
 gpu.push({path:name,bindings});
}
const report={schema:'virgl-scalar-operations-native-source-parity-v1',status:'passed',nativeCases:rows,primaryWitnesses:actualPrimary.size,physicalUniqueSources:unique.size,physicalSources:[...unique.values()].map(({pair,...v})=>v),gpu};
fs.writeFileSync(path.join(out,'native-source-parity.json'),JSON.stringify(report,null,2)+'\n');console.log(`${rows.length} public cases,${actualPrimary.size} actual pinned witnesses,${unique.size} physical sources bound.`);
