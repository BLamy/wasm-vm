#!/usr/bin/env python3
"""Interpret recorded TGSI independently; predict before inspecting physical bytes."""
import hashlib,json,math,re,struct,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent;UNPACK=OUT/'unpacked'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def check(v,m):
 if not v:raise AssertionError(m)
def f(w):return struct.unpack('<f',struct.pack('<I',w))[0]
def b(v):return struct.unpack('<I',struct.pack('<f',v))[0]
def scalar(op,w):
 n=f(w);check(math.isfinite(n),'finite scalar source')
 return b(math.copysign(float(math.trunc(n)),n)) if op=='TRUNC' else b(1 if n>0 else -1 if n<0 else 0)
def interpret(text,inputs,bank):
 regs={'IN':inputs,'IMM':{},'TEMP':{},'OUT':{},'CONST':{i:bank[i*4:i*4+4] for i in range(len(bank)//4)}};stack=[];live=True;scalar_points=[]
 def operand(s,lane):
  neg=s.startswith('-');s=s[1:]if neg else s
  match=re.fullmatch(r'(IN|IMM|TEMP|OUT|CONST)\[(\d+)\](?:\.([xyzw]{4}))?',s);check(match is not None,'source:'+s)
  file,index,swizzle=match.groups();val=regs[file].get(int(index),[None]*4)['xyzw'.index((swizzle or 'xyzw')[lane])]
  check(val is not None,'initialized source:'+s)
  return val^0x80000000 if neg else val
 for line_no,line in enumerate(text.splitlines(),1):
  line=line.strip()
  if not line or line in ['VERT','FRAG','END'] or line.startswith(('DCL ','PROPERTY ')):continue
  im=re.fullmatch(r'IMM\[(\d+)\] (UINT32|FLT32) \{([^}]+)\}',line)
  if im:
   idx,kind,vals=im.groups();regs['IMM'][int(idx)]=[int(x.strip(),0)if kind=='UINT32' else b(float(x))for x in vals.split(',')];continue
  op,args=line.split(' ',1)if ' 'in line else(line,'')
  if op=='UIF':
   cond=bool(operand(args,0)) if live else False;stack.append((live,cond));live=live and cond;continue
  if op=='ELSE':parent,cond=stack[-1];live=parent and not cond;continue
  if op=='ENDIF':live=stack.pop()[0];continue
  if not live:continue
  args=[v.strip()for v in args.split(',')];dst=re.fullmatch(r'(TEMP|OUT)\[(\d+)\](?:\.([xyzw]+))?',args[0]);check(dst is not None,'destination:'+line)
  file,index,mask=dst.groups();lanes=['xyzw'.index(c)for c in mask or 'xyzw'];old=regs[file].get(int(index),[None]*4)[:];new=old[:];src=[]
  for lane in lanes:
   words=[operand(v,lane)for v in args[1:]];src.append((lane,words))
   if op=='MOV':value=words[0]
   elif op in ['TRUNC','SSG']:value=scalar(op,words[0])
   elif op=='AND':value=words[0]&words[1]
   elif op=='OR':value=words[0]|words[1]
   elif op=='USHR':value=words[0]>>(words[1]&31)
   elif op=='UCMP':value=words[1]if words[0]else words[2]
   elif op=='F2I':
    number=f(words[0]);check(math.isfinite(number) and -2**31<=number<2**31,'defined F2I source');value=math.trunc(number)&0xffffffff
   elif op=='I2F':value=b(words[0]if words[0]<2**31 else words[0]-2**32)
   else:raise AssertionError('unhandled TGSI instruction:'+line)
   new[lane]=value
  if op in ['TRUNC','SSG']:scalar_points.append({'line':line_no,'opcode':op,'sources':src,'before':old,'after':new})
  regs[file][int(index)]=new
 check(not stack,'closed control')
 return regs['OUT'],scalar_points

def run(path):
 raw=path.read_bytes();r=json.loads(raw);a=r['acceptance'];check(a['status']=='passed','physical status')
 check(r['browserErrors']=={'console':[],'page':[],'requests':[]},'zero browser errors')
 check(r['browser']['launch']['headless']is False,'headed GPU');check('Apple M4 Max'in a['renderer']['renderer'],'physical AppleGPU')
 sources={v['path']:v['sha256']for v in r['sources']}
 for entry in r['servedFiles']:check(sources[entry['path']]==entry['sha256'],'served source')
 events=[e['source']for e in a['events']if e['call']=='shaderSource'];counts={s:events.count(s)for s in set(events)}
 rows=[];pixels=[];draws=[];checkedWords=checkedPixels=0;allowedZeroCount=0
 for vi,v in enumerate(a['vertices']):
  check(v['predicate']is False,'no predicate reduction');check(sha(v['text'].encode())==v['textSha256'],'source digest')
  check(v['reflection']==[{'name':n,'type':35666,'size':1}for n in ['gl_Position','vso_g0','vso_g1']],'actual fullword reflection')
  served=v['primary']['glsl']if v['backend']=='mesa'else v['pair']['vertex']['glsl'];check(counts.get(served,0)>0,'actual native shaderSource')
  check(counts.get(v['pair']['fragment']['glsl'],0)>0,'actual paired fragmentSource')
  for xi,x in enumerate(v['vectors']):
   # Input values precede any access to observed/bytes fields.
   inputs={0:list(map(b,x['position']))};bank=[]
   if v['inputSource']:inputs[1]=x['input']['a'];check(x['inputWords']==inputs[1],'physical input attribute')
   if v['bank']or v['variant']=='join':
    bank=[0]*184;bank[:4]=x['input']['a'];bank[180:]=x['input']['b'];bank[172]=x['condition']
    upload=x['bankUpload'];check(upload['words']==bank and upload['observedA']==bank[:4]and(upload['observedB']is None or upload['observedB']==bank[180:]),'physical dynamic bank ownership')
   out,points=interpret(v['text'],inputs,bank);predicted=out[0]+out[1]+out[2]
   result=[((out[2][i]&511)<<23)|(out[1][i]&0x7fffff)for i in range(4)]
   allowed=[[0x3f000000,0x3f000100]if v['backend']=='mesa'and lane>=8 and(result[lane-8]&0x7fffffff)==0 else [word]for lane,word in enumerate(predicted)]
   physical=bytes(x['bytes']);actual=list(struct.unpack('<12I',physical))
   check(len(physical)==48 and sha(physical)==x['sha256'],'actual feedback bytes')
   check(all(w in allowed[l]for l,w in enumerate(actual)),'source-interpreted exact scalar carrier')
   check(x['expectedWords']==predicted and x['observed']==actual and x['allowedWords']==allowed,'record matches independent prediction')
   reconstructed=[((actual[8+i]&511)<<23)|(actual[4+i]&0x7fffff)for i in range(4)]
   check(all(w==result[i]or(v['backend']=='mesa'and(w&0x7fffffff)==0 and(result[i]&0x7fffffff)==0)for i,w in enumerate(reconstructed)),'all32 result words')
   allowedZeroCount+=sum(len(s)>1 for s in allowed)
   rows.append({'point':f'acceptance.vertices[{vi}].vectors[{xi}]','op':v['op'],'variant':v['variant'],'backend':v['backend'],'modifier':v['modifier'],'input':x['input'],'condition':x['condition'],'sourceSha256':v['textSha256'],'scalarInstructions':points,'predictedWords':predicted,'all32bits':result,'actualAll32bits':reconstructed,'resultSha256':sha(physical)})
   checkedWords+=12
 for fi,frag in enumerate(a['fragments']):
  out,points=interpret(frag['text'],{},[]);rgba=[round(f(w)*255)for w in out[0]]
  check(all(v in [0,255]for v in rgba),'exact colorbit prediction')
  physical=bytes(frag['rgbaBytes']);check(len(physical)==64 and sha(physical)==frag['sha256'],'actual rgba bytes')
  # Source result bit may differ only at plane31 for a primary mathematical zero.
  check(all(x==rgba[i%4]or(frag['backend']=='mesa'and frag['plane']==31 and(scalar(frag['op'],frag['input']['a'][i%4])&0x7fffffff)==0 and x in [0,255])for i,x in enumerate(physical)),'source-interpreted physical pixels')
  served=frag['primary']['glsl']if frag['backend']=='mesa'else frag['pair']['fragment']['glsl'];check(counts.get(served,0)>0,'actual fragment shaderSource')
  pixels.append({'point':f'acceptance.fragments[{fi}]','op':frag['op'],'plane':frag['plane'],'backend':frag['backend'],'sourceSha256':sha(frag['text'].encode()),'scalarInstructions':points,'expectedRGBA':rgba,'resultSha256':sha(physical)})
  checkedPixels+=16
 guardedAttacks=asyncWaits=0
 for di,d in enumerate(a['bankDraws']):
  stage=d['stage'];check(not d['oracleStops'],'no skipped guard failure')
  check(d['components']=={'register':45 if stage==0 else 0,'mask':10 if stage==0 else 5},'postswizzle domain')
  for xi,x in enumerate(d['draws']):
   vs,_=interpret(d['sources']['vertex'],{0:list(map(b,[-1,-1,0,1]))},x['words']if stage==0 else[])
   fs,points=interpret(d['sources']['fragment'],{0:vs[1]},x['words']if stage==1 else[])
   rgba=[round(f(w)*255)for w in fs[0]];physical=bytes(x['rgbaBytes'])
   check(physical==bytes(rgba*16)and sha(physical)==x['sha256'],'actual indexed scalar pixels')
   check(x['result']['ok']is True and x['expectedRGBA']==rgba,'exact indexed expectation')
   check(x['snapshot']['contexts'][0]['subContexts'][0]['bindings']['constants'][stage]==x['words'],'whole declared bank retained')
   draws.append({'point':f'acceptance.bankDraws[{di}].draws[{xi}]','stage':stage,'async':d['asynchronous'],'expectedRGBA':rgba,'sourceSha256':{k:sha(v.encode())for k,v in d['sources'].items()},'resultSha256':sha(physical)})
   checkedPixels+=16
  for x in d['attacks'][:5]:
   check(x['before']==x['after']and x['pixelsBefore']==x['pixelsAfter'],'unsafebank unchangedCPU/GPU')
   check(x['result']['ok']is False and x['result']['appliedCommands']==0 and x['result']['error']['code']=='constant-conversion-domain-error','closed range rejection')
   check(not any(e['call']in ['uniform4uiv','drawElements','getBufferSubData','copyBufferSubData']for e in x['events']),'reject before upload/read/draw');guardedAttacks+=1
  check(d['attacks'][5]['result']['error']['code']=='incomplete-draw','completeprefix despite reflection')
  check(len(d['yieldAttacks'])==int(d['asynchronous']),'actual async wait')
  for x in d['yieldAttacks']:
   check(x['before']==x['after']and all(t['ok']is False and t['error']['code']=='busy'for t in x['attempts']),'held immutableasyncplan');asyncWaits+=1
  check(all(v==0 for v in d['finalBudgets'].values())and all(v==0 for v in d['finalResourceBudgets'].values()),'zero consumerbudget')
 for c in a['consumers']:
  check(len(c['captures'])==6 and c['rejection']['before']==c['rejection']['after']and c['rejection']['result']['ok']is False,'owned A/B/A finitebanks')
  for x in c['captures']:
   banks=x['snapshot']['contexts'][0]['subContexts'][0]['bindings']['constants'];check(banks[0]==banks[1]and len(banks[0])==184,'wholeownedstagebanks')
   for n in x['native']:check(n['words']==banks[0 if n['name']=='vsconst0'else 1][n['index']*4:n['index']*4+4],'physicaluniformownership')
  check(all(v==0 for v in c['finalBudgets'].values())and all(v==0 for v in c['finalResourceBudgets'].values()),'zero statebudget')
 check(a['objects']['live']==0 and a['checkedWords']==checkedWords and a['checkedPixels']==checkedPixels,'independentcounts/objects')
 return {'path':str(path.relative_to(OUT)),'reportSha256':sha(raw),'seed':a['seed'],'renderer':a['renderer'],'words':checkedWords,'pixels':checkedPixels,'primaryZeroAllowances':allowedZeroCount,'shaderSources':len(events),'vertices':rows,'fragments':pixels,'draws':draws,'guardedAttacks':guardedAttacks,'asyncWaits':asyncWaits}

if __name__=='__main__':
 paths=[Path(x).resolve()for x in sys.argv[1:]]if len(sys.argv)>1 else [UNPACK/prefix/('gpu-'+str(seed))/'report.json'for prefix in ['hot','cold/acceptance']for seed in [1369979863,2804203833,3781791491]]
 runs=[run(p)for p in paths];name='fourth-seed-semantics.json'if sys.argv[1:]else'source-semantics.json'
 (OUT/name).write_text(json.dumps({'schema':'virgl-scalar-operations-source-replay-v1','task':'E6-T12g6f','status':'passed','runs':runs},indent=2)+'\n')
 print(json.dumps({'status':'passed','runs':len(runs),'words':sum(r['words']for r in runs),'pixels':sum(r['pixels']for r in runs)}))
