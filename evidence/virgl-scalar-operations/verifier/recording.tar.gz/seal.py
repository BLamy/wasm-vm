import gzip,hashlib,io,json,shutil,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(n):return json.loads((OUT/n).read_bytes())
def dump(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n')
def cite(name,point):return {'path':name,'point':point,'sha256':sha((OUT/name).read_bytes())}
auth=load('authentication.json');coverage=load('coverage-audit.json');guards=load('independent-regressions.json');semantics=load('source-semantics.json');fourth=load('fourth-seed-semantics.json');consumer=load('consumer-attacks.json');sensitivity=load('sensitivity.json');final=load('final-checks.json')
for r in [auth,coverage,guards,semantics,fourth,consumer,sensitivity,final]:assert r['status']=='passed'
assert guards['cases']==len(guards['native'])==len(guards['wasm'])==1427
assert guards['testSha256']==sha((ROOT/'renderer/virgl-shader/tests/scalar-operation-regressions.mjs').read_bytes())
assert not coverage['needsEvidence']and not coverage['dead']
assert sensitivity['sabotage']['testSha256']==guards['testSha256']
findings=[
 ('P1','All81members,223hot/218cold source rows, actual binaries/profiles and pristine scrubbed cold proof authenticate at the frozen source head.',[cite('authentication.json','members,sources.hot,sources.cold,coldReport,receipts')]),
 ('P2','TRUNC rounds towardzero at fractions/integer neighbors/exponents and preserves source zero sign, as independently interpreted from TGSI and physical bytes.',[cite('source-semantics.json','runs[].vertices[].scalarInstructions,predictedWords,all32bits,resultSha256'),cite('independent-regressions.json','native/wasm:TRUNC-known-result bit projections')]),
 ('P3','SSG yields exact-1/+1/canonical+0; dynamic subnormals retain their sign. Owned comparisons have one exact zero; primary-only mathematical zeros use the documented sign freedom.',[cite('source-semantics.json','runs[].vertices:SSG,finite-bank-subnormal;fragments[].expectedRGBA'),cite('source-semantics-policy.json','GLSLES300')]),
 ('P4','Masks consume post-swizzle lanes, aliases use old sources, negation precedes the scalar operation, and saved/killed versions and joins preserve provenance.',[cite('independent-regressions.json','native/wasm:killed-lane,aliased-private-lane,finite-bank-negated,saved-version,predecessors'),cite('source-semantics.json','runs[].vertices:alias,masked,swizzled,join,modifier')]),
 ('P5','Raw private words gain no numeric authority; literal nonzero subnormals/nonfinite values reject, typed I2F restores authority, and unknown F2I integers cannot launder it. Existing dynamic bank and component range obligations remain.',[cite('independent-regressions.json','native/wasm:raw-numeric-denial,private-f2i,i2f-restores,ssg-result-integer,trunc-computed-range'),cite('consumer-attacks.json','banks[].predicted/result')]),
 ('P6','1598native/Wasm singles/pairs,1562actual pinned float->float witnesses and740unique physical sources bind exact source/results and unchanged primary physical shaderSource; rejections remain closed.',[cite('native-source-parity.json','nativeCases,primaryWitnesses,physicalSources,gpu[].bindings'),cite('carry-forward.json','retained')]),
 ('P7','Strict own-data scalar policy rejects2008independent metadata attacks without getters,26parsed snapshots stay owned/frozen, and every old wrapper obligation remains.',[cite('consumer-attacks.json','metadata,banks,ownership,getterCalls'),cite('authentication.json','members:hot/consumer.json,cold/acceptance/consumer.json')]),
 ('P8','Both stages and sync/async actual consumers preserve complete prefixes/restoration/reflection and owned waits. Unsafe banks preserve CPU/GPU state before upload/index/draw; all objects/budgets endzero.',[cite('source-semantics.json','runs[].draws,guardedAttacks,asyncWaits'),cite('fourth-seed-semantics.json','runs[0].draws,guardedAttacks,asyncWaits'),cite('cleanup.json','matchingOwnedProcesses,physicalLiveObjects,stateBudgets,drawBudgets')]),
 ('P9','Every one of23runtime hunks/103added lines executes or has an explicit static-data/structure waiver. Actual recorded LLVM exports reproduce10/10helper lines,6/6branches,21/21regions; no dead or missing runtime path.',[cite('coverage-audit.json','hunks,runtimeAddedLines,binaryBindings,helperCoverage,needsEvidence,dead'),cite('independent-regressions.json','native/wasm[1425..1426].result.metadata.scalarWordContract.operations')]),
 ('P10','Four actual emitted-source numerical faults contradict independent physical word predictions; the isolated real C-helper mutation improperly admits negativezero bit31 and the promoted test catches it.',[cite('sensitivity.json','physicalFaults[0..3],sabotage.case'),cite('sabotage-regressions.json','failure.counterexample')]),
 ('P11','1427novel deterministic bit/lane/version/provenance cases have full native/Wasm parity; new fourth Apple M4 Max seed independently reproduces29088words/13632pixels and retains all guard/wait behavior.',[cite('independent-regressions.json','cases,native,wasm,testSha256,nativeBinary'),cite('fourth-seed-semantics.json','runs[0]'),cite('source-semantics-policy.json','fourthSeed.changeWaiver')]),
]
verdict={'schema':'virgl-scalar-operations-verifier-verdict-v1','task':'E6-T12g6f','verdict':'verified','sourceHead':'ad0bf0267ce7a53e2e5ab6a2f6a5b2ee0a2383f4','base':'58601f91','workerSubmissionHead':'880b995ee0d56eadfc20c277f781548227600270','held':11,'failed':0,'needsEvidence':0,'findings':[{'id':i,'status':'HELD','observed':v,'citations':c}for i,v,c in findings],'promoted':{'path':'renderer/virgl-shader/tests/scalar-operation-regressions.mjs','schema':guards['schema'],'cases':1427,'testSha256':guards['testSha256'],'nativeBinary':guards['nativeBinary'],'reportSha256':sha((OUT/'independent-regressions.json').read_bytes())},'frozenWords':sum(r['words']for r in semantics['runs']),'frozenPixels':sum(r['pixels']for r in semantics['runs']),'fourthWords':fourth['runs'][0]['words'],'fourthPixels':fourth['runs'][0]['pixels'],'metadataAttacks':len(consumer['metadata']),'bankAttacks':len(consumer['banks']),'ownedSnapshots':len(consumer['ownership']),'duplicateColdClone':False,'implementationEdits':False,'commitsMade':False,'productionNegotiation':False,'guestExecution':False}
dump('verdict.json',verdict)
# Preserve the final promoted source and actual sabotage binary, not rebuilt substitutes.
(OUT/'promoted').mkdir(exist_ok=True);shutil.copyfile(ROOT/verdict['promoted']['path'],OUT/'promoted/scalar-operation-regressions.mjs')
(OUT/'sabotage').mkdir(exist_ok=True);shutil.copyfile(OUT/'scratch/renderer/virgl-shader/build/native/virgl-shader',OUT/'sabotage/virgl-shader')
shutil.copyfile(OUT/'scratch/renderer/virgl-shader/raw_scalar.h',OUT/'sabotage/raw_scalar.h')
members={}
for p in sorted(OUT.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(OUT)
 if rel.parts[0]in ['unpacked','scratch','__pycache__']or any(s=='__pycache__'for s in rel.parts):continue
 if str(rel)in ['manifest.json','records.json','recording.tar.gz']:continue
 members[str(rel)]=p.read_bytes()
index={'schema':'virgl-scalar-operations-verifier-records-v1','task':'E6-T12g6f','sourceHead':verdict['sourceHead'],'records':[{'path':name,'bytes':len(raw),'sha256':sha(raw)}for name,raw in sorted(members.items())]}
raw_index=(json.dumps(index,indent=2)+'\n').encode();(OUT/'records.json').write_bytes(raw_index)
archive=io.BytesIO()
with gzip.GzipFile(fileobj=archive,mode='wb',mtime=0)as z:
 with tarfile.open(fileobj=z,mode='w')as t:
  for name,raw in sorted(members.items()):
   info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(raw))
raw_archive=archive.getvalue();(OUT/'recording.tar.gz').write_bytes(raw_archive)
manifest={'schema':'virgl-scalar-operations-verifier-seal-v1','task':'E6-T12g6f','verdict':'verified','sourceHead':verdict['sourceHead'],'base':'58601f91','records':len(members),'archive':{'path':'recording.tar.gz','bytes':len(raw_archive),'sha256':sha(raw_archive)},'recordIndex':{'path':'records.json','bytes':len(raw_index),'sha256':sha(raw_index)},'verdictRecord':{'path':'verdict.json','bytes':(OUT/'verdict.json').stat().st_size,'sha256':sha((OUT/'verdict.json').read_bytes())},'workerDependencies':{'manifestSha256':auth['workerManifestSha256'],'archive':auth['workerArchive'],'recordIndex':auth['workerIndex']},'priorHeldSeals':{k:v['manifestSha256']for k,v in auth['carryForward'].items()},'promoted':verdict['promoted'],'coverage':{'hunks':23,'runtimeAddedLines':103,'needsEvidence':0,'dead':0},'held':11,'failed':0,'needsEvidence':0}
dump('manifest.json',manifest)
# Reopen every sealed byte and authenticate the deterministic index.
with tarfile.open(OUT/'recording.tar.gz','r:gz')as t:
 actual=t.getmembers();assert [m.name for m in actual]==[r['path']for r in index['records']]
 for m,e in zip(actual,index['records']):
  raw=t.extractfile(m).read();assert len(raw)==e['bytes']and sha(raw)==e['sha256']
print(json.dumps({'verdict':'verified','members':len(members),'archive':manifest['archive'],'recordIndex':manifest['recordIndex'],'verdictRecord':manifest['verdictRecord'],'promoted':manifest['promoted']}))
