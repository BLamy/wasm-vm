from pathlib import Path, PurePosixPath
import collections,hashlib,io,json,re,subprocess,tarfile
repo=Path.cwd();out=repo/'target/evidence/critic-production-keyboard-wfi-closure02'
def sha(b):return hashlib.sha256(b).hexdigest()
def obj(ref,path):return subprocess.check_output(['git','show',ref+':'+path],cwd=repo)
def git(*args):return subprocess.check_output(['git',*args],cwd=repo).decode().strip()
def function(s,name):
 s=s.decode();m=re.search(r'\bfn '+name+r'\b',s);assert m,name
 start=m.start();i=s.index('{',m.end());level=1;j=i+1
 while level:
  if s[j]=='{':level+=1
  elif s[j]=='}':level-=1
  j+=1
 return s[start:j].encode()
def inspect_tar(raw,expectedMembers):
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
  members=t.getmembers();assert len(members)==expectedMembers and len(set(m.name for m in members))==len(members)
  for m in members:assert m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts
  name='manifest.json' if 'manifest.json' in t.getnames() else 'paired-receipt.json';manifest=json.load(t.extractfile(name));entries=manifest.get('files',manifest.get('identities'));assert isinstance(entries,list)
  assert {m.name for m in members}=={name}|{f['path'] for f in entries}
  for f in entries:
   b=t.extractfile(f['path']).read();assert len(b)==f['bytes'] and sha(b)==f['sha256']
  return manifest
result={'schema':1,'task':'E6-T11d71','status':'running','scope':'Incremental evidence/source closure only; held native transport predictions plus verified D73 pacing and D72 actual stock/software/private/guard/cold proof. No new runtime or long boot.'}
try:
 current=git('rev-parse','HEAD');assert current.startswith('60e4890a')
 frozen='61eeb1b59902c9c52f0c4fdf3880a0081ebb2db2';old='5c0b909048eac8a7d8511be68b6d04482372527c'
 assert not git('diff','--name-only',frozen,current,'--','web','crates','renderer','Cargo.toml','Cargo.lock')
 assert not git('diff','--name-only','2192c4c6',current,'--','crates','renderer','Cargo.toml','Cargo.lock')
 fns=[]
 for path,name in [('crates/core/src/dev/virtio/input/mod.rs','awaiting_host_key_release'),('crates/core/src/lib.rs','external_keyboard_io_pending'),('crates/core/src/lib.rs','after_wfi_retire')]:
  before=function(obj(old,path),name);after=function(obj(frozen,path),name);assert before==after;fns.append({'path':path,'function':name,'bytes':len(after),'sha256':sha(after),'exactOriginalFunction':True})
 for path in ['crates/core/src/dev/virtio/input/mod.rs','crates/core/tests/production_keyboard_wfi_critic.rs']:
  assert obj(old,path)==obj(frozen,path)
 source={'frozen':frozen,'oldNativeEvidence':old,'productDiffAfter61':[],'nativeRendererDependencyDiffSinceVerifiedD73':[],'originalKeyboardFunctions':fns,'unchangedWholeFiles':['crates/core/src/dev/virtio/input/mod.rs','crates/core/tests/production_keyboard_wfi_critic.rs'],'D73TestSupplement':'production_keyboard_host_wait.rs adds10 original paced-mode staged/pending/delivered/break/reset rows, covered in renewed exacte17cold native recording. No original lifecycle test deletion.'}
 (out/'source-equivalence.json').write_text(json.dumps(source,indent=2)+'\n')
 archive=repo/'evidence/virgl-production-keyboard-host-wait/worker/keyboard-host-wait-proof-closure.tar.gz';raw=archive.read_bytes()
 assert len(raw)==2902259 and sha(raw)=='c37868db24a5938b2592cabfa34605497a5cca927271b44fd0f77df8c2ccd4df'
 manifest=inspect_tar(raw,23);assert manifest['head']=='8b895e75566d7c597d96919ac0a99d4b5e0cba4a'
 references=[]
 for r in manifest['references']:
  b=(repo/r['path']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256'];inspect_tar(b,r['membersReopened']);references.append(r)
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
  sources=[]
  for f in manifest['files']:
   if f['path'].startswith('source/'):
    p=f['path'][7:];assert t.extractfile(f['path']).read()==obj(frozen,p);sources.append(p)
   if f['path'].startswith('held-components/'):
    p=repo/'target/evidence'/f['path'][len('held-components/'):];assert p.read_bytes()==t.extractfile(f['path']).read()
  assert len(sources)==8 and t.extractfile('unchanged-since-61.diff').read()==b''
  stdout=t.extractfile('renewed-native/native-clock.stdout').read().decode();stderr=t.extractfile('renewed-native/native-clock.stderr').read().decode()
  for name in ['original_keyboard_lifecycle_preserves_wait_and_releases_idle_jump','paced_idle_still_honors_original_keyboard_waits_and_transport_reset','two_original_keys_require_both_breaks_and_never_freeze_busy_retirement','original_delivered_keyboard_make_preserves_host_turn_before_idle_jump']:assert 'test '+name+' ... ok' in stdout
  expected={'KEYBOARD_LIFECYCLE':48,'PACED_KEYBOARD':10,'KEYBOARD_RETIRE':4,'KEYBOARD_WFI':8,'KEYBOARD_TWO_KEYS':4};rows={k:[] for k in expected}
  for lineno,line in enumerate(stderr.splitlines(),1):
   tag=line.split(' ')[0]
   if tag not in rows:continue
   fields=dict(re.findall(r'(\w+)=([^\s]+)',line));rows[tag].append({'line':lineno,'text':line})
   if tag in ['KEYBOARD_LIFECYCLE','PACED_KEYBOARD']:assert fields['actual']==fields['expected']
   elif tag=='KEYBOARD_RETIRE':assert int(fields['actual'])==int(fields['initial'])+2 and fields['trace_retires']=='128'
   elif tag=='KEYBOARD_WFI':assert fields['actual_mtime']==fields['expected_mtime'] and fields['trace_hash']=='dd8c58e8d6e657e4'
   elif tag=='KEYBOARD_TWO_KEYS':assert int(fields['settled_mtime'])==int(fields['initial'])+500000 and fields['used']=='8' and fields['busy_ticks']=='4'
  assert {k:len(v) for k,v in rows.items()}==expected
  (out/'renewed-native-rows.json').write_text(json.dumps({'source':'closure archive/renewed-native/native-clock.stderr','sha256':sha(stderr.encode()),'rows':rows,'scope':'Read-only renewed recording, no new test execution'},indent=2)+'\n')
  # Referenced D72 source archive preserves the failures; held components are not whole-wrapper claims.
  with tarfile.open(repo/'evidence/virgl-production-interactive-clock/worker/paced-keyboard-policy-submission.tar.gz') as d:
   statuses={p:json.load(d.extractfile(p))['status'] for p in ['cold-original-failed/report.json','production-paced-policy-cold-stock02/report.json','production-paced-policy-cold-stock02/browser/report.json','production-paced-policy-private-window04/report.json']}
   assert list(statuses.values())==['failed','failed','passed','passed']
  result.update({'status':'HELD','submissionHead':current,'archive':{'path':str(archive.relative_to(repo)),'bytes':len(raw),'sha256':sha(raw),'membersReopened':23,'identities':22},'referencesRehashedAndReopened':references,'sourceCopiesMatch61':sources,'renewedNativeRows':expected,'heldNativeRows':64,'additionalVerifiedPacedRows':10,'sourceEquivalence':source,'preservedD72WrapperStatuses':statuses,'D72Verifier':'8c902c7076fcb6eee3075abc42b4a3a662558a93','D73Verifier':'7e2739f28b9c539be894ecd8f693cf743c35258e','scopeCaveats':['The native wait guard alone did not fix oldstock repeats; the explicit separately verified paced policy is a dependency.','No old D71 hot/cold failed report is renamed passed. New evidence is an explicit composition under the incremental rule.','Stock cursor displacement is proved, host cursor resource0 remains no cursor-plane recovery proof.','Parent deployment, E6e recovery and300MIPS remain unverified here.']})
except BaseException as e:result['status']='FAILED';result['failure']=repr(e);raise
finally:(out/'worker-closure-authentication.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'closureMembers':23,'references':len(references),'nativeRows':64,'pacedRows':10,'unchangedNativeFunctions':len(fns)}))
