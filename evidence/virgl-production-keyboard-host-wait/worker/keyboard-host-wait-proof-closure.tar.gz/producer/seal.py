import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
repo=Path.cwd();out=repo/'evidence/virgl-production-keyboard-host-wait/worker';out.mkdir(exist_ok=True,parents=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
def add(p,name=None):
 p=Path(p);files[name or str(p)]=p.read_bytes()
proofs=[
 ('evidence/virgl-production-interactive-clock/worker/paced-keyboard-policy-submission.tar.gz','01f6feaca7b0079b0a4dfa83fc4bdfeb757ca8b258af26c9bd8882273374a37d'),
 ('evidence/virgl-production-interactive-clock/verifier/paced-policy-final/independent-paced-keyboard-policy-review.tar.gz','57c6a9e4851218571fd4b81990757a1b3fe21b406d97b5f9d640d5f63bcec8a9'),
 ('evidence/virgl-production-paced-idle-clock/worker/paced-idle-clock-submission.tar.gz','bea622c1049539743340a05e7dd874914e2b844da785b8df9bedd58e8df09c1c'),
 ('evidence/virgl-production-paced-idle-clock/verifier/independent-paced-idle-clock-review.tar.gz','496e53dbccffd922e1fd63287cf1b2038f62f3abd6c82ef360eadac35935a14f'),
 ('target/evidence/critic-production-keyboard-wfi-native-seal01/independent-native-clock-and-input.tar.gz','a5d28ab63f64cdffbc67fb2871f90dd3f8e595a5a82272be74eae37702143c5d')]
references=[]
for name,digest in proofs:
 b=Path(name).read_bytes();assert sha(b)==digest,name
 with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as t:
  members=[m for m in t if m.isfile()]
  for m in members:assert len(t.extractfile(m).read())==m.size
 references.append({'path':name,'bytes':len(b),'sha256':digest,'membersReopened':len(members)})
add(proofs[-1][0],'prior-independent-native/independent-native-clock-and-input.tar.gz')
for name in ['paired-receipt.json','authentication.json']:add('target/evidence/critic-production-keyboard-wfi-native-seal01/'+name,'prior-independent-native/'+name)
base=Path('target/evidence/production-paced-policy-cold-final01/interactive-clock')
for name in ['native-clock.stdout','native-clock.stderr']:add(base/name,'renewed-native/'+name)
for name in ['crates/core/src/lib.rs','crates/core/src/time.rs','crates/core/src/dev/virtio/input/keyboard.rs','crates/core/tests/production_keyboard_host_wait.rs','crates/core/tests/production_keyboard_wfi_critic.rs','crates/wasm/src/lib.rs','web/loader.js','web/guest-clock.js']:
 b=Path(name).read_bytes();assert b==subprocess.check_output(['git','show','61eeb1b5:'+name]);add(name,'source/'+name)
files['unchanged-since-61.diff']=subprocess.check_output(['git','diff','61eeb1b5','--','crates/core','crates/wasm','web/loader.js','web/guest-clock.js','web/linux-worker.js','renderer'])
assert not files['unchanged-since-61.diff']
for name in ['production-paced-policy-guard-frozen01/report.json','production-paced-policy-guard-cold01/report.json','production-paced-policy-cold-stock02/browser/report.json','production-paced-policy-private-window04/report.json','production-paced-policy-private-window04/original-handshake.json','production-paced-policy-cold-final01/interactive-clock/production/fast-boot-images/report.json','production-paced-policy-valid-frame-carry01/report.json']:
 p=Path('target/evidence')/name;add(p,'held-components/'+name)
add(__file__,'producer/seal.py')
manifest={'schema':'keyboard-host-wait-incremental-closure-v1','head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'No runtime change. D71 native hold + D73 native timing + independently verified D72 final software/private/stock/cold and pure valid-frame carry. Prior failed wrappers remain failed.','references':references,'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())]}
files['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
p=out/'keyboard-host-wait-proof-closure.tar.gz'
with p.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as g:
  with tarfile.open(fileobj=g,mode='w') as t:
   for n,b in sorted(files.items()):
    m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;m.mode=0o644;t.addfile(m,io.BytesIO(b))
with tarfile.open(p,'r:gz') as t:
 for m in t:assert t.extractfile(m).read()==files[m.name]
r={'path':str(p.relative_to(repo)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'members':len(files),'identities':len(files)-1,'allMembersReopened':True}
(out/'keyboard-host-wait-proof-closure.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
