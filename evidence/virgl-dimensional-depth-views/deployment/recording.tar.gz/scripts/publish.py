from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, urllib.request

repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
head='9698c0a91086cd419087154875d7200efcfded69'
stage=Path('/tmp/wasmvm-dimensional-depth-view-pages-9698c0a9')
sha=lambda b:hashlib.sha256(b).hexdigest()
index=json.loads((stage/'staging-index.json').read_bytes())
assert index['head']==head and sha((stage/'staging-index.json').read_bytes())=='d3e28a85161387aa921752dbf268a60b784e01fa2810094e8925eb3c2c621142'
for row in index['records']:
    b=(stage/'web/dist'/row['path']).read_bytes()
    assert len(b)==row['bytes'] and sha(b)==row['sha256'] and len(b)<25*1024*1024
assert json.loads(Path('/tmp/wasmvm-dimensional-depth-views-cold-configuration-final/report.json').read_bytes())['exitCode']==0
command=['npx','--yes','wrangler@4.149.0','pages','deploy',str(stage/'web/dist'),'--project-name','wasm-vm','--branch','main','--commit-hash',head,'--commit-dirty=true']
started=datetime.now(timezone.utc).isoformat()
r=subprocess.run(command,cwd=stage,env=os.environ.copy(),capture_output=True,timeout=300)
(stage/'publish.stdout').write_bytes(r.stdout);(stage/'publish.stderr').write_bytes(r.stderr)
(stage/'publish.json').write_text(json.dumps(dict(command=command,head=head,startedAt=started,finishedAt=datetime.now(timezone.utc).isoformat(),exitCode=r.returncode,stdoutSha256=sha(r.stdout),stderrSha256=sha(r.stderr)),indent=2)+'\n')
assert r.returncode==0,r.stderr[-2000:].decode(errors='replace')
urls=re.findall(r'https://[a-z0-9]+\.wasm-vm\.pages\.dev',r.stdout.decode())
assert urls
config=(Path.home()/'Library/Preferences/.wrangler/config/default.toml').read_text()
token=re.search(r'^oauth_token\s*=\s*"([^"]+)"',config,re.M).group(1)
account='cc8e2f38f1862286b90e834d8f267d1a'
def scrub(v):
    if isinstance(v,dict):return {k:({'omitted':'environment values','count':len(x)} if k=='env_vars' else scrub(x)) for k,x in v.items()}
    if isinstance(v,list):return [scrub(x) for x in v]
    return v
def api(suffix):
    request=urllib.request.Request('https://api.cloudflare.com/client/v4/accounts/'+account+'/pages/projects/wasm-vm/'+suffix,headers={'Authorization':'Bearer '+token})
    with urllib.request.urlopen(request,timeout=60) as response:
        status=response.status;body=response.read()
    value=json.loads(body);assert status==200 and value['success'] is True
    return value
listing=api('deployments?per_page=25')
selected=[v for v in listing['result'] if v['url']==urls[-1]]
assert len(selected)==1
value=api('deployments/'+selected[0]['id'])
deployment=value['result']
assert deployment['environment']=='production' and deployment['latest_stage']['status']=='success'
assert deployment['deployment_trigger']['metadata']['commit_hash']==head
(stage/'cloudflare-success.json').write_text(json.dumps(scrub(value),indent=2)+'\n')
print(json.dumps(dict(status='published',head=head,id=deployment['id'],url=deployment['url'],environment=deployment['environment'],stage=deployment['latest_stage'],stagingSha256=sha((stage/'staging-index.json').read_bytes()))))
