from pathlib import Path
import difflib,hashlib,json,subprocess
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');O=ROOT/'target/evidence/virgl-known-branches-critic';base='97dc44d2fbc9284705ad81630998bb533186c9a1'
coverage=json.loads((O/'hot-llvm-cov.json').read_bytes());funcs=coverage['data'][0]['functions']
rows=[];bad=[];branches=[]
for filename in ['renderer/virgl-shader/bridge.c','renderer/virgl-shader/raw_bits.c']:
 src=(ROOT/filename).read_text();old=subprocess.check_output(['git','show',base+':'+filename],cwd=ROOT,text=True);lines=src.splitlines();added=[]
 for op,a,b,c,d in difflib.SequenceMatcher(None,old.splitlines(),lines,autojunk=False).get_opcodes():
  if op in ['insert','replace']:added.extend(range(c+1,d+1))
 fn=[f for f in funcs if any(p.endswith('/'+filename.split('/')[-1]) for p in f['filenames'])]
 for line in added:
  code=lines[line-1];points=[]
  for f in fn:
   for r in f['regions']:
    if r[7] or not f['filenames'][r[5]].endswith('/'+filename.split('/')[-1]):continue
    if r[0]<=line<=r[2]:points.append({'function':f['name'],'region':r})
  count_regions=[p for p in points if p['region'][0]==line or p['region'][2]==line]
  rows.append({'file':filename,'line':line,'source':code,'regions':count_regions})
  for p in count_regions:
   r=p['region'];x=code[max(0,r[1]-1):r[3]-1] if r[0]==r[2] else code
   if r[4]==0:bad.append({'file':filename,'line':line,'source':code,**p,'expression':x})
 for f in fn:
  for b in f.get('branches',[]):
   if b[0] in added or b[2]in added:branches.append({'file':filename,'function':f['name'],'branch':b,'source':lines[b[0]-1]})
jsfile='renderer/virgl-command/constant-domain.mjs';src=(ROOT/jsfile).read_text();old=subprocess.check_output(['git','show',base+':'+jsfile],cwd=ROOT,text=True);lines=src.splitlines(True);added=[]
for op,a,b,c,d in difflib.SequenceMatcher(None,old.splitlines(True),lines,autojunk=False).get_opcodes():
 if op in ['insert','replace']:added.extend(range(c+1,d+1))
profile=next((O/'original/hot/node-v8').glob('*.json'));script=next(s for s in json.loads(profile.read_bytes())['result']if s['url'].endswith('/'+jsfile));js=[]
for f in script['functions']:
 for r in f['ranges']:
  l=src[:r['startOffset']].count('\n')+1;e=src[:r['endOffset']].count('\n')+1
  if any(l<=p<=e for p in added):js.append({'function':f['functionName'],'range':r,'startLine':l,'endLine':e,'expression':src[r['startOffset']:r['endOffset']]if e-l<3 else src[r['startOffset']:r['startOffset']+120]})
report={'prediction':'P8-coverage','nativeChangedLines':rows,'nativeZeroNestedRegions':bad,'nativeChangedBranches':branches,'nodeChangedRanges':js,'notes':'Independent diff line map; original region/branch counts, including zero conditional subregions. No worker inventory used.'};(O/'coverage-inventory.json').write_text(json.dumps(report,indent=2)+'\n')
print('NATIVE ZERO NESTED REGIONS')
for p in bad:print(json.dumps(p))
print('CHANGED BRANCHES WITH ZERO ARM')
for p in branches:
 if not p['branch'][4]or not p['branch'][5]:print(json.dumps(p))
print('NODE ZERO CHANGED RANGES')
for p in js:
 if not p['range']['count']:print(json.dumps(p))
print('COUNTS',len(rows),len(bad),len(branches),len(js))
