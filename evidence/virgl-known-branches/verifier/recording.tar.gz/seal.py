#!/usr/bin/env python3
import pathlib,json,hashlib,tarfile,gzip,io,subprocess
P=pathlib.Path('target/evidence/virgl-known-branches-critic');DEST=pathlib.Path('evidence/virgl-known-branches/verifier');DEST.mkdir(parents=True,exist_ok=True)
H=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text())
files={}
for name in ['predictions.json','submission.diff','custody.json','authenticate.py','reexport.py','reexport.json','coverage-inventory.py','coverage-inventory.json','coverage-audit.py','coverage-audit.json','capture-audit.py','capture-audit.json','result-audit.py','result-audit.json','finish.py','judgment.json','verdict.md','historical-untracked.paths','untracked-preservation.json','hot-llvm-cov.json','cold-llvm-cov.json','supplement-hot-llvm-cov.json','supplement-cold-llvm-cov.json','hot-remerged.profdata','cold-remerged.profdata','supplement-hot-remerged.profdata','supplement-cold-remerged.profdata','hot-llvm-cov.stderr','cold-llvm-cov.stderr','supplement-hot-llvm-cov.stderr','supplement-cold-llvm-cov.stderr']:
 files[name]=(P/name).read_bytes()
for folder in ['attacks-complete','attacks-malformed-declaration','sabotage','checks']:
 for p in (P/folder).rglob('*'):
  if p.is_file():files[str(p.relative_to(P))]=p.read_bytes()
files['promoted/critic.mjs']=pathlib.Path('tools/virgl-known-branches/critic.mjs').read_bytes()
files['promoted/README.md']=pathlib.Path('tools/virgl-known-branches/README.md').read_bytes()
files['seal.py']=pathlib.Path(__file__).read_bytes()
assert 'native.profraw' in {p.split('/')[-1] for p in files}
# Compress reproducibly; no paths link outside the seal and no original evidence is overwritten.
archive=DEST/'recording.tar.gz';assert not archive.exists()
with archive.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0,compresslevel=9) as g:
  with tarfile.open(fileobj=g,mode='w',format=tarfile.USTAR_FORMAT) as t:
   for name,b in sorted(files.items()):
    assert not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
    entry=tarfile.TarInfo(name);entry.size=len(b);entry.mtime=0;entry.uid=entry.gid=0;entry.uname=entry.gname='';entry.mode=0o644;t.addfile(entry,io.BytesIO(b))
records=[{'path':name,'bytes':len(b),'sha256':H(b)} for name,b in sorted(files.items())]
index={'schema':'virgl-known-branches-critic-record-index-v1','task':'E6-T12g6m2','records':records};raw=(json.dumps(index,indent=2)+'\n').encode();(DEST/'records.json').write_bytes(raw)
judgment=read(P/'judgment.json');manifest={'schema':'virgl-known-branches-critic-seal-v1','task':'E6-T12g6m2','verdict':'verified','submittedHead':judgment['submittedHead'],'runtimeSourceHead':judgment['runtimeSourceHead'],'recordedSourceHead':judgment['recordedSourceHead'],'verifiedBase':judgment['verifiedBase'],'role':'fresh adversarial verifier, never implementer','records':len(records),'archive':{'path':'recording.tar.gz','bytes':archive.stat().st_size,'sha256':H(archive.read_bytes())},'recordIndex':{'path':'records.json','bytes':len(raw),'sha256':H(raw)},'verdict':{'path':'verdict.md','bytes':len(files['verdict.md']),'sha256':H(files['verdict.md'])},'judgmentSha256':H(files['judgment.json']),'promotedRecorderSha256':H(files['promoted/critic.mjs']),'workerEvidence':judgment['workerSeal'],'originalBinaryAuthority':[{'member':'generated/known-branch-sanitize/known-branch-test','sha256':'f6b310eca0495cc3a12601b8ab6a05c9c531c5284224b557bbfdbf2bd5915070'},{'member':'cold-generated/known-branch-sanitize/known-branch-test','sha256':'b2c7b6a3e32c0d172975fe98922e967a66ffa1f3e18a6a52044e3553387cfdd5'}],'newIndependentCases':174,'newOwnedPolicyAttacks':25,'independentSeeds':[0xa4093822,0x299f31d0],'runtimeEditedByCritic':False,'originalEvidenceEdited':False,'guestExecution':False,'productionNegotiation':False,'deployment':False,'performanceClaim':False,'historicalUntrackedPaths':4202,'historicalNulFilenameListSha256':judgment['historicalNulFilenameListSha256']}
mr=(json.dumps(manifest,indent=2)+'\n').encode();(DEST/'manifest.json').write_bytes(mr)
# Verify actual archive membership again, not just an inventory count.
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len(members)==len(records) and {m.name for m in members}==set(files)
 for m in members:
  assert m.isfile();b=t.extractfile(m).read();assert b==files[m.name]
summary={'directory':str(DEST),'members':len(records),'manifestSha256':H(mr),'archiveSha256':manifest['archive']['sha256'],'indexSha256':manifest['recordIndex']['sha256'],'verdictSha256':manifest['verdict']['sha256'],'archiveBytes':archive.stat().st_size};(P/'seal-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
