from pathlib import Path
import hashlib,json,subprocess,os
O=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm/target/evidence/virgl-known-branches-critic')
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[]
for label,prefix,bin in [('hot','hot','generated/known-branch-sanitize/known-branch-test'),('cold','cold/acceptance','cold-generated/known-branch-sanitize/known-branch-test'),('supplement-hot','hot/inherited-supplement','hot/inherited-supplement/original/known-test'),('supplement-cold','cold/acceptance/inherited-supplement','cold/acceptance/inherited-supplement/original/known-test')]:
 b=O/'original'/bin;p=O/'original'/prefix/'native' if label in ['hot','cold'] else O/'original'/prefix
 os.utime(b,(0,0)) # Archive file timestamps are zero; remove extraction-order mtime warnings without changing bytes.
 output=O/(label+'-llvm-cov.json');err=O/(label+'-llvm-cov.stderr')
 with output.open('wb')as f,err.open('wb')as e:subprocess.run(['xcrun','llvm-cov','export',str(b),'-instr-profile='+str(p/'native.profdata')],stdout=f,stderr=e,check=True)
 assert not err.read_bytes(),err
 actual=json.loads(output.read_bytes());recorded=json.loads((p/'coverage.json').read_bytes())
 wanted=recorded['data'][0]['functions'];byname={f['name']:f for f in actual['data'][0]['functions']}
 assert all(byname[f['name']]==f for f in wanted),'original coverage mismatch '+label
 # Independently remerge original raw profile, requiring byte-identical merged profile.
 merged=O/(label+'-remerged.profdata');subprocess.run(['xcrun','llvm-profdata','merge','-sparse',str(p/'native.profraw'),'-o',str(merged)],check=True)
 assert merged.read_bytes()==(p/'native.profdata').read_bytes(),'original raw profile not bound '+label
 row={'label':label,'originalBinary':bin,'binarySha256':sha(b.read_bytes()),'profrawSha256':sha((p/'native.profraw').read_bytes()),'profdataSha256':sha((p/'native.profdata').read_bytes()),'recordedCoverageSha256':sha((p/'coverage.json').read_bytes()),'reexportSha256':sha(output.read_bytes()),'exactRecordedFunctions':len(wanted),'fullOriginalFunctions':len(byname)};rows.append(row)
print(json.dumps(rows,indent=2));(O/'reexport.json').write_text(json.dumps({'prediction':'P8-coverage','originalBinaryProfileBindings':rows},indent=2)+'\n')
