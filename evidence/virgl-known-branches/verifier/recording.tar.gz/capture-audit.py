#!/usr/bin/env python3
# Independent critic: reconstruct truth and expected bytes from literal TGSI inputs.
import json,pathlib,hashlib,struct,math,re
p=pathlib.Path('target/evidence/virgl-known-branches-critic'); original=p/'original'
hash=lambda b:hashlib.sha256(b).hexdigest()
js=lambda d:json.dumps(d,separators=(',',':'),ensure_ascii=False).encode()
bits=lambda n:struct.unpack('<I',struct.pack('<f',n))[0]
number=lambda w:struct.unpack('<f',struct.pack('<I',w))[0]
def read(q):return json.loads(q.read_text())
def snapshot_words(s):return s['contexts'][0]['subContexts'][0]['bindings']['constants'][1]
def rows(seed):
 x=seed
 def nextword():
  nonlocal x
  x^=(x<<13)&0xffffffff;x^=x>>17;x^=(x<<5)&0xffffffff;x&=0xffffffff;return x
 names=['zero','word-2147483648','word-1','word-2143289345','word-4286578688','word-2147483649','swizzle-false','swizzle-true','masked-false','masked-true','partial-one','and-zero','nested-false','nested-true']
 out={}
 for name in names:
  w=[bits((nextword()%8193-4096)/256) for _ in range(4)]
  integers=[math.trunc(number(v))&0xffffffff for v in w]
  numeric=[bits(math.trunc(number(v))) for v in w]
  out[name]=(w,integers,numeric)
 return out
def truth(r):
 n=r['name']
 if n=='partial-one': assert r['prefix']==['OR TEMP[0].x, IN[1].xxxx, IMM[2].yyyy'];return True
 if n=='and-zero': assert r['prefix']==['AND TEMP[0].x, IN[1].xxxx, IMM[2].xxxx'];return False
 if n.startswith('masked-'):assert r['prefix']==['MOV TEMP[0].z, IMM[0].yyyy'];return r['predicate'][1]!=0
 m=re.fullmatch(r'IMM\[0\]\.([xyzw])\1\1\1',r['source']);assert m,r;return r['predicate']['xyzw'.index(m[1])]!=0
report={'schema':1,'status':'running','prediction':'P7: integer predicates select live literal words, byte encoding and owned packets survive real hardware; faults contradict original independently calculated word state.','recordings':[]}
for area in ['hot','cold/acceptance']:
 for seed in [608135816,2242054355,320440878]:
  q=original/area/f'gpu-{seed}'/'report.json';d=read(q);a=d['acceptance'];r={'path':str(q.relative_to(original)),'sha256':hash(q.read_bytes()),'seed':seed,'vectors':[],'pixels':[],'loops':[],'consumers':[]}
  assert a['status']=='passed' and a['fault'] is None and a['guestExecution'] is False and a['productionNegotiation'] is False
  b=d['browser'];assert b['launch']['headless'] is False
  assert not re.search(r'headless|swiftshader|llvmpipe|softpipe',str(b['actualCommandLine']),re.I)
  assert 'Apple M4 Max' in a['renderer']['renderer'] and 'ANGLE Metal' in a['renderer']['renderer']
  assert all(not z for z in d['browserErrors'].values())
  assert hash(js(a['plan']))==a['planSha256'];independent=rows(seed)
  for row in a['plan']:
   w,i,n=independent[row['name']];assert row['words']==w and row['integers']==i and row['numeric']==n and row['truth']==truth(row)
  shader_events=[e['source'] for e in a['events'] if e['call']=='shaderSource'];uniform_events=[e['words'] for e in a['events'] if e['call']=='uniform4uiv']
  for group in ['vertices','fragments','special','loops']:
   for ix,c in enumerate(a[group]):
    assert hash(c['text'].encode())==c['textSha256'];assert c['pair']['ok'];assert all(v=='' for v in c['logs'].values())
    assert c['pair']['vertex']['glsl'] in shader_events and c['pair']['fragment']['glsl'] in shader_events
    for block in c['systemBlocks']:
     assert block['name']=='VirglBlock' and block['byteLength']==656
     assert block['members']==[{'name':'winsys_adjust_y','reflectedName':'winsys_adjust_y','offset':640,'type':5126,'value':1}]
    if group=='vertices':
     assert c['mutation'] is None;assert c['reflection']==[{'name':name,'type':35666,'size':1} for name in ['gl_Position','vso_g0','vso_g1','vso_g2']]
     w,i,n=independent[c['row']['name']]
     assert ('/* proved raw UIF */ if ('+('true' if truth(c['row']) else 'false')+') {') in c['pair']['vertex']['glsl']
     for j,v in enumerate(c['vectors']):
      want=[bits(x) for x in v['position']]+[(x&0x7fffff)|0x3f000000 for x in w]+[(x>>23)|0x3f000000 for x in w]+n
      raw=bytes(v['bytes']);observed=list(struct.unpack('<16I',raw));assert hash(raw)==v['sha256'] and observed==v['observed'] and want==v['expectedWords']
      for lane,(expected,actual) in enumerate(zip(want,observed)):assert expected==actual or lane>=12 and expected&0x7fffffff==actual&0x7fffffff==0
      assert v['checkedWords']==16;r['vectors'].append({'point':f'acceptance.vertices[{ix}].vectors[{j}]','bytesSha256':hash(raw),'words':16})
    elif group=='fragments':
     words,ints,n=independent[c['row']['name']];w=(ints if c['converted'] else words)[c['lane']];want=[(w>>shift)&255 for shift in [0,8,16,24]]
     raw=bytes(c['bytes']);assert len(raw)==64 and hash(raw)==c['sha256'] and c['expectedBytes']==want and list(raw)==want*16 and c['checkedPixels']==16
     r['pixels'].append({'point':f'acceptance.fragments[{ix}]','bytesSha256':hash(raw),'pixels':16})
    elif group=='special':
     n=c['row']['name'];mode='discard' if n in ['live/kill','kill-if/raw-4286578688'] else 'negative-x' if n=='kill-if/dynamic-negative' else 'color'
     assert c['row']['mode']==mode;want=[]
     for j in range(16):want+=([23,47,71,95] if mode=='discard' or mode=='negative-x' and j%4<2 else [64,128,191,255])
     raw=bytes(c['bytes']);assert len(raw)==64 and hash(raw)==c['sha256'] and list(raw)==want and c['expectedBytes']==want
     if n.startswith('raster/'):
      words=[bits(x) for x in [.25,.5,.75,1]];assert c['bank']['words']==words and c['bank']['observed']==words and words in uniform_events
     if n=='texture/dead':assert c['pair']['fragment']['metadata']['samplers']==[]
     if n=='texture/live':assert c['sampler']=={'pixels':[64,128,191,255],'unit':1} and len(c['pair']['fragment']['metadata']['samplers'])==1
     r['pixels'].append({'point':f'acceptance.special[{ix}]','bytesSha256':hash(raw),'pixels':16})
    else:
     want=[bits(x) for x in [.25,-.5,.125,1]]*2;raw=bytes(c['bytes']);assert len(raw)==32 and hash(raw)==c['sha256'] and list(struct.unpack('<8I',raw))==want and c['expectedWords']==want and c['observed']==want
     assert c['bank']['active']==('live' in c['row']['name']);bank=[0]*184;bank[36]=1;bank[44]=bits(.5);assert c['bank']['words']==bank
     if c['bank']['active']:assert bank in uniform_events
     r['loops'].append({'point':f'acceptance.loops[{ix}]','bytesSha256':hash(raw),'words':8,'bankActive':c['bank']['active']})
  for ix,c in enumerate(a['consumers']):
   assert len(c['submissions'])==7 and c['asynchronous']==bool(ix)
   for j,s in enumerate(c['submissions']):
    assert len(s['before'])==len(s['after']) and all(z==255 for z in s['after'])
    if j:
     u=list(struct.unpack('<187I',bytes(s['before'])));word=[0x3fc00000,0xc0000000,0,0x4f000000,0xcf000001,0x7f800000][j-1]
     assert u[0]&0xff==12 and u[1:4]==[1,0,word] and u[4:]==[0]*183
    else:assert s['result']['appliedCommands']==5
    assert s['result']['ok']==(j<6)
    if ix and j<6:assert s['begin']['ok'] and len(s['steps'])<128 and s['steps'][-1]['status']=='done'
   for j,capture in enumerate(c['captures']):
    want=[[0x3fc00000,0,0,0],[0xc0000000,0,0,0],[0,0,0,0]][j];assert capture['observed']==want and snapshot_words(capture['snapshot'])==want+[0]*180
   for j,deferred in enumerate(c['deferredBanks']):
    assert deferred['word']==[0x4f000000,0xcf000001][j] and deferred['result']['ok'];assert deferred['observed']==deferred['prior']==[0]*4
    assert snapshot_words(deferred['snapshot'])==[deferred['word']]+[0]*183
   assert c['rejection']['result']['ok'] is False and c['rejection']['result']['appliedCommands']==0 and c['rejection']['before']==c['rejection']['after']
   assert all(z==0 for z in c['finalBudgets'].values()) and all(z==0 for z in c['finalResourceBudgets'].values())
   assert not any(len(e)==184 and e[0] in [0x4f000000,0xcf000001,0x7f800000] for e in uniform_events)
   r['consumers'].append({'point':f'acceptance.consumers[{ix}]','asynchronous':bool(ix),'ownedPacketMutations':7,'safeReadbacks':3,'unsafeUploads':0,'rejectedStateUnchanged':True,'finalBudgets':c['finalBudgets'],'finalResourceBudgets':c['finalResourceBudgets']})
  assert a['checkedWords']==480 and a['checkedPixels']==1968 and a['objects']=={'created':1127,'live':0}
  assert len(r['vectors'])==28 and len(r['pixels'])==123 and len(r['loops'])==4
  for key in ['screenshot','browserCoverage']:
   v=d[key];assert hash((q.parent/v['path']).read_bytes())==v['sha256']
  report['recordings'].append(r)
report['faults']=[]
for area in ['hot','cold/acceptance']:
 for fault in ['word','control']:
  q=original/area/f'fault-{fault}'/'report.json';d=read(q);a=d['acceptance'];assert a['status']=='failed' and a['fault']==fault and a['objects']['live']==0
  c=a['vertices'][0];m=c['mutation'];assert m['original']==c['pair']['vertex']['glsl'] and m['served']==m['original'].replace(m['needle'],m['replacement'],1) and m['served']!=m['original']
  assert m['served'] in [e['source'] for e in a['events'] if e['call']=='shaderSource']
  w,i,n=rows(608135816)['zero'];v=c['vectors'][0];want=[bits(z) for z in v['position']]+[(z&0x7fffff)|0x3f000000 for z in w]+[(z>>23)|0x3f000000 for z in w]+n
  raw=bytes(v['bytes']);obs=list(struct.unpack('<16I',raw));assert hash(raw)==v['sha256'] and v['observed']==obs and v['expectedWords']==want
  contradictions=[{'lane':lane,'expected':expected,'actual':actual} for lane,(expected,actual) in enumerate(zip(want,obs)) if expected!=actual and not(lane>=12 and expected&0x7fffffff==actual&0x7fffffff==0)]
  assert len(contradictions)==(1 if fault=='word' else 11)
  if fault=='word':assert contradictions==[{'lane':4,'expected':1060528128,'actual':1060528129}]
  report['faults'].append({'path':str(q.relative_to(original)),'sha256':hash(q.read_bytes()),'point':'acceptance.vertices[0].vectors[0]','bytesSha256':hash(raw),'contradictions':contradictions,'actualSubmittedFault':True})
report['status']='passed';(p/'capture-audit.json').write_text(json.dumps(report,indent=2)+'\n');print('Authenticated six literal GPU recordings, owned sync/async banks and four actual submitted-source fault recordings; all independent byte predictions held.')
