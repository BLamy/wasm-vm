from pathlib import Path, PurePosixPath
import hashlib, json, subprocess, tarfile
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
OUT=ROOT/'target/evidence/virgl-known-branches-critic'
BASE=ROOT/'evidence/virgl-known-branches/worker'
sha=lambda b:hashlib.sha256(b).hexdigest()
expected={'manifest.json':'3060fcc17713548f4ccc9e266c401449156c3fbe25d3a9885a4b3506117a1b11','records.json':'3e984daf15c2d029330251a1653d69efbd07f1e5df6d5fb29fa1cdb44ce21da3','recording.tar.gz':'c5cf668e9591991c253a976104e2bf7a9f95825e4baac6aa645897164fc23e29'}
for p,d in expected.items():assert sha((BASE/p).read_bytes())==d,p
m=json.loads((BASE/'manifest.json').read_bytes());i=json.loads((BASE/'records.json').read_bytes())
assert m['sourceHead']==i['sourceHead']=='8e6e3848b2df4a3bf5703a517e33d345e3b0c96c'
assert m['recordIndex']['sha256']==expected['records.json'] and m['archive']['sha256']==expected['recording.tar.gz']
assert (BASE/'recording.tar.gz').stat().st_size==m['archive']['bytes']==13227552
index={e['path']:e for e in i['records']};assert len(index)==len(i['records'])==m['records']==146
original=OUT/'original';original.mkdir(exist_ok=True)
rows=[]
with tarfile.open(BASE/'recording.tar.gz','r:gz') as t:
 members=t.getmembers();assert len(members)==len(index) and len({e.name for e in members})==len(members)
 assert {e.name for e in members}==set(index)
 for e in members:
  assert e.isfile() and not PurePosixPath(e.name).is_absolute() and '..' not in PurePosixPath(e.name).parts,e.name
  b=t.extractfile(e).read();rec=index[e.name];assert len(b)==e.size==rec['bytes'] and sha(b)==rec['sha256'],e.name
  p=original/e.name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists(),str(p);p.write_bytes(b);rows.append(rec)
source_rows=[]
for prefix,rname,digest in [('hot','hot/receipt.json',m['hotReceiptSha256']),('cold/acceptance','cold/acceptance/receipt.json',m['coldReceiptSha256'])]:
 raw=(original/rname).read_bytes();assert sha(raw)==digest
 r=json.loads(raw);assert r['gitHead']==m['sourceHead'] and r['status']=='passed'
 for rec in r['records']:
  b=(original/prefix/rec['path']).read_bytes();assert len(b)==rec['bytes'] and sha(b)==rec['sha256'],rec['path']
 for e in r['sources']:
  if e['path'].startswith('renderer/virgl-shader/build/'):
   p=original/('generated' if prefix=='hot' else 'cold-generated')/e['path'].removeprefix('renderer/virgl-shader/build/')
   # Only sealed generated executables/modules and old immutable fixtures are required here.
   if not p.exists():continue
   b=p.read_bytes()
  else:
   b=subprocess.check_output(['git','show',m['sourceHead']+':'+e['path']],cwd=ROOT)
   assert (ROOT/e['path']).read_bytes()==b,'tracked runtime/source drift '+e['path']
  assert len(b)==e['bytes'] and sha(b)==e['sha256'],e['path'];source_rows.append({'receipt':prefix,**e})
cr=(original/'cold/report.json').read_bytes();assert sha(cr)==m['coldReportSha256']
c=json.loads(cr);assert c['cloneHead']==c['gitHead']==m['sourceHead'] and c['status']=='passed' and c['exitCode']==0 and c['statusBefore']==c['statusAfter']==''
assert sha((original/'cold/cold.log').read_bytes())==c['logSha256']
for p in ['generated/known-branch-sanitize/known-branch-test','cold-generated/known-branch-sanitize/known-branch-test','generated/native/virgl-shader','cold-generated/native/virgl-shader','hot/legacy-original/virgl-shader','hot/inherited-supplement/original/known-test','cold/acceptance/inherited-supplement/original/known-test']:(original/p).chmod(0o755)
report={'task':'E6-T12g6m2','prediction':'P1-custody','status':'HELD','workerSeals':expected,'sourceHead':m['sourceHead'],'submissionHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'memberCount':len(rows),'authenticatedMembers':rows,'authenticatedSources':source_rows,'receipts':{'hot':m['hotReceiptSha256'],'cold':m['coldReceiptSha256']},'cold':c}
(OUT/'custody.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'HELD','members':len(rows),'sourceBindings':len(source_rows),'cold':c,'reportSha256':sha((OUT/'custody.json').read_bytes())}))
