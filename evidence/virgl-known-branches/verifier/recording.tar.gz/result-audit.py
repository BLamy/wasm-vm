#!/usr/bin/env python3
import json,pathlib,hashlib,tarfile,re,struct
P=pathlib.Path('target/evidence/virgl-known-branches-critic');O=P/'original'
hash=lambda b:hashlib.sha256(b).hexdigest()
js=lambda d:json.dumps(d,separators=(',',':'),ensure_ascii=False).encode()
read=lambda p:json.loads(p.read_text())
report={'schema':1,'prediction':'P2/P4/P6/P9: original native/Wasm singles/pairs are byte-complete equal; unchanged entire predecessor results stay exact; extensions belong to a closed v41 list; full literal originals still reject. Prior HELD seals remain immutable.','status':'running','native':[],'predecessors':[],'legacy':[]}
for area in ['hot','cold/acceptance']:
 native=read(O/area/'native/report.json');wasm=read(O/area/'wasm/report.json');consumer=read(O/area/'consumer.json');log=(O/area/'native/native.log').read_bytes()
 assert hash((O/area/'native/report.json').read_bytes())==wasm['nativeSha256']==consumer['nativeSha256']
 assert hash(log)==native['logSha256'];assert not (O/area/'native/native.stderr').read_bytes();assert native['predicateStates']==8 and native['hostRoundingModes']==4 and native['layout']==[111744,112,32448]
 parsed={};points={}
 for lineNo,line in enumerate(log.decode().splitlines(),1):
  m=re.fullmatch(r'(CASE|PAIR) (\d+) (.*)',line)
  if m:parsed[(m[1],int(m[2]))]=json.loads(m[3]);points[(m[1],int(m[2]))]=lineNo
 assert len(parsed)==506 and len(native['cases'])==len(wasm['cases'])==253
 rows=[]
 for c,w in zip(native['cases'],wasm['cases']):
  i=c['index'];assert c['name']==w['name'];assert hash(c['text'].encode())==c['textSha256'];assert c['result']==parsed[('CASE',i)]==w['result'];assert c['pairResult']==parsed[('PAIR',i)]==w['pair']
  assert c['ok']==c['result']['ok'] and c['pairOk']==c['pairResult']['ok']
  ascii_ok=not re.search(r'[^\x09\x0a\x0d\x20-\x7e]',c['text'])
  guard={'ok':False,'error':{'code':'invalid-input','message':'TGSI must be printable ASCII without NUL bytes.'}}
  assert w['facade']==(c['result'] if ascii_ok else guard) and w['facadePair']==(c['pairResult'] if ascii_ok else guard)
  if c['name'].startswith('original/') or c['name'].startswith('original-'):assert c['result']['ok'] is False and c['pairResult']['ok'] is False
  if c.get('held'):assert c['result']['metadata']['profile']==c['expectedProfile']
  rows.append({'index':i,'name':c['name'],'textSha256':c['textSha256'],'resultSha256':hash(js(c['result'])),'pairSha256':hash(js(c['pairResult'])),'logLines':[points[('CASE',i)],points[('PAIR',i)]],'ok':c['ok']})
 fixture=(O/area/'native/cases.bin').read_bytes();assert hash(fixture)==native['fixtureSha256'];assert fixture[:4]==b'VKA1'
 cursor=4
 def u():
  global cursor
  n=struct.unpack_from('<I',fixture,cursor)[0];cursor+=4;return n
 wordcount=u();probes=[]
 for i in range(wordcount):probes.append([u(),u(),u(),u()])
 assert probes==[[0,0,1069547520,1069547520],[0,1069547520,0,1069547520]];assert u()==253
 for c in native['cases']:
  stage,ok,n,m,pairok=u(),u(),u(),u(),u();text=fixture[cursor:cursor+n];cursor+=n;partner=fixture[cursor:cursor+m];cursor+=m
  assert stage==(0 if c['stage']=='vertex' else 1) and ok==c['ok'] and pairok==c['pairOk'] and text.decode()==c['text'] and partner.decode()==c['partner']
 assert cursor==len(fixture)
 report['native'].append({'area':area,'reportSha256':hash((O/area/'native/report.json').read_bytes()),'wasmSha256':hash((O/area/'wasm/report.json').read_bytes()),'logSha256':hash(log),'fixtureSha256':hash(fixture),'probes':probes,'rows':rows})
 assert consumer['getterInvocations']==0 and len(consumer['attacks'])==627 and all(c['result']['ok'] is False for c in consumer['attacks'])
 report.setdefault('policy',[]).append({'area':area,'reportSha256':hash((O/area/'consumer.json').read_bytes()),'rejectedOwnDataAttacks':len(consumer['attacks']),'getterInvocations':0})

def members(base,wanted):
 base=pathlib.Path(base);m=read(base/'manifest.json');idx=read(base/'records.json');ar=base/m['archive']['path'];assert hash(ar.read_bytes())==m['archive']['sha256'];assert hash((base/'records.json').read_bytes())==m['recordIndex']['sha256'];entries={r['path']:r for r in idx['records']};found={}
 with tarfile.open(ar,'r:gz') as tar:
  for member in tar:
   if member.name not in wanted:continue
   assert member.isfile();b=tar.extractfile(member).read();r=entries[member.name];assert len(b)==r['bytes'] and hash(b)==r['sha256'];found[member.name]=json.loads(b)
 assert set(found)==set(wanted);report['predecessors'].append({'path':str(base),'manifestSha256':hash((base/'manifest.json').read_bytes()),'archiveSha256':m['archive']['sha256'],'indexSha256':m['recordIndex']['sha256'],'bindings':[entries[n] for n in wanted]});return found
prior=members('evidence/virgl-fragment-discard/worker/revision-2',['hot/native/report.json'])['hot/native/report.json'];power=members('evidence/virgl-power/worker',['hot/native/report.json','hot/legacy.json']);known=members('evidence/virgl-known-arithmetic/worker',['hot/native/report.json','hot/legacy.json']);supp=members('evidence/virgl-known-arithmetic/worker/supplement',['hot/native.json'])['hot/native.json']
assert report['predecessors'][2]['manifestSha256']=='e211633f326cd8e43e37a1585d9c892f84fa8d1eea5f13ac00bcf98d4104d15f' and report['predecessors'][3]['manifestSha256']=='eafc73232ac1d2d807bde62ad21c8a11473b985c3ad06ee85ce3194d9c7a4841'
held=read(pathlib.Path('evidence/virgl-known-arithmetic/verifier/supplement/manifest.json'));assert hash(pathlib.Path('evidence/virgl-known-arithmetic/verifier/supplement/manifest.json').read_bytes())=='b09541da5a384c3b1edf283e6ec25725616e865cfd55eb29bc9f516192ffe532'
report['heldFinalCritic']={'manifestSha256':'b09541da5a384c3b1edf283e6ec25725616e865cfd55eb29bc9f516192ffe532','manifest':held,'classification':'Carry unchanged arithmetic, bank, physical GPU and prior attack proofs; newly touched bridge/emitter/policy dependency behavior is re-covered by entire-result lineage plus new recordings.'}
baseline=[];kl=known['hot/legacy.json'];previousext={c['name']:c for c in kl['extensions']}
for kind,cases in [('discard',prior['cases']),('power',power['hot/native/report.json']['cases']),('held',power['hot/legacy.json']['cases'])]:
 for c in cases:
  name=kind+'/'+c['name'];old=previousext.get(name,{}).get('result',c.get('result',c.get('old')));k=kl['cases'][len(baseline)]
  assert k['name']==name and k['textSha256']==hash(c['text'].encode()) and k['resultSha256']==hash(js(old)) and k['ok']==old['ok']
  baseline.append({'name':name,'source':c,'old':old,'oldPair':c['pairResult'] if kind=='discard' else None})
assert len(baseline)==10041
for kind,cases in [('known',known['hot/native/report.json']['cases']),('supplement',supp['cases'])]:
 for c in cases:baseline.append({'name':kind+'/'+c['name'],'source':c,'old':c['result'],'oldPair':c['pairResult']})
assert len(baseline)==10464
for area in ['hot','cold/acceptance']:
 d=read(O/area/'legacy.json');currentext={c['name']:c for c in d['extensions']};native=read(O/area/'native/report.json');wasm=read(O/area/'wasm/report.json');extensionlist=[];closed=read(pathlib.Path('tools/virgl-known-branches/extensions.json'))
 assert len(d['cases'])==10717 and len(d['extensions'])==177 and d['oldPairs']==2683
 for ix,b in enumerate(baseline):
  c=d['cases'][ix];src=b['source'];assert c['name']==b['name'] and c['textSha256']==hash(src['text'].encode());e=currentext.get(c['name']);assert c['extension']==bool(e)
  result=e['result'] if e else b['old'];assert c['resultSha256']==hash(js(result)) and c['ok']==result['ok']
  if e:assert e['old']==b['old'] and not b['old']['ok'] and result['ok'] and e['text']==src['text'] and result['metadata']['profile']=='virgl-webgl2-raw-bits-v41'
  if b['oldPair'] and not e:assert c['pairSha256']==hash(js(b['oldPair']))
 for ix,(n,w) in enumerate(zip(native['cases'],wasm['cases']),10464):
  c=d['cases'][ix];assert c['name']=='admission/'+n['name'] and c['textSha256']==n['textSha256'] and c['resultSha256']==hash(js(n['result'])) and c['pairSha256']==hash(js(w['facadePair']))
 for e in d['extensions']:
  assert e['textSha256']==hash(e['text'].encode()) and e['old']['ok'] is False and e['result']['ok'] is True and e['result']['metadata']['profile']=='virgl-webgl2-raw-bits-v41'
  extensionlist.append({k:e[k] for k in ['name','stage','textSha256']})
 assert extensionlist==closed
 report['legacy'].append({'area':area,'reportSha256':hash((O/area/'legacy.json').read_bytes()),'historicalWholeResultBindings':10464,'newCompleteResultBindings':253,'completePairs':2683,'closedExtensions':177,'closedListSha256':hash(pathlib.Path('tools/virgl-known-branches/extensions.json').read_bytes())})
report['cold']=read(O/'cold/report.json');assert report['cold']['status']=='passed' and report['cold']['exitCode']==0 and report['cold']['statusBefore']==report['cold']['statusAfter']=='' and report['cold']['cloneHead']=='8e6e3848b2df4a3bf5703a517e33d345e3b0c96c';assert report['cold']['logSha256']==hash((O/'cold/cold.log').read_bytes())
report['status']='passed';(P/'result-audit.json').write_text(json.dumps(report,indent=2)+'\n');print('Original hot/cold 253 complete native/Wasm singles/pairs, 627 inert hostile policies, 10464 historical result bindings, 253 new bindings and closed 177 extensions authenticated; scrubbed pristine clone report/log held.')
