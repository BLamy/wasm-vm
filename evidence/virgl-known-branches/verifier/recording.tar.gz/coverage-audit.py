#!/usr/bin/env python3
# Independent source/region audit, including nested conditional false arms.
import pathlib,json,hashlib,subprocess,re,difflib
P=pathlib.Path('target/evidence/virgl-known-branches-critic');BASE='97dc44d2fbc9284705ad81630998bb533186c9a1';HEAD='126f9454b6a8a69d6547fc938bb72b6d7673f751'
read=lambda p:json.loads(p.read_text());hash=lambda b:hashlib.sha256(b).hexdigest()
exports=[P/'hot-llvm-cov.json',P/'cold-llvm-cov.json',P/'attacks-complete/coverage.json']
profiles=[read(p)['data'][0]['functions'] for p in exports]
waivers={
 ('bridge.c',208):'CONST declarations can only use full xyzw: declaration rejects masks other than 15 unless semantic is GENERIC, which CONST never is (bridge.c:333-362). Source needed is a subset of xyzw, so a declared CONST cannot fail this mask comparison. Declared/undeclared bank arms execute independently.',
 ('bridge.c',796):'The complete syntax pass plus loop_recognize (bridge.c:547-625) accepts exactly one BRK at begin+7, inside fixed UIF/OR/FSLT/ISGE body. The predicate depends on the unknown owned count CONST[9] and unknown indirectly loaded header, with no discard in the fixed body. For a live loop, BRK is structurally live and sets exit_live; for a dead loop both pruning=true and frame.entry_live=false. Changed rejection alternatives are defensive invariant guards, not skipped supported behavior.',
 ('bridge.c',807):'The independently recorded dead-malformed-loop-frame case executes !frame->is_loop and the return during syntax validation. At semantic validation, complete syntax ensures balanced ENDLOOP atop the loop frame; loop_recognize fixes its unique pc to begin+15. A live certified loop executes the fixed live BRK and records exit_live; only a dead certified loop lacks exit_live and has dead_loop=true. The remaining semantic pc/no-exit/nondead rejection alternatives have no admissible input. Both live/dead success bodies execute in the original recording.',
 ('bridge.c',1380):'A success without raw storage or KNOWN_ARITHMETIC_USED cannot first arise from RAW_KNOWN_RETRY: its only semantic change is materializing an ADD/MUL known result (raw_bits.c:441-454), which sets RAW_KNOWN_ARITHMETIC_USED at :516. Otherwise the original successful attempt already returned at bridge.c:1370. These raw-null/no-known-bit alternatives guard an impossible successful retry state; failure and successful known-result entry arms execute.',
 ('bridge.c',1388):'A final branch success requires an actual candidate raw UIF, so raw storage exists. Without an emitted proved-edge flag (set at bridge.c:775-776), branch retry changes no live-flow semantics; known-only success would already have won at :1380, and parse-only failures cannot be repaired by numeric producer facts. Raw-null/no-branch-bit successful retry alternatives are defensive first-result invariants. Actual failed and flagged successful final retries execute.'
}
patch=subprocess.check_output(['git','diff','--unified=0',BASE+'..'+HEAD],text=True)
runtime=['renderer/virgl-shader/bridge.c','renderer/virgl-shader/raw_bits.c','renderer/virgl-shader/raw_bits.h','renderer/virgl-command/constant-domain.mjs']
hunks=[];file=None
for line in patch.splitlines():
 if line.startswith('+++ b/'):file=line[6:]
 if line.startswith('@@ '):
  m=re.search(r'\+(\d+)(?:,(\d+))?',line);start=int(m[1]);count=int(m[2] or 1);hunks.append({'file':file,'newStart':start,'newCount':count,'header':line})
report={'schema':1,'prediction':'P8: every changed runtime hunk has original executed expression/branch evidence or a specific proved invariant/static waiver. Conditional child regions are evaluated separately from parent coverage.','status':'running','sourceHead':HEAD,'base':BASE,'patchSha256':hash((P/'submission.diff').read_bytes()),'exports':[{'path':str(p),'sha256':hash(p.read_bytes())} for p in exports],'native':[],'node':[],'browser':[],'hunks':hunks}
for filename in runtime[:2]:
 src=pathlib.Path(filename).read_text();lines=src.splitlines();old=subprocess.check_output(['git','show',BASE+':'+filename],text=True).splitlines();added=set()
 for op,a,b,c,d in difflib.SequenceMatcher(None,old,lines,autojunk=False).get_opcodes():
  if op in ['insert','replace']:added.update(range(c+1,d+1))
 filenameTail=filename.split('/')[-1]
 def match_functions(profile):return [f for f in profile if any(p.endswith('/'+filenameTail) for p in f['filenames'])]
 def counts(name,region,kind):
  return [sum(r[4]+(r[5] if kind=='branches' else 0) for f in match_functions(profile) if f['name']==name for r in f.get(kind,[]) if r[:4]==region[:4] and (kind=='branches' or r[7]==region[7] and f['filenames'][r[5]].endswith('/'+filenameTail))) for profile in profiles]
 for n in sorted(added):
  source=lines[n-1];row={'file':filename,'line':n,'source':source,'points':[],'branches':[]}
  # Select the smallest actual region covering this statement position, then
  # include every child region touching the changed line, including zero children.
  allpoints=[(f,r) for f in match_functions(profiles[0]) for r in f['regions'] if r[7]==0 and f['filenames'][r[5]].endswith('/'+filenameTail) and r[0]<=n<=r[2]]
  col=len(source)-len(source.lstrip())+1
  containing=[(f,r) for f,r in allpoints if (r[0]<n or r[1]<=col) and (r[2]>n or r[3]>=col)]
  selected=[]
  if containing:
   f,r=min(containing,key=lambda v:((v[1][2]-v[1][0])*100000+v[1][3]-v[1][1]));selected.append((f,r))
  selected.extend((f,r) for f,r in allpoints if r[0]==n or r[2]==n)
  seen=set()
  for f,r in selected:
   key=(f['name'],tuple(r[:4]),r[7]);
   if key in seen:continue
   seen.add(key);c=counts(f['name'],r,'regions');point={'function':f['name'],'region':r[:4],'counts':c}
   if not sum(c):
    assert (filenameTail,n) in waivers,(filename,n,r,source);point.update(classification='waived',reason=waivers[(filenameTail,n)])
   else:point['classification']='executed'
   row['points'].append(point)
  for f in match_functions(profiles[0]):
   for b in f.get('branches',[]):
    if b[0]!=n:continue
    cc=[]
    for profile in profiles:
     candidates=[q for g in match_functions(profile) if g['name']==f['name'] for q in g.get('branches',[]) if q[:4]==b[:4]];assert len(candidates)==1;cc.append(candidates[0][4:6])
    branch={'function':f['name'],'region':b[:4],'arms':cc}
    if sum(z[0] for z in cc)==0 or sum(z[1] for z in cc)==0:
     assert (filenameTail,n) in waivers,(filename,n,b,source);branch.update(classification='waived-zero-arm',reason=waivers[(filenameTail,n)])
    else:branch['classification']='both-arms-executed'
    row['branches'].append(branch)
  stripped=source.strip()
  if not stripped or stripped in ['{','}','} else {','else {'] or stripped.startswith(('/*','*','static bool live_loop','static void branch_contract','static const char *check_input_attempt','int raw_uif_truth')):
   row['classification']='static-syntax-waived';row['reason']='Comment, type/signature or brace introduces no independent runtime state; body statements/child regions audited separately.'
  else:
   assert row['points'],(filename,n,source);row['classification']='executed-with-listed-invariant-waivers' if any(v['classification']=='waived' for v in row['points']) else 'executed'
  report['native'].append(row)
jsfile=runtime[3];src=pathlib.Path(jsfile).read_text();old=subprocess.check_output(['git','show',BASE+':'+jsfile],text=True);added=set()
for op,a,b,c,d in difflib.SequenceMatcher(None,old.splitlines(),src.splitlines(),autojunk=False).get_opcodes():
 if op in ['insert','replace']:added.update(range(c+1,d+1))
# Source is ASCII. Thus byte and V8 UTF-16 offsets are identical, verified.
assert src.isascii();sourcehash=hash(src.encode());report['javascriptSourceSha256']=sourcehash
for area in ['hot','cold/acceptance']:
 profile=next((P/'original'/area/'node-v8').glob('*.json'));d=read(profile);script=next(s for s in d['result'] if s['url'].endswith('/'+jsfile));rows=[]
 for f in script['functions']:
  for r in f['ranges']:
   start=src[:r['startOffset']].count('\n')+1;end=src[:r['endOffset']].count('\n')+1
   if any(start<=n<=end for n in added):assert r['count']>0;rows.append({'function':f['functionName'],'range':r,'lines':[start,end]})
 report['node'].append({'path':str(profile),'sha256':hash(profile.read_bytes()),'rows':rows})
 for seed in [608135816,2242054355,320440878]:
  q=P/'original'/area/f'gpu-{seed}'/'browser-coverage.json';d=read(q);script=next(s for s in d['scripts'] if s['source']==jsfile);assert script['sha256']==sourcehash;rows=[]
  for f in script['coverage']['functions']:
   for r in f['ranges']:
    start=src[:r['startOffset']].count('\n')+1;end=src[:r['endOffset']].count('\n')+1
    if any(start<=n<=end for n in added):rows.append({'function':f['functionName'],'range':r,'lines':[start,end]})
  # The real owned-bank consumer must execute parse+branch policy and conversion-bank.
  for name in ['parseConstantDomain','checkConversionBank']:
   assert any(r['function']==name and r['range']['count']>0 for r in rows)
  assert any(r['lines']==[146,158] and r['range']['count']>0 for r in rows)
  report['browser'].append({'path':str(q),'sha256':hash(q.read_bytes()),'rows':rows})
for h in hunks:
 f=h['file']
 if f in runtime[:2]:
  h['classification']='native-region-audited' if h['newCount'] else 'deleted-code';h['points']=[n['line'] for n in report['native'] if h['newStart']<=n['line']<h['newStart']+h['newCount']]
 elif f==runtime[2]:h.update(classification='static-layout-waived',reason='Enum/macro/prototype and bool in existing struct padding; actual hot/cold/critic LAYOUT [111744,112,32448] unchanged, all flags exercised at consumers listed in native audit.')
 elif f==jsfile:h.update(classification='original-node-and-browser-audited',reason='Original Node records cover strict hostile branches and inherited rejection; actual physical sync/async consumer profiles cover accepted branch wrapper and F2I copied-bank policy. Exact ranges and source hash listed separately.')
 elif f in ['tasks/QUEUE.md','tasks/epic-6-transcendence/E6-T12g6m2-known-branch-liveness.md','tasks/epic-6-transcendence/E6-T12g6m-larger-original-programs.md','tools/virgl-known-branches/README.md'] or f.startswith('evidence/'):h.update(classification='metadata-waived',reason='Task/queue documentation or authenticated immutable evidence bytes; no runtime path.')
 else:h.update(classification='recording-harness',reason='Actual frozen hot/cold acceptance command/log and receipts bind this proving source; fixtures complete-source hashes, request bytes, native/Wasm results and GPU bytes independently audited. No production runtime changed here.')
# Independently confirm exact supplemental native and Node child regions after anchor migration.
report['inheritedSupplement']=[]
for area,prof in [('hot',P/'supplement-hot-llvm-cov.json'),('cold/acceptance',P/'supplement-cold-llvm-cov.json')]:
 q=P/'original'/area/'inherited-supplement/report.json';d=read(q);native=read(prof)['data'][0]['functions'];assert d['status']=='passed' and len(d['nativeRegions'])==5 and len(d['v8Regions'])==2
 for v in d['nativeRegions']:
  f=next(f for f in native if f['name']==v['function']);assert v['region'] in f['regions'] and v['region'][4]>0
 v8path=next((q.parent/'node-v8').glob('*.json'));s=next(s for s in read(v8path)['result'] if s['url'].endswith('/'+jsfile))
 for r in d['v8Regions']:assert any(r==v for f in s['functions'] for v in f['ranges']) and r['count']>0
 report['inheritedSupplement'].append({'path':str(q),'sha256':hash(q.read_bytes()),'nativeRegions':d['nativeRegions'],'v8Regions':d['v8Regions'],'sourceSha256':d['v8Source']['sha256']})
report['status']='passed';(P/'coverage-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(f"{len(report['native'])} changed native lines, all {sum(len(n['branches']) for n in report['native'])} conditional branch sites and {len(hunks)} total diff hunks audited; narrow independent profile closes original zero v16/unknown-raster/v38/v39 regions; only enumerated invariant/static waivers remain.")
