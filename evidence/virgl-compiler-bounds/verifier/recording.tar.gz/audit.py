#!/usr/bin/env python3
"""Fresh critic: recompute concrete recorded state without worker oracle imports."""
from pathlib import Path
import collections
import hashlib
import json
import math
import re
import struct
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
WORKER = OUT / 'authenticated-worker'
SOURCE = '07f47569525dfa898dadd6f95dfa0a7a4a8718e4'
BASE = '60aebb0e1a4639ff4d9468067879e9789e6a5a23'
ENVELOPE = dict(textBytes=49152, tokens=8192, glslBytes=262144, instructions=768,
    registerIndex=7, temporaryRegisterIndex=511, constantRegisterIndex=45,
    immediateRegisterIndex=31, conditionalDepth=16, lines=1536, lineBytes=512)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def bind(path):
    raw = path.read_bytes()
    return dict(path=str(path.relative_to(OUT)), bytes=len(raw), sha256=sha(raw))


def u32(value):
    return struct.unpack('<I', struct.pack('<f', value))[0]


def packet(stage, text, tokens=8192):
    raw = text.encode('ascii')
    words = (len(raw) + 4) // 4
    return struct.pack('<6I', ((words + 5) << 16) | (4 << 8) | 1,
        1, 0 if stage == 'vertex' else 1, len(raw) + 1, tokens, 0) + raw + bytes(words * 4 - len(raw))


def parse_body(text):
    operations=[]
    for line in text.splitlines():
        line = re.sub(r'^\s*\d+:\s*', '', line).strip()
        if not line or line.split()[0].split('[')[0] in ['VERT','FRAG','DCL','IMM','PROPERTY','END']:
            continue
        operations.append(line)
    depth = maximum = 0
    for line in operations:
        opcode=line.split()[0]
        if opcode in ['UIF','BGNLOOP']:
            depth += 1; maximum = max(maximum,depth)
        if opcode in ['ENDIF','ENDLOOP']:
            depth -= 1
    return dict(nonEndInstructions=len(operations), maxDepth=maximum, finalDepth=depth,
                nonblankLines=sum(bool(line.strip()) for line in text.splitlines()),
                maximumLineBytes=max(map(len,text.splitlines()),default=0))


def native(prefix):
    directory=WORKER/prefix
    n=read(directory/'native/report.json');w=read(directory/'wasm/report.json')
    assert n['gitHead']==w['gitHead']==SOURCE and n['status']==w['status']=='passed'
    assert n['envelope']==w['envelope']==ENVELOPE
    assert len(n['cases'])==len(w['cases'])==603 and len(n['pairs'])==len(w['pairs'])==23
    assert w['nativeSha256']==sha((directory/'native/report.json').read_bytes())
    raw=(directory/'native/cases.bin').read_bytes();assert sha(raw)==n['fixtureSha256']
    assert raw[:4]==b'VGB2';pos=4
    def integer():
        nonlocal pos
        value=struct.unpack_from('<I',raw,pos)[0];pos+=4;return value
    assert integer()==603
    for case,wasm,wire in zip(n['cases'],w['cases'],w['wire']):
        stage,ok,length=integer(),integer(),integer();text=raw[pos:pos+length].decode('ascii');pos+=length
        assert text==case['text'] and stage==(0 if case['stage']=='vertex' else 1) and ok==int(case['ok'])
        assert sha(text.encode())==case['textSha256']==wasm['textSha256']
        assert case['result']==wasm['result'] and type(case['result']['ok']) is bool and case['result']['ok']==case['ok']
        if not case['ok']:
            assert not {'glsl','vertex','fragment'} & set(case['result'])
        assert sha(packet(case['stage'],text))==wire['packetSha256']
        assert wire['result']['ok']==(length<=49152)
        if wire['result']['ok']:
            assert wire['result']['commands'][0]['fields']['text']==text
    assert integer()==23
    for pair,wasm in zip(n['pairs'],w['pairs']):
        v,f,ok=integer(),integer(),integer()
        assert (v,f,ok)==(pair['vertex'],pair['fragment'],int(pair['ok']))
        assert pair['result']==wasm['result']
    assert pos==len(raw)
    lines=(directory/'native/native.log').read_text().splitlines();assert lines[-1]=='STATUS passed'
    assert (directory/'native/native.stderr').read_bytes()==b''
    logged=[json.loads(line.split(' ',2)[2]) for line in lines if line.startswith('CASE ')]
    assert logged==[e['result'] for e in n['cases']]
    assert len(n['allocationFaults'])==752
    for fault in n['allocationFaults']:
        assert fault['result']['ok'] is False and not {'glsl','vertex','fragment'} & set(fault['result'])
    faults=collections.Counter(f['requestedBytes'] for f in n['allocationFaults'])
    assert all(faults[size] for size in [111744,433092,207884,262145])
    assert n['writers']==dict(glslLimit=262144,singleWorstEscapedBytes=262144*6+2,
        pairWorstEscapedBytes=262144*12+4,shortCapacity=128,status='passed')
    assert n['layout']==dict(ir=111744,profile=32440,flow=433092,frame=27068,raster=207884,
        conversion=33584,pairConversions=67168,singleResponse=262144*6+16384,
        pairResponse=2*(262144*6+16384)+1024,rasterQueue=1024,laneBits=16,pcBits=16)
    # These fixed-width structures contain no pointer-size-dependent fields.
    assert 27068*16+4==n['layout']['flow']
    assert (768+1)*65*4 + 1024*4 + 768*2*2 + (768+1) + 3 + 4 == n['layout']['raster']
    assert 768*112 + 32*4*4 + 512*4*12 + 8*4*12 + 256 == n['layout']['ir']
    names={e['name']:e for e in n['cases']};boundaries=[]
    for stage in ['vertex','fragment']:
        for kind in ['high','long','deep','combined','targets','raster-long','raster-deep','legacy-long','legacy-imm','text-limit']:
            e=names[kind+'-'+stage];point=parse_body(e['text'])
            assert e['result']['ok'] is True
            if kind in ['long','combined','raster-long','legacy-long']:assert point['nonEndInstructions']==768
            if kind in ['deep','combined','targets','raster-deep']:assert point['maxDepth']==16 and point['finalDepth']==0
            if kind=='text-limit':assert len(e['text'])==49152
            boundaries.append(dict(name=e['name'],**point,glslBytes=len(e['result']['glsl'])))
        for kind in ['text-one-past','instruction-one-past','temp-one-past','temp-source-one-past','imm-one-past','imm-source-one-past','depth-one-past','join-initialization','line-limit','wrong-target','target-one-past','late-undefined','glsl-truncation']:
            assert names[kind+'-'+stage]['result']['ok'] is False
    memory=w['fixedMemory'];assert memory['bytes']==16777216 and memory['stackBytes']==262144
    assert memory['exhausted']['ok'] is False and memory['recovered'] is True and memory['allocations']>0
    assert [e['result']['ok'] for e in w['wire'][-4:]]==[False,True,False,False]
    assert w['wireEnvelope']['shaderTextBytes']==49152 and w['wireEnvelope']['shaderTokens']==8192
    frame_rows=[]
    for filename in ['bridge.su','raw_bits.su']:
        for line in (directory/'stack'/filename).read_text().splitlines():
            location,size,kind=line.split('\t');assert kind=='static'
            frame_rows.append(dict(location=location,bytes=int(size)))
    assert sum(e['bytes'] for e in frame_rows)==235392<262144
    return dict(prefix=prefix,report=bind(directory/'native/report.json'),
        caseInput=bind(directory/'native/cases.bin'),cases=603,pairs=23,
        allocationFaults=dict(sorted(faults.items())),boundaries=boundaries,
        fixedMemory=memory,ownedStaticFramesSum=235392,
        ownedStackScope='owned nonrecursive optimized frames only; excludes upstream/libc')


def oracle(kind, stage, vector):
    if kind=='legacy-imm':return [.25,.5,.75,1]
    if kind=='legacy':return vector['position'] if stage=='vertex' else vector['a']
    if kind=='raster':return vector['a'][:3]+[vector['alpha']]
    if kind=='raster-deep':return vector['a'][:3]+[vector['baseAlpha'] if vector['condition'][0]<0 else vector['alpha']]
    assert kind in ['high','long','deep','combined','targets']
    return vector['a'] if vector['condition'][0]<0 else vector['b']


def physical(path, failed=False):
    report=read(path);gpu=report['acceptance'];sources={e['path']:e['sha256'] for e in report['sources']}
    assert report['gitHead']==SOURCE and report['trackedChanges']==[]
    assert report['status']==gpu['status']==('failed' if failed else 'passed')
    assert report['browserErrors']==dict(console=[],page=[],requests=[])
    browser=report['browser'];assert browser['launch']['headless'] is False
    assert browser['gpu']['featureStatus'][browser['webglFeature']]=='enabled'
    assert 'Apple M4 Max' in gpu['renderer']['renderer'] and 'ANGLE' in gpu['renderer']['renderer']
    assert not re.search('swiftshader|llvmpipe|softpipe|software',gpu['renderer']['renderer'],re.I)
    assert not any(re.search('swiftshader|--disable-gpu(?:$|=)',s,re.I) for s in browser['actualCommandLine'])
    for item in report['servedFiles']:
        assert item['sha256']==sources[item['path']]
    module=next(e for e in report['servedFiles'] if e['path'].endswith('virgl-shader.wasm'))
    assert module['sha256']==sha((WORKER/'generated/wasm/virgl-shader.wasm').read_bytes())
    coverage=read(path.parent/report['browserCoverage']['path']);assert sha((path.parent/report['browserCoverage']['path']).read_bytes())==report['browserCoverage']['sha256']
    assert all(e['sha256']==sources[e['source']] for e in coverage['scripts'])
    screen=report.get('screenshot',report.get('failureScreenshot'));assert sha((path.parent/screen['path']).read_bytes())==screen['sha256']
    live=set();created=0;shader_sources=[]
    for event in gpu['events']:
        if event['call'].startswith('create'):
            assert event['id'] not in live;live.add(event['id']);created+=1
        elif event['call'].startswith('delete'):
            assert event['id'] in live;live.remove(event['id'])
        elif event['call'] in ['compileShader','linkProgram']:
            assert event['status'] is True
        elif event['call']=='shaderSource':shader_sources.append(event['source'])
    assert not live and gpu['objects']==dict(created=created,live=0)
    word_count=pixel_count=0;fault_points=[]
    for entry in gpu['vertices']:
        assert sha(entry['source'].encode())==entry['sourceSha256']
        pair=entry['originalPair'];mutation=entry['mutation']
        assert (mutation['served'] if mutation else pair['vertex']['glsl']) in shader_sources
        assert entry['reflection']==[dict(name='gl_Position',type=35666,size=1),dict(name='vso_g0',type=35666,size=1)]
        for point in entry['vectors']:
            vector=point['vector'];wanted=list(map(u32,vector['position']+oracle(entry['kind'],'vertex',vector)))
            assert point['expectedWords']==wanted
            raw=bytes(point['bytes']);assert len(raw)==32 and sha(raw)==point['sha256']
            actual=list(struct.unpack('<8I',raw));assert actual==point['observed']
            for check in point['checks']:
                lane=check['lane'];assert check['expected']==wanted[lane] and check['actual']==actual[lane]
                if wanted[lane]!=actual[lane]:
                    assert failed and point['failure']==check
                    fault_points.append(dict(name=entry['name'],vector=vector['name'],lane=lane,
                        expected=wanted[lane],observed=actual[lane],rawSha256=point['sha256']))
                word_count+=1
            for a in point['attributes']:
                inputs=[vector['position'],vector['a'],vector['b'],vector['condition']]
                assert a['words']==list(map(u32,inputs[a['index']]))
            for upload in point['uploads']:
                assert upload['type']==36296 and upload['count']==46
                bank=[0]*184;bank[0]=u32(vector['baseAlpha']);bank[180]=u32(vector['alpha'])
                assert upload['words']==upload['observed']==bank and upload['checked']['ok'] is True
    for entry in gpu['fragments']:
        assert sha(entry['source'].encode())==entry['sourceSha256']
        assert entry['originalPair']['fragment']['glsl'] in shader_sources
        for point in entry['draws']:
            wanted=[math.floor(min(1,max(0,x))*255+.5) for x in oracle(entry['kind'],'fragment',point['vector'])]
            assert point['expectedBytes']==wanted and point['pixelBudget']==1
            raw=bytes(point['rgbaBytes']);assert len(raw)==256 and sha(raw)==point['sha256']
            assert all(abs(value-wanted[i%4])<=1 for i,value in enumerate(raw))
            assert point['checkedPixels']==64;pixel_count+=64
    if not failed:
        assert word_count==gpu['checkedWords']==3456 and pixel_count==gpu['checkedPixels']==27648
        assert len(gpu['vertices'])==len(gpu['fragments'])==9
        for e in gpu['vertices']:assert len(e['vectors'])==48 and sum(v['vector']['condition'][0]<0 for v in e['vectors'])==24
        for e in gpu['fragments']:assert len(e['draws'])==48
    else:
        assert len(fault_points)==1 and 'independent bound word mismatch' in gpu['failure']['message']
    return dict(record=bind(path),seed=gpu['seed'],fault=gpu['fault'],words=word_count,pixels=pixel_count,
        objectsCreatedAndDeleted=created,independentFaultPoints=fault_points,
        oracle='dyadic input values/sign-bit A-or-B selection/literal IMM31/CONST45 or CONST0 alpha; no GLSL or IR interpreter')


def retained(prefix):
    directory=WORKER/prefix;r=read(directory/'retained/report.json')
    assert len(r['originals'])==25 and sum(e['native']['ok'] for e in r['originals'])==23
    for e in r['originals']:
        raw=(ROOT/e['path']).read_bytes();assert sha(raw)==e['sha256'] and len(raw)==e['bytes']
        assert e['native']==e['wasm']
        if e['sha256'].startswith('92cb866a'):
            assert len(raw)==39261 and e['old']['error']['code']=='input-too-large' and e['native']['error']['code']=='unsupported-feature'
        else:assert e['old']==e['native']
    assert len(r['historical'])==112
    assert [e['name'] for e in r['historical'] if not e['old']['ok'] and e['native']['ok']]==['oversized-temp-range']
    assert [e['name'] for e in r['historical'] if e['changed']]==['oversized-temp-range']
    original=read(directory/'retained-f6-native/report.json');wasm=read(directory/'retained-f6-wasm/report.json')
    assert len(original['originals'])==19 and len(original['pairs'])==88 and sum(e['ok'] for e in original['pairs'])==57
    assert wasm['nativeSha256']==sha((directory/'retained-f6-native/report.json').read_bytes())
    assert wasm['memory']==dict(initialBytes=16777216,finalBytes=16777216,sameBuffer=True)
    f6=read(directory/'retained-f6-gpu/report.json');gears=read(directory/'retained-gears-gpu/report.json')
    assert f6['status']==gears['status']=='passed'
    assert f6['browserErrors']==gears['browserErrors']==dict(console=[],page=[],requests=[])
    assert gears['acceptance']['checkedVertexWords']==864 and gears['acceptance']['checkedPixels']==9216
    return dict(prefix=prefix,record=bind(directory/'retained/report.json'),unchangedEmissionsAndMetadata=23,
        rejectedOriginals=[e['sha256'] for e in r['originals'] if not e['native']['ok']],
        historicalMigration='oversized-temp-range',f6Pairs=88,f6CompatiblePrograms=57,
        carriedHeld='prior F6/G6a oracles and exact-alpha contract unchanged; current authenticated physical reruns retain them')


def coverage_audit():
    coverage=read(WORKER/'hot/native/coverage.json')
    functions={e['name']:e for d in coverage['data'] for e in d['functions']}
    for name in ['register_limit','validate_body','flow_snapshot','flow_join','raw_record','raster_graph','raw_certify_raster_outputs','raw_emit','bridge_translate_pair','writer_limits']:
        assert any(e['count']>0 and (key.endswith(':'+name) or key==name) for key,e in functions.items())
    files={Path(e['filename']).name:e for d in coverage['data'] for e in d['files']}
    diff=subprocess.check_output(['git','diff','--unified=0',BASE+'..'+SOURCE,'--','renderer/virgl-shader/bridge.c','renderer/virgl-shader/raw_bits.c'],cwd=ROOT,text=True)
    points=[];filename=None;number=0
    for line in diff.splitlines():
        if line.startswith('+++ b/'):
            filename=Path(line[6:]).name
        elif line.startswith('@@'):
            number=int(re.search(r'\+(\d+)',line).group(1))
        elif line.startswith('+') and not line.startswith('+++'):
            code=line[1:];segments=[e for e in files[filename]['segments'] if e[0]==number and e[3]]
            hits=max([e[2] for e in segments],default=0)
            if '_Static_assert' in code or 'enum { FLOW_DEPTH' in code or code.lstrip().startswith(('*','/*')):
                state='WAIVED';reason='compile-time capacity/layout assertion or comment; measured allocations and address/depth witnesses bind its consequence'
            elif 'frames[BRIDGE_MAX_FLOW_DEPTH]' in code:
                state='EXECUTED';reason='raster_graph hit112 times; raster-deep sources with depth16 use frame15; local array is measured in optimized stack tables'
            elif 'unsigned temporaries =' in code or ('emit(&w,' in code and hits==0):
                state='EXECUTED';reason='raw_emit1418 calls; successful high/combined sources contain raw_temp512 and float_temp512, and physical reads address row511'
            elif hits:
                state='EXECUTED';reason='authenticated LLVM region/segment count'
            else:
                assert code.strip().startswith(('file == IMM','"bounded conditional','"'));state='EXECUTED';reason='continuation of covered expression or diagnostic string'
            points.append(dict(file='renderer/virgl-shader/'+filename,line=number,code=code,
                classification=state,hits=hits,reason=reason));number+=1
        elif line.startswith(' '):number+=1
    # Overflow inside raster_graph is unreachable from a validated public IR:
    # control rejects nesting17 first. The false comparison and deepest valid
    # write execute; demanding that redundant true edge would require invalid IR.
    return dict(record=bind(WORKER/'hot/native/coverage.json'),points=points,
        functionCounts={key:e['count'] for key,e in functions.items() if any(key.endswith(':'+name) or key==name for name in ['register_limit','validate_body','flow_snapshot','flow_join','raster_graph','raw_emit','writer_limits'])},
        redundantRasterOverflow='WAIVED true edge: complete public validation rejects depth17 before raster analysis; depth16 frame15 and false guard are exercised',
        lineCountCeiling='WAIVED overflow edge: unique declarations (512 TEMP+46 CONST+8 each IN/OUT/SAMP/SVIEW+1 ADDR),32 IMM,768 non-END,one PROPERTY/header/END total at most1394 nonblank grammar lines below1536',
        otherHunks=[
            dict(paths=['bridge.h','raw_bits.h','index.mjs LIMITS','decoder.mjs LIMITS'],classification='WAIVED configuration/types',reason='all exposed ceilings, exact allocation layouts and width calculations match deterministic witnesses'),
            dict(paths=['index.mjs capacity error paths','decoder.mjs shader text ceiling'],classification='EXECUTED',reason='recorded public exact49152/one-past49153, paired oversize vertex/fragment, and wire cases/tokens/padding'),
            dict(paths=['build.sh compiler-bounds-sanitize/wasm-stack','Makefile verify target'],classification='EXECUTED',reason='both exact-source acceptance logs contain those commands and generated source/binary/stack hashes are authenticated'),
            dict(paths=['new native/browser/receipt/cases/cold/seal harnesses','retained fixtures and capacity migrations'],classification='EXECUTED/WAIVED harness failure reporting',reason='both authenticated accepts, fault runs, original/capacity migrations and closure records exercise assertions; failure logging has no product semantics'),
            dict(paths=['README files','tasks decomposition and queue'],classification='WAIVED declarative documentation/metadata',reason='no product runtime; later unsupported grammar and production boundaries remain gated')])


def main():
    authentication=read(OUT/'authentication.json');assert authentication['status']=='passed'
    assert authentication['sourceBindingsSha256']==sha((OUT/'source-bindings.json').read_bytes())
    native_checks=[native(prefix) for prefix in ['hot','cold/acceptance']]
    physical_checks=[]
    for prefix in ['hot','cold/acceptance']:
        for seed in [588730525,2202774047,4195890887]:
            physical_checks.append(physical(WORKER/prefix/f'gpu-{seed}/report.json'))
        for fault in ['high-register','branch-join','counter']:
            physical_checks.append(physical(WORKER/prefix/f'fault-{fault}/report.json',failed=True))
    physical_checks.append(physical(OUT/'gpu-independent-1875794577/report.json'))
    retained_checks=[retained(prefix) for prefix in ['hot','cold/acceptance']]
    code_coverage=coverage_audit()
    guard=read(OUT/'independent-joins.json');assert guard['status']=='passed' and guard['cases']==402
    assert len(guard['native'])==len(guard['wasm'])==402 and all(a['result']==b['result'] for a,b in zip(guard['native'],guard['wasm']))
    promoted=read(OUT/'promoted-guard.json');assert promoted['status']=='passed' and promoted['cases']==402
    assert [e['result'] for e in promoted['native']]==[e['result'] for e in guard['native']]
    assert [e['result'] for e in promoted['wasm']]==[e['result'] for e in guard['wasm']]
    sabotage=read(OUT/'sabotage.json');assert sabotage['status']=='caught' and sabotage['expected'] is False and sabotage['observed'] is True
    assert sha((OUT/'sabotage-join-report.json').read_bytes())==sabotage['reportSha256']
    cold=read(WORKER/'cold/report.json');assert cold['status']=='passed' and cold['gitHead']==cold['cloneHead']==SOURCE and not cold['statusBefore'] and not cold['statusAfter']
    diff=(OUT/'frozen.diff').read_text();assert not re.search(r'^\+.*(?:NDEBUG|#\[ignore\]|assert.*disabled)',diff,re.M)
    report=dict(schema='virgl-compiler-bounds-critic-audit-v1',status='passed',verdict='verified',
        sourceHead=SOURCE,submissionHead='9921c1c0df69a0e4572bf4154cbd9fb2deeff264',native=native_checks,
        physical=physical_checks,retained=retained_checks,coverage=code_coverage,
        independentJoinGuard=bind(OUT/'independent-joins.json'),joinCases=402,
        promotedGuard=bind(OUT/'promoted-guard.json'),
        promotedGuardSha256=sha((ROOT/'renderer/virgl-shader/tests/compiler-bounds-joins.mjs').read_bytes()),
        sabotage=bind(OUT/'sabotage.json'),findings=[],
        performanceClaim=False,productionNegotiation=False,guestExecution=False)
    (OUT/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Independent audit passed: 603 cases/23 pairs/752 allocation faults hot+cold; 402 fresh join/bank/line/text cases; physical words/pixels recomputed without worker oracle imports; changed runtime hunks covered or explicitly waived.')


if __name__=='__main__':
    main()
