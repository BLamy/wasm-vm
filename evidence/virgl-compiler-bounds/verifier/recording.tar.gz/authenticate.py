#!/usr/bin/env python3
"""Authenticate worker archive members, source tree and pristine-clone receipt."""
from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
WORKER=ROOT/'evidence/virgl-compiler-bounds/worker'
EXTRACTED=OUT/'authenticated-worker'
SOURCE='07f47569525dfa898dadd6f95dfa0a7a4a8718e4'
SUBMISSION='9921c1c0df69a0e4572bf4154cbd9fb2deeff264'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    manifest=json.loads((WORKER/'manifest.json').read_bytes())
    index_raw=(WORKER/'records.json').read_bytes();index=json.loads(index_raw)
    archive=(WORKER/'recording.tar.gz').read_bytes()
    assert sha(archive)=='2e9a57b80f05914377f852f17c3aaf597112f269d2ea67244b1a510944601756'
    assert sha(index_raw)=='77214cdb6c845547d9985015bee862323a06cc8f401380d64340b9c21c06fcf7'
    assert len(archive)==manifest['archive']['bytes'] and sha(archive)==manifest['archive']['sha256']
    assert len(index_raw)==manifest['recordIndex']['bytes'] and sha(index_raw)==manifest['recordIndex']['sha256']
    assert manifest['sourceHead']==index['sourceHead']==SOURCE
    records={e['path']:e for e in index['records']}
    assert len(records)==len(index['records'])==104
    with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
        members=tar.getmembers()
        assert len(members)==len({m.name for m in members})==104
        assert {m.name for m in members}==set(records)
        for member in members:
            assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
            raw=tar.extractfile(member).read();entry=records[member.name]
            assert len(raw)==member.size==entry['bytes'] and sha(raw)==entry['sha256']
            path=EXTRACTED/member.name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
    checks=[];cache={};source_lists={}
    for filename in ['hot/receipt.json','cold/acceptance/receipt.json']:
        receipt=json.loads((EXTRACTED/filename).read_bytes())
        assert receipt['status']=='passed' and receipt['gitHead']==SOURCE
        assert len({e['path'] for e in receipt['sources']})==len(receipt['sources'])==1514
        for entry in receipt['records']:
            raw=(EXTRACTED/Path(filename).parent/entry['path']).read_bytes()
            assert len(raw)==entry['bytes'] and sha(raw)==entry['sha256']
        for entry in receipt['sources']:
            name=entry['path']
            if name.startswith('renderer/virgl-shader/build/'):
                raw=(EXTRACTED/'generated'/name.removeprefix('renderer/virgl-shader/build/')).read_bytes()
                if filename.startswith('cold') and sha(raw)!=entry['sha256']:
                    assert name=='renderer/virgl-shader/build/compiler-bounds-sanitize/compiler-bounds-test'
                    checks.append(dict(coldGeneratedIndependent=name,bytes=entry['bytes'],sha256=entry['sha256'],
                        scope='independent native sanitizer binary has clone-specific debug paths; cold profile/log/input/source digests are authenticated'))
                    continue
            else:
                if name not in cache:
                    cache[name]=subprocess.check_output(['git','show',SOURCE+':'+name],cwd=ROOT)
                raw=cache[name]
                assert (ROOT/name).read_bytes()==raw,'source drift: '+name
            assert len(raw)==entry['bytes'] and sha(raw)==entry['sha256'],'source digest: '+name
        source_lists[filename]=receipt['sources']
        checks.append(dict(path=filename,sha256=sha((EXTRACTED/filename).read_bytes()),
                           sources=len(receipt['sources']),records=len(receipt['records'])))
    cold=json.loads((EXTRACTED/'cold/report.json').read_bytes())
    assert cold['gitHead']==cold['cloneHead']==SOURCE and cold['status']=='passed' and cold['exitCode']==0
    assert not cold['statusBefore'] and not cold['statusAfter']
    assert sha((EXTRACTED/'cold/cold.log').read_bytes())==cold['logSha256']
    assert sha((EXTRACTED/'cold/acceptance/receipt.json').read_bytes())==cold['receiptSha256']
    assert subprocess.check_output(['git','diff','--name-only',SOURCE+'..'+SUBMISSION,'--',*cache.keys()],cwd=ROOT)==b''
    bindings=dict(schema='virgl-compiler-bounds-critic-source-bindings-v1',sourceHead=SOURCE,
                  submissionHead=SUBMISSION,workerArchiveSha256=sha(archive),receipts=source_lists,
                  generatedScope='hot generated files are archive members; independently built cold native sanitizer is bound by its receipt and captured profile/log/input')
    promoted=ROOT/'renderer/virgl-shader/tests/compiler-bounds-joins.mjs'
    if promoted.exists():
        raw=promoted.read_bytes()
        bindings['promotedGuards']=[dict(path=str(promoted.relative_to(ROOT)),bytes=len(raw),sha256=sha(raw))]
        delivered=[];hot_sources={e['path']:e for e in source_lists['hot/receipt.json']}
        for name in ['renderer/virgl-shader/build/native/virgl-shader',
                     'renderer/virgl-shader/build/wasm/virgl-shader.mjs',
                     'renderer/virgl-shader/build/wasm/virgl-shader.wasm']:
            raw=(ROOT/name).read_bytes();value=dict(path=name,bytes=len(raw),sha256=sha(raw))
            assert value==hot_sources[name]
            delivered.append(value)
        bindings['deliveredPublicArtifacts']=delivered
    (OUT/'source-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
    report=dict(schema='virgl-compiler-bounds-critic-authentication-v1',status='passed',sourceHead=SOURCE,
        submissionHead=SUBMISSION,manifestSha256=sha((WORKER/'manifest.json').read_bytes()),
        archiveSha256=sha(archive),indexSha256=sha(index_raw),uniqueMembers=104,receipts=checks,
        coldReportSha256=sha((EXTRACTED/'cold/report.json').read_bytes()),
        coldEnvironmentRemoved=cold['removedEnvironmentNames'],coldBefore=cold['statusBefore'],coldAfter=cold['statusAfter'],
        sourceBindingsSha256=sha((OUT/'source-bindings.json').read_bytes()))
    (OUT/'authentication.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Authenticated104 unique members, both1514-source receipts, unchanged submission runtime/harness and pristine cold proof.')


if __name__=='__main__':
    main()
