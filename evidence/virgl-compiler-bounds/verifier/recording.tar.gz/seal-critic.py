#!/usr/bin/env python3
"""Seal fresh critic artifacts; worker archive remains a digest-bound dependency."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    names=['authenticate.py','authentication.json','source-bindings.json',
        'audit.py','audit.json','frozen.diff','predictions-before-evidence.json','predictions.json',
        'independent-joins.mjs','independent-joins.json','promoted-guard.json',
        'sabotage.json','sabotage.diff','sabotage-bridge.c','sabotage-native',
        'sabotage-build.log','sabotage-join-report.json','sabotage-join.log',
        'resource-setup-diagnostic.log','resources.json','scratch-clone.json','scratch-clone.log',
        'verdict.txt','seal-critic.py']
    names += [str(p.relative_to(OUT)) for p in sorted((OUT/'gpu-independent-1875794577').rglob('*')) if p.is_file()]
    assert len(names)==len(set(names))
    members={name:(OUT/name).read_bytes() for name in names}
    promoted=ROOT/'renderer/virgl-shader/tests/compiler-bounds-joins.mjs'
    members['promoted/compiler-bounds-joins.mjs']=promoted.read_bytes()
    assert members['promoted/compiler-bounds-joins.mjs']==members['independent-joins.mjs']
    audit=json.loads(members['audit.json']);auth=json.loads(members['authentication.json'])
    assert audit['verdict']=='verified' and audit['status']==auth['status']=='passed'
    assert all(e['result']=='HELD' for e in json.loads(members['predictions.json'])['predictions'])
    assert sha(members['source-bindings.json'])==auth['sourceBindingsSha256']
    index=dict(schema='virgl-compiler-bounds-critic-records-v1',task='E6-T12g6b',
        sourceHead=audit['sourceHead'],submissionHead=audit['submissionHead'],
        records=[dict(path=name,bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(members.items())])
    index_raw=(json.dumps(index,indent=2)+'\n').encode();(OUT/'records.json').write_bytes(index_raw)
    archive=io.BytesIO()
    with gzip.GzipFile(fileobj=archive,mode='wb',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for name,raw in sorted(members.items()):
                entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mtime=0
                entry.mode=0o755 if name=='sabotage-native' else 0o644
                tar.addfile(entry,io.BytesIO(raw))
    archive_raw=archive.getvalue();(OUT/'recording.tar.gz').write_bytes(archive_raw)
    happy=[e for e in audit['physical'] if e['fault'] is None]
    manifest=dict(schema='virgl-compiler-bounds-critic-seal-v1',task='E6-T12g6b',verdict='verified',
        sourceHead=audit['sourceHead'],submissionHead=audit['submissionHead'],base='60aebb0e1a4639ff4d9468067879e9789e6a5a23',
        records=len(members),archive=dict(path='recording.tar.gz',bytes=len(archive_raw),sha256=sha(archive_raw)),
        recordIndex=dict(path='records.json',bytes=len(index_raw),sha256=sha(index_raw)),
        auditSha256=sha(members['audit.json']),predictionsSha256=sha(members['predictions.json']),
        sourceBindingsSha256=sha(members['source-bindings.json']),
        workerDependency=dict(path='evidence/virgl-compiler-bounds/worker/recording.tar.gz',
            sha256=auth['archiveSha256'],recordIndexSha256=auth['indexSha256'],uniqueMembers=104),
        promotedGuard=dict(path='renderer/virgl-shader/tests/compiler-bounds-joins.mjs',
            sha256=sha(promoted.read_bytes()),cases=402,resultSha256=sha(members['promoted-guard.json']),
            command='node renderer/virgl-shader/tests/compiler-bounds-joins.mjs --native renderer/virgl-shader/build/native/virgl-shader'),
        independentJoinCases=402,happyHardwareSchedules=len(happy),
        independentlyCheckedWords=sum(e['words'] for e in happy),
        independentlyCheckedPixels=sum(e['pixels'] for e in happy),
        freshSeed=1875794577,allResourcesClosed=True,productionNegotiation=False,guestExecution=False,performanceClaim=False)
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    with tarfile.open(fileobj=io.BytesIO(archive_raw),mode='r:gz') as tar:
        entries=tar.getmembers();assert len(entries)==len({e.name for e in entries})==len(members)
        for entry in entries:
            raw=tar.extractfile(entry).read();assert raw==members[entry.name]
    print(json.dumps(manifest,indent=2))


if __name__=='__main__':
    main()
