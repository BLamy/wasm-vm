from pathlib import Path, PurePosixPath
import hashlib, json, subprocess, tarfile, functools
ROOT = Path.cwd()
OUT = ROOT/'target/evidence/virgl-gears-shaders-verifier'
SOURCE = '2e7f43167fe29d8ad0da92591888e27e2dbae589'
BASE = 'ee0277231f1903633881d803ba6153b58d31fd1c'
SUBMISSION = 'c1a7f03490275d0d8ef9077d598c1e9d735cfb3c'
seal = ROOT/'evidence/virgl-gears-shaders/worker'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = functools.lru_cache(maxsize=None)(lambda *a: subprocess.check_output(['git',*a],cwd=ROOT))
def read(rel): return (OUT/'authenticated-worker'/rel).read_bytes()
def load(rel): return json.loads(read(rel))
manifest_raw = (seal/'manifest.json').read_bytes(); manifest = json.loads(manifest_raw)
index_raw = (seal/'records.json').read_bytes(); index = json.loads(index_raw)
assert manifest['sourceHead'] == index['sourceHead'] == SOURCE
assert manifest['base'] == BASE and manifest['records'] == len(index['records']) == 57
for binding in (manifest['archive'],manifest['recordIndex']):
    raw = (seal/binding['path']).read_bytes()
    assert len(raw) == binding['bytes'] and sha(raw) == binding['sha256']
assert manifest['archive']['sha256'] == '9941036d869021078ce41f67e219b568c24a5b00294598dba4b6873c67b3af6e'
assert sha(index_raw) == '66f7335f9d11d6cd9cca13b12bbf78e7ae4c43c8f0f3149baea41e514dcad5bb'
expected = {b['path']: b for b in index['records']}
assert len(expected) == len(index['records'])
member_checks=[]
with tarfile.open(seal/'recording.tar.gz','r:gz') as tar:
    members = tar.getmembers(); names=[m.name for m in members]
    assert len(names)==len(set(names))==57 and set(names)==set(expected)
    for member in members:
        name=member.name
        assert member.isfile() and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
        raw = tar.extractfile(member).read(); binding=expected[name]
        assert len(raw)==binding['bytes'] and sha(raw)==binding['sha256']
        path=OUT/'authenticated-worker'/name; path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(raw)
        member_checks.append(binding)
source_checks=[]; generated={
 'renderer/virgl-shader/build/native/virgl-shader':'generated/virgl-shader',
 'renderer/virgl-shader/build/wasm/virgl-shader.mjs':'generated/virgl-shader.mjs',
 'renderer/virgl-shader/build/wasm/virgl-shader.wasm':'generated/virgl-shader.wasm'}
for receipt_path in ('hot/receipt.json','cold/acceptance/receipt.json'):
    receipt=load(receipt_path); assert receipt['gitHead']==SOURCE and receipt['status']=='passed'
    parent=PurePosixPath(receipt_path).parent
    for binding in receipt['records']:
        raw=read(str(parent/binding['path']))
        assert len(raw)==binding['bytes'] and sha(raw)==binding['sha256']
    for binding in receipt['sources']:
        path=binding['path']
        if path.startswith('renderer/virgl-shader/build/'):
            raw=read(generated[path])
        else:
            raw=git('show',SOURCE+':'+path)
            assert raw==(ROOT/path).read_bytes(), ('current drift',path)
        assert len(raw)==binding['bytes'] and sha(raw)==binding['sha256'],('source drift',path)
        source_checks.append({'receipt':receipt_path,**binding})
    assert all(sha(git('show',BASE+':'+b['path']))==b['sha256'] for b in receipt['unchangedRuntime'])
    for leaf in receipt['carriedLeaves']:
        assert leaf['task'] in ['E6-T12g1','E6-T12g2','E6-T12g3','E6-T12g4','E6-T12g5']
    for binding in receipt['sources']:
        if binding['path'].startswith('evidence/') or binding['path'].startswith('tasks/'):
            assert git('show',BASE+':'+binding['path'])==git('show',SOURCE+':'+binding['path'])
    for report_record in receipt['records']:
        if not report_record['path'].endswith('/report.json'): continue
        rel=str(parent/report_record['path']); report=load(rel)
        assert report['gitHead']==SOURCE and not report['trackedChanges']
        assert report['browserErrors']=={'console':[],'page':[],'requests':[]}
        assert report['browser']['launch']['headless'] is False
        assert report['browser']['gpu']['featureStatus'][report['browser']['webglFeature']]=='enabled'
        for binding in report['sources']:
            path=binding['path']; raw=read(generated[path]) if path in generated else git('show',SOURCE+':'+path)
            assert len(raw)==binding.get('size',binding.get('bytes')) and sha(raw)==binding['sha256'], ('report source',rel,path)
        coverage=report['browserCoverage']; assert sha(read(str(PurePosixPath(rel).parent/coverage['path'])))==coverage['sha256']
        screen=report.get('screenshot',report.get('failureScreenshot')); assert sha(read(str(PurePosixPath(rel).parent/screen['path'])))==screen['sha256']
assert sha(read('hot/receipt.json'))==manifest['hotReceiptSha256']
assert sha(read('cold/report.json'))==manifest['coldReportSha256']
assert sha(read('cold/acceptance/receipt.json'))==manifest['coldReceiptSha256']
cold=load('cold/report.json')
assert cold['gitHead']==cold['cloneHead']==SOURCE and cold['statusBefore']==cold['statusAfter']==''
assert cold['status']=='passed' and cold['exitCode']==0 and cold['command']==['make','verify-E6-T12g6a']
assert sha(read('cold/cold.log'))==cold['logSha256']
assert sha(read('cold/acceptance/receipt.json'))==cold['receiptSha256']
assert load('hot/receipt.json')['sources']==load('cold/acceptance/receipt.json')['sources']
assert load('hot/receipt.json')['inputs']==load('cold/acceptance/receipt.json')['inputs']
assert read('diff.patch')==git('diff',BASE,SOURCE)
changed=git('diff','--name-only',SOURCE,SUBMISSION).decode().splitlines()
assert set(changed)=={'evidence/virgl-gears-shaders/worker/manifest.json','evidence/virgl-gears-shaders/worker/recording.tar.gz','evidence/virgl-gears-shaders/worker/records.json','tasks/QUEUE.md','tasks/epic-6-transcendence/E6-T12g6a-original-shader-execution.md'}
result={'prediction':'P1/P8','status':'HELD','sourceHead':SOURCE,'submission':SUBMISSION,'base':BASE,
        'manifestSha256':sha(manifest_raw),'archiveSha256':manifest['archive']['sha256'],'indexSha256':sha(index_raw),
        'members':member_checks,'sourceChecks':source_checks,'cold':cold,'submissionOnlyChanges':changed,
        'hotReceiptSha256':sha(read('hot/receipt.json')),'coldReceiptSha256':sha(read('cold/acceptance/receipt.json')),
        'summary':load('source-summary.json')}
(OUT/'authentication.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'HELD','members':len(member_checks),'sourcesChecked':len(source_checks),'coldStatus':cold['status'],'authenticationSha256':sha((OUT/'authentication.json').read_bytes())}))
