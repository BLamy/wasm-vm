from pathlib import Path
import hashlib,json,re,socket,subprocess
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-gears-shaders-verifier';SOURCE='2e7f43167fe29d8ad0da92591888e27e2dbae589';sha=lambda b:hashlib.sha256(b).hexdigest()
reports=[OUT/f'fresh-seed-{s}/report.json' for s in (431193889,2793656469,3828116243)]+[OUT/d/'report.json' for d in ('novel-hardware','novel-alpha-fault')]
processes=subprocess.check_output(['ps','-Ao','pid,ppid,args'],text=True);profiles=[];ports=set()
for file in reports:
 report=json.loads(file.read_bytes())
 for arg in report['browser']['actualCommandLine']:
  if arg.startswith('--user-data-dir='):profiles.append(arg.split('=',1)[1])
 coverage=json.loads((file.parent/report['browserCoverage']['path']).read_bytes())
 for script in coverage['scripts']:
  url=script['coverage']['url'];m=re.search(r'^http://127\.0\.0\.1:(\d+)/',url)
  if m:ports.add(int(m.group(1)))
assert all(profile not in processes for profile in profiles),'owned Chrome process still alive'
connections=[]
for port in sorted(ports):
 with socket.socket() as sock:
  sock.settimeout(.2);result=sock.connect_ex(('127.0.0.1',port));assert result!=0,('owned acceptance port still listening',port)
  connections.append({'host':'127.0.0.1','port':port,'connectResult':result,'closed':True})
modified=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
assert modified==['tasks/epic-6-transcendence/E6-T12g6a-original-shader-execution.md']
assert sha((ROOT/'renderer/virgl-shader/tests/gears-exact-alpha.mjs').read_bytes())=='9b118502814dd7634fda76c1fc6df0d9eba679dbd73a469f413d8fd637a1f3da'
inputs=json.loads((OUT/'authenticated-worker/hot/receipt.json').read_bytes())['sources'];bound=[]
for item in inputs:
 if item['path'].startswith('renderer/virgl-shader/build/'):continue
 raw=(ROOT/item['path']).read_bytes();assert len(raw)==item['bytes'] and sha(raw)==item['sha256'];bound.append(item)
result={'status':'HELD','ownedChromeProfilesClosed':profiles,'ownedServerPortsClosed':connections,'sourceHead':SOURCE,'recheckedFrozenSources':len(bound),'allowedTrackedModification':modified,'promotedTest':{'path':'renderer/virgl-shader/tests/gears-exact-alpha.mjs','sha256':sha((ROOT/'renderer/virgl-shader/tests/gears-exact-alpha.mjs').read_bytes())},'noQueueGitStackDeployOrUIWrites':True}
(OUT/'cleanup-and-boundary.json').write_text(json.dumps(result,indent=2)+'\n');print('All5 owned browsers and servers closed; frozen sources unchanged except approved verifier artifacts')
