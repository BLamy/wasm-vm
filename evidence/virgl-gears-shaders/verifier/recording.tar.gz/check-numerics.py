"""Independent critic arithmetic: no imports of worker/compiler/oracle implementation."""
from pathlib import Path
import hashlib, json, math, struct, sys
ROOT=Path.cwd(); OUT=ROOT/'target/evidence/virgl-gears-shaders-verifier'; WORK=OUT/'authenticated-worker'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
f=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
w=lambda x:struct.unpack('<I',struct.pack('<f',x))[0]
n=lambda bits:struct.unpack('<f',struct.pack('<I',bits))[0]
a=lambda x,y:f(x+y)
m=lambda x,y:f(x*y)
dot=lambda x,y:a(a(m(x[0],y[0]),m(x[1],y[1])),m(x[2],y[2]))
def norm(x):
    scale=f(1/math.sqrt(dot(x,x))); return [m(q,scale) for q in x]
def ordword(bits):return 0x80000000-(bits&0x7fffffff) if bits>>31 else 0x80000000+bits
def ulps(x,y):return abs(ordword(x)-ordword(y))
def bytes_rgba(color):return [min(255,max(0,math.floor(x*255+0.5))) for x in color]
def gears(inputs,constants):
    p,z=inputs;c=constants
    clip=[a(a(a(m(c[0][l],p[0]),m(c[1][l],p[1])),m(c[2][l],p[2])),c[3][l]) for l in range(4)]
    normal=[a(a(a(m(c[4][l],z[0]),m(c[5][l],z[1])),m(c[6][l],z[2])),c[7][l]) for l in range(3)]
    diff=max(0,dot(norm(normal),norm(c[8][:3])))
    lit=a(n(0x3e4ccccd),diff); color=[m(lit,v) for v in c[9][:3]]+[c[9][3]]
    return [w(v) for v in clip+color],color

def compositor(inputs,c):
    p,uv=inputs
    clip=[a(a(m(c[0][l],p[0]),c[2][l]),m(c[1][l],p[1])) for l in range(3)]+[1]
    extra=[a(m(v,0.0),v) for v in c[3][2:]]
    return [w(v) for v in clip+uv[:2]+c[3][:2]+extra]
def rows(raw):return [[n(b) for b in row] for row in raw]
def cite(path,text,needle,pointer):
    index=text.index(needle)
    return {'path':str(path.relative_to(OUT)), 'line':text[:index].count('\n')+1,'jsonPointer':pointer,'sha256':sha(text.encode())}

def check_report(path):
    text=path.read_text();report=json.loads(text);acc=report['acceptance'];assert report['status']==acc['status']=='passed'
    assert report['browserErrors']=={'console':[],'page':[],'requests':[]}
    assert acc['guestExecution'] is acc['productionNegotiation'] is False
    assert 'ANGLE Metal' in acc['renderer']['renderer'] and 'Apple M4 Max' in acc['renderer']['renderer']
    assert all(not any(k in arg.lower() for k in ('swiftshader','--disable-gpu','llvmpipe','software')) for arg in report['browser']['actualCommandLine'])
    assert acc['objects']=={'created':40,'live':0,'actualDeleted':40}
    creates={ev['id']:ev['call'][6:] for ev in acc['events'] if ev['call'].startswith('create')}
    deletes={ev['id']:ev['call'][6:] for ev in acc['events'] if ev['call'].startswith('delete')}
    assert len(creates)==40 and creates==deletes
    shader_sources=[ev['source'] for ev in acc['events'] if ev['call']=='shaderSource']
    shader_compiles=[ev for ev in acc['events'] if ev['call']=='compileShader']
    program_links=[ev for ev in acc['events'] if ev['call']=='linkProgram']
    assert all(e['status'] and not e['log'] for e in shader_compiles+program_links)
    assert all(p['result']['vertex']['glsl'] in shader_sources and p['result']['fragment']['glsl'] in shader_sources for p in acc['pairs'])
    vectors=[];pixels=[];max_rgb_ulp=0;num_words=0;num_pixels=0;precise=set()
    for vi,vertex in enumerate(acc['vertices']):
        isgears=vertex['sha256'].startswith('80a42bf3')
        assert vertex['writtenMasks']==([15,15] if isgears else [15,15,3])
        assert vertex['reflection']==[{'name':x,'type':35666,'size':1} for x in (['gl_Position','vso_g0'] if isgears else ['gl_Position','vso_g0','vso_g1'])]
        assert len(vertex['vectors'])==48
        assert vertex['pairKind']==('captured-program' if isgears else 'compatible-isolation')
        block=vertex['systemBlocks'][0]
        assert block['name']=='VirglBlock' and block['byteLength']==656
        assert block['members']==[{'name':'winsys_adjust_y','reflectedName':'winsys_adjust_y','offset':640,'type':5126,'value':1}]
        for i,v in enumerate(vertex['vectors']):
            inputs=rows(v['inputWords']);constants=rows(v['constantWords'])
            wanted=gears(inputs,constants)[0] if isgears else compositor(inputs,constants)
            raw=bytes(v['bytes']);obs=list(struct.unpack('<'+'I'*(len(raw)//4),raw))
            assert sha(raw)==v['sha256'] and obs==v['observed']
            assert len(obs)==(8 if isgears else 12)
            assert sorted(x['lane'] for x in v['checks'])==list(range(len(wanted)))
            for lane,expected in enumerate(wanted):
                budget=12 if isgears and 4<=lane<=6 else 0
                distance=ulps(obs[lane],expected)
                assert math.isfinite(n(obs[lane])) and distance<=budget,(path,v['name'],lane,obs[lane],expected,distance)
                check=next(x for x in v['checks'] if x['lane']==lane)
                assert check['actual']==obs[lane] and check['expected']==expected
                if budget:max_rgb_ulp=max(max_rgb_ulp,distance)
            supplied=[x for row in v['constantWords'] for x in row]
            upload=v['uploads'][0]
            assert upload['type']==36296 and upload['declaredCount']==upload['activeCount']==len(constants)
            assert upload['words']==upload['approved']['words']==upload['observed']==supplied
            assert [x['words'] for x in v['attributes']]==v['inputWords']
            assert [x['name'] for x in v['attributes']]==['in_0','in_1']
            if not isgears:precise.update(obs[8:10])
            vector_citation=cite(path,text,'"name": "'+v['name']+'"',f'/acceptance/vertices/{vi}/vectors/{i}')
            vectors.append({'name':v['name'],'writtenWords':len(wanted),'expectedWords':wanted,'maxUlp':max(ulps(obs[l],wanted[l]) for l in range(len(wanted))),'rawSha256':sha(raw),'citation':vector_citation})
            num_words+=len(wanted)
    literal_texels=[17,85,221,0,231,41,79,64,62,193,11,128,109,7,153,255]
    for fi,frag in enumerate(acc['fragments']):
        assert frag['pairKind']=='captured-program'
        if fi==1:assert frag['texture']['bytes']==literal_texels and frag['texture']['filter']=='NEAREST' and frag['texture']['wrap']=='CLAMP_TO_EDGE'
        for i,d in enumerate(frag['draws']):
            if fi==0:
                wanted=bytes_rgba(gears(rows(d['inputWords']),rows(d['constantWords']))[1])
            else:
                uv=rows(d['inputWords'])[1][:2]
                quadrant=(0 if uv[0]<.5 else 1)+(0 if uv[1]<.5 else 2)
                texel=literal_texels[quadrant*4:quadrant*4+4]; coefficient=n(d['fragmentWords'][0][0])
                wanted=bytes_rgba([m(f(x/255),coefficient) for x in texel[:3]]+[coefficient])
                assert texel==d['texel'] and uv==d['uv'] and coefficient==d['coefficient']
            raw=bytes(d['rgbaBytes']); assert len(raw)==1024 and sha(raw)==d['rgbaSha256']
            assert d['checkedPixels']==256 and d['expected']==wanted and d['pixelBudget']==1
            maxbyte=max(abs(v-wanted[j%4]) for j,v in enumerate(raw));assert maxbyte<=1
            for upload in d['uploads']:
                assert upload['type']==36296
                assert upload['words']==upload['approved']['words']==upload['observed']
                expected_words=d['constantWords'] if upload['stage']=='vertex' else d['fragmentWords']
                assert upload['words']==[v for row in expected_words for v in row]
            pixels.append({'name':d['name'],'independentExpected':wanted,'pixel0':list(raw[:4]),'maxByteDifference':maxbyte,'rawSha256':sha(raw),
              'citation':cite(path,text,'"name": "'+d['name']+'"',f'/acceptance/fragments/{fi}/draws/{i}')})
            num_pixels+=256
    assert num_words==864 and num_pixels==9216
    assert precise=={0,0x80000000,1,0x80000001,0x007fffff,0x807fffff,0x3eaaaaab,0xbeaaaaab}
    return {'status':'HELD','reportPath':str(path.relative_to(OUT)),'reportSha256':sha(path.read_bytes()),'seed':acc['seed'],
            'words':num_words,'pixels':num_pixels,'lightingMaximumUlp':max_rgb_ulp,'preciseWords':sorted(precise),'vectors':vectors,'draws':pixels,
            'alphaCheckedExactly':True,'objects':acc['objects'],'browserErrors':report['browserErrors']}

if __name__=='__main__':
    if len(sys.argv)>1:
        results=[check_report(Path(v).resolve()) for v in sys.argv[1:]]
        output=OUT/'novel-numerical-checks.json'
    else:
        results=[check_report(WORK/parent/f'gpu-{seed}/report.json') for parent in ('hot','cold/acceptance') for seed in (1648868771,254715103,3281536249)]
        output=OUT/'worker-numerical-checks.json'
    output.write_text(json.dumps({'predictions':['P3','P4','P5','P6','P7'],'status':'HELD','reports':results},indent=2)+'\n')
    print(json.dumps({'status':'HELD','reports':len(results),'words':sum(x['words'] for x in results),'pixels':sum(x['pixels'] for x in results),'maxRgbUlp':max(x['lightingMaximumUlp'] for x in results),'outputSha256':sha(output.read_bytes())}))
