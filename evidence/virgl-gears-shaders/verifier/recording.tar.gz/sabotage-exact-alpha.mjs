import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {verifyExactAlpha} from './gears-exact-alpha.mjs';
const base='target/evidence/virgl-gears-shaders-verifier';
const file=base+'/authenticated-worker/hot/gpu-1648868771/report.json';
const raw=fs.readFileSync(file),original=JSON.parse(raw),copy=structuredClone(original);
const checked=verifyExactAlpha(original,file);
const vector=copy.acceptance.vertices[0].vectors[0],expected=vector.constantWords[9][3];
assert.equal(vector.checks[7].budget,12);
const bytes=Buffer.from(vector.bytes);bytes.writeUInt32LE(expected+1,28);
vector.bytes=[...bytes];vector.sha256=createHash('sha256').update(bytes).digest('hex');vector.observed[7]=expected+1;
vector.checks[7].actual=expected+1;vector.checks[7].ulp=1;
assert.ok(vector.checks[7].ulp<=vector.checks[7].budget,'original lighting-group tolerance would accept this alpha drift');
let failure;
try{verifyExactAlpha(copy,'one-ULP-alpha-sabotage');}catch(error){failure=error.message;}
assert.ok(failure&&failure.includes('exact raw MOV alpha'),'promoted guard must reject a drift within the original alpha allowance');
const report={prediction:'P7 alpha-test sabotage',status:'HELD',sourceReportSha256:createHash('sha256').update(raw).digest('hex'),clean:checked,mutatedPoint:'/acceptance/vertices/0/vectors/0/observed/7',constantAlphaWord:expected,mutantPhysicalWord:expected+1,originalTestAllowance:12,mutantDistance:1,originalToleranceAccepts:true,newGuardRejects:true,failure};
fs.writeFileSync(base+'/sabotage-exact-alpha.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
