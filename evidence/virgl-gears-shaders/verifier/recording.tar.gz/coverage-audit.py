from pathlib import Path
import json,hashlib
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-gears-shaders-verifier';WORK=OUT/'authenticated-worker';sha=lambda b:hashlib.sha256(b).hexdigest()
by_source={};records=[]
for p in sorted(WORK.rglob('browser-coverage.json')):
 if 'retained-f6' in str(p):continue
 raw=p.read_bytes();records.append({'path':str(p.relative_to(OUT)),'sha256':sha(raw)})
 for s in json.loads(raw)['scripts']:
  assert sha((ROOT/s['source']).read_bytes())==s['sha256']
  by_source.setdefault(s['source'],[]).append(s['coverage'])
audits=[]
for source,sets in by_source.items():
 text=(ROOT/source).read_text();ranges=[];functions={}
 for coverage in sets:
  one=[]
  for fn in coverage['functions']:
   first=fn['ranges'][0];key=(fn['functionName'],first['startOffset'],first['endOffset']);functions[key]=max(functions.get(key,0),first['count'])
   one.extend(fn['ranges'])
  ranges.append(one)
 unexecuted=[]
 for offset,char in enumerate(text):
  if char.isspace():continue
  held=False
  for run in ranges:
   enclosing=[r for r in run if r['startOffset']<=offset<r['endOffset']]
   if enclosing and min(enclosing,key=lambda r:r['endOffset']-r['startOffset'])['count']>0:
    held=True;break
  if not held:unexecuted.append(offset)
 groups=[]
 for offset in unexecuted:
  if not groups or offset>groups[-1][-1]+1:groups.append([offset])
  else:groups[-1].append(offset)
 blocks=[{'startOffset':g[0],'endOffset':g[-1]+1,'startLine':text[:g[0]].count('\n')+1,'endLine':text[:g[-1]+1].count('\n')+1,'source':text[g[0]:g[-1]+1]} for g in groups]
 audits.append({'source':source,'sha256':sha((ROOT/source).read_bytes()),'coverageReports':len(sets),'functions':[{'functionName':k[0],'startLine':text[:k[1]].count('\n')+1,'maxCount':count} for k,count in functions.items()],'unexecutedNonspace':blocks})
 # Every named function actually used; the remaining gaps are individual defensive branches.
 assert all(count>0 for (name,start,end),count in functions.items()),source
out={'prediction':'P8 coverage','status':'HELD','recordedCounters':records,'audits':audits,'classifications':[
 {'path':'renderer/virgl-shader/tests/gears-originals.mjs','line':8,'classification':'waived','reason':'Generic require failure is a defensive branch for malformed fixture/hardware; all task invariants succeeded and physical explicit numeric failures are separately exercised.'},
 {'path':'renderer/virgl-shader/tests/gears-originals.mjs','line':131,'classification':'waived','reason':'Defensive written-mask skip; the independent literal auxiliary oracle supplies only defined xy lanes, leaving declared undefined zw outside the comparison loop.'},
 {'path':'tools/virgl-gears-shaders/oracle.mjs','line':11,'classification':'waived','reason':'Zero/nonfinite normal vector failure is outside the expressly bounded nonzero finite normalization inputs.'},
 {'path':'tools/virgl-gears-shaders/oracle.mjs','line':17,'classification':'waived','reason':'General negative-float ordering is unnecessary for exact negative/zero/subnormal words; only nonnegative lighting RGB has an ULP tolerance. Signed copied/precise outputs are compared as exact uint32 words.'},
 {'path':'tools/virgl-gears-shaders/{provenance,receipt,cold}.py','classification':'executed/defensive waived','reason':'Authenticated products and acceptance logs prove success traversal of literal sources, native/wasm partition, all seeded/fault records, retained F6/leaves and final pristine clone. Failure-only require/except paths and logging/config do not change the claimed shader semantics.'},
 {'path':'renderer/virgl-shader/tests/gears-originals.json','classification':'executed','reason':'Every original/retained entry is translated natively and in wasm, metadata/rejections compared literally, and all admitted body instructions execute in the declared probes; unsupported sources are complete rejections.'},
 {'path':'Makefile, tools/verify-virgl-gears-shaders.sh, tools/virgl-gears-shaders/{browser,compiler}.mjs','classification':'executed/defensive waived','reason':'Hot/cold acceptance logs prove target/driver/build steps; reports prove native/wasm equivalence and every success/fault wrapper. Initial assertion failure-only branches are defensive; the compiler metadata assertion is independently sabotaged.'},
 {'path':'tasks/QUEUE.md, tasks/epic-6-transcendence/E6-T12g6-required-format-closure.md, tools/virgl-gears-shaders/README.md','classification':'waived','reason':'Declarative queue/dependency/boundary metadata and documentation; the additional dependency correctly leaves larger unsupported programs gated.'},
 {'path':'renderer/virgl-shader/tests/gears-originals.mjs','line':132,'classification':'strengthened by promoted test','reason':'The grouped RGB budget also reaches copied alpha. The critic independently compared every alpha exactly and promoted a raw-byte exact-alpha guard, sabotaged with a one-ULP drift that the original group allowance would accept.'}
 ],'deadHunks':[],'needsEvidenceHunks':[]}
(OUT/'coverage.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':'HELD','coverageReports':len(records),'sources':len(audits),'namedFunctions':sum(len(a['functions']) for a in audits),'unexecutedNonspaceGroups':sum(len(a['unexecutedNonspace']) for a in audits),'digest':sha((OUT/'coverage.json').read_bytes())}))
