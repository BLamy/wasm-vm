from pathlib import Path
import hashlib, importlib.util,json
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-gears-shaders-verifier'
spec=importlib.util.spec_from_file_location('critic_equations',OUT/'check-numerics.py');eq=importlib.util.module_from_spec(spec);spec.loader.exec_module(eq)
f,w,n=eq.f,eq.w,eq.n
rows=lambda rows:[[w(f(v)) for v in row] for row in rows]
state=0x9d415ea7
def pick():
 global state
 state=(1664525*state+1013904223)&0xffffffff
 return ((state>>24)%25-12)/8
axes=[[1,0,0,0],[-1,0,0,0],[0,1,0,0],[0,-1,0,0],[0,0,1,0],[0,0,-1,0],[3,4,0,0],[0,-4,3,0],[1,-1,1,0],[-1,2,3,0]]
vectors=[]
for i in range(24):
 p=[pick(),pick(),pick(),[-3,.25,0,2][i%4]];normal=axes[i%len(axes)]
 matrix=[[.75,-.125,.5,.125],[-.25,.5,-.125,.25],[.125,.25,.75,-.375],[.0625,-.25,.125,1]]
 normalmatrix=[[0,1,0,0],[0,0,1,0],[1,0,0,0],[.125,-.0625,.25,0]]
 light=axes[(i*3+2)%len(axes)]
 material=[[.1,.9,.3,.1],[.75,.125,.5,1],[0,.25,1,0],[.25,.5,.75,-0.0]][i%4]
 inputs=rows([p,normal]);c=rows(matrix+normalmatrix+[light,material]);wanted,color=eq.gears(eq.rows(inputs),eq.rows(c))
 vectors.append({'name':f'critic-gears-{i}','shader':'80a42bf3','inputWords':inputs,'constantWords':c,'expectedWords':wanted,'budgets':[0,0,0,0,12,12,12,0]})
precise=[0,0x80000000,1,0x80000001,0x007fffff,0x807fffff,0x00800000,0x80800000,0x3eaaaaab,0xbeaaaaab,0x7f7fffff,0xff7fffff]
for i in range(24):
 p=[pick(),pick(),pick(),[-3,.25,0,2][i%4]];uv=[pick(),pick(),pick(),.5]
 inputs=rows([p,uv]);c=rows([[.75,-.25,.5,0],[-.125,.625,-.75,0],[.0625,-.125,.5,0],[.25 if i%2 else -0.0,.5 if i%3 else -0.0,0,0]])
 c[3][2]=precise[i%len(precise)];c[3][3]=precise[(i+5)%len(precise)]
 wanted=eq.compositor(eq.rows(inputs),eq.rows(c))
 vectors.append({'name':f'critic-compositor-{i}','shader':'7bf4d0d0','inputWords':inputs,'constantWords':c,'expectedWords':wanted,'budgets':[0]*10})
texels=[17,85,221,0,231,41,79,64,62,193,11,128,109,7,153,255]
draws=[]
uvs=[[-.5,-.5],[1.5,-.5],[-.5,1.5],[1.5,1.5],[.499,.499],[.501,.499],[.499,.501],[.501,.501],[.5,.5]]
for j,coefficient in enumerate([.1,.9,1/3,-0.0,1]):
 for i,uv in enumerate(uvs):
  u,v=map(f,uv);coeff=f(coefficient);quad=(0 if u<.5 else 1)+(0 if v<.5 else 2);texel=texels[quad*4:quad*4+4]
  expected=eq.bytes_rgba([eq.m(f(q/255),coeff) for q in texel[:3]]+[coeff])
  draws.append({'name':f'critic-texture-{j}-{i}','inputWords':rows([[0,0,0,1],[u,v,0,1]]),'constantWords':rows([[1,0,0,0],[0,1,0,0],[0,0,0,0]]),'fragmentWords':rows([[coeff,0,0,0]]),'expected':expected,'texel':texel,'quadrant':quad,'budget':1})
manifest={'prediction':'P9','phase':'predicted before hardware run','independentEquationFileSha256':hashlib.sha256((OUT/'check-numerics.py').read_bytes()).hexdigest(),'vectors':vectors,'draws':draws,'texels':texels,'fault':{'stage':'vertex','needle':'vso_g0.w = uintBitsToFloat(raw_out[1].w);','replacement':'vso_g0.w = 1.0 - uintBitsToFloat(raw_out[1].w);','expectedFailure':'critic-gears-0 lane7; alpha must equal raw C9.w'}}
(OUT/'novel-input-predictions.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Predicted',len(vectors),'vectors and',len(draws),'draws; SHA256',hashlib.sha256((OUT/'novel-input-predictions.json').read_bytes()).hexdigest())
