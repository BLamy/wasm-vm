"""Independent packet/state interpreter limited to literal shader identities and original pair provenance."""
from pathlib import Path
import gzip, hashlib, json, struct
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-gears-shaders-verifier';BASE=ROOT/'evidence/virgl-workload-inventory';CAP=BASE/'captures/es2gears'
sha=lambda b:hashlib.sha256(b).hexdigest()
index_raw=(BASE/'index.json').read_bytes();assert sha(index_raw)=='a3c6974bdf3e19b17d2150af66337bd36040191b6f23599f7ce1a3990927189f'
index=json.loads(index_raw);binding=index['capture'];manifest_raw=(BASE/binding['path']).read_bytes();assert sha(manifest_raw)==binding['sha256'] and len(manifest_raw)==binding['bytes']
manifest=json.loads(manifest_raw);binding=manifest['events'];events_raw=(CAP/binding['path']).read_bytes();assert sha(events_raw)==binding['sha256'] and len(events_raw)==binding['bytes']
events=[json.loads(x) for x in events_raw.splitlines()];assert len(events)==52809 and events[-1]['complete'] and events[-1]['normalExit']
cache={};subs={};pending={};objects={};bound={};sources={};draws={}
expected_pairs={('80a42bf3','86d0ee79'):('gears',5115,6484),('403b0529','c2474531'):('compositor-texture',5328,48168),('7bf4d0d0','92cb866a'):('unsupported-compositor-program',5328,46312),('403b0529','c5806d5f'):('unsupported-texture-program',5328,64400)}
for line,event in enumerate(events,1):
    assert event['seq']==line
    if event['type']!='submit_cmd' or event['phase']!='enter':continue
    ref=next(r for r in event['blobs'] if r['role']=='command');dg=ref['sha256']
    if dg not in cache:
        file=CAP/'blobs'/(dg+'.bin');raw=file.read_bytes() if file.exists() else gzip.decompress(file.with_suffix('.bin.gz').read_bytes())
        assert sha(raw)==dg and len(raw)==ref['bytes'];cache[dg]=raw
    raw=cache[dg];assert len(raw)==event['ndw']*4;offset=0;ctx=event['ctxId']
    while offset<len(raw):
        header=struct.unpack_from('<I',raw,offset)[0];opcode=header&255;kind=(header>>8)&255;size=((header>>16)+1)*4
        pkt=raw[offset:offset+size];assert len(pkt)==size;words=struct.unpack('<'+'I'*(size//4),pkt);sub=subs.get(ctx,0)
        if opcode==28:subs[ctx]=words[1]
        elif opcode==1 and kind==4:
            handle,stage,decl,tokens,stream=words[1:6]; key=(ctx,sub,stage)
            continuation=bool(decl&0x80000000);decl &=0x7fffffff
            if continuation:
                item=pending[key];assert stream==0 and item['handle']==handle and item['tokens']==tokens and decl==len(item['data'])
            else:
                assert key not in pending
                item={'handle':handle,'stage':stage,'declaredBytes':decl,'tokens':tokens,'data':bytearray(),'citations':[]};pending[key]=item
            data=pkt[(6+(4+2*stream if stream else 0))*4:]
            item['data'].extend(data);item['citations'].append({'line':line,'event':line,'byteOffset':offset,'commandSha256':dg,'packetBytes':size,'packetSha256':sha(pkt)})
            if len(item['data'])==((item['declaredBytes']+3)&~3):
                declared=item['data'][:item['declaredBytes']];assert declared[-1]==0 and 0 not in declared[:-1]
                # Padding after the declared NUL belongs to the transport; no zero-padding requirement is claimed.
                body=bytes(declared[:-1]);digest=sha(body);objects[(ctx,sub,handle)]=digest
                if digest not in sources:sources[digest]={'sha256':digest,'text':body,'stage':stage,'context':ctx,'subcontext':sub,**{k:v for k,v in item.items() if k not in ('data','handle','stage')},'handle':handle}
                del pending[key]
        elif opcode==3 and kind==4:objects.pop((ctx,sub,words[1]),None)
        elif opcode==31:bound[(ctx,sub,words[2])]=objects.get((ctx,sub,words[1]))
        elif opcode==8:
            pair=(bound.get((ctx,sub,0)),bound.get((ctx,sub,1)))
            prefixes=tuple(x[:8] if x else None for x in pair)
            if prefixes in expected_pairs and prefixes not in draws:
                name,expected_line,expected_offset=expected_pairs[prefixes]
                assert (line,offset)==(expected_line,expected_offset)
                draws[prefixes]={'name':name,'vertex':pair[0],'fragment':pair[1],'line':line,'event':line,'byteOffset':offset,'contextId':ctx,'subcontext':sub,'commandSha256':dg,'packetSha256':sha(pkt),'packetBytes':size}
        offset+=size
assert not pending and set(draws)==set(expected_pairs)
declared=json.loads((ROOT/'renderer/virgl-shader/tests/gears-originals.json').read_bytes());checked=[]
for e in declared['originals']+declared['retainedPartners']:
    original=sources[e['sha256']];body=(ROOT/e['path']).read_bytes()
    assert sha(body)==e['sha256'] and len(body)==e['bytes'] and body==original['text'] and original['stage']==(0 if e['stage']=='vertex' else 1)
    if 'retainedPath' in e:assert (ROOT/e['retainedPath']).read_bytes()==body
    checked.append({k:v for k,v in original.items() if k!='text'})
worker=json.loads((OUT/'authenticated-worker/hot/provenance.json').read_bytes());assert list(draws.values())==worker['pairs']
report={'prediction':'P2','status':'HELD','indexSha256':sha(index_raw),'eventSha256':sha(events_raw),'eventLines':len(events),'uniqueCommandBlobs':len(cache),'originals':checked,'capturedDraws':list(draws.values())}
(OUT/'independent-provenance.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'HELD','sources':len(checked),'drawPairs':len(draws),'digest':sha((OUT/'independent-provenance.json').read_bytes())}))
