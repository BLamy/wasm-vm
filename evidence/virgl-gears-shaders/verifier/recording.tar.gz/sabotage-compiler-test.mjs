import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const base='target/evidence/virgl-gears-shaders-verifier';
const file='renderer/virgl-shader/tests/gears-originals.json';
const original=fs.readFileSync(file),fixture=JSON.parse(original);fixture.originals[0].metadata.outputs[1].writtenMask=7;
const mutant=Buffer.from(JSON.stringify(fixture));
const read=fs.readFileSync;let reads=0;
fs.readFileSync=function(file,...args){if(file==='renderer/virgl-shader/tests/gears-originals.json'){reads++;return mutant;}return read.call(this,file,...args);};
process.argv[2]=base+'/sabotaged-compiler-output.json';let failure;
try{await import('../../../tools/virgl-gears-shaders/compiler.mjs');}catch(error){failure={message:error.message,code:error.code,actualWrittenMask:error.actual?.outputs?.[1]?.writtenMask,expectedWrittenMask:error.expected?.outputs?.[1]?.writtenMask};}finally{fs.readFileSync=read;}
assert.equal(reads,1);assert.equal(failure?.code,'ERR_ASSERTION');assert.equal(failure.actualWrittenMask,15);assert.equal(failure.expectedWrittenMask,7);
assert.deepEqual(fs.readFileSync(file),original,'reviewed literal fixture unchanged');
const hash=b=>createHash('sha256').update(b).digest('hex');
const report={prediction:'P7 written-mask sabotage',status:'HELD',compilerTestPath:'tools/virgl-gears-shaders/compiler.mjs',compilerTestSha256:hash(fs.readFileSync('tools/virgl-gears-shaders/compiler.mjs')),originalManifestSha256:hash(original),mutantManifestSha256:hash(mutant),mutatedPoint:'/originals/0/metadata/outputs/1/writtenMask',actual:15,mutantExpected:7,guardRejected:true,failure};
fs.writeFileSync(base+'/sabotage-compiler-test.json',JSON.stringify(report,null,2)+'\n');console.log('Original literal metadata assertion rejects missing alpha mask');
