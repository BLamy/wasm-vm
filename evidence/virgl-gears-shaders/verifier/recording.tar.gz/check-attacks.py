from pathlib import Path
import hashlib,json,struct
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-gears-shaders-verifier';sha=lambda b:hashlib.sha256(b).hexdigest()
pred_bytes=(OUT/'novel-input-predictions.json').read_bytes();pred=json.loads(pred_bytes)
def load(path):return json.loads((OUT/path).read_bytes())
def cite(path,needle,pointer):
 text=(OUT/path).read_text();i=text.index(needle);return {'path':path,'line':text[:i].count('\n')+1,'jsonPointer':pointer,'sha256':sha(text.encode())}
def disposal(report):
 a=report['acceptance'];assert report['browserErrors']=={'console':[],'page':[],'requests':[]}
 assert report['browser']['launch']['headless'] is False and report['browser']['gpu']['featureStatus'][report['browser']['webglFeature']]=='enabled'
 assert 'ANGLE Metal' in a['renderer']['renderer']
 assert a['objects']['created']==a['objects']['actualDeleted'] and a['objects']['live']==0
 created={x['id']:x['call'][6:] for x in a['events'] if x['call'].startswith('create')};deleted={x['id']:x['call'][6:] for x in a['events'] if x['call'].startswith('delete')};assert created==deleted and len(created)==a['objects']['created']
 for forbidden in ('swiftshader','llvmpipe','--disable-gpu'):assert all(forbidden not in x.lower() for x in report['browser']['actualCommandLine'])
 return a['objects']

clean_path='novel-hardware/report.json';r=load(clean_path);a=r['acceptance'];assert r['status']==a['status']=='passed';objects=disposal(r);assert not a['glErrors']
assert a['predictionsSha256']==sha(pred_bytes) and a['predictions']==pred
assert a['checkedVertexWords']==432 and a['checkedPixels']==11520
results=[];max_ulp=0
for i,(got,want) in enumerate(zip(a['vectors'],pred['vectors'])):
 assert got['name']==want['name'] and got['inputWords']==want['inputWords'] and got['constantWords']==want['constantWords']
 raw=bytes(got['bytes']);assert sha(raw)==got['rawSha256'];actual=list(struct.unpack('<'+'I'*(len(raw)//4),raw));assert actual==got['observed']
 assert got['upload']['words']==got['upload']['observed']==[v for row in want['constantWords'] for v in row]
 assert [v['words'] for v in got['attributes']]==want['inputWords']
 block=got['systemBlock'];assert block['value']==1 and block['offset']==640 and len(block['bytes'])==656 and struct.unpack('<f',bytes(block['bytes'][640:644]))[0]==1
 assert len(got['checks'])==len(want['expectedWords'])
 for j,c in enumerate(got['checks']):
  assert c['lane']==j and c['actual']==actual[j] and c['expected']==want['expectedWords'][j] and c['budget']==want['budgets'][j] and c['ulp']<=c['budget']
  max_ulp=max(max_ulp,c['ulp'])
 results.append({'name':got['name'],'writtenWords':len(got['checks']),'rawSha256':sha(raw),'citation':cite(clean_path,'"name": "'+got['name']+'"',f'/acceptance/vectors/{i}')})
pixels=[]
for i,(got,want) in enumerate(zip(a['draws'],pred['draws'])):
 assert got['name']==want['name'] and got['inputWords']==want['inputWords'] and got['constantWords']==want['constantWords'] and got['fragmentWords']==want['fragmentWords']
 assert got['attribute']['words']==want['inputWords'][1]
 raw=bytes(got['rgbaBytes']);assert len(raw)==1024 and sha(raw)==got['rawSha256'];assert got['checkedPixels']==256 and got['expected']==want['expected']
 diff=max(abs(x-want['expected'][j%4]) for j,x in enumerate(raw));assert diff<=1
 pixels.append({'name':got['name'],'uvWords':want['inputWords'][1][:2],'expected':want['expected'],'pixel0':list(raw[:4]),'rawSha256':sha(raw),'maxByteError':diff,'citation':cite(clean_path,'"name": "'+got['name']+'"',f'/acceptance/draws/{i}')})
fault_path='novel-alpha-fault/report.json';fr=load(fault_path);fa=fr['acceptance'];assert fr['status']==fa['status']=='failed';faultobjects=disposal(fr);assert not fa['glErrors']
assert fa['predictionsSha256']==sha(pred_bytes) and fa['predictions']==pred
fp=load('novel-fault-prediction.json');v=fa['vectors'][0];raw=bytes(v['bytes']);assert sha(raw)==v['rawSha256'];actual=list(struct.unpack('<8I',raw));failure=v['failure']
assert failure['lane']==7 and failure['budget']==0 and failure['actual']==actual[7]==fp['predictedMutantAlphaWord'] and failure['expected']==fp['predictedOriginalAlphaWord']
mutation=fa['mutation'];assert mutation['original']==a['programs'][0]['shaderSources']['vertex'];assert sha(mutation['original'].encode())==mutation['originalSha256'] and sha(mutation['served'].encode())==mutation['servedSha256'] and mutation['servedSha256']!=mutation['originalSha256']
assert fa['programs'][0]['sourceDigests']['vertex']==mutation['servedSha256'] and all(s['status'] and not s['log'] for s in fa['programs'][0]['logs']) and fa['programs'][0]['link']['status']
assert 'critic-gears-0 lane7' in fa['failure']['message']
oldfaults=[]
for mode in ['lighting','auxiliary','forced-alpha']:
 path=f'authenticated-worker/hot/fault-{mode}/report.json';report=load(path);acc=report['acceptance'];assert report['status']==acc['status']=='failed';objs=disposal(report);mutation=acc['mutations'][0];assert len(acc['mutations'])==1
 assert sha(mutation['source'].encode())==mutation['sourceSha256'] and sha(mutation['served'].encode())==mutation['servedSha256'] and mutation['sourceSha256']!=mutation['servedSha256']
 assert any(e['call']=='shaderSource' and e['source']==mutation['served'] for e in acc['events'])
 if mode in ['lighting','auxiliary']:
  vi=0 if mode=='lighting' else 1;v=acc['vertices'][vi]['vectors'][0];raw=bytes(v['bytes']);assert sha(raw)==v['sha256'];actual=list(struct.unpack('<'+'I'*(len(raw)//4),raw));fail=v['failure'];assert fail['actual']==actual[fail['lane']]
  expected_actual=(1041865114,0,4) if mode=='lighting' else (0,1065353216,8)
  assert (fail['expected'],fail['actual'],fail['lane'])==expected_actual
  point=cite(path,'"name": "'+v['name']+'"',f'/acceptance/vertices/{vi}/vectors/0/failure')
 else:
  v=acc['fragments'][1]['draws'][-1];raw=bytes(v['rgbaBytes']);assert sha(raw)==v['rgbaSha256'];fail=v['failure'];assert list(raw[:4])==fail['actual']==[4,21,55,0] and fail['expected']==[4,21,55,64] and v['name']=='compositor-pixels-1-0';point=cite(path,'"name": "'+v['name']+'"',f'/acceptance/fragments/1/draws/{len(acc["fragments"][1]["draws"])-1}/failure')
 oldfaults.append({'mode':mode,'status':'HELD','failure':fail,'mutationOriginalSha256':mutation['sourceSha256'],'mutationServedSha256':mutation['servedSha256'],'objects':objs,'citation':point})
checks={'predictions':['P7','P9'],'status':'HELD','cleanReportSha256':sha((OUT/clean_path).read_bytes()),'predictionsSha256':sha(pred_bytes),'customWords':432,'customPixels':11520,'customRgbMaxUlp':max_ulp,'vectors':results,'draws':pixels,'customObjects':objects,'novelFault':{'failure':failure,'objects':faultobjects,'sourceOriginalSha256':fa['mutation']['originalSha256'],'sourceServedSha256':fa['mutation']['servedSha256'],'citation':cite(fault_path,'"name": "critic-gears-0"','/acceptance/vectors/0/failure')},'workerFaults':oldfaults}
(OUT/'attacks.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps({'status':'HELD','words':432,'pixels':11520,'maxUlp':max_ulp,'novelFault':failure,'sha256':sha((OUT/'attacks.json').read_bytes())}))
