import {createVirglShaderBridge} from '/renderer/virgl-shader/index.mjs';
const need=(v,m)=>{if(!v)throw new Error(m);};
const same=(a,b,m)=>need(JSON.stringify(a)===JSON.stringify(b),m);
const bits=new DataView(new ArrayBuffer(4));
const num=w=>{bits.setUint32(0,w,true);return bits.getFloat32(0,true);};
const word=n=>{bits.setFloat32(0,n,true);return bits.getUint32(0,true);};
const distance=(a,b)=>Math.abs((a>>>31?0x80000000-(a&0x7fffffff):0x80000000+a)-(b>>>31?0x80000000-(b&0x7fffffff):0x80000000+b));
const hash=async raw=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',typeof raw==='string'?new TextEncoder().encode(raw):raw))].map(x=>x.toString(16).padStart(2,'0')).join('');
export async function runAcceptance({fault=false}={}) {
  const report={schema:'gears-fresh-critic-hardware-v1',status:'running',guestExecution:false,productionNegotiation:false,fault,glErrors:[],vectors:[],draws:[],events:[],programs:[],rejections:[]};
  window.__virglGearsCriticReport=report;
  const canvas=document.querySelector('#gpu');canvas.width=canvas.height=16;
  const gl=canvas.getContext('webgl2',{antialias:false,preserveDrawingBuffer:true,failIfMajorPerformanceCaveat:true});
  need(gl instanceof WebGL2RenderingContext,'real WebGL2');
  const ext=gl.getExtension('WEBGL_debug_renderer_info');need(ext,'physical identity');
  report.renderer={vendor:gl.getParameter(ext.UNMASKED_VENDOR_WEBGL),renderer:gl.getParameter(ext.UNMASKED_RENDERER_WEBGL),version:gl.getParameter(gl.VERSION)};
  need(/ANGLE Metal/.test(report.renderer.renderer)&&!/software|swiftshader|llvmpipe/i.test(report.renderer.renderer),'real Metal hardware');
  const objects=[];
  const make=(kind,...args)=>{const value=gl['create'+kind](...args);need(value,'create '+kind);objects.push({kind,value,id:kind+':'+objects.length});report.events.push({call:'create'+kind,id:objects.at(-1).id});return value;};
  const clean=label=>{const error=gl.getError();if(error!==gl.NO_ERROR)report.glErrors.push({label,error});need(error===gl.NO_ERROR,'zero GL error '+label);};
  const bank=(program,name,rows,count)=>{
    const loc=gl.getUniformLocation(program,name+'[0]');need(loc,'bank active '+name);
    const index=gl.getUniformIndices(program,[name+'[0]'])[0];
    same(gl.getActiveUniforms(program,[index],gl.UNIFORM_TYPE)[0],gl.UNSIGNED_INT_VEC4,'raw uvec4 type');
    same(gl.getActiveUniforms(program,[index],gl.UNIFORM_SIZE)[0],count,'bank count');
    const raw=rows.flat();same(raw.length,count*4,'bank size');gl.uniform4uiv(loc,new Uint32Array(raw));
    const observed=[];for(let i=0;i<count;i++)observed.push(...gl.getUniform(program,gl.getUniformLocation(program,name+'['+i+']')));
    same(raw,observed,'actual uploaded bank');return {name,count,words:raw,observed};
  };
  const system=(program)=>{
    const idx=gl.getUniformBlockIndex(program,'VirglBlock');need(idx!==gl.INVALID_INDEX,'block active');
    same(gl.getActiveUniformBlockParameter(program,idx,gl.UNIFORM_BLOCK_DATA_SIZE),656,'block actual size');
    const ui=gl.getUniformIndices(program,['winsys_adjust_y'])[0];need(ui!==gl.INVALID_INDEX,'winsys reflection');
    same(gl.getActiveUniforms(program,[ui],gl.UNIFORM_OFFSET)[0],640,'actual winsys offset');same(gl.getActiveUniforms(program,[ui],gl.UNIFORM_TYPE)[0],gl.FLOAT,'actual winsys type');
    const data=new Uint8Array(656);new DataView(data.buffer).setFloat32(640,1,true);
    const buffer=make('Buffer');gl.bindBuffer(gl.UNIFORM_BUFFER,buffer);gl.bufferData(gl.UNIFORM_BUFFER,data,gl.STATIC_DRAW);gl.uniformBlockBinding(program,idx,0);gl.bindBufferBase(gl.UNIFORM_BUFFER,0,buffer);
    const actual=new Uint8Array(656);gl.getBufferSubData(gl.UNIFORM_BUFFER,0,actual);same([...actual],[...data],'actual system block bytes');return {byteLength:656,offset:640,value:1,bytes:[...actual]};
  };
  const attribute=(program,index,words)=>{
    const loc=gl.getAttribLocation(program,'in_'+index);need(loc>=0,'actual attribute');gl.disableVertexAttribArray(loc);gl.vertexAttrib4fv(loc,new Float32Array(words.map(num)));
    const observed=[...gl.getVertexAttrib(loc,gl.CURRENT_VERTEX_ATTRIB)].map(word);same(observed,words,'actual attribute snapshot');return {index,location:loc,words:observed};
  };
  async function program(pair,varyings=[]) {
    const p=make('Program'),saved={vertex:pair.vertex.glsl,fragment:pair.fragment.glsl};
    if(fault&&pair.vertexSha.startsWith('80a42bf3')){
      const rule=report.predictions.fault;need(saved.vertex.split(rule.needle).length===2,'one fault site');saved.vertex=saved.vertex.replace(rule.needle,rule.replacement);
      report.mutation={stage:'vertex',needle:rule.needle,replacement:rule.replacement,original:pair.vertex.glsl,served:saved.vertex,originalSha256:await hash(pair.vertex.glsl),servedSha256:await hash(saved.vertex)};
    }
    const rec={vertexSha:pair.vertexSha,fragmentSha:pair.fragmentSha,scope:pair.scope,shaderSources:saved,sourceDigests:{vertex:await hash(saved.vertex),fragment:await hash(saved.fragment)},varyings,logs:[]};report.programs.push(rec);
    for(const [type,source] of [[gl.VERTEX_SHADER,saved.vertex],[gl.FRAGMENT_SHADER,saved.fragment]]){
      const s=make('Shader',type);gl.shaderSource(s,source);gl.compileShader(s);const status=gl.getShaderParameter(s,gl.COMPILE_STATUS),log=gl.getShaderInfoLog(s);rec.logs.push({type,status,log});need(status,'hardware shader compiled');gl.attachShader(p,s);
    }
    if(varyings.length)gl.transformFeedbackVaryings(p,varyings,gl.INTERLEAVED_ATTRIBS);gl.linkProgram(p);rec.link={status:gl.getProgramParameter(p,gl.LINK_STATUS),log:gl.getProgramInfoLog(p)};need(rec.link.status,'hardware original program linked');return p;
  }
  const image=(width,height,raw)=>{const tex=make('Texture');gl.bindTexture(gl.TEXTURE_2D,tex);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA8,width,height,0,gl.RGBA,gl.UNSIGNED_BYTE,raw);return tex;};
  try {
    const predRaw=new Uint8Array(await (await fetch('/target/evidence/virgl-gears-shaders-verifier/novel-input-predictions.json')).arrayBuffer());report.predictionsSha256=await hash(predRaw);report.predictions=JSON.parse(new TextDecoder().decode(predRaw));
    const manifest=await (await fetch('/renderer/virgl-shader/tests/gears-originals.json')).json();
    const bridge=await createVirglShaderBridge(),entries=[];
    for(const e of [...manifest.originals,...manifest.retainedPartners]){
      const raw=new Uint8Array(await (await fetch('/'+e.path)).arrayBuffer());same(await hash(raw),e.sha256,'literal source hash');same(raw.length,e.bytes,'literal source bytes');const text=new TextDecoder().decode(raw);
      const single=bridge.translate({stage:e.stage,text});same(single.ok,e.admitted,'admission partition');if(!single.ok){same(single.error,e.rejection,'literal rejection');report.rejections.push({sha256:e.sha256,error:single.error});}else same(single.metadata,e.metadata,'literal source metadata');entries.push({...e,text});
    }
    const by=s=>entries.find(e=>e.sha256.startsWith(s));
    async function pair(v,f,scope){const vertex=by(v),fragment=by(f),result=bridge.translatePair({vertexText:vertex.text,fragmentText:fragment.text});need(result.ok,'pair support');return {...result,vertexSha:vertex.sha256,fragmentSha:fragment.sha256,scope};}
    const gp=await pair('80a42bf3','86d0ee79','captured-program'),cp=await pair('7bf4d0d0','c2474531','compatible-isolation'),tp=await pair('403b0529','c2474531','captured-program');
    for(const [prefix,p,vars,componentCount] of [['80a42bf3',gp,['gl_Position','vso_g0'],8],['7bf4d0d0',cp,['gl_Position','vso_g0','vso_g1'],12]]){
      const prog=await program(p,vars);gl.useProgram(prog);const vao=make('VertexArray');gl.bindVertexArray(vao);const block=system(prog);
      const reflection=[];for(let i=0;i<vars.length;i++){const r=gl.getTransformFeedbackVarying(prog,i);same([r.name,r.type,r.size],[vars[i],gl.FLOAT_VEC4,1],'written output reflection');reflection.push({name:r.name,type:r.type,size:r.size});}
      const tf=make('TransformFeedback'),buffer=make('Buffer');gl.bindTransformFeedback(gl.TRANSFORM_FEEDBACK,tf);gl.bindBuffer(gl.TRANSFORM_FEEDBACK_BUFFER,buffer);gl.bufferData(gl.TRANSFORM_FEEDBACK_BUFFER,componentCount*4,gl.DYNAMIC_READ);gl.bindBufferBase(gl.TRANSFORM_FEEDBACK_BUFFER,0,buffer);gl.enable(gl.RASTERIZER_DISCARD);
      for(const predicted of report.predictions.vectors.filter(v=>v.shader===prefix)){
        const rec={...predicted,reflection,systemBlock:block,attributes:predicted.inputWords.map((ws,i)=>attribute(prog,i,ws)),upload:bank(prog,'vsconst0',predicted.constantWords,predicted.constantWords.length),checks:[]};report.vectors.push(rec);
        gl.beginTransformFeedback(gl.POINTS);gl.drawArrays(gl.POINTS,0,1);gl.endTransformFeedback();const raw=new Uint8Array(componentCount*4);gl.getBufferSubData(gl.TRANSFORM_FEEDBACK_BUFFER,0,raw);clean(predicted.name);
        rec.bytes=[...raw];rec.rawSha256=await hash(raw);rec.observed=[...new Uint32Array(raw.buffer)];
        for(let lane=0;lane<predicted.expectedWords.length;lane++){
          const actual=rec.observed[lane],wanted=predicted.expectedWords[lane],budget=predicted.budgets[lane];const difference=distance(actual,wanted);rec.checks.push({lane,actual,expected:wanted,budget,ulp:difference});
          if(!(Number.isFinite(num(actual))&&difference<=budget)){rec.failure={lane,actual,expected:wanted,budget,ulp:difference};throw new Error('critic physical word fault '+predicted.name+' lane'+lane);}
        }
      }
      gl.disable(gl.RASTERIZER_DISCARD);gl.bindTransformFeedback(gl.TRANSFORM_FEEDBACK,null);gl.bindBufferBase(gl.TRANSFORM_FEEDBACK_BUFFER,0,null);gl.bindVertexArray(null);gl.useProgram(null);
    }
    const prog=await program(tp);gl.useProgram(prog);const vao=make('VertexArray');gl.bindVertexArray(vao);const block=system(prog),geometry=[-1,-1,0,1,1,-1,0,1,-1,1,0,1,-1,1,0,1,1,-1,0,1,1,1,0,1];
    const positions=make('Buffer');gl.bindBuffer(gl.ARRAY_BUFFER,positions);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(geometry),gl.STATIC_DRAW);const pl=gl.getAttribLocation(prog,'in_0');gl.enableVertexAttribArray(pl);gl.vertexAttribPointer(pl,4,gl.FLOAT,false,0,0);
    const target=image(16,16,null),fb=make('Framebuffer');gl.bindFramebuffer(gl.FRAMEBUFFER,fb);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,target,0);same(gl.checkFramebufferStatus(gl.FRAMEBUFFER),gl.FRAMEBUFFER_COMPLETE,'physical RGBA8 target');
    for(const cap of [gl.DITHER,gl.BLEND,gl.DEPTH_TEST,gl.CULL_FACE,gl.SCISSOR_TEST,gl.STENCIL_TEST])gl.disable(cap);gl.viewport(0,0,16,16);gl.colorMask(true,true,true,true);gl.activeTexture(gl.TEXTURE0);image(2,2,new Uint8Array(report.predictions.texels));
    const loc=gl.getUniformLocation(prog,'fssamp0');need(loc,'actual sampler');gl.uniform1i(loc,0);const ui=gl.getUniformIndices(prog,['fssamp0'])[0];same(gl.getActiveUniforms(prog,[ui],gl.UNIFORM_TYPE)[0],gl.SAMPLER_2D,'sampler reflection');same(gl.getUniform(prog,loc),0,'sampler unit0');
    for(const predicted of report.predictions.draws){
      const rec={...predicted,systemBlock:block,attribute:attribute(prog,1,predicted.inputWords[1]),uploads:[bank(prog,'vsconst0',predicted.constantWords,3),bank(prog,'fsconst0',predicted.fragmentWords,1)]};report.draws.push(rec);
      gl.clearColor(.2,.3,.4,.6);gl.clear(gl.COLOR_BUFFER_BIT);gl.drawArrays(gl.TRIANGLES,0,6);const raw=new Uint8Array(1024);gl.readPixels(0,0,16,16,gl.RGBA,gl.UNSIGNED_BYTE,raw);clean(predicted.name);rec.rgbaBytes=[...raw];rec.rawSha256=await hash(raw);rec.checkedPixels=0;
      for(let i=0;i<256;i++){const rgba=[...raw.slice(i*4,i*4+4)];if(rgba.some((v,l)=>Math.abs(v-predicted.expected[l])>predicted.budget)){rec.failure={pixel:i,actual:rgba,expected:predicted.expected};throw new Error('critic physical pixel fault '+predicted.name+' pixel'+i);}rec.checkedPixels++;}
    }
    report.checkedVertexWords=report.vectors.reduce((n,v)=>n+v.checks.length,0);report.checkedPixels=report.draws.reduce((n,d)=>n+d.checkedPixels,0);report.status='passed';document.querySelector('#status').textContent='Fresh critic vectors: '+report.checkedVertexWords+' exact/lighting words and '+report.checkedPixels+' independently predicted pixels';document.querySelector('#renderer').textContent=report.renderer.renderer;return report;
  }catch(error){report.status='failed';report.failure={message:error.message,stack:error.stack};document.querySelector('#status').textContent=error.message;throw error;}
  finally{
    gl.disable(gl.RASTERIZER_DISCARD);gl.bindBufferBase(gl.TRANSFORM_FEEDBACK_BUFFER,0,null);gl.bindTransformFeedback(gl.TRANSFORM_FEEDBACK,null);gl.bindBufferBase(gl.UNIFORM_BUFFER,0,null);gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.bindVertexArray(null);gl.useProgram(null);gl.bindBuffer(gl.ARRAY_BUFFER,null);gl.bindBuffer(gl.UNIFORM_BUFFER,null);gl.bindBuffer(gl.TRANSFORM_FEEDBACK_BUFFER,null);gl.bindTexture(gl.TEXTURE_2D,null);
    for(const item of objects.toReversed()){gl['delete'+item.kind](item.value);report.events.push({call:'delete'+item.kind,id:item.id});}
    for(const item of objects)need(gl['is'+item.kind](item.value)===false,'actual GL object disposed '+item.id);clean('complete disposal');report.objects={created:objects.length,actualDeleted:objects.length,live:0};
  }
}
