from pathlib import Path
import gzip,hashlib,io,json,tarfile
OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
excluded={'recording.tar.gz','manifest.json','records.json'}
files=[]
for file in sorted(OUT.rglob('*')):
 if not file.is_file():continue
 rel=file.relative_to(OUT)
 if rel.parts[0]=='authenticated-worker' or rel.parts[0].startswith('novel-setup-attempt') or '__pycache__' in rel.parts or str(rel) in excluded:continue
 files.append(file)
records=[];unique={}
for file in files:
 raw=file.read_bytes();digest=sha(raw);path=str(file.relative_to(OUT))
 if digest not in unique:unique[digest]={'path':path,'bytes':raw}
 records.append({'path':path,'storedMember':unique[digest]['path'],'bytes':len(raw),'sha256':digest})
assert len({r['path'] for r in records})==len(records)
index={'schema':'virgl-gears-original-critic-records-v1','task':'E6-T12g6a','sourceHead':'2e7f43167fe29d8ad0da92591888e27e2dbae589','submission':'c1a7f03490275d0d8ef9077d598c1e9d735cfb3c','workerArchiveSha256':'9941036d869021078ce41f67e219b568c24a5b00294598dba4b6873c67b3af6e','logicalRecords':len(records),'storedUniqueMembers':len(unique),'records':records,'excluded':'Worker extraction is referenced by its authenticated original seal; critic setup trials and Python caches are not final proof.'}
index_raw=(json.dumps(index,indent=2)+'\n').encode();(OUT/'records.json').write_bytes(index_raw)
with (OUT/'recording.tar.gz').open('wb') as archive:
 with gzip.GzipFile(filename='',mode='wb',fileobj=archive,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for entry in sorted(unique.values(),key=lambda e:e['path']):
    info=tarfile.TarInfo(entry['path']);info.size=len(entry['bytes']);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(entry['bytes']))
archive_raw=(OUT/'recording.tar.gz').read_bytes()
with tarfile.open(OUT/'recording.tar.gz','r:gz') as tar:
 members=tar.getmembers();names=[m.name for m in members];assert len(names)==len(set(names))==len(unique)
 assert set(names)=={r['storedMember'] for r in records}
 bound={m.name:tar.extractfile(m).read() for m in members};assert all(m.isfile() for m in members)
 assert len({sha(raw) for raw in bound.values()})==len(bound),'duplicate payloads in critic seal'
 for record in records:
  raw=bound[record['storedMember']];assert len(raw)==record['bytes'] and sha(raw)==record['sha256']
manifest={'schema':'virgl-gears-original-critic-seal-v1','task':'E6-T12g6a','verdict':'verified','sourceHead':index['sourceHead'],'submission':index['submission'],'base':'ee0277231f1903633881d803ba6153b58d31fd1c','workerArchiveSha256':index['workerArchiveSha256'],'workerIndexSha256':'66f7335f9d11d6cd9cca13b12bbf78e7ae4c43c8f0f3149baea41e514dcad5bb','logicalRecords':len(records),'storedUniqueMembers':len(unique),'membersAuthenticate':True,'duplicatePayloads':0,'archive':{'path':'recording.tar.gz','bytes':len(archive_raw),'sha256':sha(archive_raw)},'recordIndex':{'path':'records.json','bytes':len(index_raw),'sha256':sha(index_raw)},'verdictSha256':sha((OUT/'verdict.md').read_bytes()),'promotedTest':{'path':'renderer/virgl-shader/tests/gears-exact-alpha.mjs','sha256':'9b118502814dd7634fda76c1fc6df0d9eba679dbd73a469f413d8fd637a1f3da'},'exactAlphaWords':432,'novelHardwareWords':3024,'novelHardwarePixels':39168,'ownedBrowsersAndServersClosed':True}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
