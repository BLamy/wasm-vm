#!/usr/bin/env python3
"""Bounded verifier mutations and line coverage for the changed inventory boundary."""
import copy
import dis
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys
import types

ROOT=Path.cwd(); OUT=ROOT/'target/evidence/virgl-workload-inventory-verifier'
sys.path.insert(0,str(ROOT/'tools/virgl-capture'))
import inventory as model
import inventory_acceptance as acceptance
from validate import CaptureError

files={str(ROOT/'tools/virgl-capture'/p) for p in ('inventory.py','inventory_acceptance.py','gears_check.py','capture.py','validate.py')}
hits={p:{} for p in files}
def trace(frame,event,arg):
    if frame.f_code.co_filename in hits:
        if event=='line':
            table=hits[frame.f_code.co_filename]; line=frame.f_lineno;table[line]=table.get(line,0)+1
        return trace
    return None

sys.settrace(trace)
results=[]
try:
    gears=model.inventory(ROOT/'evidence/virgl-workload-inventory/captures/es2gears')
    kms=model.inventory(ROOT/'evidence/virgl-corpus/captures/kmscube')
    # Novel attack: make a valid command packet change its channel swizzle while
    # preserving framing, resource role, draw count, shader bytes and other state.
    directory=ROOT/'evidence/virgl-corpus/captures/kmscube'
    events=[json.loads(raw) for raw in (directory/'events.jsonl').read_bytes().splitlines()]
    summary=json.loads((directory/'summary.json').read_bytes())
    view=next(o for o in kms['clientObjects'] if o['kind']=='SAMPLER_VIEW')
    cite=view['citation'];event=events[cite['event']-1]
    raw=bytearray(model.blob(directory,event['blobs'][0]))
    struct.pack_into('<I',raw,cite['byteOffset']+24,(view['fields']['swizzleWord']&~(7<<3))|(5<<3))
    ref=event['blobs'][0]; old_digest=ref['sha256'];ref['sha256']=hashlib.sha256(raw).hexdigest()
    original=model.blob
    def modified(directory,reference):
        return bytes(raw) if reference['sha256']==ref['sha256'] else original(directory,reference)
    model.blob=modified
    try: changed=model.Inventory(directory,summary).run(events)
    finally:model.blob=original
    actual=next(o for o in changed['clientObjects'] if o['kind']=='SAMPLER_VIEW')['fields']['swizzle']
    assert actual==[0,5,2,3] and len(changed['clientDraws'])==48
    expected=json.loads((directory/'summary.json').read_bytes())
    if model.encoded(changed)==model.encoded({k:v for k,v in kms.items() if k not in ('eventsSha256','protocolSha256','formatEnumSha256')}):
        raise RuntimeError('novel well-framed view mutation escaped inventory equality')
    results.append({'case':'well-framed-kmscube-view-one-channel-swizzle',
                    'prediction':'Literal lane G changes from Y(1) to ONE(5); saved original inventory equality rejects despite unchanged 48 draws/shaders/resources.',
                    'result':'HELD','sourceEvent':cite['event'],'byteOffset':cite['byteOffset']+24,
                    'oldCommandSha256':old_digest,'newCommandSha256':ref['sha256'],
                    'observedSwizzle':actual,'clientDraws':48})
    # Novel lifetime attack: a newly named client cannot alias the still-live
    # supporting compositor's numeric context and borrow its object state.
    gd=ROOT/'evidence/virgl-workload-inventory/captures/es2gears'
    ge=[json.loads(raw) for raw in (gd/'events.jsonl').read_bytes().splitlines()]
    creation=next(e for e in ge if e['seq']==4410);creation['ctxId']=5
    try:model.Inventory(gd,json.loads((gd/'summary.json').read_bytes())).run(ge)
    except CaptureError as error:
        assert str(error)=='overlapping context inventory lifetime'
        results.append({'case':'named-client-aliases-live-supporting-context',
                        'prediction':'New named client context at event4410 cannot reuse live Hyprland numeric context5.',
                        'result':'HELD','sourceEvent':4410,'observed':str(error)})
    else:raise RuntimeError('accepted overlapping selected/supporting context')

    # Source sabotage: disable the *new* live process comm assertion. The new
    # acceptance harness must then fail at its wrong-client-comm mutation.
    source=ROOT/'tools/virgl-capture/gears_check.py'; rawsource=source.read_text()
    exact="require(artifacts['gears-comm.txt']==b'es2gears_waylan\\n','actual client comm differs')"
    assert rawsource.count(exact)==1
    fault=rawsource.replace(exact,"require(True,'actual client comm differs')")
    path=OUT/'gears_check_comm_fault.py';path.write_text(fault)
    namespace={'__name__':'gears_check_comm_fault','__file__':str(path)}
    exec(compile(fault,str(path),'exec'),namespace)
    baseline_check=acceptance.check_gears
    acceptance.check_gears=namespace['check_gears']
    sys.argv=['inventory_acceptance.py','--output',str(OUT/'must-not-exist-sabotage.json')]
    try:acceptance.main()
    except RuntimeError as error:
        assert str(error)=='accepted deliberate forgery: wrong-client-comm'
        results.append({'case':'source-sabotage-disables-new-comm-assertion',
                        'prediction':'New harness fails because wrong-client-comm survives the disabled assertion.',
                        'result':'HELD','observed':str(error),
                        'originalSourceSha256':hashlib.sha256(rawsource.encode()).hexdigest(),
                        'faultSourceSha256':hashlib.sha256(fault.encode()).hexdigest()})
    else:raise RuntimeError('new provenance tests insensitive to exercised source fault')
    finally:acceptance.check_gears=baseline_check
finally:
    sys.settrace(None)

def lines(code):
    found={line for _,line in dis.findlinestarts(code) if line>0}
    for item in code.co_consts:
        if isinstance(item,types.CodeType):found|=lines(item)
    return found
coverage=[]
for path,counts in sorted(hits.items()):
    executable=lines(compile(Path(path).read_bytes(),path,'exec'))
    coverage.append({'source':str(Path(path).relative_to(ROOT)),
                     'sourceSha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),
                     'lineHits':{str(k):v for k,v in sorted(counts.items())},
                     'unexecutedLines':sorted(executable-counts.keys())})
(OUT/'independent-attacks.json').write_text(json.dumps(results,indent=2)+'\n')
(OUT/'coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
print(json.dumps(results,indent=2))
