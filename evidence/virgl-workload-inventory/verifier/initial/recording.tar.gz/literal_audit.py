#!/usr/bin/env python3
"""Independent literal joins; does not call the worker's Inventory/check_gears."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess

ROOT = Path.cwd()
OUT = ROOT/'target/evidence/virgl-workload-inventory-verifier'
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def enum(name, prefix):
    text = (ROOT/'renderer/virgl-shader/vendor/src/virgl_protocol.h').read_text()
    body = re.search(r'enum\s+'+name+r'\s*\{(.*?)\}', text, re.S)[1]
    body = re.sub(r'/\*.*?\*/', '', body, flags=re.S)
    result, value = {}, 0
    for item in body.split(','):
        item = item.strip()
        if not item: continue
        parts = item.split('=')
        if len(parts)>1: value=int(parts[1].strip(),0)
        result[value]=parts[0].strip().removeprefix(prefix)
        value+=1
    return result

COMMANDS=enum('virgl_context_cmd','VIRGL_CCMD_')
OBJECTS=enum('virgl_object_type','VIRGL_OBJECT_')
FORMATS={int(value):name for name,value in re.findall(r'VIRGL_FORMAT_([A-Z0-9_]+)\s*=\s*([0-9]+)',
               (ROOT/'renderer/virgl-shader/vendor/src/virgl_hw.h').read_text())}

def audit(workload, directory, inventory_path):
    manifest=json.loads((directory/'manifest.json').read_bytes())
    inv=json.loads(inventory_path.read_bytes())
    eventraw=(directory/'events.jsonl').read_bytes()
    assert sha(eventraw)==manifest['events']['sha256'] and len(eventraw)==manifest['events']['bytes']
    events=[json.loads(line) for line in eventraw.splitlines()]
    cache={}
    def blob(ref):
        digest=ref['sha256']
        if digest not in cache:
            p=directory/'blobs'/(digest+'.bin')
            cache[digest]=p.read_bytes() if p.exists() else gzip.decompress(p.with_suffix('.bin.gz').read_bytes())
        raw=cache[digest]
        assert sha(raw)==digest and len(raw)==ref['bytes']
        return raw
    def citation(cite):
        event=events[cite['event']-1]
        assert event['seq']==cite['line']==cite['event'] and event['phase']=='enter' and event['type']=='submit_cmd'
        assert event['ctxId']==cite['contextId'] and event['blobs'][0]['sha256']==cite['blobSha256']
        raw=blob(event['blobs'][0])[cite['byteOffset']:cite['byteOffset']+cite['byteLength']]
        assert len(raw)==cite['byteLength'] and sha(raw)==cite['packetSha256']
        words=struct.unpack('<'+'I'*(len(raw)//4),raw)
        assert 4*(1+(words[0]>>16))==len(raw)
        return words
    for packet in inv['clientPackets']:
        w=citation(packet['citation'])
        assert list(w)==packet['words'] and COMMANDS[w[0]&255]==packet['opcode'] and OBJECTS[(w[0]>>8)&255]==packet['objectType']
    for obj in inv['clientObjects']:
        w=citation(obj['citation']); f=obj['fields']
        assert COMMANDS[w[0]&255]=='CREATE_OBJECT' and OBJECTS[(w[0]>>8)&255]==obj['kind'] and w[1]==obj['handle']
        kind=obj['kind']
        if kind=='SURFACE':
            assert f=={'format':w[3],'formatName':FORMATS[w[3]],'level':w[4],'firstLayer':w[5]&65535,'lastLayer':w[5]>>16}
        elif kind=='VERTEX_ELEMENTS':
            elements=[{'sourceOffset':w[i],'instanceDivisor':w[i+1],'bufferIndex':w[i+2],
                       'format':w[i+3],'formatName':FORMATS[w[i+3]]} for i in range(2,len(w),4)]
            assert f['elements']==elements
        elif kind=='SAMPLER_VIEW':
            assert (f['format'],f['target'],f['layerWord'],f['levelWord'],f['swizzleWord'])==(w[3]&0xffffff,w[3]>>24,w[4],w[5],w[6])
            assert f['swizzle']==[(w[6]>>(3*i))&7 for i in range(4)]
            assert (f['firstLayer'],f['lastLayer'],f['firstLevel'],f['lastLevel'])==(w[4]&65535,w[4]>>16,w[5]&255,(w[5]>>8)&255)
        elif kind=='SAMPLER_STATE':
            s=w[2]
            expected={'stateWord':s,'wrapS':s&7,'wrapT':(s>>3)&7,'wrapR':(s>>6)&7,'minImageFilter':(s>>9)&1,
                      'minMipFilter':(s>>11)&3,'magImageFilter':(s>>13)&1,'compareMode':(s>>15)&1,
                      'compareFunc':(s>>16)&7,'seamlessCube':(s>>19)&1,'maxAnisotropy':(s>>20)&31,
                      'lodBiasBits':w[3],'minLodBits':w[4],'maxLodBits':w[5],'borderColorBits':list(w[6:10])}
            assert f==expected
    resources={r['key']:r for r in inv['resources']}
    for r in resources.values():
        e=events[r['createEvent']-1]
        assert e['type']=='resource_create' and e['phase']=='enter'
        for k in ('resourceId','target','format','bind','width','height','depth','arraySize','lastLevel','nrSamples','flags'):
            assert e[k]==r[k]
        assert r['key']==f"{e['resourceId']}@{e['seq']}" and r['formatName']==FORMATS[r['format']]
        assert (r['y0Top'],r['mapPersistent'],r['mapCoherent'],r['unknownFlagBits'])==(bool(r['flags']&1),bool(r['flags']&2),bool(r['flags']&4),r['flags']&~7)
    live_ctx={}; live_res={}; contexts=[]; states={}; expected_roles={}; real_draws=[]
    selected_names={'es2gears':b'es2gears_waylan','kmscube':b'kmscube'}
    def newstate():
        return {'objects':{},'bound':{},'shaders':{},'colors':[],'depth':None,'vertices':[],
                'index':None,'views':{},'samplers':{},'uniforms':{}}
    def objkey(c,kind,handle,seq,offset): return f"{c['key']}/{c['sub']}/{kind}/{handle}@{seq}:{offset}"
    def get(s,kind,handle): return s['objects'][(kind,handle)] if handle else None
    def mark(c,key,role):
        if c['selected']: expected_roles.setdefault(key,set()).add(role)
    packet_count=0; object_lifetime_count=0
    for e in events:
        if e.get('phase')!='enter': continue
        kind=e['type']
        if kind in ('context_create','context_create_with_flags') and e['parentCallSeq']==0:
            assert e['ctxId'] not in live_ctx
            name=blob(e['blobs'][0]); key=f"{e['ctxId']}@{e['seq']}"
            c={'id':e['ctxId'],'key':key,'create':e['seq'],'name':name.decode(),'selected':name==selected_names[workload],
               'sub':0,'draws':0,'states':{}}
            contexts.append(c);live_ctx[e['ctxId']]=c
        elif kind=='context_destroy':
            live_ctx.pop(e['ctxId'])
        elif kind=='resource_create':
            assert e['resourceId'] not in live_res
            live_res[e['resourceId']]=f"{e['resourceId']}@{e['seq']}"
        elif kind=='resource_unref':
            live_res.pop(e['resourceId'])
        elif kind in ('reset','cleanup'):
            live_ctx.clear();live_res.clear()
        elif kind=='submit_cmd':
            c=live_ctx[e['ctxId']]; raw=blob(e['blobs'][0]); offset=0
            while offset<len(raw):
                h=struct.unpack_from('<I',raw,offset)[0];end=offset+4*(1+(h>>16))
                w=struct.unpack('<'+'I'*((end-offset)//4),raw[offset:end]);cmd=COMMANDS[h&255];kind=OBJECTS[(h>>8)&255]
                s=c['states'].setdefault(c['sub'],newstate());packet_count+=1
                if cmd=='SET_SUB_CTX': c['sub']=w[1]
                elif cmd=='CREATE_SUB_CTX': c['states'][w[1]]=newstate()
                elif cmd=='DESTROY_SUB_CTX': c['states'].pop(w[1],None)
                elif cmd=='CREATE_OBJECT':
                    key=objkey(c,kind,w[1],e['seq'],offset)
                    o={'key':key,'kind':kind,'words':w}
                    if kind in ('SURFACE','MSAA_SURFACE','SAMPLER_VIEW'): o['resource']=live_res[w[2]]
                    if kind=='SHADER':
                        # These captures have complete shaders in one packet; each is independently matched to retained bytes.
                        if not (w[3]&0x80000000):
                            o['stage']=w[2]
                            if c['selected']:
                                saved=next(ob for ob in inv['clientObjects'] if ob['key']==key)
                                text=(directory/'shaders'/(saved['fields']['sha256']+'.tgsi')).read_bytes()
                                assert sha(text)==saved['fields']['sha256'] and text in raw[offset+4*6:end]
                    s['objects'][(kind,w[1])]=o;object_lifetime_count+=1
                elif cmd=='DESTROY_OBJECT': s['objects'].pop((kind,w[1]),None)
                elif cmd=='BIND_OBJECT': s['bound'][kind]=get(s,kind,w[1])
                elif cmd=='BIND_SHADER': s['shaders'][w[2]]=get(s,'SHADER',w[1])
                elif cmd=='SET_FRAMEBUFFER_STATE':
                    s['colors']=[get(s,'SURFACE',v) for v in w[3:]];s['depth']=get(s,'SURFACE',w[2])
                elif cmd=='SET_VERTEX_BUFFERS':
                    s['vertices']=[{'stride':w[i],'offset':w[i+1],'resource':live_res[w[i+2]],'resourceId':w[i+2]}
                                   if w[i+2] else None for i in range(1,len(w),3)]
                elif cmd=='SET_INDEX_BUFFER':
                    s['index']={'resource':live_res[w[1]],'indexBytes':w[2],'offset':w[3]} if w[1] else None
                elif cmd in ('SET_SAMPLER_VIEWS','BIND_SAMPLER_STATES'):
                    table=s['views' if cmd=='SET_SAMPLER_VIEWS' else 'samplers'];object_kind='SAMPLER_VIEW' if cmd=='SET_SAMPLER_VIEWS' else 'SAMPLER_STATE'
                    for slot,handle in enumerate(w[3:],w[2]):table[(w[1],slot)]=get(s,object_kind,handle)
                elif cmd=='SET_UNIFORM_BUFFER':
                    s['uniforms'][(w[1],w[2])]={'resource':live_res[w[5]]} if w[5] else None
                elif cmd=='DRAW_VBO':
                    c['draws']+=1
                    if c['selected']:
                        for o in s['colors']:
                            if o:mark(c,o['resource'],'color-surface')
                        if s['depth']:mark(c,s['depth']['resource'],'depth-stencil-surface')
                        ve=s['bound']['VERTEX_ELEMENTS']
                        for i in range(2,len(ve['words']),4):mark(c,s['vertices'][ve['words'][i+2]]['resource'],'vertex-buffer')
                        if w[4]:mark(c,s['index']['resource'],'index-buffer')
                        for view in s['views'].values():
                            if view:mark(c,view['resource'],'sampler-view')
                        for uniform in s['uniforms'].values():
                            if uniform:mark(c,uniform['resource'],'uniform-buffer')
                        d=next(d for d in inv['clientDraws'] if (d['citation']['event'],d['citation']['byteOffset'])==(e['seq'],offset))
                        assert d['words']==list(w[1:]) and d['citation']['contextCreateEvent']==c['create']
                        assert d['colors']==[o['key'] if o else None for o in s['colors']] and d['depth']==(s['depth']['key'] if s['depth'] else None)
                        assert d['vertexElements']==ve['key'] and d['shaders']=={str(k):o['key'] for k,o in s['shaders'].items() if o}
                        assert [{k:v for k,v in vb.items() if k!='citation'} if vb else None for vb in d['vertexBuffers']]==s['vertices']
                        real_draws.append(d['citation'])
                offset=end
    expected_contexts={c['key']:c for c in contexts}
    for c in inv['contexts']:
        actual=expected_contexts[c['key']]
        assert (c['name'],c['selected'],c['drawCount'])==(actual['name'],actual['selected'],actual['draws'])
    selected={c['key'] for c in contexts if c['selected']}
    for key,r in resources.items():
        roles=set()
        for c,use in r['uses'].items():
            if c in selected:roles.update(use['drawRoles'])
        assert roles==expected_roles.get(key,set()), (key,roles,expected_roles.get(key,set()))
    assert len(real_draws)==len(inv['clientDraws'])
    assert inv['supportingDraws']==sum(c['draws'] for c in contexts if not c['selected'])
    for t in inv['clientTransfers']:
        w=citation(t['citation'])
        assert (t['level'],t['usage'],t['stride'],t['layerStride'],t['box'])==(w[2],w[3],w[4],w[5],dict(zip(('x','y','z','w','h','d'),w[6:12])))
        if t['opcode']=='TRANSFER3D':assert (t['dataOffset'],t['direction'])==(w[12],w[13])
        elif t['opcode']=='COPY_TRANSFER3D':assert (t['sourceOffset'],t['flags'])==(w[13],w[14])
        for k in ('backingAtSubmit','sourceBackingAtSubmit'):
            if t.get(k):
                b=t[k];e=events[b['event']-1];assert e['type']=='backing_snapshot' and e['blobs'][0]==b['blob'] and e['iovLengths']==b['iovLengths']
    first,last=inv['clientDraws'][0],inv['clientDraws'][-1]
    return {'workload':workload,'captureManifestSha256':sha((directory/'manifest.json').read_bytes()),
            'eventsSha256':sha(eventraw),'authenticatedPacketCitations':len(inv['clientPackets']),
            'authenticatedObjectCitations':len(inv['clientObjects']),'authenticatedTransferCitations':len(inv['clientTransfers']),
            'clientDraws':len(real_draws),'supportingDraws':inv['supportingDraws'],
            'contexts':[{k:c[k] for k in ('id','key','name','selected','draws')} for c in contexts],
            'firstDrawCitation':first['citation'],'lastDrawCitation':last['citation'],
            'resourceCreates':len(resources),'requiredFormats':inv['clientResourceFormats'],
            'clientVertexFormats':inv['clientVertexFormats'],'clientInlineWrites':inv['clientInlineWriteCount'],
            'totalPackets':packet_count,'totalObjectLifetimes':object_lifetime_count}

if __name__=='__main__':
    results=[audit('es2gears',ROOT/'evidence/virgl-workload-inventory/captures/es2gears',ROOT/'evidence/virgl-workload-inventory/es2gears-inventory.json'),
             audit('kmscube',ROOT/'evidence/virgl-corpus/captures/kmscube',ROOT/'evidence/virgl-workload-inventory/kmscube-inventory.json')]
    (OUT/'literal-audit.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps([{'workload':r['workload'],'clientDraws':r['clientDraws'],'supportingDraws':r['supportingDraws'],
                       'clientPackets':r['authenticatedPacketCitations'],'clientObjects':r['authenticatedObjectCitations']} for r in results]))
