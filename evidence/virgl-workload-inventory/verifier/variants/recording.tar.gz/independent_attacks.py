#!/usr/bin/env python3
"""Bounded verifier-only input and source faults; no tracked runtime writes."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys

ROOT=Path.cwd()
OUT=ROOT/'target/evidence/virgl-workload-inventory-verifier/variants'
BASE=OUT/'archives/worker/variants/acceptance/normal'
sys.path.insert(0,str(ROOT/'tools/virgl-capture/tests'))
sys.path.insert(0,str(ROOT/'tools/virgl-capture'))
import inventory
from validate import validate_events
import inventory_variants as variants
sha=lambda raw:hashlib.sha256(raw).hexdigest()
write=lambda path,value:path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

source=BASE/'objects-index-uniform'
directory=OUT/'declared-index-role-fault'
directory.mkdir(exist_ok=True)
shutil.copytree(source/'blobs',directory/'blobs',dirs_exist_ok=True)
events=[json.loads(line) for line in (source/'events.jsonl').read_bytes().splitlines()]
changed=[e for e in events if e['type']=='resource_create' and e.get('phase')=='enter' and e['resourceId']==4]
assert len(changed)==1 and changed[0]['bind']==32
changed[0]['bind']=64
raw=(''.join(json.dumps(e,sort_keys=True)+'\n' for e in events)).encode()
(directory/'events.jsonl').write_bytes(raw)
blobs={p.stem:p.read_bytes() for p in (directory/'blobs').glob('*.bin')}
assert all(sha(b)==h for h,b in blobs.items())
summary,shaders,_=validate_events(events,blobs.__getitem__)
summary['manifestSha256']=sha(raw)
write(directory/'framing-summary.json',summary)
model=inventory.Inventory(directory,summary)
key='4@'+str(changed[0]['seq'])
context=next(e for e in events if e['type']=='context_create' and e.get('phase')=='enter' and e['ctxId']==4)
expected=f"actual client role index-buffer contradicts resource {key} bind 64 at context 4@{context['seq']}"
try:
    model.run(iter(events))
except inventory.CaptureError as error:
    assert str(error)==expected,(str(error),expected)
    attack={'passed':True,'framingValid':True,'mutation':{'resourceId':4,'event':changed[0]['seq'],'oldBind':32,'newBind':64},
        'firstIndexedDraw':next(d['citation'] for d in model.draws if d['words'][3]==1) if any(d['words'][3]==1 for d in model.draws) else {'event':58,'byteOffset':64},
        'expectedError':expected,'observedError':str(error),'eventsSha256':sha(raw),'executedInventorySha256':sha(Path(inventory.__file__).read_bytes())}
else:
    raise AssertionError('declared-index-role mutant escaped')
write(directory/'result.json',attack)

faultroot=OUT/'buffer-element-source-fault'
faultroot.mkdir(exist_ok=True)
original=Path(inventory.__file__).read_text()
needle='fields.update(firstElement=w[4],lastElement=w[5])'
assert original.count(needle)==1
faultsource=original.replace(needle,'fields.update(firstElement=w[4],lastElement=w[5]+1)')
fault=faultroot/'inventory-last-element.py'
fault.write_text(faultsource)
spec=importlib.util.spec_from_file_location('verifier_inventory_last_element_fault',fault)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
try:
    variants.run_case(module,faultroot,'objects-index-uniform',variants.bindings,variants.check_bindings)
except AssertionError as error:
    rows=json.loads((faultroot/'objects-index-uniform/assertions.json').read_bytes())
    failed=[row for row in rows if not row['held']]
    assert len(failed)==1 and failed[0]['prediction']=='buffer-view literal fields'
    assert failed[0]['expected']['lastElement']==13 and failed[0]['observed']['lastElement']==14
    sensitivity={'passed':True,'assertion':failed[0],'observedError':str(error),
        'originalInventorySha256':sha(original.encode()),'faultInventorySha256':sha(fault.read_bytes())}
else:
    raise AssertionError('buffer-element source fault escaped')
write(faultroot/'result.json',sensitivity)
print(json.dumps({'declaredRoleRejected':attack['passed'],'bufferElementSourceFaultDetected':sensitivity['passed']}))
