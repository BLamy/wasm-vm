#!/usr/bin/env python3
"""Independent literal replay of the sealed synthetic sessions, not Inventory."""
import copy
import hashlib
import json
from pathlib import Path
import struct
import subprocess

ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-workload-inventory-verifier/variants'
SEALED=OUT/'archives/worker/variants';BASE=SEALED/'acceptance/normal'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
VERTEX=b"VERT\nDCL IN[0]\nDCL OUT[0], POSITION\n  0: MOV OUT[0], IN[0]\n  1: END\n"
FRAGMENT=b"FRAG\nDCL OUT[0], COLOR\nIMM[0] FLT32 {1.0, 0.0, 0.0, 1.0}\n  0: MOV OUT[0], IMM[0]\n  1: END\n"

def inspect(case):
    d=BASE/case;event_raw=(d/'events.jsonl').read_bytes();events=[json.loads(raw) for raw in event_raw.splitlines()]
    inv=json.loads((d/'inventory.json').read_bytes());labels=json.loads((d/'fixture-labels.json').read_bytes())
    assertions=json.loads((d/'assertions.json').read_bytes());observations=json.loads((d/'observations.json').read_bytes())
    blobs={p.stem:p.read_bytes() for p in (d/'blobs').glob('*.bin')}
    for h,raw in blobs.items():assert sha(raw)==h
    for e in events:
        for b in e['blobs']:assert len(blobs[b['sha256']])==b['bytes']
    assert all(a['held'] is True and a['expected']==a['observed'] for a in assertions)
    resources={};contexts={};historical_resources={};current_backings={};objects={};pending={};draws=[];transfers=[];roles={};expected_error=None
    label_packets=0;shader_assemblies=[];boundary_states=[]
    def lookup(c,kind,handle):return c['objects'][(kind,handle)] if handle else None
    def mark(c,key,role):
        if c['name']==b'kmscube':roles.setdefault((key,c['key']),set()).add(role)
    def backing(key):return current_backings.get(key)
    for e in events:
        t=e['type'];seq=e['seq']
        if t=='backing_snapshot':
            key=resources[e['resourceId']]
            current_backings[key]={'event':seq,'line':seq,'reason':e['reason'],'iovLengths':e['iovLengths'],'blob':e['blobs'][0]}
            continue
        if e.get('phase')!='enter':continue
        if t=='context_create':
            key=f"{e['ctxId']}@{seq}";contexts[e['ctxId']]={'key':key,'name':blobs[e['blobs'][0]['sha256']],
                'objects':{},'bound':{},'shaders':{},'vertices':[],'colors':[],'depth':None,'index':None,'uniforms':{},'views':{},'samplers':{}}
        elif t=='resource_create':
            key=f"{e['resourceId']}@{seq}";resources[e['resourceId']]=key;historical_resources[key]=e
        elif t=='resource_unref':resources.pop(e['resourceId'])
        elif t in ('reset','cleanup'):
            contexts.clear();resources.clear();pending.clear()
            o=next(o for o in observations if o['event']==seq)
            assert o['liveContexts']==o['liveResources']==o['states']=={}
            boundary_states.append({'event':seq,'type':t,'liveContexts':{},'liveResources':{}})
        elif t=='submit_cmd':
            c=contexts[e['ctxId']];raw=blobs[e['blobs'][0]['sha256']];offset=0
            while offset<len(raw):
                header=struct.unpack_from('<I',raw,offset)[0];end=offset+4*(1+(header>>16));body=raw[offset:end]
                w=struct.unpack('<'+'I'*((end-offset)//4),body);cmd=header&255;kind=(header>>8)&255
                cite={'event':seq,'line':seq,'contextId':e['ctxId'],'contextCreateEvent':int(c['key'].split('@')[1]),
                      'subcontext':0,'byteOffset':offset,'byteLength':len(body),'blobSha256':sha(raw),'packetSha256':sha(body)}
                matches=[l for l in labels.values() if (l['event'],l['byteOffset'])==(seq,offset)]
                if matches:
                    assert len(matches)==1; l=matches[0]
                    # Labels identify input chunks; one negative chunk combines
                    # a zero index binding and the following indexed draw.
                    chunk=raw[offset:offset+l['byteLength']]
                    expected_label={**cite,'byteLength':len(chunk),'packetSha256':sha(chunk)}
                    assert {k:v for k,v in l.items() if k not in ('words','snapshots')}==expected_label
                    assert l['words']==list(struct.unpack('<'+'I'*(len(chunk)//4),chunk))
                    label_packets+=1
                if cmd==1:
                    names={4:'SHADER',5:'VERTEX_ELEMENTS',6:'SAMPLER_VIEW',7:'SAMPLER_STATE',8:'SURFACE',11:'MSAA_SURFACE'}
                    name=names[kind];key=f"{c['key']}/0/{name}/{w[1]}@{seq}:{offset}"
                    obj={'key':key,'kind':name,'resource':None,'fields':{},'citation':cite,'words':w}
                    if kind in (8,11):
                        obj['resource']=resources[w[2]];obj['fields']={'format':w[3],'formatName':'R8G8B8A8_UNORM','level':w[4],
                            'firstLayer':w[5]&0xffff,'lastLayer':w[5]>>16}
                        if kind==11:obj['fields']['sampleCount']=w[6]
                    elif kind==6:
                        assert historical_resources[resources[w[2]]]['target']==0
                        obj['resource']=resources[w[2]];obj['fields']={'format':w[3]&0xffffff,'formatName':'R8G8B8A8_UNORM','target':w[3]>>24,
                            'layerWord':w[4],'levelWord':w[5],'swizzleWord':w[6],'swizzle':[(w[6]>>(3*i))&7 for i in range(4)],
                            'firstElement':w[4],'lastElement':w[5]}
                    elif kind==4:
                        pk=(c['key'],w[2]);fragment=body[24:]
                        if not(w[3]&0x80000000):pending[pk]={'handle':w[1],'declared':w[3],'data':fragment,'packets':[(seq,offset,False)]}
                        else:
                            p=pending[pk];assert p['handle']==w[1] and len(p['data'])==(w[3]&0x7fffffff)
                            p['data']+=fragment;p['packets'].append((seq,offset,True))
                        p=pending[pk]
                        if len(p['data'])<p['declared']:
                            o=next(o for o in observations if o['event']==seq);assert o['shaderObjects']==[]
                            offset=end;continue
                        text=p['data'][:p['declared']-1];assert p['data'][p['declared']-1]==0
                        assert text==(VERTEX if w[2]==0 else FRAGMENT)
                        assert (d/(sha(text)+'.tgsi')).read_bytes()==text
                        obj['fields']={'sha256':sha(text),'bytes':len(text),'stage':'VERT' if w[2]==0 else 'FRAG'}
                        shader_assemblies.append({'handle':w[1],'stage':obj['fields']['stage'],'sha256':sha(text),'fragments':p['packets'],'completedObjectKey':key})
                        del pending[pk]
                    c['objects'][(kind,w[1])]=obj;objects[key]=obj
                elif cmd==2:c['bound'][kind]=lookup(c,kind,w[1])
                elif cmd==31:c['shaders'][w[2]]=lookup(c,4,w[1])
                elif cmd==5:c['colors']=[lookup(c,8,h) for h in w[3:]];c['depth']=lookup(c,8,w[2])
                elif cmd==6:c['vertices']=[{'stride':w[i],'offset':w[i+1],'resourceId':w[i+2],'resource':resources[w[i+2]],'citation':cite} for i in range(1,len(w),3)]
                elif cmd==10:
                    for slot,handle in enumerate(w[3:],w[2]):c['views'][(w[1],slot)]=lookup(c,6,handle)
                elif cmd==18:
                    for slot,handle in enumerate(w[3:],w[2]):c['samplers'][(w[1],slot)]=lookup(c,7,handle)
                elif cmd in (11,27):
                    rid=w[1] if cmd==11 else w[5]
                    if rid and rid not in resources:expected_error=f'packet references missing live resource {rid}';break
                    if cmd==11:c['index']={'resourceId':rid,'resource':resources[rid],'indexBytes':w[2],'offset':w[3],'citation':cite} if rid else None
                    else:c['uniforms'][(w[1],w[2])]={'resourceId':rid,'resource':resources[rid],'offset':w[3],'length':w[4],'citation':cite} if rid else None
                elif cmd==8:
                    if w[4] and c['index'] is None:expected_error='indexed draw has no index resource';break
                    if c['name']==b'kmscube':
                        for surf in c['colors']:mark(c,surf['resource'],'color-surface')
                        for vb in c['vertices']:mark(c,vb['resource'],'vertex-buffer')
                        if w[4]:mark(c,c['index']['resource'],'index-buffer')
                        for view in c['views'].values():
                            if view:mark(c,view['resource'],'sampler-view')
                        uniforms=[u for u in c['uniforms'].values() if u]
                        for u in uniforms:mark(c,u['resource'],'uniform-buffer')
                        drawn={'citation':cite,'words':list(w[1:]),'indexBuffer':copy.deepcopy(c['index']) if w[4] else None,
                               'uniformBuffers':copy.deepcopy(uniforms),'vertexBuffers':copy.deepcopy(c['vertices']),
                               'colors':[surf['key'] for surf in c['colors']],'shaders':{str(k):obj['key'] for k,obj in c['shaders'].items()}}
                        draws.append(drawn)
                elif cmd in (9,45):
                    key=resources[w[1]];tr={'opcode':'COPY_TRANSFER3D' if cmd==45 else 'RESOURCE_INLINE_WRITE','resource':key,
                        'level':w[2],'usage':w[3],'stride':w[4],'layerStride':w[5],
                        'box':dict(zip(('x','y','z','w','h','d'),w[6:12])),'citation':cite,'backingAtSubmit':backing(key)}
                    if cmd==45:
                        src=resources[w[12]];tr.update(sourceResource=src,sourceOffset=w[13],flags=w[14],sourceBackingAtSubmit=backing(src))
                    else:tr.update(inlineBytes=len(body)-48,inlineSha256=sha(body[48:]))
                    transfers.append(tr)
                offset=end
            if expected_error:break
    if expected_error:
        assert inv=={'rejected':True,'error':expected_error}
    else:
        assert not pending and len(draws)==len(inv['clientDraws'])
        for expected,observed in zip(draws,inv['clientDraws']):
            for key,value in expected.items():assert observed[key]==value,(case,key,observed[key],value)
        assert transfers==inv['clientTransfers']
        for obj in inv['clientObjects']:
            expected=objects[obj['key']]
            assert obj['citation']==expected['citation'] and obj['resource']==expected['resource']
            if obj['kind'] in ('SURFACE','MSAA_SURFACE','SAMPLER_VIEW'):assert obj['fields']==expected['fields']
            elif obj['kind']=='SHADER':
                for k,v in expected['fields'].items():assert obj['fields'][k]==v
        for res in inv['resources']:
            for context,use in res['uses'].items():assert set(use['drawRoles'])==roles.get((res['key'],context),set())
        if case=='copy-inline':
            copied,inlined=transfers
            assert copied['sourceOffset']==19 and copied['flags']==3
            assert blobs[copied['backingAtSubmit']['blob']['sha256']]==bytes(range(63,-1,-1))
            assert blobs[copied['sourceBackingAtSubmit']['blob']['sha256']]==bytes(range(100,164))
            assert inlined['inlineBytes']==12 and inlined['inlineSha256']==sha(bytes.fromhex('010203045566778899000000'))
        if case.endswith('-reuse'):
            assert len(boundary_states)==1 and draws[0]['vertexBuffers'][0]['resource']!=draws[3]['vertexBuffers'][0]['resource']
            assert all(draw['indexBuffer'] is None and draw['uniformBuffers']==[] for draw in draws[3:])
            assert transfers[-1]['sourceBackingAtSubmit'] is None and transfers[-1]['sourceResource'].split('@')[0]=='6'
    return {'case':case,'events':len(events),'eventsSha256':sha(event_raw),'assertionsChecked':len(assertions),
            'labelChunkCitationsChecked':label_packets,'independentDrawBindingsChecked':len(draws),
            'independentTransfersChecked':len(transfers),'shaderAssemblies':shader_assemblies,
            'boundaryStates':boundary_states,'expectedDecoderRejection':expected_error,
            'coverage':json.loads((d/'coverage.json').read_bytes())}

if __name__=='__main__':
    bindings=json.loads((SEALED/'source-bindings.json').read_bytes())
    for ref in bindings:
        raw=(SEALED/'sources'/ref['path']).read_bytes()
        assert len(raw)==ref['bytes'] and sha(raw)==ref['sha256']
        assert raw==(ROOT/ref['path']).read_bytes()
        assert raw==subprocess.check_output(['git','show','cfbe69fae8fc1b4befe85785d186a4449144f961:'+ref['path']])
    cases=['objects-index-uniform','copy-inline','reset-reuse','cleanup-reuse','index-missing-resource','uniform-missing-resource','index-unbound-draw']
    rows=[inspect(case) for case in cases]
    assert sum(r['assertionsChecked'] for r in rows)==66
    lines={line for r in rows for line in r['coverage']['lines']}
    required={139,147,166,221,222,223,231,232,233,255,256,257,258,260,261,291,292,301,302,370,371}
    assert required<=lines and all(r['coverage']['sourceSha256']==sha((ROOT/'tools/virgl-capture/inventory.py').read_bytes()) for r in rows)
    result={'sourceBindingsChecked':len(bindings),'sealedSourceHead':'cfbe69fae8fc1b4befe85785d186a4449144f961',
            'cases':rows,'requiredLineHits':sorted(required),'assertionsChecked':66,'passed':True}
    (OUT/'literal-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'passed':True,'cases':len(rows),'assertionsChecked':66,'sourceBindingsChecked':len(bindings),'demandedLinesChecked':len(required)}))
