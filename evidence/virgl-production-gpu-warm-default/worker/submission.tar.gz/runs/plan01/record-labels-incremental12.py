from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path.cwd(); base=root/'target/evidence/production-gpu-warm-pristine11'; clone=base/'clone'; out=base/'incremental923';out.mkdir(exist_ok=False)
original=base/'report.json';base_report=json.loads(original.read_text());assert base_report['status']=='passed';assert base_report['head']=='847f51927637c9ff8226068986a771c9e2a5bedc'
head='9236bc1b7f89f662ae093d4fe95a15e57e909747';env={k:v for k,v in os.environ.items() if k not in ('RUSTFLAGS','RUSTDOCFLAGS','RUST_LOG') and not k.startswith(('CARGO_','VIRGL_','CRITIC_'))}
r={'scope':'incremental launcher-label and source-recorder proof in the already fully isolated clone; unchanged runtime holds carried','head':head,'runtimeHead':base_report['head'],'basePristineReportSha256':hashlib.sha256(original.read_bytes()).hexdigest(),'status':'running','commands':[],'started':time.time(),'copiedArtifactOrBuildCache':False}
def run(name,cmd):
 start=time.time()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:p=subprocess.run(cmd,cwd=clone,env=env,stdout=stdout,stderr=stderr)
 r['commands'].append({'name':name,'command':cmd,'seconds':time.time()-start,'exitCode':p.returncode});(out/'report.json').write_text(json.dumps(r,indent=2)+'\n');assert p.returncode==0,name
try:
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=clone)
 run('fetch',['git','fetch','origin','codex/omarchy-gpu-warm-publication']);run('exact-head',['git','checkout','--detach',head])
 assert not (clone/'.git/objects/info/alternates').exists();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==head
 changed=subprocess.check_output(['git','diff','--name-only',r['runtimeHead'],head],cwd=clone,text=True).splitlines();assert set(changed)=={'tools/verify-reviewed-site.mjs','tools/virgl-production/critic-fast-boots.mjs','web/index.html','web/dist/app.html','web/dist/sw.js'};r['incrementalFiles']=changed
 for path in ('web/main.js','web/dist/main.js','web/loader.js','web/dist/loader.js','web/linux-worker.js','web/linux-worker-protocol.js','web/gpu-checkpoint.js','web/dist/pkg/wasm_vm_wasm_bg.wasm'):
  assert (clone/path).read_bytes()==subprocess.check_output(['git','show',r['runtimeHead']+':'+path],cwd=clone)
 run('web-dist',['make','web-dist']);assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=clone)
 assert '06622e33ac7fa11a0163e8c58e9f8f36dc2043830d79a04f41e001b847916527' in (clone/'web/dist/gpu-checkpoint-build.js').read_text()
 run('source-recorder-tests',['node','--test','tools/virgl-production/critic-fast-boots-protocol.test.mjs','tools/virgl-production/critic-fast-boots-final.test.mjs','tools/virgl-production/critic-gpu-restored-clock.test.mjs','tools/virgl-production/critic-warm-ui-fixtures.test.mjs','tools/virgl-production/critic-warm-pixels.test.mjs','tools/virgl-production/published-source.test.mjs'])
 run('launcher-and-site',['node','tools/verify-reviewed-site.mjs','--output',str(out/'launcher-and-site')])
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=clone);r['status']='passed'
except BaseException as error:r['status']='failed';r['failure']=str(error);raise
finally:
 r['finished']=time.time();r['files']=[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file() and p.name!='report.json'];(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
