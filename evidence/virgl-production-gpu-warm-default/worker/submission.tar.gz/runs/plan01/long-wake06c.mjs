import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createServer} from 'node:http';
import {createHash} from 'node:crypto';

const repo=process.cwd(),output=path.join(repo,'target/evidence/production-gpu-ready-wake06c');
await fs.mkdir(output,{recursive:false});
const rows=await(await fetch('http://127.0.0.1:9231/json/list')).json();
assert.equal(rows.length,1);assert.ok(rows[0].url.endsWith('/tools/virgl-production/critic-fast-boots.mjs'));
const ws=new WebSocket(rows[0].webSocketDebuggerUrl);await new Promise(r=>ws.addEventListener('open',r,{once:true}));
let serial=0;const pending=new Map();
ws.addEventListener('message',e=>{const d=JSON.parse(e.data);if(d.id){pending.get(d.id)?.(d);pending.delete(d.id);}});
const send=(method,params={})=>new Promise(r=>{const id=++serial;pending.set(id,r);ws.send(JSON.stringify({id,method,params}));});
const report={status:'running',scope:'Prepared factory from the still-live genuine cold production source05; no worker identity rewrite',source:'production-gpu-ready-factory05',commands:[],uploads:[]};
const save=()=>fs.writeFile(path.join(output,'capture-report.json'),JSON.stringify(report,null,2)+'\n');
async function evaluate(label,expression){
 const row={label,expression,started:Date.now()};report.commands.push(row);await save();
 const reply=await send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});
 row.finished=Date.now();row.reply=reply;await save();
 assert.equal(reply.result?.exceptionDetails,undefined,label);assert.ok(!reply.error,label);
 return reply.result.result.value;
}
let owner,handle,written=0,total,sha=createHash('sha256');
const server=createServer(async(req,res)=>{
 try{
  assert.equal(req.headers.origin,owner.origin);
  res.setHeader('Access-Control-Allow-Origin',owner.origin);res.setHeader('Access-Control-Allow-Methods','POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers','Content-Type');res.setHeader('Cross-Origin-Resource-Policy','cross-origin');
  if(req.method==='OPTIONS'){res.writeHead(204).end();return;}
  assert.equal(req.method,'POST');const m=req.url.match(/^\/pair\/(\d+)\/(\d+)$/);assert.ok(m);
  const offset=Number(m[1]),size=Number(m[2]);assert.ok(Number.isSafeInteger(size)&&size>0&&size<=512*1024*1024);
  assert.equal(offset,written);if(total===undefined){total=size;handle=await fs.open(path.join(output,'factory.wvgpair'),'wx');}
  assert.equal(total,size);assert.ok(handle);
  const parts=[];let bytes=0;for await(const p of req){bytes+=p.length;assert.ok(bytes<=1024*1024);parts.push(p);}
  assert.ok(bytes>0&&bytes<=total-written);const body=Buffer.concat(parts);await handle.writeFile(body);sha.update(body);written+=body.length;
  report.uploads.push({offset,bytes:body.length});let pin={written,total,complete:false};
  if(written===total){await handle.close();handle=null;pin={path:'factory.wvgpair',bytes:total,sha256:sha.digest('hex'),complete:true};report.pin=pin;await save();}
  res.writeHead(200,{'Content-Type':'application/json'}).end(JSON.stringify(pin));
 }catch(error){res.writeHead(400).end(String(error));}
});
try{
 owner=await evaluate('owned-source',`({url:__ownedFactoryPage.url(),origin:__ownedFactoryOrigin})`);
 const u=new URL(owner.url);assert.equal(u.origin,owner.origin);assert.equal(u.hostname,'127.0.0.1');assert.equal(u.searchParams.get('guest'),'omarchy');assert.ok(u.searchParams.has('noSnapshot'));
 report.owner=owner;
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const collector='http://127.0.0.1:'+server.address().port;
 report.focus=await evaluate('long-trusted-wake',`(async()=>{await __ownedFactoryPage.locator('#ide-display-canvas').focus();await __ownedFactoryPage.keyboard.press('Escape',{delay:500});await __ownedFactoryPage.keyboard.press('Control+c',{delay:500});return __ownedFactoryPage.evaluate(async()=>({focus:await wvmDemo.run('XDG_RUNTIME_DIR=/run/user/1000 hyprctl -i 0 -j activewindow',300000),clock:await __linuxCtl.guestClockState()}));})()`);
 report.status='passed';
}catch(error){report.status='failed';report.error=error.stack||String(error);process.exitCode=1;}
finally{await handle?.close();await save();server.closeAllConnections();await new Promise(r=>server.close(r));ws.close();}
console.log(JSON.stringify({status:report.status,focus:report.focus,error:report.error}));
