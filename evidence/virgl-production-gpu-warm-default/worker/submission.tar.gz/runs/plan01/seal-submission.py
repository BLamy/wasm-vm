#!/usr/bin/env python3
"""Seal recorded E6-T11d74d proof; large immutable pair stays content addressed."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
R=Path.cwd()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='db04c369fe3915537d8cdcf05e59d81bba5bf8dd'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
sha=lambda b:hashlib.sha256(b).hexdigest()
roots={
 'factory07':'target/evidence/production-gpu-ready-factory07',
 'warm-self08':'target/evidence/production-gpu-ready-warm-self08',
 'pristine11':'target/evidence/production-gpu-warm-pristine11',
 'https12':'target/evidence/production-gpu-warm-https12',
 'failed-recorder-site13':'target/evidence/production-gpu-warm-site13',
 'site14':'target/evidence/production-gpu-warm-site14',
 'failed-product-https10':'target/evidence/production-gpu-warm-https10',
 'failed-recorder-https11':'target/evidence/production-gpu-warm-https11',
 'failed-recorder-self07':'target/evidence/production-gpu-ready-warm-self07',
 'plan01':'target/evidence/production-gpu-warm-restore-plan01',
}
for key in ['factory07','warm-self08','pristine11','site14']:
 assert json.loads((R/roots[key]/'report.json').read_text())['status']=='passed',key
assert json.loads((R/roots['pristine11']/'incremental923/report.json').read_text())['status']=='passed'
public=json.loads((R/roots['https12']/'report.json').read_text());assert public['status']=='failed'
assert [(c['name'],c['exitCode']) for c in public['commands']]==[('default-gpu-warm',0),('software-fast-boots',0),('default-browser',0),('unified-site',1)]
output=R/'evidence/virgl-production-gpu-warm-default/worker'
assert not output.exists()
files={}
excluded=[]
for label,relative in roots.items():
 root=R/relative
 for p in sorted(root.rglob('*')):
  parts=p.relative_to(root).parts
  if 'clone' in parts or '__pycache__' in parts or not p.is_file():continue
  if p.is_symlink():raise ValueError('source record is a symlink '+str(p))
  if p.suffix in ('.wvgpair','.ext4','.snap','.qcow2'):
   excluded.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'reason':'large immutable boot input; named original public custody'})
   continue
  assert p.stat().st_size<256*1024*1024,str(p)
  files['runs/'+label+'/'+str(p.relative_to(root))]=p.read_bytes()
base='3027442a'
changed=subprocess.check_output(['git','diff','--name-only',base+'..'+head],text=True).splitlines()
source=set(changed)|{'AGENTS.md','Cargo.toml','Cargo.lock','web/dist/pkg/wasm_vm_wasm_bg.wasm','web/dist/gpu-checkpoint-build.js','tools/virgl-production/prepare-image.py','tools/gen-gpu-checkpoint-build.mjs'}
# Include every tracked deployable runtime module, but no immutable boot blobs.
for name in subprocess.check_output(['git','ls-files','web/dist'],text=True).splitlines():
 if name.endswith(('.js','.mjs','.wasm')):source.add(name)
for name in sorted(source):
 try:body=subprocess.check_output(['git','show',head+':'+name],stderr=subprocess.PIPE)
 except subprocess.CalledProcessError:
  assert name not in changed,name
  continue
 files['source/'+name]=body
files['source/task.diff']=subprocess.check_output(['git','diff','--binary',base+'..'+head])
source_map={name:{'bytes':len(body),'sha256':sha(body)} for name,body in files.items() if name.startswith('source/')}
files['source-index.json']=(json.dumps({'sourceHead':head,'base':base,'files':source_map},indent=2)+'\n').encode()
files['README.md']=(R/'target/evidence/production-gpu-warm-restore-plan01/submission-claim.md').read_bytes()
files['custody.json']=(json.dumps({'sourceHead':head,'runs':roots,'excludedInputs':excluded,'runtimeHead':'847f51927637c9ff8226068986a771c9e2a5bedc','pristineHead':'847f51927637c9ff8226068986a771c9e2a5bedc','incrementalLabelAndRecorderHead':'9236bc1b7f89f662ae093d4fe95a15e57e909747','incrementalSiteRecorderHead':head,'factoryRecordedHead':'6297df65b3405acc665b76eff2e504c6def96248','workerBuildId':'06622e33ac7fa11a0163e8c58e9f8f36dc2043830d79a04f41e001b847916527','pairSha256':'2aa73b5d39fa6702cecc5c57193896b8798271a3075e1b0294bed3db864deb4f','pairUrl':'https://pub-c7188e40d3a0463183db72f9dd03cae2.r2.dev/sha256/2aa73b5d39fa6702cecc5c57193896b8798271a3075e1b0294bed3db864deb4f/releases/boot-snapshot/omarchy-virgl-ready.wvgpair'},indent=2)+'\n').encode()
index={'task':'E6-T11d74d','sourceHead':head,'records':[{'path':name,'bytes':len(body),'sha256':sha(body)} for name,body in sorted(files.items())]}
index_raw=(json.dumps(index,indent=2)+'\n').encode()
output.mkdir(parents=True)
archive=output/'submission.tar.gz'
with archive.open('xb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,compresslevel=6) as gz:
  with tarfile.open(fileobj=gz,mode='w|') as tar:
   known={}
   for name,body in sorted(files.items()):
    info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0;info.size=len(body)
    identity=(len(body),sha(body))
    if identity in known:
     info.type=tarfile.LNKTYPE;info.linkname=known[identity];info.size=0;tar.addfile(info)
    else:tar.addfile(info,io.BytesIO(body));known[identity]=name
assert archive.stat().st_size<95*1024*1024,'split required before Git'
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(files)
 seen={}
 for m in members:
  assert not m.name.startswith('/') and '..' not in Path(m.name).parts
  assert m.isfile() or m.islnk()
  if m.islnk():assert m.linkname in seen and seen[m.linkname].isfile()
  body=tar.extractfile(m).read();assert body==files[m.name],m.name;seen[m.name]=m
(output/'records.json').write_bytes(index_raw)
manifest={'task':'E6-T11d74d','status':'worker-submission','sourceHead':head,'runtimeHead':'847f51927637c9ff8226068986a771c9e2a5bedc','archive':'submission.tar.gz','archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive.read_bytes()),'records':len(files),'reopenedAndRehashedMembers':len(files),'recordIndexSha256':sha(index_raw),'sourceClosureIncluded':True,'largePairInPublicContentAddressedStorage':True}
(output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest))
