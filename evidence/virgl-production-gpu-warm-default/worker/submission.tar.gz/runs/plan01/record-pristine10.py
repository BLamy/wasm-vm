#!/usr/bin/env python3
"""Prove the public GPU warm boot from one complete, isolated exact-head clone."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
repo = Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
output = args.output.resolve()
output.mkdir(parents=True, exist_ok=False)
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
# A Pages publication is simultaneously staging only its five URI-rewritten manifests.
# Git clone reads committed objects; independently authenticate those sole worktree edits.
dirty = subprocess.check_output(["git", "diff", "--name-only"], cwd=repo, text=True).splitlines()
manifest_names = ["artifacts.json", "artifacts-alpine.json", "artifacts-node-alpine.json", "artifacts-omarchy.json", "artifacts-omarchy-virgl.json"]
assert not subprocess.check_output(["git", "diff", "--cached", "--name-only"], cwd=repo)
assert set(dirty).issubset({"web/dist/"+name for name in manifest_names})
node_auth = """import assert from 'node:assert/strict';import fs from 'node:fs';import {execFileSync} from 'node:child_process';import {expectedPublishedSource} from './tools/virgl-production/published-source.mjs';
for(const file of JSON.parse(process.argv[1])){const original=execFileSync('git',['show',process.argv[2]+':'+file]);assert.deepEqual(fs.readFileSync(file),expectedPublishedSource(file.split('/').at(-1),original));}console.log(JSON.stringify({head:process.argv[2],stagedDeploymentManifests:JSON.parse(process.argv[1]),onlyKnownLiteralR2Rewrites:true}));"""
root_staging = json.loads(subprocess.check_output(["node", "--input-type=module", "-e", node_auth, json.dumps(dirty), head], cwd=repo, text=True))
(output/"root-deployment-staging.json").write_text(json.dumps(root_staging, indent=2)+"\n")
clone = output / "clone"
env = {key: value for key, value in os.environ.items()
       if key not in ("RUSTFLAGS", "RUSTDOCFLAGS", "RUST_LOG")
       and not key.startswith(("CARGO_", "VIRGL_", "CRITIC_"))}
report = {"task": "E6-T11d74d", "head": head, "status": "running", "started": time.time(),
          "cloneMethod": "full-history --no-local; no alternates; no copied build or release cache",
          "commands": []}


def run(name, command, cwd, timeout=3600):
    print(name, flush=True)
    started = time.time()
    with (output/(name+".stdout")).open("wb") as stdout, (output/(name+".stderr")).open("wb") as stderr:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=stdout, stderr=stderr, timeout=timeout)
    report["commands"].append({"name": name, "command": command, "exitCode": result.returncode,
                               "seconds": time.time()-started})
    (output/"report.json").write_text(json.dumps(report, indent=2)+"\n")
    assert result.returncode == 0, name+" failed; inspect the recorded output"


try:
    run("clone", ["git", "clone", "--no-local", str(repo), str(clone)], repo)
    run("exact-head", ["git", "checkout", "--detach", head], clone)
    assert not (clone/".git/objects/info/alternates").exists()
    assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=clone, text=True).strip() == head
    assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=clone)
    run("acceptance", ["python3", "tools/virgl-production/verify-public-gpu-warm.py",
                       "--output", str(output/"acceptance")], clone)
    assert json.loads((output/"acceptance/report.json").read_text())["status"] == "passed"
    assert not subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=no"], cwd=clone)
    report["status"] = "passed"
except BaseException as error:
    report["status"] = "failed"
    report["failure"] = str(error)
    raise
finally:
    report["finished"] = time.time()
    report["files"] = [{"path": str(file.relative_to(output)), "bytes": file.stat().st_size,
                        "sha256": hashlib.sha256(file.read_bytes()).hexdigest()}
                       for file in sorted(output.rglob("*"))
                       if file.is_file() and clone not in file.parents and file != output/"report.json"]
    (output/"report.json").write_text(json.dumps(report, indent=2)+"\n")
