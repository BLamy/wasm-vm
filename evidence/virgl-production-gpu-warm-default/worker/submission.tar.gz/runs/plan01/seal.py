import hashlib,io,json,pathlib,subprocess,tarfile
repo=pathlib.Path.cwd(); stage=repo/'target/evidence/production-gpu-checkpoint-submission01'; stage.mkdir(exist_ok=False)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
cold=repo/'target/evidence/production-gpu-checkpoint-cold01'
assert json.loads((cold/'report.json').read_text())['status']=='passed'
assert json.loads((cold/'acceptance/report.json').read_text())['status']=='passed'
assert json.loads((repo/'target/evidence/production-gpu-checkpoint-browser02/report.json').read_text())['status']=='passed'
assert not subprocess.check_output(['git','diff','3505a7c4',head,'--','crates','web','tools/virgl-production/verify-gpu-checkpoint.py','Makefile'])
files={}
for label,root in [('frozen01',repo/'target/evidence/production-gpu-checkpoint-frozen01'),('browser02',repo/'target/evidence/production-gpu-checkpoint-browser02'),('cold01/acceptance',cold/'acceptance')]:
 for item in sorted(root.rglob('*')):
  if item.is_file():files[label+'/'+str(item.relative_to(root))]=item.read_bytes()
for name in ['report.json','clone.stdout','clone.stderr','make.stdout','make.stderr']:
 files['cold01/'+name]=(cold/name).read_bytes()
for name in ['web-dist-build01.stdout','web-dist-build01.stderr','cold.py']:
 files['recording/'+name]=(repo/'target/evidence/production-gpu-warm-restore-plan01'/name).read_bytes()
changed=subprocess.check_output(['git','diff','--name-only','1efc0b84',head],text=True).splitlines()
for name in changed:
 if (repo/name).is_file():files['source/'+name]=(repo/name).read_bytes()
files['task.diff']=subprocess.check_output(['git','diff','1efc0b84',head])
files['claim.json']=(json.dumps({'task':'E6-T11d74a','head':head,'runtimeHead':'3505a7c480ec855bd1d64d7c0188dea8fc3ab4e8','status':'implemented-worker-claim','hot':'frozen01 remains failed only at obsolete roadmap oracle; ten native/build prefixes held by identical source','browser':'browser02 exact final harness passed127/0/errors[]','cold':'one full-history --no-local clone, no alternates, complete acceptance passed at exact finalhead','boundary':'Native qualified checkpoint only. Physical host reconstruction and production GPU warm boot remain74b-d. Ordinary 3D snapshot API still refuses. No new Wasm export.','sourceChanges':changed},indent=2)+'\n').encode()
identity={'files':[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(files.items())]}
files['identities.json']=(json.dumps(identity,indent=2)+'\n').encode()
archive=repo/'evidence/virgl-production-gpu-checkpoint/worker/native-gpu-checkpoint-submission.tar.gz';archive.parent.mkdir(exist_ok=True,parents=True)
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)
 for row in identity['files']:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
receipt={'archive':str(archive.relative_to(repo)),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files),'identities':len(identity['files']),'head':head}
(stage/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
