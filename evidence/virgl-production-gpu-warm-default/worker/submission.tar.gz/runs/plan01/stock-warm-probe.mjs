// Worker composition self-validation. Only served launcher selection/descriptor are supplemented;
// loader, worker, renderer and ordinary Wasm are unchanged, hash-recorded source bytes.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {createServer} from 'node:http';
import {pathToFileURL} from 'node:url';
const repo=process.cwd(),out=path.resolve(process.argv[2]);await fs.mkdir(out,{recursive:false});
const hash=b=>createHash('sha256').update(b).digest('hex');
const pairFile=path.join(repo,'target/evidence/production-gpu-paired-stock-cold03/factory.wvgpair'),pair=await fs.readFile(pairFile);
assert.equal(hash(pair),'95ef658cb259f13c542b36c6742a85cca0ef61af63f0780af297420845dabbc5');
const descriptor=JSON.parse(await fs.readFile('web/artifacts-omarchy-virgl.json'));
descriptor.artifacts.gpuCheckpoint={url:'/factory.wvgpair',size:pair.length,sha256:hash(pair)};
const originalMain=await fs.readFile('web/main.js'),needle='bootSnapshot: !accelerated && !query.has("noSnapshot"),';
assert.equal(originalMain.toString().split(needle).length,2);const main=Buffer.from(originalMain.toString().replace(needle,'bootSnapshot: !query.has("noSnapshot"),'));
const sources=new Map(),report={status:'running',scope:'Original Omarchy pair through unchanged actual production worker; served-only launcher flag/descriptor supplements, not public/default publication',pair:{bytes:pair.length,sha256:hash(pair)},selection:{originalMainSha256:hash(originalMain),servedMainSha256:hash(main),replacement:needle},started:Date.now(),errors:[],events:[],requests:[]};
let browser,page;
const image=path.join(repo,'target/virgl-production/image-12');
const server=createServer(async(req,res)=>{const name=new URL(req.url,'http://local').pathname;const record={name,time:Date.now()};report.requests.push(record);try{
 res.setHeader('Cross-Origin-Opener-Policy','same-origin');res.setHeader('Cross-Origin-Embedder-Policy','require-corp');res.setHeader('Cache-Control','no-store');
 if(name==='/favicon.ico'){res.writeHead(204).end();return;}
 let bytes,file,type='application/octet-stream';
 if(name==='/factory.wvgpair')bytes=pair;
 else if(name==='/main.js'){bytes=main;type='text/javascript';}
 else if(name==='/artifacts-omarchy-virgl.json'){bytes=Buffer.from(JSON.stringify(descriptor));type='application/json';}
 else if(name==='/chunked-omarchy/manifest-87e23271916159e1aaed163df43caeec67cd568c4c7e8843527572412fec2c95.json'){file=path.join(image,'manifest.json');type='application/json';}
 else if(/^\/chunked-omarchy\/chunks\/[a-f0-9]{64}\.bin$/.test(name))file=path.join(image,'chunks',path.basename(name));
 else if(name.startsWith('/releases/'))file=path.join(repo,name.slice(1));
 else {file=path.resolve(repo,'web','.'+(name==='/app'?'/index.html':name));assert.ok(file.startsWith(repo+'/web/'));type=({'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.wasm':'application/wasm','.css':'text/css','.svg':'image/svg+xml','.png':'image/png'})[path.extname(file)]||type;}
 if(file){if(file.startsWith(repo+'/web/')){bytes=await fs.readFile(file);sources.set(path.relative(repo,file),{path:path.relative(repo,file),bytes:bytes.length,sha256:hash(bytes)});}else{const s=await fs.stat(file);res.writeHead(200,{'Content-Type':type,'Content-Length':s.size});createReadStream(file).pipe(res);record.status=200;record.bytes=s.size;return;}}
 record.status=200;record.bytes=bytes.length;res.writeHead(200,{'Content-Type':type,'Content-Length':bytes.length}).end(bytes);
 }catch(error){record.status=404;record.error=String(error);res.writeHead(404).end(String(error));}});
try{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
 const {chromium}=await import(pathToFileURL(path.join(repo,'web/node_modules/playwright/index.mjs')));
 browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:false,args:['--enable-gpu']});
 const cdp=await browser.newBrowserCDPSession();report.hardware=await cdp.send('SystemInfo.getInfo');
 page=await browser.newPage({viewport:{width:1500,height:1000}});
 page.on('console',m=>{if(m.type()==='error')report.errors.push(m.text());});page.on('pageerror',e=>report.errors.push(String(e)));
 await page.addInitScript(()=>{window.__stockProbe={events:[],output:'',errors:[],boot:[]};const original=Worker.prototype.postMessage,seen=new WeakSet();Worker.prototype.postMessage=function(message,...rest){if(message?.type==='boot')__stockProbe.boot.push(message.opts);if(!seen.has(this)){seen.add(this);const decoder=new TextDecoder();this.addEventListener('message',e=>{const d=e.data;if(d?.type==='output')__stockProbe.output+=decoder.decode(new Uint8Array(d.buffer),{stream:true});if(d?.type==='gpu-event'&&['qualified','context-lost','checkpoint-loaded'].includes(d.info?.type))__stockProbe.events.push(d.info);if(['error','fatal'].includes(d?.type))__stockProbe.errors.push(d.error);});}return original.call(this,message,...rest);};});
 report.url=origin+'/app?guest=omarchy&desktop=1&testHooks=1&gpuTrace=1&omarchyAssetBase='+encodeURIComponent(origin)+'#ide';await page.goto(report.url);
 let ready=false;
 for(let n=0;n<180;n++){
  const s=await page.evaluate(()=>({status:document.querySelector('#status')?.textContent,error:document.querySelector('#os-launcher-status')?.textContent,ready:window.wvmDemo?.isGuestReady?.(),restored:window.__linux?.restoredFromBootSnapshot?.(),qualified:document.documentElement.dataset.gpuQualified,probe:window.__stockProbe,desktop:document.querySelector('#omarchy-boot-overlay')?.hidden}));
  await fs.writeFile(path.join(out,'heartbeat.json'),JSON.stringify({...s,elapsedMs:Date.now()-report.started},null,2));
  if(n%10===0)console.log(JSON.stringify({elapsedMs:Date.now()-report.started,status:s.status,error:s.error,ready:s.ready,restored:s.restored,qualified:s.qualified,desktop:s.desktop,workerErrors:s.probe.errors,serialTail:s.probe.output.slice(-300)}));
  assert.deepEqual(s.probe.errors,[]);if(/cannot boot|linux worker fatal/i.test(s.status||''))throw Error(s.status);
  if(s.ready&&s.restored&&s.qualified==='true'){ready=true;report.readyMs=Date.now()-report.started;break;}
  await new Promise(r=>setTimeout(r,1000));
 }
 assert.equal(ready,true,'actual original Omarchy GPU warm worker ready');
 report.state=await page.evaluate(async()=>({probe:__stockProbe,gpu:await wvmDemo.gpuStats(),clock:await __linuxCtl.guestClockState(),scheduler:await __linuxCtl.schedulerStats(),restored:__linux.restoredFromBootSnapshot(),display:__presentation.state(),cursor:__cursor.state()}));
 assert.equal(report.state.restored,true);assert.equal(report.state.gpu.qualified,true);assert.equal(report.state.gpu.counters.failed,0);assert.ok(report.state.gpu.counters.completed>0&&report.state.gpu.counters.draws>0);assert.ok(report.state.probe.events.some(e=>e.type==='checkpoint-loaded'));
 report.command=await page.evaluate(()=>wvmDemo.run('printf "GPU_WARM_%s_PASS\\n" "$((6*7))"; /opt/virgl-proof/eglinfo -B -p gbm -a gles',300000));
 assert.equal(report.command.exit,0);assert.match(report.command.stdout,/GPU_WARM_42_PASS/);assert.match(report.command.stdout,/virgl\s*\(/);assert.doesNotMatch(report.command.stdout,/llvmpipe|softpipe/i);
 assert.deepEqual(report.errors,[]);report.status='passed';
}catch(e){report.status='failed';report.failure=e.stack;process.exitCode=1;console.error(e.stack);}
finally{
 if(page){try{report.final=await page.evaluate(async()=>({probe:__stockProbe,gpu:await wvmDemo?.gpuStats?.(),status:document.querySelector('#status')?.textContent}));await page.screenshot({path:path.join(out,'browser.png'),fullPage:true});}catch(e){report.captureFailure=String(e);}}
 report.sources=[...sources.values()];report.finished=Date.now();await fs.writeFile(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');await browser?.close();server.closeAllConnections();await new Promise(r=>server.close(r));
}
