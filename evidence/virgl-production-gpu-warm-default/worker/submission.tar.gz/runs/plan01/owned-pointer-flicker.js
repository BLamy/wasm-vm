(async()=>{
 const p=__ownedWarmPages[0];
 if(!p.url().startsWith('http://127.0.0.1:53807/'))throw Error('wrong owned guest');
 const before=await p.evaluate(async()=>({gpu:await wvmDemo.gpuStats(),presentation:__presentation.state(),workspace:await wvmDemo.run('XDG_RUNTIME_DIR=/run/user/1000 hyprctl -i 0 -j activeworkspace',300000)}));
 const box=await p.locator('#ide-display-canvas').boundingBox();
 await p.evaluate(()=>{
  const canvas=document.querySelector('#ide-display-canvas'),ctx=canvas.getContext('2d');
  const d=globalThis.__warmFlickerDiagnostic={running:true,samples:[],events:[],blankPngs:[]};
  d.listener=e=>d.events.push({type:e.type,time:performance.now(),x:e.clientX,y:e.clientY,button:e.button,trusted:e.isTrusted});
  for(const type of ['pointermove','pointerdown','pointerup'])canvas.addEventListener(type,d.listener,true);
  const points=[[16,13],[640,13],[1260,13],[16,200],[640,200],[1260,200],[16,780],[640,780],[1260,780]];
  const tick=()=>{
   if(!d.running)return;
   const alpha=points.map(([x,y])=>ctx.getImageData(x,y,1,1).data[3]);
   const blank=alpha.every(a=>a===0);
   d.samples.push({time:performance.now(),alpha,blank,received:__presentation.state().framesReceived});
   if(blank&&d.blankPngs.length<3)d.blankPngs.push({time:performance.now(),data:canvas.toDataURL('image/png')});
   requestAnimationFrame(tick);
  };requestAnimationFrame(tick);
 });
 const moves=[];
 for(const [x,y] of [[200,220],[900,600],[500,300],[1100,500],[250,400],[700,250]]){
  moves.push({x,y,sent:Date.now()});await p.mouse.move(box.x+x*box.width/1280,box.y+y*box.height/800);
  await new Promise(r=>setTimeout(r,350));
 }
 await p.mouse.click(box.x+65*box.width/1280,box.y+13*box.height/800);
 await new Promise(r=>setTimeout(r,1000));
 const after=await p.evaluate(async()=>{
  const d=__warmFlickerDiagnostic;d.running=false;
  for(const type of ['pointermove','pointerdown','pointerup'])document.querySelector('#ide-display-canvas').removeEventListener(type,d.listener,true);
  return {samples:d.samples,events:d.events,blankPngs:d.blankPngs,gpu:await wvmDemo.gpuStats(),presentation:__presentation.state(),pointer:__pointer.frames().slice(-80),wire:__fastBootCritic.wire.slice(-150),workspace:await wvmDemo.run('XDG_RUNTIME_DIR=/run/user/1000 hyprctl -i 0 -j activeworkspace; XDG_RUNTIME_DIR=/run/user/1000 hyprctl -i 0 cursorpos',300000)};
 });
 const fs=process.getBuiltinModule('fs'),dir=process.cwd()+'/target/evidence/production-gpu-ready-warm-self04/';
 for(let i=0;i<after.blankPngs.length;i++)fs.writeFileSync(dir+'pointer-blank-'+i+'.png',Buffer.from(after.blankPngs[i].data.split(',')[1],'base64'));
 after.blankPngs=after.blankPngs.map((row,i)=>({time:row.time,path:'pointer-blank-'+i+'.png'}));
 await p.screenshot({path:dir+'pointer-after.png',fullPage:true});
 return {scope:'original owned GPU worker; read-only rAF alpha observations, trusted moves and workspace2 click; no runtime replacements',before,moves,box,after};
})()
