import fs from 'node:fs/promises';
const out = new URL('../production-gpu-ready-factory05/owned-process-inspection.json', import.meta.url);
const rows = await (await fetch('http://127.0.0.1:9231/json/list')).json();
if (rows.length !== 1 || !rows[0].url.endsWith('/tools/virgl-production/critic-fast-boots.mjs')) throw Error('wrong owned recorder');
const endpoint = new URL(rows[0].webSocketDebuggerUrl);
if (endpoint.hostname !== '127.0.0.1') throw Error('wrong inspector host');
const ws = new WebSocket(endpoint); await new Promise(resolve => ws.addEventListener('open', resolve, {once: true}));
const pending = new Map(); let id = 0, pauseResolve;
ws.addEventListener('message', event => {
  const message = JSON.parse(event.data);
  if (message.id) { pending.get(message.id)?.(message); pending.delete(message.id); }
  if (message.method === 'Debugger.paused') pauseResolve?.(message.params);
});
const send = (method, params = {}) => new Promise(resolve => { const next = ++id; pending.set(next, resolve); ws.send(JSON.stringify({id: next, method, params})); });
let breakpoint;
try {
  await send('Debugger.enable');
  const paused = new Promise(resolve => { pauseResolve = resolve; });
  const pin = await send('Debugger.setBreakpointByUrl', {url: rows[0].url, lineNumber: 376});
  breakpoint = pin.result.breakpointId;
  const state = await Promise.race([paused, new Promise((_, reject) => setTimeout(() => reject(Error('owned recorder did not reach its next idle observation')), 15000))]);
  const frame = state.callFrames.find(frame => frame.functionName === 'waitActualReady');
  if (!frame) throw Error('wrong capture frame');
  const ownership = await send('Debugger.evaluateOnCallFrame', {callFrameId: frame.callFrameId,
    expression: '(globalThis.__ownedFactoryPage=page,globalThis.__ownedFactoryOrigin=origin,page.url())', returnByValue: true});
  await send('Debugger.removeBreakpoint', {breakpointId: breakpoint}); breakpoint = null;
  await send('Debugger.resume'); await send('Debugger.disable');
  const expression = `(async()=>{
    const p=__ownedFactoryPage,u=new URL(p.url());
    if(u.origin!==__ownedFactoryOrigin||u.searchParams.get('guest')!=='omarchy'||!u.searchParams.has('noSnapshot'))throw Error('wrong owned guest');
    return p.evaluate(async()=>({clock:await __linuxCtl.guestClockState(),scheduler:await __linuxCtl.schedulerStats(),
      processes:await wvmDemo.run('ps -eo pid,ppid,stat,wchan:24,args',300000)}));
  })()`;
  const result = await send('Runtime.evaluate', {expression, awaitPromise: true, returnByValue: true});
  await fs.writeFile(out, JSON.stringify({scope: 'read-only original controller in the owned new cold factory; no product values replaced', ownership, expression, result}, null, 2) + '\n');
  if (result.result.exceptionDetails) throw Error(JSON.stringify(result.result.exceptionDetails));
  const value = result.result.result.value;
  console.log(JSON.stringify({clock: value.clock, retired: value.scheduler.retiredInstructions, exit: value.processes.exit, stdout: value.processes.stdout}));
} finally {
  if (breakpoint) await send('Debugger.removeBreakpoint', {breakpointId: breakpoint});
  await send('Debugger.resume'); await send('Debugger.disable'); ws.close();
}
