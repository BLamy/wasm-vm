__ownedWarmPages[0].evaluate(()=>wvmDemo.run('cat /tmp/warm-evdev.err; sudo -n true; id',300000))
