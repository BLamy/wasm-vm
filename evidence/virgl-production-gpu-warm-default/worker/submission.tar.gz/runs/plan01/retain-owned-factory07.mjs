import fs from 'node:fs/promises';
const out = new URL('../production-gpu-ready-factory07/owned-process-inspection.json', import.meta.url);
const rows = await (await fetch('http://127.0.0.1:9234/json/list')).json();
if (rows.length !== 1 || !rows[0].url.endsWith('/tools/virgl-production/critic-fast-boots.mjs')) throw Error('wrong owned recorder');
const endpoint = new URL(rows[0].webSocketDebuggerUrl);
if (endpoint.hostname !== '127.0.0.1') throw Error('wrong inspector host');
const ws = new WebSocket(endpoint); await new Promise(resolve => ws.addEventListener('open', resolve, {once: true}));
const pending = new Map(); let id = 0, pauseResolve;
ws.addEventListener('message', event => {
  const message = JSON.parse(event.data);
  if (message.id) { pending.get(message.id)?.(message); pending.delete(message.id); }
  if (message.method === 'Debugger.paused') pauseResolve?.(message.params);
});
const send = (method, params = {}) => new Promise(resolve => { const next = ++id; pending.set(next, resolve); ws.send(JSON.stringify({id: next, method, params})); });
let breakpoint;
try {
  await send('Debugger.enable');
  const paused = new Promise(resolve => { pauseResolve = resolve; });
  const loaded = await fs.readFile(new URL('../production-gpu-ready-factory07/executed-harness/critic-fast-boots.mjs', import.meta.url), 'utf8');
  const lines=loaded.split('\n'),start=lines.findIndex(line=>line.includes('async function waitActualReady('));
  const lineNumber=lines.findIndex((line,index)=>index>start&&line.includes('const state=await page.evaluate'));
  if(lineNumber<0)throw Error('missing exact owned observation line');
  const pin = await send('Debugger.setBreakpointByUrl', {url: rows[0].url, lineNumber});
  breakpoint = pin.result.breakpointId;
  const state = await Promise.race([paused, new Promise((_, reject) => setTimeout(() => reject(Error('owned recorder did not reach its next idle observation')), 15000))]);
  const frame = state.callFrames.find(frame => frame.functionName === 'waitActualReady');
  if (!frame) throw Error('wrong capture frame');
  const ownership = await send('Debugger.evaluateOnCallFrame', {callFrameId: frame.callFrameId,
    expression: '(globalThis.__ownedFactoryPage=page,globalThis.__ownedFactoryOrigin=origin,page.url())', returnByValue: true});
  await send('Debugger.removeBreakpoint', {breakpointId: breakpoint}); breakpoint = null;
  await send('Debugger.resume'); await send('Debugger.disable');
  const expression = `({url:__ownedFactoryPage.url(),origin:__ownedFactoryOrigin,closed:__ownedFactoryPage.isClosed()})`;
  const result=await send('Runtime.evaluate',{expression,returnByValue:true});
  await fs.writeFile(out,JSON.stringify({scope:'Bind only the private recorder page for bounded recovery if the cold source later fails; no product values replaced',ownership,expression,result},null,2)+'\n');
  console.log(JSON.stringify(result.result.result.value));

} finally {
  if (breakpoint) await send('Debugger.removeBreakpoint', {breakpointId: breakpoint});
  await send('Debugger.resume'); await send('Debugger.disable'); ws.close();
}
