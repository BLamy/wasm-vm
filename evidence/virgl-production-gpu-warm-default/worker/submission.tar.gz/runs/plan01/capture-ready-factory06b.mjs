import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createServer} from 'node:http';
import {createHash} from 'node:crypto';

const repo=process.cwd(),output=path.join(repo,'target/evidence/production-gpu-ready-factory06b');
await fs.mkdir(output,{recursive:false});
const rows=await(await fetch('http://127.0.0.1:9231/json/list')).json();
assert.equal(rows.length,1);assert.ok(rows[0].url.endsWith('/tools/virgl-production/critic-fast-boots.mjs'));
const ws=new WebSocket(rows[0].webSocketDebuggerUrl);await new Promise(r=>ws.addEventListener('open',r,{once:true}));
let serial=0;const pending=new Map();
ws.addEventListener('message',e=>{const d=JSON.parse(e.data);if(d.id){pending.get(d.id)?.(d);pending.delete(d.id);}});
const send=(method,params={})=>new Promise(r=>{const id=++serial;pending.set(id,r);ws.send(JSON.stringify({id,method,params}));});
const report={status:'running',scope:'Prepared factory from the still-live genuine cold production source05; no worker identity rewrite',source:'production-gpu-ready-factory05',commands:[],uploads:[]};
const save=()=>fs.writeFile(path.join(output,'capture-report.json'),JSON.stringify(report,null,2)+'\n');
async function evaluate(label,expression){
 const row={label,expression,started:Date.now()};report.commands.push(row);await save();
 const reply=await send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});
 row.finished=Date.now();row.reply=reply;await save();
 assert.equal(reply.result?.exceptionDetails,undefined,label);assert.ok(!reply.error,label);
 return reply.result.result.value;
}
let owner,handle,written=0,total,sha=createHash('sha256');
const server=createServer(async(req,res)=>{
 try{
  assert.equal(req.headers.origin,owner.origin);
  res.setHeader('Access-Control-Allow-Origin',owner.origin);res.setHeader('Access-Control-Allow-Methods','POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers','Content-Type');res.setHeader('Cross-Origin-Resource-Policy','cross-origin');
  if(req.method==='OPTIONS'){res.writeHead(204).end();return;}
  assert.equal(req.method,'POST');const m=req.url.match(/^\/pair\/(\d+)\/(\d+)$/);assert.ok(m);
  const offset=Number(m[1]),size=Number(m[2]);assert.ok(Number.isSafeInteger(size)&&size>0&&size<=512*1024*1024);
  assert.equal(offset,written);if(total===undefined){total=size;handle=await fs.open(path.join(output,'factory.wvgpair'),'wx');}
  assert.equal(total,size);assert.ok(handle);
  const parts=[];let bytes=0;for await(const p of req){bytes+=p.length;assert.ok(bytes<=1024*1024);parts.push(p);}
  assert.ok(bytes>0&&bytes<=total-written);const body=Buffer.concat(parts);await handle.writeFile(body);sha.update(body);written+=body.length;
  report.uploads.push({offset,bytes:body.length});let pin={written,total,complete:false};
  if(written===total){await handle.close();handle=null;pin={path:'factory.wvgpair',bytes:total,sha256:sha.digest('hex'),complete:true};report.pin=pin;await save();}
  res.writeHead(200,{'Content-Type':'application/json'}).end(JSON.stringify(pin));
 }catch(error){res.writeHead(400).end(String(error));}
});
try{
 owner=await evaluate('owned-source',`({url:__ownedFactoryPage.url(),origin:__ownedFactoryOrigin})`);
 const u=new URL(owner.url);assert.equal(u.origin,owner.origin);assert.equal(u.hostname,'127.0.0.1');assert.equal(u.searchParams.get('guest'),'omarchy');assert.ok(u.searchParams.has('noSnapshot'));
 report.owner=owner;
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const collector='http://127.0.0.1:'+server.address().port;
 report.input=await evaluate('genuine-wake-prompt-reset-bar-and-typing',`(async()=>{
  const vm=process.getBuiltinModule('node:vm');
  const {verifyPublicDesktopInput}=await vm.runInThisContext('import('+JSON.stringify('file://'+process.cwd()+'/tools/virgl-production/critic-fast-boots-input.mjs?factory06b')+')',{importModuleDynamically:vm.constants.USE_MAIN_CONTEXT_DEFAULT_LOADER});
  const command=(page,command,timeout)=>page.evaluate(({command,timeout})=>wvmDemo.run(command,timeout),{command,timeout});
  const result=await verifyPublicDesktopInput(__ownedFactoryPage,command,${JSON.stringify(output)},
   {name:'prepared-cold-source',initialClockMode:'paced-icount',prepareFactory:true,text:'touch /tmp/gpukeyboard86touch',
    markerAbsent:'test ! -e /tmp/gpukeyboard86touch',markerRead:'test -f /tmp/gpukeyboard86touch && echo TRUSTED_TOUCH_86',expected:'TRUSTED_TOUCH_86'});
  globalThis.__factory06Input=result;return {status:result.status,foot:result.foot,barContent:result.barContent,barActions:{status:result.barActions.status,actions:result.barActions.actions},clock:result.browserInput.clock};
 })()`);
 assert.equal(report.input.status,'passed');
 report.cleanup=await evaluate('remove-only-owned-markers',`__ownedFactoryPage.evaluate(()=>wvmDemo.run('rm -f -- /tmp/gpukeyboard42touch /tmp/gpukeyboard86touch && test ! -e /tmp/gpukeyboard42touch && test ! -e /tmp/gpukeyboard86touch',300000))`);
 assert.equal(report.cleanup.exit,0);
 report.active=await evaluate('real-foot-before-capture',`__ownedFactoryPage.evaluate(()=>wvmDemo.run('XDG_RUNTIME_DIR=/run/user/1000 hyprctl -i 0 -j activewindow',300000))`);
 assert.equal(report.active.exit,0);assert.equal(JSON.parse(report.active.stdout).pid,report.input.foot.pid);
 report.capture=await evaluate('original-paused-clock-ram-disk-gpu-capture',`__ownedFactoryPage.evaluate(async collector=>{
  const c=__linuxCtl;await c.pause();const before={clock:await c.guestClockState(),scheduler:await c.schedulerStats(),gpu:await c.gpuStats()};
  try{const pair=await c.saveGpuCheckpoint();const after={clock:await c.guestClockState(),scheduler:await c.schedulerStats(),gpu:await c.gpuStats()};let pin;
   for(let at=0;at<pair.length;at+=1024*1024){const r=await fetch(collector+'/pair/'+at+'/'+pair.length,{method:'POST',body:pair.subarray(at,Math.min(at+1024*1024,pair.length))});if(!r.ok)throw Error('collector refused');pin=await r.json();}
   if(!pin.complete)throw Error('incomplete pair');return {before,after,pin};
  }finally{await c.resume();}
 },${JSON.stringify(collector)})`);
 assert.equal(report.capture.before.clock.mode,'paced-icount');assert.deepEqual(report.capture.before.clock,report.capture.after.clock);
 assert.ok(Number.isSafeInteger(report.capture.before.scheduler.retiredInstructions));
 assert.equal(report.capture.before.scheduler.retiredInstructions,report.capture.after.scheduler.retiredInstructions);
 assert.deepEqual(report.capture.pin,report.pin);
 await evaluate('source-screenshot',`__ownedFactoryPage.screenshot({path:${JSON.stringify(path.join(output,'factory-source.png'))},fullPage:true}).then(()=>true)`);
 report.status='passed';
}catch(error){report.status='failed';report.error=error.stack||String(error);process.exitCode=1;}
finally{await handle?.close();await save();server.closeAllConnections();await new Promise(r=>server.close(r));ws.close();}
console.log(JSON.stringify({status:report.status,pin:report.pin,error:report.error}));
