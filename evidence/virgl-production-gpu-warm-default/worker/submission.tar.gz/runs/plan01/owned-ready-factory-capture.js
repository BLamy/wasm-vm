(async()=>{
 const p=__ownedWarmPages[0];const clean=await p.evaluate(()=>wvmDemo.run('rm -f /tmp/gpukeyboard42touch /tmp/warm-evdev.bin /tmp/warm-evdev.err; sync',300000));if(clean.exit!==0)throw Error('factory cleanup failed');
 await p.locator('#ide-display-canvas').focus();await p.keyboard.press('Control+l');await new Promise(r=>setTimeout(r,1000));
 const capture=await p.evaluate(async()=>{
  const c=__linuxCtl;await c.pause();
  const summarize=s=>({qualified:s.qualified,lost:s.lost,epoch:s.epoch,counters:s.counters,checkpoint:s.checkpoint,lastFailure:s.lastFailure});
  const before={clock:await c.guestClockState(),scheduler:await c.schedulerStats(),gpu:summarize(await c.gpuStats())};
  const pair=await c.saveGpuCheckpoint();
  const after={clock:await c.guestClockState(),scheduler:await c.schedulerStats(),gpu:summarize(await c.gpuStats())};
  let pin;for(let at=0;at<pair.length;at+=1048576){const r=await fetch('/__factory-gpu-pair/'+at+'/'+pair.length,{method:'POST',body:pair.subarray(at,Math.min(pair.length,at+1048576))});if(!r.ok)throw Error('bounded factory upload failed');pin=await r.json();}
  if(!pin?.complete)throw Error('incomplete factory');return {before,after,pin,paused:await c.isPaused(),held:__keyboardCapture.heldSnapshot(),presentation:__presentation.state(),cursor:__cursor.state()};
 });
 await p.screenshot({path:process.cwd()+'/target/evidence/production-gpu-ready-factory01/owned-ready-factory-source.png',fullPage:true});return {scope:'new ready/paced candidate from original held worker; first strict input attempt remains failed; requires fresh default input/repeat verification',clean,capture};
})()
