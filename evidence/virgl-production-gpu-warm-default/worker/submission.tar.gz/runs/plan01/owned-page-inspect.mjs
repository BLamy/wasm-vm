import fs from 'node:fs/promises';
const [expressionFile,output]=process.argv.slice(2);const expression=await fs.readFile(expressionFile,'utf8');
const rows=await(await fetch('http://127.0.0.1:9229/json/list')).json();const endpoint=new URL(rows[0].webSocketDebuggerUrl);if(endpoint.hostname!=='127.0.0.1')throw Error('not owned local inspector');
const ws=new WebSocket(endpoint);await new Promise(r=>ws.addEventListener('open',r,{once:true}));
const pending=new Map();let id=0;ws.addEventListener('message',e=>{const d=JSON.parse(e.data);if(d.id){pending.get(d.id)?.(d);pending.delete(d.id);}});
const send=(method,params={})=>new Promise(r=>{const k=++id;pending.set(k,r);ws.send(JSON.stringify({id:k,method,params}));});
const result=await send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});await fs.writeFile(output,JSON.stringify({scope:'owned recorder process; original public controller, no product values substituted',expression,result},null,2)+'\n');if(result.result?.exceptionDetails){console.error(JSON.stringify(result.result.exceptionDetails));process.exitCode=1;}else console.log('owned observation saved',output);ws.close();
