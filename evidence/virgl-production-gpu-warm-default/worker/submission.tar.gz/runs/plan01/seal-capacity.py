import gzip, hashlib, io, json, os, subprocess, tarfile
from pathlib import Path

repo = Path.cwd().resolve()
base = repo / 'target/evidence/production-desktop-capacity-pristine01'
final = base / 'desktop-capacity'
report = json.loads((final / 'report.json').read_text())
assert report['status'] == 'passed'
assert json.loads((base / 'report.json').read_text())['status'] == 'passed'
for item in report['files']:
    p = final / item['path']
    assert p.stat().st_size == item['bytes']
    assert hashlib.sha256(p.read_bytes()).hexdigest() == item['sha256']
files = {}
for root, dirs, names in os.walk(base):
    dirs[:] = [d for d in dirs if d != 'clone']
    for name in names:
        p = Path(root) / name
        files['recording/' + p.relative_to(base).as_posix()] = p
changed = subprocess.check_output(['git', 'diff', '--name-only', '612b1b7bc179ab18c0777592e364c80fc57eb6d1', report['head']], text=True).splitlines()
for name in changed + ['tools/virgl-production/paired-guest/main.c', 'tools/virgl-production/paired-guest/commands.h']:
    p = repo / name
    assert p.read_bytes() == subprocess.check_output(['git', 'show', report['head'] + ':' + name])
    files['submission-source/' + name] = p
out = repo / 'evidence/virgl-production-desktop-capacity/worker'
out.mkdir(parents=True, exist_ok=True)
manifest = {'task': 'E6-T11d74d2', 'head': report['head'], 'status': 'passed', 'files': []}
for name, p in sorted(files.items()):
    manifest['files'].append({'path': name, 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
archive = out / 'submission.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w|') as tar:
    for name, p in sorted(files.items()):
        body = p.read_bytes(); info = tarfile.TarInfo(name); info.size = len(body); info.mode = 0o644
        tar.addfile(info, io.BytesIO(body))
    body = (json.dumps(manifest, indent=2) + '\n').encode()
    info = tarfile.TarInfo('manifest.json'); info.size = len(body); info.mode = 0o644
    tar.addfile(info, io.BytesIO(body))
with tarfile.open(archive) as tar:
    for item in manifest['files']:
        body = tar.extractfile(item['path']).read()
        assert len(body) == item['bytes'] and hashlib.sha256(body).hexdigest() == item['sha256']
pin = {'task': 'E6-T11d74d2', 'head': report['head'], 'path': 'submission.tar.gz', 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'members': len(files) + 1}
(out / 'submission.json').write_text(json.dumps(pin, indent=2) + '\n')
print(json.dumps(pin))
