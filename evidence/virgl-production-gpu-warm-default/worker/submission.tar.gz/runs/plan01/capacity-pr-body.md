The production desktop exhausts its 64-resource limit and rejects valid 24×24 popup textures. Give the production GPU profile a coherent limit of 512 live/retained resources, 32 contexts and 64 renderer subcontexts across native admission, host ownership, accepted-job rosters and checkpoint reconstruction.

Private proof profiles retain their original limits. GPU/CPU bytes, leases, tickets, shader sizes and state-object budgets remain bounded at their existing values.

Validation: all 16 gates pass from a complete pristine exact-head clone at `f0f36214`, including original MMIO capacity and atomic-refusal checks; fully rehashed malformed-checkpoint tests; 4,837 independent physical assertions; actual worker cold/warm/repeat reconstruction with fresh pixels and trusted input; scanout continuity; and 127 passed / 0 failed default browser tests. Evidence is sealed in `evidence/virgl-production-desktop-capacity/worker/submission.tar.gz` (SHA256 `6c4a82aa2bb909fd29f56db4634bda5b12b6bac28ad87f18c5414de8948c54fc`).

This layer supplies the capacity prerequisite for the new Omarchy warm artifact; real desktop click/pointer acceptance and publication follow in the next layer. Continues native stack #557; no PRs are merged.
