import gzip,hashlib,io,json,os,tarfile
from pathlib import Path
repo=Path.cwd().resolve();base=repo/'target/evidence/production-scanout-continuity-pristine02'
final=base/'scanout-continuity-repaired01';report=json.loads((final/'report.json').read_text());assert report['status']=='passed'
for f in report['files']:
 p=final/f['path'];assert p.stat().st_size==f['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256'],p
assert json.loads((base/'repaired-report.json').read_text())['status']=='passed'
files={}
for root,dirs,names in os.walk(base):
 dirs[:]=[d for d in dirs if d!='clone']
 for name in names:
  p=Path(root)/name;files['recording/'+p.relative_to(base).as_posix()]=p
for name in ['tools/virgl-production/scanout-worker-browser.mjs','tools/virgl-production/verify-scanout-continuity.py','tools/virgl-production/paired-guest/build-scanout.mjs','tools/virgl-production/paired-guest/scanout.c','tools/virgl-production/paired-guest/main.c','tools/virgl-production/paired-guest/commands.h','guest/prebuilt/production-gpu-scanout.bin','target/evidence/production-gpu-warm-restore-plan01/continue-scanout-cold.py']:
 files['submission-source/'+name]=repo/name
out=repo/'evidence/virgl-production-scanout-continuity/worker';out.mkdir(parents=True,exist_ok=True)
manifest={'task':'E6-T11d74d1','head':report['head'],'status':'passed','files':[]}
for name,p in sorted(files.items()):manifest['files'].append({'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
p=out/'submission.tar.gz'
with p.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w|') as tar:
 for name,file in sorted(files.items()):
  b=file.read_bytes();info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;tar.addfile(info,io.BytesIO(b))
 b=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('manifest.json');info.size=len(b);info.mode=0o644;tar.addfile(info,io.BytesIO(b))
with tarfile.open(p) as tar:
 for item in manifest['files']:
  b=tar.extractfile(item['path']).read();assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
pin={'task':'E6-T11d74d1','head':report['head'],'path':'submission.tar.gz','bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'members':len(files)+1}
(out/'submission.json').write_text(json.dumps(pin,indent=2)+'\n');print(json.dumps(pin))
