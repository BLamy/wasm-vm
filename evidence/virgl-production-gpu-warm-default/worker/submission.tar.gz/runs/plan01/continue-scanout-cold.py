import os, json, hashlib, subprocess, time
from pathlib import Path
repo=Path.cwd().resolve()
base=repo/'target/evidence/production-scanout-continuity-pristine02'
clone=base/'clone'
assert clone.is_dir() and not (clone/'.git/objects/info/alternates').exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('afd26047')
env={k:v for k,v in os.environ.items() if k not in ('RUSTFLAGS','RUSTDOCFLAGS','RUST_LOG') and not k.startswith(('CARGO_','VIRGL_','CRITIC_'))}
record={'task':'E6-T11d74d1','status':'running','head':head,'started':time.time(),'commands':[],
 'scope':'Same complete no-local pristine02 clone, advanced only for generator/recording-harness portability repair; no external build/release cache copied',
 'priorFailure':'report.json and acceptance.stderr preserve generated task-history mismatch before any runtime acceptance command'}
def run(name,cmd,timeout=1800):
 print(name,flush=True);started=time.time()
 with (base/('repaired-'+name+'.stdout')).open('wb') as a,(base/('repaired-'+name+'.stderr')).open('wb') as b:
  r=subprocess.run(cmd,cwd=clone,env=env,stdout=a,stderr=b,timeout=timeout)
 record['commands'].append({'name':name,'command':cmd,'exitCode':r.returncode,'seconds':time.time()-started})
 (base/'repaired-report.json').write_text(json.dumps(record,indent=2)+'\n')
 assert r.returncode==0,name
try:
 (base/'generated-history-mismatch.diff').write_bytes(subprocess.check_output(['git','diff'],cwd=clone))
 run('discard-only-generated-mismatch',['git','restore','--','web/tasks.json','web/dist/tasks.json','web/dist/sw.js'])
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=clone)
 run('fetch-final-harness-head',['git','fetch','--no-tags','origin','codex/omarchy-gpu-warm-default'])
 run('exact-head',['git','checkout','--detach',head])
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==head
 assert not (clone/'.git/shallow').exists() and not (clone/'.git/objects/info/alternates').exists()
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=clone)
 record['cloneCommitCount']=int(subprocess.check_output(['git','rev-list','--all','--count'],cwd=clone))
 run('build',['make','web-dist'])
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=clone),'final clean build drift'
 run('acceptance',['python3','tools/virgl-production/verify-scanout-continuity.py','--output',str(base/'scanout-continuity-repaired01')])
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=clone)
 record['status']='passed'
except BaseException as e:
 record['status']='failed';record['failure']=str(e);raise
finally:
 record['finished']=time.time()
 (base/'repaired-report.json').write_text(json.dumps(record,indent=2)+'\n')
