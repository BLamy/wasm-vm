import hashlib,io,json,pathlib,subprocess,tarfile
repo=pathlib.Path.cwd();stage=repo/'target/evidence/production-paired-worker-submission01';stage.mkdir(exist_ok=False)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();cold=repo/'target/evidence/production-paired-worker-cold01'
assert json.loads((cold/'report.json').read_text())['status']=='passed'
acceptance=json.loads((cold/'acceptance/report.json').read_text());assert acceptance['status']=='passed' and acceptance['head']==head
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
assert not subprocess.check_output(['git','diff','4c40697b',head,'--','crates','renderer','web'])
files={}
for label,root in [('frozen01-lint-negative',repo/'target/evidence/production-paired-worker-frozen01'),('frozen02',repo/'target/evidence/production-paired-worker-frozen02'),('large-self01-memory-negative',repo/'target/evidence/production-paired-worker-large-self01'),('large-self02',repo/'target/evidence/production-paired-worker-large-self02'),('stock-warm-self01',repo/'target/evidence/production-gpu-paired-stock-warm-self01'),('cold01/acceptance',cold/'acceptance')]:
 for item in sorted(root.rglob('*')):
  if item.is_file():files[label+'/'+str(item.relative_to(root))]=item.read_bytes()
for name in ['report.json','clone.stdout','clone.stderr','make.stdout','make.stderr']:files['cold01/'+name]=(cold/name).read_bytes()
plan=repo/'target/evidence/production-gpu-warm-restore-plan01'
for name in ['paired-web-dist02.log','paired-lint-build01.log','paired-cold.py','paired-stock-cold01.log','paired-stock-cold02.log','paired-stock-cold03.log','stock-warm-probe.mjs','paired-stock-warm-self01.log']:
 files['recording/'+name]=(plan/name).read_bytes()
for run,names in [('production-gpu-paired-stock-cold01',['report.json','heartbeat.json']),('production-gpu-paired-stock-cold03',['artifact-inspection.json'])]:
 for name in names:files['scope-observations/'+run+'/'+name]=(repo/'target/evidence'/run/name).read_bytes()
changed=subprocess.check_output(['git','diff','--name-only','6070877f',head],text=True).splitlines()
for name in changed:
 if (repo/name).is_file():files['source/'+name]=(repo/name).read_bytes()
files['task.diff']=subprocess.check_output(['git','diff','6070877f',head])
files['claim.json']=(json.dumps({'task':'E6-T11d74c','head':head,'runtimeHead':'4c40697b','status':'implemented-worker-claim','hot':'Frozen02 all22 gates passed. Tools-only optional release/readiness critic promoted after hot acceptance; original healthy and disk-negative branch behavior preserved, direct supplement passed. Frozen01 lint-only failure retained.','cold':'one full-history --no-local clone, no alternates; all23 recurring gates at exact head','boundary':'Actual production worker save/close/fresh-worker reconstruction, original-MMIO supervisor at64/1024MiB, real GPU completion/fresh scanout drawn receipts/trusted input/native cursor, disk pairing, exact selected clock, refusals and physical context loss. Supervisor is not Linux/Mesa. Actual Omarchy warm artifact/default/publication remain74d.','productionCapture':'Original Omarchy cold03 POSTed an authenticated137111825-byte pair, then the recorder failed Node transport message-size limit; this run is not a pass. Envelope/compressed/raw digests validated separately. Not counted as a production warm claim.','negativeEvidence':'Original DMA journal overflow, actual1GiB wasm32 extra-allocation trap, removed-disk-witness native application failure, sparse preflight sabotage (critic), real context-loss and descriptor/failed-receipt refusals.','heldDependencies':'74a native opaque witness and74b physical reconstruction carry only unchanged boundaries; new full native/RAM/physical/browser regressions are recorded here.','runtimeIdentity':'5dd286c9663c5740e1d26873c26e0ea81d1d32bf67b9c31c758842dbf23f3f09','ordinaryWasmSha256':'9b7fd9243787a69747d421b3cffe8606d16796d97adbab4fe8e292f6035e1e96','sourceChanges':changed},indent=2)+'\n').encode()
identity={'files':[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(files.items())]};files['identities.json']=(json.dumps(identity,indent=2)+'\n').encode()
archive=repo/'evidence/virgl-production-paired-worker/worker/paired-production-worker-submission.tar.gz';archive.parent.mkdir(exist_ok=True,parents=True)
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)
 for row in identity['files']:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
receipt={'archive':str(archive.relative_to(repo)),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files),'identities':len(identity['files']),'head':head}
(stage/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
