from pathlib import Path
p=Path('crates/core/src/dev/virtio/gpu/checkpoint.rs');s=p.read_text().replace('    fn checkpoint_ready(&self)', '    pub(crate) fn checkpoint_ready(&self)');p.write_text(s)
p=Path('crates/core/src/dev/virtio/gpu/snapshot.rs');s=p.read_text().replace('impl PreparedGpu {\n    pub(super) fn valid_backing_range','impl PreparedGpu {\n    #[cfg(feature = "virgl-renderer")]\n    pub(super) fn valid_backing_range',1);p.write_text(s)
p=Path('crates/core/src/lib.rs');s=p.read_text()
needle='''    pub fn save_resume(&mut self) -> Result<alloc::vec::Vec<u8>, crate::resume::SnapshotError> {
        #[cfg(feature = "virgl-renderer")]
        if self.control3d_proof_installed() {''';assert s.count(needle)==1
s=s.replace(needle,'''    pub fn save_resume(&mut self) -> Result<alloc::vec::Vec<u8>, crate::resume::SnapshotError> {
        self.save_resume_inner(None)
    }

    /// Native half of an explicitly paired accelerated checkpoint. `renderer_digest` identifies
    /// the separately reconstructed physical renderer; it is never a WebGL handle or RAM fallback.
    #[cfg(feature = "virgl-renderer")]
    pub fn save_accelerated_resume(&mut self, renderer_digest: &[u8; 32]) -> Result<alloc::vec::Vec<u8>, crate::resume::SnapshotError> {
        self.save_resume_inner(Some(renderer_digest))
    }

    fn save_resume_inner(&mut self, gpu_witness: Option<&[u8;32]>) -> Result<alloc::vec::Vec<u8>, crate::resume::SnapshotError> {
        #[cfg(not(feature = "virgl-renderer"))]
        let _ = gpu_witness;
        #[cfg(feature = "virgl-renderer")]
        if self.control3d_proof_installed() && gpu_witness.is_none() {''',1)
needle='''        self.quiesce()?;
        use crate::resume::{ComponentSnapshot, SnapshotWriter, section};''';assert s.count(needle)==1
s=s.replace(needle,'''        #[cfg(feature = "virgl-renderer")]
        if let Some(witness) = gpu_witness {
            let error = crate::resume::SnapshotError::BadComponentState {tag: crate::resume::section::VIRTIO_GPU};
            let Some((state, ..)) = &self.gpu else { return Err(error); };
            if witness.iter().all(|b|*b==0) || state.borrow().checkpoint_ready().is_err() { return Err(error); }
        }
        self.quiesce()?;
        use crate::resume::{ComponentSnapshot, SnapshotWriter, section};''',1)
needle='''            let payload = state.borrow().to_snapshot().map_err(|_| {
                crate::resume::SnapshotError::BadComponentState {
                    tag: section::VIRTIO_GPU,
                }
            })?;''';assert s.count(needle)==1
s=s.replace(needle,'''            let gpu = state.borrow();
            #[cfg(feature = "virgl-renderer")]
            let payload = if let Some(witness)=gpu_witness {
                gpu.to_gpu_checkpoint(witness).map_err(|_| crate::resume::SnapshotError::BadComponentState {tag:section::VIRTIO_GPU})?
            } else {
                gpu.to_snapshot().map_err(|_| crate::resume::SnapshotError::BadComponentState {tag:section::VIRTIO_GPU})?
            };
            #[cfg(not(feature = "virgl-renderer"))]
            let payload = gpu.to_snapshot().map_err(|_| crate::resume::SnapshotError::BadComponentState {tag:section::VIRTIO_GPU})?;''',1)
needle='''    pub fn load_resume(&mut self, blob: &[u8]) -> Result<(), crate::resume::SnapshotError> {
        #[cfg(feature = "virgl-renderer")]
        if self.control3d_proof_installed() {''';assert s.count(needle)==1
s=s.replace(needle,'''    pub fn load_resume(&mut self, blob: &[u8]) -> Result<(), crate::resume::SnapshotError> {
        self.load_resume_inner(blob, None).map(|_| ())
    }

    /// Restore only the native half of a matching, independently reconstructed GPU checkpoint.
    /// Return the saved and fresh transport epochs so the host reconstruction lane can remap its
    /// logical identities. The ordinary load API retains its explicit accelerated refusal.
    #[cfg(feature = "virgl-renderer")]
    pub fn load_accelerated_resume(&mut self, blob: &[u8], renderer_digest: &[u8;32]) -> Result<(u64,u64), crate::resume::SnapshotError> {
        self.load_resume_inner(blob, Some(renderer_digest))?.ok_or(crate::resume::SnapshotError::BadComponentState {tag:crate::resume::section::VIRTIO_GPU})
    }

    fn load_resume_inner(&mut self, blob: &[u8], gpu_witness: Option<&[u8;32]>) -> Result<Option<(u64,u64)>, crate::resume::SnapshotError> {
        #[cfg(not(feature = "virgl-renderer"))]
        let _ = gpu_witness;
        #[cfg(feature = "virgl-renderer")]
        if (self.control3d_proof_installed() && gpu_witness.is_none()) || (gpu_witness.is_some() && !self.control3d_proof_installed()) {''',1)
needle='''        for sec in &sections {
            match sec.tag {
                section::CPU => Hart::new().restore(sec.payload)?,''';assert s.count(needle)==1
s=s.replace(needle,'''        #[cfg(feature = "virgl-renderer")]
        let mut staged_gpu_checkpoint = None;
        #[cfg(feature = "virgl-renderer")]
        let mut gpu_epochs = None;
        #[cfg(not(feature = "virgl-renderer"))]
        let gpu_epochs = None;
        for sec in &sections {
            match sec.tag {
                section::CPU => Hart::new().restore(sec.payload)?,''',1)
needle='''                    let mut device = dev::virtio::gpu::VirtioGpu::new();
                    device.restore_snapshot(payload).map_err(|_| {
                        crate::resume::SnapshotError::BadComponentState { tag: sec.tag }
                    })?;''';assert s.count(needle)==1
s=s.replace(needle,'''                    #[cfg(feature = "virgl-renderer")]
                    if let Some(witness)=gpu_witness {
                        let Some((state,..)) = &self.gpu else {return Err(crate::resume::SnapshotError::BadComponentState {tag:sec.tag});};
                        staged_gpu_checkpoint = Some(state.borrow().prepare_gpu_checkpoint(payload,witness,self.ram_base(),self.ram_len() as u64)
                            .map_err(|_|crate::resume::SnapshotError::BadComponentState {tag:sec.tag})?);
                        continue;
                    }
                    let mut device = dev::virtio::gpu::VirtioGpu::new();
                    device.restore_snapshot(payload).map_err(|_| {
                        crate::resume::SnapshotError::BadComponentState { tag: sec.tag }
                    })?;''',1)
needle='''                    state.borrow_mut().restore_snapshot(payload).map_err(|_| {
                        crate::resume::SnapshotError::BadComponentState { tag: sec.tag }
                    })?;
                    *control_vq = queues.remove(0);''';assert s.count(needle)==1
s=s.replace(needle,'''                    #[cfg(feature = "virgl-renderer")]
                    if let Some(prepared)=staged_gpu_checkpoint.take() {
                        gpu_epochs=Some((prepared.saved_epoch,prepared.restored_epoch));
                        state.borrow_mut().commit_gpu_checkpoint(prepared);
                    } else {
                        state.borrow_mut().restore_snapshot(payload).map_err(|_|crate::resume::SnapshotError::BadComponentState {tag:sec.tag})?;
                    }
                    #[cfg(not(feature = "virgl-renderer"))]
                    state.borrow_mut().restore_snapshot(payload).map_err(|_|crate::resume::SnapshotError::BadComponentState {tag:sec.tag})?;
                    *control_vq = queues.remove(0);''',1)
needle='''        self.rebase_guest_clock();
        Ok(())
    }

    /// RISCOF signature dump''';assert s.count(needle)==1
s=s.replace(needle,'''        self.rebase_guest_clock();
        Ok(gpu_epochs)
    }

    /// RISCOF signature dump''',1)
p.write_text(s)
