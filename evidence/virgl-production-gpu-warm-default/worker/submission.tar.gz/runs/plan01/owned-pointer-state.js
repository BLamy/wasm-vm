(async()=>{
 if(process.pid!==34150)throw Error('wrong recorder process');
 const chromium=process.getBuiltinModule('module').createRequire(process.cwd()+'/package.json')('./web/node_modules/playwright').chromium;
 globalThis.__ownedWarmPages=[...chromium._connection._objects.values()].filter(o=>o._type==='Page'&&o.url().startsWith('http://127.0.0.1:'));
 if(__ownedWarmPages.length!==1)throw Error('unexpected owned page set');
 const p=__ownedWarmPages[0];
 const state=await p.evaluate(async()=>({url:location.href,clock:await __linuxCtl.guestClockState(),paused:await __linuxCtl.isPaused(),gpu:await __linuxCtl.gpuStats(),presentation:__presentation.state(),pointer:__pointer.state(),cursor:__cursor.state(),pointerFrames:__pointer.frames().slice(-50),keyboard:__keyboardCapture.frames().slice(-80),bar:await wvmDemo.run('XDG_RUNTIME_DIR=/run/user/1000 hyprctl -i 0 -j activeworkspace; XDG_RUNTIME_DIR=/run/user/1000 hyprctl -i 0 -j activewindow',300000)}));
 await p.screenshot({path:process.cwd()+'/target/evidence/production-gpu-ready-warm-self04/pointer-before.png',fullPage:true});
 return {pid:process.pid,state};
})()
