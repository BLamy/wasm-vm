(async()=>{
 const p=__ownedWarmPages[0];
 if(!p.url().startsWith('http://127.0.0.1:53807/'))throw Error('wrong owned guest');
 const read=()=>p.evaluate(()=>wvmDemo.run('XDG_RUNTIME_DIR=/run/user/1000 hyprctl -i 0 -j activeworkspace; XDG_RUNTIME_DIR=/run/user/1000 hyprctl -i 0 cursorpos',300000));
 const before=await read(),box=await p.locator('#ide-display-canvas').boundingBox();
 await p.mouse.click(box.x+65*box.width/1280,box.y+13*box.height/800,{delay:120});
 const tabletAfter=await read();
 const mouse=await p.evaluate(async()=>{
  const c=__linuxCtl;const start=performance.now();
  await c.sendMouseEvent(1,272,1);await c.syncMouse();
  await new Promise(r=>setTimeout(r,120));
  await c.sendMouseEvent(1,272,0);await c.syncMouse();
  return {start,end:performance.now(),scope:'diagnostic original controller mouse button at the same real absolute cursor; not trusted DOM proof'};
 });
 const mouseAfter=await read();
 const devices=await p.evaluate(()=>wvmDemo.run('XDG_RUNTIME_DIR=/run/user/1000 hyprctl -i 0 -j devices',300000));
 await p.screenshot({path:process.cwd()+'/target/evidence/production-gpu-ready-warm-self04/pointer-click-ab.png',fullPage:true});
 return {before,tabletAfter,mouse,mouseAfter,devices};
})()
