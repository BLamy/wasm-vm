from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
root=Path.cwd(); out=root/'target/evidence/production-gpu-warm-restore-plan01'; dist=root/'web/dist'; names=['artifacts.json','artifacts-alpine.json','artifacts-node-alpine.json','artifacts-omarchy.json','artifacts-omarchy-virgl.json']
prior=out/'public-warm-deploy09.json'; assert json.loads(prior.read_text())['status']=='passed'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(); assert head=='847f51927637c9ff8226068986a771c9e2a5bedc'; assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
r={'stage':'Pages-only bounded-startup fix; unchanged immutable R2 objects carry exact prior full-GET proof','head':head,'status':'running','started':time.time(),'carriedArtifactDeployment':{'path':str(prior.relative_to(root)),'sha256':hashlib.sha256(prior.read_bytes()).hexdigest()},'commands':[]}
log=(out/'public-warm-pages-deploy11.log').open('wb')
def run(command):
 start=time.time(); result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT);r['commands'].append({'command':command,'seconds':time.time()-start,'exitCode':result.returncode}); assert result.returncode==0
try:
 run(['python3','tools/validate-deploy-artifacts.py','--root',str(root),'--reject-remote',*sum((['--manifest',str(dist/n)] for n in names),[])])
 node="import assert from 'node:assert/strict';import fs from 'node:fs';import {expectedPublishedSource} from './tools/virgl-production/published-source.mjs';for(const name of JSON.parse(process.argv[1]))assert.deepEqual(expectedPublishedSource(name,fs.readFileSync('web/dist/'+name)),fs.readFileSync(process.argv[2]+'/'+name));"
 run(['node','--input-type=module','-e',node,json.dumps(names),str(out/'published-manifests09')])
 r['smallPagesArtifacts']=[]
 for name in names:
  descriptor=json.loads((dist/name).read_text())
  for item in descriptor['artifacts'].values():
   url=item['url']
   if url.startswith('releases/boot-snapshot/') and item['size']<=25*1024*1024:
    data=(root/url).read_bytes(); assert len(data)==item['size'] and hashlib.sha256(data).hexdigest()==item['sha256']; destination=dist/url;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(data);r['smallPagesArtifacts'].append(dict(item))
  shutil.copyfile(out/'published-manifests09'/name,dist/name)
 run(['python3','tools/validate-deploy-artifacts.py','--root',str(dist),*sum((['--manifest',str(dist/n)] for n in names),[])])
 assert not [p for p in dist.rglob('*') if p.is_file() and p.stat().st_size>25*1024*1024]
 run(['npx','--yes','wrangler','pages','deploy',str(dist),'--project-name','wasm-vm','--branch','main','--commit-dirty=true'])
 r['status']='passed'
except BaseException as error:
 r['status']='failed';r['failure']=str(error);raise
finally:
 subprocess.run(['git','restore','--source='+head,'--worktree','--',*['web/dist/'+n for n in names]],check=True)
 r['finished']=time.time();(out/'public-warm-pages-deploy11.json').write_text(json.dumps(r,indent=2)+'\n');log.close()
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
print(json.dumps(r))
