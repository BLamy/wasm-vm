from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path.cwd();output=root/'target/evidence/production-gpu-warm-site14';output.mkdir(exist_ok=False)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
env={k:v for k,v in os.environ.items() if k not in ('RUSTFLAGS','RUSTDOCFLAGS','RUST_LOG') and not k.startswith(('CARGO_','VIRGL_','CRITIC_'))}
commands=[]
for name,extra in [('local',[]),('https',['--url','https://wasm-vm.pages.dev/'])]:
 command=['node','tools/verify-reviewed-site.mjs','--output',str(output/name),*extra]
 stdout=(output/(name+'.stdout')).open('wb');stderr=(output/(name+'.stderr')).open('wb')
 p=subprocess.Popen(command,env=env,stdout=stdout,stderr=stderr);commands.append((name,command,p,stdout,stderr,time.time()))
result=[]
for name,command,p,stdout,stderr,started in commands:
 code=p.wait(timeout=360);stdout.close();stderr.close();result.append(dict(name=name,command=command,seconds=time.time()-started,exitCode=code));print(name,code,flush=True)
report=dict(head=head,status='passed' if all(r['exitCode']==0 for r in result) else 'failed',commands=result,carriedRuntime='847f51927637c9ff8226068986a771c9e2a5bedc',carriedPublic='target/evidence/production-gpu-warm-https12',sourceOnlyDiff=['tools/verify-reviewed-site.mjs'])
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head;assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
report['files']=[dict(path=str(p.relative_to(output)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(output.rglob('*')) if p.is_file()]
(output/'report.json').write_text(json.dumps(report,indent=2)+'\n');assert report['status']=='passed'
