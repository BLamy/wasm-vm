import hashlib,io,json,pathlib,subprocess,tarfile
repo=pathlib.Path.cwd();stage=repo/'target/evidence/production-renderer-checkpoint-submission01';stage.mkdir(exist_ok=False)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();cold=repo/'target/evidence/production-renderer-checkpoint-cold01'
assert json.loads((cold/'report.json').read_text())['status']=='passed'
acceptance=json.loads((cold/'acceptance/report.json').read_text());assert acceptance['status']=='passed' and acceptance['head']==head
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
assert not subprocess.check_output(['git','diff','de33c99f',head,'--','crates','renderer','web'])
files={}
for label,root in [('frozen01',repo/'target/evidence/production-renderer-checkpoint-frozen01'),('self08-fixture-negative',repo/'target/evidence/production-renderer-checkpoint-self08'),('self09',repo/'target/evidence/production-renderer-checkpoint-self09'),('cold01/acceptance',cold/'acceptance')]:
 for item in sorted(root.rglob('*')):
  if item.is_file():files[label+'/'+str(item.relative_to(root))]=item.read_bytes()
for name in ['report.json','clone.stdout','clone.stderr','make.stdout','make.stderr']:files['cold01/'+name]=(cold/name).read_bytes()
for name in ['renderer-dist01.stdout','renderer-dist01.stderr','renderer-cold.py']:files['recording/'+name]=(repo/'target/evidence/production-gpu-warm-restore-plan01'/name).read_bytes()
changed=subprocess.check_output(['git','diff','--name-only','b549877c',head],text=True).splitlines()
for name in changed:
 if (repo/name).is_file():files['source/'+name]=(repo/name).read_bytes()
files['task.diff']=subprocess.check_output(['git','diff','b549877c',head])
files['claim.json']=(json.dumps({'task':'E6-T11d74b','head':head,'runtimeHead':'de33c99f','status':'implemented-worker-claim','hot':'frozen01 physics/attacks passed; intentional negative exit1 exposed wrapper expected-exit bug, preserved. Only wrapper/log changed afterwards.','cold':'one full-history --no-local clone, no alternates; full corrected acceptance at exact head','boundary':'Fresh physical renderer and checked original command/DMA reconstruction. Production worker/native pair composition and actual Omarchy warm artifact remain74c/d. No production GPU warm-boot claim.','heldNative':'E6-T11d74a verified e26e3e83, native core unchanged; see its committed worker/verifier capsules.','sourceChanges':changed},indent=2)+'\n').encode()
identity={'files':[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(files.items())]};files['identities.json']=(json.dumps(identity,indent=2)+'\n').encode()
archive=repo/'evidence/virgl-production-renderer-checkpoint/worker/physical-renderer-reconstruction-submission.tar.gz';archive.parent.mkdir(exist_ok=True,parents=True)
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)
 for row in identity['files']:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
receipt={'archive':str(archive.relative_to(repo)),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files),'identities':len(identity['files']),'head':head}
(stage/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
