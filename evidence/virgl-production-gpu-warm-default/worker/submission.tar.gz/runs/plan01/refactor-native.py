from pathlib import Path
p=Path('crates/core/src/dev/virtio/gpu/snapshot.rs');s=p.read_text()
needle='''    let records = state.resources.snapshot_records();''';assert s.count(needle)==1
s=s.replace(needle,'''    encode_2d(state, state.scanout_resource)
}

/// The accelerated envelope separately carries its renderer scanout reference.
pub(super) fn encode_2d(state: &GpuState, scanout: Option<u32>) -> Result<Vec<u8>, GpuSnapshotError> {
    let records = state.resources.snapshot_records();''',1).replace('let scanout_resource = state.scanout_resource.unwrap_or(NONE_RESOURCE);','let scanout_resource = scanout.unwrap_or(NONE_RESOURCE);',1)
needle='''    let parsed = parse(bytes)?;
    let resources = ResourceMap::from_snapshot_records''';assert s.count(needle)==1
s=s.replace(needle,'''    let prepared = prepare(bytes)?;
    apply(state, prepared);
    Ok(())
}

pub(super) struct PreparedGpu {
    parsed: ParsedGpu,
    resources: ResourceMap,
    scanout_resource: Option<u32>,
    cursor_states: [CursorState; DEFAULT_NUM_SCANOUTS as usize],
}

pub(super) fn prepare(bytes: &[u8]) -> Result<PreparedGpu, GpuSnapshotError> {
    let parsed = parse(bytes)?;
    let resources = ResourceMap::from_snapshot_records''',1)
s=s.replace('for (index, cursor) in parsed.cursors.into_iter().enumerate() {','for (index, cursor) in parsed.cursors.iter().copied().enumerate() {',1)
needle='''    // No fallible parse or reference validation remains.  This is the one commit point for live''';assert s.count(needle)==1
s=s.replace(needle,'''    Ok(PreparedGpu { parsed, resources, scanout_resource, cursor_states })
}

pub(super) fn apply(state: &mut GpuState, prepared: PreparedGpu) {
    let PreparedGpu { parsed, resources, scanout_resource, cursor_states } = prepared;
    // No fallible parse or reference validation remains.  This is the one commit point for live''',1)
needle='''    Ok(())
}

struct ParsedGpu''';assert s.count(needle)==1;s=s.replace(needle,''' }

struct ParsedGpu''',1)
p.write_text(s)
p=Path('crates/core/src/dev/virtio/gpu/control3d.rs');s=p.read_text();needle='''    pub(crate) fn poison(&mut self) {''';assert s.count(needle)==1;s=s.replace(needle,'''    pub(super) fn checkpoint_sizes(&self, metadata: Resource3dMetadata) -> Result<(u64, u64), Control3dError> {
        metadata.sizes_limited(self.desktop_resources, self.dimensional_resources,
            self.dimensional_depth_resources, self.stream_output_resources,
            32 * 1024 * 1024, self.production_limits)
    }
    /// Only the detached, bounded production checkpoint decoder constructs this state.
    pub(super) fn commit_checkpoint(&mut self, snapshot: Control3dSnapshot, epoch: u64) {
        self.epoch = epoch;
        self.next_generation = snapshot.next_generation;
        self.next_backing_generation = snapshot.next_backing_generation;
        self.poisoned = false;
        self.contexts = snapshot.contexts;
        self.resources = snapshot.resources;
        self.logical_bytes = snapshot.logical_bytes;
        self.gpu_bytes = snapshot.gpu_bytes;
        self.backing_bytes = snapshot.backing_bytes;
    }
    pub(crate) fn poison(&mut self) {''',1);p.write_text(s)
p=Path('crates/core/src/dev/virtio/gpu/submit3d.rs');s=p.read_text();needle='''    pub fn next_key(&self, epoch: u64) -> Result<Submit3dKey, Control3dError> {''';assert s.count(needle)==1;s=s.replace(needle,'''    pub(super) fn commit_checkpoint(&mut self, snapshot: Submit3dSnapshot) {
        self.mailbox.revoke();
        self.pending = None;
        self.next_sequence = snapshot.next_sequence;
        self.counters = snapshot.counters;
    }
    pub fn next_key(&self, epoch: u64) -> Result<Submit3dKey, Control3dError> {''',1);p.write_text(s)
p=Path('crates/core/src/dev/virtio/gpu/scanout3d.rs');s=p.read_text();needle='''    pub fn reset(&mut self) {
        self.snapshot.binding = None;''';assert s.count(needle)==1;s=s.replace(needle,'''    pub(super) fn commit_checkpoint(&mut self, snapshot: Scanout3dSnapshot) {
        self.snapshot = snapshot;
    }
    pub fn reset(&mut self) {
        self.snapshot.binding = None;''',1);p.write_text(s)
p=Path('crates/core/src/dev/virtio/gpu/mod.rs');s=p.read_text().replace('pub mod capabilities;','pub mod capabilities;\n#[cfg(feature = "virgl-renderer")]\npub mod checkpoint;',1);p.write_text(s)
