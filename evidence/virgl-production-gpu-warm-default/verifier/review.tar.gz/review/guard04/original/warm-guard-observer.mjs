import fs from 'node:fs/promises';
import path from 'node:path';
export async function observeOriginalGuard(context,page,output){
 const session=await context.newCDPSession(page),pending=new Map();let next=0;
 const report={scope:'read-only debugger snapshots at the unchanged original worker guard; no state replacement',events:[],states:[]};
 const save=()=>fs.writeFile(path.join(output,'original-warm-guard.json'),JSON.stringify(report,null,2)+'\n');
 const child=(sid,method,params={})=>new Promise((resolve,reject)=>{const id=++next;pending.set(id,{resolve,reject});session.send('Target.sendMessageToTarget',{sessionId:sid,message:JSON.stringify({id,method,params})}).catch(reject);});
 const progress=new Map();
 session.on('Target.receivedMessageFromTarget',({sessionId,message})=>{const r=JSON.parse(message);if(r.id){const p=pending.get(r.id);pending.delete(r.id);if(r.error)p?.reject(Error(JSON.stringify(r.error)));else p?.resolve(r.result);return;}
  if(r.method==='Debugger.paused')void(async()=>{
   try{const state=progress.get(sessionId);if(!state)throw Error('unknown worker');const frame=r.params.callFrames.find(f=>f.url.includes('/loader.js'))||r.params.callFrames[0];
    const expression=`(()=>{const gpu=productionGpu.inspect();return {now:performance.now(),deadline,stopped,paused,tickScheduled,runQuantum,sliceCount,sliceTotalMs,sliceMaxMs,clock:machine.guestClockState(),jit:machine.jitStats(),fetch:machine.fetchStats(),input:machine.inputDeviceStats(),gpu:{qualified:gpu.qualified,lost:gpu.lost,epoch:gpu.epoch,counters:gpu.counters,pending:gpu.pending,renderer:gpu.renderer.work,scanout:gpu.scanout},visibleFrames:gpuVisibleFrames,baselineFrames:frames,baselineCompleted:before.counters.completed,baselineDraws:before.renderer.work.draws};})()`;
    const value=await child(sessionId,'Debugger.evaluateOnCallFrame',{callFrameId:frame.callFrameId,expression,returnByValue:true});report.states.push({stage:state.visits++===0?'entry':'deadline',url:frame.url,location:frame.location,expression,value});await save();
    await child(sessionId,'Debugger.removeBreakpoint',{breakpointId:state.breakpoint});
    if(state.visits===1){const b=await child(sessionId,'Debugger.setBreakpointByUrl',{urlRegex:'/loader\\.js(?:\\?|$)',lineNumber:1242,condition:'performance.now()>deadline-100'});state.breakpoint=b.breakpointId;}
   }catch(error){report.events.push({type:'observer-error',error:String(error)});await save();}
   finally{await child(sessionId,'Debugger.resume').catch(()=>{});}
  })();
 });
 session.on('Target.attachedToTarget',({sessionId,targetInfo})=>{void(async()=>{try{
  report.events.push({type:'attached',targetInfo});await child(sessionId,'Debugger.enable');
  const b=await child(sessionId,'Debugger.setBreakpointByUrl',{urlRegex:'/loader\\.js(?:\\?|$)',lineNumber:1242});progress.set(sessionId,{visits:0,breakpoint:b.breakpointId});await save();
 }catch(error){report.events.push({type:'attach-error',error:String(error)});await save();}
 finally{await child(sessionId,'Runtime.runIfWaitingForDebugger').catch(()=>{});}})();});
 await session.send('Target.setAutoAttach',{autoAttach:true,waitForDebuggerOnStart:true,flatten:false,filter:[{type:'worker',exclude:false},{exclude:true}]});await save();
}
