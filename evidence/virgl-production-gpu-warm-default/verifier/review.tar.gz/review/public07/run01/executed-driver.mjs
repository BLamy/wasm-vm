#!/usr/bin/env node
// Independent bounded challenge. No intercepted responses or invented guest output.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath, pathToFileURL} from 'node:url';

const repo = '/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm';
const frozen = '24cfc8bb567f3dd0c8e0d6784120b81919d74575';
const worker = '06622e33ac7fa11a0163e8c58e9f8f36dc2043830d79a04f41e001b847916527';
const pairSha = '2aa73b5d39fa6702cecc5c57193896b8798271a3075e1b0294bed3db864deb4f';
const pairSize = 173104561;
const imageSha = '87e23271916159e1aaed163df43caeec67cd568c4c7e8843527572412fec2c95';
const expectedPixelsSha = 'c33e9d0a9029ef47e3edefa9cb3740630c08444a04404f5cdd19f621ae4228b7';
const base = 'https://wasm-vm.pages.dev';
const output = path.resolve(process.argv[2]);
assert.ok(process.argv[2] && process.argv.length === 3);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const blob = name => execFileSync('git', ['show', frozen + ':' + name], {cwd: repo, maxBuffer: 128 * 1024 * 1024});
await fs.mkdir(output, {recursive: false});
const report = {schema: 'independent-public-default-warm-seed7-v1', status: 'running', frozenHead: frozen,
  observedRepoHead: execFileSync('git', ['rev-parse', 'HEAD'], {cwd: repo, encoding: 'utf8'}).trim(),
  startedAt: new Date().toISOString(), command: [process.execPath, ...process.argv.slice(1)],
  scope: 'Fresh actual public default warm worker, novel literal Mesa seed7 and genuine seed5 oracle sensitivity',
  worker, pair: {sha256: pairSha, bytes: pairSize}, imageSha, sources: [], chunks: [], requests: [], errors: [],
  predictions: ['One default GPU warm boot, no cold/software fallback, real restored controller and fresh presentation.',
    'Every observed published source equals the frozen Git bytes after the declared immutable-R2 URL rewrite.',
    'Original downloaded pair has the pinned extent/digest, exact worker/image identity and saved paced clock.',
    'Actual installed pinned RISC-V ELF seed7 produces all64 literal expected pixels and new physical jobs in the restored epoch.',
    'A genuine seed5 run on that same owner is rejected by the independent seed7 pixel oracle.'],
  expectedPixels: {seed: 7, bytes: 256, rgbaSha256: expectedPixelsSha,
    GLBottomLeftBottomRightTopLeftTopRightRgba: [[0,255,255,255],[255,0,255,255],[255,255,0,255],[0,0,255,255]]}};
const save = () => fs.writeFile(path.join(output, 'report.json'), JSON.stringify(report, null, 2) + '\n');
const write = async (name, bytes) => { await fs.mkdir(path.dirname(path.join(output, name)), {recursive: true}); await fs.writeFile(path.join(output, name), bytes); };
await write('executed-driver.mjs', await fs.readFile(fileURLToPath(import.meta.url)));
report.driverSha256 = sha(await fs.readFile(fileURLToPath(import.meta.url)));
await write('pre-data.json', JSON.stringify(report, null, 2) + '\n');

// Frozen helpers supply the real ELF and installation channel, not the seed7 oracle.
const helperPaths = ['critic-warm-pixels.mjs', 'published-source.mjs',
  'fixtures/critic-warm-pixels-riscv64.elf', 'fixtures/critic-warm-pixels-riscv64.build.json',
  'probes/critic-warm-pixels.c'];
report.harness = [];
for (const name of helperPaths) {
  const bytes = blob('tools/virgl-production/' + name);
  await write('executed-harness/' + name, bytes);
  report.harness.push({path: name, bytes: bytes.length, sha256: sha(bytes)});
}
await write('executed-harness/checkpoint-codec.mjs', blob('web/dist/renderer/virgl-command/checkpoint-codec.mjs'));
const {readWarmPixelProbe, warmPixelInstallCommand, assertWarmPixelInstall, assertWarmPixelResult} =
  await import(pathToFileURL(path.join(output, 'executed-harness/critic-warm-pixels.mjs')));
const {expectedPublishedSource} = await import(pathToFileURL(path.join(output, 'executed-harness/published-source.mjs')));
const {decodeCheckpointData} = await import(pathToFileURL(path.join(output, 'executed-harness/checkpoint-codec.mjs')));
const descriptorBytes = expectedPublishedSource('artifacts-omarchy-virgl.json', blob('web/dist/artifacts-omarchy-virgl.json'));
const descriptor = JSON.parse(descriptorBytes);
assert.equal(descriptor.artifacts.gpuCheckpoint.sha256, pairSha);
assert.equal(descriptor.artifacts.gpuCheckpoint.size, pairSize);
assert.equal(descriptor.chunkedImage.sha256, imageSha);
const pairUrl = descriptor.artifacts.gpuCheckpoint.url;
await write('expected-artifacts-omarchy-virgl.json', descriptorBytes);
const expected = Buffer.alloc(256);
for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++)
  expected.set(report.expectedPixels.GLBottomLeftBottomRightTopLeftTopRightRgba[(y < 4 ? 0 : 2) + (x < 4 ? 0 : 1)], (y * 8 + x) * 4);
assert.equal(sha(expected), expectedPixelsSha);
await write('seed7.expected.rgba', expected);
const probe = await readWarmPixelProbe();
report.probe = {sha256: probe.binarySha256, bytes: probe.binary.length, sourceSha256: probe.sourceSha256};

function parseActual(result, seed) {
  assert.equal(result?.exit, 0, 'real guest probe exits successfully');
  const stdout = String(result.stdout).replaceAll('\r', '');
  const lines = stdout.split('\n');
  for (const line of ['WARM_PIXELS_RENDERER=virgl (wasm-vm WebGL2 VirGL)',
    'WARM_PIXELS_VERSION=OpenGL ES 3.0 Mesa 26.2.2',
    `WARM_PIXELS_RESULT seed=${seed} pixels=64 bytes=256 draws=4 different=0`, 'WARM_PIXELS_PASS failures=0'])
    assert.equal(lines.filter(value => value === line).length, 1, 'original exact probe line ' + line);
  assert.doesNotMatch(stdout, /llvmpipe|softpipe|swrast|WARM_PIXELS_(?:FAIL|TIMEOUT|GL_ERROR|SHADER_FAIL|DIFFERENT)/i);
  const rows = [...stdout.matchAll(/^WARM_PIXELS_BYTES=([0-9a-f]{512})$/gm)];
  assert.equal(rows.length, 1, 'original full64-pixel readback exactly once');
  return Buffer.from(rows[0][1], 'hex');
}
function assertGpu(state) {
  assert.equal(state.restored, true);
  assert.equal(state.ready, true); assert.equal(state.up, true);
  for (const key of ['lost', 'disposed', 'poisoned']) assert.equal(state.gpu[key], false, key);
  assert.equal(state.gpu.qualified, true);
  for (const key of ['failed', 'cancelled']) assert.equal(state.gpu.counters[key], 0, key);
  assert.equal(state.gpu.guestCommands.dropped, 0);
  for (const command of state.gpu.guestCommands.records) assert.ok(command.response < 0x1200, 'no original device refusal');
}
function assertNewWork(before, after) {
  assertGpu(before); assertGpu(after);
  assert.equal(after.gpu.epoch, before.gpu.epoch);
  const delta = Object.fromEntries(['begun', 'completed', 'draws', 'outputBytes'].map(key => [key, after.gpu.counters[key] - before.gpu.counters[key]]));
  assert.ok(delta.draws >= 4); assert.ok(delta.completed > 0); assert.ok(delta.outputBytes >= 256);
  return delta;
}
function observe() {
  globalThis.__independentWarm = {boots: [], states: [], events: [], workerErrors: [], wireTotals: {}};
  for (const type of ['wvm:guest-state', 'wvm:guest-progress', 'wvm:desktop-ready', 'wvm:guest-error'])
    addEventListener(type, event => globalThis.__independentWarm.events.push({type, detail: event.detail, time: performance.now()}));
  const original = Worker.prototype.postMessage, seen = new WeakSet();
  Worker.prototype.postMessage = function(message, ...rest) {
    const state = globalThis.__independentWarm;
    if (!seen.has(this)) {
      seen.add(this);
      this.addEventListener('message', event => {
        const message = event.data, key = 'receive:' + message?.type;
        state.wireTotals[key] = (state.wireTotals[key] || 0) + 1;
        if (['fatal', 'error'].includes(message?.type)) state.workerErrors.push(message.error);
        if (message?.type === 'gpu-event') void globalThis.__recordIndependentWarmGpu(message.info);
      });
    }
    if (message?.type === 'boot') state.boots.push({time: performance.now(), options: message.opts});
    return original.call(this, message, ...rest);
  };
}

let browser, context, page, executable, failure;
let gpuRecording = Promise.resolve(), gpuBytes = 0;
const reads = [], readErrors = [];
const recordResponse = response => {
  const url = new URL(response.url());
  if (url.pathname === '/favicon.ico') return;
  if (url.origin !== base && response.url() !== pairUrl && !/\/chunks\/[a-f0-9]{64}\.bin$/.test(url.pathname)) return;
  const row = {url: response.url(), status: response.status(), fromServiceWorker: response.fromServiceWorker()};
  report.requests.push(row);
  reads.push((async () => {
    try {
      assert.equal(response.status(), 200, 'actual published response ' + url.pathname);
      const bytes = await response.body(); row.bytes = bytes.length; row.sha256 = sha(bytes);
      if (response.url() === pairUrl) {
        assert.equal(bytes.length, pairSize); assert.equal(sha(bytes), pairSha);
        assert.equal(bytes.subarray(0, 8).toString(), 'WVGPAIR1'); assert.equal(bytes.readUInt32LE(8), 1);
        assert.equal(bytes.readUInt32LE(12), bytes.length - 48);
        assert.equal(sha(bytes.subarray(0, -32)), bytes.subarray(-32).toString('hex'));
        const metadata = decodeCheckpointData(new Uint8Array(bytes.subarray(16, -32)));
        assert.equal(metadata.schema, 'production-gpu-pair-v1'); assert.equal(metadata.identity.buildId, worker);
        assert.equal(metadata.identity.imageManifestSha256, imageSha);
        assert.equal(metadata.clockState.mode, 'paced-icount'); assert.equal(metadata.clockState.mtime, '1552009163');
        report.pair.metadata = {identity: metadata.identity, profile: metadata.profile, epoch: metadata.epoch,
          clockState: metadata.clockState, parts: Object.fromEntries(Object.entries(metadata.parts).map(([name, part]) =>
            [name, {bytes: part.bytes.length, sha256: part.sha256, observedSha256: sha(part.bytes)}]))};
        for (const part of Object.values(report.pair.metadata.parts)) assert.equal(part.observedSha256, part.sha256);
        report.pair.browserResponse = row;
      } else if (url.origin === base) {
        let relative = url.pathname === '/app' ? 'app.html' : url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
        if (relative === 'favicon.ico' && response.status() === 404) return;
        const expectedBody = expectedPublishedSource(relative, blob('web/dist/' + relative));
        assert.equal(sha(bytes), sha(expectedBody), 'exact frozen published source ' + relative);
        const bodyPath = 'served-source/' + relative;
        await write(bodyPath, bytes);
        report.sources.push({...row, relative, bodyPath, frozenSha256: sha(expectedBody)});
      } else {
        const chunkSha = url.pathname.match(/\/chunks\/([a-f0-9]{64})\.bin$/)[1];
        assert.equal(sha(bytes), chunkSha, 'actual original disk chunk digest');
        report.chunks.push(row);
      }
    } catch (error) { readErrors.push({url: response.url(), error: error.stack || String(error)}); }
  })());
};
const state = () => page.evaluate(async () => ({time: performance.now(), restored: __linux.restoredFromBootSnapshot(),
  ready: wvmDemo.isGuestReady(), up: wvmDemo.isGuestUp(), clock: await __linuxCtl.guestClockState(),
  gpu: await wvmDemo.gpuStats(), display: __presentation.state(), observer: __independentWarm,
  qualified: document.documentElement.dataset.gpuQualified, caches: await caches.keys(),
  serviceWorker: navigator.serviceWorker.controller?.scriptURL ?? null}));
const run = command => page.evaluate(command => wvmDemo.run(command, 300000), command);
try {
  const {chromium} = await import(pathToFileURL(path.join(repo, 'web/node_modules/playwright/index.mjs')));
  browser = await chromium.launch({headless: true, executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    args: ['--enable-gpu', '--use-gl=angle', '--use-angle=metal']});
  const cdp = await browser.newBrowserCDPSession();
  report.hardware = await cdp.send('SystemInfo.getInfo'); report.commandLine = await cdp.send('Browser.getBrowserCommandLine');
  assert.equal(report.hardware.gpu.featureStatus.webgl2 ?? report.hardware.gpu.featureStatus.webgl, 'enabled');
  assert.ok(!report.commandLine.arguments.some(value => /swiftshader|llvmpipe|softpipe|--disable-gpu(?:$|=)/i.test(value)));
  context = await browser.newContext({viewport: {width: 1280, height: 850}, serviceWorkers: 'allow'});
  await context.exposeBinding('__recordIndependentWarmGpu', (_source, event) => {
    const body = JSON.stringify(event) + '\n'; gpuBytes += Buffer.byteLength(body);
    if (gpuBytes > 256 * 1024 * 1024) throw Error('Bounded original GPU recording exceeded256MiB');
    gpuRecording = gpuRecording.then(() => fs.appendFile(path.join(output, 'gpu.ndjson'), body));
    return gpuRecording;
  });
  await context.addInitScript(observe);
  context.on('response', recordResponse);
  page = await context.newPage();
  page.on('pageerror', error => report.errors.push({type: 'pageerror', error: String(error)}));
  page.on('console', message => { if (message.type() === 'error' && !/favicon/.test(message.location().url || '')) report.errors.push({type: 'console', error: message.text()}); });
  const url = base + '/app?' + new URLSearchParams({guest: 'omarchy', desktop: '1', testHooks: '1', gpuTrace: '1'}) + '#ide';
  report.url = url;
  for (const option of ['gpu', 'noSnapshot', 'persist', 'worker', 'assetBase', 'omarchyAssetBase']) assert.equal(new URL(url).searchParams.has(option), false);
  await save(); await page.goto(url, {waitUntil: 'domcontentloaded', timeout: 90000});
  const deadline = Date.now() + 600000;
  while (true) {
    const ready = await page.evaluate(() => ({ready: globalThis.wvmDemo?.isGuestReady?.(), restored: globalThis.__linux?.restoredFromBootSnapshot?.(),
      desktop: __independentWarm.events.some(event => event.type === 'wvm:desktop-ready'),
      errors: __independentWarm.workerErrors, fatal: __independentWarm.events.filter(event => event.type === 'wvm:guest-error')}));
    assert.deepEqual(ready.errors, []); assert.deepEqual(ready.fatal, []); assert.deepEqual(report.errors, []);
    if (ready.ready && ready.restored && ready.desktop) break;
    if (Date.now() > deadline) throw Error('Bounded public default warm readiness deadline');
    await page.waitForTimeout(1000);
  }
  report.before = await state(); await save(); assertGpu(report.before);
  assert.equal(report.before.observer.boots.length, 1, 'one explicit original boot, no fallback');
  const options = report.before.observer.boots[0].options;
  assert.equal(options.virgl, true); assert.equal(options.bootSnapshot, true); assert.equal(options.persist, false);
  assert.ok(report.before.display.successfulPresents > 0);
  const restored = report.before.observer.events.filter(event => event.type === 'wvm:guest-state' && event.detail.state === 'restored');
  assert.equal(restored.length, 1);
  const progress = report.before.observer.events.filter(event => event.type === 'wvm:guest-progress' && event.detail.phase.startsWith('gpuCheckpoint:'));
  assert.ok(progress.length > 0); assert.equal(progress.at(-1).detail.loaded, pairSize);
  assert.ok(progress.every(event => !event.detail.phase.includes('reading cache')), 'fresh private context reads original network bytes');
  report.install = await run(warmPixelInstallCommand(probe.binary)); await save();
  executable = assertWarmPixelInstall(report.install);
  report.seed7 = {before: await state()}; await save();
  report.seed7.result = await run(executable + ' 7'); report.seed7.after = await state(); await save();
  const actual = parseActual(report.seed7.result, 7);
  assert.deepEqual(actual, expected, 'all64 original actual readPixels equal independent pre-data literal seed7');
  report.seed7.rgbaSha256 = sha(actual); report.seed7.newGpuWork = assertNewWork(report.seed7.before, report.seed7.after);
  await write('seed7.actual.rgba', actual); await save();
  report.sensitivity = {before: await state(), purpose: 'Genuine seed5 output must fail seed7 oracle; not a product failure'};
  report.sensitivity.result = await run(executable + ' 5'); report.sensitivity.after = await state(); await save();
  const other = parseActual(report.sensitivity.result, 5);
  assertWarmPixelResult(report.sensitivity.result, 5);
  assert.throws(() => assert.deepEqual(other, expected), {code: 'ERR_ASSERTION'});
  report.sensitivity.rejectedBySeed7Oracle = true; report.sensitivity.rgbaSha256 = sha(other);
  report.sensitivity.newGpuWork = assertNewWork(report.sensitivity.before, report.sensitivity.after);
  await write('seed5.actual.rgba', other);
  report.after = await state(); assertGpu(report.after);
  assert.equal(report.after.observer.boots.length, 1); assert.deepEqual(report.after.observer.workerErrors, []);
  await page.screenshot({path: path.join(output, 'actual-public-warm.png'), fullPage: true});
  await Promise.all(reads); await gpuRecording;
  report.sourceReadErrors = readErrors; assert.deepEqual(readErrors, []);
  assert.ok(report.pair.browserResponse, 'Original browser downloaded exact public pair');
  for (const required of ['app.html', 'main.js', 'loader.js', 'linux-worker.js', 'linux-worker-protocol.js', 'gpu-checkpoint-build.js',
    'pkg/wasm_vm_wasm.js', 'pkg/wasm_vm_wasm_bg.wasm', 'artifacts-omarchy-virgl.json', 'renderer/virgl-command/production.mjs'])
    assert.ok(report.sources.some(row => row.relative === required), 'authenticated actual executed source ' + required);
  assert.deepEqual(report.errors, []); report.status = 'passed';
} catch (error) { failure = error; report.status = 'failed'; report.error = error.stack || String(error); }
finally {
  if (executable) {
    try {
      assert.match(executable, /^\/tmp\/wvm-critic-warm-pixels\.[A-Za-z0-9]+\/probe$/);
      report.cleanup = await run('rm -- ' + executable + ' && rmdir -- ' + path.posix.dirname(executable));
      assert.equal(report.cleanup.exit, 0);
    } catch (error) { report.cleanupError = error.stack || String(error); if (!failure) { failure = error; report.status = 'failed'; } }
  }
  if (failure && page && !page.isClosed()) {
    report.failureState = await state().catch(error => ({error: String(error)}));
    await page.screenshot({path: path.join(output, 'failure.png'), fullPage: true}).catch(() => {});
  }
  await Promise.allSettled(reads); await gpuRecording.catch(error => { report.recordingError = String(error); });
  report.sourceReadErrors = readErrors; report.gpuRecordingBytes = gpuBytes;
  await context?.close(); await browser?.close();
  report.finishedAt = new Date().toISOString(); await save();
}
if (failure) throw failure;
console.log(JSON.stringify({status: report.status, frozen, seed7: report.seed7.rgbaSha256,
  sensitivity: report.sensitivity.rejectedBySeed7Oracle, sourceCount: report.sources.length, pair: report.pair.browserResponse.sha256}));
