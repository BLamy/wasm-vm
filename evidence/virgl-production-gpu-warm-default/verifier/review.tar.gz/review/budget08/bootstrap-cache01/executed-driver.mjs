#!/usr/bin/env node
// Missing bootstrap byte acquisition only: actual SW remains enabled, no guest boot.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath,pathToFileURL} from 'node:url';
const repo='/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm';
const output=path.resolve(process.argv[2]),frozen=process.argv[3];
assert.equal(process.argv.length,4);assert.match(frozen,/^[a-f0-9]{40}$/);
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const blob=name=>execFileSync('git',['show',frozen+':web/dist/'+name],{cwd:repo,maxBuffer:128*1024*1024});
const base='https://wasm-vm.pages.dev';
const expectedWorker=blob('linux-worker.js'),expectedSw=blob('sw.js');
const version=expectedSw.toString().match(/const VERSION\s*=\s*"([^"]+)"/)[1];
await fs.mkdir(output,{recursive:false});
const report={schema:'independent-original-sw-bootstrap-cache-proof-v1',status:'running',frozen,startedAt:new Date().toISOString(),
 scope:'Actual original module Worker and current production SW shell bytes, without Linux boot or GPU work',
 predictions:['Real production SW controls actual original worker request; no service worker disabled or bypassed.',
 'Live worker installs original bootstrap callback; exact fetched and cache bytes equal frozen Git.',
 'Actual same-version shell cache used by original cache-first fetch handler supplies linux-worker.js; no body rewrite.',
 'No Linux controller or guest boot is created.'],requests:[],errors:[],expected:{version,workerSha256:hash(expectedWorker),swSha256:hash(expectedSw)}};
const save=()=>fs.writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n');
await fs.writeFile(path.join(output,'executed-driver.mjs'),await fs.readFile(fileURLToPath(import.meta.url)));
await fs.writeFile(path.join(output,'pre-data.json'),JSON.stringify(report,null,2)+'\n');await save();
let browser,context,page,failure;
try{
 const {chromium}=await import(pathToFileURL(path.join(repo,'web/node_modules/playwright/index.mjs')));
 browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--enable-gpu','--use-gl=angle','--use-angle=metal']});
 context=await browser.newContext({viewport:{width:1280,height:850},serviceWorkers:'allow'});page=await context.newPage();
 page.on('pageerror',error=>report.errors.push(String(error)));
 page.on('console',message=>{if(message.type()==='error'&&!/favicon/.test(message.location().url||''))report.errors.push(message.text());});
 page.on('response',response=>{if(response.url()===base+'/linux-worker.js')report.requests.push({url:response.url(),status:response.status(),fromServiceWorker:response.fromServiceWorker()});});
 await page.goto(base+'/app?noAutoBoot&testHooks=1#ide',{waitUntil:'domcontentloaded',timeout:90000});
 await page.waitForFunction(()=>navigator.serviceWorker.controller?.scriptURL.endsWith('/sw.js'),null,{timeout:30000});
 report.before=await page.evaluate(()=>({ready:globalThis.wvmDemo?.isGuestReady?.(),up:globalThis.wvmDemo?.isGuestUp?.(),
  serviceWorker:navigator.serviceWorker.controller.scriptURL}));
 const workerEvent=page.waitForEvent('worker',{predicate:worker=>worker.url()===base+'/linux-worker.js',timeout:30000});
 await page.evaluate(()=>{globalThis.__verifierBootstrapWorker=new Worker('./linux-worker.js',{type:'module',name:'independent-byte-acquisition-only'});});
 const actual=await workerEvent;
 const deadline=Date.now()+30000;
 while(!await actual.evaluate(()=>typeof globalThis.__wasmVmTailscaleEvent==='function')){
  assert.ok(Date.now()<deadline,'original worker bootstrap installed');await page.waitForTimeout(50);
 }
 report.originalWorkerInstalled=true;
 report.originalBytes=await page.evaluate(async({version,url})=>{
  const cacheName='wasm-vm-shell-'+version;
  const deadline=performance.now()+10000;
  let response;
  while(!(response=await(await caches.open(cacheName)).match(url))){if(performance.now()>deadline)throw Error('Original worker cache entry absent');await new Promise(r=>setTimeout(r,25));}
  const bytes=new Uint8Array(await response.arrayBuffer());
  const sw=await fetch('./sw.js',{cache:'reload'});const swBytes=new Uint8Array(await sw.arrayBuffer());
  return {cacheName,key:url,workerStatus:response.status,workerHeaders:Object.fromEntries(response.headers),workerBytes:[...bytes],
   swStatus:sw.status,swBytes:[...swBytes],serviceWorker:navigator.serviceWorker.controller.scriptURL,
   cacheKeys:await caches.keys(),ready:globalThis.wvmDemo?.isGuestReady?.(),up:globalThis.wvmDemo?.isGuestUp?.()};
 },{version,url:base+'/linux-worker.js'});
 const bytes=Buffer.from(report.originalBytes.workerBytes),sw=Buffer.from(report.originalBytes.swBytes);
 delete report.originalBytes.workerBytes;delete report.originalBytes.swBytes;
 report.originalBytes.workerSha256=hash(bytes);report.originalBytes.swSha256=hash(sw);
 assert.deepEqual(bytes,expectedWorker);assert.deepEqual(sw,expectedSw);
 assert.equal(report.originalBytes.up,false,'no Linux guest/controller booted');
 assert.ok(report.requests.some(row=>row.url===base+'/linux-worker.js'&&row.status===200&&row.fromServiceWorker),'actual original worker response was SW-controlled');
 assert.deepEqual(report.errors,[]);
 await fs.writeFile(path.join(output,'original-linux-worker.js'),bytes);await fs.writeFile(path.join(output,'original-sw.js'),sw);
 await page.evaluate(()=>globalThis.__verifierBootstrapWorker.terminate());report.status='passed';
}catch(error){failure=error;report.status='failed';report.error=error.stack||String(error);}
finally{await context?.close();await browser?.close();report.finishedAt=new Date().toISOString();await save();}
if(failure)throw failure;
console.log(JSON.stringify({status:report.status,worker:report.originalBytes.workerSha256,sw:report.originalBytes.swSha256,noGuest:true}));
