"""Enumerate every changed hunk; never infer execution from a worker summary."""
import datetime
import json
from pathlib import Path
import subprocess
import sys

base, head, destination = sys.argv[1:]
def group(filename):
    if filename in ("web/loader.js", "web/dist/loader.js"):
        return "readiness-runtime"
    if filename in ("web/main.js", "web/dist/main.js"):
        return "client-selection-error-and-budget"
    if filename in ("web/index.html", "web/dist/app.html", "web/ide.js", "web/dist/ide.js"):
        return "launcher-and-error-overlay"
    if "artifacts-omarchy-virgl.json" in filename or "gpu-checkpoint-build.js" in filename:
        return "pair-and-worker-identities"
    if filename.startswith(("web/docs", "web/dist/docs")) or filename.endswith(".md") or filename in ("web/landing.html", "web/dist/index.html", "docs/gpu-3d-contract.json"):
        return "prose-and-generated-reader"
    if filename.endswith(("omarchy-startup-state.js", "roadmap.js", "tasks.json", "sw.js")):
        return "declarative-progress-status-and-cache"
    if any(part in filename for part in ("idle-worker-browser", "idle.c", "build-idle", "production-gpu-idle", "capacity-worker-browser", "paired-worker-browser")):
        return "original-mmio-physical-fixture"
    if "warm-pixels" in filename:
        return "original-mesa-literal-probe"
    if "warm-ui" in filename:
        return "original-artifact-sw-cache-negative-harness"
    if any(part in filename for part in ("critic-desktop-actions", "critic-fast-boots")):
        return "original-guest-input-and-bar-harness"
    if filename.startswith(("tools/", "web/tests/")) or filename in ("Makefile", ".gitignore"):
        return "verification-orchestration-and-tests"
    raise AssertionError("unclassified changed path " + filename)

descriptions = {
 "readiness-runtime": "Exact loader block:17synthetic vectors/3private weakened-guard mutants, plus6actual Metal original-worker receipt/loss/old-loader cases. Genuine current repair+CPU accepts; no-CPU/stale/cancelled/undrawn/unusable rejects. Removed visible-frame counter is dead-code elimination. Real post-start Mesa required separately.",
 "client-selection-error-and-budget": "Actual default/repeat warm route, original failure/retry UI, one-worker/no-auto-fallback assertions. Default600s versus explicit tiny override:11exact-expression vectors/2mutants, actual delayed185s and1000ms browser rows. Unchanged software-error fallback tail is waived as pre-existing code, not a new failure policy.",
 "launcher-and-error-overlay": "Real negative DOM ancestor/rect/elementFromPoint checks and screenshots cover showing the launcher, reset/retry, all three recovery choices and desktop CSS override. Two stale warm-default labels were raised and require direct final copy assertions. Static HTML/CSS declarative hunks are waived from instruction-coverage instrumentation.",
 "pair-and-worker-identities": "Configuration bytes authenticate genuine cold factory07 after trusted input, full2aa/173104561B checksum,06622worker, image12 and exact saved clock. Public original CacheStorage/envelope/component metadata authentication and canonical R2 GET bind publication. Generated worker build label is verified against the reproducible build; no relabel/migration.",
 "prose-and-generated-reader": "Declarative documentation only: qualified warm/default, explicit cold/software, ephemeral disk, actual clock and partial GPU boundaries. Format/link/dist parity and direct reader/launcher source+DOM assertions; generated reader/template hash changes are waived as derived output with clean build parity. No emulation capability inferred from prose.",
 "declarative-progress-status-and-cache": "Declarative progress role, honest partial/verified statuses, HEAD-derived activity and generated shell cache identity. Original progress events and default127/0/roadmap/reader checks plus clean build parity cover use. No live-GPU claim from task history or capability label.",
 "original-mmio-physical-fixture": "Real Metal original Wasm/MMIO/device/renderer idle cold/warm/repeat, trusted new red/blue work, source-authenticated old-loader refusal and owner loss. Binary reproducibility is separately recorded. This fixture is explicitly not Linux/Mesa proof. Renderer/capacity implementation remains dependency HELD.",
 "original-mesa-literal-probe": "Pinned independently compiled RISC-V ELF, actual GLES3 readPixels and all64 literal pixels: worker5/2, independent public7 and genuine5 sensitivity. Real new same-epoch jobs/draws/readback; no prefilled GL results. Compiler/build record is metadata, not an emulated GPU substitute. Getter recorder failure stays failed; corrected proof required.",
 "original-artifact-sw-cache-negative-harness": "Six actual default-app failure cases: missing,digest,envelope,identity,SW,cache; original unchanged responses authenticated before forwarding. Fresh digest on modified envelope isolates inner identity; original bad cache entry removed; no readiness/fallback; real retry and visible/hit-testable recovery. Synthetic fixture-oracle controls are distinct from real browser rows.",
 "original-guest-input-and-bar-harness": "Actual mapped Foot focus/uid, trusted absent-to-present marker, guest cursor, original workspace2-to1 effect and9point rAF alpha samples. Factory captures after typing/marker removal, full original GPU trace retained. Network versus cache timing is descriptive only. Original boot-error detection/timeout failures remain preserved; cleanup/diagnostic recorder branches are waived unless negative evidence exercises them.",
 "verification-orchestration-and-tests": "Verification/config only: full-history no-local/noalternates exact committed clone, scrubbed environment, clean ordinary build, native/protocol gates, software4guests/10phases, default127/0 and direct site. Literal public R2 URL rewrite waives no hashes/roles/size bytes. Infrastructure exception/finally branches do not claim product behavior; original failures remain separately recorded.",
}

diff = subprocess.check_output(["git", "diff", "--unified=0", "--no-color", base, head], text=True)
rows = []
filename = None
for line in diff.splitlines():
    if line.startswith("diff --git "):
        filename = line.split(" b/", 1)[1]
    elif line.startswith("@@ "):
        rows.append({"path": filename, "hunk": line, "group": group(filename)})
files = subprocess.check_output(["git", "diff", "--name-only", base, head], text=True).splitlines()
for filename in files:
    if not any(row["path"] == filename for row in rows):
        rows.append({"path": filename, "hunk": "binary/nontext metadata", "group": group(filename)})
assert len(set(row["path"] for row in rows)) == len(files)
Path(destination).write_text(json.dumps({
    "schema": "independent-hunk-sufficiency-map-v1", "base": base, "head": head,
    "status": "interpret with final VERDICT citations; map alone is not proof of execution",
    "recordedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "fileCount": len(files), "hunkCount": len(rows),
    "groups": descriptions, "hunks": rows,
}, indent=2) + "\n")
print(json.dumps({"files": len(files), "hunks": len(rows), "output": destination}))
