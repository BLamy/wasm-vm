#!/usr/bin/env node
// Bounded actual app negative: an explicit tiny client budget remains authoritative.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath, pathToFileURL} from 'node:url';
const repo='/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm';
const output=path.resolve(process.argv[2]), frozen=process.argv[3];
assert.equal(process.argv.length,4);assert.match(frozen,/^[a-f0-9]{40}$/);
const hash=body=>createHash('sha256').update(body).digest('hex');
const blob=name=>execFileSync('git',['show',frozen+':web/dist/'+name],{cwd:repo,maxBuffer:128*1024*1024});
const base='https://wasm-vm.pages.dev';
await fs.mkdir(output,{recursive:false});
const report={schema:'independent-public-explicit-boot-budget-negative-v1',status:'running',frozen,
 startedAt:new Date().toISOString(),scope:'Original default warm app with explicit1000ms boot budget; expected visible refusal, no fallback',
 predictions:['Explicit query1000ms takes precedence over new warm default600000ms.',
  'Original client timeout produces a real guest-error, no ready/restored/controller/desktop.',
  'Retry/cold/software controls remain visible and hit-testable; one intended warm GPU boot and no automatic fallback.'],
 errors:[],consoleErrors:[],sources:[]};
const save=()=>fs.writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n');
await fs.writeFile(path.join(output,'executed-driver.mjs'),await fs.readFile(fileURLToPath(import.meta.url)));
await fs.writeFile(path.join(output,'pre-data.json'),JSON.stringify(report,null,2)+'\n');await save();
function observe(){
 globalThis.__budgetNegative={boots:[],events:[]};
 for(const type of ['wvm:guest-state','wvm:guest-error','wvm:desktop-ready'])addEventListener(type,event=>__budgetNegative.events.push({type,detail:event.detail,time:performance.now()}));
 const post=Worker.prototype.postMessage;
 Worker.prototype.postMessage=function(message,...rest){if(message?.type==='boot')__budgetNegative.boots.push(message.opts);return post.call(this,message,...rest);};
}
let browser,context,page,failure;
try{
 const {chromium}=await import(pathToFileURL(path.join(repo,'web/node_modules/playwright/index.mjs')));
 browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--enable-gpu','--use-gl=angle','--use-angle=metal']});
 const cdp=await browser.newBrowserCDPSession();report.hardware=await cdp.send('SystemInfo.getInfo');report.commandLine=await cdp.send('Browser.getBrowserCommandLine');
 assert.equal(report.hardware.gpu.featureStatus.webgl2??report.hardware.gpu.featureStatus.webgl,'enabled');
 assert.ok(!report.commandLine.arguments.some(value=>/swiftshader|llvmpipe|softpipe|--disable-gpu(?:$|=)/i.test(value)));
 context=await browser.newContext({viewport:{width:1280,height:850},serviceWorkers:'allow'});
 // Authenticate changed main before the real app executes; return exact original bytes.
 await context.route(base+'/main.js',async route=>{
  const response=await route.fetch();assert.equal(response.status(),200);const body=await response.body();assert.equal(hash(body),hash(blob('main.js')));
  await fs.writeFile(path.join(output,'original-main.js'),body);report.sources.push({path:'main.js',bytes:body.length,sha256:hash(body),forwardedUnchanged:true});
  await route.fulfill({response,body});
 });
 await context.addInitScript(observe);page=await context.newPage();
 page.on('pageerror',error=>report.errors.push(String(error)));
 page.on('console',message=>{if(message.type()==='error'&&!/favicon/.test(message.location().url||''))report.consoleErrors.push(message.text());});
 report.url=base+'/app?guest=omarchy&desktop=1&testHooks=1&workerBootTimeoutMs=1000#ide';
 const query=new URL(report.url).searchParams;for(const key of ['gpu','noSnapshot','persist','worker','assetBase','omarchyAssetBase'])assert.equal(query.has(key),false);
 await page.goto(report.url,{waitUntil:'domcontentloaded',timeout:90000});
 await page.waitForFunction(()=>__budgetNegative.events.some(event=>event.type==='wvm:guest-error'&&/boot timed out after 1000ms/.test(event.detail.message)),null,{timeout:90000});
 await page.waitForTimeout(2000);
 report.state=await page.evaluate(()=>{
  const action=selector=>{
   const element=document.querySelector(selector),rect=element?.getClientRects()[0];
   const point=rect?{x:(Math.max(0,rect.left)+Math.min(innerWidth,rect.right))/2,y:(Math.max(0,rect.top)+Math.min(innerHeight,rect.bottom))/2}:null;
   return {visible:Boolean(rect&&getComputedStyle(element).visibility!=='hidden'),hitTestable:Boolean(point&&element.contains(document.elementFromPoint(point.x,point.y))),
    href:element?.href??null,disabled:element?.disabled??false,text:element?.textContent,point};
  };
  return {observer:__budgetNegative,ready:wvmDemo.isGuestReady(),up:wvmDemo.isGuestUp(),restored:__linux.restoredFromBootSnapshot(),
   bootState:__linuxBootStateForTest(),graphics:document.querySelector('#desktop-graphics')?.value,message:document.querySelector('#gpu-status')?.textContent,
   actions:{retry:action('[data-os="omarchy"]'),cold:action('#gpu-cold-retry'),software:action('#gpu-retry')}};
 });
 const state=report.state;
 assert.equal(state.observer.boots.length,1);const options=state.observer.boots[0];assert.equal(options.virgl,true);assert.equal(options.bootSnapshot,true);assert.equal(options.persist,false);
 assert.equal(state.ready,false);assert.equal(state.up,false);assert.equal(state.restored,false);assert.equal(state.graphics,'gpu');
 assert.match(state.bootState.lastBootError,/Linux worker boot timed out after 1000ms/);assert.match(state.message,/GPU desktop could not start/);
 assert.equal(state.observer.events.filter(row=>row.type==='wvm:desktop-ready').length,0);
 assert.equal(state.observer.events.filter(row=>row.type==='wvm:guest-state'&&row.detail.state==='restored').length,0);
 for(const [name,action]of Object.entries(state.actions)){assert.equal(action.visible,true,name+'visible');assert.equal(action.hitTestable,true,name+'hit-testable');}
 assert.equal(state.actions.retry.disabled,false);
 const software=new URL(state.actions.software.href),cold=new URL(state.actions.cold.href);
 assert.equal(software.searchParams.get('gpu'),'0');assert.equal(software.searchParams.has('noSnapshot'),false);
 assert.equal(cold.searchParams.get('gpu'),'1');assert.equal(cold.searchParams.get('noSnapshot'),'1');
 assert.equal(software.hash,'#ide');assert.equal(cold.hash,'#ide');
 assert.deepEqual(report.errors,[]);
 for(const error of report.consoleErrors)assert.match(error,/boot timed out after 1000ms/,'no unrelated browser error');
 assert.equal(report.sources.length,1);
 await page.screenshot({path:path.join(output,'visible-timeout-recovery.png'),fullPage:true});report.status='passed';
}catch(error){failure=error;report.status='failed';report.error=error.stack||String(error);}
finally{
 if(failure&&page&&!page.isClosed())await page.screenshot({path:path.join(output,'failure.png'),fullPage:true}).catch(()=>{});
 await context?.close();await browser?.close();report.finishedAt=new Date().toISOString();await save();
}
if(failure)throw failure;
console.log(JSON.stringify({status:report.status,originalFailure:report.state.bootState.lastBootError,visibleRecovery:true}));
