// Correct only the recorder's compressed/uncompressed digest interpretation.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {createGunzip} from 'node:zlib';
import {Readable} from 'node:stream';
import {fileURLToPath,pathToFileURL} from 'node:url';
const repo='/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm';
const directory=path.resolve(process.argv[2]),prior=path.resolve(process.argv[3]);assert.equal(process.argv.length,4);
await fs.mkdir(directory,{recursive:false});
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const originalBytes=await fs.readFile(path.join(prior,'report.json')),original=JSON.parse(originalBytes);
assert.equal(original.status,'failed');assert.match(original.error,/authenticate-missing\.mjs:152/);
assert.equal(original.state.restored,true);assert.equal(original.state.ready,true);assert.equal(original.state.up,true);
assert.ok(original.delayedOriginalPairRequest.actualHeldMs>=185000);
const codec=execFileSync('git',['show','847f51927637c9ff8226068986a771c9e2a5bedc:web/dist/renderer/virgl-command/checkpoint-codec.mjs'],{cwd:repo});
await fs.writeFile(path.join(directory,'frozen-checkpoint-codec.mjs'),codec);
const {decodeCheckpointData}=await import(pathToFileURL(path.join(directory,'frozen-checkpoint-codec.mjs')));
const pair=await fs.readFile(path.join(repo,'target/evidence/production-gpu-ready-factory07/factory.wvgpair'));
assert.equal(pair.length,original.browserPair.bytes);assert.equal(hash(pair),original.browserPair.sha256);
assert.equal(hash(pair),'2aa73b5d39fa6702cecc5c57193896b8798271a3075e1b0294bed3db864deb4f');
const metadata=decodeCheckpointData(pair.subarray(16,-32));
const report={schema:'independent-compressed-pair-digest-interpretation-v1',status:'running',
 scope:'Identical full2aa local/captured-browser pair; compare gzip bytes to compressedSha256 and independently stream inflate to raw sha256',
 sourceReportSha256:hash(originalBytes),sourceRawStatus:original.status,codecSha256:hash(codec),pairSha256:hash(pair),parts:{},
 predictions:['Captured browser gzip digest must equal declared compressedSha256, not raw sha256.',
  'Independently streamed gzip output must have declared raw length and raw sha256.',
  'Original failed wrapper is preserved unchanged; actual185s warm result is not rerun.']};
await fs.writeFile(path.join(directory,'pre-data.json'),JSON.stringify(report,null,2)+'\n');
await fs.writeFile(path.join(directory,'executed-driver.mjs'),await fs.readFile(fileURLToPath(import.meta.url)));
for(const[name,part]of Object.entries(metadata.parts)){
 assert.equal(part.encoding,'gzip');
 const observed=original.browserPair.parts[name];
 assert.equal(hash(part.bytes),part.compressedSha256);
 assert.equal(observed.observedSha256,part.compressedSha256);
 assert.equal(observed.declaredSha256,part.sha256);
 const digest=createHash('sha256');let length=0;
 const stream=Readable.from([part.bytes]).pipe(createGunzip());
 for await(const block of stream){length+=block.length;assert.ok(length<=part.length);digest.update(block);}
 const rawSha256=digest.digest('hex');assert.equal(length,part.length);assert.equal(rawSha256,part.sha256);
 report.parts[name]={compressedBytes:part.bytes.length,compressedSha256:part.compressedSha256,capturedBrowserCompressedSha256:observed.observedSha256,
  rawBytes:length,rawSha256,declaredRawSha256:part.sha256};
}
assert.equal(hash(await fs.readFile(path.join(prior,'report.json'))),report.sourceReportSha256);
report.status='passed';
await fs.writeFile(path.join(directory,'report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,parts:Object.keys(report.parts),pair:report.pairSha256,rawOriginalStillFailed:true}));
