#!/usr/bin/env node
// Narrow recording repair: preserve run01 and obtain only its two missing bodies.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath, pathToFileURL} from 'node:url';
const repo = '/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm';
const frozen = process.argv[4];
assert.match(frozen, /^[a-f0-9]{40}$/);
const worker = '06622e33ac7fa11a0163e8c58e9f8f36dc2043830d79a04f41e001b847916527';
const pairSha = '2aa73b5d39fa6702cecc5c57193896b8798271a3075e1b0294bed3db864deb4f';
const imageSha = '87e23271916159e1aaed163df43caeec67cd568c4c7e8843527572412fec2c95';
const base = 'https://wasm-vm.pages.dev';
const output = path.resolve(process.argv[2]), prior = path.resolve(process.argv[3]);
assert.equal(process.argv.length, 5);
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const blob = name => execFileSync('git', ['show', frozen + ':' + name], {cwd: repo, maxBuffer: 128 * 1024 * 1024});
await fs.mkdir(output, {recursive: false});
const originalBytes = await fs.readFile(path.join(prior, 'report.json')), original = JSON.parse(originalBytes);
assert.equal(original.status, 'failed'); assert.equal(original.sourceReadErrors.length, 2);
assert.ok(original.sourceReadErrors.some(row => row.url === base + '/linux-worker.js' && /No resource with given identifier/.test(row.error)));
assert.ok(original.sourceReadErrors.some(row => row.url.endsWith('/omarchy-virgl-ready.wvgpair') && /evicted from inspector cache/.test(row.error)));
assert.equal(original.seed7.rgbaSha256, 'c33e9d0a9029ef47e3edefa9cb3740630c08444a04404f5cdd19f621ae4228b7');
assert.equal(original.sensitivity.rejectedBySeed7Oracle, true);
assert.equal(original.sensitivity.rgbaSha256, '73df19f029a14f11beb08a145fdea0ec54ecb72cd25a105e4634ebe29e6814d5');
for (const value of [original.seed7, original.sensitivity]) {
  assert.ok(value.newGpuWork.draws >= 4); assert.ok(value.newGpuWork.outputBytes >= 256);
  assert.equal(value.after.gpu.counters.failed, 0); assert.equal(value.after.gpu.counters.cancelled, 0);
  assert.equal(value.before.gpu.epoch, value.after.gpu.epoch);
}
assert.deepEqual(original.errors, []); assert.deepEqual(original.after.observer.workerErrors, []);
const expectedPixels = await fs.readFile(path.join(prior, 'seed7.expected.rgba'));
assert.equal(hash(expectedPixels), original.seed7.rgbaSha256);
assert.deepEqual(await fs.readFile(path.join(prior, 'seed7.actual.rgba')), expectedPixels);
const report = {schema: 'independent-public-missing-body-supplement-v1', status: 'running', frozen,
  startedAt: new Date().toISOString(), originalRun: {path: prior, reportSha256: hash(originalBytes), rawStatus: original.status,
    carried: ['actual literal seed7', 'genuine seed5 sensitivity', 'same-epoch new physical work', '116original source bodies', 'zero GPU/browser errors'],
    missingOnly: ['linux-worker.js inspector handle', '173MB pair inspector eviction']},
  scope: 'Capture two missing byte identities plus actual original pair request held185seconds; no Mesa/input/broad gate repeated',
  sources: [], errors: [], requests: [], predictions: ['Capture actual worker bootstrap original HTTP body before forwarding unchanged.',
    'In fresh default restored session, read exact original verified CacheStorage pair using browser WebCrypto; never transfer a giant inspector body.',
    'Pair extent/outer digest/envelope/components/worker/image/clock match the same pre-data pins; no auto fallback.',
    'Default app survives185000ms before actual R2 request continues, crossing the former180000ms client deadline.']};
const save = () => fs.writeFile(path.join(output, 'report.json'), JSON.stringify(report, null, 2) + '\n');
const write = async (name, body) => {await fs.mkdir(path.dirname(path.join(output, name)), {recursive: true}); await fs.writeFile(path.join(output, name), body);};
await write('executed-driver.mjs', await fs.readFile(fileURLToPath(import.meta.url)));
await write('published-source.mjs', blob('tools/virgl-production/published-source.mjs'));
const {expectedPublishedSource} = await import(pathToFileURL(path.join(output, 'published-source.mjs')));
for (const row of original.sources) {
  const actual = await fs.readFile(path.join(prior, row.bodyPath));
  assert.equal(hash(actual), row.sha256);
  const originalFrozenBody = execFileSync('git', ['show', original.frozenHead + ':web/dist/' + row.relative], {cwd:repo, maxBuffer:128*1024*1024});
  assert.equal(hash(actual), hash(expectedPublishedSource(row.relative, originalFrozenBody)));
}
await write('pre-data.json', JSON.stringify(report, null, 2) + '\n'); await save();
let browser, context, page, failure;
const reads = [], readErrors = [];
function observe() {
  globalThis.__missingBody = {boots: [], events: [], errors: []};
  for (const type of ['wvm:guest-state', 'wvm:guest-progress', 'wvm:desktop-ready', 'wvm:guest-error'])
    addEventListener(type, event => globalThis.__missingBody.events.push({type, detail: event.detail, time: performance.now()}));
  const post = Worker.prototype.postMessage, seen = new WeakSet();
  Worker.prototype.postMessage = function(message, ...rest) {
    if (!seen.has(this)) {seen.add(this); this.addEventListener('message', event => {
      if (['fatal','error'].includes(event.data?.type)) globalThis.__missingBody.errors.push(event.data.error);
    });}
    if (message?.type === 'boot') globalThis.__missingBody.boots.push(message.opts);
    return post.call(this, message, ...rest);
  };
}
try {
  const {chromium} = await import(pathToFileURL(path.join(repo, 'web/node_modules/playwright/index.mjs')));
  browser = await chromium.launch({headless: true, executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    args: ['--enable-gpu', '--use-gl=angle', '--use-angle=metal']});
  const cdp = await browser.newBrowserCDPSession();
  report.hardware = await cdp.send('SystemInfo.getInfo'); report.commandLine = await cdp.send('Browser.getBrowserCommandLine');
  assert.equal(report.hardware.gpu.featureStatus.webgl2 ?? report.hardware.gpu.featureStatus.webgl, 'enabled');
  assert.ok(!report.commandLine.arguments.some(value => /swiftshader|llvmpipe|softpipe|--disable-gpu(?:$|=)/i.test(value)));
  context = await browser.newContext({viewport: {width:1280, height:850}, serviceWorkers:'allow'});
  const descriptor = JSON.parse(expectedPublishedSource('artifacts-omarchy-virgl.json', blob('web/dist/artifacts-omarchy-virgl.json')));
  const pairUrl = descriptor.artifacts.gpuCheckpoint.url;
  assert.equal(descriptor.artifacts.gpuCheckpoint.sha256, pairSha);
  await context.route(pairUrl, async route => {
    assert.equal(report.delayedOriginalPairRequest, undefined, 'one original pair request');
    const row = report.delayedOriginalPairRequest = {url:route.request().url(),receivedAt:Date.now(),delayMs:185000,unchangedNetworkContinue:true};
    await save(); await new Promise(resolve=>setTimeout(resolve,row.delayMs));
    row.releasedAt=Date.now();row.actualHeldMs=row.releasedAt-row.receivedAt;await save();
    try {await route.continue();} catch(error) {row.error=String(error);await save();}
  });
  await context.route(base + '/linux-worker.js', async route => {
    const original = await route.fetch(); assert.equal(original.status(), 200);
    const body = await original.body(); assert.equal(hash(body), hash(blob('web/dist/linux-worker.js')));
    await write('original-linux-worker.js', body);
    report.workerBootstrap = {url: route.request().url(), bytes: body.length, sha256: hash(body), forwardedUnchanged: true};
    await route.fulfill({response: original, body});
  });
  await context.addInitScript(observe);
  context.on('response', response => {
    const url = new URL(response.url());
    if (url.pathname === '/favicon.ico') return;
    report.requests.push({url: response.url(), status: response.status(), fromServiceWorker: response.fromServiceWorker()});
    if (url.origin !== base || url.pathname === '/linux-worker.js') return;
    reads.push((async () => {try {
      assert.equal(response.status(), 200);
      const relative = url.pathname === '/app' ? 'app.html' : url.pathname.slice(1), body = await response.body();
      assert.equal(hash(body), hash(expectedPublishedSource(relative, blob('web/dist/' + relative))));
      const bodyPath = 'served-source/' + relative; await write(bodyPath, body);
      report.sources.push({url: response.url(), relative, bodyPath, bytes: body.length, sha256: hash(body)});
    } catch (error) {readErrors.push({url: response.url(), error: String(error)});}})());
  });
  page = await context.newPage();
  page.on('pageerror', error => report.errors.push(String(error)));
  page.on('console', message => {if (message.type() === 'error' && !/favicon/.test(message.location().url || '')) report.errors.push(message.text());});
  report.url = base + '/app?guest=omarchy&desktop=1&testHooks=1&gpuTrace=1#ide';
  await page.goto(report.url, {waitUntil:'domcontentloaded', timeout:90000});
  await page.waitForFunction(() => globalThis.wvmDemo?.isGuestReady?.() && globalThis.__linux?.restoredFromBootSnapshot?.() &&
    __missingBody.events.some(row => row.type === 'wvm:desktop-ready'), null, {timeout:600000});
  report.state = await page.evaluate(async () => ({restored:__linux.restoredFromBootSnapshot(), ready:wvmDemo.isGuestReady(),
    up:wvmDemo.isGuestUp(), gpu:await wvmDemo.gpuStats(), clock:await __linuxCtl.guestClockState(), observer:__missingBody}));
  await save();
  assert.equal(report.state.observer.boots.length, 1);
  assert.ok(report.delayedOriginalPairRequest.actualHeldMs>=185000, 'crossed old180s network budget');
  assert.equal(report.delayedOriginalPairRequest.error, undefined);
  const options = report.state.observer.boots[0];
  assert.equal(options.virgl, true); assert.equal(options.bootSnapshot, true); assert.equal(options.persist, false);
  assert.deepEqual(report.state.observer.errors, []); assert.equal(report.state.gpu.qualified, true); assert.equal(report.state.gpu.counters.failed, 0);
  // Read only the actual cache entry written by the original verified asset path.
  // Hash in the browser; return small metadata, never an enormous CDP JSON string.
  report.browserPair = await page.evaluate(async sha256 => {
    const key = location.origin + '/__wasm-vm-boot-assets-v1/' + sha256;
    const response = await (await caches.open('wasm-vm-boot-assets-v1')).match(key);
    if (!response) throw Error('Original warm loader did not cache the verified pair');
    const bytes = new Uint8Array(await response.arrayBuffer());
    const hash = async bytes => [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(x => x.toString(16).padStart(2,'0')).join('');
    const {decodeCheckpointData} = await import('./renderer/virgl-command/checkpoint-codec.mjs');
    const metadata = decodeCheckpointData(bytes.subarray(16, -32));
    const parts = {};
    for (const [name, part] of Object.entries(metadata.parts)) parts[name] = {bytes: part.bytes.length, declaredSha256: part.sha256, observedSha256: await hash(part.bytes)};
    return {key, bytes: bytes.length, sha256: await hash(bytes), magic: new TextDecoder().decode(bytes.subarray(0,8)),
      version: new DataView(bytes.buffer).getUint32(8,true), payloadLength: new DataView(bytes.buffer).getUint32(12,true),
      envelopeSha256: await hash(bytes.subarray(0,-32)), trailerSha256: [...bytes.subarray(-32)].map(x=>x.toString(16).padStart(2,'0')).join(''),
      schema: metadata.schema, identity: metadata.identity, profile: metadata.profile, clockState: metadata.clockState, epoch:metadata.epoch, parts};
  }, pairSha);
  const pair = report.browserPair;
  assert.equal(pair.bytes, 173104561); assert.equal(pair.sha256, pairSha);
  assert.equal(pair.magic, 'WVGPAIR1'); assert.equal(pair.version, 1); assert.equal(pair.payloadLength, pair.bytes-48);
  assert.equal(pair.envelopeSha256, pair.trailerSha256); assert.equal(pair.schema, 'production-gpu-pair-v1');
  assert.equal(pair.identity.buildId, worker); assert.equal(pair.identity.imageManifestSha256, imageSha);
  assert.equal(pair.identity.icountDivider, 64); assert.equal(pair.clockState.mode, 'paced-icount'); assert.equal(pair.clockState.mtime, '1552009163');
  for (const part of Object.values(pair.parts)) assert.equal(part.declaredSha256, part.observedSha256);
  assert.ok(report.requests.some(row => row.url.includes('/sha256/'+pairSha+'/') && row.status===200 && !row.fromServiceWorker));
  assert.ok(report.workerBootstrap?.forwardedUnchanged);
  await page.screenshot({path:path.join(output,'public-warm-authentication.png'), fullPage:true});
  await Promise.all(reads); assert.deepEqual(readErrors, []); assert.deepEqual(report.errors, []);
  assert.equal(hash(await fs.readFile(path.join(prior,'report.json'))), report.originalRun.reportSha256, 'raw failing record remains unchanged');
  report.status = 'passed';
} catch (error) {failure = error; report.status='failed'; report.error=error.stack||String(error);}
finally {
  await Promise.allSettled(reads); report.sourceReadErrors=readErrors;
  if (failure && page && !page.isClosed()) await page.screenshot({path:path.join(output,'failure.png'),fullPage:true}).catch(()=>{});
  await context?.close(); await browser?.close(); report.finishedAt=new Date().toISOString(); await save();
}
if (failure) throw failure;
console.log(JSON.stringify({status:report.status, pair:report.browserPair.sha256, worker:report.workerBootstrap.sha256, originalRawStatus:report.originalRun.rawStatus}));
