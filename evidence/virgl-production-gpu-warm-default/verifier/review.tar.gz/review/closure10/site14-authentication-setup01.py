"""Check every acquired marketing byte against frozen Git or literal R2 rewrite."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path.cwd()
HEAD = "db04c369fe3915537d8cdcf05e59d81bba5bf8dd"
BASE = ROOT / "target/evidence/production-gpu-warm-site14"
sha = lambda body: hashlib.sha256(body).hexdigest()
R2 = "https://pub-c7188e40d3a0463183db72f9dd03cae2.r2.dev"

def expected(name, remote):
    body = subprocess.check_output(["git", "show", HEAD + ":web/dist/" + name])
    if not remote or not re.fullmatch(r"artifacts(?:-[a-z-]+)?\.json", name):
        return body
    value, changed = json.loads(body), False
    for artifact in value.get("artifacts", {}).values():
        url = artifact.get("url", "")
        if re.match(r"^releases/(?:kernel|initramfs|rootfs)/", url) or (
            url.startswith("releases/boot-snapshot/") and artifact["size"] > 25 * 1024 * 1024
        ):
            artifact["url"] = R2 + "/sha256/" + artifact["sha256"] + "/" + url
            changed = True
    def chunks(item):
        nonlocal changed
        if isinstance(item, str) and re.match(r"^releases/chunked-(?:alpine|node-alpine|omarchy)/", item):
            changed = True
            return R2 + "/" + item.removeprefix("releases/")
        if isinstance(item, list):
            return [chunks(value) for value in item]
        if isinstance(item, dict):
            return {key: chunks(value) for key, value in item.items()}
        return item
    value = chunks(value)
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode() if changed else body

result = {"schema": "independent-exact-site14-body-authentication-v1", "status": "passed", "head": HEAD, "rows": []}
for label in ("local", "https"):
    folder = BASE / label
    raw = (folder / "report.json").read_bytes()
    report = json.loads(raw)
    assert report["status"] == "passed" and report["head"] == HEAD
    assert report["errors"] == [] and len(report["steps"]) == 8
    assert report["actualGuestGpu"] is False
    cache, checks = {}, []
    for receipt in report["originalRouteBodies"]:
        name = receipt["path"]
        if name not in cache:
            cache[name] = expected(name, label == "https")
        location = folder / receipt["bodyPath"]
        assert folder.resolve() in location.resolve().parents
        body = location.read_bytes()
        assert len(body) == receipt["bytes"] and sha(body) == receipt["sha256"]
        assert body == cache[name], name
        assert receipt["status"] == 200 and receipt["forwardedUnchanged"] is True
        checks.append({"bodyPath": receipt["bodyPath"], "path": name, "sha256": sha(body), "bytes": len(body)})
    for interrupted in report["interruptedResponseBodies"]:
        matches = [row for row in report["originalRouteBodies"]
                   if row["url"] == interrupted["url"] and row["bodyPath"] == interrupted["originalBodyPath"]]
        assert len(matches) == 1
        assert matches[0]["sha256"] == interrupted["sha256"]
        assert interrupted["acquisition"] == "exact-request-original-response-forwarded-unchanged"
    required = {"omarchy-startup-state.js", "artifacts-busybox.json", "artifacts-alpine.json", "artifacts-node-alpine.json", "artifacts-omarchy.json", "artifacts-omarchy-virgl.json"}
    assert required <= {row["path"] for row in checks}
    result["rows"].append({"label": label, "reportSha256": sha(raw), "originalBodiesChecked": len(checks),
                           "uniquePathsChecked": len(cache), "interruptedExactRequestReceipts": len(report["interruptedResponseBodies"]),
                           "steps": report["steps"], "checks": checks})
destination = ROOT / "target/evidence/critic-production-gpu-warm-final-verifier/closure10/site14-authentication.json"
destination.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"status": result["status"], "rows": [{k: v for k, v in row.items() if k not in ("checks", "steps")} for row in result["rows"]]}))
