"""Falsify concrete final phase claims against independently authenticated records."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import parse_qs, urlsplit

ROOT = Path.cwd()
OUT = ROOT / "target/evidence/critic-production-gpu-warm-final-verifier/closure10"
index = json.loads((ROOT / "evidence/virgl-production-gpu-warm-default/worker/records.json").read_text())
records = {row["path"]: row for row in index["records"]}
custody = json.loads((OUT / "worker-authentication.json").read_text())["custody"]
sha = lambda value: hashlib.sha256(value).hexdigest()

def body(label, relative):
    member = "runs/" + label + "/" + relative
    value = (ROOT / custody["runs"][label] / relative).read_bytes()
    assert records[member] == {"path": member, "bytes": len(value), "sha256": sha(value)}, member
    return value

def report(label, relative="report.json"):
    return json.loads(body(label, relative))

def point(label, relative, pointer):
    name = "runs/" + label + "/" + relative
    return {"archiveMember": name, "sha256": records[name]["sha256"], "jsonPointer": pointer}

result = {"schema": "independent-final-warm-recording-interrogation-v1", "status": "passed", "checks": []}
gpu = report("https12", "default-gpu-warm/report.json")
assert gpu["status"] == "passed" and gpu["errors"] == [] and gpu["warmGpu"] is True
assert len(gpu["phases"]) == 2
palettes = {
    5: [(0, 0, 255, 255), (255, 255, 255, 255), (255, 0, 0, 255), (0, 255, 255, 255)],
    2: [(255, 255, 0, 255), (0, 0, 0, 255), (0, 255, 255, 255), (255, 0, 0, 255)],
}
for number, phase in enumerate(gpu["phases"]):
    state = phase["state"]
    query = parse_qs(urlsplit(phase["url"]).query)
    assert query["guest"] == ["omarchy"]
    assert not {"gpu", "noSnapshot", "persist", "worker", "workerBootTimeoutMs", "assetBase", "omarchyAssetBase"} & set(query)
    assert state["ready"] is True and state["restored"] is True and state["bootState"]["lastBootError"] is None
    assert len(state["workers"]) == 1 and state["workerErrors"] == []
    options = state["workers"][0]["options"]
    assert options["virgl"] is True and options["bootSnapshot"] is True and options["persist"] is False
    assert options["manifestUrl"] == "./artifacts-omarchy-virgl.json"
    inputs = phase["publicDesktopInput"]
    post = phase["postWorkloadInput"]
    for actual, marker in ((inputs, "42"), (post, "84")):
        assert actual["status"] == "passed" and actual["uid"] == "1000"
        assert actual["foot"]["class"] == "foot" and actual["foot"]["mapped"] is True
        assert actual["immediateFocus"]["pid"] == actual["foot"]["pid"]
        assert actual["typedText"] == "touch /tmp/gpukeyboard" + marker + "touch"
        assert actual["markerAbsent"]["exit"] == 0 and actual["markerAbsent"]["stdout"].strip() == ""
        assert actual["marker"]["exit"] == 0 and actual["marker"]["stdout"].strip() == "TRUSTED_TOUCH_" + marker
        events = actual["browserInput"]["events"]
        assert len(events) >= 50 and all(event["trusted"] is True for event in events)
    actions = inputs["barActions"]
    assert [(action["expected"], action["observed"]["id"]) for action in actions["actions"]] == [(2, 2), (1, 1)]
    continuity = actions["continuity"]
    assert continuity["overflow"] is False and len(continuity["samples"]) > 1000
    assert all(sample["blank"] is False and len(sample["alpha"]) == 9 and any(sample["alpha"]) for sample in continuity["samples"])
    assert len(continuity["events"]) >= 50 and all(event["trusted"] is True for event in continuity["events"])
    assert continuity["samples"][-1]["framesReceived"] > continuity["samples"][0]["framesReceived"]
    pixels = phase["warmPixels"]
    assert pixels["status"] == "passed" and pixels["errors"] == []
    assert [run["seed"] for run in pixels["runs"]] == [5, 2]
    pixel_checks = []
    for run in pixels["runs"]:
        seed = run["seed"]
        stdout = run["result"]["stdout"].replace("\r", "")
        actual = re.findall(r"^WARM_PIXELS_BYTES=([0-9a-f]{512})$", stdout, flags=re.M)
        assert len(actual) == 1 and run["result"]["exit"] == 0
        actual = bytes.fromhex(actual[0])
        expected = bytes(channel for y in range(8) for x in range(8)
                         for channel in palettes[seed][(2 if y >= 4 else 0) + (1 if x >= 4 else 0)])
        assert actual == expected
        assert "WARM_PIXELS_RENDERER=virgl (wasm-vm WebGL2 VirGL)\n" in stdout
        assert "WARM_PIXELS_VERSION=OpenGL ES 3.0 Mesa 26.2.2\n" in stdout
        assert f"WARM_PIXELS_RESULT seed={seed} pixels=64 bytes=256 draws=4 different=0\n" in stdout
        assert "WARM_PIXELS_PASS failures=0\n" in stdout
        before, after = run["before"], run["after"]
        assert before["restored"] is True and after["restored"] is True
        assert before["gpu"]["epoch"] == after["gpu"]["epoch"] == "0000000000000003"
        for state_at in (before, after):
            g = state_at["gpu"]
            assert g["qualified"] is True and not any(g[k] for k in ("lost", "disposed", "poisoned"))
            assert g["counters"]["failed"] == 0
        delta = {key: after["gpu"]["counters"][key] - before["gpu"]["counters"][key]
                 for key in ("begun", "completed", "draws", "outputBytes")}
        assert delta == run["gpuDelta"] == {"begun": 5, "completed": 5, "draws": 4, "outputBytes": 256}
        assert sha(actual) == run["pixels"]["rgbaSha256"]
        pixel_checks.append({"seed": seed, "rgbaSha256": sha(actual), "delta": delta})
    final = phase["publicDesktopFinal"]
    assert final["pageErrors"] == [] and final["workerErrors"] == [] and final["ready"] is True and final["restored"] is True
    assert final["gpu"]["qualified"] is True and final["gpu"]["counters"]["failed"] == 0
    result["checks"].append({"criterion": "actual warm/default, new literal Mesa, input, workspace and opacity",
        **point("https12", "default-gpu-warm/report.json", "/phases/" + str(number)),
        "phase": phase["phase"], "newPixels": pixel_checks, "trustedWorkspaceIDs": [2, 1],
        "alphaSamples": len(continuity["samples"]), "fullyTransparentSamples": 0,
        "warmTiming": phase["warmTiming"]})
assert len(gpu["originalWorkerResponses"]) == 2
for receipt in gpu["originalWorkerResponses"]:
    assert receipt["status"] == 200 and receipt["fromServiceWorker"] is True and receipt["acquired"] is True
    assert receipt["acquisition"] == "original-service-worker-cache"
    assert receipt["bytes"] == 1188 and receipt["sha256"] == "7783b4aecb74b83882a2ca3495ed46932ed7930543d0cab72f4035ccfc13e4b9"
    assert receipt["cacheName"] == "wasm-vm-shell-bb643302f27a"
    assert receipt["controller"] == "https://wasm-vm.pages.dev/sw.js"

software = report("https12", "software-fast-boots/report.json")
assert software["status"] == "passed" and software["errors"] == [] and len(software["phases"]) == 10
software_checks = []
for phase in software["phases"]:
    assert phase["state"]["ready"] is True and phase["state"]["restored"] is True
    if "result" in phase:
        assert phase["result"]["exit"] == 0 and "_42_PASS" in phase["result"]["stdout"]
    else:
        assert phase["write"]["exit"] == phase["read"]["exit"] == 0
        assert "DURABLE_" in phase["read"]["stdout"] and phase["checkpoint"]["restored"] is True
        assert phase["generation"] == phase["before"]
    software_checks.append({"phase": phase["phase"], "restoredMs": phase["restoredMs"]})
result["checks"].append({"criterion": "four software guests and persistence", **point("https12", "software-fast-boots/report.json", "/phases"), "phases": software_checks})

failure = report("pristine11", "acceptance/failed-warm-restore/report.json")
assert failure["status"] == "passed" and len(failure["rows"]) == 6
for row in failure["rows"]:
    assert row["status"] == "passed"
    for attempt_name, count in (("attempt1", 1), ("attempt2", 2)):
        attempt = row[attempt_name]
        assert len(attempt["boots"]) == count and attempt["desktopReady"] == []
        assert attempt["ready"] is False and attempt["up"] is False and attempt["restored"] is False
        assert attempt["graphics"] == "gpu" and attempt["pageErrors"] == []
        for boot in attempt["boots"]:
            assert boot["virgl"] is True and boot["bootSnapshot"] is True
        for action in attempt["actions"].values():
            assert action["visible"] is True and action["hitTestable"] is True and action["disabled"] is False
            assert all(not ancestor["hidden"] and ancestor["display"] != "none" for ancestor in action["ancestors"])
    assert row.get("badCacheEntryRemains", False) is False
result["checks"].append({"criterion": "six original failed-restore/retry paths without fallback", **point("pristine11", "acceptance/failed-warm-restore/report.json", "/rows"), "modes": [row["mode"] for row in failure["rows"]]})

default = report("https12", "default-browser/report.json")
assert default["status"] == "passed" and default["errors"] == [] and default["passed"] == 127 and default["failed"] == 0
assert default["proofExportAbsent"] is True and default["graphicsRoadmapPip"] == "cap-pip partial"
pristine = report("pristine11")
acceptance = report("pristine11", "acceptance/report.json")
increment = report("pristine11", "incremental923/report.json")
assert pristine["status"] == acceptance["status"] == increment["status"] == "passed"
assert pristine["head"] == acceptance["head"] == "847f51927637c9ff8226068986a771c9e2a5bedc"
assert len(acceptance["commands"]) == 16 and all(row["exitCode"] == 0 for row in acceptance["commands"])
assert pristine["commands"][0]["command"][1:3] == ["clone", "--no-local"]
assert increment["head"] == "9236bc1b7f89f662ae093d4fe95a15e57e909747" and increment["copiedArtifactOrBuildCache"] is False
assert increment["basePristineReportSha256"] == records["runs/pristine11/report.json"]["sha256"]
native = body("pristine11", "acceptance/native.stdout").decode()
counts = [int(n) for n in re.findall(r"test result: ok\. (\d+) passed", native)]
assert sum(counts) == 423
assert "# tests 101\n" in body("pristine11", "acceptance/protocol.stdout").decode()
result["checks"].append({"criterion": "pristine runtime then reproducible labels/recorder increment", **point("pristine11", "acceptance/report.json", "/commands"), "commands": 16, "nativeTests": sum(counts), "protocolTests": 101})

outer = report("https12")
assert outer["status"] == "failed"
assert [(row["name"], row["exitCode"]) for row in outer["commands"]] == [("default-gpu-warm", 0), ("software-fast-boots", 0), ("default-browser", 0), ("unified-site", 1)]
assert report("site14")["status"] == "passed"
for scope in ("local", "https"):
    site = report("site14", scope + "/report.json")
    assert site["status"] == "passed" and site["errors"] == [] and len(site["steps"]) == 8
assert report("site13")["status"] == "failed"
result["checks"].append({"criterion": "incremental final site acquisition closure preserves original failed wrappers", **point("https12", "report.json", "/commands"), "closure": point("site14", "report.json", "/commands")})
(OUT / "final-interrogation.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"status": result["status"], "checks": len(result["checks"]), "publicGPUPhases": 2, "publicSoftwarePhases": 10, "negativeVariants": 6, "nativeTests": 423, "protocolTests": 101}))
