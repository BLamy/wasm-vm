"""Independently bind public recorded sources to Git, not declared hash strings."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path.cwd()
OUT = ROOT / "target/evidence/critic-production-gpu-warm-final-verifier/closure10"
index = json.loads((ROOT / "evidence/virgl-production-gpu-warm-default/worker/records.json").read_text())
records = {row["path"]: row for row in index["records"]}
sha = lambda body: hashlib.sha256(body).hexdigest()
# This verifier-authored function uses only literal published URL transformations.
# Its main site audit is not executed here; every body still comes from the archive index.
source = (OUT / "site14-authentication.py").read_text().split("result = ", 1)[0]
scope = {}
exec(compile(source, "independent-literal-public-source-expectation", "exec"), scope)
expected = scope["expected"]
cache, groups = {}, []
for group in ("default-gpu-warm", "software-fast-boots"):
    folder = ROOT / "target/evidence/production-gpu-warm-https12" / group
    raw = (folder / "report.json").read_bytes()
    member = "runs/https12/" + group + "/report.json"
    assert sha(raw) == records[member]["sha256"]
    report = json.loads(raw)
    assert report["status"] == "passed" and report["errors"] == []
    observed = set()
    for row in report["liveSources"]:
        name = row["path"]
        path = folder / row["bodyPath"]
        assert folder.resolve() in path.resolve().parents
        body = path.read_bytes()
        member = "runs/https12/" + group + "/" + row["bodyPath"]
        assert sha(body) == records[member]["sha256"]
        assert len(body) == row["bytes"] and sha(body) == row["sha256"]
        if name not in cache:
            cache[name] = expected(name, True)
        assert body == cache[name], name
        observed.add(name)
    required = {"app.html", "main.js", "loader.js", "linux-worker.js", "linux-worker-protocol.js", "linux-worker-host.js", "pkg/wasm_vm_wasm.js", "pkg/wasm_vm_wasm_bg.wasm", "src/sink/presentation.js"}
    assert required <= observed
    if group == "default-gpu-warm":
        assert "artifacts-omarchy-virgl.json" in observed
    groups.append({"phaseGroup": group, "reportSha256": records["runs/https12/" + group + "/report.json"]["sha256"],
                   "recordedBodiesComparedWithGit": len(report["liveSources"]), "uniquePaths": len(observed),
                   "workerBootstrapAcquisitions": report["originalWorkerResponses"]})
result = {"schema": "independent-final-public-source-authentication-v1", "status": "passed",
          "frozenSource": "db04c369fe3915537d8cdcf05e59d81bba5bf8dd", "publishedSource": "9236bc1b7f89f662ae093d4fe95a15e57e909747",
          "literalR2UrlRewriteOnly": True, "groups": groups,
          "uniqueSourceBodies": [{"path": name, "bytes": len(value), "sha256": sha(value)} for name, value in sorted(cache.items())]}
(OUT / "live-source-authentication.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"status": result["status"], "groups": [{key: value for key, value in group.items() if key != "workerBootstrapAcquisitions"} for group in groups]}))
