"""Independent seal/source authentication. Never extracts or edits worker inputs."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile

ROOT = Path.cwd()
OUTPUT = ROOT / "target/evidence/critic-production-gpu-warm-final-verifier/closure10"
WORKER = ROOT / "evidence/virgl-production-gpu-warm-default/worker"
sha = lambda body: hashlib.sha256(body).hexdigest()
manifest = json.loads((WORKER / "manifest.json").read_text())
index_raw = (WORKER / "records.json").read_bytes()
index = json.loads(index_raw)
archive = WORKER / manifest["archive"]
assert archive.stat().st_size == manifest["archiveBytes"]
assert sha(archive.read_bytes()) == manifest["archiveSha256"]
assert sha(index_raw) == manifest["recordIndexSha256"]
assert manifest["sourceHead"] == index["sourceHead"]
expected = {row["path"]: row for row in index["records"]}
assert len(expected) == len(index["records"]) == manifest["records"]
assert manifest["reopenedAndRehashedMembers"] == len(expected)

rows, bodies, regular, ordered = {}, {}, set(), []
with tarfile.open(archive, "r:gz") as tar:
    for member in tar:
        name = member.name
        assert name not in rows and name in expected, name
        path = PurePosixPath(name)
        assert not path.is_absolute() and ".." not in path.parts, name
        assert member.isfile() or member.islnk(), (name, member.type)
        if member.islnk():
            assert member.linkname in regular, (name, member.linkname)
            body = bodies[member.linkname]
        else:
            body = tar.extractfile(member).read()
            regular.add(name)
        row = {"path": name, "bytes": len(body), "sha256": sha(body)}
        assert row == expected[name], name
        rows[name] = row
        bodies[name] = body
        ordered.append(name)
assert set(rows) == set(expected)
source_index = json.loads(bodies["source-index.json"])
assert source_index["sourceHead"] == manifest["sourceHead"]
source_checks = []
for name, receipt in source_index["files"].items():
    body = bodies[name]
    assert receipt == {"bytes": len(body), "sha256": sha(body)}, name
    if name == "source/task.diff":
        original = subprocess.check_output([
            "git", "diff", "--binary", source_index["base"] + ".." + manifest["sourceHead"]
        ])
    else:
        original = subprocess.check_output([
            "git", "show", manifest["sourceHead"] + ":" + name.removeprefix("source/")
        ])
    assert body == original, name
    source_checks.append(rows[name])
changed = subprocess.check_output([
    "git", "diff", "--name-only", source_index["base"] + ".." + manifest["sourceHead"]
], text=True).splitlines()
assert all("source/" + name in source_index["files"] for name in changed)

important = [
    "runs/factory07/report.json",
    "runs/warm-self08/report.json",
    "runs/pristine11/report.json",
    "runs/pristine11/acceptance/report.json",
    "runs/pristine11/incremental923/report.json",
    "runs/https12/report.json",
    "runs/https12/default-gpu-warm/report.json",
    "runs/https12/software-fast-boots/report.json",
    "runs/https12/default-browser/report.json",
    "runs/https12/unified-site/report.json",
]
for label in ("site13", "site14"):
    important.extend("runs/" + label + "/" + name for name in ("report.json", "local/report.json", "https/report.json"))
report_summaries = []
for name in important:
    if name not in bodies:
        continue
    report = json.loads(bodies[name])
    report_summaries.append({
        **rows[name], "status": report.get("status"),
        "head": report.get("head", report.get("sourceHead")),
        "errors": report.get("errors"),
        "commands": [{k: c.get(k) for k in ("name", "exitCode", "command")} for c in report.get("commands", [])],
        "steps": report.get("steps"),
        "failure": report.get("failure"),
    })
custody = json.loads(bodies["custody.json"])
assert custody["sourceHead"] == manifest["sourceHead"]
assert custody["pairSha256"] == "2aa73b5d39fa6702cecc5c57193896b8798271a3075e1b0294bed3db864deb4f"
assert custody["workerBuildId"] == "06622e33ac7fa11a0163e8c58e9f8f36dc2043830d79a04f41e001b847916527"
result = {
    "schema": "independent-worker-capsule-authentication-v1", "status": "authenticated",
    "archive": str(archive.relative_to(ROOT)), "archiveBytes": archive.stat().st_size,
    "archiveSha256": sha(archive.read_bytes()), "recordIndexSha256": sha(index_raw),
    "sourceHead": manifest["sourceHead"], "base": source_index["base"],
    "logicalMembersChecked": len(rows), "uniqueRegularBodiesChecked": len(regular),
    "sourceBodiesComparedWithGit": len(source_checks), "changedPathsCovered": len(changed),
    "safePathsAndEarlierBodyHardlinksOnly": True,
    "reports": report_summaries, "custody": custody,
}
(OUTPUT / "worker-authentication.json").write_text(json.dumps(result, indent=2) + "\n")
(OUTPUT / "source-body-checks.json").write_text(json.dumps(source_checks, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k not in ("reports", "custody")}))
