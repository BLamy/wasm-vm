#!/usr/bin/env node
// Actual owned CacheStorage negatives against the exact frozen recorder helper.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {createServer} from 'node:http';
import {fileURLToPath,pathToFileURL} from 'node:url';
const repo='/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm';
const frozen='9236bc1b7f89f662ae093d4fe95a15e57e909747';
const output=path.resolve(process.argv[2]);assert.equal(process.argv.length,3);
const hash=body=>createHash('sha256').update(body).digest('hex');
const git=name=>execFileSync('git',['show',frozen+':'+name],{cwd:repo,maxBuffer:128*1024*1024});
await fs.mkdir(output,{recursive:false});
const original=git('web/dist/linux-worker.js'),sw=git('web/dist/sw.js'),harness=git('tools/virgl-production/critic-fast-boots.mjs');
assert.equal(original.length,1133);assert.equal(hash(original),'7783b4aecb74b83882a2ca3495ed46932ed7930543d0cab72f4035ccfc13e4b9');
const version=sw.toString().match(/const VERSION = "([a-f0-9]{12})";/)[1];
const text=harness.toString(),start=text.indexOf('    async function captureWorkerShellSources() {');
const end=text.indexOf("\n    if (remoteUrl) page.on('response'",start);assert.ok(start>=0&&end>start);
const exact=text.slice(start,end);
const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;
const invoke=new AsyncFunction('workerShellReceipts','page','shellVersion','fs','path','output','web','hash','report','assert',
 exact+'\nawait captureWorkerShellSources();');
const expectedWeb=path.join(output,'frozen-web');await fs.mkdir(expectedWeb);
await fs.writeFile(path.join(expectedWeb,'linux-worker.js'),original);
await fs.writeFile(path.join(output,'original-sw.js'),sw);await fs.writeFile(path.join(output,'original-helper-source.mjs'),harness);
await fs.writeFile(path.join(output,'exact-extracted-helper.js.txt'),exact);await fs.writeFile(path.join(output,'executed-driver.mjs'),await fs.readFile(fileURLToPath(import.meta.url)));
const wrong=Buffer.from(original);wrong[3]^=1;assert.notEqual(hash(wrong),hash(original));
await fs.writeFile(path.join(output,'wrong-one-byte-bootstrap.js'),wrong);
const report={schema:'independent-original-sw-acquisition-rejections-v1',status:'running',frozen,
 scope:'Exact recorder helper, real owned production SW/cache and original bootstrap module; no Linux boot or GPU rendering',
 beforeBrowser:true,source:{workerBytes:original.length,workerSha256:hash(original),swSha256:hash(sw),helperFileSha256:hash(harness),exactHelperSha256:hash(exact),version,
  wrongBytes:wrong.length,wrongSha256:hash(wrong),singleChangedByte:3},rows:[],requests:[],errors:[],
 predictions:['Original1133B real module+same-version SWcache is acquired exactly.',
  'Deleting only expected owned shell cache rejects the exact helper while original SW stays controlling.',
  'Wrong one-byte bootstrap stored by actual SW retains real URL/status, but exact helper rejects its hash and records no successful acquisition.',
  'No boot message or guest controller is created.']};
const save=()=>fs.writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n');
await fs.writeFile(path.join(output,'pre-data.json'),JSON.stringify(report,null,2)+'\n');await save();
let current=original,browser,context,page,failure;
const served=new Map();
const server=createServer(async(request,response)=>{
 const name=new URL(request.url,'http://owned.invalid').pathname.slice(1);
 try{
  let bytes,type='text/javascript';
  if(!name){bytes=Buffer.from('<!doctype html><title>Owned source acquisition only</title>');type='text/html';}
  else if(name==='favicon.ico'){response.writeHead(204).end();return;}
  else if(name==='sw.js')bytes=sw;
  else if(name==='linux-worker.js')bytes=current;
  else{if(!served.has(name))served.set(name,git('web/dist/'+name));bytes=served.get(name);}
  report.requests.push({path:name,bytes:bytes.length,sha256:hash(bytes)});
  response.writeHead(200,{'Content-Type':type,'Cache-Control':'no-store'}).end(bytes);
 }catch(error){report.requests.push({path:name,error:String(error)});response.writeHead(404).end('Not in frozen corpus');}
});
async function call(name,expectedFailure){
 const directory=path.join(output,name);await fs.mkdir(directory);
 const receipt={phase:name,url:report.workerUrl,path:'linux-worker.js',status:200,fromServiceWorker:true};
 const capture={liveSources:[]},row={name,expectedFailure,helperSha256:hash(exact)};report.rows.push(row);
 row.actualCache=await page.evaluate(async({name,url})=>{
  const keys=await caches.keys();const response=keys.includes(name)?await(await caches.open(name)).match(url):null;
  return {keys,controller:navigator.serviceWorker.controller?.scriptURL??null,url:response?.url??null,status:response?.status??null,
   bytes:response?Array.from(new Uint8Array(await response.arrayBuffer())):null};
 },{name:'wasm-vm-shell-'+version,url:report.workerUrl});
 if(row.actualCache.bytes){row.actualCache.sha256=hash(Buffer.from(row.actualCache.bytes));delete row.actualCache.bytes;}
 let error;
 try{await invoke([receipt],page,version,fs,path,directory,expectedWeb,hash,capture,assert);}catch(caught){error=caught.message;}
 row.helperError=error;row.receipt=receipt;row.recordedSources=capture.liveSources;await save();
 if(expectedFailure){
  assert.match(error??'',expectedFailure);assert.equal(receipt.acquired,undefined);assert.equal(capture.liveSources.length,0);
 }else{
  assert.equal(error,undefined);assert.equal(receipt.acquired,true);assert.equal(receipt.sha256,hash(original));
  assert.deepEqual(await fs.readFile(path.join(directory,receipt.bodyPath)),original);
 }
 row.prediction='HELD';await save();
}
try{
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin='http://127.0.0.1:'+server.address().port;report.workerUrl=origin+'/linux-worker.js';
 const {chromium}=await import(pathToFileURL(path.join(repo,'web/node_modules/playwright/index.mjs')));
 browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--enable-gpu','--use-gl=angle','--use-angle=metal']});
 context=await browser.newContext({serviceWorkers:'allow'});page=await context.newPage();
 page.on('pageerror',error=>report.errors.push(String(error)));
 page.on('console',message=>{if(message.type()==='error'&&!/favicon/.test(message.location().url||''))report.errors.push(message.text());});
 report.workerResponses=[];page.on('response',response=>{if(response.url()===report.workerUrl)report.workerResponses.push({url:response.url(),status:response.status(),fromServiceWorker:response.fromServiceWorker()});});
 await page.goto(origin+'/');
 await page.evaluate(async()=>{await navigator.serviceWorker.register('./sw.js',{scope:'./'});await navigator.serviceWorker.ready;});
 await page.waitForFunction(()=>Boolean(navigator.serviceWorker.controller));
 await page.evaluate(()=>{
  globalThis.__acquisitionBoots=[];const post=Worker.prototype.postMessage;
  Worker.prototype.postMessage=function(message,...rest){if(message?.type==='boot')__acquisitionBoots.push(message);return post.call(this,message,...rest);};
 });
 const event=page.waitForEvent('worker',{predicate:worker=>worker.url()===report.workerUrl,timeout:30000});
 await page.evaluate(()=>{globalThis.__acquisitionWorker=new Worker('./linux-worker.js',{type:'module'});});
 const actual=await event;let deadline=Date.now()+30000;
 while(!await actual.evaluate(()=>typeof globalThis.__wasmVmTailscaleEvent==='function')){assert.ok(Date.now()<deadline);await page.waitForTimeout(25);}
 assert.ok(report.workerResponses.some(row=>row.fromServiceWorker&&row.status===200));
 await page.waitForFunction(async({name,url})=>Boolean(await(await caches.open(name)).match(url)),{name:'wasm-vm-shell-'+version,url:report.workerUrl});
 await call('original-positive',null);
 await page.evaluate(()=>__acquisitionWorker.terminate());
 await page.evaluate(name=>caches.delete(name),'wasm-vm-shell-'+version);
 await call('missing-cache',/controlling service worker/);
 current=wrong;
 const poisoned=await page.evaluate(async url=>{const response=await fetch(url,{cache:'reload'});return {url:response.url,status:response.status,bytes:Array.from(new Uint8Array(await response.arrayBuffer()))};},report.workerUrl);
 assert.equal(poisoned.url,report.workerUrl);assert.equal(poisoned.status,200);assert.equal(hash(Buffer.from(poisoned.bytes)),hash(wrong));
 deadline=Date.now()+10000;
 while(!await page.evaluate(async({name,url})=>Boolean(await(await caches.open(name)).match(url)),{name:'wasm-vm-shell-'+version,url:report.workerUrl})){assert.ok(Date.now()<deadline);await page.waitForTimeout(25);}
 current=original;
 await call('wrong-cached-bytes',/actual cached worker bootstrap source/);
 const wrongRow=report.rows.at(-1);assert.equal(wrongRow.actualCache.url,report.workerUrl);assert.equal(wrongRow.actualCache.status,200);assert.equal(wrongRow.actualCache.sha256,hash(wrong));
 report.bootMessages=await page.evaluate(()=>__acquisitionBoots);assert.deepEqual(report.bootMessages,[]);assert.deepEqual(report.errors,[]);
 report.status='passed';
}catch(error){failure=error;report.status='failed';report.error=error.stack||String(error);}
finally{await context?.close();await browser?.close();await new Promise(resolve=>server.close(resolve));report.finishedAt=new Date().toISOString();await save();}
if(failure)throw failure;
console.log(JSON.stringify({status:report.status,rows:report.rows.map(row=>({name:row.name,prediction:row.prediction,expectedRejection:!!row.expectedFailure})),noBoot:report.bootMessages.length===0}));
