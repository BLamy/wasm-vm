from pathlib import Path
import hashlib
import json
import subprocess

REPO = Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
OUT = Path(__file__).resolve().parent
FROZEN = 'ccc8d0026462aa3492f88f3c90cc894dd66fc9f9'
OLD = '6297df65b3405acc665b76eff2e504c6def96248'
NEW_ID = '06622e33ac7fa11a0163e8c58e9f8f36dc2043830d79a04f41e001b847916527'
sha = lambda body: hashlib.sha256(body).hexdigest()
read = lambda path: json.loads(path.read_text())
git = lambda *args: subprocess.check_output(['git', *args], cwd=REPO)
names = ['healthy01', 'old-loader-negative01', 'withheld01', 'cancelled01', 'stale-generation01', 'context-loss01']
reports = {name: read(OUT/name/'report.json') for name in names}
tracked = {ref: set(git('ls-tree', '-r', '--name-only', ref, '--', 'web').decode().splitlines()) for ref in [FROZEN, OLD]}
queries, uses = [], []
for name, report in reports.items():
    assert report['hardware']['gpu']['featureStatus'].get('webgl2', report['hardware']['gpu']['featureStatus'].get('webgl')) == 'enabled'
    assert any(arg.startswith('--headless') for arg in report['hardware']['commandLine'])
    assert '--use-angle=metal' in report['hardware']['commandLine']
    assert not report['errors'], (name, report['errors'])
    assert report['kernel']['sha256'] == '27d38ba1c7a120ba9f55613bb1a0ca634e75369b3a094099bd16bbe68b788aed'
    for item in report['sources']:
        frozen = OUT/name/'source'/item['path']
        body = frozen.read_bytes()
        assert len(body) == item['bytes'] and sha(body) == item['sha256'], (name, item['path'])
        ref = OLD if name == 'old-loader-negative01' and item['path'] in ['web/loader.js', 'web/gpu-checkpoint-build.js'] else FROZEN
        source = item['path']
        if source not in tracked[ref] and source.startswith('web/pkg/'):
            source = source.replace('web/pkg/', 'web/dist/pkg/', 1)
        assert source in tracked[ref], ('unmatched frozen source', name, source)
        query = ref + ':' + source
        queries.append(query)
        uses.append((name, item['path'], query, body))
unique = list(dict.fromkeys(queries))
result = subprocess.run(['git', 'cat-file', '--batch'], cwd=REPO, input=('\n'.join(unique)+'\n').encode(), stdout=subprocess.PIPE, check=True).stdout
offset, objects = 0, {}
for query in unique:
    newline = result.index(b'\n', offset)
    header = result[offset:newline].decode().split()
    assert len(header) == 3 and header[1] == 'blob', (query, header)
    size = int(header[2]); offset = newline + 1
    objects[query] = result[offset:offset+size]; offset += size
    assert result[offset:offset+1] == b'\n'; offset += 1
assert offset == len(result)
for name, path, query, body in uses:
    assert body == objects[query], ('frozen source drift', name, path, query)

healthy, old = reports['healthy01'], reports['old-loader-negative01']
a = {x['path']: x['sha256'] for x in healthy['sources']}
b = {x['path']: x['sha256'] for x in old['sources']}
assert a.keys() == b.keys()
changed = sorted(path for path in a if a[path] != b[path])
assert changed == ['web/gpu-checkpoint-build.js', 'web/loader.js'], changed
assert healthy['status'] == 'passed'
phases = {x['label']: read(OUT/'healthy01'/(x['label']+'.json')) for x in healthy['phases']}
for item in healthy['phases']:
    assert sha((OUT/'healthy01'/(item['label']+'.json')).read_bytes()) == item['sha256']
for state in phases.values():
    g = state['gpu']
    assert g['qualified'] and not any(g[k] for k in ['lost', 'poisoned', 'disposed'])
    assert g['counters']['failed'] == 0 and not state['errors']
    assert state['scheduler']['retiredInstructions'] > 0
cold, warm, typed, repeat = [phases[x] for x in ['cold', 'warm', 'warm-input', 'repeat']]
assert cold['restored'] is False and warm['restored'] is True and repeat['restored'] is True
assert cold['pixel'] == warm['pixel'] == [0, 255, 0, 255]
assert typed['pixel'] == phases['repeat-input']['pixel'] == [255, 0, 0, 255]
assert repeat['pixel'] == [0, 0, 255, 255]
assert warm['gpu']['renderer']['work']['draws'] == cold['gpu']['renderer']['work']['draws']
assert warm['gpu']['counters']['completed'] == cold['gpu']['counters']['completed']
assert typed['gpu']['renderer']['work']['draws'] > warm['gpu']['renderer']['work']['draws']
assert typed['gpu']['counters']['completed'] > warm['gpu']['counters']['completed']
assert any(x['type'] == 'keydown' and x['isTrusted'] for x in typed['trusted'])
for state in [warm, repeat]:
    assert any(x['epoch'] == state['gpu']['epoch'] and x['sequence'] is None and x['status'] == 'drawn' for x in state['gpu']['scanout']['retirements'])
    assert 'PAIR_GUEST_START' not in state['serial'] and 'PAIR_FAIL' not in state['serial']

negative_summaries = []
for name in names[1:]:
    report = reports[name]
    assert report['status'] == 'failed' and report['cold']['restored'] is False
    assert report.get('warm') is None
    partial = report['partial']
    assert 'restored' not in partial['states'] and 'booting' not in partial['states']
    assert partial['states'] == ['fetching', 'instantiating', 'restoring', 'error']
    expected = 'resumed guest did not produce new GPU work and scanout' if name == 'old-loader-negative01' else 'resumed worker stopped or GPU owner became unusable' if name == 'context-loss01' else 'resumed CPU or fresh physical scanout did not become ready'
    assert expected in report['failure']['message'], (name, report['failure']['message'])
    if name not in ['old-loader-negative01', 'context-loss01']:
        assert partial['attacks']
    negative_summaries.append({'name': name, 'status': 'HELD expected failure', 'failure': expected,
        'reportSha256': sha((OUT/name/'report.json').read_bytes()), 'states': partial['states']})

observer = read(OUT/'stale-generation01/guard-observer.json')
assert not observer['errors'] and len(observer['observations']) == 2
entry, deadline = [x['value'] for x in observer['observations']]
assert entry['retiredInstructions'] == 0 and deadline['retiredInstructions'] > 0
assert deadline['freshDrawn'] is False and deadline['scanout']['drawn'] == 0 and deadline['scanout']['retainedFrames'] == 1
assert deadline['owner']['qualified'] and deadline['owner']['counters']['failed'] == 0
for row in observer['observations']:
    assert row['sourceSha256'] == a['web/loader.js']
loss = read(OUT/'context-loss01/guard-observer.json')
assert not loss['errors'] and len(loss['observations']) == 1
assert loss['observations'][0]['injection']['expression'] == 'productionGpu.loseContext("now")'
assert 'context lost' in reports['context-loss01']['partial']['errors']
vectors = read(OUT/'exact-guard-vectors.json')
assert vectors['status'] == 'passed' and len(vectors['rows']) == 17 and len(vectors['negativeControls']) == 3
assert vectors['loaderSha256'] == a['web/loader.js']
assert all(row['oracleRejected'] for row in vectors['negativeControls'])
review = {'schema': 'independent-readiness-physical-authentication-v1', 'status': 'passed',
    'frozenRuntimeHead': FROZEN, 'workerBuildId': NEW_ID, 'sourceByteChecks': len(uses),
    'oldLoaderNegativeDiffOnly': changed, 'healthy': {'phases': list(phases), 'reportsHead': healthy['head'],
        'warmHasNoSpontaneousGuestDraws': True, 'trustedPostStartDraws': True, 'freshRepairBeforeInput': True},
    'negativePredictions': negative_summaries, 'staleAckCpuRetirements': deadline['retiredInstructions'],
    'syntheticGuardVectors': 17, 'privateWeakenedGuardNegatives': 3,
    'scope': 'Original MMIO supervisor fixture and exact guard branches; actual Omarchy/Mesa/published artifact acceptance remains separate.'}
(OUT/'authentication.json').write_text(json.dumps(review, indent=2)+'\n')
print(json.dumps(review, indent=2))
