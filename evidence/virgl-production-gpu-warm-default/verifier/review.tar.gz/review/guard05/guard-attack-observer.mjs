// Owned-worker debugger observation; source bytes are authenticated before injection.
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
export async function observeGuardAttack(context,page,output,{attack='observe'}={}) {
  const loader=await fs.readFile('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm/web/loader.js','utf8');
  const sha=s=>createHash('sha256').update(s).digest('hex');
  const lines=loader.split('\n'),line=lines.findIndex(s=>s.includes('if(retiredInstructions>0&&freshDrawn)break;'));
  assert.ok(line>0);
  const report={schema:'independent-original-guard-attack-v1',attack,loaderSha256:sha(loader),lineNumber:line,
    runtimeSourceModified:false,events:[],observations:[],errors:[]};
  const save=()=>fs.writeFile(path.join(output,'guard-observer.json'),JSON.stringify(report,null,2)+'\n');
  const session=await context.newCDPSession(page),pending=new Map(),children=new Map(),jobs=new Set();let id=0;
  const child=(sid,method,params={})=>new Promise((resolve,reject)=>{
    const sequence=++id;pending.set(sequence,{resolve,reject});
    session.send('Target.sendMessageToTarget',{sessionId:sid,message:JSON.stringify({id:sequence,method,params})}).catch(reject);
  });
  const launch=fn=>{const job=fn();jobs.add(job);job.finally(()=>jobs.delete(job));};
  session.on('Target.receivedMessageFromTarget',({sessionId,message})=>{
    const event=JSON.parse(message);
    if(event.id){const p=pending.get(event.id);pending.delete(event.id);if(event.error)p?.reject(Error(JSON.stringify(event.error)));else p?.resolve(event.result);return;}
    if(event.method!=='Debugger.paused')return;
    launch(async()=>{
      const pausedAt=performance.now();let row;
      try {
        const state=children.get(sessionId);assert.ok(state);
        const frame=event.params.callFrames[0];
        const source=await child(sessionId,'Debugger.getScriptSource',{scriptId:frame.location.scriptId});
        assert.equal(sha(source.scriptSource),report.loaderSha256,'debugger executed the exact frozen original loader');
        await fs.writeFile(path.join(output,'debugger-original-loader.js.txt'),source.scriptSource);
        const expression="(()=>{const g=productionGpu.inspect(),j=machine.jitStats();return {now:performance.now(),deadline,stopped,paused,tickScheduled,sliceCount,retiredInstructions,active:taskQuiescence.isActive(),clock:machine.guestClockState(),jit:{guestRetired:j.guestRetired,compiledBlocks:j.compiledBlocks,executedBlocks:j.executedBlocks},pendingChunks:machine.pendingChunks(),fetch:machine.fetchStats(),owner:{epoch:g.epoch,qualified:g.qualified,lost:g.lost,disposed:g.disposed,poisoned:g.poisoned,pending:g.pending,counters:g.counters},scanout:{drawn:g.scanout.drawn,cancelled:g.scanout.cancelled,retainedFrames:g.scanout.retainedFrames,lastRetirements:g.scanout.retirements.slice(-2)},freshDrawn};})()";
        const observation=await child(sessionId,'Debugger.evaluateOnCallFrame',{callFrameId:frame.callFrameId,expression,returnByValue:true});
        assert.equal(observation.exceptionDetails,undefined);
        row={stage:state.visits++===0?'entry':'deadline',scriptId:frame.location.scriptId,sourceSha256:sha(source.scriptSource),location:frame.location,expression,value:observation.result.value};
        report.observations.push(row);
        if(attack==='loss'&&state.visits===1){
          const injection='productionGpu.loseContext("now")';
          row.injection={expression:injection,result:await child(sessionId,'Debugger.evaluateOnCallFrame',{callFrameId:frame.callFrameId,expression:injection,returnByValue:true})};
          assert.equal(row.injection.result.exceptionDetails,undefined);
        }
        await child(sessionId,'Debugger.removeBreakpoint',{breakpointId:state.breakpoint});
        if(attack==='observe'&&state.visits===1){const b=await child(sessionId,'Debugger.setBreakpointByUrl',{urlRegex:'/loader\\.js(?:\\?|$)',lineNumber:line,condition:'performance.now()>deadline-100'});state.breakpoint=b.breakpointId;}
      }catch(error){report.errors.push({message:String(error),stack:error.stack});}
      finally {
        try {await child(sessionId,'Debugger.resume');}catch(error){report.errors.push({message:String(error)});}
        if(row)row.nodePausedMillis=performance.now()-pausedAt;
        await save();
      }
    });
  });
  session.on('Target.attachedToTarget',({sessionId,targetInfo})=>launch(async()=>{
    try {
      report.events.push({type:'attached',targetInfo});await child(sessionId,'Debugger.enable');
      const b=await child(sessionId,'Debugger.setBreakpointByUrl',{urlRegex:'/loader\\.js(?:\\?|$)',lineNumber:line});
      children.set(sessionId,{visits:0,breakpoint:b.breakpointId});
    }catch(error){report.errors.push({message:String(error)});}
    finally {await child(sessionId,'Runtime.runIfWaitingForDebugger').catch(error=>report.errors.push({message:String(error)}));await save();}
  }));
  await session.send('Target.setAutoAttach',{autoAttach:true,waitForDebuggerOnStart:true,flatten:false,filter:[{type:'worker',exclude:false},{exclude:true}]});await save();
  return {finish:async()=>{await Promise.allSettled([...jobs]);await save();}};
}
