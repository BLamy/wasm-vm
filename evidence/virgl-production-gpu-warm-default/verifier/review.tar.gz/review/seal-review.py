"""Seal every independent byte, deduplicating identical bodies with tar hardlinks."""
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile
import sys

source, destination = map(Path, sys.argv[1:])
source = source.resolve()
destination = destination.resolve()
assert source not in destination.parents
assert not destination.exists()
files = []
for item in sorted(source.rglob("*")):
    assert not item.is_symlink(), item
    if item.is_file():
        body = item.read_bytes()
        files.append({"path": item.relative_to(source).as_posix(), "bytes": len(body),
                      "sha256": hashlib.sha256(body).hexdigest()})
manifest = {"schema": "independent-warm-verifier-capsule-v1", "sourceRoot": str(source),
            "files": files, "indexedFiles": len(files),
            "deduplication": "Internal prior-member hardlinks preserve every original path and exact body"}
manifest_body = (json.dumps(manifest, indent=2)+"\n").encode()
destination.parent.mkdir(parents=True, exist_ok=True)

def info(name, size):
    value = tarfile.TarInfo(name)
    value.size = size
    value.mode = 0o444
    value.mtime = 0
    value.uid = value.gid = 0
    value.uname = value.gname = ""
    return value

unique = {}
with destination.open("xb") as raw:
    with gzip.GzipFile(filename="", fileobj=raw, mode="wb", mtime=0, compresslevel=9) as zipped:
        with tarfile.open(fileobj=zipped, mode="w") as archive:
            archive.addfile(info("MANIFEST.json", len(manifest_body)), io.BytesIO(manifest_body))
            for entry in files:
                name = "review/" + entry["path"]
                body = (source / entry["path"]).read_bytes()
                assert len(body) == entry["bytes"] and hashlib.sha256(body).hexdigest() == entry["sha256"]
                value = info(name, len(body))
                if entry["sha256"] in unique:
                    value.type = tarfile.LNKTYPE
                    value.linkname = unique[entry["sha256"]]
                    value.size = 0
                    archive.addfile(value)
                else:
                    unique[entry["sha256"]] = name
                    archive.addfile(value, io.BytesIO(body))

# Reopen independently and hash every path, including tar hardlink aliases.
with tarfile.open(destination, "r:gz") as archive:
    members = archive.getmembers()
    assert len(members) == len(files) + 1
    assert len({member.name for member in members}) == len(members)
    for member in members:
        parts = PurePosixPath(member.name)
        assert not parts.is_absolute() and ".." not in parts.parts
        assert member.isfile() or member.islnk()
        if member.islnk():
            target = PurePosixPath(member.linkname)
            assert not target.is_absolute() and ".." not in target.parts
            assert member.linkname in {other.name for other in members}
    assert archive.extractfile("MANIFEST.json").read() == manifest_body
    for entry in files:
        body = archive.extractfile("review/"+entry["path"]).read()
        assert len(body) == entry["bytes"] and hashlib.sha256(body).hexdigest() == entry["sha256"]
receipt = {"schema": "independent-warm-verifier-capsule-receipt-v1", "path": str(destination),
           "bytes": destination.stat().st_size, "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
           "members": len(files)+1, "indexedFiles": len(files), "uniqueBodies": len(unique),
           "allMemberBodiesRehashed": True, "manifestSha256": hashlib.sha256(manifest_body).hexdigest()}
destination.with_suffix(destination.suffix+".json").write_text(json.dumps(receipt, indent=2)+"\n")
print(json.dumps(receipt))
