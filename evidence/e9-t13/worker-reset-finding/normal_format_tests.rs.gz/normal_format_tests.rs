#[test]
fn critic_all_event_forms_and_mixed_same_boundary_schedules_roundtrip() {
    use wasm_vm_core::session_network::LinkStatus;
    let forms = [
        Event::Receive(vec![]),
        Event::Receive(vec![0x59; MAX_FRAME]),
        Event::Pending(false),
        Event::Pending(true),
        Event::Link { status: LinkStatus::Open, code: 0 },
        Event::Link { status: LinkStatus::Closed, code: 0 },
        Event::Link { status: LinkStatus::Failed, code: 0xffff_fffe },
        Event::Send { request: NetworkRequest { id: 1, frame: vec![] }, result: SendResult::Sent },
        Event::Send { request: NetworkRequest { id: 1, frame: vec![0x71; MAX_FRAME] }, result: SendResult::Failed },
        Event::Send { request: NetworkRequest { id: u64::MAX, frame: vec![0x73] }, result: SendResult::Cancelled },
    ];
    for form in forms { assert_eq!(Event::decode(&form.encode().unwrap()), Ok(form)); }
    for seed in [0x04c6_13a9_u64, 0x9ff7_201d, 0x731c_48e5, 0xc102_d7b3, 0x6a85_f903, 0xf387_412b] {
        let mut m = fixture(false);
        until(&mut m, START, 1 + seed % 113, &mut Trace::default());
        let pending = m.save_session_resume().unwrap();
        let request = m.session_network_requests().unwrap().remove(0);
        let mut events = vec![
            Event::Pending(true),
            Event::Receive(vec![seed as u8, 0x57, 0xa9]),
            Event::Send { request, result: if seed & 1 == 0 { SendResult::Failed } else { SendResult::Cancelled } },
            Event::Receive(vec![0x23, (seed >> 8) as u8]),
            Event::Link { status: LinkStatus::Open, code: 0 },
        ];
        let mut rng = seed;
        for index in (1..events.len()).rev() {
            rng ^= rng << 13; rng ^= rng >> 7; rng ^= rng << 17;
            events.swap(index, rng as usize % (index + 1));
        }
        let mut receipts = Vec::new();
        for event in events { receipts.push(capture(&mut m, event)); }
        receipts.push(capture(&mut m, Event::Link { status: LinkStatus::Closed, code: 0 }));
        assert_eq!(receipts.iter().map(|r| r.position.ordinal).collect::<Vec<_>>(), (1..=6).collect::<Vec<_>>());
        let queued = m.save_session_resume().unwrap();
        let mut same = fixture(false); same.load_session_resume(&queued).unwrap();
        assert_eq!(same.save_session_resume().unwrap(), queued);
        let mut original_trace = Trace::default();
        until(&mut m, END, 31, &mut original_trace);
        let expected = m.save_session_resume().unwrap();
        let mut r = fixture(true); r.load_session_resume(&pending).unwrap();
        for row in &receipts { replay(&mut r, row); }
        let mut rt = Trace::default(); until(&mut r, END, 1 + (seed >> 4) % 257, &mut rt);
        r.finish_session_network_replay(6).unwrap();
        assert_eq!(r.save_session_resume().unwrap(), expected, "seed={seed:x}");
        assert_eq!(rt.0, original_trace.0);
        evidence(&format!("critic-same-boundary-{seed:x}.resume"), &expected);
        evidence(&format!("critic-same-boundary-{seed:x}.trace"), rt.0.as_bytes());
    }
}

#[test]
fn critic_combined_owned_capacity_frees_exactly_the_acknowledged_tx_bytes() {
    use wasm_vm_core::session_network::MAX_OWNED;
    let mut m = fixture(false); until(&mut m, START, 31, &mut Trace::default());
    let request = m.session_network_requests().unwrap().remove(0);
    let mut remaining = MAX_OWNED - request.frame.len();
    while remaining != 0 {
        let n = remaining.min(MAX_FRAME);
        capture(&mut m, Event::Receive(vec![0x67; n])); remaining -= n;
    }
    let full = m.save_session_resume().unwrap();
    let ingress = m.lease_session_network(None).unwrap();
    assert_eq!(m.complete_session_network(&ingress, Event::Receive(vec![0x31])), Err(Error::Limit));
    assert_eq!(m.save_session_resume().unwrap(), full);
    capture(&mut m, Event::Send { request: request.clone(), result: SendResult::Cancelled });
    capture(&mut m, Event::Receive(vec![0x29; request.frame.len()]));
    let full_again = m.save_session_resume().unwrap();
    assert_eq!(m.complete_session_network(&ingress, Event::Receive(vec![0x32])), Err(Error::Limit));
    assert_eq!(m.save_session_resume().unwrap(), full_again);
    let mut restored = fixture(false); restored.load_session_resume(&full_again).unwrap();
    assert_eq!(restored.save_session_resume().unwrap(), full_again);
    m.bus_mut().store32(0x10002070, 0).unwrap();
    assert_eq!(m.complete_session_network(&ingress, Event::Receive(vec![0x33])), Err(Error::StaleLease));
    let reset = m.save_session_resume().unwrap();
    let mut after = fixture(true); after.load_session_resume(&reset).unwrap();
    assert_eq!(after.save_session_resume().unwrap(), reset);
    evidence("critic-owned-full-before-ack.resume", &full);
    evidence("critic-owned-full-after-ack.resume", &full_again);
    evidence("critic-owned-reset.resume", &reset);
}

#[test]
fn critic_backend_wrappers_forward_maximum_and_reset() {
    use std::{cell::Cell, rc::Rc};
    use wasm_vm_core::dev::virtio::net::{NetBackend, NetBackendHandle, PcapBackend};
    struct Counted(Rc<Cell<u32>>);
    impl NetBackend for Counted {
        fn max_frame_bytes(&self) -> usize { 47 }
        fn reset(&mut self) { self.0.set(self.0.get() + 1); }
        fn tx(&mut self, _: &[u8]) {}
        fn rx(&mut self) -> Option<Vec<u8>> { None }
        fn rx_ready(&self) -> bool { false }
    }
    let count = Rc::new(Cell::new(0));
    let (mut switched, _) = NetBackendHandle::new(Box::new(PcapBackend::new(Counted(count.clone()))));
    assert_eq!(switched.max_frame_bytes(), 47); switched.reset();
    assert_eq!(count.get(), 1);
    let mut pcap = PcapBackend::new(Counted(count.clone()));
    assert_eq!(pcap.max_frame_bytes(), 47); pcap.reset();
    assert_eq!(count.get(), 2);
    let mut m = fixture(false); let mut opened = 0;
    let (_, lease) = m.open_session_network_provider(|| { opened += 1; 47 }).unwrap();
    assert_eq!(opened, 1); m.complete_session_network(&lease, Event::Pending(false)).unwrap();
    m.take_session_deliveries().unwrap();
    let r = fixture(true); assert!(matches!(r.open_session_network_provider(|| { opened += 1; 48 }), Err(Error::ReplayIngress)));
    assert_eq!(opened, 1);
}
