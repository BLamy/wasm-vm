# Coverage harness setup attempt

The first invocation of run_coverage.py exited before any command or test because
the host Python lacks stdlib tomllib. No product code or output was involved. The
producer now reads only Cargo.lock package identity/checksum string fields with
the standard re/json modules, then checks each selected registry dependency against
the frozen workspace lock. No package was installed or dependency changed.
