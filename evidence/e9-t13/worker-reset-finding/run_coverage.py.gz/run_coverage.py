from pathlib import Path
import hashlib,json,os,re,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed');harness=r/'harness'
prepared=json.loads((r/'coverage-preparation.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,expected in prepared['runtime_sources'].items():assert sha(r/'core'/name.removeprefix('crates/core/'))==expected,name
env={k:v for k,v in os.environ.items()if not k.startswith(('CARGO_','GIT_'))and k not in('RUSTFLAGS','RUSTDOCFLAGS','RUST_LOG','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER')}
env.update(RUSTUP_TOOLCHAIN='1.96.0',TMPDIR='/Volumes/e9-final-proof-ram/deploy-tmp/',RUSTFLAGS='-C instrument-coverage',LLVM_PROFILE_FILE=str(r/'profiles/normal-%p-%m.profraw'),E9_NETWORK_EVIDENCE=str(r/'recorded-normal'))
receipt={'head':prepared['head'],'started':time.time(),'runtime_sources':prepared['runtime_sources'],'gates':[]}
commands=[('format-harness',['rustfmt','--edition','2024',str(harness/'tests/critic.rs')]),('normal-native',['cargo','test','--offline','--manifest-path',str(harness/'Cargo.toml'),'--target-dir',str(r/'coverage-target'),'--test','critic','--','--nocapture','--skip','real_guest_counter_exchange_replays_offline_without_constructing_live_transport','--skip','real_connection_refusal_and_32_callback_schedules_replay_without_transport'])]
try:
 for name,command in commands:
    started=time.time()
    with(r/(name+'.log')).open('wb')as log:done=subprocess.run(command,cwd=repo,env=env,stdout=log,stderr=log,timeout=300)
    receipt['gates'].append({'name':name,'command':command,'exit_code':done.returncode,'seconds':time.time()-started});assert done.returncode==0,name
 def packages(path):
    return [dict((m[0],json.loads(m[1]))for m in re.findall(r'(?m)^(name|version|source|checksum) = ("[^"\n]*")$',block))for block in path.read_text().split('[[package]]')[1:]]
 original=packages(repo/'Cargo.lock');selected=packages(harness/'Cargo.lock')
 origins={(p['name'],p['version'],p.get('source')):p.get('checksum')for p in original}
 for p in selected:
    if 'source'in p:assert origins.get((p['name'],p['version'],p['source']))==p.get('checksum'),p
 receipt['selected_registry_packages']=len([p for p in selected if 'source'in p]);receipt['harness_lock_sha256']=sha(harness/'Cargo.lock');receipt['test_sha256']=sha(harness/'tests/critic.rs')
 for name,expected in prepared['runtime_sources'].items():assert sha(r/'core'/name.removeprefix('crates/core/'))==expected,name
finally:
 receipt['finished']=time.time();(r/'normal-coverage-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'gates':receipt['gates'],'selected_registry_packages':receipt.get('selected_registry_packages')}))
