from pathlib import Path
import hashlib,json,re,subprocess,shutil,time
r=Path(__file__).resolve().parent;repo=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed');head='e91c7af9bd8ec64c200c7d5a6687d9e4e124db12'
core=r/'core';harness=r/'harness';core.mkdir(exist_ok=False);(harness/'tests').mkdir(parents=True,exist_ok=False);(harness/'src').mkdir();(harness/'src/lib.rs').write_text('')
files=subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--','crates/core/src','crates/core/benches'],cwd=repo,text=True).splitlines();expected={}
for name in files:
    raw=subprocess.check_output(['git','show',head+':'+name],cwd=repo);p=core/name.removeprefix('crates/core/');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);expected[name]=hashlib.sha256(raw).hexdigest()
manifest=subprocess.check_output(['git','show',head+':crates/core/Cargo.toml'],cwd=repo,text=True);workspace=subprocess.check_output(['git','show',head+':Cargo.toml'],cwd=repo,text=True)
package=dict(re.findall(r'^([\w-]+)\s*=\s*(.+)$',workspace.split('[workspace.package]',1)[1].split('\n[',1)[0],re.M))
for key,value in package.items():manifest=re.sub('(?m)^'+re.escape(f'{key}.workspace = true')+'$',f'{key} = {value}',manifest)
(core/'Cargo.toml').write_text(manifest)
(harness/'Cargo.toml').write_text('[package]\nname="e9-t13-critic"\nversion="0.1.0"\nedition="2024"\n[workspace]\n[features]\nzicsr-stub=[]\n[dependencies]\nwasm-vm-core={path='+json.dumps(str(core))+',features=["trace","virgl-renderer"]}\n')
shutil.copyfile(repo/'Cargo.lock',harness/'Cargo.lock')
fixture=r/'network-guest.bin';fixture.write_bytes(subprocess.check_output(['git','show',head+':web/assets/e9-network-capture.bin'],cwd=repo))
test=subprocess.check_output(['git','show',head+':crates/core/tests/e9_network_capture.rs'],cwd=repo,text=True).replace('"../../../web/assets/e9-network-capture.bin"',json.dumps(str(fixture)))
test+='\n'+(r/'normal_format_tests.rs').read_text();(harness/'tests/critic.rs').write_text(test)
(r/'profiles').mkdir()
(r/'coverage-preparation.json').write_text(json.dumps({'head':head,'created':time.time(),'runtime_sources':expected,'test_sha256':hashlib.sha256(test.encode()).hexdigest(),'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'scope':'Scratch source copy authenticated from immutable Git; implementation unchanged. Three ordinary in-memory format/capacity/schedule/wrapper tests appended to the worker tests; no new injection demonstrator or external target.'},indent=2)+'\n')
print('Prepared',len(files),'exact runtime source/bench files; not executed yet.')
