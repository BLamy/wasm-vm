# Frozen repair predictions: e91c7af9bd8ec64c200c7d5a6687d9e4e124db12

Written after reading the complete runtime/test/browser/contract repair diff and
before opening this revision's final recordings. The new high-risk recording is
still running; no incomplete artifact is treated as a submission. The prior failed
prediction and its immutable packet remain unchanged. No runtime edits authorized.

- R1: the recorded eighth native regression will reject the four impossible
  represented-result states in both recording and replay, preserve the complete
  machine frame and an acquired callback lease, and accept/roundtrip the genuine
  all-four-terms state at cursor4 before guest RX dequeue. Its before-save RX used
  index remains0. The analogous built-browser refusal adds one case atomically.
- R2: checked minimum M=sent+receive.len+[link!=0]+[external_pending]<=cursor is
  preserved by every reachable transition. Base M=C=0. Accepted Send and Receive
  increase M by1 with cursor+1. Pending increases M by at most1. Link increases its
  indicator by at most1 and Closed/Failed clear pending. RX consumption and reset
  decrease M. TX allocation changes pending_tx and next_id together and does not
  enter M. All Failed/Cancelled acknowledgements and empty frames still consume
  their events. Repeated outcomes add slack. Checked-add overflow cannot be a
  reachable valid state. No Open-before-RX or factory-implies-Link rule is imposed.
- R3: authenticated happy-path complete frames, guest traces, exact positions,
  original counter actions, zero replay providers and all JIT CPU edge results
  will carry unchanged where code/dependencies/recording bytes are identical. The
  new final source/origin/assets must nevertheless authenticate at the new freeze.
- R4: normal valid format/event roundtrips (all Send results, all Link statuses,
  Pending false/true and Receive empty/max) and independent same-boundary schedules
  will survive save/restore/reset without false rejection. Direct tests will use
  only this repository's own in-memory VM and no external target.
- R5: exact frame/count/combined-owned bounds will hold with normal accepted
  callbacks, including mixed pending TX and queued RX. At4MiB owned bytes the next
  byte refuses atomically; acknowledging a pending TX frees exactly its bytes.
  Reset empties queues/revokes leases and preserves cumulative allocator/cursor.
  Delegating Pcap/Switchable adapters forward their maximum and reset calls.
- R6: scratch-only removal of private Rc incarnation equality will make an
  existing stale/foreign callback regression fail; restored exact source passes.
  Coverage will use instrumented copies authenticated against the frozen source,
  never implementation changes. Native source mappings plus actual V8/browser
  witnesses will classify each changed hunk; remaining non-executable or dominated
  branches receive explicit reasons.
- R7: a completed new24-gate independent cold packet is required before final
  re-verification. P13 remains NEEDS EVIDENCE until the repaired T13 bundle is
  published and the public browser recording is complete. No task status write
  or verified claim before the final worker submission/publication state is known.

The original bounded novel checkpoint attack is already recorded/refuted. No new
injection demonstrator or external target is required. Remaining work is ordinary
format/boundary correctness, instrumentation, sensitivity checks and evidence audit.
