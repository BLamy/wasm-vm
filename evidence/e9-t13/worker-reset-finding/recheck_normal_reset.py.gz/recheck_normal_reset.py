from pathlib import Path
import hashlib,json,os,subprocess,time,shutil
r=Path(__file__).resolve().parent;repo=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed');h=r/'harness'
saved=r/'normal-first-attempt';saved.mkdir(exist_ok=False)
for source in[r/'normal-native.log',r/'normal-coverage-receipt.json',h/'tests/critic.rs']:shutil.copyfile(source,saved/source.name)
source=(h/'tests/critic.rs').read_text();needle='    assert_eq!(after.save_session_resume().unwrap(), reset);'
assert source.count(needle)==1
source=source.replace(needle,'''    let after_frame = after.save_session_resume().unwrap();
    evidence("critic-owned-full-before-ack.resume", &full);
    evidence("critic-owned-full-after-ack.resume", &full_again);
    evidence("critic-owned-reset.resume", &reset);
    evidence("critic-owned-reset-restored.resume", &after_frame);
    assert!(after_frame == reset, "normal reset checkpoint must roundtrip byte-for-byte");''')
(h/'tests/critic.rs').write_text(source)
env={k:v for k,v in os.environ.items()if not k.startswith(('CARGO_','GIT_'))and k not in('RUSTFLAGS','RUSTDOCFLAGS','RUST_LOG','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER')}
env.update(RUSTUP_TOOLCHAIN='1.96.0',TMPDIR='/Volumes/e9-final-proof-ram/deploy-tmp/',RUSTFLAGS='-C instrument-coverage',LLVM_PROFILE_FILE=str(r/'profiles/reset-%p-%m.profraw'))
command=['cargo','test','--offline','--manifest-path',str(h/'Cargo.toml'),'--target-dir',str(r/'coverage-target'),'--test','critic','critic_combined_owned_capacity_frees_exactly_the_acknowledged_tx_bytes','--','--nocapture']
receipt={'head':'e91c7af9bd8ec64c200c7d5a6687d9e4e124db12','command':command,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'started':time.time(),'runs':[]}
for label in['first','recheck']:
    env['E9_NETWORK_EVIDENCE']=str(r/('recorded-reset-'+label))
    with(r/('normal-reset-'+label+'.log')).open('wb')as log:result=subprocess.run(command,cwd=repo,env=env,stdout=log,stderr=log,timeout=300)
    receipt['runs'].append({'label':label,'exit_code':result.returncode})
receipt['finished']=time.time();(r/'normal-reset-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(receipt['runs'])
