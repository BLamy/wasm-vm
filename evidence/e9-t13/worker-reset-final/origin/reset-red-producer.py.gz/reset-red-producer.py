from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path.cwd();m=Path('/Volumes/e9-final-proof-ram');out=m/'e9-t13-normal-reset-red';out.mkdir(exist_ok=False)
source=root/'crates/core/tests/e9_network_capture.rs'
oldsource=m/'cold-source-e9-t13-e91c7af9bd8e'
oldtarget=m/'cold-target-e9-t13-e91c7af9bd8e'
rlib=oldtarget/'debug/deps/libwasm_vm_core-ae3fa3a83363b55a.rlib'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
proof=json.loads((m/'cold-proof-e9-t13-e91c7af9bd8e-retry/report.json').read_text())
assert proof['status']=='passed'and proof['head']=='e91c7af9bd8ec64c200c7d5a6687d9e4e124db12'
assert sha(oldsource/'crates/core/src/lib.rs')==proof['source_sha256']['crates/core/src/lib.rs']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=oldsource,text=True).strip()==proof['head']
(out/'regression.rs').write_bytes(source.read_bytes())
cmd=['rustc','--edition=2024','--test',str(source),'-L','dependency='+str(oldtarget/'debug/deps'),'--extern','wasm_vm_core='+str(rlib),'-o',str(out/'regression-old-runtime')]
env=os.environ.copy();env['TMPDIR']=str(m/'deploy-tmp')+'/'
with(out/'build.log').open('wb')as f:subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
with(out/'red.log').open('wb')as f:r=subprocess.run([str(out/'regression-old-runtime'),'--exact','normal_reset_checkpoint_roundtrips_and_resumes_without_polling','--nocapture'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==101
assert 'normal reset checkpoint changed on restore mode=false q=1' in(out/'red.log').read_text()
receipt={'old_runtime':proof['head'],'old_core_rlib_sha256':sha(rlib),'frozen_old_core_source_sha256':sha(oldsource/'crates/core/src/lib.rs'),'source_sha256':sha(out/'regression.rs'),'compile':cmd,'red_exit':r.returncode,'red_log_sha256':sha(out/'red.log'),'binary_sha256':sha(out/'regression-old-runtime'),'time':time.time(),'scope':'Ordinary worker reset/checkpoint regression linked to authenticated pre-repair core; this is not a retry of the stopped independent capacity test.'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'expected_red_exit':r.returncode,'receipt_sha256':sha(out/'receipt.json')}))
