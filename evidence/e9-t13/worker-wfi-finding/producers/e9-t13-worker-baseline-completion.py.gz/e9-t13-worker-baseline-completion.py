from pathlib import Path
import json,hashlib,subprocess,shutil,gzip,time
repo=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
before=Path('/Volumes/e9-final-proof-ram/e9-t13-worker-coverage-baseline')
out=Path('/Volumes/e9-final-proof-ram/e9-t13-worker-coverage-baseline-completion');out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((before/'report.json').read_text());assert old['status']=='failed'and old['failure']=='worker-guest-oracle'
assert [x['exit_code']for x in old['commands']]==[0,0,1]
binary=out/'profile-object';shutil.copyfile(old['executable']['path'],binary);assert sha(binary)==old['executable']['sha256']
llvm=Path('/Users/blamy/.rustup/toolchains/1.96.0-aarch64-apple-darwin/lib/rustlib/aarch64-apple-darwin/bin')
env=dict(__import__('os').environ,TMPDIR='/Volumes/e9-final-proof-ram/deploy-tmp/')
profiles=sorted((before/'profiles').glob('*.profraw'));assert profiles
commands=[]
def run(name,command):
 with(out/(name+'.log')).open('wb')as f:r=subprocess.run(command,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
 commands.append({'name':name,'command':command,'exit_code':r.returncode});assert r.returncode==0,name
run('merge',[str(llvm/'llvm-profdata'),'merge','-sparse',*[str(p)for p in profiles],'-o',str(out/'worker.profdata')])
run('coverage',[str(llvm/'llvm-cov'),'export',str(binary),'-instr-profile='+str(out/'worker.profdata'),'-format=lcov'])
view=out/'oracle-view';view.mkdir()
links=[]
for p in sorted((before/'native').iterdir()):
 if p.is_file():
  (view/p.name).symlink_to(p);links.append({'name':p.name,'path':str(p),'sha256':sha(p),'role':'new ordinary worker recording'})
held=Path('/Volumes/e9-final-proof-ram/cold-proof-e9-t13-04f628dd02a0/native')
for target in (5000,5001,5002):
 for q in (31,1,8,4096):
  p=held/f'jit-network-target{target}-q{q}.resume';assert p.is_file();(view/p.name).symlink_to(p);links.append({'name':p.name,'path':str(p),'sha256':sha(p),'role':'explicitly carried unchanged frozen04f actual-JIT recording; not rerun here'})
run('guest-oracle-with-disclosed-held-jit',['python3','-B','tools/verify/e9-network-capture-files.py','--directory',str(view)])
r={'kind':'Additive completion of ordinary worker component coverage; no independent verdict','created':time.time(),'head':old['head'],'runtime':old['runtime'],'original_failed_attempt':str(before/'report.json'),'original_failed_attempt_sha256':sha(before/'report.json'),'failure_explanation':'The combined existing oracle requires 12 separate actual-JIT frames. The nine worker regressions passed. The original failed report/log remain unaltered. This additive view explicitly carries the 12 unchanged frozen04f JIT inputs; it does not label them freshly executed.','binary':{'path':str(binary),'sha256':sha(binary)},'profiles':[{'path':str(p),'sha256':sha(p)}for p in profiles],'commands':commands,'oracle_inputs':links,'runtime_sources':old['runtime_sources'],'test_source_sha256':old['test_source_sha256'],'status':'passed'}
(out/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'commands':commands,'report':str(out/'report.json')},indent=2))
