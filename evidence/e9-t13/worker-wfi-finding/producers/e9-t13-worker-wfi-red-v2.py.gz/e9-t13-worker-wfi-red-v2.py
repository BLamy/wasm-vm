from pathlib import Path
import json,os,subprocess,hashlib,time
repo=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
out=Path('/Volumes/e9-final-proof-ram/e9-t13-worker-wfi-red-v2');out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads(Path('/Volumes/e9-final-proof-ram/e9-t13-worker-coverage-baseline/report.json').read_text())
for n,h in old['runtime_sources'].items():assert sha(repo/n)==h,n
test=repo/'crates/core/tests/e9_network_components.rs'
env={k:v for k,v in os.environ.items()if not k.startswith(('CARGO_','GIT_'))and k not in('RUSTFLAGS','RUSTDOCFLAGS','RUST_LOG','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER')}
env.update(RUSTUP_TOOLCHAIN='1.96.0',TMPDIR='/Volumes/e9-final-proof-ram/deploy-tmp/',CARGO_TARGET_DIR='/Volumes/e9-t11-cold-scratch/e9-t13-worker-coverage-target',CARGO_INCREMENTAL='0',RUSTFLAGS='-C instrument-coverage',LLVM_PROFILE_FILE=str(out/'wfi-red-%p-%m.profraw'),E9_NETWORK_EVIDENCE=str(out/'native'))
subprocess.run(['rustfmt','--edition','2024',str(test)],env=env,check=True)
(out/'regression.rs').write_bytes(test.read_bytes())
(out/'prediction.json').write_text(json.dumps({'created':time.time(),'prediction':'Owned external_pending=true must suppress idle fast-forward: after two transitions both WFI and following ADDI retire, mtime=2 not1000000. Frozen04f appears to consult only generic clock.external_pending, so the ordinary pending=true branch is predicted to fail retired delta2 vs1. Guest-TX matrix and complete Record/Replay witnesses are part of the same ordinary regression.'},indent=2)+'\n')
command=['cargo','test','--locked','--offline','-p','wasm-vm-core','--features','trace,virgl-renderer','--test','e9_network_components','owned_external_pending_and_guest_tx_gate_wfi_idle_advance','--','--nocapture']
start=time.time()
with(out/'red.log').open('wb')as f:r=subprocess.run(command,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
bins=[p for p in Path(env['CARGO_TARGET_DIR']).glob('debug/deps/e9_network_components-*')if p.is_file()and p.suffix not in('.d','.o')]
binary=max(bins,key=lambda p:p.stat().st_mtime_ns)
(out/'old-runtime-test-object').write_bytes(binary.read_bytes())
report={'kind':'Worker ordinary semantic regression, not independent verification','runtime':'04f628dd02a0bf57331682e05607829e25a0ca46','head':old['head'],'test_sha256':sha(test),'runtime_sources':old['runtime_sources'],'command':command,'exit_code':r.returncode,'seconds':time.time()-start,'binary_sha256':sha(out/'old-runtime-test-object'),'scope':'New worker WFI/owned-pending regression. No stopped independent critic execution is retried.'}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'exit_code':r.returncode,'report':str(out/'report.json'),'binary_sha256':report['binary_sha256']}))
assert r.returncode==101
