from pathlib import Path
import os,subprocess,json,time,hashlib
repo=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
out=Path('/Volumes/e9-final-proof-ram/e9-t13-worker-coverage-baseline')
target=Path('/Volumes/e9-t11-cold-scratch/e9-t13-worker-coverage-target')
out.mkdir(exist_ok=False);target.mkdir(exist_ok=False);(out/'profiles').mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
runtime='04f628dd02a0bf57331682e05607829e25a0ca46'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=repo)
names=subprocess.check_output(['git','ls-tree','-r','--name-only',runtime,'--','crates/core/src','crates/core/Cargo.toml','Cargo.toml','Cargo.lock'],cwd=repo,text=True).splitlines()
sources={}
for name in names:
 raw=subprocess.check_output(['git','show',runtime+':'+name],cwd=repo);assert (repo/name).read_bytes()==raw,name;sources[name]=hashlib.sha256(raw).hexdigest()
env={k:v for k,v in os.environ.items()if not k.startswith(('CARGO_','GIT_'))and k not in('RUSTFLAGS','RUSTDOCFLAGS','RUST_LOG','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER')}
env.update(RUSTUP_TOOLCHAIN='1.96.0',TMPDIR='/Volumes/e9-final-proof-ram/deploy-tmp/',CARGO_TARGET_DIR=str(target),CARGO_INCREMENTAL='0',CARGO_TERM_COLOR='never',GIT_OPTIONAL_LOCKS='0',RUSTFLAGS='-C instrument-coverage',LLVM_PROFILE_FILE=str(out/'profiles/worker-%p-%m.profraw'),E9_NETWORK_EVIDENCE=str(out/'native'))
report={'kind':'Ordinary worker regression coverage, not independent verification','head':head,'runtime':runtime,'started':time.time(),'runtime_sources':sources,'test_source_sha256':sha(repo/'crates/core/tests/e9_network_capture.rs'),'commands':[],'scope':'Existing nine worker network regressions only; does not execute the stopped independent critic harness or satisfy its remaining charter.'}
(out/'prediction.json').write_text(json.dumps({'created':time.time(),'prediction':'The existing nine worker regressions pass and retain guest/frame assertions on unchanged 04f628 runtime; coverage records actual changed-line execution. Limits absent from these ordinary cases remain evidence gaps. No independent verdict follows.'},indent=2)+'\n')
def run(name,cmd,timeout=900):
 with(out/(name+'.log')).open('wb')as f:
  start=time.time();r=subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 report['commands'].append({'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.time()-start});(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');assert r.returncode==0,name
 return out/(name+'.log')
try:
 log=run('compile-worker-regressions',['cargo','test','--locked','--offline','-p','wasm-vm-core','--features','trace,virgl-renderer','--test','e9_network_capture','--no-run','--message-format=json'])
 exe=None
 for line in log.read_text().splitlines():
  if not line.startswith('{'):continue
  try:d=json.loads(line)
  except ValueError:continue
  if d.get('reason')=='compiler-artifact'and d.get('target',{}).get('name')=='e9_network_capture'and d.get('executable'):exe=d['executable']
 assert exe
 report['executable']={'path':exe,'sha256':sha(Path(exe))}
 run('worker-regressions',[exe,'--nocapture'])
 run('worker-guest-oracle',['python3','-B','tools/verify/e9-network-capture-files.py','--directory',str(out/'native')])
 llvm=Path('/Users/blamy/.rustup/toolchains/1.96.0-aarch64-apple-darwin/lib/rustlib/aarch64-apple-darwin/bin')
 profiles=sorted((out/'profiles').glob('*.profraw'));assert profiles
 run('merge-worker-profiles',[str(llvm/'llvm-profdata'),'merge','-sparse',*[str(p)for p in profiles],'-o',str(out/'worker.profdata')])
 run('export-worker-coverage',[str(llvm/'llvm-cov'),'export',exe,'-instr-profile='+str(out/'worker.profdata'),'-format=lcov'])
 for name,digest in sources.items():assert sha(repo/name)==digest,name
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=repo)
 report['status']='passed'
except BaseException as e:
 report['status']='failed';report['failure']=str(e);raise
finally:
 report['finished']=time.time();report['files']=[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(out.rglob('*'))if p.is_file()and p!=out/'report.json'];(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'commands':report['commands'],'report':str(out/'report.json')},indent=2))
