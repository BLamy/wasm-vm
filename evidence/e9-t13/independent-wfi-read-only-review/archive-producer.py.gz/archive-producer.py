from pathlib import Path
import json,hashlib,gzip,time,subprocess
repo=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
origin=Path('/Volumes/e9-final-proof-ram/t13-critic-main/wfi-read-only-followup')
out=repo/'evidence/e9-t13/independent-wfi-read-only-review'
out.mkdir(parents=True,exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
raw_provenance=(origin/'provenance.json').read_bytes()
assert sha(raw_provenance)=='8ed07112038ca59d96d4284dd3d857e5ab46f33c589a8f7a9c5a2223555f0873'
source=json.loads(raw_provenance)
records=[]
def keep(path,name,expected=None):
 raw=path.read_bytes()
 if expected is not None: assert sha(raw)==expected,str(path)
 compressed=gzip.compress(raw,compresslevel=9,mtime=0)
 target=out/(name+'.gz')
 target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(compressed)
 assert gzip.decompress(target.read_bytes())==raw
 records.append({'original_path':str(path),'artifact':str(target.relative_to(out)),'size':len(raw),'sha256':sha(raw),'gzip_size':len(compressed),'gzip_sha256':sha(compressed)})
for i,item in enumerate(source['inputs']):
 keep(Path(item['path']),f"inputs/{i:02d}-{Path(item['path']).name}",item['sha256'])
for item in source['artifacts']:
 keep(Path(item['path']),'assessment/'+Path(item['path']).name,item['sha256'])
keep(origin/'provenance.json','assessment/provenance.json',sha(raw_provenance))
keep(repo/'tasks/epic-9-session-time-travel/E9-T13-network-capture.md','boundary/task-at-review.md')
keep(Path(__file__),'archive-producer.py')
manifest={
 'kind':'Lossless worker preservation of separate critic WFI read-only follow-up; no verification verdict',
 'task':'E9-T13','created':time.time(),'assessment_author':'/root/verify_e9_t12',
 'frozen_runtime':source['scope']['frozen_runtime'],
 'previous_runtime':source['scope']['base'],
 'repository_head_at_review':source['scope']['metadata_head'],
 'assessment_provenance_sha256':sha(raw_provenance),
 'restrictions':source['restrictions'],'remaining_gaps':source['remaining'],
 'entries':records
}
p=out/'provenance.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
(out/'README.md').write_text(
 '# Partial independent WFI read-only assessment\n\n'
 'This packet preserves the separate critic authored follow-up over 19 changed files and 39 textual hunks at frozen runtime 2f2aa7. It is **not a verification verdict**. Saved WFI predictions hold; the additional worker recordings answer narrow G1–G8 requests with explicit scope and dominance waivers. G9 independent execution/sensitivity/suite disposition and P13 live publication/public-browser evidence remain unfinished.\n\n'
 'Read assessment/assessment.md.gz and its detailed JSON alongside the original assessment provenance. The critic authenticated 923 primary entries, 199 red entries, 37 source hashes, 180 matching supplementary artifacts and 32 unchanged prior HELD artifacts. No VM, test or producer execution occurred in this follow-up. No stopped execution was retried and no alternate model/session was used. The worker only authenticated and compressed these existing files. All originals are retained losslessly; each source path, digest and compressed digest is inventoried.\n')
for entry in records:
 packed=(out/entry['artifact']).read_bytes()
 assert sha(packed)==entry['gzip_sha256']
 assert sha(gzip.decompress(packed))==entry['sha256']
result={'packet':str(p),'sha256':sha(p.read_bytes()),'entries':len(records),'gzip_bytes':sum(x['gzip_size'] for x in records)}
Path('/Volumes/e9-final-proof-ram/e9-t13-preserve-wfi-read-only-review-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
