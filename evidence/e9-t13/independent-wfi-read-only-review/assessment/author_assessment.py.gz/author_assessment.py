"""Author an incremental assessment from saved-data decoding; no VM execution."""
from pathlib import Path
import hashlib, json, re, subprocess, time

out = Path(__file__).resolve().parent
repo = Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
main = Path('/Volumes/e9-t13-wfi-cold/cold-proof-e9-t13-2f2aa7aba484')
supp = Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-native-line-proof')
base = '04f628dd02a0bf57331682e05607829e25a0ca46'
head = '2f2aa7aba484f6954ca04358385828093e561b83'
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda name: json.loads((out/name).read_text())
observed = load('decoded-observations.json')
auth = load('authentication.json')
maps = load('native-line-map.json')
browser = load('browser-coverage.json')
points = load('component-and-format-points.json')

gaps = {
 'G1': {'classification':'SUPPORTED + justified waivers',
  'source':'session_network.rs:119–142,180–208,289–331; session_clock.rs:625–628; lib.rs:3344–3350,6504–6509; session_network/codec.rs:132–135',
  'evidence':'New native component tests: pending_tx_capacity…, allocator_and_cursor_exhaustion…, exact_owned_byte_budget…. Saved tx-capacity-valid.resume has IDs1–256; the exact-owned control has65 queued RX frames totalling4194304 bytes. Stop records retain transition1040/cursor0 and transition1025/cursor68 respectively, with no retirement after refusal. Supplement new8 counters: broker return/latch122/183/190, clock628=4, run-stop6507=4, snapshot mapping3345–3347=6, codec fatal134=6. Main and supplement artifacts match.',
  'waiver':'The sent increment cannot overflow after the cursor increment succeeds: admitted sent<=cursor; cursor==u64::MAX refuses first; otherwise sent<u64::MAX. The backend TX frame-size guard is dominated on the qualified real descriptor path by NetDevice applying max_frame_bytes before calling tx. Positive arithmetic-line counts alone are not used as overflow proof.',
  'remaining':'No further narrow G1 worker recording requested by this inspection. G9 remains separate.'},
 'G2': {'classification':'SUPPORTED',
  'source':'session_clock.rs:648–650; session_network.rs:220–223; lib.rs:4788–4792',
  'evidence':'All four native and four built-browser WFI cases satisfy the source-first CPU/clock/trace predictions, with exact restored Replay matches. New8 owned getter count8; clock650 count6953, idle fast-forward651–657 count4. These figures are backed by the four concrete pending/control states, rather than treated as branch coverage by themselves.',
  'waiver':'The pre-existing generic pending-control boundary is carried; no unrelated GPU idle policy or full Linux scheduling requirement is added.',
  'remaining':'No further narrow G2 worker recording requested by this inspection.'},
 'G3': {'classification':'SUPPORTED + justified scope waiver',
  'source':'session_network.rs:238–246; lib.rs:1621–1652; e9_network_components.rs:231–268',
  'evidence':'ordinary_installation_refusals_preserve_the_complete_original_machine passes in main/supplement. Exact source assertions compare full before/after checkpoints for duplicate ownership, an existing live NIC, and installation after execution; corresponding retained frames and executed test lines are indexed.',
  'waiver':'The extra slot-vector-shape disjunct at244 is outside the qualified standard assembly: enable_virtio_slots creates the fixed platform slot count and leaves slot1 empty before NIC installation. This is a scope waiver for that assembly, not a claim about arbitrary caller-modified device handles or a demand to fabricate topology.',
  'remaining':'No further narrow G3 worker recording requested for the qualified assembly.'},
 'G4': {'classification':'SUPPORTED',
  'source':'crates/wasm/src/session_network.rs:49–59; generated wasm_vm_wasm.js:2087–2104',
  'evidence':'Source-exact V8 networkCursor count8. Raw components/wide-cursor.resume decodes cursor/clock sequence9007199254740999; the saved actual call returns that exact decimal. The inactive call refuses Inactive, and the component source records full-state identity. Cursor2 is also read after two real outcomes.',
  'waiver':'Generated GC fallback plumbing retains the prior explicit-free waiver.',
  'remaining':'No further narrow G4 worker recording requested.'},
 'G5': {'classification':'SUPPORTED + carried waiver',
  'source':'session_network.rs:289–308,347–408; e9_network_components.rs:270–330',
  'evidence':'wrong_mode_queued_common_work_and_unfinished_replays_refuse_atomically passes. New8 counters296/359/381/408 each1; correct-cursor TX/RX/external finish returns306 count3, with raw admitted checkpoint controls and exact-state assertions. The queued common delivery is drained normally and the recording lease then completes. Existing9 covers changed/stale intents and ordinary completion.',
  'waiver':'Non-Before return385 retains the synchronous quiescent-call waiver: public callbacks cannot interleave halfway through the borrowed guest transition. The ordinal/sequence overflow fixtures separately force their two checked-add outcomes.',
  'remaining':'No further narrow G5 worker recording requested.'},
 'G6': {'classification':'SUPPORTED + justified waivers',
  'source':'session_network/codec.rs:80–123,159–217; e9_network_components.rs:333–556',
  'evidence':'Retained wire fixtures independently decode the outer cap, bad magic and reserved Send/Link/kind cases; new8 return counts82/86/94/111/119 each1. Saved checkpoint inputs encode duplicate IDs[1,1], sent>allocator, sent+pending=3>next2, u64::MAX+1 allocator overflow, u64::MAX+1 represented overflow, outer cap and4194305-byte ownership. Their source assertions prove refusal before full-state/incarnation mutation and then successful use of the prior lease. Exact4MiB and two-pending controls roundtrip. New8 rejection counts165=1,187=1,196=1,215=4; existing9 supplies earlier malformed fields/conservation states.',
  'waiver':'Reader offset-add overflow is dominated by outer bounds and bounded/fixed reads. Continuation-only233 has no independent action. Native supplemental Cancelled decode line93 is zero, but actual built-Wasm input result2, returned cancelled status, durable bytes and matching replay prove the same unchanged decoder outcome; prior independent unchanged event-form evidence also carries. Counter positivity is not substituted for the distinct overflow fixtures.',
  'remaining':'No further narrow G6 worker recording requested.'},
 'G7': {'classification':'SUPPORTED',
  'source':'web/session-network.js:6–49; tools/verify/e9-network-component-browser.mjs:45–128',
  'evidence':'All session-network V8 ranges are positive in the source-exact main recording. Two real failed/cancelled guest sends plus failed links reopen actual CAS-backed manifests with statuses[failed,failed] and[cancelled,failed], codes61/62 and sequence2. Independent saved-data decoding reconstructs each wire header+payload from8 objects and checks1024 actual PC/opcodes; original/replay frames and traces match. Reserved-kind refusal and a throwing factory free the actual native lease once, with cursor0 and unchanged checkpoint.',
  'waiver':'The intentionally uncalled replay-provider closure remains positive zero-egress evidence, not an untested callback requirement.',
  'remaining':'No further narrow G7 worker recording requested.'},
 'G8': {'classification':'SUPPORTED',
  'source':'web/session-inputs.js:61,93,138–139; tools/verify/e9-network-component-browser.mjs:129–168',
  'evidence':'The wrong-policy call reports frozen network policy and performs0 puts/0 publications. Absent-source stage/read calls report the adapter refusal and preserve manifests/end; raw manifests retain sequence0/no events and sequence2 respectively. Source-exact need() rejection is now reached. Zero ternary-alternative ranges on93/138 are unrelated alternatives, not the exercised channel20 network branch.',
  'waiver':'Absent optional networkPolicy is allowed when no network receipt is admitted; the required refusals occur at stage/read. No blanket refusal of an intentionally network-free prefix is required.',
  'remaining':'No further narrow G8 worker recording requested.'},
 'G9': {'classification':'NEEDS EVIDENCE',
  'source':'AGENTS.md independent verifier charter',
  'evidence':'The earlier independent execution was stopped by automatic security review. This task only inspects source and existing recordings; it does not retry that execution or run a sensitivity test.',
  'waiver':'None. Worker regressions and this partial read-only audit do not replace independent execution/sensitivity/suite disposition.',
  'remaining':'Complete the unfinished independent charter only when the external restriction changes. No alternate model/session substitution is authorized.'},
 'P13': {'classification':'NEEDS EVIDENCE',
  'source':'AGENTS.md worker3a(c); current E9-T13 task claim',
  'evidence':'No T13 publication/public-browser recording is provided. A prepared bundle is not a deployment.',
  'waiver':'None. Earlier runtime candidates were withdrawn; T12 public evidence cannot prove2f2aa7.',
  'remaining':'After official human Cloudflare authorization, publish the exact frozen2f2 bundle and retain authenticated public assets plus the required public-browser proof.'},
}

def readable(text):
    for word in ('The','New','new','Existing','existing','IDs','totalling','count','clock','mapping','latch','fatal','Cursor','cursor','sequence','preserved','codes','each','return','returns','counts','next','Exact','exact','result','line','checks','and'):
        text=re.sub(r'\b'+word+r'(?=[0-9])',word+' ',text)
    return text
for gap in gaps.values():
    for key in ('evidence','waiver','remaining'):
        gap[key]=readable(gap[key])

diff = subprocess.check_output(['git','diff','--unified=0',base,head,'--','.',':(exclude)evidence/**'],cwd=repo)
files=[];current=None
for line in diff.decode().splitlines():
    if line.startswith('diff --git '):
        name=line.split(' b/',1)[1]
        if name=='crates/core/src/session_clock.rs':kind='SUPPORTED';reason='New owned-pending predicate has explicit W1/W2 native/browser states and new8 counters.'
        elif name.startswith(('crates/core/tests/','tools/verify/')):kind='SUPPORTED + harness waivers';reason='Authenticated active producer/test path and its saved raw outputs; type declarations, failure-report and evidence-write plumbing have no separate guest action.'
        elif name.endswith(('network-capture-probe.js','main.js')):kind='SUPPORTED + presentation/cleanup waivers';reason='Source-exact built V8 and saved WFI/click outcomes support the added path; the changed success label is presentation.'
        else:kind='WAIVED representation';reason='Declarative contract/docs/task/build-binding/cache-version or generated Wasm representation; authenticated source/build bundle and selected gate evidence. Underlying source/API proof is tracked separately.'
        current={'path':name,'classification':kind,'reason':reason,'hunks':[]};files.append(current)
    elif line.startswith('@@'):current['hunks'].append(line)
    elif line.startswith('Binary files '):current['binary']=True
assert len(files)==19
assessment={'kind':'Bounded incremental read-only sufficiency assessment; NO task verdict',
 'scope':{'base':base,'frozen_runtime':head,'metadata_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'changed_files':19,'text_hunks':sum(len(f['hunks'])for f in files),'source_diff_sha256':sha(diff)},
 'predictions':{'W1':'HELD in saved recordings','W2':'HELD in saved recordings','W3':'HELD as historical old-runtime worker fault; repaired states agree','H1':'HELD for authenticated identities/32 unchanged artifacts'},
 'gaps':gaps,'delta_files':files,
 'no_new_execution':'Only source and saved data were read/hashed/decoded. No VM/test/producer launched, stopped execution retried, sensitivity test run, alternate model/session used, or shared file/index/status/queue/commit changed.',
 'remaining':['G9','P13']}
(out/'assessment.json').write_text(json.dumps(assessment,indent=2)+'\n')

lines=['# T13 WFI incremental read-only assessment','',
 '**No task verification verdict.** The new saved WFI states support the repair, and the additional worker recordings answer the narrow G1–G8 component requests with the qualifications below. G9 and P13 remain unresolved. No independent execution is claimed.','',
 f'Source-first scope: `{base}..{head}`; metadata HEAD `{assessment["scope"]["metadata_head"]}`. The runtime change is the owned-network pending predicate in session_clock.rs:650. The19-file delta has{assessment["scope"]["text_hunks"]} textual hunks; exact headers/classifications are in assessment.json. The prior52-file/156-hunk ledger remains unchanged and is incrementally qualified here.','',
 '## Authentication and attribution','',
 'Authenticated923 primary gzip/original pairs,199 preserved red packet entries,508 main and195 supplementary inventory files, and37 frozen source hashes against Git and the current source. All original primary/red paths were checked when present; availability is explicit per entry in authentication.json. All25 main worker commands and all supplementary commands passed. The cold receipt records an initially empty compiler target and no inherited node_modules, with independent source/refs/index and disclosed read-only Git object sharing. This is recorded worker environment evidence, not a newly executed cold clone.','',
 'Independently compared all180 supplementary native overlaps with the main cold recording: every byte matches. The two existing9/new8 objects and their raw profiles/exports remain separately attributable. Twelve JIT inputs are explicitly carried from the SAME frozen main recording and are not labelled rerun. Thirty-two previously HELD happy-path/JIT artifacts remain byte-identical; source/dependency changes are confined to the reviewed predicate/harness/declarative delta. This carries the prior concrete arithmetic/frame/trace observations, not a blanket claim that all runtime source is unchanged.','',
 '## Predicted WFI states','',
 'Predictions were saved before new reports/frames/traces/coverage were opened. Native cases execute at0x80060000 for two transitions. With pending work: WFI+ADDI retire, x1=1, PC0x80060008. Without it: only WFI retires, x1=0, PC0x80060004, mtime1000000. All saved original/restored pairs match completely.','',
 '| Native guest TX | Pending | Begin retired | End retired | End mtime | x1 |','| --- | --- | --- | --- | --- | --- |']
for row in observed['native_wfi']:
    lines.append(f'| {row["name"].split("-pending")[0].split("tx")[1]} | {row["name"].split("pending")[1]} | {row["before"]["retired"]} | {row["after"]["retired"]} | {row["after"]["mtime"]} | {row["after"]["x1"]} |')
lines+=['','| Built-browser guest TX | Pending | End transition | End retired | End mtime | x1 |','| --- | --- | --- | --- | --- | --- |']
for row in observed['browser_wfi']:
    s=row['final'];lines.append(f'| {row["guest_tx"]} | {row["pending_work"]} | {s["transition"]} | {s["retired"]} | {s["mtime"]} | {s["x1"]} |')
native_pending=observed['native_wfi'][1];browser_pending=observed['browser_wfi'][1]
lines+=['',f'Concrete native point: `{main}/native/components/wfi-txfalse-pendingtrue.trace:1–2`, SHA256 `{native_pending["trace_sha256"]}`: WFI then ADDI. Final frame SHA256 `{native_pending["after"]["sha256"]}`. Browser point: `{main}/browser/idle/txfalse-pendingtrue-original.trace:5–6`, SHA256 `{browser_pending["trace_sha256"]}`: the same WFI/ADDI after the four timer-setup words. All case/frame/trace digests and decoded fields are retained in decoded-observations.json.','',
 'The preserved04f628 red pending=true frame is transition2/retired1/mtime1000000/x1=0, SHA256 b599fcbe8b7af9d2b864244d97b5696bcc17e32b02591f43bd3b59c753cfe16e. Its trace:1 contains only WFI, SHA256191bc787c07d102613e354ab7a1ed05fb58e8c5f8bae8be4ced9e5e2daf4bf6c. The corrected worker-v2 receipt remains exit101. The earlier budget-target harness failure is separately preserved, not used as this semantic observation.','',
 '## G1–G8 evidence ledger','']
for name,gap in gaps.items():
    lines+=['### '+name+' — '+gap['classification'],'','Source: '+gap['source']+'.','',gap['evidence'],'','Qualification: '+gap['waiver'],'','Remaining: '+gap['remaining'],'']
lines+=['## New delta accounting','', '| File | Hunk starts | Classification |','| --- | --- | --- |']
for f in files:
    starts=[re.search(r'\+(\d+)',h)[1]for h in f['hunks']]
    lines.append('| `'+f['path']+'` | '+(','.join(starts)if starts else'binary')+' | '+f['classification']+' |')
lines+=['','The new common-clock predicate is supported by actual instruction/clock states and source-exact instrumented counts. The full test/helper additions have concrete saved outputs and recorded assertions. Documentation/contracts, generated task data, build fingerprints and cache versions carry explicit representation waivers. No unseen branch is declared dead, and a positive line count is not treated as proof of every logical outcome.','',
 '## Saved evidence points','',
 f'- Main `{main}/report.json`, SHA256 eee0a035d1157b4db78e3ab6bb6a661c2963758876506f171adc9a91c59d2bcb.','- Primary packet evidence/e9-t13/worker-wfi-final/provenance.json, SHA256 dcfded2590ed9e6471f8d6cd9c07f4c93523f5c1e34d97a2b7d0b3a5aafeedf9.',
 f'- Supplement `{supp}/report.json`, SHA25622149b1059c2bb7dd62b3047c7be8a30d96be79171fa7c517babcaa83603e72c. Counts are preserved by file/line/source/object in native-line-map.json; the full original lcov exports/raw profiles/objects are authenticated by its inventory.',
 f'- `{main}/browser/report.json` components and probe data. Source-exact V8 ranges are preserved in browser-coverage.json; actual CAS/event/manifest and1024-opcode observations are in component-and-format-points.json.',
 '- Previous authored ledger SHA256708d74ad9e6978448191c316792c591022cc4dacf8810e5a567576ee163b5827; provenance SHA256a7fd8006df45744730cb6d489f5ee64b37b97694886e17836769353af9108ba2. It is preserved unchanged.','',
 '## Limits','',
 'This bounded follow-up found no new contradiction in the inspected repair/component recordings. It does not close G9, issue a full verified verdict, change shared metadata, authorize a dependent task or establish publication. No further narrow G1–G8 worker recording is requested by this partial inspection.','',
 'Automatic security review stopped the earlier independent execution for possible cybersecurity risk. That execution was not retried, and independent execution/sensitivity/suite disposition remain unfinished. Required T13 Cloudflare publication and authenticated public-browser evidence are also absent (P13).','']
text='\n'.join(lines)
for word in ('the','prior','and','at','with','for','from','same','all','All','Authenticated','compared','delta','has','Count','cursor','transition','retired','mtime','PC','x','SHA256'):
    if word=='x':continue
    text=re.sub(r'\b'+word+r'(?=[0-9])',word+' ',text)
text=text.replace('owning0','owning 0').replace('in2','in 2').replace('by8','by 8')
text=readable(text).replace('pairs,199','pairs, 199').replace('entries,508','entries, 508').replace('exit101','exit 101').replace('65 queued','65 queued')
(out/'assessment.md').write_text(text)

inputs=[repo/'evidence/e9-t13/worker-wfi-final/provenance.json',repo/'evidence/e9-t13/worker-wfi-finding/provenance.json',main/'report.json',supp/'report.json',main/'browser/report.json',main/'browser/probe.json',main/'browser/javascript-coverage.json',main/'network-and-session-native.log',supp/'e9_network_capture-coverage.log',supp/'e9_network_components-coverage.log',supp/'e9_network_capture.log',supp/'e9_network_components.log',out.parent/'partial-sufficiency-ledger/changed-hunk-ledger.md',out.parent/'partial-sufficiency-ledger/provenance.json']
def rows(paths):return [{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in paths]
provenance={'kind':'T13 bounded WFI/G1–G8 read-only incremental assessment; no verdict','created':time.time(),'scope':assessment['scope'],'restrictions':assessment['no_new_execution'],'remaining':['G9','P13'],'inputs':rows(inputs),'artifacts':rows([p for p in sorted(out.iterdir())if p.is_file()and p.name!='provenance.json']),'shared_status':subprocess.check_output(['git','status','--short'],cwd=repo,text=True),'shared_changes_by_this_review':False,'status_note':'Parent-owned external blocker evidence appeared untracked during final QA; this review did not edit or stage it. Initial authoring stopped at a clean-tree assertion; the assertion was corrected to record external status rather than misrepresent it.'}
(out/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(json.dumps({'assessment_sha256':sha((out/'assessment.md').read_bytes()),'json_sha256':sha((out/'assessment.json').read_bytes()),'provenance_sha256':sha((out/'provenance.json').read_bytes()),'files':len(files),'hunks':assessment['scope']['text_hunks'],'artifacts':len(provenance['artifacts']),'remaining':provenance['remaining']}))
