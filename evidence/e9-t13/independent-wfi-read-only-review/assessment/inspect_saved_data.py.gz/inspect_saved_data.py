"""Read/hash/decode existing T13 files only. Never launches a VM or producer."""
from pathlib import Path
import gzip, hashlib, json, re, struct, subprocess

OUT = Path(__file__).resolve().parent
REPO = Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
MAIN = Path('/Volumes/e9-t13-wfi-cold/cold-proof-e9-t13-2f2aa7aba484')
SUPP = Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-native-line-proof')
OLD = Path('/Volumes/e9-final-proof-ram/cold-proof-e9-t13-04f628dd02a0')
HEAD = '2f2aa7aba484f6954ca04358385828093e561b83'
sha = lambda b: hashlib.sha256(b).hexdigest()
u32 = lambda b, at=0: struct.unpack_from('<I', b, at)[0]
u64 = lambda b, at=0: struct.unpack_from('<Q', b, at)[0]

def file_sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def saved(path):
    return json.loads(Path(path).read_text())

def frame(raw):
    assert raw[:12] == b'WVMRESU1\1\0\0\0'
    sections = {}; at = 84
    while at < len(raw):
        tag, size = struct.unpack_from('<II', raw, at); at += 8
        assert tag not in sections and at + size <= len(raw)
        sections[tag] = raw[at:at + size]; at += size
    assert at == len(raw)
    c = sections[18]; n = sections[21]
    assert c[:8] == b'WVCLK001' and n[:8] == b'WVNETS01'
    transition, retired, ordinal, sequence, ticket = struct.unpack_from('<QQQQQ', c, 12)
    next_id, cursor, sent = struct.unpack_from('<QQQ', n, 8)
    return {'sha256': sha(raw), 'transition': transition, 'retired': retired,
            'ordinal': ordinal, 'sequence': sequence, 'ticket': ticket,
            'next_id': next_id, 'cursor': cursor, 'sent': sent,
            'pc': u64(sections[1]), 'x1': u64(sections[1], 8),
            'mtime': u64(sections[3]), 'link': n[32], 'external_pending': bool(n[33]),
            'code': u32(n, 36), 'sections': sections}

def compact(value):
    return {k: v for k, v in value.items() if k != 'sections'}

def owned(n):
    at = 40; count = u32(n, at); at += 4; ids = []; sizes = []
    for _ in range(count):
        ident = u64(n, at); size = u32(n, at + 8); at += 12
        assert at + size <= len(n); ids.append(ident); sizes.append(size); at += size
    receive = u32(n, at); at += 4
    for _ in range(receive):
        size = u32(n, at); at += 4
        assert at + size <= len(n); sizes.append(size); at += size
    assert at == len(n)
    return {'pending': count, 'receive': receive, 'ids': ids, 'owned': sum(sizes)}

expected = {
    MAIN/'report.json': 'eee0a035d1157b4db78e3ab6bb6a661c2963758876506f171adc9a91c59d2bcb',
    Path('/Volumes/e9-t13-wfi-cold/cold-worker-e9-t13-2f2aa7aba484/receipt.json'): 'b1221d5fb5063b5e4ead4c72ca451400b27ad4ed56960ac3082e9d84f0d040c9',
    SUPP/'report.json': '22149b1059c2bb7dd62b3047c7be8a30d96be79171fa7c517babcaa83603e72c',
    REPO/'evidence/e9-t13/worker-wfi-final/provenance.json': 'dcfded2590ed9e6471f8d6cd9c07f4c93523f5c1e34d97a2b7d0b3a5aafeedf9',
    REPO/'evidence/e9-t13/worker-wfi-finding/provenance.json': '76825ff1d7eb7e6a40ad32065da8775dbac20dd4f43f2b63a6afb7b8dd07fde5',
}
auth = {'reports': [], 'primary': [], 'red': [], 'inventories': [], 'sources': [], 'failures': []}
for path, digest in expected.items():
    actual = file_sha(path); assert actual == digest, str(path)
    auth['reports'].append({'path': str(path), 'sha256': actual})
packet = saved(REPO/'evidence/e9-t13/worker-wfi-final/provenance.json')
for row in packet['files']:
    path = REPO/'evidence/e9-t13/worker-wfi-final'/row['gzip']
    compressed = path.read_bytes(); raw = gzip.decompress(compressed)
    assert len(compressed) == row['gzip_bytes'] and sha(compressed) == row['gzip_sha256']
    assert len(raw) == row['original_bytes'] and sha(raw) == row['original_sha256']
    original = Path(row['original_path'])
    present = original.is_file()
    if present:
        assert original.stat().st_size == len(raw) and file_sha(original) == row['original_sha256']
    auth['primary'].append({'path': row['path'], 'sha256': row['original_sha256'], 'original_present': present})
red_packet = saved(REPO/'evidence/e9-t13/worker-wfi-finding/provenance.json')
for row in red_packet['entries']:
    path = REPO/'evidence/e9-t13/worker-wfi-finding'/row['artifact']
    compressed = path.read_bytes(); raw = gzip.decompress(compressed)
    assert len(compressed) == row['gzip_size'] and sha(compressed) == row['gzip_sha256']
    assert len(raw) == row['size'] and sha(raw) == row['sha256']
    original = Path(row['original']); present = original.is_file()
    if present:
        assert original.stat().st_size == len(raw) and file_sha(original) == row['sha256']
    auth['red'].append({'path': row['artifact'], 'sha256': row['sha256'], 'original_present': present})
main_report = saved(MAIN/'report.json'); supp_report = saved(SUPP/'report.json')
for root, report in ((MAIN, main_report), (SUPP, supp_report)):
    for row in report['files']:
        path = root/row['path']
        assert path.stat().st_size == row['bytes'] and file_sha(path) == row['sha256']
    auth['inventories'].append({'path': str(root/'report.json'), 'files': len(report['files'])})
for name, digest in main_report['source_sha256'].items():
    frozen = subprocess.check_output(['git', 'show', HEAD+':'+name], cwd=REPO)
    assert sha(frozen) == digest and file_sha(REPO/name) == digest
    auth['sources'].append({'path': name, 'sha256': digest})
for row in supp_report['explicitly_carried_jit_inputs']:
    assert file_sha(Path(row['path'])) == row['sha256']
auth['supplement_jit_carried'] = supp_report['explicitly_carried_jit_inputs']
auth['supplement_main_comparisons'] = supp_report['comparison_with_main_cold_recording']
auth['commands'] = {'main': main_report['commands'], 'supplement': supp_report['commands']}
(OUT/'authentication.json').write_text(json.dumps(auth, indent=2)+'\n')

observed = {'native_wfi': [], 'browser_wfi': [], 'red_wfi': [], 'capacity': [], 'browser_components': {}, 'carried_artifacts': []}
for tx in (False, True):
    for pending in (False, True):
        name = f'wfi-tx{str(tx).lower()}-pending{str(pending).lower()}'
        root = MAIN/'native/components'; before_raw = (root/(name+'-before.resume')).read_bytes()
        after_raw = (root/(name+'-after.resume')).read_bytes(); replay = (root/(name+'-replayed.resume')).read_bytes()
        before = frame(before_raw); after = frame(after_raw); trace = (root/(name+'.trace')).read_bytes()
        assert replay == after_raw and (root/(name+'-replayed.trace')).read_bytes() == trace
        assert after['transition'] == before['transition']+2
        assert after['retired'] == before['retired']+(2 if pending else 1)
        assert after['mtime'] == (before['retired']+2 if pending else 1000000)
        assert after['x1'] == int(pending) and after['pc'] == 0x80060000+(8 if pending else 4)
        lines = trace.decode().splitlines(); words = [0x10500073, 0x00108093] if pending else [0x10500073]
        for i, (line, word) in enumerate(zip(lines, words)):
            m = re.match(r'core 0: 0x([0-9a-f]+) \(0x([0-9a-f]+)\)', line)
            assert m and int(m[1],16) == 0x80060000+i*4 and int(m[2],16) == word
        assert len(lines) == len(words)
        observed['native_wfi'].append({'name': name, 'before': compact(before), 'after': compact(after),
            'owned_before': owned(before['sections'][21]), 'trace_sha256': sha(trace),
            'trace_lines': lines, 'record_replay_equal': True})
probe = saved(MAIN/'browser/probe.json'); browser_report = saved(MAIN/'browser/report.json')
def artifact(row):
    raw = (MAIN/'browser'/row['file']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']; return raw
for row in probe['idle']:
    start = 390 if row['guestTx'] else 0; pending = row['pendingWork']
    raw = artifact(row['frame']); value = frame(raw); paused = frame(artifact(row['paused']))
    trace = artifact(row['trace']); assert artifact(row['replayFrame']) == raw and artifact(row['replayTrace']) == trace
    retired = 6 if pending else 5
    assert (value['transition'], value['retired'], value['mtime'], value['x1'], value['pc']) == (start+6,start+retired,start+6 if pending else 1000000,int(pending),0x80000000+(start+retired)*4)
    words = [0x020041b7,0x000f42b7,0x24028293,0x0051b023,0x10500073,0x00108093][:retired]
    lines = trace.decode().splitlines(); assert len(lines) == retired
    for i,(line,word) in enumerate(zip(lines,words)):
        m = re.match(r'core 0: 0x([0-9a-f]+) \(0x([0-9a-f]+)\)',line)
        assert m and int(m[1],16) == 0x80000000+(start+i)*4 and int(m[2],16) == word
    observed['browser_wfi'].append({'guest_tx':row['guestTx'],'pending_work':pending,'paused':compact(paused),'final':compact(value),'owned_before':owned(paused['sections'][21]),'trace_sha256':sha(trace),'trace_lines':lines,'record_replay_equal':True})
red = Path('/Volumes/e9-final-proof-ram/e9-t13-worker-wfi-red-v2/native/components')
for pending in (False, True):
    name = 'wfi-txfalse-pending'+str(pending).lower()
    value = frame((red/(name+'-after.resume')).read_bytes()); trace = (red/(name+'.trace')).read_bytes()
    assert (value['transition'],value['retired'],value['mtime'],value['x1'],value['pc']) == (2,1,1000000,0,0x80060004)
    observed['red_wfi'].append({'name':name,'state':compact(value),'trace_sha256':sha(trace),'trace_lines':trace.decode().splitlines()})
for name in ('tx-capacity-valid.resume','owned-four-mebibytes-valid.resume','owned-one-byte-over-invalid.resume','codec-valid-two-pending-control.resume','cursor-u64-max.resume'):
    raw=(MAIN/'native/components'/name).read_bytes(); value=frame(raw)
    observed['capacity'].append({'name':name,'state':compact(value),'owned':owned(value['sections'][21])})
components=browser_report['checks']['components']
for row in components['outcomes']:
    raw=artifact(row['final']);value=frame(raw);trace=artifact(row['trace'])
    assert artifact(row['replay'])==raw and artifact(row['replayTrace'])==trace
    assert (value['transition'],value['retired'],value['cursor'],value['sent'],value['link'],value['code']) == (1024,1024,2,1,3,60+row['result'])
    assert row['statuses']==(['failed','failed']if row['result']==1 else['cancelled','failed'])
wide=frame(artifact(components['wideCursor']['frame']))
assert str(wide['cursor'])==components['wideCursor']['value']=='9007199254740999'
assert components['factory']['factories']==components['factory']['frees']==1
assert components['policyPublication']['puts']==components['policyPublication']['publications']==0
observed['browser_components']=components
observed['browser_components']['decoded_wide_cursor']=compact(wide)
for group, names in [('native',['initial.resume','pending.resume','final.resume','original.trace']),('browser',['initial.resume','pending.resume','final.resume','original.trace'])]:
    for name in names:
        a=OLD/group/name;b=MAIN/group/name
        observed['carried_artifacts'].append({'old':str(a),'new':str(b),'same':file_sha(a)==file_sha(b),'old_sha256':file_sha(a),'new_sha256':file_sha(b)})
for target in (5000,5001,5002):
    for q in (31,1,8,4096):
        for group, name in [('native',f'jit-network-target{target}-q{q}.resume'),('browser',f'jit/target{target}-q{q}.resume.gz')]:
            a=OLD/group/name;b=MAIN/group/name
            x=a.read_bytes();y=b.read_bytes()
            if name.endswith('.gz'):x=gzip.decompress(x);y=gzip.decompress(y)
            observed['carried_artifacts'].append({'old':str(a),'new':str(b),'same':x==y,'old_sha256':sha(x),'new_sha256':sha(y)})
(OUT/'decoded-observations.json').write_text(json.dumps(observed,indent=2)+'\n')

coverage={}
for target in ('e9_network_capture','e9_network_components'):
    maps={}; current=None
    for line in (SUPP/(target+'-coverage.log')).read_text().splitlines():
        if line.startswith('SF:'):
            name=line[3:];marker='/crates/core/'
            current='crates/core/'+name.split(marker,1)[1]if marker in name else None
            if current:maps.setdefault(current,{})
        elif current and line.startswith('DA:'):
            number,count=line[3:].split(',')[:2];maps[current][int(number)]=int(count)
    coverage[target]={}
    for name in ('crates/core/src/session_network.rs','crates/core/src/session_network/codec.rs','crates/core/src/session_clock.rs','crates/core/src/lib.rs','crates/core/tests/e9_network_components.rs','crates/core/tests/e9_network_capture.rs'):
        counts=maps.get(name,{});source=(REPO/name).read_text().splitlines()
        coverage[target][name]=[{'line':n,'count':count,'source':source[n-1]}for n,count in sorted(counts.items())if n<=len(source)]
(OUT/'native-line-map.json').write_text(json.dumps(coverage,indent=2)+'\n')
print(json.dumps({'primary':len(auth['primary']),'red':len(auth['red']),'inventories':auth['inventories'],'sources':len(auth['sources']),'native_wfi':len(observed['native_wfi']),'browser_wfi':len(observed['browser_wfi']),'carried_same':sum(x['same']for x in observed['carried_artifacts']),'carried_total':len(observed['carried_artifacts']),'main_commands':len(main_report['commands']),'main_failed':[x['name']for x in main_report['commands']if x['exit_code']!=0]}))
