from pathlib import Path
import os,subprocess,json,time
repo=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
out=Path('/Volumes/e9-final-proof-ram/e9-t13-wfi-web-precheck');out.mkdir(exist_ok=False)
env={k:v for k,v in os.environ.items()if not k.startswith(('CARGO_','GIT_'))and k not in('RUSTFLAGS','RUSTDOCFLAGS','RUST_LOG','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','LLVM_PROFILE_FILE')}
env.update(RUSTUP_TOOLCHAIN='1.96.0',TMPDIR='/Volumes/e9-final-proof-ram/deploy-tmp/',TMPPREFIX='/Volumes/e9-final-proof-ram/deploy-tmp/zsh',PATH='/Volumes/e9-t11-cold-scratch/bash-tools/bin:'+os.environ['PATH'],XDG_CACHE_HOME='/Volumes/e9-build-scratch/e9-toolchain-cache',npm_config_cache='/Volumes/e9-final-proof-ram/e9-t13-npm-cache',npm_config_offline='true')
report={'kind':'Worker precheck, not frozen submission','commands':[],'started':time.time()}
commands=[
 ('format-components',['rustfmt','--edition','2024','crates/core/tests/e9_network_components.rs']),
 ('format',['cargo','fmt','--all','--check']),
 ('component-clippy',['cargo','clippy','--locked','--offline','-p','wasm-vm-core','--test','e9_network_components','--features','trace,virgl-renderer','--','-D','warnings']),
 ('web-dist',['make','web-dist'])]
try:
 for name,cmd in commands:
  start=time.time()
  with(out/(name+'.log')).open('wb')as f:r=subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
  report['commands'].append({'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.time()-start});(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');assert r.returncode==0,name
 report['status']='passed'
except BaseException as e:report.update(status='failed',failure=str(e));raise
finally:
 report['finished']=time.time();(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
