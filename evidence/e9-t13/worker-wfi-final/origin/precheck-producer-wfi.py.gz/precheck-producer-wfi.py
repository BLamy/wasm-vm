from pathlib import Path
import os,json,subprocess,time,hashlib
repo=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
out=Path('/Volumes/e9-final-proof-ram/e9-t13-worker-wfi-green');out.mkdir(exist_ok=False)
env={k:v for k,v in os.environ.items()if not k.startswith(('CARGO_','GIT_'))and k not in('RUSTFLAGS','RUSTDOCFLAGS','RUST_LOG','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER')}
env.update(RUSTUP_TOOLCHAIN='1.96.0',TMPDIR='/Volumes/e9-final-proof-ram/deploy-tmp/',CARGO_TARGET_DIR='/Volumes/e9-t11-cold-scratch/e9-t13-worker-coverage-target',CARGO_INCREMENTAL='0',RUSTFLAGS='-C instrument-coverage',LLVM_PROFILE_FILE=str(out/'green-%p-%m.profraw'),E9_NETWORK_EVIDENCE=str(out/'native'))
cmd=['cargo','test','--locked','--offline','-p','wasm-vm-core','--features','trace,virgl-renderer','--test','e9_network_components','--test','e9_network_capture','--','--nocapture']
subprocess.run(['rustfmt','--edition','2024','crates/core/src/session_clock.rs','crates/core/tests/e9_network_components.rs'],cwd=repo,env=env,check=True)
start=time.time()
with(out/'green.log').open('wb')as f:r=subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
report={'kind':'Worker self-validation of WFI repair, not frozen submission or independent verdict','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'command':cmd,'exit_code':r.returncode,'seconds':time.time()-start,'source_sha256':{n:hashlib.sha256((repo/n).read_bytes()).hexdigest()for n in['crates/core/src/session_clock.rs','crates/core/tests/e9_network_components.rs']}}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));assert r.returncode==0
