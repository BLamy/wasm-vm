from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,time
head='2f2aa7aba484f6954ca04358385828093e561b83'
mount=Path('/Volumes/e9-final-proof-ram');cold=Path('/Volumes/e9-t13-wfi-cold')
proof=cold/('cold-proof-e9-t13-'+head[:12]);wrapper=cold/('cold-worker-e9-t13-'+head[:12]);line=cold/'e9-t13-wfi-native-line-proof'
for p in[proof/'report.json',wrapper/'receipt.json',line/'report.json']:assert json.loads(p.read_text())['status']=='passed',str(p)
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'])
full=cold/'e9-t13-wfi-full-archive';primary=Path('evidence/e9-t13/worker-wfi-final')
full.mkdir(exist_ok=False);primary.mkdir(parents=True,exist_ok=False)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for block in iter(lambda:f.read(1<<20),b''):h.update(block)
 return h.hexdigest()
files=[]
def archive(src,name):
 dest=full/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True)
 with src.open('rb')as source,dest.open('wb')as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6)as target:shutil.copyfileobj(source,target,1<<20)
 h=hashlib.sha256();n=0
 with gzip.open(dest,'rb')as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b);n+=len(b)
 assert n==src.stat().st_size and h.hexdigest()==sha(src)
 entry={'original_path':str(src.resolve()),'path':name,'original_bytes':n,'original_sha256':h.hexdigest(),'gzip':str(dest.relative_to(full)),'gzip_bytes':dest.stat().st_size,'gzip_sha256':sha(dest)};files.append(entry)
 if 'chromium-profile'not in Path(name).parts:
  other=primary/entry['gzip'];other.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dest,other);assert sha(other)==entry['gzip_sha256']
for p in sorted(proof.rglob('*')):
 if p.is_file()and not p.is_symlink():archive(p,'acceptance/'+str(p.relative_to(proof)))
for p in sorted(line.rglob('*')):
 if p.is_file()and not p.is_symlink():archive(p,'supplemental-native-lines/'+str(p.relative_to(line)))
inputs={
 'cold-wrapper-receipt.json':wrapper/'receipt.json','cold-wrapper-commands.log':wrapper/'commands.log',
 'cold-producer.py':mount/'e9-t13-wfi-frozen-cold-wrapper.py','cold-wrapper.log':mount/'e9-t13-wfi-frozen-cold-wrapper.log',
 'native-line-producer.py':mount/'e9-t13-wfi-native-line-proof.py',
 'bash-runtime-receipt.json':Path('/Volumes/e9-t11-cold-scratch/bash-tools/receipt.json'),
 'emsdk-ram-copy-receipt.json':Path('/Volumes/e9-t11-cold-scratch/e9-t12-emsdk-ram-copy.json'),
 'new-ram-receipt.json':mount/'e9-t13-wfi-new-ram.json','new-ram-format.log':mount/'e9-t13-wfi-new-ram-format.log',
 'incremental-cache-release.json':mount/'e9-t13-wfi-incremental-cache-release.json',
 'independent-service-block.json':mount/'e9-t13-independent-service-block.json',
 'publication-prepared-receipt.json':mount/'e9-t13-wfi-publication-prepared/receipt.json',
 'publication-preparation-producer.py':mount/'e9-t13-prepare-wfi-publication.py',
 'freeze-dist.json':mount/'e9-t13-wfi-freeze-dist.json','freeze-dist.log':mount/'e9-t13-wfi-freeze-dist.log',
 'browser-precheck-command.json':mount/'e9-t13-wfi-browser-precheck-v1-command.json',
 'browser-precheck.log':mount/'e9-t13-wfi-browser-precheck-v1.log',
 'browser-precheck-first-oracle-failure.log':mount/'e9-t13-wfi-browser-precheck-v1-oracle.log',
 'browser-precheck-corrected-oracle.log':mount/'e9-t13-wfi-browser-precheck-v1-oracle-v2.log',
 'precheck-producer-wfi.py':mount/'e9-t13-worker-wfi-green.py',
 'precheck-producer-components-first.py':mount/'e9-t13-components-precheck-v1.py',
 'precheck-producer-components-corrected.py':mount/'e9-t13-components-precheck-v2.py',
 'precheck-producer-web.py':mount/'e9-t13-wfi-web-precheck.py',
 'precheck-producer-browser.py':mount/'e9-t13-wfi-browser-precheck-v1.py',
 'precheck-existing-directory-guard.log':mount/'e9-t13-wfi-web-precheck-repeat-disallowed.log',
}
for folder in ['worker-final','verifier-refutation','worker-conservation-final','worker-reset-finding','worker-reset-final','independent-read-only-review','worker-wfi-finding','external-proof-blockers']:
 inputs['previous-'+folder+'-manifest.json']=Path('evidence/e9-t13')/folder/'provenance.json'
for name,src in inputs.items():archive(src,'origin/'+name)
groups={
 'precheck-wfi-green':mount/'e9-t13-worker-wfi-green',
 'precheck-components-first':mount/'e9-t13-components-precheck-v1',
 'precheck-components-corrected':mount/'e9-t13-components-precheck-v2',
 'precheck-web':mount/'e9-t13-wfi-web-precheck',
 'precheck-browser':mount/'e9-t13-wfi-browser-precheck-v1'}
for label,root in groups.items():
 for p in sorted(root.rglob('*')):
  if p.is_file()and not p.is_symlink():archive(p,'worker-loop/'+label+'/'+str(p.relative_to(root)))
diff=mount/'e9-t13-wfi-runtime-diff.patch'
with diff.open('wb')as f:subprocess.run(['git','diff','--binary','76cc2c8dc1df4b17572bf09c73618e10ad848d63',head,'--','.',':(exclude)evidence'],stdout=f,check=True)
archive(diff,'origin/runtime-diff.patch');archive(Path(__file__),'origin/archive-producer.py')
common={'task':'E9-T13','status':'passed','head':head,'created':time.time(),'producer_sha256':sha(Path(__file__)),'original_recording':str(proof),'original_wrapper':str(wrapper),
 'scope':'Lossless exact frozen25-command worker recording, full guest traces/frames, HTTP and independent transport witnesses, complete durable object graphs, Playwright traces/screenshots/coverage, WFI and ordinary component cases, and fresh compiler/source provenance. Supplemental instrumented existing9/new8 native runs have separately attributable profiles/objects and byte comparisons with the main cold recording; actual JIT input carry into their oracle is explicit and from the same frozen head. Worker-loop prechecks and original harness-only failures are retained for context, not substituted for frozen acceptance. Prior refutations/withdrawn recordings/read-only assessment remain immutable in their prior committed packets. No independent verdict is claimed; the stopped independent execution was not retried, and publication/account authorization remain external. No private authentication logs or credentials are archived.',
 'files':files,'original_bytes':sum(e['original_bytes']for e in files),'compressed_bytes':sum(e['gzip_bytes']for e in files)}
(full/'provenance.json').write_text(json.dumps(common,indent=2)+'\n');kept=[e for e in files if 'chromium-profile'not in Path(e['path']).parts]
(primary/'provenance.json').write_text(json.dumps({**common,'files':kept,'full_archive':str(full),'full_archive_provenance_sha256':sha(full/'provenance.json'),'deferred_derived_profiles':[e for e in files if e not in kept],
 'scope':common['scope']+' Derived fresh Chromium GPU profile/cache files are inventoried separately and retained as original/authenticated gzip bytes in the full archive; no claim relies on a private unexported database.',
 'primary_original_bytes':sum(e['original_bytes']for e in kept),'primary_compressed_bytes':sum(e['gzip_bytes']for e in kept)},indent=2)+'\n')
print(json.dumps({'primary':str(primary),'sha256':sha(primary/'provenance.json'),'files':len(kept),'gzip_bytes':sum(e['gzip_bytes']for e in kept),'full_archive_sha256':sha(full/'provenance.json')}))
