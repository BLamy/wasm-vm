from pathlib import Path
import os,subprocess,json,time,hashlib,shutil
repo=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
mount=Path('/Volumes/e9-t13-wfi-cold');head='2f2aa7aba484f6954ca04358385828093e561b83'
cold=mount/('cold-proof-e9-t13-'+head[:12]);accepted=json.loads((cold/'report.json').read_text());assert accepted['status']=='passed'and accepted['head']==head
out=mount/'e9-t13-wfi-native-line-proof';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=repo)
for n,h in accepted['source_sha256'].items():assert sha(repo/n)==h,n
env={k:v for k,v in os.environ.items()if not k.startswith(('CARGO_','GIT_'))and k not in('RUSTFLAGS','RUSTDOCFLAGS','RUST_LOG','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','LLVM_PROFILE_FILE')}
env.update(RUSTUP_TOOLCHAIN='1.96.0',TMPDIR='/Volumes/e9-final-proof-ram/deploy-tmp/',CARGO_TARGET_DIR='/Volumes/e9-t11-cold-scratch/e9-t13-worker-coverage-target',CARGO_INCREMENTAL='0',CARGO_TERM_COLOR='never',RUSTFLAGS='-C instrument-coverage',E9_NETWORK_EVIDENCE=str(out/'native'))
report={'kind':'Supplemental worker line proof of exact frozen source; not independent verification and not a second cold-compiler claim','head':head,'started':time.time(),'source_sha256':accepted['source_sha256'],'cold_report_sha256':sha(cold/'report.json'),'commands':[],'objects':{},'instrumentation':'-C instrument-coverage only; each existing9/new8 test binary has its own raw-profile directory and independently exported line counts.'}
def run(name,cmd,local_env=env):
 start=time.time()
 with(out/(name+'.log')).open('wb')as f:r=subprocess.run(cmd,cwd=repo,env=local_env,stdout=f,stderr=subprocess.STDOUT,timeout=900)
 report['commands'].append({'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.time()-start});(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');assert r.returncode==0,name
 return out/(name+'.log')
try:
 compile_env=dict(env,LLVM_PROFILE_FILE=str(out/'build-%p-%m.profraw'))
 log=run('compile',['cargo','test','--locked','--offline','-p','wasm-vm-core','--features','trace,virgl-renderer','--test','e9_network_capture','--test','e9_network_components','--no-run','--message-format=json'],compile_env)
 exes={}
 for line in log.read_text().splitlines():
  if not line.startswith('{'):continue
  try:d=json.loads(line)
  except ValueError:continue
  if d.get('reason')=='compiler-artifact'and d.get('executable')and d.get('target',{}).get('name')in('e9_network_capture','e9_network_components'):exes[d['target']['name']]=Path(d['executable'])
 assert len(exes)==2
 llvm=Path('/Users/blamy/.rustup/toolchains/1.96.0-aarch64-apple-darwin/lib/rustlib/aarch64-apple-darwin/bin')
 for name,exe in sorted(exes.items()):
  obj=out/('object-'+name);shutil.copy2(exe,obj);assert sha(obj)==sha(exe)
  profiles=out/(name+'-profiles');profiles.mkdir()
  report['objects'][name]={'path':str(obj),'sha256':sha(obj),'source_test_sha256':sha(repo/('crates/core/tests/'+name+'.rs'))}
  run(name,[str(obj),'--nocapture'],dict(env,LLVM_PROFILE_FILE=str(profiles/'worker-%p-%m.profraw')))
  raw=sorted(profiles.glob('*.profraw'));assert raw
  run(name+'-merge',[str(llvm/'llvm-profdata'),'merge','-sparse',*[str(p)for p in raw],'-o',str(out/(name+'.profdata'))])
  run(name+'-coverage',[str(llvm/'llvm-cov'),'export',str(obj),'-instr-profile='+str(out/(name+'.profdata')),'-format=lcov'])
 view=out/'oracle-view';view.mkdir();carried=[]
 for p in sorted((out/'native').rglob('*')):
  if p.is_file():
   dest=view/p.relative_to(out/'native');dest.parent.mkdir(parents=True,exist_ok=True);dest.symlink_to(p)
 for target in (5000,5001,5002):
  for q in (31,1,8,4096):
   p=cold/f'native/jit-network-target{target}-q{q}.resume';(view/p.name).symlink_to(p);carried.append({'path':str(p),'sha256':sha(p),'scope':'Actual JIT run from the successful main cold recording at the same frozen head; not rerun for this component line proof.'})
 run('guest-oracle',['python3','-B','tools/verify/e9-network-capture-files.py','--directory',str(view)])
 comparisons=[]
 for p in sorted((out/'native').rglob('*')):
  if p.is_file():
   other=cold/'native'/p.relative_to(out/'native')
   if other.is_file():comparisons.append({'path':str(p.relative_to(out/'native')),'profiled_sha256':sha(p),'cold_sha256':sha(other),'equal':sha(p)==sha(other)})
 assert comparisons and all(x['equal']for x in comparisons)
 report['comparison_with_main_cold_recording']=comparisons;report['explicitly_carried_jit_inputs']=carried
 for n,h in accepted['source_sha256'].items():assert sha(repo/n)==h,n
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=repo)
 report['status']='passed'
except BaseException as error:report.update(status='failed',failure=str(error));raise
finally:
 report['producer_sha256']=sha(Path(__file__));report['finished']=time.time();report['files']=[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(out.rglob('*'))if p.is_file()and not p.is_symlink()and p!=out/'report.json'];(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'report':str(out/'report.json'),'comparisons':len(report.get('comparison_with_main_cold_recording',[]))}))
