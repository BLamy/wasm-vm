from pathlib import Path
import os,subprocess,json,time
repo=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
log=Path('/Volumes/e9-final-proof-ram/e9-t13-wfi-browser-precheck-v1.log')
env={k:v for k,v in os.environ.items()if k not in('RUSTFLAGS','RUSTDOCFLAGS','RUST_LOG','LLVM_PROFILE_FILE')}
env.update(TMPDIR='/Volumes/e9-final-proof-ram/deploy-tmp/',CHROME='/Users/blamy/Library/Caches/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-mac-arm64/chrome-headless-shell')
cmd=['node','tools/verify/e9-network-capture-browser.mjs','--development','--probe-only','--output','/Volumes/e9-final-proof-ram/e9-t13-wfi-browser-precheck-v1']
start=time.time()
with log.open('wb')as f:r=subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
Path('/Volumes/e9-final-proof-ram/e9-t13-wfi-browser-precheck-v1-command.json').write_text(json.dumps({'kind':'Worker development precheck only; final built/cold proof pending','command':cmd,'exit_code':r.returncode,'seconds':time.time()-start},indent=2)+'\n')
print(json.dumps({'exit_code':r.returncode,'seconds':time.time()-start}))
