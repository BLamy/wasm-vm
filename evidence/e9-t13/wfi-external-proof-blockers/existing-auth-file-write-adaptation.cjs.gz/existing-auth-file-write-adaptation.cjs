'use strict';
// Preserve Wrangler's standard credential path and content. The full APFS volume
// rejects O_TRUNC; opening its existing file with O_RDWR permits the same update.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const original=fs.writeFileSync,auth=path.join(os.homedir(),'Library/Preferences/.wrangler/config/default.toml');
fs.writeFileSync=function(file,data,options){
 if(typeof file!=='string'||path.resolve(file)!==auth)return original.apply(this,arguments);
 const st=fs.lstatSync(auth);if(!st.isFile()||st.isSymbolicLink())throw Error('Expected existing regular Wrangler auth file');
 const encoding=typeof options==='string'?options:options?.encoding||'utf8';
 const bytes=Buffer.isBuffer(data)?data:Buffer.from(data,encoding);
 if(bytes.length>16384)throw Error('Unexpected authentication config length');
 const fd=fs.openSync(auth,fs.constants.O_RDWR);
 try{let done=0;while(done<bytes.length){const n=fs.writeSync(fd,bytes,done,bytes.length-done,done);if(n<=0)throw Error('Incomplete existing-file auth write');done+=n;}fs.ftruncateSync(fd,bytes.length);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
};
require('node:module').syncBuiltinESMExports();
