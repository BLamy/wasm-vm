from pathlib import Path
import hashlib,json,os,subprocess,time
m=Path('/Volumes/e9-final-proof-ram');h='e91c7af9bd8ec64c200c7d5a6687d9e4e124db12'
source=m/('cold-source-e9-t13-'+h[:12]);target=m/('cold-target-e9-t13-'+h[:12]);metadata=m/('cold-git-e9-t13-'+h[:12])
first=m/('cold-proof-e9-t13-'+h[:12]);original=m/('cold-worker-e9-t13-'+h[:12]);out=m/('cold-worker-e9-t13-'+h[:12]+'-retry');proof=m/('cold-proof-e9-t13-'+h[:12]+'-retry')
assert not out.exists() and not proof.exists();out.mkdir()
prior=json.loads((original/'receipt.json').read_text());r=json.loads((first/'report.json').read_text())
assert prior['head']==h and prior['status']=='failed' and r['head']==h and r['status']=='failed'
assert len(r['commands'])==13 and all(c['exit_code']==0 for c in r['commands'][:-1]) and r['commands'][-1]['name']=='browser-build'
assert 'ETIMEDOUT' in(first/'browser-build.log').read_text()
assert prior['compiler_storage']['initial_entries']==[] and prior['compiler_storage']['no_inherited_compiler_cache']
assert source.resolve()!=Path.cwd().resolve() and (source/'target').resolve()==target
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==h
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=source)
env={k:v for k,v in os.environ.items() if k not in('RUSTFLAGS','RUSTDOCFLAGS','RUST_LOG','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER') and not k.startswith(('CARGO_','GIT_','npm_config_'))}
env['PATH']='/Volumes/e9-t11-cold-scratch/bash-tools/bin:'+str(Path.home()/'.cargo/bin')+':/usr/bin:/bin:/usr/sbin:/sbin:'+env['PATH']
env.update(GIT_OPTIONAL_LOCKS='0',E9_NETWORK_EVIDENCE_DIR=str(proof),TMPDIR=str(m/'catalog-build-tmp')+'/',TMPPREFIX=str(m/'catalog-build-tmp/zsh'),XDG_CACHE_HOME='/Volumes/e9-build-scratch/e9-toolchain-cache',npm_config_cache=str(m/'e9-t13-npm-cache'),npm_config_offline='true',CHROME='/Users/blamy/Library/Caches/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-mac-arm64/chrome-headless-shell')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
report={'task':'E9-T13','head':h,'status':'running','source':str(source),'target':str(target),'git_metadata':str(metadata),'original_cold_wrapper':str(original/'receipt.json'),'original_cold_wrapper_sha256':sha(original/'receipt.json'),'original_failed_acceptance':str(first/'report.json'),'original_failed_acceptance_sha256':sha(first/'report.json'),'scope':'Repeat all24 prescribed gates after the original independent cold build passed its first12 gates but npm registry read timed out. Same pristine unchanged frozen source, own compiler cache built solely by the authenticated originally empty-target attempt. No external compiler cache or installed Node modules copied. npm ci uses exact lockfile integrities with the existing download-only cache in offline mode. The failed attempt is preserved, not overwritten.','started':time.time(),'commands':[]}
try:
 with(out/'commands.log').open('wb')as log:
  result=subprocess.run(['make','verify-E9-T13'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=7200)
 report['commands'].append({'command':['make','verify-E9-T13'],'cwd':str(source),'exit_code':result.returncode})
 assert result.returncode==0
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=source)
 final=json.loads((proof/'report.json').read_text());assert final['status']=='passed' and final['head']==h
 report['source_sha256']=final['source_sha256'];report['status']='passed'
except BaseException as error:report['status']='failed';report['failure']=str(error);raise
finally:
 report['finished']=time.time();report['producer_sha256']=sha(Path(__file__))
 report['files']=[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(out.rglob('*'))if p.is_file()and p!=out/'receipt.json']
 (out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
 print(report['status'],out,flush=True)
