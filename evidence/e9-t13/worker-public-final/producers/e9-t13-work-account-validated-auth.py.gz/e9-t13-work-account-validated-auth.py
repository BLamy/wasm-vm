from pathlib import Path
import os,json,subprocess,time
prefix=Path('/Volumes/e9-final-proof-ram/e9-t13-work-account-validated')
private=Path(str(prefix)+'-auth-private.log')
debug=Path(str(prefix)+'-auth-private-debug.log')
receipt=Path(str(prefix)+'-auth-result.json')
assert not private.exists() and not debug.exists() and not receipt.exists()
auth=Path('/Users/blamy/Library/Preferences/.wrangler/config/default.toml')
def metadata():
 s=auth.stat()
 return {'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'mode':oct(s.st_mode&0o777)}
before=metadata()
env=os.environ.copy()
env.update({'TMPDIR':'/Volumes/e9-final-proof-ram/deploy-tmp/',
 'NODE_OPTIONS':'--require=/Volumes/e9-final-proof-ram/wrangler-existing-auth-write.cjs',
 'WRANGLER_LOG_PATH':str(debug),'WRANGLER_SEND_METRICS':'false'})
cmd=['node','/Volumes/e9-t11-cold-scratch/e9-t12-npm-cache/_npx/32026684e21afda6/node_modules/wrangler/bin/wrangler.js','whoami']
fd=os.open(private,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'wb') as output:
 result=subprocess.run(cmd,env=env,stdout=output,stderr=subprocess.STDOUT)
if debug.exists(): debug.chmod(0o600)
raw=private.read_text(errors='replace').lower()
unauth=any(s in raw for s in ['not authenticated','not logged in','you are not logged','authentication error'])
authenticated=any(s in raw for s in ['you are logged in','account name','account id']) and not unauth and result.returncode==0
record={'task':'E9-T13','time':time.time(),'command':cmd,
 'exit_code':result.returncode,'unauthenticated_marker':unauth,'authenticated_marker':authenticated,
 'configured_api_token_present':bool(os.environ.get('CLOUDFLARE_API_TOKEN') or os.environ.get('CF_API_TOKEN')),
 'auth_file_before_metadata_only':before,'auth_file_after_metadata_only':metadata(),
 'scope':'Official account-status revalidation only; no login/device request or publication. Credential contents and private auth/debug output excluded.'}
receipt.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
