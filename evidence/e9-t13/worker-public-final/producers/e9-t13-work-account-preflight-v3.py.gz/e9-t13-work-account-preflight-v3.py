from pathlib import Path
import os,json,re,subprocess,time,hashlib
ram=Path('/Volumes/e9-final-proof-ram')
proof=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-corrected-account-v3')
proof.mkdir(exist_ok=False)
login=json.loads((ram/'e9-t13-work-account-validated-auth-result.json').read_text())
assert login['exit_code']==0 and login['authenticated_marker']
account=json.loads(Path('/Users/blamy/Documents/Codex/wasm-vm/.wrangler/cache/wrangler-account.json').read_text())['account']
private=ram/'e9-t13-corrected-target-projects-v3-private.log'
debug=ram/'e9-t13-corrected-target-projects-v3-private-debug.log'
assert not private.exists() and not debug.exists()
env=os.environ.copy()
env.update({'CLOUDFLARE_ACCOUNT_ID':account['id'],'TMPDIR':'/Volumes/e9-final-proof-ram/deploy-tmp/',
 'NODE_OPTIONS':'--require=/Volumes/e9-final-proof-ram/wrangler-existing-auth-write.cjs',
 'WRANGLER_LOG_PATH':str(debug),'WRANGLER_SEND_METRICS':'false','CI':'true'})
cmd=['node','/Volumes/e9-t11-cold-scratch/e9-t12-npm-cache/_npx/32026684e21afda6/node_modules/wrangler/bin/wrangler.js','pages','project','list','--json']
fd=os.open(private,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'wb')as f:r=subprocess.run(cmd,cwd='/Volumes/e9-final-proof-ram/e9-t13-wfi-publication-source',env=env,stdout=f,stderr=subprocess.STDOUT)
if debug.exists():debug.chmod(0o600)
s=re.sub(r'\x1b\[[0-9;]*m','',private.read_text(errors='replace'));rows=None
for i,c in enumerate(s):
 if c not in '[{':continue
 try:
  candidate,_=json.JSONDecoder().raw_decode(s[i:])
  if isinstance(candidate,list):rows=candidate;break
 except json.JSONDecodeError:pass
result={'task':'E9-T13','command':cmd,'time':time.time(),'account_id_sha256':hashlib.sha256(account['id'].encode()).hexdigest(),
 'account_source':'Repo saved project account, explicitly selected for this read-only query.',
 'exit_code':r.returncode,'parsed_project_list':rows is not None,
 'project_count':len(rows)if rows is not None else None,
 'target_present':any(x.get('Project Name')=='wasm-vm'for x in rows)if rows is not None else None,
 'api_error_codes':sorted(set(re.findall(r'\[code:\s*(\d+)\]',s))),
 'authentication_error':bool(re.search(r'authentication error|unauthorized|permission|forbidden',s,re.I)),
 'parsed_project_name_field':'Project Name','parser_correction':'Prior v2 account query succeeded; its checker used name instead of the actual CLI Project Name field. Both original result and this corrected fresh query are retained.','scope':'Official read-only access check; exact CLI JSON schema used; private account labels/identifiers and auth/debug output excluded.'}
p=proof/'project-availability.json';p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
