from pathlib import Path
import subprocess,os,json,time,hashlib,datetime
root=Path('/Volumes/e9-t13-wfi-cold/cold-source-e9-t13-2f2aa7aba484')
deployment=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-publication-v2/receipt.json')
d=json.loads(deployment.read_text())
assert d['status']=='published' and d['exit_code']==0 and d['head']=='2f2aa7aba484f6954ca04358385828093e561b83'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==d['head']
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=root,text=True)
out=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-public-browser')
assert not out.exists()
log=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-public-browser-run.log')
receipt=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-public-browser-run.json')
assert not log.exists() and not receipt.exists()
tmp=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-public-browser-tmp');tmp.mkdir(exist_ok=False)
chrome='/Users/blamy/Library/Caches/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-mac-arm64/chrome-headless-shell'
assert Path(chrome).is_file()
env=os.environ.copy();env.update({'CHROME':chrome,'TMPDIR':str(tmp)+'/'})
cmd=['node','tools/verify/e9-network-capture-browser.mjs','--url','https://wasm-vm.pages.dev/','--output',str(out)]
record={'task':'E9-T13','status':'running','head':d['head'],'command':cmd,
 'cwd':str(root),'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'deployment_receipt':str(deployment),'deployment_receipt_sha256':hashlib.sha256(deployment.read_bytes()).hexdigest(),
 'environment':{'CHROME':chrome,'TMPDIR':str(tmp)+'/'},
 'scope':'Actual production page and public asset authentication from the clean frozen worker checkout; required public browser currency, not an independent adversarial verifier run.'}
receipt.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':'running','command':cmd}),flush=True)
with log.open('xb')as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
record.update({'status':'passed'if r.returncode==0 else'failed','exit_code':r.returncode,
 'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':str(log),
 'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
report=out/'report.json'
if report.exists():
 record['report']=str(report);record['report_sha256']=hashlib.sha256(report.read_bytes()).hexdigest()
 p=json.loads(report.read_text());record['browser_status']=p['status'];record['browser_errors']=p['errors']
record['clean_source_after']=not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=root,text=True)
receipt.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
raise SystemExit(r.returncode)
