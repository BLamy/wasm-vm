from pathlib import Path
import urllib.request,urllib.error,urllib.parse,json,hashlib,datetime
sha=lambda b:hashlib.sha256(b).hexdigest()
original=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-public-assets')
spec_path=Path('/Volumes/e9-final-proof-ram/e9-t13-wfi-publication-prepared/receipt.json')
spec=json.loads(spec_path.read_text())
prior=json.loads((original/'report.json').read_text())
assert len(prior['assets'])==36
out=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-public-assets-complete');out.mkdir(exist_ok=False)
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):return None
opener=urllib.request.build_opener(NoRedirect())
rows=[]
for old in prior['assets']:
 row=dict(old)
 if old['status']=='passed':
  raw=(original/old['file']).read_bytes()
  assert sha(raw)==old['sha256']==spec['staged_files'][old['name']]['sha256']
  assert len(raw)==old['bytes']==spec['staged_files'][old['name']]['bytes']
  row.update({'evidence_root':str(original),'attribution':'Carried byte-identical prior response; not fetched again.'})
 else:
  assert old['name']=='app.html'and old['failure']=='HTTP Error 308: Permanent Redirect'
  url=old['url'];allowed=urllib.parse.urlsplit(url).netloc;hops=[]
  for n in range(5):
   request=urllib.request.Request(url,headers={'Cache-Control':'no-cache','User-Agent':'wasm-vm-E9-T13-public-asset-proof'})
   try:response=opener.open(request,timeout=30)
   except urllib.error.HTTPError as error:response=error
   with response:
    data=response.read();status=response.code
    headers={k:response.headers[k]for k in ['Date','ETag','Content-Type','Cache-Control','CF-Cache-Status','Age','Last-Modified','Content-Length','Location']if k in response.headers}
   hopfile=f"{old['origin']}/hop-{n}.bin";p=out/hopfile;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
   hops.append({'url':url,'http_status':status,'headers':headers,'body_file':hopfile,'bytes':len(data),'sha256':sha(data)})
   if status in (301,302,303,307,308):
    url=urllib.parse.urljoin(url,headers['Location']);parsed=urllib.parse.urlsplit(url)
    assert parsed.scheme=='https'and parsed.netloc==allowed and parsed.username is None
    continue
   assert status==200
   expected=spec['staged_files']['app.html']
   assert len(data)==expected['bytes']and sha(data)==expected['sha256']
   final=out/old['origin']/'app.html';final.write_bytes(data)
   row={'origin':old['origin'],'name':old['name'],'url':old['url'],'final_url':url,
    'status':'passed','http_status':status,'bytes':len(data),'sha256':sha(data),
    'expected_bytes':expected['bytes'],'expected_sha256':expected['sha256'],
    'file':str(final.relative_to(out)),'evidence_root':str(out),'hops':hops,
    'attribution':'Freshly recorded canonical GET redirect chain; Python3.9 does not natively follow308. No asset bytes normalized.'}
   break
  else:raise AssertionError('Redirect hop limit')
 rows.append(row)
report={'task':'E9-T13','status':'passed','head':spec['head'],
 'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'original_report':str(original/'report.json'),'original_report_sha256':sha((original/'report.json').read_bytes()),
 'prepared_receipt_sha256':sha(spec_path.read_bytes()),
 'carried_responses':34,'newly_recorded_html_chains':2,'assets':rows,
 'qualification':'The original extra asset capture retained34 matching responses and two HTTP308 exceptions. Those are a Python3.9 redirect-handler limitation. This additive result carries the34 exact originals and records only both canonical HTML redirect chains. It does not rerun or replace the successful production browser session.'}
p=out/'report.json';p.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'passed','responses':len(rows),'carried':34,'fresh_html_chains':2,'report':str(p),'sha256':sha(p.read_bytes())},indent=2))
