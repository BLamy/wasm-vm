from pathlib import Path
import os,json,re,subprocess,time
ram=Path('/Volumes/e9-final-proof-ram')
source=(ram/'e9-t13-corrected-account-auth-private.log').read_text(errors='replace')
source=re.sub(r'\x1b\[[0-9;]*m','',source)
scopes=[]
for line in source.splitlines():
 m=re.match(r'^\s*-\s+([a-z][a-z0-9_-]*)(?:\s+\(([a-z_]+)\))?\s*$',line)
 if m:scopes.append(m[1]+(':'+m[2]if m[2]else''))
assert len(scopes)==27 and 'offline_access'in scopes and 'pages:write'in scopes and 'account:read'in scopes
requested=[x for x in scopes if x!='offline_access']
assert len(requested)==26
private=ram/'e9-t13-work-account-device-private.log'
debug=ram/'e9-t13-work-account-device-private-debug.log'
receipt=ram/'e9-t13-work-account-device-status.json'
assert not private.exists() and not debug.exists() and not receipt.exists()
env=os.environ.copy()
env.update({'TMPDIR':'/Volumes/e9-final-proof-ram/deploy-tmp/',
 'NODE_OPTIONS':'--require=/Volumes/e9-final-proof-ram/wrangler-existing-auth-write.cjs',
 'WRANGLER_LOG_PATH':str(debug),'WRANGLER_SEND_METRICS':'false','CI':'true'})
cmd=['node','/Volumes/e9-t11-cold-scratch/e9-t12-npm-cache/_npx/32026684e21afda6/node_modules/wrangler/bin/wrangler.js','login','--device','--browser=false','--scopes',*requested]
record={'status':'waiting-for-official-authorization','started':time.time(),
 'command':cmd,'requested_existing_scopes':requested,
 'scope':'Normal official Wrangler credential refresh after the human confirmed work-account readiness. All26 requested permissions match the existing session; offline_access is auto-added by Wrangler. No new scope or alternative credential store. Private auth/device/debug output is excluded.'}
receipt.write_text(json.dumps(record,indent=2)+'\n')
fd=os.open(private,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
print(json.dumps({'status':record['status'],'existing_requested_scope_count':len(requested)}),flush=True)
with os.fdopen(fd,'wb')as f:r=subprocess.run(cmd,cwd='/Volumes/e9-final-proof-ram/e9-t13-wfi-publication-source',env=env,stdout=f,stderr=subprocess.STDOUT)
if debug.exists():debug.chmod(0o600)
record.update({'status':'completed'if r.returncode==0 else'failed','exit_code':r.returncode,'finished':time.time()})
receipt.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':record['status'],'exit_code':r.returncode}),flush=True)
