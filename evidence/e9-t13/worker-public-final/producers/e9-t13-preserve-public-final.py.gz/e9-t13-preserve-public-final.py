from pathlib import Path
import json,hashlib,gzip,time,subprocess
repo=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
ram=Path('/Volumes/e9-final-proof-ram');proof=Path('/Volumes/e9-t13-wfi-cold')
out=repo/'evidence/e9-t13/worker-public-final';out.mkdir(parents=True,exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
browser=proof/'e9-t13-wfi-public-browser';br=json.loads((browser/'report.json').read_text())
run=json.loads((proof/'e9-t13-wfi-public-browser-run.json').read_text())
deployment=json.loads((proof/'e9-t13-wfi-publication-v2/receipt.json').read_text())
assets=json.loads((proof/'e9-t13-wfi-public-assets-complete/report.json').read_text())
oracle=json.loads((proof/'e9-t13-wfi-public-oracle-qualification/report.json').read_text())
assert br['status']=='passed'and br['errors']==[]and br['checks']['suite']=={'passed':127,'failed':0}
assert run['status']=='passed'and run['clean_source_after']and run['report_sha256']==sha((browser/'report.json').read_bytes())
assert deployment['status']=='published'and deployment['exit_code']==0
assert br['head']==deployment['head']==run['head']=='2f2aa7aba484f6954ca04358385828093e561b83'
assert assets['status']=='passed'and len(assets['assets'])==36 and oracle['status']=='passed'
assert br['checks']['independentEgress']=={'fetchAttempts':[],'socketAttempts':0}
assert len(br['checks']['jit'])==12 and len(br['checks']['abi'])==28
for entry in br['files']:
 raw=(browser/entry['path']).read_bytes()
 assert len(raw)==entry['bytes']and sha(raw)==entry['sha256'],entry['path']
for entry in assets['assets']:
 raw=(Path(entry['evidence_root'])/entry['file']).read_bytes()
 assert len(raw)==entry['bytes']and sha(raw)==entry['sha256']==entry['expected_sha256']
summary={
 'task':'E9-T13','status':'Worker publication and recorded public proof complete; independent G9 charter still unfinished',
 'time':time.time(),'runtime':br['head'],'production_url':'https://wasm-vm.pages.dev/',
 'tested_url':br['url'],'immutable_deployment_url':deployment['public_urls'][0],
 'deployment_receipt_sha256':sha((proof/'e9-t13-wfi-publication-v2/receipt.json').read_bytes()),
 'public_browser_report_sha256':sha((browser/'report.json').read_bytes()),
 'public_browser_run_sha256':sha((proof/'e9-t13-wfi-public-browser-run.json').read_bytes()),
 'public_assets_completion_sha256':sha((proof/'e9-t13-wfi-public-assets-complete/report.json').read_bytes()),
 'public_oracle_qualification_sha256':sha((proof/'e9-t13-wfi-public-oracle-qualification/report.json').read_bytes()),
 'suite':br['checks']['suite'],'console_errors':br['errors'],'public_source_assets':len(br['assets']),
 'probe':br['checks']['probe'],'abi_refusals':len(br['checks']['abi']),
 'jit_cases':len(br['checks']['jit']),'component_refusals':len(br['checks']['components']['refusals']),
 'component_outcomes':len(br['checks']['components']['outcomes']),
 'reload':br['checks']['reload'],'independent_egress':br['checks']['independentEgress'],
 'asset_responses':36,'carried_asset_responses':34,'fresh_canonical_html_chains':2,
 'payload':deployment['after'],'clean_frozen_source_after':run['clean_source_after'],
 'qualifications':[
 'Original wrong-account deployment refusal and account-query checker mistakes remain preserved. Corrected CLI Project Name schema and official same-scope work-account refresh establish access; actual selected-account deployment succeeds.',
 'Python3.9 extra HTTP capture does not natively follow308. Original34 passing responses and two308 exceptions are preserved; an additive recording carries the34 exact files and records only both normal same-origin canonical HTML chains.',
 'The frozen local-counter byte oracle expects an OK synthetic HTTP reason. The public CDN trace.network:232 has HTTP3/status200/empty statusText and the same77-byte body as the guest response. The supplementary public-only decoder changes that one reason assertion, retaining every other original check; no recording or emulator/web source is normalized.',
 'All25 frozen local gates remain carried unchanged. This worker public proof is not an independent adversarial verifier execution or full verdict. G9 remains unresolved after the prior automatic security review stop.'
 ]}
summary_path=ram/'e9-t13-public-completion-summary.json';summary_path.write_text(json.dumps(summary,indent=2)+'\n')
records=[]
private_accounts=[
 json.loads(Path('/Users/blamy/Documents/Codex/wasm-vm/.wrangler/cache/wrangler-account.json').read_text())['account'],
 json.loads((ram/'e9-t13-wfi-publication-source/.wrangler/cache/wrangler-account.json').read_text())['account']]
def keep(path,name,expected=None):
 raw=path.read_bytes()
 if expected:assert sha(raw)==expected,str(path)
 for account in private_accounts:
  assert account['id'].encode()not in raw,str(path)
  assert account['name'].encode()not in raw,str(path)
 zipped=gzip.compress(raw,compresslevel=9,mtime=0)
 dst=out/(name+'.gz');dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(zipped)
 assert gzip.decompress(dst.read_bytes())==raw
 records.append({'original_path':str(path),'artifact':str(dst.relative_to(out)),'size':len(raw),'sha256':sha(raw),'gzip_size':len(zipped),'gzip_sha256':sha(zipped)})
roots=[
 ('acceptance/browser',browser),
 ('public-assets/original',proof/'e9-t13-wfi-public-assets'),
 ('public-assets/completion',proof/'e9-t13-wfi-public-assets-complete'),
 ('public-oracle',proof/'e9-t13-wfi-public-oracle-qualification'),
 ('publication',proof/'e9-t13-wfi-publication-v2'),
 ('account/corrected-first',proof/'e9-t13-wfi-corrected-account'),
 ('account/corrected-v2',proof/'e9-t13-wfi-corrected-account-v2'),
 ('account/corrected-v3',proof/'e9-t13-wfi-corrected-account-v3')]
for label,root in roots:
 for path in sorted(root.rglob('*')):
  if path.is_file():keep(path,label+'/'+str(path.relative_to(root)))
extras=[
 (summary_path,'summary.json'),
 (proof/'e9-t13-wfi-public-browser-run.json','origin/public-browser-run.json'),
 (proof/'e9-t13-wfi-public-browser-run.log','origin/public-browser-run.log'),
 (proof/'e9-t13-wfi-public-browser-oracle.log','origin/frozen-public-oracle-original-failure.log'),
 (proof/'e9-t13-wfi-public-provider-response-points.json','origin/public-provider-response-points.json'),
 (proof/'e9-t13-wfi-project-list-schema-qualification.json','origin/project-list-schema-qualification.json'),
 (ram/'e9-t13-work-account-device-status.json','origin/work-account-refresh-status.json'),
 (ram/'e9-t13-work-account-validated-auth-result.json','origin/work-account-authenticated.json'),
 (ram/'e9-t13-corrected-account-auth-result.json','origin/first-correction-still-old-session.json'),
 (ram/'e9-t13-wfi-publication-prepared/receipt.json','origin/prepared-payload.json'),
 (repo/'evidence/e9-t13/project-account-preflight/provenance.json','origin/earlier-account-packet-manifest.json'),
 (repo/'evidence/e9-t13/worker-wfi-final/provenance.json','origin/frozen-local-worker-packet-manifest.json')]
for path,name in extras:keep(path,name)
producers=[
 'e9-t13-publish-frozen-wfi-v2.py','e9-t13-run-public-browser.py','e9-t13-record-public-assets.py',
 'e9-t13-record-public-assets-v2.py','e9-t13-complete-public-asset-capture.py','e9-t13-run-public-file-oracle.py',
 'e9-t13-public-assets-original-syntax-failure.log','e9-t13-refresh-work-account.py',
 'e9-t13-work-account-validated-auth.py','e9-t13-corrected-account-preflight.py',
 'e9-t13-work-account-preflight.py','e9-t13-work-account-preflight-v3.py']
for name in producers:keep(ram/name,'producers/'+name)
keep(Path(__file__),'archive-producer.py')
manifest={'kind':'Lossless worker public deployment and production browser packet; no full verification verdict',
 'task':'E9-T13','created':time.time(),'frozen_runtime':br['head'],
 'repository_head_at_capture':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
 'summary_sha256':sha(summary_path.read_bytes()),
 'production_url':summary['production_url'],'immutable_deployment_url':summary['immutable_deployment_url'],
 'privacy':'Credentials, device codes, consent challenges, actual account labels/identifiers and private auth/debug logs excluded. Only account identifier fingerprints are retained.',
 'entries':records}
p=out/'provenance.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
(out/'README.md').write_text(
 '# Public deployment and recorded browser proof\n\n'
 'Frozen runtime2f2aa7 is actually deployed at https://wasm-vm.pages.dev/ with immutable deployment https://cb3b19fb.wasm-vm.pages.dev. The clean frozen checkout ran the complete public browser command:127passed/0failed, no console errors, five network receipts, six matching offline replays, four WFI cases,12 actual JIT cases,28 ABI refusals and six component refusals. Replay provider factories and independently witnessed replay fetch/socket attempts are zero. The recorded session, source-exact asset hashes, full frames/traces, CAS objects and screenshots are retained losslessly.\n\n'
 'Read summary.json.gz and all stated qualifications. Eighteen critical runtime/guest/boot-manifest assets match on both production and the immutable deployment. The additive asset completion explicitly carries34 original responses and records two canonical HTML308 chains; Python3.9 lacked that redirect handler. The original local-counter oracle rejected the public HTTP3 empty reason text; a public-only one-assertion qualification is anchored to actual trace.network:232 and matching response-body bytes. All other decoder assertions remain unchanged, and no runtime or recording bytes were normalized. Original failures and producers are preserved.\n\n'
 'This is a worker public-proof submission, not a full independent verification verdict. All25 original local gates remain carried at the same frozen runtime. The separate critic must assess this additional currency; G9 independent execution/sensitivity/suite disposition remains unfinished after the prior automatic security-review stop. No dependent task is cleared and no PR is merged. Private authorization output and actual account labels/identifiers are not published.\n')
for item in records:
 packed=(out/item['artifact']).read_bytes()
 assert sha(packed)==item['gzip_sha256']and sha(gzip.decompress(packed))==item['sha256']
result={'packet':str(p),'sha256':sha(p.read_bytes()),'entries':len(records),'gzip_bytes':sum(x['gzip_size']for x in records),
 'summary_sha256':sha(summary_path.read_bytes()),'production_url':summary['production_url']}
(ram/'e9-t13-public-final-packet-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
