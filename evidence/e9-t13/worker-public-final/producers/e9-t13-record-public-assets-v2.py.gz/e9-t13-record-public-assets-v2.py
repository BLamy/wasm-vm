from pathlib import Path
import urllib.request,urllib.error,concurrent.futures,json,hashlib,time,datetime
spec_path=Path('/Volumes/e9-final-proof-ram/e9-t13-wfi-publication-prepared/receipt.json')
deployment_path=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-publication-v2/receipt.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(spec_path.read_bytes())=='9f5ec1661f7d1895c59b332750dab1a803b8477358c86a0da62f75e2a1714163'
spec=json.loads(spec_path.read_text());deployment=json.loads(deployment_path.read_text())
assert deployment['status']=='published'and deployment['head']==spec['head']
out=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-public-assets');out.mkdir(exist_ok=False)
names=['app.html','main.js','network-capture-probe.js','session-network.js','session-inputs.js','roadmap.js','assets/e9-network-capture.bin','assets/e9-network-capture.elf','assets/e9-network-capture.json','pkg/wasm_vm_wasm.js','pkg/wasm_vm_wasm_bg.wasm','session-pkg/wasm_vm_session.js','session-pkg/wasm_vm_session_bg.wasm','artifacts.json','artifacts-alpine.json','artifacts-node-alpine.json','artifacts-omarchy.json','artifacts-omarchy-virgl.json']
origins={'production':'https://wasm-vm.pages.dev/','deployment':deployment['public_urls'][0].rstrip('/')+'/'}
results=[]
def get(item):
 label,name=item;url=origins[label]+name
 record={'origin':label,'name':name,'url':url,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  request=urllib.request.Request(url,headers={'Cache-Control':'no-cache','User-Agent':'wasm-vm-E9-T13-public-asset-proof'})
  with urllib.request.urlopen(request,timeout=30)as response:
   data=response.read()
   record.update({'http_status':response.status,'final_url':response.url,'headers':{k:response.headers[k]for k in ['Date','ETag','Content-Type','Cache-Control','CF-Cache-Status','Age','Last-Modified','Content-Length']if k in response.headers}})
  dst=out/label/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
  expected=spec['staged_files'][name]
  record.update({'file':str(dst.relative_to(out)),'bytes':len(data),'sha256':sha(data),'expected_sha256':expected['sha256'],'expected_bytes':expected['bytes']})
  assert record['http_status']==200 and len(data)==expected['bytes']and sha(data)==expected['sha256'],name
  record['status']='passed'
 except Exception as error:record.update({'status':'failed','failure':str(error)})
 return record
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
 for row in pool.map(get,[(label,name)for label in origins for name in names]):
  results.append(row)
  if len(results)%6==0:print(json.dumps({'captured':len(results),'failed':sum(x['status']!='passed'for x in results)}),flush=True)
report={'task':'E9-T13','status':'passed'if all(x['status']=='passed'for x in results)else'failed','head':spec['head'],
 'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prepared_receipt_sha256':sha(spec_path.read_bytes()),
 'deployment_receipt_sha256':sha(deployment_path.read_bytes()),'assets':results,
 'scope':'Raw public response bytes for18 critical runtime/guest/boot-manifest assets on both production and immutable deployment origins. No credentials, Set-Cookie or authorization headers retained; guest network counter endpoint not fetched.'}
p=out/'report.json';p.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'responses':len(results),'bytes':sum(x.get('bytes',0)for x in results),'report':str(p),'sha256':sha(p.read_bytes())}),flush=True)
raise SystemExit(0 if report['status']=='passed'else 1)
