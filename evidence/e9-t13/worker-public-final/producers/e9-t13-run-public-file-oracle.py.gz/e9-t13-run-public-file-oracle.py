from pathlib import Path
import json,hashlib,difflib,subprocess,ast,time
cold=Path('/Volumes/e9-t13-wfi-cold/cold-source-e9-t13-2f2aa7aba484')
root=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-public-browser')
out=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-public-oracle-qualification');out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
frozen='2f2aa7aba484f6954ca04358385828093e561b83'
relative='tools/verify/e9-network-capture-files.py'
base=(cold/relative).read_bytes()
assert subprocess.check_output(['git','show',frozen+':'+relative],cwd=cold)==base
guest=(cold/'web/assets/e9-network-capture.bin').read_bytes()
assert subprocess.check_output(['git','show',frozen+':web/assets/e9-network-capture.bin'],cwd=cold)==guest
assert sha(guest)=='85ba7328592bfbb4928291e1f7f6ef8418701bdea3ad3f10fc6faa29b8847ae4'
http=(root/'http-response.bin').read_bytes();head,body=http.split(b'\r\n\r\n',1)
assert head.split(b'\r\n',1)[0]==b'HTTP/1.1 200 '
points_path=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-public-provider-response-points.json')
points=json.loads(points_path.read_text())
assert len(points['provider_responses'])==1
point=points['provider_responses'][0]
assert point['status']==200 and point['statusText']=='' and point['httpVersion']=='h3'
assert point['body_sha256']==sha(body)
source=base.decode()
needle="head.startswith(b'HTTP/1.1 200 OK\\r\\n')"
replacement="head.startswith(b'HTTP/1.1 200 \\r\\n')"
assert source.count(needle)==1
qualified=source.replace(needle,replacement,1);ast.parse(qualified)
script=out/'source'/relative;script.parent.mkdir(parents=True)
script.write_text(qualified)
pin=out/'source/web/assets/e9-network-capture.bin';pin.parent.mkdir(parents=True);pin.write_bytes(guest)
(out/'frozen-base.py').write_bytes(base)
(out/'qualified-assertion.diff').write_text(''.join(difflib.unified_diff(source.splitlines(keepends=True),qualified.splitlines(keepends=True),fromfile='frozen-local-http-reason',tofile='qualified-public-http-reason')))
cmd=['python3','-B',str(script),'--directory',str(root),'--browser']
log=out/'oracle.log'
with log.open('xb')as f:result=subprocess.run(cmd,cwd=cold,stdout=f,stderr=subprocess.STDOUT)
record={'task':'E9-T13','status':'passed'if result.returncode==0 else'failed','time':time.time(),
 'frozen_runtime':frozen,'frozen_oracle_sha256':sha(base),'qualified_oracle_sha256':sha(qualified.encode()),
 'pinned_guest_sha256':sha(guest),'command':cmd,'exit_code':result.returncode,
 'original_frozen_attempt_log':'/Volumes/e9-t13-wfi-cold/e9-t13-wfi-public-browser-oracle.log',
 'original_frozen_attempt_log_sha256':sha(Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-public-browser-oracle.log').read_bytes()),
 'public_browser_report_sha256':sha((root/'report.json').read_bytes()),
 'provider_response_points_sha256':sha(points_path.read_bytes()),
 'provider_point':point,'recorded_synthetic_status_line':head.split(b'\r\n',1)[0].decode(),
 'changed_assertion':{'before':needle,'after':replacement},
 'qualification':'Supplementary worker data decoder only. The frozen local-counter oracle expects an OK reason phrase. The original public run failed solely there; the retained public Playwright network point is HTTP3/status200/empty statusText, and its77-byte response body exactly matches the saved guest transport bytes. This public-only copy requires that exact empty synthetic reason; all other original state, queue, pinned instruction, event, CAS, WFI, JIT and refusal assertions remain unchanged. No recording bytes or emulator/web sources normalized or changed. This is not a fresh independent verifier execution.'}
output=root/'network-oracle.json'
if output.exists():record.update({'oracle_result':str(output),'oracle_result_sha256':sha(output.read_bytes())})
p=out/'report.json';p.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':record['status'],'exit_code':result.returncode,'report':str(p),'sha256':sha(p.read_bytes())},indent=2))
raise SystemExit(result.returncode)
