from pathlib import Path
import json,hashlib,gzip,time,subprocess
repo=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
origin=Path('/Volumes/e9-final-proof-ram/t13-critic-main/partial-sufficiency-ledger')
out=repo/'evidence/e9-t13/independent-read-only-review'
out.mkdir(parents=True,exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
source=json.loads((origin/'provenance.json').read_text())
assert sha((origin/'provenance.json').read_bytes())=='a7fd8006df45744730cb6d489f5ee64b37b97694886e17836769353af9108ba2'
records=[]
def keep(path,name,expected=None):
 raw=path.read_bytes()
 if expected is not None:assert sha(raw)==expected,str(path)
 compressed=gzip.compress(raw,compresslevel=9,mtime=0)
 target=out/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(compressed)
 assert gzip.decompress(target.read_bytes())==raw
 records.append({'original_path':str(path),'artifact':str(target.relative_to(out)),'size':len(raw),'sha256':sha(raw),'gzip_size':len(compressed),'gzip_sha256':sha(compressed)})
for i,item in enumerate(source['inputs']):
 keep(Path(item['path']),f"inputs/{i:02d}-{Path(item['path']).name}",item['sha256'])
for item in source['artifacts']:
 keep(Path(item['path']),'assessment/'+Path(item['path']).name,item['sha256'])
keep(origin/'provenance.json','assessment/provenance.json','a7fd8006df45744730cb6d489f5ee64b37b97694886e17836769353af9108ba2')
keep(repo/'tasks/epic-9-session-time-travel/E9-T13-network-capture.md','boundary/task-at-review.md','406e02c848bd6cbc8b7a069a7169d9c9b80094d08f2adb4098dabc7b035af60d')
keep(Path(__file__),'archive-producer.py')
manifest={'kind':'Lossless worker preservation of separate critic read-only assessment; no verification verdict','task':'E9-T13','created':time.time(),'assessment_author':'/root/verify_e9_t12','frozen_runtime':source['head'],'parent_verified':source['base'],'repository_head_at_review':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'assessment_provenance_sha256':sha((origin/'provenance.json').read_bytes()),'restrictions':source['restrictions'],'remaining_gaps':source['remaining_gaps'],'entries':records}
p=out/'provenance.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
readme=out/'README.md'
readme.write_text('# Partial independent read-only review\n\nThis packet preserves the separate critic authored 52-file / 156-hunk assessment of frozen runtime 04f628. It is **not a verification verdict**. The source and saved-record inspection supports the reset repair and carries unchanged HELD observations while identifying G1–G8 component-evidence gaps, G9 unfinished independent execution/sensitivity/suite disposition, and P13 publication/public-browser proof.\n\nRead assessment/changed-hunk-ledger.md.gz and its detailed JSON alongside the original assessment provenance. All 255 final worker artifacts and 35 source hashes were authenticated by that read-only review; its six reset resumes agree. No stopped execution was retried or replaced. The worker only compressed and authenticated these existing files. Each input is retained losslessly, including the saved coverage executable as data; preserving it does not execute it.\n')
print(json.dumps({'packet':str(p),'sha256':sha(p.read_bytes()),'entries':len(records),'gzip_bytes':sum(x['gzip_size']for x in records)},indent=2))
