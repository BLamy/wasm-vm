"""Read-only source/saved-coverage analysis. Never loads or executes a VM/test/producer."""
from pathlib import Path
import difflib,hashlib,json,re,subprocess
from urllib.parse import urlparse

root=Path(__file__).resolve().parent
critic=root.parent
repo=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
base='76cc2c8dc1df4b17572bf09c73618e10ad848d63'
head='04f628dd02a0bf57331682e05607829e25a0ca46'
saved='e91c7af9bd8ec64c200c7d5a6687d9e4e124db12'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def source(name,revision=head):return git('show',revision+':'+name).decode()
diff=git('diff','--unified=0',base,head,'--','.',':!evidence')
files={};name=None;added=set()
for row in diff.decode().splitlines():
    if row.startswith('diff --git '):
        name=row.split(' b/',1)[1];files[name]={'path':name,'hunks':[],'added_lines':[]}
    elif row.startswith('@@'):
        match=re.search(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',row)
        old,oldn,new,newn=[int(match[1]),int(match[2]or'1'),int(match[3]),int(match[4]or'1')]
        h={'old_start':old,'old_count':oldn,'new_start':new,'new_count':newn,'header':row}
        files[name]['hunks'].append(h);at=new
    elif row.startswith('+')and not row.startswith('+++'):
        files[name]['added_lines'].append(at);at+=1
    elif row.startswith('Binary files '):files[name]['binary']=True

native={};name=None
for row in(root/'saved-native.lcov').read_text().splitlines():
    if row.startswith('SF:'):
        path=row[3:];prefix=str(critic/'core')+'/'
        name='crates/core/'+path[len(prefix):]if path.startswith(prefix)else None
    elif name and row.startswith('DA:'):
        n,count=map(int,row[3:].split(',')[:2]);native.setdefault(name,{})[n]=count

native_out={}
for name,counts in native.items():
    if name not in files:continue
    old_lines=source(name,saved).splitlines();new_lines=source(name).splitlines()
    if old_lines==new_lines:mapping={i:i for i in range(1,len(old_lines)+1)}
    else:
        matcher=difflib.SequenceMatcher(a=old_lines,b=new_lines,autojunk=False)
        mapping={i+offset+1:j+offset+1 for i,j,n in matcher.get_matching_blocks()if n>=2 for offset in range(n)}
    # New reset serialization has recorded frame/trace support, not counters from the old body.
    if name=='crates/core/src/lib.rs':mapping={i:j for i,j in mapping.items()if not 3378<=j<=3383}
    current={mapping[n]:c for n,c in counts.items()if n in mapping}
    changed={n:c for n,c in current.items()if n in files[name]['added_lines']}
    native_out[name]={'saved_source_sha256':sha(source(name,saved).encode()),'current_source_sha256':sha(source(name).encode()),
                      'changed_counted':len(changed),'changed_positive':sum(c>0 for c in changed.values()),
                      'changed_line_counts':changed,'all_mapped_line_counts':current,
                      'changed_zero':[{'line':n,'source':new_lines[n-1]}for n,c in changed.items()if c==0]}

browser=[]
for record in [Path('/Volumes/e9-final-proof-ram/cold-proof-e9-t13-04f628dd02a0/browser/javascript-coverage.json'),Path('/Volumes/e9-final-proof-ram/cold-proof-e9-t13-04f628dd02a0/retained-gpu-browser/javascript-coverage.json')]:
    for script in json.loads(record.read_text()):
        path=urlparse(script['url']).path.lstrip('/');name='web/dist/'+path
        if name not in files or name.endswith('.wasm'):continue
        try:expected=source(name)
        except subprocess.CalledProcessError:continue
        exact=script['source']==expected
        if not exact:
            browser.append({'file':name,'record':str(record),'source_exact':False,'saved_sha256':sha(script['source'].encode()),'expected_sha256':sha(expected.encode())});continue
        text16=expected.encode('utf-16-le')
        def line_at(offset):return text16[:offset*2].count(b'\n\0')+1
        def excerpt(start,end):return text16[start*2:end*2].decode('utf-16-le',errors='replace')
        functions=[];zeros=[]
        for f in script['functions']:
            main=f['ranges'][0];a,b=line_at(main['startOffset']),line_at(main['endOffset']-1)
            if not any(a<=n<=b for n in files[name]['added_lines']):continue
            functions.append({'name':f['functionName'],'line_start':a,'line_end':b,'count':main['count'],'start':main['startOffset'],'end':main['endOffset']})
            for item in f['ranges']:
                if item['count']!=0:continue
                a,b=line_at(item['startOffset']),line_at(max(item['startOffset'],item['endOffset']-1))
                if any(a<=n<=b for n in files[name]['added_lines']):zeros.append({'function':f['functionName'],'line_start':a,'line_end':b,'start':item['startOffset'],'end':item['endOffset'],'source':excerpt(item['startOffset'],item['endOffset'])[:240]})
        browser.append({'file':name,'record':str(record),'source_exact':True,'source_sha256':sha(expected.encode()),'functions':functions,'zero_ranges':zeros})

data={'base':base,'head':head,'saved_native_head':saved,'source_diff_sha256':sha(diff),'files':list(files.values()),'native':native_out,'browser':browser,
      'interpretation':'Counters are decoded from already saved profiles/object data; no VM/test/producer execution occurred. Native hits carry only through identical source contexts. Zero counters refer only to these saved profiles, not every recorded run. V8 zero intervals refer only to source-exact records and UTF16 source offsets. The Markdown ledger supplies evidence beyond counters, explicit waivers and unresolved requirements.'}
(root/'source-and-coverage.json').write_text(json.dumps(data,indent=2)+'\n')
print('files',len(files),'hunks',sum(len(x['hunks'])for x in files.values()))
for name,item in native_out.items():print('NATIVE',name,item['changed_positive'],'/',item['changed_counted'],json.dumps(item['changed_zero']))
for item in browser:
    if item['source_exact']:
        print('BROWSER',item['file'],'functions',[(f['name'],f['count'])for f in item['functions']if f['count']==0],'zero_ranges',[(z['line_start'],z['line_end'],z['source'][:100])for z in item['zero_ranges']])
    else:print('MISMATCH',item['file'])
