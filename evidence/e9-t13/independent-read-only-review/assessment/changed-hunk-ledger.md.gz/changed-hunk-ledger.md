# E9-T13 partial read-only changed-hunk ledger

**No verification verdict.** This source/saved-evidence audit leaves T13 blocked; it does not complete the independent execution charter or authorize publication. No VM/test binary or recorded producer was run. Existing raw coverage profiles and their executable object were decoded as data with LLVM tools; the object was never launched. No implementation, shared status, queue or commit changed.

Scope: `76cc2c8dc1df4b17572bf09c73618e10ad848d63..04f628dd02a0bf57331682e05607829e25a0ca46`, excluding evidence directories. There are 52 changed files and 156 textual hunks plus binary representations. Every hunk has an explicit classification, evidence citation, waiver and/or gap in `changed-hunk-ledger.json`; the table below indexes every file.

SUPPORTED means the cited recording/counter/frame supports the identified operation, not that every branch or the task is verified. WAIVED identifies a non-executable, generated, syntactic or narrowly dominated case with its reason. NEEDS EVIDENCE means a required execution claim has no retained point sufficient to close it; a zero in one saved recording is not a claim that the code never ran anywhere. Worker evidence and independently observed evidence are distinguished.

## Completed read-only reset assessment

The final packet manifest SHA 60304b99d0b98842aa4c5fbacc10025b82169927972fa08f2cd6365d66358d5b and report SHA e8976823db2791f96502b8da745360148f92647eb189d00ae43a4556c18280f5 authenticate 255 primary originals/gzip artifacts and 35 frozen source hashes. All 24 worker commands pass. This inspection did not rerun them.

Paused normal-reset checkpoint SHA 28e6b071904333fb5581e8f1cf41f9afe25f1329cab9d6263ddc6087751db736 is at transition/retired 1024, ordinal/sequence/cursor 2. Section 21 retains reset_pending 1, nextID 1, sent 0, empty pending/RX, link 0 and external_pending 0. UsedTX/RX=[1,0], guest report=[1,0,1]. Section 7 is 311 bytes with the two cache records encoded as ten zero bytes and counters[rx_dropped,tx_count,rx_count]=[0,1,0]. Its SHA ded04079b6bfd3de9987a2b67aaeaae17bd402e2e56a19df2356cd725755a6e2 matches the previous saved restored component exactly. The new filter agrees with existing service() at net.rs:574-578, which invalidates those views before use; it does not poll while saving.

All six recorded Record/Replay resumes at budgets 1/7/4096 have final frame SHA 446ff4e9c7d452fa1b9052268ad051ac58f40334c097e3f158a48639112007d0 and the same 8192-instruction trace SHA b277f17a4541496aeba08092dabf01059e788bcf491595368733ef87a63f8592. At trace lines 1478 and 3565 x6 reads IRQ0 from 0x10002060; final guest report=[1,0,0], cursor 2, reset_pending 0. New worker regression passes; its separately retained old-e91c linked run fails at the reset roundtrip. Those are worker regression observations, not an independent rerun.

Thirty-two previously HELD native/browser initial, pending and final frames, original traces and actual-JIT edge frames are byte-identical at 04f628. Prior independent CPU arithmetic/CAS/DMA/ordering observations carry across those exact unchanged boundaries. Historical conservation and normal-reset failures remain failures of their respective old revisions.

## Saved coverage boundary

Boundary QA accounts for all 52 files and 156 textual hunks. Seventeen of nineteen available source/dist pairs are byte-identical; app.html and sw.js contain generated deployment rewrites and are treated as declarative/generated representations. All 14 registry package identities and checksums in the saved native harness lock agree with the source lock. This static comparison neither installs dependencies nor reruns a recording. See boundary-qa.json.

The saved e91c independent native recording has eight passed tests and one normal-reset failure. Exact 101 runtime source/bench prefixes remain authenticated. Native counts are carried only through byte-identical contextual mappings; the new 04f628 reset filter is supported by E8/E9 instead, not old counters. Raw profiles, object SHA 54106c1ee6d409b85a8f717d6c09c37ffa3b96d65df1071c062398a2ebc8b204, merged profile, lcov and decoder diagnostics remain indexed in provenance. Diagnostics are empty. No whole-program/branch 100% claim is made.

| Changed native file | Positive/counted changed lines in saved independent records | Qualification |
| --- | --- | --- |
| `crates/core/src/dev/virtio/net.rs` | 30/34 | Identical source contexts only; zero lines/complete maps in source-and-coverage.json; logical outcome gaps below still apply to positive checked-add lines. |
| `crates/core/src/lib.rs` | 39/44 | Identical source contexts only; zero lines/complete maps in source-and-coverage.json; logical outcome gaps below still apply to positive checked-add lines. |
| `crates/core/src/resume.rs` | 0/0 | Identical source contexts only; zero lines/complete maps in source-and-coverage.json; logical outcome gaps below still apply to positive checked-add lines. |
| `crates/core/src/session_clock.rs` | 3/4 | Identical source contexts only; zero lines/complete maps in source-and-coverage.json; logical outcome gaps below still apply to positive checked-add lines. |
| `crates/core/src/session_network.rs` | 281/299 | Identical source contexts only; zero lines/complete maps in source-and-coverage.json; logical outcome gaps below still apply to positive checked-add lines. |
| `crates/core/src/session_network/codec.rs` | 208/216 | Identical source contexts only; zero lines/complete maps in source-and-coverage.json; logical outcome gaps below still apply to positive checked-add lines. |

Built V8 sources are matched byte-for-byte to frozen Git and offsets are UTF16, not Python codepoint indexes. All named session-network functions execute in the main network recording, while networkCursor has count 0 in generated bindings. GPU-only page coverage loads unused network modules; those zeros do not override positive main-page records. Inline app.html script records contain script bodies, not whole HTML, and are not misidentified as a stale full-page source. Their unmatchable whole-file comparison is excluded.

Native functional subranges: session_network.rs:1-118 declarations/representation are waived;119-172 validate/accept are supported except G1 exhaustion;176-219 max/normal TX/RX/idle supported with G1 error outcomes open;220-223 G2;224-231 reset supported;238-263 install success supported with G3 refusal gap;264-288 mode/provider/cursor supported;289-308 finish success/exhaustion-count mismatch supported with G1/G5 outcome gaps;310-374 request/lease/normal completion and stale/foreign intent checks supported, with G1/G5 entries open;375-431 exact replay/common success supported, with G5 queued-event/wrong-mode and G1 counter-exhaustion gaps. The internal non-Before guard is waived for the public quiescent synchronous assembly: no callback can enter halfway through a borrowed guest transition.

Codec functional subranges:1-79 bounded read/encode forms supported;80-123 normal decode/truncation/trailing supported with reserved/magic/outer-cap cases G6;127-157 checkpoint success supported with fatal-state G1;159-217 staged validation/conservation supported with specific G6 limits/relations unresolved;219-260 whole-machine validation/commit and incarnation replacement supported by atomic/lease and normal-reset recordings. Reader checked_add-overflow is dominated by bounded input/read sizes; closing continuation233 has no independent action.

Wasm bytes/strict counters/boolean/ordinal/shared-buffer/foreign lease refusals and ordinary methods are supported by 28 actual browser ABI cases. G4 remains for the unused cursor string wrapper. Repeated try_borrow guards are existing synchronous API plumbing, with no guest callback invoked under these method borrows; no new reentrant use is claimed. Generated declarations, finalizer fallbacks and reordered unchanged helper bodies have representation waivers, not new runtime behavior claims.

## Every changed file and hunk index

| File | Hunk new starts (count) | Classification | Citations / remaining gaps |
| --- | --- | --- | --- |
| `.gitignore` | 117(2) | WAIVED | E1, E2, E5, E7 |
| `Makefile` | 2755(4) | SUPPORTED | E1, E2 |
| `crates/core/src/dev/virtio/net.rs` | 68(7), 150(7), 300(7), 348(8), 397(1), 426(1), 428(3), 480(6) | SUPPORTED | E10, E3, E4, E8 |
| `crates/core/src/lib.rs` | 55(1), 288(1), 967(1), 2121(3), 3309(1), 3344(7), 3378(4), 3383(1), 3395(0), 3761(25), 3801(3), 4197(4), 4328(3), 6504(6) | NEEDS EVIDENCE; SUPPORTED; WAIVED | E10, E3, E4, E7, E8, E9, G1 |
| `crates/core/src/resume.rs` | 69(2), 98(1), 130(1) | WAIVED | E2, E7 |
| `crates/core/src/session_clock.rs` | 19(1), 625(5) | NEEDS EVIDENCE; WAIVED | E10, G1 |
| `crates/core/src/session_network.rs` | 1(431) | NEEDS EVIDENCE | E10, E3, E4, E5, E7, G1, G2, G3, G5 |
| `crates/core/src/session_network/codec.rs` | 1(260) | NEEDS EVIDENCE | E10, E3, E4, E7, E8, G1, G6 |
| `crates/core/tests/e9_network_capture.rs` | 1(833) | SUPPORTED | E2, E4, E7, E8, E9 |
| `crates/jit-runtime/tests/e9_network_capture.rs` | 1(101) | SUPPORTED | E2, E4, E7, E8, E9 |
| `crates/wasm/src/lib.rs` | 46(1) | WAIVED | E2, E7 |
| `crates/wasm/src/session_network.rs` | 1(147) | NEEDS EVIDENCE | E5, E6, G4 |
| `docs/design/session-replay-contract.json` | 453(20), 491(8), 812(1), 817(2), 823(2), 835(1), 841(1), 859(2) | WAIVED | E1, E2, E5, E7 |
| `docs/design/session-replay.md` | 458(44) | WAIVED | E1, E2, E5, E7 |
| `tasks/QUEUE.md` | 10(0), 458(1) | WAIVED | E1, E2, E5, E7 |
| `tasks/epic-9-session-time-travel/E9-T13-network-capture.md` | 6(1), 37(259) | WAIVED | E1, E2, E5, E7 |
| `tools/verify/build-e9-network-guest.py` | 1(57) | SUPPORTED | E1, E2, E4, E5, E7 |
| `tools/verify/e9-network-capture-browser.mjs` | 1(131) | SUPPORTED | E1, E2, E4, E5, E7 |
| `tools/verify/e9-network-capture-files.py` | 1(96) | SUPPORTED | E1, E2, E4, E5, E7 |
| `tools/verify/e9-network-capture.py` | 1(50) | SUPPORTED | E1, E2, E4, E5, E7 |
| `tools/verify/e9-network-guest.listing` | 1(2477) | WAIVED | E1, E2, E5, E7 |
| `web/assets/e9-network-capture.bin` | binary(-) | WAIVED | E1, E2, E5, E7 |
| `web/assets/e9-network-capture.elf` | binary(-) | WAIVED | E1, E2, E5, E7 |
| `web/assets/e9-network-capture.json` | 1(14) | WAIVED | E1, E2, E5, E7 |
| `web/dist/app.html` | 112(1), 984(6) | WAIVED | E1, E2, E5, E7 |
| `web/dist/assets/e9-network-capture.bin` | binary(-) | WAIVED | E1, E2, E5, E7 |
| `web/dist/assets/e9-network-capture.elf` | binary(-) | WAIVED | E1, E2, E5, E7 |
| `web/dist/assets/e9-network-capture.json` | 1(14) | WAIVED | E1, E2, E5, E7 |
| `web/dist/gpu-checkpoint-build.js` | 2(3) | WAIVED | E1, E2, E5, E7 |
| `web/dist/main.js` | 17(1), 2649(2), 2962(2), 2973(1), 3024(1), 3028(1), 3279(7), 3287(1), 3294(1), 3302(1) | SUPPORTED | E5, E6 |
| `web/dist/network-capture-probe.js` | 1(89) | SUPPORTED | E5, E6, E7 |
| `web/dist/network-probe-response.json` | 1(1) | WAIVED | E1, E2, E5, E7 |
| `web/dist/pkg/snippets/wasm-vm-wasm-0a6604668439f3ad/inline0.js` | 2(18), 21(7) | WAIVED | E1, E11, E2, E5, E7 |
| `web/dist/pkg/snippets/wasm-vm-wasm-0a6604668439f3ad/inline1.js` | 2(11), 13(0) | WAIVED | E1, E11, E2, E5, E7 |
| `web/dist/pkg/wasm_vm_wasm.d.ts` | 22(6), 578(1), 600(1), 609(1), 616(1), 623(3), 643(1), 704(1), 922(16), 960(0), 965(1), 968(1), 970(25), 996(1), 998(4), 1008(1), 1010(1) | WAIVED | E1, E2, E5, E7 |
| `web/dist/pkg/wasm_vm_wasm.js` | 2(1), 83(20), 1916(11), 1986(11), 2023(9), 2057(13), 2084(41), 2198(19), 2467(10), 3526(3) | NEEDS EVIDENCE; SUPPORTED | E2, E5, E6, G4 |
| `web/dist/pkg/wasm_vm_wasm_bg.wasm` | binary(-) | WAIVED | E1, E2, E5, E7 |
| `web/dist/pkg/wasm_vm_wasm_bg.wasm.d.ts` | 114(16), 152(0), 157(1), 160(1), 162(25), 188(1), 190(4), 200(1), 202(1) | WAIVED | E1, E2, E5, E7 |
| `web/dist/roadmap.js` | 232(1) | WAIVED | E1, E2, E5, E7 |
| `web/dist/session-inputs.js` | 6(1), 19(1), 29(1), 61(1), 75(1), 93(1), 106(1), 132(1), 136(1), 138(2) | NEEDS EVIDENCE; SUPPORTED | E5, E6, E7, G8 |
| `web/dist/session-network.js` | 1(69) | NEEDS EVIDENCE | E5, E6, G7 |
| `web/dist/sw.js` | 21(1) | WAIVED | E1, E2, E5, E7 |
| `web/dist/tasks.json` | 34784(1), 34811(1), 34814(15) | WAIVED | E1, E2, E5, E7 |
| `web/gpu-checkpoint-build.js` | 2(3) | WAIVED | E1, E2, E5, E7 |
| `web/index.html` | 112(1), 984(6) | WAIVED | E1, E2, E5, E7 |
| `web/main.js` | 17(1), 2649(2), 2962(2), 2973(1), 3024(1), 3028(1), 3279(7), 3287(1), 3294(1), 3302(1) | SUPPORTED | E5, E6 |
| `web/network-capture-probe.js` | 1(89) | SUPPORTED | E5, E6, E7 |
| `web/network-probe-response.json` | 1(1) | WAIVED | E1, E2, E5, E7 |
| `web/roadmap.js` | 232(1) | WAIVED | E1, E2, E5, E7 |
| `web/session-inputs.js` | 6(1), 19(1), 29(1), 61(1), 75(1), 93(1), 106(1), 132(1), 136(1), 138(2) | NEEDS EVIDENCE; SUPPORTED | E5, E6, E7, G8 |
| `web/session-network.js` | 1(69) | NEEDS EVIDENCE | E5, E6, G7 |
| `web/tasks.json` | 34784(1), 34811(1), 34814(15) | WAIVED | E1, E2, E5, E7 |

Per-hunk explanations, including positive support inside a NEEDS EVIDENCE file and explicit waiver reasons, are in changed-hunk-ledger.json. The JSON includes all 156 exact unified-zero headers and binary entries, so no generated/duplicate or deleted-only hunk disappears from the audit. Source/dist functional duplicates use the same evidence only after exact-byte matching.

## Concrete missing proof

### G1

Source: `crates/core/src/session_network.rs:120-142,180-208,289-331`; `crates/core/src/session_clock.rs:625-628`; `crates/core/src/lib.rs:3344-3350,6504-6509`; `crates/core/src/session_network/codec.rs:132-135`.

Saved native counters have zero at broker fatal forwarding/tx Limit return/error latch, execution stop and checkpoint-on-error returns. Positive counts on checked_add lines do not prove their exhaustion outcome. The oversized guest descriptor test stops before allocating a broker intent, so it does not establish broker exhaustion.

Narrow missing proof: One bounded ordinary native component recording of pending-TX capacity, allocator/cursor limits and sticky error propagation: unchanged counters/guest position after refusal, repeat run remains stopped, snapshot on fatal state refuses. Include the originating guard and its caller error/stop/checkpoint path. No performance or external transport test is requested.

### G2

Source: `crates/core/src/session_network.rs:220-223`.

The saved independent profiles give this owned external_io_pending override count 0. Pending events and persistence are recorded, but those records alone do not show the getter affecting guest idle/WFI scheduling.

Narrow missing proof: A bounded ordinary owned-NIC idle/WFI recording distinguishing outstanding guest TX and external_pending true/false, with exact guest clock/retirement witnesses; or a direct deterministic component getter assertion plus the already qualified caller boundary. This remains a coverage request, not a claim that no submitted run called it.

### G3

Source: `crates/core/src/session_network.rs:238-246`.

Fresh owned installation succeeds in all fixtures; native Unsupported return has count 0 in saved independent profiles. Strict boolean browser errors occur before native installation and do not establish these topology/lifecycle refusals.

Narrow missing proof: Record ordinary installation refusal for an existing live NIC, duplicate installation and installation after execution; preserve the complete original state. Qualify any structurally unreachable malformed slot-vector branch separately rather than fabricating such topology.

### G4

Source: `crates/wasm/src/session_network.rs:49-59`; `web/dist/pkg/wasm_vm_wasm.js:2084-2104`.

Source-exact built V8 coverage reports networkCursor() count 0; the native cursor method is called, but that does not prove Wasm exact-decimal conversion/allocation/free.

Narrow missing proof: One ordinary built-browser call to networkCursor after known receipts (expected exact decimal cursor), tied to its actual native checkpoint/outcomes. An inactive-machine refusal can close the wrapper error path at the same time.

### G5

Source: `crates/core/src/session_network.rs:289-308,347-381,400-408`.

Success, wrong coordinates, duplicate and changed intent are recorded. Saved counters leave finish-in-Record, direct completion-in-Replay, replay-event-in-Record and queued-common-event refusal without a direct retained point. Existing live-provider checks block construction/lease acquisition; they do not demonstrate every completion entry point. Wrong expected cursor can short-circuit the pending/RX/external-work finish conditions.

Narrow missing proof: A small ordinary in-memory protocol recording for these entry points and for finish with the correct cursor but pending TX, queued RX or external_pending still present. Assert exact-state/cursor preservation. No new network action is needed.

### G6

Source: `crates/core/src/session_network/codec.rs:80-123,159-217`.

Truncation, trailing bytes, invalid typed events,13 malformed checkpoints and four conservation cases are recorded. Saved counters show zero for outer event/checkpoint byte cap, event magic and reserved Send/Link/event-tag decode returns. Counted arithmetic/checkpoint conditions alone are not branch proof of duplicate-ID, combined decoded-owned cap or checked joint-sum overflow outcomes.

Narrow missing proof: Retain bounded codec/format fixtures for these specific cases, showing rejection before state/incarnation mutation and a valid callback still usable. Preserve the already demonstrated valid exact 4 MiB state and all-terms conservation state as controls. These are missing format proofs, not newly demonstrated product faults.

### G7

Source: `web/session-network.js:16-19,35-48`.

Source-exact V8 records cover normal split/join, five events, replay and divergence. Unknown event-kind and Link-Failed status selection have zero ranges; native Failed/Cancelled result coverage does not by itself show browser durable serialization. Factory-throw cleanup has count 0.

Narrow missing proof: A bounded built-browser in-memory journal roundtrip/replay containing Failed/Cancelled sends and a failed link with code; a reserved event-kind rejection; and a recording factory that throws before construction, checking cleanup and no state/cursor change. No external target is required.

### G8

Source: `web/session-inputs.js:61,93,138-139`.

The network policy and required-source gates execute successfully for the valid network prefix. The retained need() rejection body has count 0 in this module; the missing-payload case fails in SessionStore instead. Thus valid-policy execution is supported but these newly added negative policy/adapter checks are not directly proven.

Narrow missing proof: One bounded ordinary durable-prefix check refusing a wrong/absent network policy or absent required network adapter before publication, with its original manifest/cursor unchanged. Keep this separate from the already proven missing-object refusal.

### G9

Source: `AGENTS.md verifier charter`.

The independent execution turn was stopped by automatic security review citing possible cybersecurity risk. No new execution, retry, alternate model/session or sensitivity check is performed in this assessment.

Narrow missing proof: Complete the authorized independent risk-tier critique when the restriction changes, including the prescribed bounded scratch sensitivity check, remaining independent executions and permanent-suite decision. Worker red/green regressions are retained evidence but cannot substitute for this charter requirement.

### P13

Source: `AGENTS.md worker protocol3a(c)`; `tasks/epic-9-session-time-travel/E9-T13-network-capture.md`.

Required Cloudflare publication and a direct public-browser recording for 04f628 are absent; official account/device authorization expired. Earlier candidates were not deployed.

Narrow missing proof: Authorized stock publication of the frozen04f628 bundle followed by exact public asset authentication and the required public browser/network recording. No T12 live proof may be carried as T13 publication proof.

## Evidence citations

| ID | Saved artifact | SHA256 / point |
| --- | --- | --- |
| E1 | `/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed/evidence/e9-t13/worker-reset-final/provenance.json` | `60304b99d0b98842aa4c5fbacc10025b82169927972fa08f2cd6365d66358d5b`; 255 primary originals/gzip artifacts authenticated in the read-only reset inspection; frozen source hashes 35 and acceptance commands 24. |
| E2 | `/Volumes/e9-final-proof-ram/cold-proof-e9-t13-04f628dd02a0/report.json` | `e8976823db2791f96502b8da745360148f92647eb189d00ae43a4556c18280f5`; Completed exact-head worker report; all 24 exit codes 0. Source/build provenance is a worker recording, not a replacement for independent execution. |
| E3 | `/Volumes/e9-final-proof-ram/t13-critic-main/normal-native.log` | `b502741d1ddca7943501d0affc421ada51ead18add21c17fae551e5602f997fe`; Saved pre-stop native recording: eight tests pass, one normal-reset test fails; two local-counter tests intentionally filtered. Passed schedule/event-form and wrapper tests are carried only across unchanged source. Assertions before the reset failure support the capacity prefix; the failed whole test is not relabeled passing. |
| E4 | `/Volumes/e9-final-proof-ram/cold-proof-e9-t13-04f628dd02a0/network-and-session-native.log` | `7f802af7d43b63cdbcaeabf868cee075ab9d0e11e63e9e0ad989ff5833e59aed`; Nine final worker network tests pass, including conservation, queued RX, normal reset and malformed checkpoints; other affected session/legacy net tests also pass. |
| E5 | `/Volumes/e9-final-proof-ram/cold-proof-e9-t13-04f628dd02a0/browser/report.json` | `af17a8b5efbdfe1534c2076e9be6f0882a155a3d6435eb2e8488e70bbbf4d5d2`; Built suite 127/0, errors[], probe 5 events/6 replays/18 refusals,28 ABI cases, reload 5, missing required payload refusal, zero replay factory/fetch/socket attempts. |
| E6 | `/Volumes/e9-final-proof-ram/cold-proof-e9-t13-04f628dd02a0/browser/javascript-coverage.json` | `596a44772b829169d0d169b9174c9d4dd2a4fb7605187fc88778e3f9b4e0dc6b`; Source-exact V8 function/range records. UTF16 offsets and positive/zero counts are preserved in source-and-coverage.json. Main browser record is distinguished from unused modules loaded in the GPU-only recording. |
| E7 | `/Volumes/e9-final-proof-ram/t13-critic-main/guest-oracle.json` | `752a63cf17b3bad7844b870379547cb9308922da3a77df8cb8e7198258c39d6b`; Prior independent struct/hashlib decoding: exact request/response positions, CPU/RAM/rings/IRQ/CAS, all 24 native/browser JIT CPU witnesses. The32 initial/pending/final/trace/JIT artifacts were subsequently compared byte-identical with 04f628. |
| E8 | `/Volumes/e9-final-proof-ram/cold-proof-e9-t13-04f628dd02a0/native/normal-reset-paused.resume` | `28e6b071904333fb5581e8f1cf41f9afe25f1329cab9d6263ddc6087751db736`; Paused transition 1024/sequence 2/cursor 2; section 7 cache markers 10 zero bytes, counters[0,1,0], reset flag 1 in section 21. Section 7 matches the previous saved restored component. |
| E9 | `/Volumes/e9-final-proof-ram/cold-proof-e9-t13-04f628dd02a0/native/normal-reset-original.trace` | `b277f17a4541496aeba08092dabf01059e788bcf491595368733ef87a63f8592`; 8192 retired instructions. All six Record/Replay q1/7/4096 traces match exactly; each final frame has SHA 446ff4e9c7d452fa1b9052268ad051ac58f40334c097e3f158a48639112007d0. IRQ0 is read at lines 1478 and 3565. |
| E10 | `/Volumes/e9-final-proof-ram/t13-critic-main/coverage-preparation.json` | `5e060f2f98bbdfe2f9fc55afaeb8d07291e92ab59b737f1462958024a57f1ca8`; 101 exact source/bench prefixes from e91c; all remain unchanged in the saved scratch copy. Native saved counters map only through identical current source contexts; new reset lines are excluded from old counters. |
| E11 | `/Volumes/e9-final-proof-ram/cold-proof-e9-t13-04f628dd02a0/retained-gpu-browser/report.json` | `e03384ceffdd90000fdbd8b1e190b57202529c0414b62f34d0dac6dad63fd8a7`; Retained factory GPU worker recording passes at 04f628; generated snippet reorder preserves pre-existing function bytes. Page V8 records do not establish worker-context function execution. |
| E12 | `/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed/tasks/epic-9-session-time-travel/E9-T13-network-capture.md` | `406e02c848bd6cbc8b7a069a7169d9c9b80094d08f2adb4098dabc7b035af60d`; Current blocked metadata and explicit missing publication/account authorization plus stopped independent charter. No T13 public deployment claimed; T12 live runtime cannot discharge P13. |
| E13 | `/Volumes/e9-final-proof-ram/t13-critic-main/harness/tests/critic.rs` | `2123ba667438dd8fb69e052d6c46ae41504e105f89402275b459228ede2e7b21`; Saved ordinary in-memory critic test source corresponding to the profile-bearing executable; source hashes, failed reset and earlier test version are preserved separately. |
| E14 | `/Volumes/e9-final-proof-ram/cold-proof-e9-t13-04f628dd02a0/native/pending.resume` | `c646d95dcc12666db5f49a48c887f5a2b66f5e8e85121cb2d1a6c8c93822dbee`; Real guest TX request 1 at 1024; sequence/cursor 1, usedTX1/RX0. Native/final.resume9216 has usedTX/RX1/1 and guest report[1,1,1]. |

## Handoff limits

No new attack, VM/test execution, producer rerun, sensitivity test, alternate model/session or shared write occurs in this bounded task. Static LLVM coverage-data decoding is distinct from launching the recorded object. This partial sufficiency audit is useful evidence accounting; it cannot substitute for the unfinished independent charter. Existing stopped-execution records, the two repaired findings, all original data and the external publication/account-authorization gap remain preserved. No dependent E9 task is cleared and no verified verdict is issued.
