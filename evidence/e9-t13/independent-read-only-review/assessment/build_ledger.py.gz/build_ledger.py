"""Author a partial sufficiency assessment from source and saved data only."""
from pathlib import Path
import hashlib,json,re,subprocess,time

r=Path(__file__).resolve().parent;c=r.parent
repo=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
proof=Path('/Volumes/e9-final-proof-ram/cold-proof-e9-t13-04f628dd02a0')
data=json.loads((r/'source-and-coverage.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

evidence={
 'E1':{'path':str(repo/'evidence/e9-t13/worker-reset-final/provenance.json'),'point':'255 primary originals/gzip artifacts authenticated in the read-only reset inspection; frozen source hashes 35 and acceptance commands 24.'},
 'E2':{'path':str(proof/'report.json'),'point':'Completed exact-head worker report; all 24 exit codes 0. Source/build provenance is a worker recording, not a replacement for independent execution.'},
 'E3':{'path':str(c/'normal-native.log'),'point':'Saved pre-stop native recording: eight tests pass, one normal-reset test fails; two local-counter tests intentionally filtered. Passed schedule/event-form and wrapper tests are carried only across unchanged source. Assertions before the reset failure support the capacity prefix; the failed whole test is not relabeled passing.'},
 'E4':{'path':str(proof/'network-and-session-native.log'),'point':'Nine final worker network tests pass, including conservation, queued RX, normal reset and malformed checkpoints; other affected session/legacy net tests also pass.'},
 'E5':{'path':str(proof/'browser/report.json'),'point':'Built suite 127/0, errors[], probe 5 events/6 replays/18 refusals,28 ABI cases, reload 5, missing required payload refusal, zero replay factory/fetch/socket attempts.'},
 'E6':{'path':str(proof/'browser/javascript-coverage.json'),'point':'Source-exact V8 function/range records. UTF16 offsets and positive/zero counts are preserved in source-and-coverage.json. Main browser record is distinguished from unused modules loaded in the GPU-only recording.'},
 'E7':{'path':str(c/'guest-oracle.json'),'point':'Prior independent struct/hashlib decoding: exact request/response positions, CPU/RAM/rings/IRQ/CAS, all 24 native/browser JIT CPU witnesses. The32 initial/pending/final/trace/JIT artifacts were subsequently compared byte-identical with 04f628.'},
 'E8':{'path':str(proof/'native/normal-reset-paused.resume'),'point':'Paused transition 1024/sequence 2/cursor 2; section 7 cache markers 10 zero bytes, counters[0,1,0], reset flag 1 in section 21. Section 7 matches the previous saved restored component.'},
 'E9':{'path':str(proof/'native/normal-reset-original.trace'),'point':'8192 retired instructions. All six Record/Replay q1/7/4096 traces match exactly; each final frame has SHA 446ff4e9c7d452fa1b9052268ad051ac58f40334c097e3f158a48639112007d0. IRQ0 is read at lines 1478 and 3565.'},
 'E10':{'path':str(c/'coverage-preparation.json'),'point':'101 exact source/bench prefixes from e91c; all remain unchanged in the saved scratch copy. Native saved counters map only through identical current source contexts; new reset lines are excluded from old counters.'},
 'E11':{'path':str(proof/'retained-gpu-browser/report.json'),'point':'Retained factory GPU worker recording passes at 04f628; generated snippet reorder preserves pre-existing function bytes. Page V8 records do not establish worker-context function execution.'},
 'E12':{'path':str(repo/'tasks/epic-9-session-time-travel/E9-T13-network-capture.md'),'point':'Current blocked metadata and explicit missing publication/account authorization plus stopped independent charter. No T13 public deployment claimed; T12 live runtime cannot discharge P13.'},
 'E13':{'path':str(c/'harness/tests/critic.rs'),'point':'Saved ordinary in-memory critic test source corresponding to the profile-bearing executable; source hashes, failed reset and earlier test version are preserved separately.'},
 'E14':{'path':str(proof/'native/pending.resume'),'point':'Real guest TX request 1 at 1024; sequence/cursor 1, usedTX1/RX0. Native/final.resume9216 has usedTX/RX1/1 and guest report[1,1,1].'},
}
for item in evidence.values():item['sha256']=sha(Path(item['path']))
for key,word in [('E3','critic_backend_wrappers'),('E4','normal_reset_checkpoint'),('E4','checkpoint_conserves_all')]:
    lines=Path(evidence[key]['path']).read_text().splitlines();evidence[key].setdefault('line_points',[]).extend({'line':i+1,'text':line[:240]}for i,line in enumerate(lines)if word in line)

gaps={
 'G1':{'source':['crates/core/src/session_network.rs:120-142,180-208,289-331','crates/core/src/session_clock.rs:625-628','crates/core/src/lib.rs:3344-3350,6504-6509','crates/core/src/session_network/codec.rs:132-135'],
       'observation':'Saved native counters have zero at broker fatal forwarding/tx Limit return/error latch, execution stop and checkpoint-on-error returns. Positive counts on checked_add lines do not prove their exhaustion outcome. The oversized guest descriptor test stops before allocating a broker intent, so it does not establish broker exhaustion.',
       'missing':'One bounded ordinary native component recording of pending-TX capacity, allocator/cursor limits and sticky error propagation: unchanged counters/guest position after refusal, repeat run remains stopped, snapshot on fatal state refuses. Include the originating guard and its caller error/stop/checkpoint path. No performance or external transport test is requested.'},
 'G2':{'source':['crates/core/src/session_network.rs:220-223'],
       'observation':'The saved independent profiles give this owned external_io_pending override count 0. Pending events and persistence are recorded, but those records alone do not show the getter affecting guest idle/WFI scheduling.',
       'missing':'A bounded ordinary owned-NIC idle/WFI recording distinguishing outstanding guest TX and external_pending true/false, with exact guest clock/retirement witnesses; or a direct deterministic component getter assertion plus the already qualified caller boundary. This remains a coverage request, not a claim that no submitted run called it.'},
 'G3':{'source':['crates/core/src/session_network.rs:238-246'],
       'observation':'Fresh owned installation succeeds in all fixtures; native Unsupported return has count 0 in saved independent profiles. Strict boolean browser errors occur before native installation and do not establish these topology/lifecycle refusals.',
       'missing':'Record ordinary installation refusal for an existing live NIC, duplicate installation and installation after execution; preserve the complete original state. Qualify any structurally unreachable malformed slot-vector branch separately rather than fabricating such topology.'},
 'G4':{'source':['crates/wasm/src/session_network.rs:49-59','web/dist/pkg/wasm_vm_wasm.js:2084-2104'],
       'observation':'Source-exact built V8 coverage reports networkCursor() count 0; the native cursor method is called, but that does not prove Wasm exact-decimal conversion/allocation/free.',
       'missing':'One ordinary built-browser call to networkCursor after known receipts (expected exact decimal cursor), tied to its actual native checkpoint/outcomes. An inactive-machine refusal can close the wrapper error path at the same time.'},
 'G5':{'source':['crates/core/src/session_network.rs:289-308,347-381,400-408'],
       'observation':'Success, wrong coordinates, duplicate and changed intent are recorded. Saved counters leave finish-in-Record, direct completion-in-Replay, replay-event-in-Record and queued-common-event refusal without a direct retained point. Existing live-provider checks block construction/lease acquisition; they do not demonstrate every completion entry point. Wrong expected cursor can short-circuit the pending/RX/external-work finish conditions.',
       'missing':'A small ordinary in-memory protocol recording for these entry points and for finish with the correct cursor but pending TX, queued RX or external_pending still present. Assert exact-state/cursor preservation. No new network action is needed.'},
 'G6':{'source':['crates/core/src/session_network/codec.rs:80-123,159-217'],
       'observation':'Truncation, trailing bytes, invalid typed events,13 malformed checkpoints and four conservation cases are recorded. Saved counters show zero for outer event/checkpoint byte cap, event magic and reserved Send/Link/event-tag decode returns. Counted arithmetic/checkpoint conditions alone are not branch proof of duplicate-ID, combined decoded-owned cap or checked joint-sum overflow outcomes.',
       'missing':'Retain bounded codec/format fixtures for these specific cases, showing rejection before state/incarnation mutation and a valid callback still usable. Preserve the already demonstrated valid exact 4 MiB state and all-terms conservation state as controls. These are missing format proofs, not newly demonstrated product faults.'},
 'G7':{'source':['web/session-network.js:16-19,35-48'],
       'observation':'Source-exact V8 records cover normal split/join, five events, replay and divergence. Unknown event-kind and Link-Failed status selection have zero ranges; native Failed/Cancelled result coverage does not by itself show browser durable serialization. Factory-throw cleanup has count 0.',
       'missing':'A bounded built-browser in-memory journal roundtrip/replay containing Failed/Cancelled sends and a failed link with code; a reserved event-kind rejection; and a recording factory that throws before construction, checking cleanup and no state/cursor change. No external target is required.'},
 'G8':{'source':['web/session-inputs.js:61,93,138-139'],
       'observation':'The network policy and required-source gates execute successfully for the valid network prefix. The retained need() rejection body has count 0 in this module; the missing-payload case fails in SessionStore instead. Thus valid-policy execution is supported but these newly added negative policy/adapter checks are not directly proven.',
       'missing':'One bounded ordinary durable-prefix check refusing a wrong/absent network policy or absent required network adapter before publication, with its original manifest/cursor unchanged. Keep this separate from the already proven missing-object refusal.'},
 'G9':{'source':['AGENTS.md verifier charter'],
       'observation':'The independent execution turn was stopped by automatic security review citing possible cybersecurity risk. No new execution, retry, alternate model/session or sensitivity check is performed in this assessment.',
       'missing':'Complete the authorized independent risk-tier critique when the restriction changes, including the prescribed bounded scratch sensitivity check, remaining independent executions and permanent-suite decision. Worker red/green regressions are retained evidence but cannot substitute for this charter requirement.'},
 'P13':{'source':['AGENTS.md worker protocol3a(c)','tasks/epic-9-session-time-travel/E9-T13-network-capture.md'],
       'observation':'Required Cloudflare publication and a direct public-browser recording for 04f628 are absent; official account/device authorization expired. Earlier candidates were not deployed.',
       'missing':'Authorized stock publication of the frozen04f628 bundle followed by exact public asset authentication and the required public browser/network recording. No T12 live proof may be carried as T13 publication proof.'},
}

def rule(name,h):
    n=h['new_start'];support=[];waive=[];need=[];refs=[]
    def result():return {'classification':'NEEDS EVIDENCE'if need else'SUPPORTED'if support else'WAIVED','supported':support,'waived':waive,'gaps':need,'citations':refs}
    if name=='crates/core/src/dev/virtio/net.rs':
        if n==68:support+=['Default maximum reached by recorded affected legacy net TX tests; ordinary override/delegation is counted.'];waive+=['The default reset hook is intentionally empty; it adds no state action.'];refs+=['E3','E4']
        else:support+=['Exact unchanged saved native source counters are positive across this maximum/reset/flags/bounded-TX hunk; concrete reset and oversized-descriptor worker assertions agree.'];refs+=['E3','E4','E8','E10']
    elif name=='crates/core/src/lib.rs':
        if n in(55,288):waive+=['Module/type storage declaration; compilation and authenticated source establish representation.']
        elif n==967:support+=['Initial native/browser frames and saved constructor counters show absence before explicit install.'];refs+=['E7','E10']
        elif n==2121:support+=['Recorded replace-live-backend refusal; native return counter positive.'];waive+=['Zero closing-brace counter has no independent runtime action.'];refs+=['E3','E4','E10']
        elif n==3309:support+=['Network-only queued RX save retains usedRX0; exact captures retain clocks and do not quiesce.'];refs+=['E4','E8','E9']
        elif n==3344:support+=['Section 21 emitted and authenticated in actual native/browser frames.'];need+=['G1'];refs+=['E7','E8','E10']
        elif n in(3378,3383):support+=['New reset canonicalization is directly supported by paused section 7, prior restored-component equality and six resumed frame/trace equalities. Old native counters are explicitly excluded for these new statements.'];refs+=['E8','E9']
        elif h['new_count']==0:waive+=['Borrow moved into the same net snapshot block before the filter; this deletion has no additional execution action.'];refs+=['E8']
        elif n==3761:support+=['Presence/topology, staged whole-state validation and invalid checkpoint atomicity have counted old-identical lines and concrete worker cases.'];waive+=['Missing-clock ok_or is defensive: owned installation requires an active clock and strict clock validation precedes commit. Braces/closure syntax have no separate state action.'];refs+=['E4','E7','E10']
        elif n in(3801,4197,4328):support+=['Real section 21 topology and final staged restore commit; saved source counters plus exact frames/callback revocation witness.'];waive+=['Pattern-arm layout is representation, not another device action.'];refs+=['E4','E7','E8','E10']
        else:support+=['The nonfatal guard is reached in ordinary run.'];need+=['G1'];refs+=['E10']
    elif name=='crates/core/src/session_clock.rs':
        if n==19:waive+=['Error enum representation.']
        else:support+=['Ordinary preparation guard reached; fatal return not established in retained independent counters.'];need+=['G1'];refs+=['E10']
    elif name in('crates/core/src/resume.rs','crates/wasm/src/lib.rs'):waive+=['Section IDs/module declaration and exhaustive known/supported tags are declarative; actual section 21 frames and target builds authenticate use.'];refs+=['E2','E7']
    elif name=='crates/core/src/session_network.rs':support+=['Saved exact-source counters 281/299; all event forms, intents/results, callback identities, queue consumption/reset, provider gate and common-boundary success have concrete native/browser records. See functional subranges below.'];waive+=['Imports, types, constants, derives and closing syntax; unreachable non-Before public-call branch has no externally enterable quiescent state.'];need+=['G1','G2','G3','G5'];refs+=['E3','E4','E5','E7','E10']
    elif name=='crates/core/src/session_network/codec.rs':support+=['Saved exact-source counters 208/216; valid event/checkpoint forms, malformed field cases, conservation refusal, valid all-terms control and roundtrip are recorded.'];waive+=['Reader checked_add overflow is dominated by outer 4 MiB+16KiB bound and fixed/bounded reads; continuation-only line233 is part of the executed validation call.'];need+=['G1','G6'];refs+=['E3','E4','E7','E8','E10']
    elif name=='crates/wasm/src/session_network.rs':support+=['Actual built ordinary Wasm calls and 28 ABI cases support all used methods; exact new generated wrappers have positive V8 function counts except networkCursor.'];waive+=['Bindings/types and repeated try_borrow reentrancy plumbing: these synchronous methods invoke no guest-supplied callback while borrowed.'];need+=['G4'];refs+=['E5','E6']
    elif name.startswith(('crates/core/tests/','crates/jit-runtime/tests/')):support+=['Final worker target passes9 network tests or the real translated-edge target respectively. Native/browser raw frames, traces and prior independent arithmetic observations are retained. Test harness cfg/format/evidence-write plumbing is not asserted as guest runtime.'];refs+=['E2','E4','E7','E8','E9']
    elif name.startswith('tools/verify/')and not name.endswith('.listing'):support+=['Exact-source recorded producer commands, logs, output inventories and independent guest/object witnesses support the active producer path. Failure/catch/report plumbing is process accounting, not guest behavior. No producer was executed in this assessment.'];refs+=['E1','E2','E4','E5','E7']
    elif name=='Makefile':support+=['Recorded cold wrapper calls make verify-E9-T13; report lists all 24 commands and exact recipe source digest.'];refs+=['E1','E2']
    elif name in('web/session-network.js','web/dist/session-network.js'):support+=['Source-exact V8 shows every named function called; run succeeds and becomes/stays diverged for recorded missing/changed/extra tape. Error-status and cleanup qualifications remain explicit.'];need+=['G7'];refs+=['E5','E6']
    elif name in('web/session-inputs.js','web/dist/session-inputs.js'):
        support+=['Source-exact V8 and durable exported graph show channel20 validation, payload separation, write/read/rejoin and required network source in the valid prefix.'];refs+=['E5','E6','E7']
        if n in(61,93,138):need+=['G8']
        waive+=['Pre-existing time/device branches on the same changed line retain their earlier boundary; no unrelated replay requirement is introduced.']
    elif name in('web/network-capture-probe.js','web/dist/network-capture-probe.js'):support+=['All active named probe functions execute at exact source hash: five receipts, durable reopen, six offline replays,18 refusals and new conservation check.'];waive+=['Fixture assertions are failure-report plumbing; initial pre-existing-session deletion and final emergency writer-release branches are cleanup. The replay provider closure having count 0 is the measured positive suppression result.'];refs+=['E5','E6','E7']
    elif name in('web/main.js','web/dist/main.js'):support+=['Actual click, busy-state update, live pip/roadmap and shared regression clicks have source-exact V8 counts and screenshots.'];waive+=['Failed-label/regressed-pip presentation and disabled-control early returns are UI/logging defenses; they add no network semantics.'];refs+=['E5','E6']
    elif name=='web/dist/pkg/wasm_vm_wasm.js':
        if n==2084:support+=['Requests/replay-mode wrappers execute, but networkCursor is an entire zero-count function.'];need+=['G4']
        else:support+=['Generated new used wrapper and explicit lease-free methods have positive built V8 counts; source/target/build bytes are authenticated.']
        waive+=['Unused JS finalization fallback/GC callback branches are generated resource boilerplate; leases are explicitly freed in recorded code. Generated import/snippet numbering is representation.'];refs+=['E2','E5','E6']
    else:
        waive+=['Declarative/generated representation, documentation, pinned fixture bytes or task metadata; no separate T13 runtime action. The full listing/bin/ELF correspondence, source/dist identity, source hashes, frozen build artifacts and direct browser result authenticate the applicable representation.']
        refs+=['E1','E2','E5','E7']
        if name=='web/dist/pkg/wasm_vm_wasm_bg.wasm':need=[];waive+=['This representation waiver does not close the source/API gaps G1-G8.']
        if '/snippets/'in name:waive+=['Pre-existing invokeJitBlock/throwJitMemFault/invokeVirglControl function bytes only exchange generated inline module numbers; no new helper behavior is added. Worker-context execution is not inferred from page coverage.'];refs+=['E11']
    return result()

classified=[]
for file in data['files']:
    rows=[]
    for number,h in enumerate(file['hunks'],1):rows.append({'id':file['path']+'#'+str(number),**h,**rule(file['path'],h)})
    if not rows:rows=[{'id':file['path']+'#binary','header':'binary representation',**rule(file['path'],{'new_start':0,'new_count':0})}]
    classified.append({'path':file['path'],'hunks':rows})

assessment={'scope':{'base':data['base'],'head':data['head'],'excludes':'evidence directories; retained recordings are declarative evidence, not runtime diff','files':len(classified),'text_hunks':sum(len(f['hunks'])for f in data['files']),'verdict':'NO VERDICT; partial read-only sufficiency audit'},'evidence':evidence,'gaps':gaps,'files':classified}
(r/'changed-hunk-ledger.json').write_text(json.dumps(assessment,indent=2)+'\n')

lines=['# E9-T13 partial read-only changed-hunk ledger','',
       '**No verification verdict.** This source/saved-evidence audit leaves T13 blocked; it does not complete the independent execution charter or authorize publication. No VM/test binary or recorded producer was run. Existing raw coverage profiles and their executable object were decoded as data with LLVM tools; the object was never launched. No implementation, shared status, queue or commit changed.','',
       f'Scope: `{data["base"]}..{data["head"]}`, excluding evidence directories. There are 52 changed files and 156 textual hunks plus binary representations. Every hunk has an explicit classification, evidence citation, waiver and/or gap in `changed-hunk-ledger.json`; the table below indexes every file.','',
       'SUPPORTED means the cited recording/counter/frame supports the identified operation, not that every branch or the task is verified. WAIVED identifies a non-executable, generated, syntactic or narrowly dominated case with its reason. NEEDS EVIDENCE means a required execution claim has no retained point sufficient to close it; a zero in one saved recording is not a claim that the code never ran anywhere. Worker evidence and independently observed evidence are distinguished.','',
       '## Completed read-only reset assessment','',
       'The final packet manifest SHA 60304b99d0b98842aa4c5fbacc10025b82169927972fa08f2cd6365d66358d5b and report SHA e8976823db2791f96502b8da745360148f92647eb189d00ae43a4556c18280f5 authenticate 255 primary originals/gzip artifacts and 35 frozen source hashes. All 24 worker commands pass. This inspection did not rerun them.','',
       'Paused normal-reset checkpoint SHA 28e6b071904333fb5581e8f1cf41f9afe25f1329cab9d6263ddc6087751db736 is at transition/retired 1024, ordinal/sequence/cursor 2. Section 21 retains reset_pending 1, nextID 1, sent 0, empty pending/RX, link 0 and external_pending 0. UsedTX/RX=[1,0], guest report=[1,0,1]. Section 7 is 311 bytes with the two cache records encoded as ten zero bytes and counters[rx_dropped,tx_count,rx_count]=[0,1,0]. Its SHA ded04079b6bfd3de9987a2b67aaeaae17bd402e2e56a19df2356cd725755a6e2 matches the previous saved restored component exactly. The new filter agrees with existing service() at net.rs:574-578, which invalidates those views before use; it does not poll while saving.','',
       'All six recorded Record/Replay resumes at budgets 1/7/4096 have final frame SHA 446ff4e9c7d452fa1b9052268ad051ac58f40334c097e3f158a48639112007d0 and the same 8192-instruction trace SHA b277f17a4541496aeba08092dabf01059e788bcf491595368733ef87a63f8592. At trace lines 1478 and 3565 x6 reads IRQ0 from 0x10002060; final guest report=[1,0,0], cursor 2, reset_pending 0. New worker regression passes; its separately retained old-e91c linked run fails at the reset roundtrip. Those are worker regression observations, not an independent rerun.','',
       'Thirty-two previously HELD native/browser initial, pending and final frames, original traces and actual-JIT edge frames are byte-identical at 04f628. Prior independent CPU arithmetic/CAS/DMA/ordering observations carry across those exact unchanged boundaries. Historical conservation and normal-reset failures remain failures of their respective old revisions.','',
       '## Saved coverage boundary','',
       'Boundary QA accounts for all 52 files and 156 textual hunks. Seventeen of nineteen available source/dist pairs are byte-identical; app.html and sw.js contain generated deployment rewrites and are treated as declarative/generated representations. All 14 registry package identities and checksums in the saved native harness lock agree with the source lock. This static comparison neither installs dependencies nor reruns a recording. See boundary-qa.json.','',
       'The saved e91c independent native recording has eight passed tests and one normal-reset failure. Exact 101 runtime source/bench prefixes remain authenticated. Native counts are carried only through byte-identical contextual mappings; the new 04f628 reset filter is supported by E8/E9 instead, not old counters. Raw profiles, object SHA 54106c1ee6d409b85a8f717d6c09c37ffa3b96d65df1071c062398a2ebc8b204, merged profile, lcov and decoder diagnostics remain indexed in provenance. Diagnostics are empty. No whole-program/branch 100% claim is made.','',
       '| Changed native file | Positive/counted changed lines in saved independent records | Qualification |','| --- | --- | --- |']
for name,item in data['native'].items():lines.append(f'| `{name}` | {item["changed_positive"]}/{item["changed_counted"]} | Identical source contexts only; zero lines/complete maps in source-and-coverage.json; logical outcome gaps below still apply to positive checked-add lines. |')
lines+=['','Built V8 sources are matched byte-for-byte to frozen Git and offsets are UTF16, not Python codepoint indexes. All named session-network functions execute in the main network recording, while networkCursor has count 0 in generated bindings. GPU-only page coverage loads unused network modules; those zeros do not override positive main-page records. Inline app.html script records contain script bodies, not whole HTML, and are not misidentified as a stale full-page source. Their unmatchable whole-file comparison is excluded.','',
        'Native functional subranges: session_network.rs:1-118 declarations/representation are waived;119-172 validate/accept are supported except G1 exhaustion;176-219 max/normal TX/RX/idle supported with G1 error outcomes open;220-223 G2;224-231 reset supported;238-263 install success supported with G3 refusal gap;264-288 mode/provider/cursor supported;289-308 finish success/exhaustion-count mismatch supported with G1/G5 outcome gaps;310-374 request/lease/normal completion and stale/foreign intent checks supported, with G1/G5 entries open;375-431 exact replay/common success supported, with G5 queued-event/wrong-mode and G1 counter-exhaustion gaps. The internal non-Before guard is waived for the public quiescent synchronous assembly: no callback can enter halfway through a borrowed guest transition.','',
        'Codec functional subranges:1-79 bounded read/encode forms supported;80-123 normal decode/truncation/trailing supported with reserved/magic/outer-cap cases G6;127-157 checkpoint success supported with fatal-state G1;159-217 staged validation/conservation supported with specific G6 limits/relations unresolved;219-260 whole-machine validation/commit and incarnation replacement supported by atomic/lease and normal-reset recordings. Reader checked_add-overflow is dominated by bounded input/read sizes; closing continuation233 has no independent action.','',
        'Wasm bytes/strict counters/boolean/ordinal/shared-buffer/foreign lease refusals and ordinary methods are supported by 28 actual browser ABI cases. G4 remains for the unused cursor string wrapper. Repeated try_borrow guards are existing synchronous API plumbing, with no guest callback invoked under these method borrows; no new reentrant use is claimed. Generated declarations, finalizer fallbacks and reordered unchanged helper bodies have representation waivers, not new runtime behavior claims.','',
        '## Every changed file and hunk index','',
        '| File | Hunk new starts (count) | Classification | Citations / remaining gaps |','| --- | --- | --- | --- |']
for f in classified:
    hs=f['hunks'];kinds=sorted(set(x['classification']for x in hs));starts=', '.join(str(x.get('new_start','binary'))+'('+str(x.get('new_count','-'))+')'for x in hs)
    refs=sorted(set(z for x in hs for z in x['citations']));needs=sorted(set(z for x in hs for z in x['gaps']))
    lines.append('| `'+f['path']+'` | '+starts+' | '+'; '.join(kinds)+' | '+', '.join(refs+needs)+' |')
lines+=['','Per-hunk explanations, including positive support inside a NEEDS EVIDENCE file and explicit waiver reasons, are in changed-hunk-ledger.json. The JSON includes all 156 exact unified-zero headers and binary entries, so no generated/duplicate or deleted-only hunk disappears from the audit. Source/dist functional duplicates use the same evidence only after exact-byte matching.','',
        '## Concrete missing proof','']
for key,gap in gaps.items():
    lines+=['### '+key,'','Source: '+'; '.join('`'+x+'`'for x in gap['source'])+'.','',gap['observation'],'','Narrow missing proof: '+gap['missing'],'']
lines+=['## Evidence citations','', '| ID | Saved artifact | SHA256 / point |','| --- | --- | --- |']
for key,item in evidence.items():lines.append('| '+key+' | `'+item['path']+'` | `'+item['sha256']+'`; '+item['point']+' |')
lines+=['','## Handoff limits','',
        'No new attack, VM/test execution, producer rerun, sensitivity test, alternate model/session or shared write occurs in this bounded task. Static LLVM coverage-data decoding is distinct from launching the recorded object. This partial sufficiency audit is useful evidence accounting; it cannot substitute for the unfinished independent charter. Existing stopped-execution records, the two repaired findings, all original data and the external publication/account-authorization gap remain preserved. No dependent E9 task is cleared and no verified verdict is issued.','']
(r/'changed-hunk-ledger.md').write_text('\n'.join(lines))

inputs=[c/'coverage-preparation.json',c/'normal-native.log',c/'normal-coverage-receipt.json',c/'normal-first-attempt/critic.rs',c/'harness/tests/critic.rs',c/'guest-oracle.json',c/'authentication.json',c/'coverage-target/debug/deps/critic-a2812715fe550f16',
        c/'profiles/normal-12566-7532279334979752817_0.profraw',c/'profiles/reset-12805-7532279334979752817_0.profraw',c/'profiles/reset-12807-7532279334979752817_0.profraw',
        proof/'report.json',proof/'network-and-session-native.log',proof/'browser/report.json',proof/'browser/javascript-coverage.json',proof/'retained-gpu-browser/report.json',proof/'retained-gpu-browser/javascript-coverage.json',
        proof/'native/normal-reset-paused.resume',proof/'native/normal-reset-final.resume',proof/'native/normal-reset-original.trace',repo/'evidence/e9-t13/worker-reset-final/provenance.json',repo/'evidence/e9-t13/worker-reset-finding/provenance.json']
outputs=[p for p in sorted(r.iterdir())if p.is_file()and p.name!='provenance.json']
rows=lambda paths:[{'path':str(p),'size':p.stat().st_size,'sha256':sha(p)}for p in paths]
provenance={'kind':'T13 partial read-only changed-hunk sufficiency assessment','created':time.time(),'base':data['base'],'head':data['head'],'files':52,'text_hunks':156,'no_verdict':True,
            'restrictions':'No VM/test binary or recorded producer launched; no new attack or security-stopped retry. Only source and saved evidence inspected. LLVM utilities read the prior object/counters as coverage data; the object is never executed. Shared implementation/status/queue/index untouched.',
            'inputs':rows(inputs),'artifacts':rows(outputs),'remaining_gaps':list(gaps),
            'data_decoding_commands':['llvm-profdata merge -sparse normal-12566-7532279334979752817_0.profraw reset-12805-7532279334979752817_0.profraw reset-12807-7532279334979752817_0.profraw -o saved-native.profdata','llvm-cov export critic-a2812715fe550f16 -instr-profile=saved-native.profdata -format=lcov','python3 -B analyze_saved_records.py (source/hash/JSON/counter mapping only)','python3 -B build_ledger.py (authored assessment only)']}
(r/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(json.dumps({'ledger_sha256':sha(r/'changed-hunk-ledger.md'),'json_sha256':sha(r/'changed-hunk-ledger.json'),'provenance_sha256':sha(r/'provenance.json'),'artifacts':len(outputs),'gaps':list(gaps)}))
