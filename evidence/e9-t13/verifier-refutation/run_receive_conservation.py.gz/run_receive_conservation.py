from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent
deps=Path('/Volumes/e9-final-proof-ram/cold-target-e9-t13-43031d92822b/debug/deps')
core=deps/'libwasm_vm_core-ae3fa3a83363b55a.rlib'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env={k:v for k,v in os.environ.items()if not k.startswith('CARGO_')and k not in('RUSTFLAGS','RUSTDOCFLAGS','RUST_LOG','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER')}
env['TMPDIR']='/Volumes/e9-final-proof-ram/deploy-tmp/'
command=['/Users/blamy/.rustup/toolchains/1.96.0-aarch64-apple-darwin/bin/rustc','--edition=2024','--test',str(r/'receive_conservation.rs'),'-L','dependency='+str(deps),'--extern','wasm_vm_core='+str(core),'-o',str(r/'receive-conservation')]
receipt={'head':'43031d92822be59b8ddd15a599428194dc1470aa','compile':command,'source_sha256':sha(r/'receive_conservation.rs'),'core_rlib_sha256':sha(core),'started':time.time(),'runs':[]}
with(r/'receive-conservation-build.log').open('wb')as log:built=subprocess.run(command,env=env,stdout=log,stderr=log)
receipt['build_exit_code']=built.returncode
assert built.returncode==0
for label in['first','recheck']:
    env['T13_CRITIC_OUTPUT']=str(r/('receive-conservation-'+label))
    with(r/('receive-conservation-'+label+'.log')).open('wb')as log:run=subprocess.run([str(r/'receive-conservation'),'--nocapture'],env=env,stdout=log,stderr=log)
    receipt['runs'].append({'label':label,'exit_code':run.returncode,'log_sha256':sha(r/('receive-conservation-'+label+'.log'))})
receipt['binary_sha256']=sha(r/'receive-conservation');receipt['finished']=time.time()
(r/'receive-conservation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt['runs']))
