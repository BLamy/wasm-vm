# Compound checkpoint attack, declared before execution

Every accepted Send increases `sent` and `cursor` once; every queued Receive also
required one distinct cursor increment. Therefore every reachable state satisfies
`sent + queued_receive_count <= cursor`, including reset (which only removes queued
RX), save and restore. I predict that a frame with one already acknowledged send,
cursor1 and an additional queued RX frame will refuse before mutation. Accepting it,
delivering its bytes to guest DMA and successfully finishing replay at cursor1
would admit an observation with no source event. This tests the new persistence
boundary and the claim that exhausted/missing network observations stop replay.

The probe will use the pinned guest, generate its real TX, acknowledge that TX once,
save the exact whole frame and append only one RX entry to section21. Clock, RAM,
virtqueues, acknowledgement and all other fields remain byte-identical. Preserve
both original and mutant frames; recheck any contradiction before reporting it.
