from pathlib import Path
import gzip,hashlib,json,shutil,time
root=Path(__file__).resolve().parent
dest=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed/evidence/e9-t13/verifier-refutation')
dest.mkdir(parents=True,exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[]
for path in sorted(root.rglob('*')):
    rel=path.relative_to(root)
    if not path.is_file()or any(part=='__pycache__'or part.endswith('.dSYM')for part in rel.parts):continue
    raw=path.read_bytes();target=dest/(str(rel)+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('wb')as stream:
        with gzip.GzipFile(filename='',fileobj=stream,mode='wb',compresslevel=9,mtime=0)as zipped:zipped.write(raw)
    compressed=target.read_bytes();assert gzip.decompress(compressed)==raw
    rows.append({'original':str(path),'relative':str(rel),'size':len(raw),'sha256':sha(raw),'mode':oct(path.stat().st_mode&0o777),'gzip':str(target.relative_to(dest)),'gzip_bytes':len(compressed),'gzip_sha256':sha(compressed)})
for name in['ledger.md','predictions.md']:shutil.copyfile(root/name,dest/name)
data={'task':'E9-T13','verdict':'refuted','runtime':'43031d92822be59b8ddd15a599428194dc1470aa','claim':'de83cc42af476d963f616a6bae65603c99034394','created':time.time(),'files':rows,'scope':'First independent conservation refutation plus original pre-inspection predictions, authenticated held happy-path observations, exact independent decoder and original/refutation code/frames/guest traces. No original removed. Further read-only critique continues separately.','excluded':'Python bytecode and derived dSYM bundles remain on RAM; self-contained repro executables are included. Exact final cold core rlib hash and source/build provenance are preserved; no dependency substituted.','worker_primary_sha256':'800d1348c378f950d2457cde1e8cca1b69bd89280461b5d69b2539bf39b20576','worker_full_sha256':'9c47b24009b2bc81d442ff0fb9b17f6d01732152299ddc68a15a264e6b089638'}
(dest/'provenance.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'entries':len(rows),'gzip_bytes':sum(r['gzip_bytes']for r in rows),'provenance_sha256':sha((dest/'provenance.json').read_bytes())}))
