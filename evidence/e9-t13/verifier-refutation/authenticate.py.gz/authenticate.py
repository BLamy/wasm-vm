from pathlib import Path
import hashlib, gzip, json, subprocess, time

out = Path(__file__).resolve().parent
repo = Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
head = '43031d92822be59b8ddd15a599428194dc1470aa'
proof = Path('/Volumes/e9-final-proof-ram/cold-proof-e9-t13-43031d92822b')
packet = repo / 'evidence/e9-t13/worker-final'
full = Path('/Volumes/e9-final-proof-ram/e9-t13-full-archive')

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

expected = {packet/'provenance.json': '800d1348c378f950d2457cde1e8cca1b69bd89280461b5d69b2539bf39b20576',
            full/'provenance.json': '9c47b24009b2bc81d442ff0fb9b17f6d01732152299ddc68a15a264e6b089638',
            proof/'report.json': '67cf9b564a4bf01ae254dba5d0642abeed45d4179645644b960c98c3d20436ae'}
for path, digest in expected.items():
    assert sha(path) == digest, path
inventory = {}
for root in [packet, full]:
    data = json.loads((root/'provenance.json').read_text())
    assert data['status'] == 'passed' and data['head'] == head
    for row in data['files']:
        original = Path(row['original_path'])
        compressed = root / row['gzip']
        assert sha(original) == row['original_sha256'] and original.stat().st_size == row['original_bytes'], original
        assert sha(compressed) == row['gzip_sha256'] and compressed.stat().st_size == row['gzip_bytes'], compressed
        h = hashlib.sha256(); n = 0
        with gzip.open(compressed, 'rb') as stream:
            for block in iter(lambda: stream.read(1048576), b''):
                h.update(block); n += len(block)
        assert h.hexdigest() == row['original_sha256'] and n == row['original_bytes'], compressed
    inventory[str(root)] = len(data['files'])
report = json.loads((proof/'report.json').read_text())
assert report['head'] == head and report['status'] == 'passed'
assert len(report['commands']) == 24 and all(row['exit_code'] == 0 for row in report['commands'])
for row in report['files']:
    path = proof / row['path']
    assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes'], path
source = Path('/Volumes/e9-final-proof-ram/cold-source-e9-t13-43031d92822b')
for name, digest in report['source_sha256'].items():
    body = subprocess.check_output(['git', 'show', head+':'+name], cwd=repo)
    assert hashlib.sha256(body).hexdigest() == digest == sha(source/name) == sha(repo/name), name
contract = json.loads((repo/'docs/design/session-replay-contract.json').read_text())
def digest_maps(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if isinstance(item, str) and len(item) == 64 and '/' in key and (repo/key).is_file():
                yield key, item
            else:
                yield from digest_maps(item)
    elif isinstance(value, list):
        for item in value: yield from digest_maps(item)
boundary = dict(digest_maps(contract))
for name, digest in boundary.items(): assert sha(repo/name) == digest, name
origin = json.loads((Path('/Volumes/e9-final-proof-ram/cold-worker-e9-t13-43031d92822b')/'receipt.json').read_text())
assert origin['status'] == 'passed' and origin['head'] == head
assert origin['source_sha256'] == report['source_sha256']
assert origin['compiler_storage']['initial_entries'] == []
assert origin['compiler_storage']['no_inherited_compiler_cache'] and origin['compiler_storage']['no_inherited_node_modules']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip() == head
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=source)
metadata = Path(origin['git_metadata'])
assert (metadata/'objects/info/alternates').read_text().strip() == origin['git_object_storage']['parent_objects']
with (out/'cold-fsck.log').open('wb') as log:
    result = subprocess.run(['git','fsck','--connectivity-only','--no-reflogs'],cwd=source,stdout=log,stderr=log)
assert result.returncode == 0
browser = json.loads((proof/'browser/report.json').read_text())
assert browser['head'] == head and browser['status'] == 'passed' and not browser['development'] and not browser['errors']
for row in browser['assets']:
    assert sha(repo/'web/dist'/row['name']) == row['sha256'], row['name']
    assert hashlib.sha256(subprocess.check_output(['git','show',head+':web/dist/'+row['name']],cwd=repo)).hexdigest() == row['sha256']
gpu = json.loads((proof/'retained-gpu-browser/report.json').read_text())
assert gpu['head'] == head and gpu['status'] == 'passed' and not gpu['errors']
data = {'status':'passed', 'head':head, 'created':time.time(), 'authenticated_provenance':{str(k):v for k,v in expected.items()},
        'compressed_raw_inventory':inventory, 'raw_report_files':len(report['files']),
        'source_files':len(report['source_sha256']), 'boundary_files':len(boundary),
        'cold_origin':{k:v for k,v in origin.items() if k not in ('files','source_sha256')},
        'browser_checks':browser['checks'], 'transport_witness':browser['transportWitness'],
        'gpu_report_sha256':sha(proof/'retained-gpu-browser/report.json')}
(out/'authentication.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'status':'passed','inventories':inventory,'source_files':len(report['source_sha256']),'boundary_files':len(boundary)}))
