from pathlib import Path
import gzip, hashlib, json, re, struct

root=Path(__file__).resolve().parent
proof=Path('/Volumes/e9-final-proof-ram/cold-proof-e9-t13-43031d92822b')
repo=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
sha=lambda b:hashlib.sha256(b).hexdigest()
class Reader:
    def __init__(self,b):self.b,self.i=b,0
    def take(self,n):
        assert n>=0 and self.i+n<=len(self.b)
        value=self.b[self.i:self.i+n];self.i+=n;return value
    def n(self,f):return struct.unpack('<'+f,self.take(struct.calcsize('<'+f)))[0]
    def blob(self):return self.take(self.n('I'))
    def end(self):assert self.i==len(self.b)

def decode(raw):
    r=Reader(raw);assert r.take(12)==b'WVMRESU1\1\0\0\0';r.take(72);sections={}
    while r.i<len(raw):
        tag=r.n('I');assert tag not in sections;sections[tag]=r.blob()
    r.end();ram=bytearray();r=Reader(sections[2])
    while r.i<len(r.b):
        kind,n=r.n('B'),r.n('I');assert kind in(0,1)and 0<n<=16<<20
        ram.extend(r.take(n)if kind else bytes(n))
    r.end();assert len(ram)in(1<<20,16<<20)
    r=Reader(sections[18]);assert r.take(12)==b'WVCLK001\1\0\0\0'
    clock=dict(zip(['transition','retired','ordinal','sequence','ticket'],[r.n('Q')for _ in range(5)]));phase=r.n('B');assert phase==0 and r.n('B')==0 and r.n('I')==0;r.end()
    r=Reader(sections[21]);assert r.take(8)==b'WVNETS01'
    network=dict(zip(['next_id','cursor','sent'],[r.n('Q')for _ in range(3)]))
    network.update(link=r.n('B'),external_pending=r.n('B'),kicked=r.n('B'),reset_pending=r.n('B'),code=r.n('I'))
    network['pending']=[{'id':r.n('Q'),'frame_hex':r.blob().hex()}for _ in range(r.n('I'))]
    network['receive']=[r.blob().hex()for _ in range(r.n('I'))];r.end()
    u16=lambda at:struct.unpack_from('<H',ram,at)[0]
    u64=lambda at:struct.unpack_from('<Q',ram,at)[0]
    return {'sha256':sha(raw),'clock':clock,'network':network,'used':[u16(0x22002),u16(0x12002)],'guest_report':[u64(0x40000+i*8)for i in range(3)],'sections':{str(k):len(v)for k,v in sections.items()}},bytes(ram),sections

def envelope(raw):
    r=Reader(raw);assert r.take(8)==b'WVNETE01';tag=r.n('B');d={'tag':tag};payload=b''
    if tag==1:d.update(result=r.n('B'),id=r.n('Q'));payload=r.blob()
    elif tag==2:payload=r.blob()
    elif tag==3:d.update(id=r.n('B'),result=r.n('I'))
    elif tag==4:d['result']=r.n('B')
    else:assert False
    r.end();d.update(payload_hex=payload.hex(),payload_sha256=sha(payload),payload_bytes=len(payload));return d

http=b'GET /network-probe-response.json HTTP/1.1\r\nHost: session-probe\r\nConnection: close\r\n\r\n'
expected_tx=bytes.fromhex('02000000000152540012345688b5')+http
expected_positions=[(0,0,1,1),(1024,1024,1,2),(1024,1024,2,3),(1121,1121,1,4),(1137,1137,1,5)]
program=(repo/'web/assets/e9-network-capture.bin').read_bytes()

def audit(directory,browser):
    initial,_,_=decode((directory/'initial.resume').read_bytes())
    pending,_,_=decode((directory/'pending.resume').read_bytes())
    final,ram,sections=decode((directory/'final.resume').read_bytes())
    assert initial['clock']['transition']==initial['clock']['sequence']==initial['network']['cursor']==0
    assert pending['clock']['transition']==pending['clock']['retired']==1024
    assert pending['clock']['sequence']==pending['network']['cursor']==1 and pending['used']==[1,0]
    assert pending['network']['pending']==[{'id':1,'frame_hex':expected_tx.hex()}]
    assert final['clock']['transition']==final['clock']['retired']==9216
    assert final['clock']['sequence']==final['network']['cursor']==5
    assert final['network']['next_id']==final['network']['sent']==1
    assert final['network']['pending']==final['network']['receive']==[]
    assert final['network']['link']==2 and not final['network']['external_pending'] and final['network']['code']==0
    assert final['used']==[1,1]and final['guest_report']==[1,1,1]
    rx=(directory/'receive-frame.bin').read_bytes();response=(directory/'http-response.bin').read_bytes()
    assert rx[:14]==bytes.fromhex('52540012345602000000000188b5')and rx[14:]==response
    header,body=response.split(b'\r\n\r\n',1);assert header.startswith(b'HTTP/1.1 200 OK\r\n')
    assert int(re.search(rb'Content-Length: (\d+)',header)[1])==len(body)and b'Connection: close'in header
    assert json.loads(body)=={'count':1,'source':'original-counter'}
    assert ram[0x14000:0x1400c]==bytes(10)+b'\1\0'
    assert ram[0x1400c:0x1400c+len(rx)]==ram[0x40000+44:0x40000+44+len(rx)]==rx
    guest=(directory/('guest.bin'if browser else'guest-report.bin')).read_bytes();assert guest==ram[0x40000:0x40420]
    lines=(directory/'original.trace').read_text().splitlines();assert len(lines)==9216
    witnesses=[]
    for i,line in enumerate(lines):
        m=re.match(r'core 0: 0x([0-9a-f]+) \(0x([0-9a-f]+)\)',line);assert m
        index=i if i<390 else 390+(i-390)%2087
        assert int(m[1],16)==0x80000000+index*4 and int(m[2],16)==struct.unpack_from('<I',program,index*4)[0]
        if i>1121 and any(f'mem 0x{x:016x}'in line for x in [0x80012002,0x80022002,0x10002060,0x8001400c,0x80040000]):witnesses.append({'line':i+1,'text':line})
    events=[]
    if browser:
        probe=json.loads((directory/'probe.json').read_text());manifest=json.loads((directory/'manifest.json').read_text())
        assert len(probe['receipts'])==5
        for receipt,position in zip(probe['receipts'],expected_positions):
            raw=(directory/receipt['bytes']['file']).read_bytes();assert sha(raw)==receipt['bytes']['sha256']
            assert (int(receipt['transition']),int(receipt['retired']),receipt['ordinal'],int(receipt['sequence']))==position and receipt['phase']=='before'
            events.append(envelope(raw))
        encoded=[]
        for item in probe['persisted']['objects']:
            raw=(directory/item['bytes']['file']).read_bytes();assert sha(raw)==item['ref']['sha256']and str(len(raw))==item['ref']['length']
        for index in manifest['events']:
            raw=(directory/'objects'/index['content']['sha256']).read_bytes();assert sha(raw)==index['content']['sha256'];encoded.extend(json.loads(raw))
        assert len(encoded)==5
        for entry,event,position in zip(encoded,events,expected_positions):
            intent=json.loads(bytes(entry['intent']));assert intent['channel']==20 and entry['kind']=='network'and entry['device']=='virtio-net'
            if entry['payload']['storage']=='blob':
                ref=entry['payload']['content'];payload=(directory/'objects'/ref['sha256']).read_bytes();assert sha(payload)==ref['sha256']and str(len(payload))==ref['length']
            else:payload=bytes(entry['payload']['bytes'])
            assert envelope(bytes(intent['header'])+payload)==event
            assert (int(entry['transition']),int(entry['retired']),entry['ordinal'],int(entry['sequence']))==position
        for replay in probe['replays']:
            assert(directory/replay['frame']['file']).read_bytes()==(directory/'final.resume').read_bytes()
    else:
        assert (directory/'http-request.bin').read_bytes()==http
        r=Reader((directory/'network-envelopes.bin').read_bytes())
        while r.i<len(r.b):events.append(envelope(r.blob()))
        assert [tuple(map(int,line.split()))for line in(directory/'network-positions.tsv').read_text().splitlines()]==expected_positions
    assert [e['tag']for e in events]==[3,1,4,2,3]
    assert events[0]['id']==1 and events[1]['id']==1 and events[1]['result']==0 and events[2]['result']==1 and events[4]['id']==2
    assert events[1]['payload_hex']==expected_tx.hex()and events[3]['payload_hex']==rx.hex()
    for q in(1,7,4096):
        for start in(False,True):assert(directory/f'replay-{q}-pending-{str(start).lower()}.trace').read_text().splitlines()==lines[1024 if start else 0:]
    return {'initial':initial,'pending':pending,'final':final,'events':events,'trace_sha256':sha((directory/'original.trace').read_bytes()),'witnesses':witnesses}

if __name__=='__main__':
    result={name:audit(proof/name,name=='browser')for name in['native','browser']};matrix=[]
    for kind in['native','browser']:
        for target in[5000,5001,5002]:
            full,remainder=divmod(target-390,6)
            expected=[(full+(i<remainder))*increment for i,increment in enumerate([1,3,5,7,11])]
            frames=[]
            for quantum in[31,1,8,4096]:
                path=proof/('native/jit-network-target'+str(target)+'-q'+str(quantum)+'.resume'if kind=='native'else'browser/jit/target'+str(target)+'-q'+str(quantum)+'.resume.gz')
                raw=path.read_bytes();raw=gzip.decompress(raw)if kind=='browser'else raw;frames.append(raw)
                state,_,sections=decode(raw);cpu=sections[1];pc=struct.unpack_from('<Q',cpu)[0];values=[struct.unpack_from('<Q',cpu,i*8)[0]for i in range(20,25)]
                assert values==expected and pc==0x80000000+(390+remainder)*4
                assert state['clock']['transition']==state['clock']['retired']==target and state['network']['cursor']==1
                matrix.append({'kind':kind,'target':target,'quantum':quantum,'frame_sha256':sha(raw),'pc':hex(pc),'x20_x24':values})
            assert all(frame==frames[0]for frame in frames)
    result['jit']=matrix
    (root/'guest-oracle.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'passed','native_final':result['native']['final']['sha256'],'browser_final':result['browser']['final']['sha256'],'jit_cpu_witnesses':len(matrix)}))
