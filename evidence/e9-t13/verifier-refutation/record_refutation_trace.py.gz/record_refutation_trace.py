from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent;deps=Path('/Volumes/e9-final-proof-ram/cold-target-e9-t13-43031d92822b/debug/deps');core=deps/'libwasm_vm_core-ae3fa3a83363b55a.rlib'
original=(r/'receive_conservation.rs').read_text()
before='fn run(m:&mut Machine,t:u64){while m.session_position().unwrap().transition<t{assert_eq!(m.run_session_until(t,31),Ok(RunOutcome::MaxInstrs));}}'
after='''#[derive(Default)] struct Trace(String);
impl wasm_vm_core::trace::TraceSink for Trace {fn retire(&mut self,r:&wasm_vm_core::trace::TraceRecord){self.0.push_str(&wasm_vm_core::trace::fmt_canonical(r).to_string());self.0.push('\\n');}}
fn run(m:&mut Machine,t:u64){let mut trace=Trace::default();while m.session_position().unwrap().transition<t{assert_eq!(m.run_session_until_traced(t,31,&mut trace).unwrap(),RunOutcome::MaxInstrs);}std::fs::write(std::path::Path::new(&std::env::var("T13_CRITIC_OUTPUT").unwrap()).join(format!("to-{t}.trace")),trace.0).unwrap();}'''
assert original.count(before)==1
source=original.replace(before,after);(r/'receive_conservation_trace.rs').write_text(source)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
command=['/Users/blamy/.rustup/toolchains/1.96.0-aarch64-apple-darwin/bin/rustc','--edition=2024','--test',str(r/'receive_conservation_trace.rs'),'-L','dependency='+str(deps),'--extern','wasm_vm_core='+str(core),'-o',str(r/'receive-conservation-trace')]
env={k:v for k,v in os.environ.items()if not k.startswith('CARGO_')and k not in('RUSTFLAGS','RUSTDOCFLAGS','RUST_LOG','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER')};env['TMPDIR']='/Volumes/e9-final-proof-ram/deploy-tmp/'
receipt={'head':'43031d92822be59b8ddd15a599428194dc1470aa','compile':command,'source_sha256':sha(r/'receive_conservation_trace.rs'),'core_rlib_sha256':sha(core),'started':time.time(),'runs':[]}
with(r/'receive-conservation-trace-build.log').open('wb')as log:built=subprocess.run(command,env=env,stdout=log,stderr=log)
assert built.returncode==0
for label in['trace-first','trace-recheck']:
    directory=r/('receive-conservation-'+label);directory.mkdir()
    env['T13_CRITIC_OUTPUT']=str(directory)
    with(r/('receive-conservation-'+label+'.log')).open('wb')as log:run=subprocess.run([str(r/'receive-conservation-trace'),'--nocapture'],env=env,stdout=log,stderr=log)
    trace=(directory/'to-9216.trace').read_text().splitlines();assert len(trace)==8192
    points=[{'file':str(directory/'to-9216.trace'),'line':i+1,'transition_before':1024+i,'text':line}for i,line in enumerate(trace)if any('mem 0x'+f'{x:016x}'in line for x in[0x8001400c,0x8004002c])]
    assert points
    receipt['runs'].append({'label':label,'exit_code':run.returncode,'log_sha256':sha(r/('receive-conservation-'+label+'.log')),'trace_sha256':sha(directory/'to-9216.trace'),'points':points})
receipt['binary_sha256']=sha(r/'receive-conservation-trace');receipt['finished']=time.time()
(r/'receive-conservation-trace-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'runs':[{'label':x['label'],'exit_code':x['exit_code'],'first_points':x['points'][:2]}for x in receipt['runs']]}))
