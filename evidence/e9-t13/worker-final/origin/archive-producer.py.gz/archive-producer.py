from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,time
head='43031d92822be59b8ddd15a599428194dc1470aa';mount=Path('/Volumes/e9-final-proof-ram')
proof=mount/('cold-proof-e9-t13-'+head[:12]);wrapper=mount/('cold-worker-e9-t13-'+head[:12])
assert json.loads((proof/'report.json').read_text())['status']=='passed'
assert json.loads((wrapper/'receipt.json').read_text())['status']=='passed'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'])
full=mount/'e9-t13-full-archive';primary=Path('evidence/e9-t13/worker-final')
full.mkdir(exist_ok=False);primary.mkdir(parents=True,exist_ok=False)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for block in iter(lambda:f.read(1<<20),b''):h.update(block)
 return h.hexdigest()
files=[];origins=[]
def archive(src,name):
 dest=full/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True)
 with src.open('rb')as source,dest.open('wb')as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6)as target:shutil.copyfileobj(source,target,1<<20)
 h=hashlib.sha256();n=0
 with gzip.open(dest,'rb')as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b);n+=len(b)
 assert n==src.stat().st_size and h.hexdigest()==sha(src)
 entry={'original_path':str(src.resolve()),'path':name,'original_bytes':n,'original_sha256':h.hexdigest(),'gzip':str(dest.relative_to(full)),'gzip_bytes':dest.stat().st_size,'gzip_sha256':sha(dest)}
 files.append(entry)
 if 'chromium-profile'not in Path(name).parts:
  other=primary/entry['gzip'];other.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dest,other);assert sha(other)==entry['gzip_sha256']
for p in sorted(proof.rglob('*')):
 if p.is_file():archive(p,'acceptance/'+str(p.relative_to(proof)))
inputs={
 'cold-wrapper-receipt.json':wrapper/'receipt.json','cold-wrapper-commands.log':wrapper/'commands.log',
 'cold-producer.py':mount/'e9-t13-repaired-frozen-cold-wrapper.py','cold-wrapper.log':mount/'e9-t13-repaired-frozen-cold-wrapper.log',
 'bash-runtime-receipt.json':Path('/Volumes/e9-t11-cold-scratch/bash-tools/receipt.json'),
 'emsdk-ram-copy-receipt.json':Path('/Volumes/e9-t11-cold-scratch/e9-t12-emsdk-ram-copy.json'),
 'withdrawn-submission-stop.json':mount/'e9-t13-first-submission-stop.json',
 'withdrawn-wrapper-receipt.json':mount/'cold-worker-e9-t13-abb77eb06a7e/receipt.json',
 'withdrawn-report.json':mount/'cold-proof-e9-t13-abb77eb06a7e/report.json',
 'withdrawn-producer.py':mount/'e9-t13-frozen-cold-wrapper.py',
 'withdrawn-wrapper.log':mount/'e9-t13-frozen-cold-wrapper.log',
}
for name,src in inputs.items():archive(src,'origin/'+name)
diff=mount/'e9-t13-runtime-diff.patch'
with diff.open('wb')as f:subprocess.run(['git','diff','--binary','76cc2c8dc1df4b17572bf09c73618e10ad848d63',head],stdout=f,check=True)
archive(diff,'origin/runtime-diff.patch')
archive(Path(__file__),'origin/archive-producer.py')
common={'task':'E9-T13','status':'passed','head':head,'created':time.time(),'producer_sha256':sha(Path(__file__)),'original_recording':str(proof),'original_wrapper':str(wrapper),
 'scope':'All final guest traces, full machine frames, HTTP request/response and transport witnesses, durable immutable object graphs, recorded Playwright traces/captures/coverage and exact-head cold-build logs are retained losslessly. The withdrawn original runtime was not submitted; its interrupted receipt and repair reason are included. No authentication logs or credentials are archived.',
 'files':files,'original_bytes':sum(e['original_bytes']for e in files),'compressed_bytes':sum(e['gzip_bytes']for e in files)}
(full/'provenance.json').write_text(json.dumps(common,indent=2)+'\n')
kept=[e for e in files if 'chromium-profile'not in Path(e['path']).parts]
(primary/'provenance.json').write_text(json.dumps({**common,'files':kept,'full_archive':str(full),'full_archive_provenance_sha256':sha(full/'provenance.json'),'deferred_derived_profiles':[e for e in files if e not in kept],
 'scope':common['scope']+' Derived Chromium GPU profile/cache files are inventoried separately; their original and authenticated gzip bytes remain in the full RAM archive. No claim relies on a private unexported database.',
 'primary_original_bytes':sum(e['original_bytes']for e in kept),'primary_compressed_bytes':sum(e['gzip_bytes']for e in kept)},indent=2)+'\n')
print(json.dumps({'primary':str(primary),'sha256':sha(primary/'provenance.json'),'files':len(kept),'gzip_bytes':sum(e['gzip_bytes']for e in kept),'full_archive_sha256':sha(full/'provenance.json')}))
