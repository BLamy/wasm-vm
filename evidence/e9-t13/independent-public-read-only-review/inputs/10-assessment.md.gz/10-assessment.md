# T13 WFI incremental read-only assessment

**No task verification verdict.** The new saved WFI states support the repair, and the additional worker recordings answer the narrow G1–G8 component requests with the qualifications below. G9 and P13 remain unresolved. No independent execution is claimed.

Source-first scope: `04f628dd02a0bf57331682e05607829e25a0ca46..2f2aa7aba484f6954ca04358385828093e561b83`; metadata HEAD `d454fc78f0b32baa59c175541e73fc660fb23cfb`. The runtime change is the owned-network pending predicate in session_clock.rs:650. The 19-file delta has 39 textual hunks; exact headers/classifications are in assessment.json. The prior 52-file/156-hunk ledger remains unchanged and is incrementally qualified here.

## Authentication and attribution

Authenticated 923 primary gzip/original pairs, 199 preserved red packet entries, 508 main and 195 supplementary inventory files, and 37 frozen source hashes against Git and the current source. All original primary/red paths were checked when present; availability is explicit per entry in authentication.json. All 25 main worker commands and all supplementary commands passed. The cold receipt records an initially empty compiler target and no inherited node_modules, with independent source/refs/index and disclosed read-only Git object sharing. This is recorded worker environment evidence, not a newly executed cold clone.

Independently compared all 180 supplementary native overlaps with the main cold recording: every byte matches. The two existing 9/new 8 objects and their raw profiles/exports remain separately attributable. Twelve JIT inputs are explicitly carried from the SAME frozen main recording and are not labelled rerun. Thirty-two previously HELD happy-path/JIT artifacts remain byte-identical; source/dependency changes are confined to the reviewed predicate/harness/declarative delta. This carries the prior concrete arithmetic/frame/trace observations, not a blanket claim that all runtime source is unchanged.

## Predicted WFI states

Predictions were saved before new reports/frames/traces/coverage were opened. Native cases execute at 0x80060000 for two transitions. With pending work: WFI+ADDI retire, x1=1, PC 0x80060008. Without it: only WFI retires, x1=0, PC 0x80060004, mtime 1000000. All saved original/restored pairs match completely.

| Native guest TX | Pending | Begin retired | End retired | End mtime | x1 |
| --- | --- | --- | --- | --- | --- |
| false | false | 0 | 1 | 1000000 | 0 |
| false | true | 0 | 2 | 2 | 1 |
| true | false | 1024 | 1025 | 1000000 | 0 |
| true | true | 1024 | 1026 | 1026 | 1 |

| Built-browser guest TX | Pending | End transition | End retired | End mtime | x1 |
| --- | --- | --- | --- | --- | --- |
| False | False | 6 | 5 | 1000000 | 0 |
| False | True | 6 | 6 | 6 | 1 |
| True | False | 396 | 395 | 1000000 | 0 |
| True | True | 396 | 396 | 396 | 1 |

Concrete native point: `/Volumes/e9-t13-wfi-cold/cold-proof-e9-t13-2f2aa7aba484/native/components/wfi-txfalse-pendingtrue.trace:1–2`, SHA256 `aba6749203441db6a938ffbb767dad9aa7ddfbd307d9cc734afa885e2b4cc8ea`: WFI then ADDI. Final frame SHA256 `8023fafe9ab5b2ff7e65a941f7675f735edccc78124199a97ba23623ccfea822`. Browser point: `/Volumes/e9-t13-wfi-cold/cold-proof-e9-t13-2f2aa7aba484/browser/idle/txfalse-pendingtrue-original.trace:5–6`, SHA256 `b195e0c0932be14000df3e6278fd2245c786a8955ff84ed9d653595dd6799cd5`: the same WFI/ADDI after the four timer-setup words. All case/frame/trace digests and decoded fields are retained in decoded-observations.json.

The preserved 04f628 red pending=true frame is transition 2/retired 1/mtime 1000000/x1=0, SHA256 b599fcbe8b7af9d2b864244d97b5696bcc17e32b02591f43bd3b59c753cfe16e. Its trace:1 contains only WFI, SHA256 191bc787c07d102613e354ab7a1ed05fb58e8c5f8bae8be4ced9e5e2daf4bf6c. The corrected worker-v2 receipt remains exit 101. The earlier budget-target harness failure is separately preserved, not used as this semantic observation.

## G1–G8 evidence ledger

### G1 — SUPPORTED + justified waivers

Source: session_network.rs:119–142,180–208,289–331; session_clock.rs:625–628; lib.rs:3344–3350,6504–6509; session_network/codec.rs:132–135.

New native component tests: pending_tx_capacity…, allocator_and_cursor_exhaustion…, exact_owned_byte_budget…. Saved tx-capacity-valid.resume has IDs 1–256; the exact-owned control has 65 queued RX frames totalling 4194304 bytes. Stop records retain transition 1040/cursor 0 and transition 1025/cursor 68 respectively, with no retirement after refusal. Supplement new 8 counters: broker return/latch 122/183/190, clock 628=4, run-stop6507=4, snapshot mapping 3345–3347=6, codec fatal 134=6. Main and supplement artifacts match.

Qualification: The sent increment cannot overflow after the cursor increment succeeds: admitted sent<=cursor; cursor==u64::MAX refuses first; otherwise sent<u64::MAX. The backend TX frame-size guard is dominated on the qualified real descriptor path by NetDevice applying max_frame_bytes before calling tx. Positive arithmetic-line counts alone are not used as overflow proof.

Remaining: No further narrow G1 worker recording requested by this inspection. G9 remains separate.

### G2 — SUPPORTED

Source: session_clock.rs:648–650; session_network.rs:220–223; lib.rs:4788–4792.

All four native and four built-browser WFI cases satisfy the source-first CPU/clock/trace predictions, with exact restored Replay matches. New 8 owned getter count 8; clock 650 count 6953, idle fast-forward651–657 count 4. These figures are backed by the four concrete pending/control states, rather than treated as branch coverage by themselves.

Qualification: The pre-existing generic pending-control boundary is carried; no unrelated GPU idle policy or full Linux scheduling requirement is added.

Remaining: No further narrow G2 worker recording requested by this inspection.

### G3 — SUPPORTED + justified scope waiver

Source: session_network.rs:238–246; lib.rs:1621–1652; e9_network_components.rs:231–268.

ordinary_installation_refusals_preserve_the_complete_original_machine passes in main/supplement. Exact source assertions compare full before/after checkpoints for duplicate ownership, an existing live NIC, and installation after execution; corresponding retained frames and executed test lines are indexed.

Qualification: The extra slot-vector-shape disjunct at 244 is outside the qualified standard assembly: enable_virtio_slots creates the fixed platform slot count and leaves slot1 empty before NIC installation. This is a scope waiver for that assembly, not a claim about arbitrary caller-modified device handles or a demand to fabricate topology.

Remaining: No further narrow G3 worker recording requested for the qualified assembly.

### G4 — SUPPORTED

Source: crates/wasm/src/session_network.rs:49–59; generated wasm_vm_wasm.js:2087–2104.

Source-exact V8 networkCursor count 8. Raw components/wide-cursor.resume decodes cursor/clock sequence 9007199254740999; the saved actual call returns that exact decimal. The inactive call refuses Inactive, and the component source records full-state identity. Cursor 2 is also read after two real outcomes.

Qualification: Generated GC fallback plumbing retains the prior explicit-free waiver.

Remaining: No further narrow G4 worker recording requested.

### G5 — SUPPORTED + carried waiver

Source: session_network.rs:289–308,347–408; e9_network_components.rs:270–330.

wrong_mode_queued_common_work_and_unfinished_replays_refuse_atomically passes. New 8 counters296/359/381/408 each 1; correct-cursor TX/RX/external finish returns 306 count 3, with raw admitted checkpoint controls and exact-state assertions. The queued common delivery is drained normally and the recording lease then completes. Existing 9 covers changed/stale intents and ordinary completion.

Qualification: Non-Before return 385 retains the synchronous quiescent-call waiver: public callbacks cannot interleave halfway through the borrowed guest transition. The ordinal/sequence overflow fixtures separately force their two checked-add outcomes.

Remaining: No further narrow G5 worker recording requested.

### G6 — SUPPORTED + justified waivers

Source: session_network/codec.rs:80–123,159–217; e9_network_components.rs:333–556.

Retained wire fixtures independently decode the outer cap, bad magic and reserved Send/Link/kind cases; new 8 return counts 82/86/94/111/119 each 1. Saved checkpoint inputs encode duplicate IDs[1,1], sent>allocator, sent+pending=3>next 2, u64::MAX+1 allocator overflow, u64::MAX+1 represented overflow, outer cap and 4194305-byte ownership. Their source assertions prove refusal before full-state/incarnation mutation and then successful use of the prior lease. Exact 4MiB and two-pending controls roundtrip. New 8 rejection counts 165=1,187=1,196=1,215=4; existing 9 supplies earlier malformed fields/conservation states.

Qualification: Reader offset-add overflow is dominated by outer bounds and bounded/fixed reads. Continuation-only233 has no independent action. Native supplemental Cancelled decode line 93 is zero, but actual built-Wasm input result 2, returned cancelled status, durable bytes and matching replay prove the same unchanged decoder outcome; prior independent unchanged event-form evidence also carries. Counter positivity is not substituted for the distinct overflow fixtures.

Remaining: No further narrow G6 worker recording requested.

### G7 — SUPPORTED

Source: web/session-network.js:6–49; tools/verify/e9-network-component-browser.mjs:45–128.

All session-network V8 ranges are positive in the source-exact main recording. Two real failed/cancelled guest sends plus failed links reopen actual CAS-backed manifests with statuses[failed,failed] and[cancelled,failed], codes 61/62 and sequence 2. Independent saved-data decoding reconstructs each wire header+payload from 8 objects and checks 1024 actual PC/opcodes; original/replay frames and traces match. Reserved-kind refusal and a throwing factory free the actual native lease once, with cursor 0 and unchanged checkpoint.

Qualification: The intentionally uncalled replay-provider closure remains positive zero-egress evidence, not an untested callback requirement.

Remaining: No further narrow G7 worker recording requested.

### G8 — SUPPORTED

Source: web/session-inputs.js:61,93,138–139; tools/verify/e9-network-component-browser.mjs:129–168.

The wrong-policy call reports frozen network policy and performs0 puts/0 publications. Absent-source stage/read calls report the adapter refusal and preserve manifests/end; raw manifests retain sequence 0/no events and sequence 2 respectively. Source-exact need() rejection is now reached. Zero ternary-alternative ranges on93/138 are unrelated alternatives, not the exercised channel20 network branch.

Qualification: Absent optional networkPolicy is allowed when no network receipt is admitted; the required refusals occur at stage/read. No blanket refusal of an intentionally network-free prefix is required.

Remaining: No further narrow G8 worker recording requested.

### G9 — NEEDS EVIDENCE

Source: AGENTS.md independent verifier charter.

The earlier independent execution was stopped by automatic security review. This task only inspects source and existing recordings; it does not retry that execution or run a sensitivity test.

Qualification: None. Worker regressions and this partial read-only audit do not replace independent execution/sensitivity/suite disposition.

Remaining: Complete the unfinished independent charter only when the external restriction changes. No alternate model/session substitution is authorized.

### P13 — NEEDS EVIDENCE

Source: AGENTS.md worker3a(c); current E9-T13 task claim.

No T13 publication/public-browser recording is provided. A prepared bundle is not a deployment.

Qualification: None. Earlier runtime candidates were withdrawn; T12 public evidence cannot prove2f2aa7.

Remaining: After official human Cloudflare authorization, publish the exact frozen2f2 bundle and retain authenticated public assets plus the required public-browser proof.

## New delta accounting

| File | Hunk starts | Classification |
| --- | --- | --- |
| `crates/core/src/session_clock.rs` | 648 | SUPPORTED |
| `crates/core/tests/e9_network_components.rs` | 1 | SUPPORTED + harness waivers |
| `docs/design/session-replay-contract.json` | 499,822 | WAIVED representation |
| `docs/design/session-replay.md` | 478 | WAIVED representation |
| `tasks/epic-9-session-time-travel/E9-T13-network-capture.md` | 29,296 | WAIVED representation |
| `tools/verify/e9-network-capture-browser.mjs` | 10,62,66,74,115 | SUPPORTED + harness waivers |
| `tools/verify/e9-network-capture-files.py` | 10,36,97,142 | SUPPORTED + harness waivers |
| `tools/verify/e9-network-capture.py` | 25,35,48 | SUPPORTED + harness waivers |
| `tools/verify/e9-network-component-browser.mjs` | 1 | SUPPORTED + harness waivers |
| `web/dist/gpu-checkpoint-build.js` | 2 | WAIVED representation |
| `web/dist/main.js` | 3282 | SUPPORTED + presentation/cleanup waivers |
| `web/dist/network-capture-probe.js` | 16,87 | SUPPORTED + presentation/cleanup waivers |
| `web/dist/pkg/wasm_vm_wasm_bg.wasm` | binary | WAIVED representation |
| `web/dist/sw.js` | 21 | WAIVED representation |
| `web/dist/tasks.json` | 34794,34811,34817,34819,34828 | WAIVED representation |
| `web/gpu-checkpoint-build.js` | 2 | WAIVED representation |
| `web/main.js` | 3282 | SUPPORTED + presentation/cleanup waivers |
| `web/network-capture-probe.js` | 16,87 | SUPPORTED + presentation/cleanup waivers |
| `web/tasks.json` | 34794,34811,34817,34819,34828 | WAIVED representation |

The new common-clock predicate is supported by actual instruction/clock states and source-exact instrumented counts. The full test/helper additions have concrete saved outputs and recorded assertions. Documentation/contracts, generated task data, build fingerprints and cache versions carry explicit representation waivers. No unseen branch is declared dead, and a positive line count is not treated as proof of every logical outcome.

## Saved evidence points

- Main `/Volumes/e9-t13-wfi-cold/cold-proof-e9-t13-2f2aa7aba484/report.json`, SHA256 eee0a035d1157b4db78e3ab6bb6a661c2963758876506f171adc9a91c59d2bcb.
- Primary packet evidence/e9-t13/worker-wfi-final/provenance.json, SHA256 dcfded2590ed9e6471f8d6cd9c07f4c93523f5c1e34d97a2b7d0b3a5aafeedf9.
- Supplement `/Volumes/e9-t13-wfi-cold/e9-t13-wfi-native-line-proof/report.json`, SHA256 22149b1059c2bb7dd62b3047c7be8a30d96be79171fa7c517babcaa83603e72c. Counts are preserved by file/line/source/object in native-line-map.json; the full original lcov exports/raw profiles/objects are authenticated by its inventory.
- `/Volumes/e9-t13-wfi-cold/cold-proof-e9-t13-2f2aa7aba484/browser/report.json` components and probe data. Source-exact V8 ranges are preserved in browser-coverage.json; actual CAS/event/manifest and 1024-opcode observations are in component-and-format-points.json.
- Previous authored ledger SHA256 708d74ad9e6978448191c316792c591022cc4dacf8810e5a567576ee163b5827; provenance SHA256a7fd8006df45744730cb6d489f5ee64b37b97694886e17836769353af9108ba2. It is preserved unchanged.

## Limits

This bounded follow-up found no new contradiction in the inspected repair/component recordings. It does not close G9, issue a full verified verdict, change shared metadata, authorize a dependent task or establish publication. No further narrow G1–G8 worker recording is requested by this partial inspection.

Automatic security review stopped the earlier independent execution for possible cybersecurity risk. That execution was not retried, and independent execution/sensitivity/suite disposition remain unfinished. Required T13 Cloudflare publication and authenticated public-browser evidence are also absent (P13).
