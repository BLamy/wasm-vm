from pathlib import Path
import json,hashlib,gzip,time,subprocess
repo=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
origin=Path('/Volumes/e9-final-proof-ram/t13-critic-main/public-read-only-followup')
out=repo/'evidence/e9-t13/independent-public-read-only-review'
sha=lambda b:hashlib.sha256(b).hexdigest()
raw_provenance=(origin/'provenance.json').read_bytes()
assert sha(raw_provenance)=='b911027358ecf7b4f1e584ff124e82c0a61cc509c2f6fd300eb84000431e8319'
source=json.loads(raw_provenance)
assert source['p13']=='SUPPORTED' and source['full_task_verdict'] is None
assert source['remaining']==['G9']
assert source['metadata_head']=='6d21bdbc54815738304acece4f7388fae1844881'
assert source['frozen_runtime']=='2f2aa7aba484f6954ca04358385828093e561b83'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==source['metadata_head']
records=[]
# Authenticate every named input before creating the additive packet.
for item in source['inputs']+source['artifacts']:
 raw=Path(item['path']).read_bytes()
 assert len(raw)==item['bytes'] and sha(raw)==item['sha256'],item['path']
out.mkdir(parents=True,exist_ok=False)
def keep(path,name,expected=None):
 raw=path.read_bytes()
 if expected is not None: assert sha(raw)==expected,str(path)
 compressed=gzip.compress(raw,compresslevel=9,mtime=0)
 target=out/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(compressed)
 assert gzip.decompress(target.read_bytes())==raw
 records.append({'original_path':str(path),'artifact':str(target.relative_to(out)),'size':len(raw),'sha256':sha(raw),'gzip_size':len(compressed),'gzip_sha256':sha(compressed)})
for i,item in enumerate(source['inputs']):
 keep(Path(item['path']),f"inputs/{i:02d}-{Path(item['path']).name}",item['sha256'])
for item in source['artifacts']:
 keep(Path(item['path']),'assessment/'+Path(item['path']).name,item['sha256'])
keep(origin/'provenance.json','assessment/provenance.json',sha(raw_provenance))
keep(repo/'tasks/epic-9-session-time-travel/E9-T13-network-capture.md','boundary/task-at-review.md')
keep(Path(__file__),'archive-producer.py')
manifest={'kind':'Lossless worker preservation of separate critic P13 saved-data assessment; no full verification verdict','task':'E9-T13','created':time.time(),'assessment_author':'/root/verify_e9_t12','frozen_runtime':source['frozen_runtime'],'repository_head_at_review':source['metadata_head'],'assessment_provenance_sha256':sha(raw_provenance),'p13':source['p13'],'full_task_verdict':None,'restrictions':source['restrictions'],'remaining_gaps':source['remaining'],'entries':records}
p=out/'provenance.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
(out/'README.md').write_text(
 '# Partial independent production-publication assessment\n\n'
 'The separate critic supports P13 from saved production evidence at frozen runtime 2f2aa7. The release is at https://wasm-vm.pages.dev/; https://cb3b19fb.wasm-vm.pages.dev is the permanent URL for that same production release. **This is not a full task verification verdict. G9 independent execution, sensitivity and suite disposition remain unfinished.**\n\n'
 'Read assessment/assessment.md.gz with the detailed JSON and authored provenance. Six publication predictions and the supplementary root-render prediction hold with explicit qualifications: 34 carried asset responses and two fresh canonical HTML chains; inherited URL-only boot manifest staging; the recorded HTTP3 empty reason; and separate failed/corrected account-query records. The normal Chrome root render is distinct from the auxiliary Python403 observation, whose cause is unestablished.\n\n'
 'The critic authenticated 189 public originals, 13 earlier-account snapshots, 106 browser inventory entries and 750 staged files, then decoded guest frames/traces/CAS and actual trace-loaded source bytes. Prior local gates and unchanged HELD results carry without relabelling. No VM/test/browser/acceptance producer or stopped harness was executed, no sensitivity run occurred, and no alternate model/session was used. The worker only authenticated and compressed the named saved files. Each original path, digest and compressed digest is retained losslessly.\n')
for entry in records:
 packed=(out/entry['artifact']).read_bytes()
 assert sha(packed)==entry['gzip_sha256']
 raw=gzip.decompress(packed)
 assert len(raw)==entry['size'] and sha(raw)==entry['sha256']
result={'packet':str(p),'sha256':sha(p.read_bytes()),'assessment_provenance_sha256':sha(raw_provenance),'assessment_sha256':sha((origin/'assessment.md').read_bytes()),'entries':len(records),'gzip_bytes':sum(x['gzip_size'] for x in records),'p13':'SUPPORTED','full_task_verdict':None,'remaining':['G9']}
Path('/Volumes/e9-final-proof-ram/e9-t13-preserve-public-read-only-review-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
