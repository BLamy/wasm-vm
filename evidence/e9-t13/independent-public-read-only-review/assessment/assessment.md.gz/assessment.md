# P13 publication — bounded read-only assessment

**P13: SUPPORTED. No full task verification verdict.** The saved production recording and exact-byte publication evidence answer P13 with the qualifications below. G9 remains unresolved.

Frozen runtime: `2f2aa7aba484f6954ca04358385828093e561b83`; metadata HEAD: `6d21bdbc54815738304acece4f7388fae1844881`. Source/metadata diff was read first: only task/queue metadata and evidence changed after the prior assessed head; crates/web/tools/docs and dependency boundary remain unchanged. Prior local 25 gates, G1–G8 and 32 HELD artifacts carry unchanged.

Production: https://wasm-vm.pages.dev/; same-release immutable origin: https://cb3b19fb.wasm-vm.pages.dev. Browser acceptance ran on the production app; immutable-origin proof here is exact asset authentication, not a second browser acceptance.

## Predictions and observations

### P13-A — HELD with declared deployment representation qualification

Successful production receipt exit0, project wasm-vm/branch main; before/after 750 files and 84317110 bytes. All 750 staged files authenticate. Original745 tracked identities match frozen Git:740 staged files are literal frozen bytes;5 boot manifests change only URL fields and exactly match the held T12 deployment. Five additional release files also match that held baseline. All 13 runtime/page/guest assets are exact frozen bytes on both origins.

Citation: authentication.json payload; asset-authentication.json; publication receipt3473bc9398b674342a67a63cc23e80cba2f7e978c3f2c88454183e93aa791e63.

### P13-B — HELD

Exactly34 original successful asset responses carry byte-for-byte. Both original app.html HTTP308 exceptions remain preserved. Only the two HTML chains are fresh: same-origin app.html→/app,308 then200, with 55777-byte frozen app.html SHA5731888361e5f0d77927713254ff68047b4bfde404cc9ec16582861c3eaab3e1. Eighteen critical assets per origin match the prepared payload.

Citation: asset-authentication.json; complete report2be08caa1d680983eaf808eb632ff28c45c19e3b026c70eaad4b500c8db7a67e; original reportb97fd649af4d535bfcdd2322fecf4fcf9230b24bb7515bb5744a46894ef763df.

### P13-C — HELD with precise scope

Actual production browser status passed, development=false, frozen head,127/0/errors[]. Six exact final-frame replays and trace suffixes;4 matching WFI cases;12 JIT budget cases (9 positive translated executions,3 q1 scalar controls);28 ABI and 6 component refusals; reload5; two live pips. Trace-loaded Wasm bytes match frozen2f2,2178164 bytes, SHA29911c6854410dfe75b3d798c23b2ba86e8456ffaeb07264c894106ded79a948. Six active script sources match frozen bytes. Zero replay provider construction and fetch/socket attempts, plus exactly one safe production provider GET. Public counterRequests/bridgeRequests are0; the state-changing local counter/unavailable-server proof is carried unchanged, not repeated or claimed public.

Citation: decoded-public-states.json; public reportb8e97c1cdc3c41b04876c58d6528d46dc4ea7d4dad9757b43792ae49d18e666c; trace.network:81 and 232; trace.trace records 689/695.

### P13-D — HELD

trace.network:232 is the actual production GET, h3/status 200/empty statusText. Its resource body is77 bytes with SHA0a691b80cfbc3aac5134efb5c414724941ee2dde6731cbf0e4366e0f1c3ea1ad, equal to frozen safe-response asset and guest HTTP body. Guest RAM/DMA/report contain the same bridge response; full 9216-opcode trace matches pinned code.

Citation: public-response-and-qualification.json provider_point; decoded-public-states.json; trace ZIP43b222d473b6482ee29f099888009b5658e5ac5ddc206474fc1a60245b8916ba.

### P13-E — HELD; qualification accepted

Frozen oracle base matches Git SHAaee77f3451f6fa153befa18bace6f524591d59da92d636dda111216a43906907. The public-only copy is byte-identical except the single exact empty-reason assertion replacing OK; pinned guest SHA85ba7328592bfbb4928291e1f7f6ef8418701bdea3ad3f10fc6faa29b8847ae4 is unchanged. Original assertion failure remains preserved; qualified recorded exit0 is supplementary worker data decoding. No recorded response/frame/trace/CAS bytes were normalized.

Citation: public-response-and-qualification.json oracle; qualified report108a56406978beca6a66e659f7aa3dda941370596688dd823d56484d90759334.

### P13-F — HELD; accounting qualification accepted

Initial account publication remains failed/exit1 with no public URL. V2 query exit0/target_present=false is preserved; the checker used name. Fresh v3 uses actual Project Name, exit0/target_present=true, and its selected account fingerprint matches deployment. Separate additive interpretation preserves old private-source fingerprints; no private source was followed. Publication/site identity is independently supported by the production response bytes, not private credential contents.

Citation: account-qualification.json; preflight packeta9c5ca2a5807144f3b3f993c40f686f4a1ea8ab460360964448bcd1e26399f19.

### R1 — HELD with client limitation

Normal Chrome root observation shows https://wasm-vm.pages.dev/, home title/H1 and ./app.html#ide link, corroborated by saved AX/image. Distinct Python3.9.6 default-header request returned 403 before body/headers were captured. Its cause is unestablished. No guest boot, all-client compatibility or cause of 403 is inferred.

Citation: root-and-trace-observations.json; root-browser-observation SHA db998418c84668686ad705f4a2d1a107d8a9d158eaf3ea4733d90b72cb16b0ba; initial-python-root-attempt SHA a881f203a2fded5fef167a5b80751b87cb0b28c5d5e4fbda86326fd74811f663.

## Qualifications

- All 189 public packet originals+gzip authenticate, as do all 13 earlier-account gzip snapshots and 106 browser inventory files. The account packet has one intentionally historical task-before-account-log snapshot; its gzip/hash is valid while the current task file has later metadata. It is not stale runtime evidence.
- The five staged boot URL rewrites are explicit deployment representation inherited by exact hashes from the held T12 publication, with all other manifest fields unchanged. The claim is not that every staged byte is literally the frozen Git blob.
- Original34 responses are carried, two canonical HTML chains are new; the passing additive report does not relabel the original Python308 capture as passed or rerun the production browser.
- The public reason qualification is specific to recorded h3 empty statusText and its synthetic guest HTTP header. It does not accept arbitrary status/reason values, alter runtime code or change the local-counter oracle. Its saved producer is not executed by this review.
- The provider witness covers recorded synchronous offline replay calls. Asset requests and intercepted artifact-export POSTs are distinct proof plumbing; the whole page is not claimed to make zero network requests.
- ZIP CRC checks pass and all 916 trace.trace records decode using byte-LF delimiters. Python str.splitlines also splits embedded Unicode separators; an initial helper decoding assumption was corrected without changing recording bytes.
- No VM, test, browser, acceptance producer, sensitivity run or stopped harness was launched. No alternate model/session or shared implementation/task/status/queue/index/commit write occurred. Only saved-file helpers and authored scratch reports ran.

## Concrete saved points

- `/Volumes/e9-t13-wfi-cold/e9-t13-wfi-public-browser/browser-trace.zip`, SHA256 43b222d473b6482ee29f099888009b5658e5ac5ddc206474fc1a60245b8916ba. `trace.network:81` serves the exact 2178164-byte frozen ordinary Wasm; `trace.network:232` serves the actual 77-byte safe provider body.
- In the same ZIP, `trace.trace` records 689 and 695 return `cap-pip live` for the network panel and Offline network recording roadmap entry. The retained desktop screenshot shows the green pip and successful offline/timer-order message.
- `/Volumes/e9-t13-wfi-cold/e9-t13-wfi-public-browser/original.trace`:9216 pinned retired PCs/opcodes; all six replay frames match final SHA256`b3223531e5d35aedf824e02c158f50b347f35bb8076b1d55c63a1979ee8474ea`. Initial-prefix traces match the full original; pending-prefix traces match original lines1025–9216 (8192 instructions). Thirteen CAS objects authenticate and reconstruct the five exact event envelopes.
- `asset-authentication.json` lists all 36 origin/name/size/hash points, both old308 exceptions and both complete redirect chains. `authentication.json` preserves every packet/inventory identity and all five URL-only manifest qualifications.
- `public-response-and-qualification.json` contains the exact oracle diff and original/qualified/pinned guest hashes. `decoded-public-states.json` contains actual checkpoint/trace/loaded-Wasm points. `account-qualification.json` preserves failed/corrected query distinctions without private logs.

## Remaining gate

No precise P13 evidence gap remains in this bounded inspection. This publication does not prove a complete Linux/TCP replay system; the previously qualified Ethernet HTTP bridge and T14 boundary are unchanged.

**G9 remains NEEDS EVIDENCE.** Automatic security review stopped the earlier independent execution for possible cybersecurity risk. Independent execution/sensitivity/suite disposition remains unfinished; this read-only assessment did not retry or replace it. The task remains blocked, no full verified verdict is issued and no dependent task is cleared.
