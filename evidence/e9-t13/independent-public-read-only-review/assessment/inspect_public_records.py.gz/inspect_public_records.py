"""P13 saved-file inspection only: hashes, JSON, ZIP and checkpoint structures."""
from pathlib import Path
from urllib.parse import urljoin, urlparse
import difflib, gzip, hashlib, json, re, struct, subprocess, zipfile

OUT=Path(__file__).resolve().parent
REPO=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
PUB=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-public-browser')
ASSETS=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-public-assets-complete')
ORACLE=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-public-oracle-qualification')
HEAD='2f2aa7aba484f6954ca04358385828093e561b83'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
u32=lambda b,i=0:struct.unpack_from('<I',b,i)[0]
u64=lambda b,i=0:struct.unpack_from('<Q',b,i)[0]

def digest(path):
    h=hashlib.sha256()
    with path.open('rb')as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

expected={
 REPO/'evidence/e9-t13/worker-public-final/provenance.json':'0b829b1ec86a8abb82b8f0d045db3932755d929c1db083525a41fb44777b80b5',
 REPO/'evidence/e9-t13/project-account-preflight/provenance.json':'a9c5ca2a5807144f3b3f993c40f686f4a1ea8ab460360964448bcd1e26399f19',
 Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-publication-v2/receipt.json'):'3473bc9398b674342a67a63cc23e80cba2f7e978c3f2c88454183e93aa791e63',
 PUB/'report.json':'b8e97c1cdc3c41b04876c58d6528d46dc4ea7d4dad9757b43792ae49d18e666c',
 PUB/'browser-trace.zip':'43b222d473b6482ee29f099888009b5658e5ac5ddc206474fc1a60245b8916ba',
 ASSETS/'report.json':'2be08caa1d680983eaf808eb632ff28c45c19e3b026c70eaad4b500c8db7a67e',
 ORACLE/'report.json':'108a56406978beca6a66e659f7aa3dda941370596688dd823d56484d90759334',
}
auth={'reports':[],'packets':[],'browser_inventory':[],'source_identity':{},'payload':{}}
for path,want in expected.items():
    got=digest(path);assert got==want,str(path)
    auth['reports'].append({'path':str(path),'sha256':got})
for kind in('worker-public-final','project-account-preflight'):
    root=REPO/'evidence/e9-t13'/kind;manifest=load(root/'provenance.json');rows=[]
    for row in manifest['entries']:
        path=root/row['artifact'];compressed=path.read_bytes();raw=gzip.decompress(compressed)
        assert len(compressed)==row['gzip_size']and sha(compressed)==row['gzip_sha256']
        assert len(raw)==row['size']and sha(raw)==row['sha256']
        original=Path(row['original_path']);present=original.is_file()
        matches=present and original.stat().st_size==len(raw)and digest(original)==row['sha256']
        if present and not matches:
            assert kind=='project-account-preflight'and row['artifact']=='boundary/task-before-account-log.md.gz'
        rows.append({'artifact':row['artifact'],'original':str(original),'sha256':row['sha256'],'original_present':present,'current_original_matches':matches,'qualification':'Historical task-before-account-log snapshot; current metadata has later append-only log entries'if present and not matches else None})
    auth['packets'].append({'kind':kind,'files':rows,'privacy':manifest['privacy']})
report=load(PUB/'report.json')
assert report['status']=='passed'and not report['development']and report['head']==HEAD and report['errors']==[]
for row in report['files']:
    path=PUB/row['path'];assert path.stat().st_size==row['bytes']and digest(path)==row['sha256']
    auth['browser_inventory'].append(row)
runtime_diff=subprocess.check_output(['git','diff','--name-only',HEAD,'6d21bdbc54815738304acece4f7388fae1844881','--','crates','web','tools','docs'],cwd=REPO,text=True)
assert not runtime_diff
auth['source_identity']={'frozen_runtime':HEAD,'metadata_head':'6d21bdbc54815738304acece4f7388fae1844881','crates_web_tools_docs_diff':runtime_diff}

deployment=load('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-publication-v2/receipt.json')
assert deployment['status']=='published'and deployment['exit_code']==0 and deployment['head']==HEAD
assert deployment['before']==deployment['after']=={'files':750,'bytes':84317110}
assert deployment['production_url']=='https://wasm-vm.pages.dev/'and deployment['public_urls']==['https://cb3b19fb.wasm-vm.pages.dev']
command=deployment['command'];assert command[command.index('--project-name')+1]=='wasm-vm'and command[command.index('--branch')+1]=='main'
assert '--commit-dirty=true'in command
prepared=load(deployment['prepared_receipt']);assert digest(Path(deployment['prepared_receipt']))==deployment['prepared_receipt_sha256']
assert prepared['head']==HEAD and len(prepared['original_files'])==745 and len(prepared['staged_files'])==750
assert sum(v['bytes']for v in prepared['staged_files'].values())==84317110
source=Path(prepared['source']);dist=source/'web/dist'
tree=subprocess.check_output(['git','ls-tree','-r',HEAD,'--','web/dist'],cwd=REPO,text=True)
blobs={line.split('\t',1)[1][len('web/dist/'):]:line.split()[2]for line in tree.splitlines()}
baseline=load(prepared['baseline_receipt']);assert digest(Path(prepared['baseline_receipt']))==prepared['baseline_receipt_sha256']
manifest_changes=[]
for name,row in prepared['original_files'].items():
    raw=(dist/name).read_bytes()
    if len(raw)==row['bytes']and sha(raw)==row['sha256']:
        assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blobs[name],name
    else:
        assert name in ('artifacts.json','artifacts-alpine.json','artifacts-node-alpine.json','artifacts-omarchy.json','artifacts-omarchy-virgl.json')
        frozen_blob=subprocess.check_output(['git','cat-file','blob',blobs[name]],cwd=REPO)
        assert len(frozen_blob)==row['bytes']and sha(frozen_blob)==row['sha256']
        assert baseline['files'][name]==prepared['staged_files'][name]
        a=json.loads(frozen_blob);b=json.loads(raw);changed_urls=[]
        for key,item in a['artifacts'].items():
            if item.get('url')!=b['artifacts'][key].get('url'):changed_urls.append('/artifacts/'+key+'/url')
            if 'url'in item:item['url']=b['artifacts'][key]['url']
        assert a==b
        manifest_changes.append({'name':name,'frozen_sha256':sha(frozen_blob),'staged_sha256':sha(raw),'only_changed_fields':changed_urls,'matches_held_T12_deployment':True})
assert len(manifest_changes)==5
for name,row in prepared['staged_files'].items():
    path=dist/name;assert path.stat().st_size==row['bytes']and digest(path)==row['sha256']
    assert row['bytes']<25*1024*1024
for name in prepared['carried_release_extras']:assert baseline['files'][name]==prepared['staged_files'][name]
auth['payload']={'original_frozen_files':745,'staged_files':750,'staged_bytes':84317110,'prepared_sha256':deployment['prepared_receipt_sha256'],'five_carried_extras':prepared['carried_release_extras'],'before_after_counts_equal':True,'frozen_git_identity':'740 staged files equal frozen blobs; original bytes of5 boot manifests equal frozen blobs and staged bytes differ only in carried deployment URLs','boot_manifest_qualifications':manifest_changes,'held_T12_baseline_receipt_sha256':prepared['baseline_receipt_sha256']}

complete=load(ASSETS/'report.json');original=load(complete['original_report'])
assert digest(Path(complete['original_report']))==complete['original_report_sha256']
old_rows={(r['origin'],r['name']):r for r in original['assets']}
asset_points=[];carried=0;fresh=0
for row in complete['assets']:
    key=(row['origin'],row['name']);prior=old_rows[key]
    root=Path(row['evidence_root']);raw=(root/row['file']).read_bytes()
    assert row['status']=='passed'and row['http_status']==200
    assert len(raw)==row['bytes']==row['expected_bytes']and sha(raw)==row['sha256']==row['expected_sha256']
    assert prepared['staged_files'][row['name']]=={'bytes':len(raw),'sha256':sha(raw)}
    if row['name'].startswith('artifacts'):
        assert baseline['files'][row['name']]==prepared['staged_files'][row['name']]
    else:assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blobs[row['name']]
    if row['name']=='app.html':
        fresh+=1;assert prior['status']=='failed'and '308'in prior['failure']and len(row['hops'])==2
        a,b=row['hops'];assert a['http_status']==308 and b['http_status']==200
        assert urljoin(a['url'],a['headers']['Location'])==b['url']==row['final_url']
        assert urlparse(a['url']).netloc==urlparse(b['url']).netloc==urlparse(row['url']).netloc
        for hop in row['hops']:
            body=(root/hop['body_file']).read_bytes();assert len(body)==hop['bytes']and sha(body)==hop['sha256']
        assert (root/b['body_file']).read_bytes()==raw
    else:
        carried+=1;assert prior['status']=='passed'
        for k in('origin','name','url','bytes','sha256','expected_bytes','expected_sha256','file'):assert row[k]==prior[k]
        assert Path(row['evidence_root'])==Path(complete['original_report']).parent
        assert (Path(complete['original_report']).parent/prior['file']).read_bytes()==raw
    asset_points.append({'origin':row['origin'],'name':row['name'],'sha256':sha(raw),'bytes':len(raw),'carried':row['name']!='app.html','url':row['url'],'final_url':row.get('final_url'),'hops':row.get('hops',[])})
assert carried==complete['carried_responses']==34 and fresh==complete['newly_recorded_html_chains']==2
assert len({(r['origin'],r['name'])for r in asset_points})==36
assert {r['origin']for r in asset_points}=={'production','deployment'}
for origin in('production','deployment'):assert len([r for r in asset_points if r['origin']==origin])==18
for row in report['assets']:
    assert row=={'name':row['name'],**prepared['staged_files'][row['name']]}
(OUT/'asset-authentication.json').write_text(json.dumps({'original_exceptions':[r for r in original['assets']if r['status']=='failed'],'carried':carried,'fresh_html_chains':fresh,'assets':asset_points},indent=2)+'\n')
(OUT/'authentication.json').write_text(json.dumps(auth,indent=2)+'\n')

trace_path=PUB/'browser-trace.zip'
with zipfile.ZipFile(trace_path)as archive:
    assert archive.testzip()is None
    networks=[json.loads(line)for line in archive.read('trace.network').decode().splitlines()]
    entry=networks[231];s=entry['snapshot'];request=s['request'];response=s['response'];content=response['content']
    assert request['url']=='https://wasm-vm.pages.dev/network-probe-response.json'and request['method']=='GET'
    assert response['status']==200 and response['statusText']==''and response['httpVersion']=='h3'
    body=archive.read('resources/'+content['_sha1'])
    assert len(body)==content['size']==77 and sha(body)=='0a691b80cfbc3aac5134efb5c414724941ee2dde6731cbf0e4366e0f1c3ea1ad'
    frozen_response=subprocess.check_output(['git','show',HEAD+':web/dist/network-probe-response.json'],cwd=REPO)
    assert body==frozen_response
    http=(PUB/'http-response.bin').read_bytes();headers,guest_body=http.split(b'\r\n\r\n',1)
    assert guest_body==body and headers.split(b'\r\n',1)[0]==b'HTTP/1.1 200 '
    assert (PUB/'receive-frame.bin').read_bytes()[14:]==http
    requests=[{'line':i+1,'url':e['snapshot']['request']['url'],'method':e['snapshot']['request']['method'],'status':e['snapshot']['response']['status']}for i,e in enumerate(networks)if e.get('snapshot',{}).get('request',{}).get('url','').endswith('/network-probe-response.json')]
    assert len(requests)==1
    zip_info={'path':str(trace_path),'sha256':digest(trace_path),'members':len(archive.namelist()),'crc_errors':False,'provider_point':{'member':'trace.network','line':232,'url':request['url'],'method':request['method'],'status':response['status'],'statusText':response['statusText'],'httpVersion':response['httpVersion'],'resource':'resources/'+content['_sha1'],'body_bytes':len(body),'body_sha256':sha(body)},'provider_requests':requests,'synthetic_status_line':headers.split(b'\r\n')[0].decode()}

qualified=load(ORACLE/'report.json');frozen_path=ORACLE/'frozen-base.py';qualified_path=ORACLE/'source/tools/verify/e9-network-capture-files.py'
base=frozen_path.read_bytes();changed=qualified_path.read_bytes()
frozen=subprocess.check_output(['git','show',HEAD+':tools/verify/e9-network-capture-files.py'],cwd=REPO)
assert base==frozen and sha(base)==qualified['frozen_oracle_sha256']
before=b"head.startswith(b'HTTP/1.1 200 OK\\r\\n')";after=b"head.startswith(b'HTTP/1.1 200 \\r\\n')"
assert base.count(before)==1 and changed==base.replace(before,after,1)
assert sha(changed)==qualified['qualified_oracle_sha256']and qualified['exit_code']==0
guest=(ORACLE/'source/web/assets/e9-network-capture.bin').read_bytes()
assert guest==subprocess.check_output(['git','show',HEAD+':web/assets/e9-network-capture.bin'],cwd=REPO)
assert sha(guest)==qualified['pinned_guest_sha256']
failure=Path(qualified['original_frozen_attempt_log']);assert digest(failure)==qualified['original_frozen_attempt_log_sha256']
failure_text=failure.read_text();assert 'AssertionError'in failure_text and 'HTTP/1.1 200 OK'in failure_text
diff=''.join(difflib.unified_diff(base.decode().splitlines(True),changed.decode().splitlines(True),fromfile='frozen',tofile='public-only'))
recorded_diff=(ORACLE/'qualified-assertion.diff').read_text()
assert recorded_diff.splitlines()[2:]==diff.splitlines()[2:]
zip_info['oracle']={'frozen_sha256':sha(base),'qualified_sha256':sha(changed),'pinned_guest_sha256':sha(guest),'only_reason_assertion_changed':True,'diff':diff,'original_failure_sha256':digest(failure),'qualified_recorded_exit':qualified['exit_code'],'original_inputs_unchanged':True}
(OUT/'public-response-and-qualification.json').write_text(json.dumps(zip_info,indent=2)+'\n')
print(json.dumps({'packet_counts':[len(p['files'])for p in auth['packets']],'browser_inventory':len(auth['browser_inventory']),'payload':auth['payload'],'carried_assets':carried,'fresh_chains':fresh,'asset_points':len(asset_points),'provider_body_sha256':sha(body),'only_reason_assertion_changed':True}))
