"""Decode saved public checkpoints/traces and immutable payloads; no VM execution."""
from pathlib import Path
from urllib.parse import urlparse
import gzip, hashlib, json, re, struct, subprocess, zipfile

OUT=Path(__file__).resolve().parent
REPO=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
PUB=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-public-browser')
HEAD='2f2aa7aba484f6954ca04358385828093e561b83'
sha=lambda b:hashlib.sha256(b).hexdigest()
u32=lambda b,i=0:struct.unpack_from('<I',b,i)[0]
u64=lambda b,i=0:struct.unpack_from('<Q',b,i)[0]
report=json.loads((PUB/'report.json').read_text());probe=json.loads((PUB/'probe.json').read_text())

def artifact(info):
    raw=(PUB/info['file']).read_bytes();assert len(raw)==info['bytes']and sha(raw)==info['sha256'];return raw

def frame(raw,ram=False):
    assert raw[:12]==b'WVMRESU1\1\0\0\0';at=84;parts={}
    while at<len(raw):
        tag,n=struct.unpack_from('<II',raw,at);at+=8;assert tag not in parts and at+n<=len(raw);parts[tag]=raw[at:at+n];at+=n
    assert at==len(raw);c=parts[18];n=parts[21]
    assert c[:8]==b'WVCLK001'and n[:8]==b'WVNETS01'
    t,r,o,s,ticket=struct.unpack_from('<QQQQQ',c,12);next_id,cursor,sent=struct.unpack_from('<QQQ',n,8)
    value={'sha256':sha(raw),'transition':t,'retired':r,'ordinal':o,'sequence':s,'ticket':ticket,'next_id':next_id,'cursor':cursor,'sent':sent,'pc':u64(parts[1]),'x1':u64(parts[1],8),'mtime':u64(parts[3])}
    memory=None
    if ram:
        memory=bytearray();at=0;b=parts[2]
        while at<len(b):
            kind,size=struct.unpack_from('<BI',b,at);at+=5;assert kind in(0,1)and size>0
            if kind:memory.extend(b[at:at+size]);at+=size
            else:memory.extend(bytes(size))
        assert len(memory)in(1<<20,16<<20)
    return value,memory

final_raw=artifact(probe['final']);final,ram=frame(final_raw,True)
assert (final['transition'],final['retired'],final['sequence'],final['cursor'],final['next_id'],final['sent'])==(9216,9216,5,5,1,1)
receive_frame=(PUB/'receive-frame.bin').read_bytes();assert ram[0x1400c:0x1400c+len(receive_frame)]==receive_frame
assert [u64(ram,0x40000+i*8)for i in range(3)]==[1,1,1]
assert ram[0x40000:0x40420]==(PUB/'guest.bin').read_bytes()
assert ram[0x40000+44:0x40000+44+len(receive_frame)]==receive_frame
program=subprocess.check_output(['git','show',HEAD+':web/assets/e9-network-capture.bin'],cwd=REPO)
trace=artifact(probe['trace']);lines=trace.decode().splitlines();assert len(lines)==9216
for i,line in enumerate(lines):
    m=re.match(r'core 0: 0x([0-9a-f]+) \(0x([0-9a-f]+)\)',line);assert m
    index=i if i<390 else 390+(i-390)%2087
    assert int(m[1],16)==0x80000000+4*index and int(m[2],16)==u32(program,4*index)
replays=[]
for row in probe['replays']:
    raw=artifact(row['frame']);rtrace=artifact(row['trace']);assert raw==final_raw
    expected=lines[1024:]if row['fromPending']else lines
    assert rtrace.decode().splitlines()==expected
    replays.append({'quantum':row['quantum'],'from_pending':row['fromPending'],'frame_sha256':sha(raw),'trace_sha256':sha(rtrace),'trace_lines':len(expected)})
assert len(replays)==6
wfi=[]
for row in probe['idle']:
    raw=artifact(row['frame']);state,_=frame(raw);rtrace=artifact(row['trace'])
    assert artifact(row['replayFrame'])==raw and artifact(row['replayTrace'])==rtrace
    start=390 if row['guestTx']else 0;pending=row['pendingWork'];retired=6 if pending else 5
    assert (state['transition'],state['retired'],state['mtime'],state['x1'])==(start+6,start+retired,start+6 if pending else 1000000,int(pending))
    wfi.append({'guest_tx':row['guestTx'],'pending':pending,'state':state,'trace_sha256':sha(rtrace),'record_replay_equal':True})
assert len(wfi)==4
jit=[];target_frames={}
for row in report['checks']['jit']:
    raw=gzip.decompress(artifact(row['frame']));state,_=frame(raw)
    assert state['transition']==state['retired']==row['target']and state['cursor']==1
    assert sha(raw)==row['sha256']
    if row['target']in target_frames:assert raw==target_frames[row['target']]
    else:target_frames[row['target']]=raw
    assert row['compiled']>0 if row['quantum']>=8 else row['compiled']==0
    jit.append({'target':row['target'],'quantum':row['quantum'],'compiled':row['compiled'],'state':state})
assert len(jit)==12
manifest=json.loads(artifact(probe['persisted']['manifest']));objects={}
for obj in probe['persisted']['objects']:
    raw=artifact(obj['bytes']);ref=obj['ref'];assert sha(raw)==ref['sha256']and str(len(raw))==str(ref['length']);objects[ref['sha256']]=raw
events=[]
for index in manifest['events']:events.extend(json.loads(objects[index['content']['sha256']]))
assert len(events)==len(probe['receipts'])==5 and 'network'in manifest['policy']['required_inputs']
for item,receipt in zip(events,probe['receipts']):
    intent=json.loads(bytes(item['intent']));p=item['payload']
    payload=bytes(p['bytes'])if p['storage']=='inline'else objects[p['content']['sha256']]
    assert bytes(intent['header'])+payload==artifact(receipt['bytes'])
assert report['checks']['suite']=={'passed':127,'failed':0}and report['errors']==[]
assert report['checks']['reload']=={'receipts':5}
assert len(report['checks']['abi'])==28 and len(report['checks']['components']['refusals'])==6
assert report['checks']['independentEgress']=={'fetchAttempts':[],'socketAttempts':0}
assert probe['transport']=={'recordFactories':1,'replayFactories':0,'requests':1}
assert report['transportWitness']['browserProviderRequests']==1 and report['transportWitness']['forbiddenReplayProviderRequests']==0
sources=[]
for script in json.loads((PUB/'javascript-coverage.json').read_text()):
    name=urlparse(script['url']).path.lstrip('/')
    if name not in('main.js','roadmap.js','session-network.js','session-inputs.js','network-capture-probe.js','pkg/wasm_vm_wasm.js'):continue
    frozen=subprocess.check_output(['git','show',HEAD+':web/dist/'+name],cwd=REPO)
    assert script['source'].encode()==frozen
    sources.append({'name':name,'sha256':sha(frozen)})
assert len(sources)==6
loaded_wasm=[]
with zipfile.ZipFile(PUB/'browser-trace.zip')as z:
    for i,line in enumerate(z.read('trace.network').decode().splitlines()):
        e=json.loads(line).get('snapshot',{});request=e.get('request',{});response=e.get('response',{})
        if urlparse(request.get('url','')).path!='/pkg/wasm_vm_wasm_bg.wasm':continue
        ref=response.get('content',{}).get('_sha1')
        if not ref:continue
        raw=z.read('resources/'+ref)
        frozen=subprocess.check_output(['git','show',HEAD+':web/dist/pkg/wasm_vm_wasm_bg.wasm'],cwd=REPO)
        assert raw==frozen
        loaded_wasm.append({'member':'trace.network','line':i+1,'url':request['url'],'bytes':len(raw),'sha256':sha(raw)})
assert loaded_wasm
result={'final':final,'guest_dma_response_sha256':sha(receive_frame),'original_trace_sha256':sha(trace),'original_trace_lines':len(lines),'replays':replays,'wfi':wfi,'jit':jit,'jit_positive_translated_cases':sum(r['compiled']>0 for r in jit),'jit_q1_scalar_controls':sum(r['compiled']==0 for r in jit),'cas_objects':len(objects),'cas_event_statuses':[e['status']for e in events],'cas_manifest_sha256':sha(artifact(probe['persisted']['manifest'])),'source_exact_active_scripts':sources,'loaded_wasm':loaded_wasm,'checks_summary':{'suite':report['checks']['suite'],'probe':report['checks']['probe'],'reload':report['checks']['reload'],'abi':28,'component_refusals':6,'independent_egress':report['checks']['independentEgress'],'transport':report['transportWitness']}}
(OUT/'decoded-public-states.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'replays':len(replays),'wfi':len(wfi),'jit':len(jit),'positive_translated':result['jit_positive_translated_cases'],'q1_controls':result['jit_q1_scalar_controls'],'cas_objects':len(objects),'exact_active_sources':len(sources),'actual_loaded_wasm_points':loaded_wasm}))
