from pathlib import Path
import os,json,hashlib,subprocess,time,re,datetime
root=Path('/Volumes/e9-final-proof-ram/e9-t13-wfi-publication-source')
prepared=Path('/Volumes/e9-final-proof-ram/e9-t13-wfi-publication-prepared/receipt.json')
auth=Path('/Volumes/e9-final-proof-ram/e9-t13-authorized-publication-auth-result.json')
out=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-publication')
out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=prepared.read_bytes()
assert sha(raw)=='9f5ec1661f7d1895c59b332750dab1a803b8477358c86a0da62f75e2a1714163'
spec=json.loads(raw);login=json.loads(auth.read_text())
assert login['exit_code']==0 and login['authenticated_marker'] and not login['unauthenticated_marker']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head==spec['head']=='2f2aa7aba484f6954ca04358385828093e561b83'
def inventory():
 files={str(p.relative_to(root/'web/dist')):p for p in (root/'web/dist').rglob('*') if p.is_file()}
 assert set(files)==set(spec['staged_files'])
 for rel,p in files.items():
  data=p.read_bytes();expected=spec['staged_files'][rel]
  assert len(data)==expected['bytes'] and sha(data)==expected['sha256'],rel
  assert len(data)<=25*1024*1024,rel
 return {'files':len(files),'bytes':sum(x['bytes']for x in spec['staged_files'].values())}
before=inventory()
cmd=['node','/Volumes/e9-t11-cold-scratch/e9-t12-npm-cache/_npx/32026684e21afda6/node_modules/wrangler/bin/wrangler.js','pages','deploy','web/dist','--project-name','wasm-vm','--branch','main','--commit-dirty=true']
private=Path('/Volumes/e9-final-proof-ram/e9-t13-wfi-deploy-private.log')
debug=Path('/Volumes/e9-final-proof-ram/e9-t13-wfi-deploy-private-debug.log')
assert not private.exists() and not debug.exists()
env=os.environ.copy()
env.update({'TMPDIR':'/Volumes/e9-final-proof-ram/deploy-tmp/',
 'NODE_OPTIONS':'--require=/Volumes/e9-final-proof-ram/wrangler-existing-auth-write.cjs',
 'WRANGLER_LOG_PATH':str(debug),'WRANGLER_SEND_METRICS':'false','CI':'true'})
receipt={'task':'E9-T13','status':'running','head':head,'source':str(root),'command':cmd,
 'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before':before,
 'prepared_receipt':str(prepared),'prepared_receipt_sha256':sha(raw),
 'login_receipt':str(auth),'login_receipt_sha256':sha(auth.read_bytes()),
 'scope':'Ordinary authorized Cloudflare Pages publication of the exact locally proven runtime; unchanged boot manifests and Pages release extras authenticated by the prepared receipt. No build or implementation change. Authentication/debug logs remain private and are excluded.'}
rp=out/'receipt.json';rp.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':'publishing','head':head,**before}),flush=True)
fd=os.open(private,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'wb')as log:
 result=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
if debug.exists():debug.chmod(0o600)
text=private.read_text(errors='replace')
clean=re.sub(r'\x1b\[[0-9;]*m','',text)
urls=sorted(set(re.findall(r'https://[a-z0-9.-]+\.pages\.dev/?',clean)))
public_lines=[]
for line in clean.splitlines():
 if any(x in line for x in ['Success! Uploaded','Deployment complete!','Take a peek','Alias:','Uploading _headers','Uploading _redirects']):
  if not any(x in line.lower()for x in ['token','authorization','bearer','cookie']):public_lines.append(line)
publiclog='\n'.join(public_lines)+'\n'
(out/'deployment-public.log').write_text(publiclog)
receipt.update({'status':'published'if result.returncode==0 and urls else'failed',
 'exit_code':result.returncode,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'public_urls':urls,'production_url':'https://wasm-vm.pages.dev/',
 'after':inventory(),'deployment_public_log':'deployment-public.log',
 'deployment_public_log_sha256':sha(publiclog.encode()),
 'private_stdout_sha256':sha(private.read_bytes()),'private_stdout_bytes':private.stat().st_size})
rp.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'exit_code':result.returncode,'public_urls':urls,'receipt':str(rp),'sha256':sha(rp.read_bytes())}),flush=True)
if receipt['status']!='published':raise SystemExit(1)
