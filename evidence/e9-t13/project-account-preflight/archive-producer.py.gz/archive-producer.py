from pathlib import Path
import json,hashlib,gzip,time,subprocess,re,os
repo=Path('/Volumes/e9-t11-cold-scratch/cold-source-e9-t12-986c38e6b7ed')
ram=Path('/Volumes/e9-final-proof-ram')
proof=Path('/Volumes/e9-t13-wfi-cold/e9-t13-wfi-publication')
out=repo/'evidence/e9-t13/project-account-preflight'
out.mkdir(parents=True,exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
expected=json.loads(Path('/Users/blamy/Documents/Codex/wasm-vm/.wrangler/cache/wrangler-account.json').read_text())['account']
current=json.loads((ram/'e9-t13-wfi-publication-source/.wrangler/cache/wrangler-account.json').read_text())['account']
assert expected['id']!=current['id']
original_target=proof/'target-account-availability.json'
target=json.loads(original_target.read_text())
assert target['explicit_account_id']==expected['id']
target['explicit_account_id_sha256']=sha(target.pop('explicit_account_id').encode())
target['original_local_receipt_sha256']=sha(original_target.read_bytes())
target['privacy_note']='Raw account identifier and account labels are retained locally, not published in this packet.'
public_target=proof/'target-account-availability-public.json'
public_target.write_text(json.dumps(target,indent=2)+'\n')
auth=ram/'e9-t13-authorized-publication-auth-result.json'
login=json.loads(auth.read_text())
deployment=json.loads((proof/'receipt.json').read_text())
projects=json.loads((proof/'project-availability.json').read_text())
assert login['exit_code']==0 and login['authenticated_marker'] and not login['unauthenticated_marker']
assert deployment['status']=='failed' and deployment['exit_code']==1 and deployment['public_urls']==[]
assert deployment['before']==deployment['after']=={'files':750,'bytes':84317110}
assert projects['exit_code']==0 and projects['target_present'] is False
assert target['exit_code']==1 and target['authentication_error'] and target['api_error_codes']==['10000']
diagnosis={
 'task':'E9-T13','time':time.time(),'runtime':deployment['head'],
 'status':'Authenticated session cannot access the repo saved project account; no publication',
 'current_account_id_sha256':sha(current['id'].encode()),
 'expected_account_id_sha256':sha(expected['id'].encode()),
 'account_match':False,'login_authenticated':True,
 'standard_deploy_error':'The Pages project "wasm-vm" does not exist.',
 'standard_deploy_exit_code':1,
 'current_account_project_count':projects['project_count'],
 'target_present_in_current_account':False,
 'repo_saved_account_probe_api_error_codes':target['api_error_codes'],
 'repo_saved_account_probe_authentication_error':True,
 'payload':deployment['before'],'payload_unchanged':True,
 'pending':'Official Wrangler authorization for the project owning account, actual deployment and public-browser evidence. G9 independent execution/sensitivity/suite disposition also remains unfinished.',
 'scope':'Read-only account diagnosis after the ordinary deployment refused. No account, project, permission or credential created; no T13 runtime deployed. Actual account labels/IDs and private authentication/debug output are not published.'
}
public_diag=proof/'account-diagnosis-public.json';public_diag.write_text(json.dumps(diagnosis,indent=2)+'\n')
failure=proof/'deployment-failure-public.log'
failure.write_text('Wrangler pages deploy web/dist --project-name wasm-vm --branch main --commit-dirty=true\nExit: 1\n[ERROR] The Pages project "wasm-vm" does not exist.\nNo deployment URL returned. The authenticated current-account project list has no wasm-vm; the repo saved account read-only query returns API10000 authentication error.\n')
records=[]
def keep(path,name,expected_digest=None):
 raw=path.read_bytes()
 if expected_digest:assert sha(raw)==expected_digest,str(path)
 for account in (current,expected):
  assert account['id'].encode()not in raw,str(path)
  assert account['name'].encode()not in raw,str(path)
 compressed=gzip.compress(raw,compresslevel=9,mtime=0)
 dst=out/(name+'.gz');dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(compressed)
 assert gzip.decompress(dst.read_bytes())==raw
 records.append({'original_path':str(path),'artifact':str(dst.relative_to(out)),'size':len(raw),'sha256':sha(raw),'gzip_size':len(compressed),'gzip_sha256':sha(compressed)})
inputs=[
 (auth,'receipts/login-authenticated.json',None),
 (ram/'e9-t13-authorized-publication-auth.py','producers/auth-status.py',None),
 (ram/'e9-t13-wfi-publication-prepared/receipt.json','receipts/prepared-payload.json','9f5ec1661f7d1895c59b332750dab1a803b8477358c86a0da62f75e2a1714163'),
 (ram/'e9-t13-wfi-prepublication-inventory.json','receipts/prepublication-inventory-original.json',None),
 (ram/'e9-t13-wfi-prepublication-inventory-v2.json','receipts/prepublication-inventory-corrected.json','7f7a2eda4d8916c99920b6a35aa0bd2581ebb8e9a4d827c9dfcc96b904ca661d'),
 (ram/'e9-t13-publish-frozen-wfi.py','producers/publish-frozen.py',None),
 (proof/'receipt.json','receipts/publication-refusal.json','b5851b90c572efab98e3ce75bdb6557c3e82f537147c4ce7c5a3b2ca565c56da'),
 (failure,'receipts/deployment-failure-public.log',None),
 (proof/'project-availability.json','receipts/current-project-availability.json',None),
 (public_target,'receipts/target-account-availability-public.json',None),
 (public_diag,'receipts/account-diagnosis-public.json',None),
 (repo/'tasks/epic-9-session-time-travel/E9-T13-network-capture.md','boundary/task-before-account-log.md',None),
 (Path(__file__),'archive-producer.py',None)
]
for path,name,digest in inputs:keep(path,name,digest)
manifest={'kind':'Authenticated account mismatch and failed ordinary publication; no deployment or verification verdict',
 'task':'E9-T13','created':time.time(),'frozen_runtime':deployment['head'],
 'repository_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
 'privacy':'Credential material, private authentication/debug logs and account labels/identifiers excluded. Account identifiers are represented only by SHA256 digests in the public diagnosis.',
 'entries':records}
p=out/'provenance.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
(out/'README.md').write_text(
 '# Project-account preflight\n\n'
 'The refreshed official Wrangler session is authenticated, but its current account has no wasm-vm Pages project. The ordinary deployment refuses with exit1 before returning a deployment URL. A bounded read-only query against the repo saved target account returns authentication error API10000. Account fingerprints differ. The same750-file payload remains unchanged at frozen runtime2f2aa7.\n\n'
 'This packet preserves the nonsecret command receipts, payload inventory, ordinary producer and sanitized account diagnosis. The original inventory report has a path-label error; its additive corrected report is preserved alongside it. All payload checks themselves passed. Actual account names/identifiers and private authentication/debug logs remain local. No credential material is copied. This is neither a successful publication nor a task verification verdict. Correct project-account authorization, publication/public-browser proof and the unfinished G9 independent charter remain required.\n')
result={'packet':str(p),'sha256':sha(p.read_bytes()),'entries':len(records),'gzip_bytes':sum(x['gzip_size']for x in records)}
(ram/'e9-t13-account-preflight-packet-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
