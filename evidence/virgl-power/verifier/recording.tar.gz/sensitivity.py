#!/usr/bin/env python3
"""Original-source oracle must reject actual hardware faults and cached forgery."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for label,prefix in [('hot','hot'),('cold','cold/acceptance')]:
 for fault in('base','exponent','broadcast'):
  report=OUT/'unpacked'/prefix/('fault-'+fault)/'report.json';output=OUT/(label+'-fault-'+fault+'-guards.json');command=['python3','renderer/virgl-shader/tests/power-capture-regressions.py','--report',str(report),'--output',str(output)];run=subprocess.run(command,cwd=ROOT,capture_output=True)
  (OUT/(label+'-fault-'+fault+'-guards.log')).write_bytes(run.stdout+run.stderr);guard=json.loads(output.read_bytes());assert run.returncode!=0 and guard['status']=='failed'and 'prediction'in guard['failure']['message']
  original=json.loads(report.read_bytes());changed=[v for v in original['acceptance']['vertices']if v['mutation']];assert len(changed)==1 and changed[0]['backend']=='owned';v=changed[0];point=next(x for x in v['vectors']if 'failure'in x)
  rows.append(dict(checkout=label,fault=fault,exit=run.returncode,reportSha256=sha(report.read_bytes()),guardSha256=sha(output.read_bytes()),sourceSha256=v['textSha256'],captureSha256=point['sha256'],mutation=v['mutation'],failure=guard['failure']))
# A stored expectation forged around the faulty observation cannot turn it
# into evidence. TGSI operand versions and rational equations still control.
source=OUT/'unpacked/hot/fault-base/report.json';j=json.loads(source.read_bytes());j['status']=j['acceptance']['status']='passed'
for v in j['acceptance']['vertices']:
 for x in v['vectors']:
  if 'failure'not in x:continue
  lane=x['failure']['lane'];row=x['oracles'][lane];w=x['reconstructed'][lane];row['allowedLower']=row['allowedUpper']=dict(n=str(w),d='1');row['exact']=w
for v in j['acceptance']['vertices']:
 for x in v['vectors']:
  x.pop('failure',None)
forged=OUT/'forged-cached-oracle.json';forged.write_text(json.dumps(j,indent=2)+'\n');output=OUT/'forged-cached-oracle-guards.json';command=['python3','renderer/virgl-shader/tests/power-capture-regressions.py','--report',str(forged),'--output',str(output)];run=subprocess.run(command,cwd=ROOT,capture_output=True);(OUT/'forged-cached-oracle-guards.log').write_bytes(run.stdout+run.stderr);guard=json.loads(output.read_bytes());assert run.returncode!=0 and guard['status']=='failed'and 'prediction'in guard['failure']['message']
rows.append(dict(fault='forged cached expectation around actual source fault',exit=run.returncode,reportSha256=sha(forged.read_bytes()),guardSha256=sha(output.read_bytes()),failure=guard['failure']))
(OUT/'sensitivity.json').write_text(json.dumps(dict(status='passed',records=rows),indent=2)+'\n');print('All6 actual physical source faults and a cached-oracle forgery independently rejected.')
