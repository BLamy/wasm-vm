#!/usr/bin/env python3
"""Replay each sealed binary with its own fixture and original LLVM profile."""
from pathlib import Path
import hashlib,json,subprocess,os
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;UNPACKED=OUT/'unpacked'
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[]
for label,prefix,gprefix in [('hot','hot','generated'),('cold','cold/acceptance','cold-generated')]:
 binary=UNPACKED/gprefix/'power-sanitize/power-test';native=UNPACKED/prefix/'native'
 binary.chmod(0o700)
 env=dict(os.environ,LLVM_PROFILE_FILE=str(OUT/(label+'-replay.profraw')),ASAN_OPTIONS='abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
 run=subprocess.run([str(binary)],input=(native/'cases.bin').read_bytes(),capture_output=True,env=env)
 (OUT/(label+'-native-replay.log')).write_bytes(run.stdout);(OUT/(label+'-native-replay.stderr')).write_bytes(run.stderr)
 assert run.returncode==0 and not run.stderr and run.stdout==(native/'native.log').read_bytes(),label+' exact sealed replay'
 profile=OUT/(label+'-original.profdata')
 subprocess.run(['xcrun','llvm-profdata','merge','-sparse',str(native/'native.profraw'),'-o',str(profile)],check=True)
 coverage=json.loads(subprocess.check_output(['xcrun','llvm-cov','export',str(binary),'-instr-profile='+str(profile)]))
 for d in coverage['data']:
  d['files']=[f for f in d['files']if any(f['filename'].endswith('/'+s)for s in ['bridge.c','raw_bits.c','native_tests/power.c'])]
  d['functions']=[f for f in d['functions']if any(any(p.endswith('/'+s)for s in ['bridge.c','raw_bits.c','native_tests/power.c'])for p in f['filenames'])]
 assert coverage==json.loads((native/'coverage.json').read_bytes()),label+' original profile export'
 cp=OUT/(label+'-coverage-export.json');cp.write_text(json.dumps(coverage,indent=2)+'\n')
 for name in ['bridge.c','raw_bits.c','native_tests/power.c']:
  source=next(f['filename']for d in coverage['data']for f in d['files']if f['filename'].endswith('/'+name))
  text=subprocess.check_output(['xcrun','llvm-cov','show',str(binary),'-instr-profile='+str(profile),'-show-line-counts-or-regions',source],stderr=subprocess.STDOUT)
  (OUT/(label+'-coverage-'+name.replace('/','_')+'.txt')).write_bytes(text)
 report=json.loads((native/'report.json').read_bytes())
 rows.append(dict(label=label,binarySha256=sha(binary.read_bytes()),fixtureSha256=sha((native/'cases.bin').read_bytes()),
  originalProfileSha256=sha((native/'native.profraw').read_bytes()),replayedLogSha256=sha(run.stdout),
  stderrSha256=sha(run.stderr),originalProfileExportSha256=sha(cp.read_bytes()),originalProfileExportEqualsWorker=True,
  cases=len(report['cases']),primaryComparisons=report['primaryComparisons']))
(OUT/'native-replays.json').write_text(json.dumps(dict(status='passed',records=rows),indent=2)+'\n')
print(json.dumps(dict(status='passed',records=rows)))
