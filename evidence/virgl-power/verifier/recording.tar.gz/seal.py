#!/usr/bin/env python3
"""Seal the completed critic session, including actual scratch faults and profiles."""
from pathlib import Path
import gzip, hashlib, io, json, tarfile
R=Path(__file__).resolve().parents[3];O=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
verdict=json.loads((O/'verdict.json').read_bytes());auth=json.loads((O/'authentication.json').read_bytes())
assert verdict['verdict']=='verified' and all(r['status']=='HELD' for r in verdict['predictions'])
skip={'recording.tar.gz','records.json','manifest.json','README.md','seal.log'}
members={}
for p in sorted(O.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(O);parts=rel.parts;name=str(rel)
 if parts[0]=='unpacked' or '__pycache__' in parts or p.name in skip or '.dSYM' in name:continue
 if parts[0]=='sabotage' and not (name.endswith('/renderer/virgl-shader/raw_bits.c') or name.endswith('/renderer/virgl-shader/build/native/virgl-shader')):continue
 members[name]=p.read_bytes()
index=dict(schema='virgl-power-critic-records-v1',task='E6-T12g6j2',criticHead=verdict['criticGuardHead'],
 workerArchiveSha256=auth['archiveSha256'],records=[dict(path=n,bytes=len(b),sha256=sha(b)) for n,b in sorted(members.items())])
idx=(json.dumps(index,indent=2)+'\n').encode();(O/'records.json').write_bytes(idx)
out=io.BytesIO()
with gzip.GzipFile(fileobj=out,mode='wb',mtime=0) as z:
 with tarfile.open(fileobj=z,mode='w') as t:
  for n,b in sorted(members.items()):
   i=tarfile.TarInfo(n);i.size=len(b);i.mtime=0;i.mode=0o755 if n.endswith('/build/native/virgl-shader') else 0o644
   t.addfile(i,io.BytesIO(b))
raw=out.getvalue();(O/'recording.tar.gz').write_bytes(raw)
manifest=dict(schema='virgl-power-critic-seal-v1',task='E6-T12g6j2',verdict='verified',
 prerequisite=verdict['prerequisite'],workerSubmissionHead=verdict['workerSubmissionHead'],
 workerEvidenceHead=verdict['workerEvidenceHead'],frozenRuntime=verdict['workerEvidenceHead'],criticHead=verdict['criticGuardHead'],
 records=len(members),archive=dict(path='recording.tar.gz',bytes=len(raw),sha256=sha(raw)),
 recordIndex=dict(path='records.json',bytes=len(idx),sha256=sha(idx)),verdictSha256=sha((O/'verdict.json').read_bytes()),
 predictionsSha256=sha((O/'predictions.json').read_bytes()),
 workerManifestSha256=sha((R/'evidence/virgl-power/worker/manifest.json').read_bytes()),
 workerArchiveSha256=auth['archiveSha256'],workerRecordIndexSha256=auth['indexSha256'],
 independentGuards=1914,independentMetadataAttacks=298,originalWorkerMetadataAttacks=516,
 fourthSeed=2654435769,fourthWords=12384,fourthPixels=21760,uniquePhysicalSeeds=4,
 totalUniqueWords=49536,totalUniquePixels=87040,canonicalPrimaryWords=14496,concreteVendorDeviations=856,
 changedRuntimeLines=77,waivers=18,selectorArms=11,productionNegotiation=False,guestExecution=False,
 coldProof=dict(sourceHead=verdict['workerEvidenceHead'],reportSha256=auth['receipts']['cold/report.json'],
 incremental=True,additionalClone=False),qualifications=verdict['qualifications'])
(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(O/'recording.tar.gz') as t:
 actual=t.getmembers();assert len(actual)==len(members) and len({r.name for r in actual})==len(actual)
 for r in actual:
  data=t.extractfile(r).read();assert data==members[r.name]
  row=next(e for e in index['records'] if e['path']==r.name);assert len(data)==row['bytes'] and sha(data)==row['sha256']
print(json.dumps(manifest,indent=2))
