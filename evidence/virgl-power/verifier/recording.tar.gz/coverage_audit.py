#!/usr/bin/env python3
"""Hold every changed runtime line against authenticated and supplement profiles."""
from pathlib import Path
import hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;UNPACKED=OUT/'unpacked';sha=lambda b:hashlib.sha256(b).hexdigest()
paths=['renderer/virgl-shader/raw_bits.c','renderer/virgl-shader/bridge.c','renderer/virgl-shader/raw_bits.h','renderer/virgl-command/constant-domain.mjs']
patch=subprocess.check_output(['git','diff','--unified=0','ff4692e52a3ea52ee75368358b46fed1bd3fce9b..6fcadd1eaa08f72b3fd7d301ce1df88fca452b1d','--',*paths],cwd=ROOT,text=True);added={};file=None;line=0
for s in patch.splitlines():
 if s.startswith('+++ b/'):file=s[6:];added[file]=[]
 elif s.startswith('@@'):line=int(re.search(r'\+(\d+)',s)[1])
 elif s.startswith('+')and not s.startswith('+++'):added[file].append((line,s[1:]));line+=1
 elif not s.startswith('-')and not s.startswith(('diff','index','---','\\')):line+=1
exports={label:json.loads((OUT/name).read_bytes())for label,name in [('hot','hot-coverage-export.json'),('cold','cold-coverage-export.json'),('critic','critic-native-coverage.json')]}
binary=UNPACKED/'generated/power-sanitize/power-test';profile=OUT/'critic-native.profdata'
for p in paths[:2]:
 source=next(f['filename']for d in exports['critic']['data']for f in d['files']if f['filename'].endswith('/'+Path(p).name))
 text=subprocess.check_output(['xcrun','llvm-cov','show',str(binary),'-instr-profile='+str(profile),'-show-line-counts-or-regions',source],stderr=subprocess.STDOUT)
 (OUT/('critic-coverage-'+Path(p).name+'.txt')).write_bytes(text)
counts={}
for label in exports:
 for p in paths[:2]:
  seen={}
  for s in (OUT/(label+'-coverage-'+Path(p).name+'.txt')).read_text().splitlines():
   m=re.match(r'\s*(\d+)\|\s*([0-9.]+[kMGT]?)\|',s)
   if m:
    x=m[2];scale={'k':1000,'M':10**6,'G':10**9,'T':10**12}.get(x[-1],1);n=float(x[:-1]if scale!=1 else x)*scale;seen[int(m[1])]=max(seen.get(int(m[1]),0),n)
  counts[(label,p)]=seen
runtime=[];waivers=[]
for p in paths[:2]:
 for line,text in added[p]:
  c={label:counts[(label,p)].get(line,0)for label in exports}
  if any(c.values()):runtime.append(dict(path=p,line=line,source=text,originalOrSupplementProfileCounts=c,status='executed'))
  else:
   assert not text.strip()or text.strip().startswith(('/*','*','//','{','}'))or text.strip().startswith(('static void power_contract','static bool power_domain_proved')),(p,line,text)
   waivers.append(dict(path=p,line=line,source=text,status='waived',reason='Nonexecuting signature, brace or documentation; adjacent runtime body executes in both matching original profiles and the independent unchanged-binary supplement.'))
for line,text in added[paths[2]]:waivers.append(dict(path=paths[2],line=line,source=text,status='waived',reason='Declarative opcode56, numeric masks and compile-time separation assertion. Native/Wasm admission, FLOAT/REPL pinned parser, snapshots and physical results exercise their runtime use; no separate behavior.'))
branches=[]
for label,j in exports.items():
 f=next(f for d in j['data']for f in d['files']if f['filename'].endswith('/raw_bits.c'))
 branches.extend(dict(label=label,line=b[0],column=b[1],true=b[4],false=b[5])for b in f['branches']if 206<=b[0]<=234)
assert all(any(b[k]>0 for b in branches if b['line']==line and b['column']==column)for line,column in {(b['line'],b['column'])for b in branches}for k in('true','false')if (line,column,k)!=(232,40,'true'))
waivers.append(dict(path=paths[0],line=232,column=40,status='waived',reason='The true outcome of product <= (120 >> scale) is unreachable. scale>=0 implies exponent field>=150 and significand>=2^23. A nonunit base has integer log_size>=1, hence product>=2^23>120>=(120>>scale). Unit bases have log_size=0 and return earlier at !product. The product-zero exponent identity likewise returns earlier. Both scale<7 outcomes execute, and the final comparison false outcome executes128 times in the supplement.'))
jspath=paths[3];js=(ROOT/jspath).read_text();bindings=[]
for checkout in ['hot','cold/acceptance']:
 for seed in [608135816,2242054355,320440878]:
  directory=UNPACKED/checkout/f'gpu-{seed}';report=json.loads((directory/'report.json').read_bytes());raw=(directory/'browser-coverage.json').read_bytes();assert sha(raw)==report['browserCoverage']['sha256']
  script=next(s for s in json.loads(raw)['scripts']if s['source']==jspath);assert script['sha256']==sha((ROOT/jspath).read_bytes());bindings.append(dict(label=checkout+'-'+str(seed),sha256=sha(raw),functions=script['coverage']['functions']))
for f in sorted((OUT/'node-consumer-coverage').glob('*.json')):
 j=json.loads(f.read_bytes())
 for script in j['result']:
  if script['url'].endswith('/'+jspath):bindings.append(dict(label='critic-node-owned-consumer',sha256=sha(f.read_bytes()),functions=script['functions']))
def effective(functions,offset):
 ranges=[r for f in functions for r in f['ranges']if r['startOffset']<=offset<r['endOffset']]
 return min(ranges,key=lambda r:r['endOffset']-r['startOffset'])['count']if ranges else 0
for line,text in added[jspath]:
 if not text.strip():waivers.append(dict(path=jspath,line=line,status='waived',reason='Blank separation.'));continue
 offset=sum(len(s)+1 for s in js.splitlines()[:line-1])+len(text)-len(text.lstrip());c={b['label']:effective(b['functions'],offset)for b in bindings};assert any(c.values()),(line,text,c)
 runtime.append(dict(path=jspath,line=line,source=text,V8Counts=c,status='executed'))
guards=json.loads((OUT/'independent-regressions.json').read_bytes());selectors=[dict(name=c['name'],base=c['result']['metadata']['powerBaseProfile'],resultSha256=sha(json.dumps(c['result'],sort_keys=True).encode()))for c in guards['native']if c['name'].startswith('wrapper-selector')]
assert {int(c['base'].rsplit('v',1)[1])for c in selectors}=={1,27,28,29,30,31,32,33,34,35,36}
legacy=json.loads((UNPACKED/'hot/legacy.json').read_bytes());profiles=sorted({c['added']['metadata']['powerBaseProfile']for c in legacy['cases']if c['ok']});consumer=json.loads((UNPACKED/'hot/consumer.json').read_bytes());assert len(consumer['combined'])==4
out=dict(status='passed',changedRuntimeLines=runtime,waivers=waivers,domainBranches=branches,selectorArms=selectors,nativeBindings=json.loads((OUT/'native-replays.json').read_bytes()),supplement=json.loads((OUT/'critic-native-recording.json').read_bytes()),V8Bindings=[{k:v for k,v in b.items()if k!='functions'}for b in bindings],legacyWrapperBases=profiles,simultaneousWrapperBases=4,scope='Every changed C/mjs runtime line, every power-domain branch outcome except one proved impossible comparison, and all11 inherited wrapper selector arms. Unchanged predecessor behavior carried incrementally.')
(OUT/'coverage-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(len(runtime),'changed runtime lines exercised;',len(waivers),'declarative/unreachable waivers; line212 independent rejection true20/false6.')
