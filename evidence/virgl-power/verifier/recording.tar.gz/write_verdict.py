#!/usr/bin/env python3
"""Produce the independent verdict after all predicted checks have held."""
from pathlib import Path
import json, hashlib
O=Path(__file__).resolve().parent; R=O.parents[2]
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda n:json.loads((O/n).read_bytes())
before=load('predictions.json');final=load('final-audits.json');coverage=load('coverage-audit.json')
assert final['status']==coverage['status']=='passed'
assert load('wiring-checks.json')['status']=='passed'
def point(record,pointer=''):
 value=dict(record=record,sha256=sha((O/record).read_bytes()))
 if pointer:value['point']=pointer
 return value
observations={
 'P1': ('Authenticated all147 members and both exact-source receipts;384 tracked hot/cold sources agree,13 incidental hot-only generated files are absent in the successful pristine clone. Replayed each original sanitizer binary/fixture and re-exported each own original profile with matching coverage.',
  [point('authentication.json','/receipts'),point('native-replays.json','/records'),point('carry-forward.json','/coldIncremental')]),
 'P2': ('1914 independent native/Wasm predictions agree, including zero-capable joins with zero/negative exponents and positive endpoint exponent cubes that can contain zero. The unchanged original sanitizer binary records20 hits on the formerly unexercised line212,column35 rejection outcome.',
  [point('independent-regressions.json','/native/1091: joined-cube-0-1056964608-8388608-16777216'),point('critic-native-recording.json'),point('coverage-audit.json','/domainBranches: critic line212,column35')]),
 'P3': ('All15 masks, both source aliases, swizzle pairs, post-modifier operands, unused specials and consumed uninitialized lanes obey the independently predicted admission and snapshots. Physical equations derive original TGSI versions before masked publication.',
  [point('independent-regressions.json','/native/1857: aliased-snapshots-0-x; /native/1861: aliased-snapshots-1-x; consumed-mask-* and initialized-x-only-*'),point('fourth-source-guards.json','/physical/points'),point('sabotage-regressions.json','/records: exponent-snapshot')]),
 'P4': ('Saved and killed versions, opaque arithmetic, negation order, consumed dependencies, no static result/F2I authority and inherited bank obligations held; deliberately granting a zero fact is refuted by the promoted test.',
  [point('independent-regressions.json','/native/1853: saved-version-0-TEMP[3]; /native/1854: saved-version-0-TEMP[4] invalid live version; opaque-* and no-result-lane-facts-*'),point('consumer-boundary-attacks.json','/ownership'),point('sabotage-regressions.json','/records: result-facts')]),
 'P5': ('Each sealed checkout has1167 equal native/Wasm singles and pairs and1106 authentic pinned FLOAT/REPL witnesses. The critic retained the original converter componentwise pow and constructor-mask-rank behavior. Four unique seeds preserve856 concrete vendor deviations and14496 canonical words; original literal-source enumeration finds72 sites and14 exponent words.',
  [point('native-replays.json'),point('reference-audit.json','/captures'),point('final-audits.json','/allUniquePhysicalSeeds'),point('carry-forward.json','/wholePredecessorResponses')]),
 'P6': ('Independent original-TGSI equations use exact binary32 rationals and outward1040-bit dyadic atanh/exp intervals, nesting in both worker160/220-decimal intervals for80 equations. All four unique seeds meet relative<=2^-14 or exact owned+0; maximum conservative owned error1.1862894318599564e-6 and Mesa6.09422101737745e-8.',
  [point('reference-audit.json','/rows'),point('final-audits.json','/maximumObservedRelativeError'),point('fourth-source-guards.json','/physical/maximumObservedError')]),
 'P7': ('Seed2654435769 was physically captured on headed ANGLE Metal Apple M4 Max WebGL2 at committed critic harness headfcf065ac with trackedChanges=[] and no errors.12384 feedback words/21760 RGBA8 pixels have complete source/reflection/capture bindings and zero live objects.80 new pinned native witnesses and before-observation equations are sealed. Four unique seeds total49536 words/87040 pixels.',
  [point('fourth-command.json'),point('fourth-plan.json'),point('gpu-2654435769/report.json','/trackedChanges'),point('final-audits.json','/fourthCoverage')]),
 'P8': ('298 additional owned metadata and bank attacks reject recursive, forged, sparse, symbol, accessor, revoked and throwing policies without invoking getters. Complete delegation and immutable snapshots held; both actual sync/async hardware consumers poison caller storage, restore A/B/A banks, reject atomically and dispose all objects.',
  [point('consumer-boundary-attacks.json'),point('fourth-source-guards.json','/physical'),point('gpu-2654435769/report.json','/acceptance/consumers')]),
 'P9': ('All6 original physical source faults are contradicted by original-source equations, including a forged cached oracle around the faulty observation. Four actual scratch runtime mutations and two test-source mutations are refuted. Exact promoted receipt statements accept authentic records and reject4 tampered records.',
  [point('sensitivity.json','/records'),point('sabotage-regressions.json','/records'),point('wiring-checks.json','/tamperChecks')]),
 'P10': ('77 changed runtime lines executed and all11 profile selector arms are covered.17 declarative/documentation line waivers and one mathematically impossible comparison outcome are explicit. SAT/EX/SIN seals,15256 inherited guards,6867 complete responses,3 admitted old POW spellings and2 inherited SIN admissions retain their authority.26 original computed/uniform sites and2 full larger bodies stay gated. Runtime/production/capability sources remain unchanged.',
  [point('coverage-audit.json','/waivers'),point('coverage-audit.json','/selectorArms'),point('carry-forward.json'),point('final-audits.json','/unchangedTrackedSources')])}
rows=[]
for prediction in before['predictions']:
 observed,citations=observations[prediction['id']]
 rows.append(dict(**prediction,status='HELD',observed=observed,citations=citations,demand=None))
result=dict(schema='virgl-power-critic-verdict-v1',task='E6-T12g6j2',verdict='verified',
 prerequisite=before['prerequisite'],workerEvidenceHead=before['workerSourceHead'],workerSubmissionHead=before['workerSubmissionHead'],
 criticGuardHead=final['criticHead'],predictionsMadeBeforeInspection=True,predictionsSha256=sha((O/'predictions.json').read_bytes()),
 predictions=rows,coverage=dict(executedRuntimeLines=77,waivers=18,selectorArms=11,
 zeroCapableJoinSupplement='Original unchanged sealed hot binary, line212,column35 true20/false6; independent native and Wasm reject the cube.',
 impossibleOutcome='raw_bits.c:232,column40 true. scale>=0 requires significand>=2^23. Nonunit integer log_size>=1 forces product>=2^23>120>=(120>>scale); unit or exponent-zero identities return at !product.'),
 suite=dict(commit=final['criticHead'],nativeWasmGuards=1914,captureOracle='renderer/virgl-shader/tests/power-capture-regressions.py',
 nativeGuard='renderer/virgl-shader/tests/power-regressions.mjs',acceptance='make verify-E6-T12g6j2',
 wiringChecks=point('wiring-checks.json'),retainedOriginalFixtureSpellings=True),
 measuredHardware=load('fourth-source-guards.json')['physical']['renderer'],allUniquePhysicalSeeds=final['allUniquePhysicalSeeds'],
 maximumObservedRelativeError=final['maximumObservedRelativeError'],productionNegotiation=False,guestExecution=False,
 qualifications=['Measured physical-host relative budget, not a portable ESSL accuracy guarantee.',
 'Original componentwise vendor GLSL remains unchanged and is independently evaluated; scalar and mask-rank equations are distinguished.',
 'Known initializers isolate literal statements, never authorize computed/uniform original domains or full compositor bodies.',
 'One authenticated final pristine clone at frozen runtime head is carried forward incrementally after test/wiring-only promotions.',
 'No production capability/offload/performance/FPS/MIPS claim.'])
(O/'verdict.json').write_text(json.dumps(result,indent=2)+'\n')
print('VERDICT: verified; all10 prior predictions HELD; promoted guards and original-source equations sealed.')
