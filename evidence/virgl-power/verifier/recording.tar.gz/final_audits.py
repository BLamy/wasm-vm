#!/usr/bin/env python3
"""Bind the final critic records to the committed harness and immutable runtime."""
from pathlib import Path
import ast, copy, hashlib, json, subprocess
R = Path(__file__).resolve().parents[3]
O = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda n: json.loads((O/n).read_bytes())
FROZEN = '6fcadd1eaa08f72b3fd7d301ce1df88fca452b1d'
CRITIC = 'fcf065acf2397362057ab85b75708212ca09fe29'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip() == CRITIC
assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R)
allowed = {
 'evidence/virgl-power/worker/README.md', 'evidence/virgl-power/worker/manifest.json',
 'evidence/virgl-power/worker/records.json','evidence/virgl-power/worker/recording.tar.gz',
 'tasks/QUEUE.md','tasks/epic-6-transcendence/E6-T12g6j2-power.md',
 'renderer/virgl-shader/tests/power-regressions.mjs',
 'renderer/virgl-shader/tests/power-capture-regressions.py',
 'tools/verify-virgl-power.sh','tools/virgl-power/receipt.py'}
changed = set(subprocess.check_output(['git','diff','--name-only',FROZEN,CRITIC],cwd=R,text=True).splitlines())
assert changed == allowed
auth = load('authentication.json')
bindings = []
for name, digest in auth['trackedSources']['hot'].items():
 if name in changed: continue
 raw = (R/name).read_bytes()
 assert sha(raw) == digest
 assert raw == subprocess.check_output(['git','show',f'{FROZEN}:{name}'],cwd=R)
 bindings.append(dict(path=name,sha256=digest,authority='unchanged-worker-source'))
for name,digest in auth['generatedSources']['hot'].items():
 assert sha((R/name).read_bytes()) == digest, ('restored generated artifact',name)
guard = load('independent-regressions.json')
assert guard['testSha256'] == sha((R/'renderer/virgl-shader/tests/power-regressions.mjs').read_bytes())
assert guard['cases'] == len(guard['native']) == len(guard['wasm']) == 1914
assert all(a['result']==b['result'] for a,b in zip(guard['native'],guard['wasm']))
assert guard['nativeBinary']['sha256'] == auth['generatedSources']['hot']['renderer/virgl-shader/build/native/virgl-shader']
positive = ['authentication.json','native-replays.json','independent-regressions.json',
 'critic-native-recording.json','consumer-boundary-attacks.json','coverage-audit.json',
 'reference-audit.json','carry-forward.json','sabotage-regressions.json','sensitivity.json',
 'fourth-source-semantics.json','fourth-source-guards.json']
for checkout in ['hot','cold']:
 for seed in [608135816,2242054355,320440878]: positive.append(f'{checkout}-source-{seed}.json')
for name in positive: assert load(name)['status']=='passed',name
for prefix in ['hot','cold']:
 for fault in ['base','exponent','broadcast']:
  value=load(f'{prefix}-fault-{fault}-guards.json')
  assert value['status']=='failed' and 'prediction' in value['failure']['message']
for fault in ['zero-capable-domain','exponent-snapshot','zero-bypass','result-facts']:
 value=load(f'sabotage-{fault}-guards.json'); assert value['status']=='failed'
for name in ['sabotage-test-guards.json','sabotage-test-capture.json','forged-cached-oracle-guards.json']:
 assert load(name)['status']=='failed'
report=load('gpu-2654435769/report.json'); source_map={r['path']:r for r in report['sources']}
assert report['gitHead']==CRITIC and report['trackedChanges']==[]
assert report['browserErrors']==dict(console=[],page=[],requests=[])
assert report['productionNegotiation'] is False and report['guestExecution'] is False
overrides={'renderer/virgl-shader/build/power-primary.json':'fourth-primary.json',
 'renderer/virgl-shader/build/power-reference.json':'fourth-reference.json'}
for row in report['sources']:
 raw=(O/overrides[row['path']]).read_bytes() if row['path'] in overrides else (R/row['path']).read_bytes()
 assert sha(raw)==row['sha256'] and len(raw)==row['size'],row['path']
 if not row['path'].startswith('renderer/virgl-shader/build/'):
  assert raw==subprocess.check_output(['git','show',f'{CRITIC}:{row["path"]}'],cwd=R)
for row in report['servedFiles']: assert row==source_map[row['path']]
for field in ['screenshot','browserCoverage']:
 row=report[field];assert sha((O/'gpu-2654435769'/row['path']).read_bytes())==row['sha256']
for row in load('gpu-2654435769/browser-coverage.json')['scripts']:
 assert sha((R/row['source']).read_bytes())==row['sha256']==source_map[row['source']]['sha256']
assert report['browser']['launch']['headless'] is False
assert report['browser']['gpu']['featureStatus'][report['browser']['webglFeature']]=='enabled'
fresh=load('fourth-source-guards.json')
assert fresh['reportSha256']==sha((O/'gpu-2654435769/report.json').read_bytes())
assert fresh['testSha256']==sha((R/'renderer/virgl-shader/tests/power-capture-regressions.py').read_bytes())
assert fresh['physical']==load('fourth-source-semantics.json')['physical']
assert report['acceptance']['objects']['live']==0
physical=[load(f'hot-source-{s}.json')['physical'] for s in [608135816,2242054355,320440878]]+[fresh['physical']]
assert len({r['seed'] for r in physical})==4
totals=dict(words=sum(r['words'] for r in physical),pixels=sum(r['pixels'] for r in physical),
 deviations=sum(len(r['deviations']) for r in physical),canonicalPrimaryWords=sum(r['canonicalPrimaryWords'] for r in physical))
assert totals==dict(words=49536,pixels=87040,deviations=856,canonicalPrimaryWords=14496)
maximum={b:max((r['maximumObservedError'][b] for r in physical),key=lambda v:v['displayApproximation']) for b in ['owned','mesa']}
novel=[dict(index=i,name=c['name'],result=c['result']) for i,c in enumerate(guard['native']) if c['name'].startswith('joined-cube-0-1056964608-')]
assert len(novel)>0 and any(not c['result']['ok'] for c in novel)
checks=[]
for command in [['node','--check','renderer/virgl-shader/tests/power-regressions.mjs'],
 ['python3','-m','py_compile','renderer/virgl-shader/tests/power-capture-regressions.py','tools/virgl-power/receipt.py'],
 ['bash','-n','tools/verify-virgl-power.sh'],['git','diff','--check']]:
 p=subprocess.run(command,cwd=R,capture_output=True,text=True);assert p.returncode==0,(command,p.stderr)
 checks.append(dict(command=command,exit=p.returncode,stdout=p.stdout,stderr=p.stderr))
(O/'final-audits.json').write_text(json.dumps(dict(status='passed',runtimeHead=FROZEN,criticHead=CRITIC,
 changedMetadataAndHarness=sorted(changed),unchangedTrackedSources=bindings,restoredGeneratedSources=auth['generatedSources']['hot'],
 fourthReportSha256=sha((O/'gpu-2654435769/report.json').read_bytes()),fourthCoverage=report['browserCoverage'],
 allUniquePhysicalSeeds=totals,maximumObservedRelativeError=maximum,novelAttackCases=novel,checks=checks),indent=2)+'\n')
print('Final source bindings, restored generated artifacts, fourth capture,1914 exact native/Wasm responses and syntax checks held.')
