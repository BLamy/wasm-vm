#!/usr/bin/env python3
"""Execute the exact promoted receipt statements against authenticated captures."""
from pathlib import Path
import ast, hashlib, json, subprocess, copy
R=Path(__file__).resolve().parents[3];O=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
source_file=R/'tools/virgl-power/receipt.py';raw=source_file.read_bytes();tree=ast.parse(raw)
main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
guard_loop=next(n for n in main.body if isinstance(n,ast.For) and isinstance(n.target,ast.Tuple) and ast.unparse(n.target)=='(filename, count)')
gpu_loop=next(n for n in main.body if isinstance(n,ast.For) and ast.unparse(n.target)=='(seed, plan)')
fault_loop=next(n for n in main.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='fault')
def promoted_checks(loop):
 i=next(i for i,n in enumerate(loop.body) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='critic')
 return loop.body[i:i+3]
def run(nodes,values):exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source_file),'exec'),values)
def require(v,label):
 if not v:raise ValueError(label)
def source(name,digest):
 value=(R/name).read_bytes();require(sha(value)==digest,'source digest: '+name)
 require(value==subprocess.check_output(['git','show',f'HEAD:{name}'],cwd=R),'committed source')
artifacts={}
for name in ['joins','hex','signed','conversion','scalar','minimum','fraction','saturation','exponent','sine']:
 artifacts[f'independent-{name}-guards.json']=(O/'unpacked/hot'/f'independent-{name}-guards.json').read_bytes()
artifacts['independent-power-guards.json']=(O/'independent-regressions.json').read_bytes()
env=dict(json=json,artifact=lambda n:artifacts[n],require=require,source=source)
run([guard_loop],dict(env))
outcomes=[dict(check='exact promoted native/Wasm guard loop',outcome='passed',cases=17170)]
for checkout,folder in [('hot','hot'),('cold','cold/acceptance')]:
 records={}
 for seed in [608135816,2242054355,320440878]:
  name=f'gpu-{seed}/report.json';physical=json.loads((O/f'{checkout}-source-{seed}.json').read_bytes())
  # These source audit records were produced through inspect(), the very same
  # function main() calls. Wrap its unchanged result in main's documented envelope.
  digest=sha((O/'unpacked'/folder/name).read_bytes());records[name]=dict(sha256=digest)
  value=dict(schema='virgl-power-critic-capture-guards-v1',task='E6-T12g6j2',status=physical['status'],
   testSha256=physical['testSha256'],reportSha256=physical['physical']['sha256'],physical=physical['physical'])
  assert digest==value['reportSha256']
  artifacts[f'source-{seed}-guards.json']=json.dumps(value).encode()
  run(promoted_checks(gpu_loop),dict(env,seed=seed,records=records))
  outcomes.append(dict(check=checkout+'/'+name,outcome='passed',reportSha256=digest))
 for fault in ['base','exponent','broadcast']:
  name=f'fault-{fault}/report.json';digest=sha((O/'unpacked'/folder/name).read_bytes());records[name]=dict(sha256=digest)
  artifacts[f'source-fault-{fault}-guards.json']=(O/f'{checkout}-fault-{fault}-guards.json').read_bytes()
  run(promoted_checks(fault_loop),dict(env,fault=fault,records=records))
  outcomes.append(dict(check=checkout+'/'+name,outcome='failed-as-required',reportSha256=digest))
bad_checks=[]
def contradict(label,nodes,values,filename,mutate):
 original=artifacts[filename];value=json.loads(original);mutate(value);artifacts[filename]=json.dumps(value).encode()
 try:
  try:run(nodes,values)
  except ValueError as e:bad_checks.append(dict(check=label,outcome='rejected',message=str(e)))
  else:raise AssertionError('tampered promoted record accepted: '+label)
 finally:artifacts[filename]=original
name='source-608135816-guards.json';records={'gpu-608135816/report.json':dict(sha256=json.loads(artifacts[name])['reportSha256'])}
for field in ['reportSha256','testSha256']:
 contradict('capture '+field,promoted_checks(gpu_loop),dict(env,seed=608135816,records=records),name,lambda v,f=field:v.update({f:'0'*64}))
contradict('native/Wasm guard extent',[guard_loop],dict(env),'independent-power-guards.json',lambda v:v.update(cases=1913))
def corrupt(v):v['wasm'][0]['result']=dict(ok=True,glsl='forged')
contradict('native/Wasm guard response',[guard_loop],dict(env),'independent-power-guards.json',corrupt)
fresh=json.loads((O/'fourth-source-guards.json').read_bytes());artifacts['source-2654435769-guards.json']=(O/'fourth-source-guards.json').read_bytes()
run(promoted_checks(gpu_loop),dict(env,seed=2654435769,records={'gpu-2654435769/report.json':dict(sha256=fresh['reportSha256'])}))
outcomes.append(dict(check='promoted CLI output and fourth capture binding',outcome='passed'))
result=dict(status='passed',receiptSourceSha256=sha(raw),statementLines=dict(nativeWasm=[guard_loop.lineno,guard_loop.end_lineno],
 positive=[n.lineno for n in promoted_checks(gpu_loop)],fault=[n.lineno for n in promoted_checks(fault_loop)]),
 mode='Incremental execution of the exact changed receipt statements; sealed earlier gates are carried forward, not rerun.',checks=outcomes,tamperChecks=bad_checks)
(O/'wiring-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print('Promoted receipt statements accept bound captures/guards and reject4 tampered evidence records.')
