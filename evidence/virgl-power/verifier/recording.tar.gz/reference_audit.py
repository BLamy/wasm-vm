#!/usr/bin/env python3
"""Independently recompute sealed Decimal rows and literal original operands."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,importlib.util,json,re,struct
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;UNPACKED=OUT/'unpacked';sha=lambda b:hashlib.sha256(b).hexdigest()
p=ROOT/'renderer/virgl-shader/tests/power-capture-regressions.py';spec=importlib.util.spec_from_file_location('critic_power',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
reference=json.loads((UNPACKED/'generated/power-reference.json').read_bytes());rows=[]
for r in reference['rows']:
 truth=m.prediction(r['word'],r['exponentWord'])
 assert r['op']=='POW'
 if 'exact'in truth:assert r['exact']==truth['exact']==0
 else:
  a,b=m.unpair(truth['lower']),m.unpair(truth['upper'])
  assert m.unpair(r['lower'])<=m.unpair(r['higherLower'])<=a<=b<=m.unpair(r['higherUpper'])<=m.unpair(r['upper']),'independent1040-bit enclosure nests inside both160/220-digit worker intervals'
  assert m.unpair(r['budget'])==F(1,1<<14)and m.unpair(r['allowedLower'])==m.unpair(r['upper'])*(1-F(1,1<<14))and m.unpair(r['allowedUpper'])==m.unpair(r['lower'])*(1+F(1,1<<14))
 rows.append(dict(word=r['word'],exponentWord=r['exponentWord'],workerMethod=r.get('method',r.get('kind')),criticMethod=truth['method'],status='HELD'))
captures=[];unbounded=[];exponents=set()
inventory=json.loads((ROOT/'tools/virgl-power/capture-inputs.json').read_bytes());wanted={(c['path'],c['line']):c for c in inventory}
for path in sorted({c['path']for c in inventory}):
 source=(ROOT/path).read_bytes();lines=source.decode().splitlines();imms={}
 for line in lines:
  imm=re.fullmatch(r'IMM\[(\d+)\] (UINT32|FLT32) \{([^}]+)\}',line.strip())
  if imm:
   values=[s.strip()for s in imm[3].split(',')]
   imms[int(imm[1])]=(imm[2],values)
 for i,line in enumerate(lines,1):
  statement=re.sub(r'^\d+:\s*','',line.strip())
  if not statement.startswith('POW '):continue
  match=re.fullmatch(r'POW (.*), (.*), IMM\[(\d+)\]\.([xyzw]{4})',statement)
  if match:
   kind,values=imms[int(match[3])];literal=values[m.LANES.index(match[4][0])]
   if kind=='UINT32'or literal.lower().startswith('0x'):w=int(literal,0);q=m.number(w)
   else:q=F(literal);w=struct.unpack('<I',struct.pack('<f',float(q)))[0]
   # Validate nearest-even conversion independently against exact decimal
   # rational and neighboring binary32 values; no host pow/log is involved.
   distance=abs(m.number(w)-q)
   for neighbor in(w-1,w+1):
    other=abs(m.number(neighbor)-q);assert distance<other or distance==other and w%2==0
   c=wanted[(path,i)];assert c['statement']==statement and c['sha256']==sha(source)and c['exponentWord']==w
   captures.append(dict(path=path,line=i,statement=statement,exponentWord=w,sha256=sha(source)));exponents.add(w)
  else:unbounded.append(dict(path=path,line=i,statement=statement,reason='Original computed/uniform exponent has no proven static domain; full source is rejected and no isolated literal admission extends it.'))
assert len(captures)==72 and len(unbounded)==26 and len(exponents)==14
assert {(c['path'],c['line'])for c in captures}==set(wanted)
tgsi=ROOT/'renderer/virgl-shader/tests/mesa-24.2.8-tgsi.rst';s=tgsi.read_text();start=s.index('.. opcode:: POW');snippet=s[start:start+600];assert 'src0.x' in snippet and 'src1.x' in snippet
vendor=ROOT/'renderer/virgl-shader/vendor/src/vrend/vrend_shader.c';assert 'case TGSI_OPCODE_POW:\n      emit_buff(&ctx->glsl_strbufs, "%s = %s(pow(%s, %s));\\n", dsts[0], get_string(dinfo.dstconv), srcs[0], srcs[1]);'in vendor.read_text()
out=dict(status='passed',workerReferenceSha256=sha((UNPACKED/'generated/power-reference.json').read_bytes()),criticOracleSha256=sha(p.read_bytes()),precision=dict(workerDecimalDigits=[160,220],criticRationalGridBits=1040,proof='Outward atanh geometric remainder, positive exp Taylor geometric remainder, exact binary reduction and8 outward squarings.1040-bit intervals nest inside both worker precision intervals.'),rows=rows,captures=captures,gatedOriginalSites=unbounded,literalExponents=sorted(exponents),primarySources=[dict(path=str(tgsi.relative_to(ROOT)),sha256=sha(tgsi.read_bytes()),fact='Pinned POW equation consumes src0.x and src1.x and replicates.'),dict(path=str(vendor.relative_to(ROOT)),line=5902,sha256=sha(vendor.read_bytes()),fact='Original converter emits componentwise pow through destination float/vecN constructor; original GLSL retained and measured separately.')],webPrimarySources=[dict(url='https://registry.khronos.org/OpenGL/specs/es/3.0/GLSL_ES_Specification_3.00.pdf',revision='3.00 revision6,29January2016',pages=[58,68,93],fact='Section8.2 pow is componentwise; zero with nonpositive exponent and negative base are undefined. Section5.4 selects the first scalar/vector constructor components. The precision table expression apparently reverses the documented base/exponent roles, so this claim uses an explicit measured budget.'),dict(url='https://docs.python.org/3/library/decimal.html',anchors=['decimal.Decimal.ln','decimal.Decimal.exp'],fact='Official Decimal docs state correctly rounded nearest-even ln and exp; worker multiplication is directed outward. The critic uses a separate rational-series proof.')])
(OUT/'reference-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(len(rows),'independent nested equations;72 literal sites/14exact declared exponents;26computed/uniform sites remain gated.')
