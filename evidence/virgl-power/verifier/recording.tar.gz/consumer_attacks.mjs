import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash}from 'node:crypto';
import {parseConstantDomain,checkConversionBank}from '../../../renderer/virgl-command/constant-domain.mjs';
const file='evidence/virgl-power/verifier/unpacked/hot/native/report.json',j=JSON.parse(fs.readFileSync(file));
const report={status:'running',nativeReportSha256:createHash('sha256').update(fs.readFileSync(file)).digest('hex'),attacks:[],ownership:[],getterCalls:0};
let serial=0;
function attack(c,name,mutate){const copy=structuredClone(c.result.metadata);mutate(copy);const result=parseConstantDomain(copy,c.stage);assert.equal(result.ok,false,name);assert.equal(result.error.code,'shader-domain-error');report.attacks.push({name:c.name+'/'+name,result});}
const groups=new Map();for(const c of j.cases)if(c.ok)groups.set(JSON.stringify(c.result.metadata),c);
for(const c of groups.values()){
 attack(c,'unexpected power on lower profile',m=>{m.profile=m.powerBaseProfile;});
 attack(c,'cross-stage',m=>{m.powerContract.stage=c.stage==='vertex'?'fragment':'vertex';});
 attack(c,'binary policy confused with two operations',m=>{m.powerContract.operations=['POW','POW'];});
 attack(c,'unknown own policy key',m=>{m.powerContract.fabricatedRange=[0,1];});
 attack(c,'symbol policy key',m=>m.powerContract[Symbol('hidden')]=true);
 attack(c,'symbol operation key',m=>m.powerContract.operations[Symbol('hidden')]='POW');
 attack(c,'accessor operations index',m=>Object.defineProperty(m.powerContract.operations,0,{get(){report.getterCalls++;throw new Error('operation getter invoked');},enumerable:true}));
 attack(c,'accessor policy parent',m=>Object.defineProperty(m,'powerContract',{get(){report.getterCalls++;throw new Error('policy getter invoked');},enumerable:true}));
 attack(c,'no own operation',m=>{const a=[];a.length=1;Object.setPrototypeOf(a,{0:'POW'});m.powerContract.operations=a;});
 attack(c,'array metadata',m=>{m.powerContract=[];});
 attack(c,'boolean base',m=>{m.powerBaseProfile=true;});
 attack(c,'profile38 base',m=>{m.powerBaseProfile='virgl-webgl2-raw-bits-v38';});
 attack(c,'recursive operation policy',m=>{m.powerContract.operations=[m.powerContract];});
 attack(c,'extra base alias',m=>{m.powerBaseProfile='virgl-webgl2-raw-bits-v37';});
 attack(c,'claimed portable power precision',m=>{m.powerContract.precision='portable-relative-guarantee';});
 attack(c,'claimed result bound',m=>{m.powerContract.result='exact-power-result';});
 attack(c,'revoked policy proxy',m=>{const p=Proxy.revocable({},{});p.revoke();m.powerContract=p.proxy;});
 attack(c,'throwing descriptor policy',m=>{m.powerContract=new Proxy(m.powerContract,{ownKeys(){throw new Error('descriptor failure');}});});
 const copy=structuredClone(c.result.metadata),contract=parseConstantDomain(copy,c.stage);assert.equal(contract.ok,true);const before=JSON.stringify(contract);assert.ok(Object.isFrozen(contract.power)&&Object.isFrozen(contract.power.operations));
 copy.powerContract.operations[0]='POW_PRECISE';copy.powerContract.domain='unbounded';for(const key of ['constantDomains','constantAccesses','constantConversionDomains','constantRasterDomains'])if(copy[key]){copy[key][0].count=1;copy[key].push({stage:'poison'});}
 assert.equal(JSON.stringify(contract),before,'full parser-owned wrapper independence');report.ownership.push({name:c.name,snapshotSha256:createHash('sha256').update(before).digest('hex')});
 const base=structuredClone(c.result.metadata);base.profile=base.powerBaseProfile;delete base.powerBaseProfile;delete base.powerContract;const plain=parseConstantDomain(base,c.stage);assert.equal(plain.ok,true,'underlying complete base is independently accepted');
 if(contract.conversionDomain){
  const words=Array(Math.min(contract.conversionDomain.count,46)*4).fill(0);if(contract.radialDomain)words[16]=0x3f800000;
  const approved=checkConversionBank(words,contract.conversionDomain,contract);assert.equal(approved.ok,true);const owned=approved.words.slice();words.fill(0xdeadbeef);assert.deepEqual(approved.words,owned);assert.ok(Object.isFrozen(approved.words));
  for(const entry of contract.conversionDomain.components)for(let lane=0;lane<4;lane++)if(entry.mask&(1<<lane))for(const bad of [0x7f800000,0xff800000,0x7fc0aaaa,0x4f000000]){const poisoned=owned.slice();poisoned[entry.register*4+lane]=bad;assert.equal(checkConversionBank(poisoned,contract.conversionDomain,contract).ok,false);report.attacks.push({name:c.name+'/consumed conversion bank poison',word:bad,register:entry.register,lane});}
 }
}
assert.equal(report.getterCalls,0);report.status='passed';fs.writeFileSync('evidence/virgl-power/verifier/consumer-boundary-attacks.json',JSON.stringify(report,null,2)+'\n');console.log(report.attacks.length+' independent metadata/ownership/consumed-bank attacks; no getter invocations.');
