#!/usr/bin/env python3
"""Carry only unchanged authenticated HELD evidence and whole prior responses."""
from pathlib import Path
import json,hashlib,tarfile,subprocess
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;UNPACKED=OUT/'unpacked';sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
BASE='ff4692e52a3ea52ee75368358b46fed1bd3fce9b';HEAD='6fcadd1eaa08f72b3fd7d301ce1df88fca452b1d'
def seal(base):
 p=ROOT/base;m=json.loads((p/'manifest.json').read_bytes());index=(p/'records.json').read_bytes();a=p/m['archive']['path'];assert sha(index)==m['recordIndex']['sha256']and sha(a.read_bytes())==m['archive']['sha256'];return m,{r['path']:r for r in json.loads(index)['records']},a
def extract(binding):
 m,index,a=seal(str(Path(binding['sealPath']).parent));e=binding['member'];assert e==index[e['path']]
 with tarfile.open(a)as t:b=t.extractfile(e['path']).read()
 assert len(b)==e['bytes']and sha(b)==e['sha256'];return b
for name in('saturation','exponent','sine'):
 p=UNPACKED/'hot'/('held-'+name);r=json.loads((p/'report.json').read_bytes());assert r['status']=='passed'and r['faultExit']!=0
 for key,file in [('capture','capture.json'),('fault','fault.json')]:assert extract(r[key])==(p/file).read_bytes()
 guard='renderer/virgl-shader/tests/'+('exponent-logarithm'if name=='exponent'else name)+'-capture-regressions.py'
 assert not subprocess.check_output(['git','diff',BASE+'..'+HEAD,'--',guard],cwd=ROOT),'unchanged promoted oracle'
 rows.append(dict(boundary=name,status='HELD',guard=guard,guardSha256=sha((ROOT/guard).read_bytes()),capture=r['capture'],fault=r['fault'],guardOutputSha256=sha((p/'guards.json').read_bytes()),faultOutputSha256=sha((p/'fault-guards.json').read_bytes()),physicalWords=r['physicalWords'],reason='Independent prior source oracle, verified capture/fault bytes and dependency boundary are unchanged and bound by their original seals. Adjacent power admission retains whole inherited responses below.'))
legacy=json.loads((UNPACKED/'hot/legacy.json').read_bytes());assert len(legacy['cases'])==6867 and legacy['status']=='passed'
for c in legacy['cases']:
 assert c['old']==c['parent']and c['old']['ok']==c['ok']==c['added']['ok']
 if c['ok']:
  m=dict(c['added']['metadata']);m['profile']=m.pop('powerBaseProfile');m.pop('powerContract');b=dict(c['parent']['metadata'])
  if c['baseTransition']:b['profile']='virgl-webgl2-raw-bits-v1'
  assert m==b,'whole inherited obligations'
 else:assert not any(k in c['added']for k in('glsl','metadata'))
extensions=[]
for binding in legacy['extensionFixtures']:
 b=extract(binding);original=json.loads(b)
 for c in original['cases']:
  if not c['name'].endswith('-unsupported-POW'):continue
  x=next(x for x in legacy['extensions']if x['name']==c['name']);assert x['text']==c['text']and x['parent']==c['result']and x['parent']['ok']is False and x['current']['ok']is True and x['transition']=='declared-new-bounded-POW-admission';extensions.append(x)
assert len(extensions)==3
held=json.loads(extract(legacy['heldExtensionFixture']));assert len(legacy['heldExtensions'])==len(held['extensions'])==2
for c,x in zip(held['extensions'],legacy['heldExtensions']):assert x['text']==c['text']and x['parent']==x['current']==c['current']
guards=[]
for name,count in [('joins',402),('hex',49),('signed',108),('conversion',1575),('scalar',1427),('minimum',4524),('fraction',4469),('saturation',1160),('exponent',1022),('sine',520)]:
 p=UNPACKED/'hot'/('independent-'+name+'-guards.json');r=json.loads(p.read_bytes());assert r['status']=='passed'and r['cases']==len(r['native'])==len(r['wasm'])==count
 guards.append(dict(name=name,cases=count,reportSha256=sha(p.read_bytes()),status='HELD',qualification='Current unsupported-POW spelling guards use binary-arity POW_PRECISE; original plain-POW rejection seals and exactly3 new bounded admissions are retained above.'if name in('exponent','sine')else'Unchanged promoted guard source and deterministic results.'))
assert sum(r['cases']for r in guards)==15256
retained=json.loads((UNPACKED/'hot/retained/report.json').read_bytes());assert sum(x['native']['ok']for x in retained['originals'])==23 and sum(x['native']['ok']for x in retained['historical'])==5
sm,si,sa=seal('evidence/virgl-sine/worker');sb=dict(sealPath='evidence/virgl-sine/worker/manifest.json',member=si['hot/retained/report.json']);previous=json.loads(extract(sb))
for c,b in zip(retained['originals'],previous['originals']):assert c['path']==b['path']and c['sha256']==b['sha256']and c['native']==c['wasm']==b['native']==b['wasm']
for c,b in zip(retained['historical'],previous['historical']):assert c['native']==b['native']
out=dict(status='passed',held=rows,promotedGuards=guards,wholePredecessorResponses=6867,predecessorRecordSha256=sha((UNPACKED/'hot/legacy.json').read_bytes()),declaredExtensions=extensions,heldSINExtensions=legacy['heldExtensions'],originalBodies=dict(originals=len(retained['originals']),historical=len(retained['historical']),predecessorBinding=sb,rejected=[dict(path=c['path'],sha256=c['sha256'],result=c['native'])for c in retained['originals']if not c['native']['ok']],recordSha256=sha((UNPACKED/'hot/retained/report.json').read_bytes())),coldIncremental=dict(reportSha256=sha((UNPACKED/'cold/report.json').read_bytes()),sourceHead=HEAD,reason='Exactly one final pristine clone passed at the frozen runtime head. Subsequent critic changes are tests and verification wiring only; runtime and dependency sources remain byte-identical. No additional cold clone is required.'))
(OUT/'carry-forward.json').write_text(json.dumps(out,indent=2)+'\n');print('HELD SAT/EX/SIN seals and faults;15256 promoted guards;6867 complete responses;3 new POW and2 inherited SIN admissions; original larger bodies gated.')
