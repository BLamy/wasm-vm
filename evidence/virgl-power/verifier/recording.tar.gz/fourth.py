#!/usr/bin/env python3
"""Fresh physical seed with source-derived rational expectations before capture."""
from pathlib import Path
import json,subprocess,struct,os,hashlib,importlib.util
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;UNPACKED=OUT/'unpacked';SEED=2654435769
sha=lambda b:hashlib.sha256(b).hexdigest()
oracle=ROOT/'renderer/virgl-shader/tests/power-capture-regressions.py';spec=importlib.util.spec_from_file_location('critic_power',oracle);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base=json.loads((UNPACKED/'generated/power-primary.json').read_bytes());have={r['text']for r in base}
source="""import {vectors,carrier,bytesFragment}from './tools/virgl-power/cases.mjs';let cases=[];for(const v of vectors('POW',2654435769))for(const variant of ['direct','swizzle-xxxx-xxxx']){cases.push({name:v.name+'-'+variant,stage:'vertex',text:carrier('POW',v,variant)});for(let i=0;i<4;i++)cases.push({name:v.name+'-'+variant+'-'+i,stage:'fragment',text:bytesFragment('POW',v,i,variant)});}console.log(JSON.stringify(cases));"""
cases=[r for r in json.loads(subprocess.check_output(['node','--input-type=module','-e',source],cwd=ROOT))if r['text']not in have]
assert len(cases)==80
fixture=b'VPW1'+struct.pack('<I',len(cases))+b''.join(struct.pack('<4I',int(c['stage']=='fragment'),1,1,len(c['text'].encode()))+c['text'].encode()for c in cases)
(OUT/'fourth-native-predictions.json').write_text(json.dumps(cases,indent=2)+'\n');(OUT/'fourth-cases.bin').write_bytes(fixture)
binary=UNPACKED/'generated/power-sanitize/power-test';env=dict(os.environ,LLVM_PROFILE_FILE=str(OUT/'fourth-native.profraw'),ASAN_OPTIONS='abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
run=subprocess.run([str(binary)],input=fixture,capture_output=True,env=env,cwd=ROOT);(OUT/'fourth-native.log').write_bytes(run.stdout);(OUT/'fourth-native.stderr').write_bytes(run.stderr);assert run.returncode==0 and not run.stderr
for line in run.stdout.decode().splitlines():
 if line.startswith('PRIMARY '):
  _,i,body=line.split(' ',2);c=cases[int(i)];base.append(dict(name=c['name'],stage=c['stage'],text=c['text'],primary=json.loads(body)))
 assert not line.startswith('CASE ')or json.loads(line.split(' ',2)[2])['ok']is True
assert len(base)==1186
primary=ROOT/'renderer/virgl-shader/build/power-primary.json';reference=ROOT/'renderer/virgl-shader/build/power-reference.json';saved={p:p.read_bytes()for p in(primary,reference)}
try:
 primary_raw=(json.dumps(base,indent=2)+'\n').encode();primary.write_bytes(primary_raw);(OUT/'fourth-primary.json').write_bytes(primary_raw)
 plan=json.loads(subprocess.check_output(['node','--input-type=module','-e',"import fs from 'node:fs';import {physicalPlan}from './tools/virgl-power/plan.mjs';process.stdout.write(JSON.stringify(physicalPlan(2654435769,JSON.parse(fs.readFileSync('renderer/virgl-shader/build/power-primary.json')))));"],cwd=ROOT));(OUT/'fourth-plan.json').write_text(json.dumps(plan,indent=2)+'\n');keys=set()
 # Independently derive operands/versions from original TGSI; selected lists
 # and observations cannot create expectations or select an easier equation.
 for v in plan['vertices']:
  for x in v['vectors']:
   bank=[0]*184;bank[:4]=v['input']['a'];bank[180:184]=v['input']['e'];bank[172]=x['condition']
   truth,_=m.execute(v['text'],bank,v['backend']);keys.update((r['word'],r['exponentWord'])for r in truth if 'op'in r)
 for f in plan['fragments']:
  bank=[0]*184;bank[:4]=f['input']['a'];bank[180:184]=f['input']['e'];truth,_=m.execute(f['text'],bank,f['backend']);r=truth[f['lane']]
  if 'op'in r:keys.add((r['word'],r['exponentWord']))
 ref=dict(schema='virgl-power-critic-reference-v1',primaryFileSha256=sha(primary_raw),referenceSourceSha256=sha(oracle.read_bytes()),referenceMethod='independent rational atanh log and range-reduced exp,1040-bit outward dyadic arithmetic',rows=[m.prediction(w,e)for w,e in sorted(keys)])
 refraw=(json.dumps(ref,indent=2)+'\n').encode();reference.write_bytes(refraw);(OUT/'fourth-reference.json').write_bytes(refraw)
 command=['node','tools/virgl-power/browser.mjs','--output',str(OUT/f'gpu-{SEED}'),'--seed',str(SEED)]
 command_record=dict(command=command,seed=SEED,nativeCases=len(cases),nativeBinarySha256=sha(binary.read_bytes()),fixtureSha256=sha(fixture),primarySha256=sha(primary_raw),referenceSha256=sha(refraw),oracleSourceSha256=sha(oracle.read_bytes()),gitHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip())
 (OUT/'fourth-command.json').write_text(json.dumps(command_record,indent=2)+'\n')
 with (OUT/'fourth-seed.log').open('wb')as log:subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
 output=OUT/f'gpu-{SEED}/report.json';report=json.loads(output.read_bytes());assert report['acceptance']['primaryFile']['sha256']==sha(primary_raw)and report['acceptance']['referenceFile']['sha256']==sha(refraw)and not report['trackedChanges']
 result=m.inspect(output);(OUT/'fourth-source-semantics.json').write_text(json.dumps(dict(status='passed',testSha256=sha(oracle.read_bytes()),physical=result),indent=2)+'\n')
 print(json.dumps(dict(status='passed',seed=SEED,nativeCases=len(cases),checkedWords=result['words'],checkedPixels=result['pixels'],maximumObservedError=result['maximumObservedError'])))
finally:
 for p,b in saved.items():p.write_bytes(b)
