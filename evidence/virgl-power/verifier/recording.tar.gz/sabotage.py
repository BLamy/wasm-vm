#!/usr/bin/env python3
"""Fault scratch copies only; require independent promoted guards to refute them."""
from pathlib import Path
import subprocess,json,hashlib,shutil
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();source=ROOT/'renderer/virgl-shader/raw_bits.c';original=source.read_text();files=subprocess.check_output(['git','ls-files','renderer/virgl-shader'],cwd=ROOT,text=True).splitlines()
def once(s,needle,replacement):assert s.count(needle)==1,needle;return s.replace(needle,replacement,1)
faults={
 'zero-capable-domain':once(original,'   if (!(base.one & magnitude) && !positive_exponent) return false;','   /* sabotage: allow zero-capable base with nonpositive exponent */'),
 'exponent-snapshot':once(original,'      float_operand(w, p, instruction, 1, 0);','      float_operand(w, p, instruction, 0, 0);'),
 'zero-bypass':once(original,'if (power_base != 0.0) float_rhs = vec4(/* power:POW */','float_rhs = vec4(/* power:POW */'),
 'result-facts':once(original,'      case RAW_POW:\n      case RAW_TEX:','      case RAW_POW:\n         result[lane] = known_word(0);\n         result[lane].origin = RAW_FLOAT_SHADOW | RAW_OUTPUT | dependency;\n         break;\n      case RAW_TEX:')}
rows=[]
for fault,changed in faults.items():
 scratch=OUT/'sabotage'/fault;scratch.mkdir(parents=True,exist_ok=True)
 for name in files:
  p=scratch/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,p)
 (scratch/'renderer/virgl-shader/raw_bits.c').write_text(changed)
 with (OUT/('sabotage-'+fault+'-build.log')).open('wb')as log:subprocess.run(['bash','renderer/virgl-shader/build.sh','native'],cwd=scratch,stdout=log,stderr=subprocess.STDOUT,check=True)
 binary=scratch/'renderer/virgl-shader/build/native/virgl-shader';output=OUT/('sabotage-'+fault+'-guards.json');command=['node','renderer/virgl-shader/tests/power-regressions.mjs','--native',str(binary),'--native-only','--output',str(output)]
 with (OUT/('sabotage-'+fault+'-guards.log')).open('wb')as log:run=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
 report=json.loads(output.read_bytes());assert run.returncode!=0 and report['status']=='failed','source fault must contradict independent guards'
 rows.append(dict(fault=fault,sourceSha256=sha(source.read_bytes()),mutatedSourceSha256=sha(changed.encode()),binarySha256=sha(binary.read_bytes()),guardSha256=sha((ROOT/'renderer/virgl-shader/tests/power-regressions.mjs').read_bytes()),exit=run.returncode,reportSha256=sha(output.read_bytes()),counterexample=report['failure']['counterexample'],failure=report['failure']['message']))
 assert source.read_text()==original,'production implementation remains unchanged'
testroot=OUT/'sabotage-test-source';testdir=testroot/'renderer/virgl-shader/tests';testdir.mkdir(parents=True,exist_ok=True);guard=ROOT/'renderer/virgl-shader/tests/power-regressions.mjs';bad=once(guard.read_text(),'if(as.some(w=>(w&0x7fffffff)===0)&&!es.every(w=>value(w)>0))return false;','if(false)return false;');(testdir/guard.name).write_text(bad);shutil.copyfile(guard.parent/'raster-bank-cases.json',testdir/'raster-bank-cases.json')
output=OUT/'sabotage-test-guards.json';command=['node',str(testdir/guard.name),'--native',str(ROOT/'renderer/virgl-shader/build/native/virgl-shader'),'--native-only','--root',str(ROOT),'--output',str(output)]
with (OUT/'sabotage-test-guards.log').open('wb')as log:run=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
report=json.loads(output.read_bytes());assert run.returncode!=0 and report['status']=='failed'
rows.append(dict(fault='test-source-invalid-zero-prediction',mutatedTestSha256=sha(bad.encode()),exit=run.returncode,reportSha256=sha(output.read_bytes()),counterexample=report['failure']['counterexample']))
oracle=ROOT/'renderer/virgl-shader/tests/power-capture-regressions.py';bad=once(oracle.read_text(),' x,y=number(w),number(e)',' x,y=number(w),number(e)\n return F(1),F(1),"sabotaged-self-golden"');(testdir/oracle.name).write_text(bad);output=OUT/'sabotage-test-capture.json'
command=['python3',str(testdir/oracle.name),'--report',str(OUT/'unpacked/hot/gpu-608135816/report.json'),'--output',str(output)]
with (OUT/'sabotage-test-capture.log').open('wb')as log:run=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
report=json.loads(output.read_bytes());assert run.returncode!=0 and report['status']=='failed'and 'prediction'in report['failure']['message']
rows.append(dict(fault='test-source-false-unit-oracle',mutatedTestSha256=sha(bad.encode()),exit=run.returncode,reportSha256=sha(output.read_bytes()),failure=report['failure']))
(OUT/'sabotage-regressions.json').write_text(json.dumps(dict(status='passed',records=rows),indent=2)+'\n');print('All4 runtime source faults and2 test-source faults are caught; production sources untouched.')
