#!/usr/bin/env python3
"""Record independent guard inputs with the unchanged worker binary."""
import hashlib,json,os,struct,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=subprocess.check_output(['node','--input-type=module','-e',"import {getPowerRegressions} from './renderer/virgl-shader/tests/power-regressions.mjs';console.log(JSON.stringify(getPowerRegressions()));"],cwd=ROOT)
cases=json.loads(raw);(OUT/'critic-native-predictions.json').write_bytes(raw)
fixture=b'VPW1'+struct.pack('<I',len(cases))
for c in cases:
 text=c['text'].encode();fixture+=struct.pack('<4I',int(c['stage']=='fragment'),int(c['ok']),0,len(text))+text
(OUT/'critic-native-cases.bin').write_bytes(fixture)
binary=OUT/'unpacked/generated/power-sanitize/power-test';profile=OUT/'critic-native.profraw'
env=dict(os.environ,LLVM_PROFILE_FILE=str(profile),ASAN_OPTIONS='abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
run=subprocess.run([str(binary)],input=fixture,capture_output=True,env=env,cwd=ROOT)
(OUT/'critic-native.log').write_bytes(run.stdout);(OUT/'critic-native.stderr').write_bytes(run.stderr)
assert run.returncode==0 and not run.stderr
subprocess.run(['xcrun','llvm-profdata','merge','-sparse',str(profile),'-o',str(OUT/'critic-native.profdata')],check=True)
coverage=json.loads(subprocess.check_output(['xcrun','llvm-cov','export',str(binary),'-instr-profile='+str(OUT/'critic-native.profdata')]))
for d in coverage['data']:
 d['files']=[f for f in d['files']if any(f['filename'].endswith('/'+s)for s in ['bridge.c','raw_bits.c','native_tests/power.c'])]
 d['functions']=[f for f in d['functions']if any(any(p.endswith('/'+s)for s in ['bridge.c','raw_bits.c','native_tests/power.c'])for p in f['filenames'])]
(OUT/'critic-native-coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
report=dict(status='passed',cases=len(cases),binarySha256=sha(binary.read_bytes()),sourceUnchanged=True,fixtureSha256=sha(fixture),predictionsSha256=sha(raw),logSha256=sha(run.stdout),stderrSha256=sha(run.stderr),profileSha256=sha(profile.read_bytes()),coverageSha256=sha((OUT/'critic-native-coverage.json').read_bytes()))
(OUT/'critic-native-recording.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
