#!/usr/bin/env python3
"""Fresh critic: byte-authenticate worker recording before semantic inspection."""
import hashlib, json, os, subprocess, tarfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
WORKER=OUT.parent/'worker'
HEAD='6fcadd1eaa08f72b3fd7d301ce1df88fca452b1d'
BASE='ff4692e52a3ea52ee75368358b46fed1bd3fce9b'
EXPECTED={
 'recording.tar.gz':'5630a4ff3fcc271a812096b602d04c73b31bb3691fc6f39e1b6b9a653f02f3a2',
 'records.json':'3043e4458999f7a0f6024348ea2e2e18251c505c1bdfbfb6da43bcedb30e3363',
 'hot/receipt.json':'e02ad44fc5473da72b8f99308c3dd7f5cfe30d5806039a715272f92cb2c42f0f',
 'cold/report.json':'99ab9a9128b1f7b37809d6ba06e1fbc35e634fabb6640be1decb38312521f9e7',
 'cold/acceptance/receipt.json':'9b48f5d7434576de3fe10bce24990ace3e94a41a4b661939a2317785fdb95251'}
def sha(b):return hashlib.sha256(b).hexdigest()
def git_bytes(commit,path):
 p=subprocess.run(['git','show',commit+':'+path],cwd=ROOT,capture_output=True)
 return p.stdout if p.returncode==0 else None
def main():
 for n in ('recording.tar.gz','records.json'):assert sha((WORKER/n).read_bytes())==EXPECTED[n],n
 manifest=json.loads((WORKER/'manifest.json').read_bytes())
 index=json.loads((WORKER/'records.json').read_bytes())
 assert manifest['sourceHead']==index['sourceHead']==HEAD and manifest['base']==BASE
 assert manifest['records']==len(index['records'])==147
 assert manifest['archive']['sha256']==EXPECTED['recording.tar.gz'] and manifest['recordIndex']['sha256']==EXPECTED['records.json']
 assert manifest['archive']['bytes']==(WORKER/'recording.tar.gz').stat().st_size
 assert manifest['recordIndex']['bytes']==(WORKER/'records.json').stat().st_size
 indexed={r['path']:r for r in index['records']};assert len(indexed)==147
 unpacked=OUT/'unpacked';unpacked.mkdir(exist_ok=True)
 with tarfile.open(WORKER/'recording.tar.gz','r:gz') as t:
  assert len(t.getmembers())==147 and {m.name for m in t.getmembers()}==set(indexed)
  for m in t.getmembers():
   assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
   b=t.extractfile(m).read();e=indexed[m.name]
   assert len(b)==e['bytes'] and sha(b)==e['sha256'],m.name
   p=unpacked/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 for n,h in EXPECTED.items():
  if n.startswith(('hot/','cold/')):assert sha((unpacked/n).read_bytes())==h,n
 hot=json.loads((unpacked/'hot/receipt.json').read_bytes());cold=json.loads((unpacked/'cold/report.json').read_bytes());second=json.loads((unpacked/'cold/acceptance/receipt.json').read_bytes())
 assert all(r['gitHead']==HEAD and r['status']=='passed' for r in (hot,cold,second))
 assert cold['cloneHead']==HEAD and not cold['statusBefore'] and not cold['statusAfter']
 assert sha((unpacked/'cold/cold.log').read_bytes())==cold['logSha256']
 assert cold['receiptSha256']==EXPECTED['cold/acceptance/receipt.json']
 bindings={};generated={};extras={}
 for label,receipt,prefix in [('hot',hot,'hot'),('cold',second,'cold/acceptance')]:
  for r in receipt['records']:
   b=(unpacked/prefix/r['path']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256'],(label,r['path'])
  bindings[label]={};generated[label]={};extras[label]={}
  for r in receipt['sources']:
   p=r['path'];b=git_bytes(HEAD,p)
   if b is not None:
    assert len(b)==r['bytes'] and sha(b)==r['sha256'],(label,p)
    bindings[label][p]=r['sha256']
   elif p.startswith('renderer/virgl-shader/build/'):
    u=('generated/' if label=='hot' else 'cold-generated/')+p.removeprefix('renderer/virgl-shader/build/')
    b=(unpacked/u).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256'],(label,u)
    generated[label][p]=r['sha256']
   else:extras[label][p]=r
 assert bindings['hot']==bindings['cold']
 assert not extras['hot'] and not extras['cold']
 for label in ('hot','cold'):
  p=unpacked/('generated' if label=='hot' else 'cold-generated')/'power-sanitize/power-test'
  os.chmod(p,0o755)
 report=dict(schema='virgl-power-critic-authentication-v1',status='passed',sourceHead=HEAD,base=BASE,
  archiveSha256=EXPECTED['recording.tar.gz'],indexSha256=EXPECTED['records.json'],members=147,
  receipts={k:v for k,v in EXPECTED.items()if k.startswith(('hot/','cold/'))},
  trackedSources=bindings,generatedSources=generated,cold=dict(clone=cold['clone'],statusBefore=cold['statusBefore'],statusAfter=cold['statusAfter']),
  generatedOnlyHot=sorted(set(generated['hot'])-set(generated['cold'])))
 (OUT/'authentication.json').write_text(json.dumps(report,indent=2)+'\n')
 (OUT/'task-diff.patch').write_bytes(subprocess.check_output(['git','diff',BASE+'..'+HEAD],cwd=ROOT))
 print(json.dumps(dict(status='passed',members=147,trackedSources=len(bindings['hot']),hotGenerated=len(generated['hot']),coldGenerated=len(generated['cold']))))
if __name__=='__main__':main()
