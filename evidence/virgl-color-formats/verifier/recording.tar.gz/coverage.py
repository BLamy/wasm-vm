import hashlib, json, pathlib, re, subprocess

root = pathlib.Path(__file__).resolve().parents[3]
out = pathlib.Path(__file__).resolve().parent
head = 'f0770a386271513fac56df8da26057e256a6ae8b'
base = '0550aa94b59364380e543b0c6de41697c5f18fb8'
runtime = ['renderer/virgl-command/' + p for p in ['resources.mjs', 'decoder.mjs', 'state.mjs']]
data = {}
for f in sorted((out / 'recording/acceptance').glob('**/browser-coverage.json')):
    if 'sabotage-' in str(f): continue
    raw = f.read_bytes()
    payload = json.loads(raw)
    for s in payload.get('scripts', [payload] if 'source' in payload else []):
        source = subprocess.check_output(['git', 'show', head + ':' + s['source']], cwd=root)
        assert hashlib.sha256(source).hexdigest() == s['sha256']
        ranges = [r for fn in s['coverage']['functions'] for r in fn['ranges']]
        data.setdefault(s['source'], []).append((str(f.relative_to(out)), hashlib.sha256(raw).hexdigest(), ranges))

diff = subprocess.check_output(['git', 'diff', '--unified=0', base + '..' + head, '--', *runtime], cwd=root, text=True)
added = {}; source = None; number = 0
for line in diff.splitlines():
    if line.startswith('+++ b/'):
        source = line[6:]
    elif line.startswith('@@ '):
        number = int(re.search(r'\+(\d+)', line).group(1))
    elif line.startswith('+') and not line.startswith('+++'):
        added.setdefault(source, []).append((number, line[1:])); number += 1
    elif not line.startswith('-') and not line.startswith('\\'):
        number += 1

rows = []
for source, lines in added.items():
    content = subprocess.check_output(['git', 'show', head + ':' + source], cwd=root, text=True)
    split = content.splitlines(keepends=True)
    offsets = [0]
    for line in split: offsets.append(offsets[-1] + len(line))
    for number, text in lines:
        first = len(text) - len(text.lstrip())
        executable = bool(text.strip()) and not text.lstrip().startswith('//') and bool(re.search(r'[\w!]', text))
        points = [offsets[number - 1] + i for i, c in enumerate(text) if not c.isspace()]
        hits = []
        for file, sha, ranges in data[source]:
            wins = []
            for p in points:
                enclosing = [r for r in ranges if r['startOffset'] <= p < r['endOffset']]
                if enclosing:
                    narrowest = min(enclosing, key=lambda r: (r['endOffset'] - r['startOffset']))
                    wins.append(narrowest)
            if any(r['count'] > 0 for r in wins):
                positive = min((r for r in wins if r['count'] > 0), key=lambda r: r['endOffset'] - r['startOffset'])
                hits.append({'recording': file, 'sha256': sha, 'range': positive,
                             'coveredCharacterOffsets': len([r for r in wins if r['count'] > 0]), 'totalOffsets': len(points)})
        classification = 'waived' if not executable else 'executed' if hits else 'needs-evidence'
        rows.append({'source': source, 'line': number, 'code': text, 'executable': executable,
                     'classification': classification, 'hits': hits,
                     **({'waiver': 'Comment or syntax-only line has no standalone behavior.'} if classification == 'waived' else {})})
summary = {'base': base, 'sourceHead': head, 'method': 'Independent diff-added line positions; narrowest enclosing V8 ranges from authenticated happy hardware/regressions; excludes faults, cold duplicate and worker audit.',
           'changedRuntimeLines': len(rows), 'v8HitLines': sum(bool(r['hits']) for r in rows),
           'executed': sum(r['classification'] == 'executed' for r in rows),
           'waived': sum(r['classification'] == 'waived' for r in rows),
           'needsEvidence': sum(r['classification'] == 'needs-evidence' for r in rows), 'rows': rows}
(out / 'coverage.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k: v for k, v in summary.items() if k != 'rows'}, indent=2))
for r in rows:
    print(f"{r['classification']:14} {r['source']}:{r['line']} {r['code'].strip()}")
assert summary['needsEvidence'] == 0
