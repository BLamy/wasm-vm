import hashlib, json, pathlib, subprocess, tarfile

root = pathlib.Path(__file__).resolve().parents[3]
out = pathlib.Path(__file__).resolve().parent
seal = root / 'evidence/virgl-color-formats/worker'
head = 'f0770a386271513fac56df8da26057e256a6ae8b'
digest = lambda b: hashlib.sha256(b).hexdigest()
manifest = json.loads((seal / 'manifest.json').read_bytes())
assert manifest['task'] == 'E6-T12g2' and manifest['sourceHead'] == head
assert manifest['archive']['sha256'] == 'ef5cd601c77585b597b85fda5f77e227694d6ddb1a3041dd50ae398b6920b273'
index_raw = (seal / 'records.json').read_bytes()
assert len(index_raw) == manifest['recordIndex']['bytes'] and digest(index_raw) == manifest['recordIndex']['sha256']
index = json.loads(index_raw)
raw = (seal / manifest['archive']['path']).read_bytes()
assert len(raw) == manifest['archive']['bytes'] and digest(raw) == manifest['archive']['sha256']
bound = {r['path']: r for r in index}
assert len(bound) == len(index) == manifest['records'] == 60
dest = out / 'recording'
dest.mkdir(exist_ok=True)
with tarfile.open(seal / manifest['archive']['path']) as tar:
    members = tar.getmembers()
    assert len(members) == 60 and len({m.name for m in members}) == 60
    for m in members:
        p = pathlib.PurePosixPath(m.name)
        assert m.isfile() and not p.is_absolute() and '..' not in p.parts and str(p) == m.name
        rec = bound[m.name]
        b = tar.extractfile(m).read()
        assert len(b) == rec['bytes'] and digest(b) == rec['sha256'], m.name
        target = dest / m.name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(b)
assert set(bound) == {m.name for m in members}
code_diff = subprocess.check_output(['git', 'diff', '0550aa94b59364380e543b0c6de41697c5f18fb8..' + head, '--', '.', ':(exclude)tasks'], cwd=root)
assert (dest / 'diff.patch').read_bytes() == code_diff
reports = sorted(p for p in dest.glob('**/report.json') if not str(p.relative_to(dest)).startswith('initial-fixture-failure/'))
historical = json.loads((dest / 'initial-fixture-failure/regression/async/report.json').read_bytes())
assert historical['status'] == 'failed' and historical['gitHead'] == 'a5fde8580cee4aab0648960781d78e0f80aa82b9'
source_bindings, input_bindings, checked, generated = {}, {}, {}, {}
for file in reports:
    r = json.loads(file.read_bytes())
    assert r['gitHead'] == head, file
    for group, collection in [('sources', source_bindings), ('inputs', input_bindings)]:
        for item in r.get(group, []):
            name = item['path']
            if name in collection: assert collection[name] == item
            collection[name] = item
            b = (root / name).read_bytes()
            assert digest(b) == item['sha256'] and len(b) == item['bytes'], name
            if name.startswith('renderer/virgl-shader/build/'):
                generated[name] = item
            else:
                frozen = subprocess.check_output(['git', 'show', head + ':' + name], cwd=root)
                assert frozen == b, name
                checked[name] = item
    if '/hardware/' in str(file):
        assert r['native'] == r['browserResult'].get('native', r['native'])
    if 'browser' in r:
        assert r['browserErrors'] == {'console': [], 'page': [], 'requests': []}
        assert r['browser']['headless'] is False
        gpu = r['browser']['gpu']['featureStatus']
        assert gpu.get('webgl2', gpu.get('webgl')) == 'enabled'
        covinfo = r['browserCoverage']
        covbytes = (file.parent / covinfo['path']).read_bytes()
        assert digest(covbytes) == covinfo['sha256']
        cov = json.loads(covbytes)
        scripts = cov.get('scripts', [cov] if 'source' in cov else [])
        for script in scripts:
            mutation = r.get('sabotage', {})
            expected = mutation['servedSha256'] if mutation.get('path') == script['source'] else source_bindings[script['source']]['sha256']
            assert script['sha256'] == expected
        served = {s['path']: s for s in r['servedFiles']}
        for item in r['sources']:
            if '/' + item['path'] not in served: continue
            mutation = r.get('sabotage', {})
            expected = mutation['servedSha256'] if mutation.get('path') == item['path'] else item['sha256']
            assert served['/' + item['path']]['sha256'] == expected
        screen = r.get('screenshot', r.get('failureScreenshot'))
        assert digest((file.parent / screen['path']).read_bytes()) == screen['sha256']
happy = json.loads((dest / 'acceptance/receipt.json').read_bytes())
cold = json.loads((dest / 'cold/report.json').read_bytes())
cold_receipt = json.loads((dest / 'cold/acceptance/receipt.json').read_bytes())
assert digest((dest / 'acceptance/receipt.json').read_bytes()) == manifest['receiptSha256']
assert digest((dest / 'cold/report.json').read_bytes()) == manifest['coldReportSha256']
assert digest((dest / 'cold/acceptance/receipt.json').read_bytes()) == manifest['coldReceiptSha256']
assert cold['status'] == 'passed' and cold['cloneHead'] == head and cold['exitCode'] == 0
assert cold['statusBefore'] == cold['statusAfter'] == ''
assert cold['receiptSha256'] == manifest['coldReceiptSha256']
assert happy['sources'] == cold_receipt['sources'] and happy['inputs'] == cold_receipt['inputs']
summary = {'status': 'passed', 'sourceHead': head, 'archiveSha256': digest(raw), 'members': len(members),
           'recordIndexSha256': digest(index_raw), 'sourceAndInputBindings': len(checked),
           'generatedBindings': generated, 'coldReport': cold, 'receiptSha256': manifest['receiptSha256'],
           'historicalFailureExcludedFromAcceptance': {'head': historical['gitHead'], 'status': historical['status']},
           'sealedDiffSha256': digest(code_diff), 'sealedDiffTaskMetadataWaiver': 'Sealed code diff intentionally excludes only tasks; exact runtime, harness, docs and Makefile diff bytes match frozen base..sourceHead.',
           'reports': [{'path': str(p.relative_to(dest)), 'sha256': digest(p.read_bytes()), 'status': json.loads(p.read_bytes())['status']} for p in reports]}
(out / 'authentication.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
