import { createResourceStore, createWebGL2TransferBackend } from '/renderer/virgl-command/resources.mjs';
import { createVirglStateRenderer } from '/renderer/virgl-command/state.mjs';
import { decodeSubmission } from '/renderer/virgl-command/decoder.mjs';

const m = (format, bind = 10, id = 1) => ({id, target:2, format, bind, width:5, height:5, depth:1, arraySize:1, lastLevel:0, nrSamples:0, flags:0});
const box = {x:1,y:1,z:0,width:3,height:3,depth:1};
const transfer = (direction=1) => ({opcode:43,fields:{resourceHandle:1,level:0,usage:0,stride:17,layerStride:51,box,dataOffset:7,direction}});
function packet(op,type,words) {const bytes=new Uint8Array(4+4*words.length),v=new DataView(bytes.buffer);v.setUint32(0,op+256*type+65536*words.length,true);words.forEach((w,i)=>v.setUint32(4+4*i,w,true));return bytes;}
function floatWord(f){const v=new DataView(new ArrayBuffer(4));v.setFloat32(0,f,true);return v.getUint32(0,true);}
function checks(){const rows=[];const equal=(a,e,label)=>{const held=JSON.stringify(a)===JSON.stringify(e);rows.push({prediction:label,expected:e,observed:a,held});if(!held)throw new Error(label+': '+JSON.stringify(a)+' != '+JSON.stringify(e));};const ok=(r,l)=>{equal(r.ok,true,l);return r;};const bad=(r,code,l)=>{equal(r.ok,false,l);equal(r.error.code,code,l+' error');};return{rows,equal,ok,bad};}
function close(s,c){c.ok(s.dispose(),'dispose attack store');const b=c.ok(s.inspect(),'final attack budgets').budgets;for(const[k,v]of Object.entries(b))c.equal(v,0,'final '+k);}
function roleAttack(c){
 const backend={maxTextureSize:16384,allocate:meta=>({kind:meta.kind}),destroy(){},upload(){},readback:(s,m,l)=>new Uint8Array(l.tightBytes),dispose(){}};
 const {store:s}=c.ok(createResourceStore({backend}),'metadata-only hostile store');
 for(let format=0;format<301;format++)if(![2,67,233].includes(format))c.bad(s.createResource(m(format)),'unsupported-resource','forbidden numeric format '+format);
 for(let bit=0;bit<32;bit++)if(![1,3,18,20].includes(bit))c.bad(s.createResource(m(233,2+2**bit)),'unsupported-resource','forbidden bind bit '+bit);
 for(const bind of [0,262144,1048576,1310720])c.bad(s.createResource(m(233,bind)),'unsupported-resource','hints cannot grant a role '+bind);
 c.equal(c.ok(s.inspect(),'metadata guards did not allocate').budgets.gpuBytes,0,'all forbidden requests publish no allocation');close(s,c);
 for(const format of [2,67,233])for(const bind of [2,8,10,262146,1048584]){
  const {store,bindings}=c.ok(createResourceStore({backend}),'role matrix store');c.ok(store.createContext(1),'role context');const r=c.ok(store.createResource(m(format,bind)),'valid role matrix create').resource;c.ok(store.attachContext(1,1),'role matrix attach');
  for(const role of ['view','surface','vertex','index','readback']){const allowed=role==='readback'||role==='view'&&Boolean(bind&8)||role==='surface'&&Boolean(bind&2),v=store.retainStorage(1,1,role);if(allowed)c.ok(store.releaseStorage(c.ok(v,'allowed '+role).lease),'release allowed '+role);else c.bad(v,'unsupported-resource','denied '+role);}
  if(format===67&&Boolean(bind&2))c.ok(store.releaseStorage(c.ok(bindings.retainScanout(1,r.generation),'legacy render scanout').lease),'release legacy scanout');else c.bad(bindings.retainScanout(1,r.generation),'unsupported-resource','no scanout role expansion');
  close(store,c);
 }
 for(const format of [1,68,134,234])c.bad(decodeSubmission(packet(1,8,[1,1,format,0,0])),'unsupported-feature','surface decoder rejects unsupported '+format);
 for(const [level,layers]of [[1,0],[0,1],[0,65536]])c.bad(decodeSubmission(packet(1,8,[1,1,233,level,layers])),'unsupported-feature','surface rejects alternate level/layer');
}
function physical(gl,texture,format){
 const fb=gl.createFramebuffer();gl.bindFramebuffer(gl.READ_FRAMEBUFFER,fb);gl.framebufferTexture2D(gl.READ_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,texture,0);gl.readBuffer(gl.COLOR_ATTACHMENT0);
 if(gl.checkFramebufferStatus(gl.READ_FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw new Error('independent physical attachment incomplete');
 gl.bindBuffer(gl.PIXEL_PACK_BUFFER,null);for(const [p,v]of [[gl.PACK_ALIGNMENT,1],[gl.PACK_ROW_LENGTH,0],[gl.PACK_SKIP_ROWS,0],[gl.PACK_SKIP_PIXELS,0]])gl.pixelStorei(p,v);
 const raw=format===233?new Uint32Array(25):new Uint8Array(100);gl.readPixels(0,0,5,5,gl.RGBA,format===233?gl.UNSIGNED_INT_2_10_10_10_REV:gl.UNSIGNED_BYTE,raw);
 const result=[];for(let i=0;i<25;i++)result.push(format===233?[raw[i]%1024,Math.floor(raw[i]/1024)%1024,Math.floor(raw[i]/1048576)%1024,Math.floor(raw[i]/1073741824)]:Array.from(raw.subarray(4*i,4*i+4)));
 gl.framebufferTexture2D(gl.READ_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,null,0);gl.deleteFramebuffer(fb);return result;
}
function sample(gl,texture,format){
 const shaders=[],p=gl.createProgram(),out=gl.createTexture(),fb=gl.createFramebuffer(),vao=gl.createVertexArray();
 for(const[t,src]of [[gl.VERTEX_SHADER,'#version 300 es\nvoid main(){vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2));gl_Position=vec4(2.*p-1.,0.,1.);}'],[gl.FRAGMENT_SHADER,'#version 300 es\nprecision highp float;uniform sampler2D t;out vec4 c;void main(){c=texelFetch(t,ivec2(gl_FragCoord.xy),0);}']]){const s=gl.createShader(t);shaders.push(s);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(s));gl.attachShader(p,s);}
 gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(p));
 gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,out);gl.texStorage2D(gl.TEXTURE_2D,1,format===233?gl.RGB10_A2:gl.RGBA8,5,5);
 gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,fb);gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,out,0);gl.drawBuffers([gl.COLOR_ATTACHMENT0]);gl.bindVertexArray(vao);gl.useProgram(p);gl.uniform1i(gl.getUniformLocation(p,'t'),0);gl.bindTexture(gl.TEXTURE_2D,texture);gl.bindSampler(0,null);gl.viewport(0,0,5,5);gl.colorMask(true,true,true,true);
 for(const cap of [gl.BLEND,gl.DITHER,gl.SCISSOR_TEST,gl.DEPTH_TEST,gl.STENCIL_TEST,gl.CULL_FACE,gl.RASTERIZER_DISCARD])gl.disable(cap);gl.drawArrays(gl.TRIANGLES,0,3);
 const result=physical(gl,out,format===233?233:67);gl.deleteProgram(p);shaders.forEach(s=>gl.deleteShader(s));gl.deleteTexture(out);gl.deleteFramebuffer(fb);gl.deleteVertexArray(vao);return result;
}
function input(format,seed){
 let state=seed;const next=()=>{state=(Math.imul(state,1664525)+1013904223)>>>0;return state;};
 const dense=new Uint8Array(36),canonical=new Uint8Array(36),v=new DataView(dense.buffer),cv=new DataView(canonical.buffer),rgba=[];
 for(let i=0;i<9;i++){
  const max=format===233?1024:256,r=next()%max,g=next()%max,b=next()%max,a=next()%(format===233?4:256);rgba.push([r,g,b,format===233?3:format===2?255:a]);
  if(format===233){v.setUint32(i*4,b+1024*g+1048576*r+1073741824*a,true);cv.setUint32(i*4,b+1024*g+1048576*r+3221225472,true);}
  else{dense.set(format===2?[b,g,r,a]:[r,g,b,a],4*i);canonical.set(format===2?[b,g,r,255]:[r,g,b,a],4*i);}
 }
 const padded=new Uint8Array(57).fill(0xa3);for(let row=0;row<3;row++)padded.set(dense.subarray(12*row,12*row+12),7+17*row);
 const canonicalPadded=new Uint8Array(57).fill(0xa3);for(let row=0;row<3;row++)canonicalPadded.set(canonical.subarray(12*row,12*row+12),7+17*row);
 const expected=Array.from({length:25},()=>[0,0,0,format===233?3:format===2?255:0]);for(let y=0;y<3;y++)for(let x=0;x<3;x++)expected[(y+1)*5+x+1]=rgba[y*3+x];
 return{dense,canonical,padded,canonicalPadded,expected};
}
async function poll(a,t,c){for(let i=0;i<100;i++){await new Promise(r=>setTimeout(r,1));const r=c.ok(a.poll(t),'bounded independent PBO poll');if(r.status==='ready')return r.bytes;c.equal(r.status,'pending','only pending before real fence');}throw new Error('independent bounded poll timeout');}
async function partial(gl,format,seed,c){
 let nativeStorage,delays=(seed%4)+1,collects=0;
 const wrapped=new Proxy(gl,{get(t,k){const f=Reflect.get(t,k,t);if(typeof f!=='function')return f;return(...args)=>{if(k==='clientWaitSync'){const r=f.apply(t,args);if(delays>0){delays--;return t.TIMEOUT_EXPIRED;}return r;}if(k==='getBufferSubData')collects++;return f.apply(t,args);};}});
 const native=c.ok(createWebGL2TransferBackend(wrapped),'hardware attack backend').backend,backend={...native,allocate(meta){const s=native.allocate(meta);nativeStorage=s;return s;}};
 const {store,bindings,asyncAccess}=c.ok(createResourceStore({backend}),'hardware attack store');
 const renderer=c.ok(createVirglStateRenderer({gl:wrapped,resources:store,bindings,shaderBridge:{translate(){throw new Error('clear-only attack');}}}),'hardware attack renderer').renderer;
 c.ok(store.createContext(1),'attack context');c.ok(renderer.createContext(1),'attack state context');
 gl.colorMask(false,true,false,false);gl.enable(gl.SCISSOR_TEST);gl.scissor(1,1,1,1);const previous=gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING);
 c.ok(store.createResource(m(format)),'attack texture');if(format===233){c.equal(gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING)===previous,true,'packed initialization restores exact DRAW framebuffer');c.equal([...gl.getParameter(gl.COLOR_WRITEMASK)],[false,true,false,false],'packed initialization restores hostile mask');c.equal(gl.isEnabled(gl.SCISSOR_TEST),true,'packed initialization restores hostile scissor');}
 c.ok(store.attachContext(1,1),'attack attachment');
 const f=input(format,seed),caller=f.padded.slice();c.ok(store.attachBacking(1,[caller.subarray(0,1),caller.subarray(1,13),caller.subarray(13,32),caller.subarray(32)]),'unaligned split caller backing');caller.fill(0);
 c.ok(store.executeTransfer(c.ok(store.prepareTransfer(1,transfer()),'nonzero partial upload').ticket),'partial physical upload');
 c.equal([...c.ok(store.readBacking(1,0,57),'caller input owned').bytes],[...f.padded],'caller poison cannot change split backing');
 c.equal(physical(gl,nativeStorage.texture,format),f.expected,'independent native partial physical '+format+' seed '+seed);
 c.equal(sample(gl,nativeStorage.texture,format),f.expected,'independent sampled partial physical '+format+' seed '+seed);
 const lease=c.ok(store.retainStorage(1,1,'view'),'exact partial view').lease;
 c.equal([...c.ok(store.readStorage(lease,box),'partial inverse read').bytes],[...f.canonical],'independent inverse channels '+format+' seed '+seed);
 c.ok(store.writeBacking(1,0,new Uint8Array(57).fill(0xa3)),'poison private scatter backing');c.ok(store.executeTransfer(c.ok(store.prepareTransfer(1,transfer(2)),'prepare partial scatter').ticket),'partial scatter');
 c.equal([...c.ok(store.readBacking(1,0,57),'partial scatter result').bytes],[...f.canonicalPadded],'partial inverse preserves offset/row/prefix/suffix padding');
 const t=c.ok(asyncAccess.prepareTransfer(1,transfer()),'async partial input ticket').ticket;
 const container=new Uint8Array(41);container.set(f.dense,3);c.ok(asyncAccess.provideInput(t,container.subarray(3,39)),'unaligned dense caller input');container.fill(0);c.ok(asyncAccess.upload(t),'unaligned async source cloned');c.ok(asyncAccess.release(t),'release async input');
 c.equal(sample(gl,nativeStorage.texture,format),f.expected,'async input poison cannot change partial physical pixels');
 collects=0;const hold=(seed%4)+1;delays=hold;const read=c.ok(asyncAccess.beginStorageRead(lease,box),'partial PBO issue').ticket;
 for(let i=0;i<hold;i++)c.equal(c.ok(asyncAccess.poll(read),'withheld actual fence').status,'pending','withheld actual fence has no CPU completion');c.equal(collects,0,'withheld fence cannot collect CPU payload');
 c.equal([...await poll(asyncAccess,read,c)],[...f.canonical],'varied fence schedule physical inverse');c.equal(collects,1,'signaled PBO collected once');c.ok(asyncAccess.release(read),'release partial PBO');
 const stale=c.ok(asyncAccess.beginStorageRead(lease,box),'revision stale PBO').ticket;c.ok(store.executeTransfer(c.ok(store.prepareTransfer(1,transfer()),'overwrite while staged').ticket),'overwrite retained content');c.bad(asyncAccess.poll(stale),'stale-storage','changed contents cannot collect old view');c.ok(asyncAccess.release(stale),'release revision stale PBO');
 c.bad(store.readStorage(Object.freeze({}),box),'invalid-lease','forged storage lease');c.ok(store.releaseStorage(lease),'release exact partial lease');c.bad(store.readStorage(lease,box),'invalid-lease','released storage lease');
 const pending=c.ok(store.prepareTransfer(1,transfer()),'backing stale upload').ticket;c.ok(store.detachBacking(1),'revoke attached backing');c.ok(store.attachBacking(1,[f.padded]),'replace same byte backing');c.bad(store.executeTransfer(pending),'stale-ticket','exact backing generation rejects old transfer');
 for(const other of [2,67,233].filter(v=>v!==format))c.bad(renderer.executeSubmission(1,packet(1,8,[100+other,1,other,0,0])),'incompatible-resource','surface format cannot reinterpret '+format+' as '+other);
 c.ok(renderer.executeSubmission(1,packet(1,8,[50,1,format,0,0])),'new format surface');c.ok(renderer.executeSubmission(1,packet(5,0,[1,0,50])),'select attack surface');
 c.ok(renderer.executeSubmission(1,packet(7,0,[4,0,0,0,floatWord(0),0,0x3ff00000,0])),'production X clear after sampled GL poison');
 c.equal(physical(gl,nativeStorage.texture,format),Array.from({length:25},()=>[0,0,0,format===233?3:format===2?255:0]),'CLEAR after host poison keeps exact X alpha');
 c.ok(renderer.dispose(),'dispose attack renderer');close(store,c);c.equal(gl.getError(),gl.NO_ERROR,'independent final GL errors');return{format,seed,partialBox:box,expectedPixels:f.expected,denseGuest:[...f.dense],canonicalGuest:[...f.canonical],withheldFencePolls:hold};
}
async function hardwareRoles(gl,c){
 const reports=[];
 for(const format of [2,67,233])for(const bind of [2,8]){
  let allocation;const native=c.ok(createWebGL2TransferBackend(gl),'role real backend').backend,backend={...native,allocate(meta){const s=native.allocate(meta);allocation=s;return s;}};
  const {store,bindings}=c.ok(createResourceStore({backend}),'role actual store');const renderer=c.ok(createVirglStateRenderer({gl,resources:store,bindings,shaderBridge:{translate(){throw new Error('role-only attack');}}}),'role actual renderer').renderer;
  c.ok(store.createContext(1),'role actual context');c.ok(renderer.createContext(1),'role actual state context');c.ok(store.createResource(m(format,bind)),'single-role hardware create');c.ok(store.attachContext(1,1),'single-role hardware attach');const f=input(format,0xabcdef);c.ok(store.attachBacking(1,[f.padded]),'single-role backing');c.ok(store.executeTransfer(c.ok(store.prepareTransfer(1,transfer()),'single-role upload prepare').ticket),'single-role actual upload');
  c.equal(physical(gl,allocation.texture,format),f.expected,'single-role actual attachment '+format+' bind '+bind);
  if(bind===8){const lease=c.ok(store.retainStorage(1,1,'view'),'sampler-only actual view').lease;c.equal(sample(gl,allocation.texture,format),f.expected,'sampler-only actual hardware sampling '+format);c.ok(store.releaseStorage(lease),'sampler-only view release');c.bad(renderer.executeSubmission(1,packet(1,8,[10,1,format,0,0])),'unsupported-resource','sampler-only renderer cannot make surface');}
  else{c.bad(store.retainStorage(1,1,'view'),'unsupported-resource','render-only cannot make sample lease');c.ok(renderer.executeSubmission(1,packet(1,8,[10,1,format,0,0])),'render-only actual surface');c.ok(renderer.executeSubmission(1,packet(5,0,[1,0,10])),'render-only select');c.ok(renderer.executeSubmission(1,packet(7,0,[4,0,0,0,0,0,0x3ff00000,0])),'render-only actual clear');c.equal(physical(gl,allocation.texture,format),Array.from({length:25},()=>[0,0,0,format===233?3:format===2?255:0]),'render-only physical forced alpha '+format);}
  const lease=c.ok(store.retainStorage(1,1,'readback'),'single-role readback lease').lease;c.equal(c.ok(store.readStorage(lease,box),'single-role inverse physical read').bytes.length,36,'single-role readback exact byte extent');c.ok(store.releaseStorage(lease),'release single-role readback');c.ok(renderer.dispose(),'dispose single-role renderer');close(store,c);c.equal(gl.getError(),gl.NO_ERROR,'single-role actual GL errors');reports.push({format,bind});
 }
 return reports;
}
async function partialBudgets(gl,c){
 const reports=[];
 for(const format of [2,233])for(const short of [null,'gpuBytes','cpuBytes','scratchBytes']){
  let reads=0;const wrapped=new Proxy(gl,{get(t,k){const f=Reflect.get(t,k,t);return typeof f==='function'?(...a)=>{if(k==='readPixels')reads++;return f.apply(t,a);}:f;}}),backend=c.ok(createWebGL2TransferBackend(wrapped),'quota hardware backend').backend;
  const limits={resourceBytes:128,gpuBytes:136,cpuBytes:93,scratchBytes:36};if(short)limits[short]--;
  const {store,asyncAccess}=c.ok(createResourceStore({backend,limits}),'quota partial store');c.ok(store.createContext(1),'quota context');c.ok(store.createResource(m(format)),'quota resource100');c.ok(store.attachContext(1,1),'quota attach');c.ok(store.attachBacking(1,[input(format,0x2468ac).padded]),'quota backing57');const lease=c.ok(store.retainStorage(1,1,'readback'),'quota retained readback').lease,before=c.ok(store.inspect(),'quota before').budgets;
  const begun=asyncAccess.beginStorageRead(lease,box);
  if(short){c.bad(begun,'limit-exceeded','independent one-byte-short '+short);c.equal(c.ok(store.inspect(),'quota rejection state').budgets,before,'independent pressure rollback '+short);c.equal(reads,0,'independent pressure fails before physical read '+short);}
  else{const ticket=c.ok(begun,'independent exact partial PBO').ticket,active=c.ok(store.inspect(),'active exact quota').budgets;c.equal([active.gpuBytes,active.cpuBytes,active.scratchBytes],[136,93,36],'independent exact partial quota accounting');const bytes=await poll(asyncAccess,ticket,c);c.equal(bytes.length,36,'independent exact partial output');c.ok(asyncAccess.release(ticket),'release exact partial PBO');c.equal(c.ok(store.inspect(),'exact partial quota release').budgets,before,'exact partial PBO releases once');}
  c.ok(store.releaseStorage(lease),'quota lease release');close(store,c);c.equal(gl.getError(),gl.NO_ERROR,'independent quota GL errors');reports.push({format,limits,short});
 }
 return reports;
}
export async function run(){
 const c=checks();roleAttack(c);const canvas=document.querySelector('canvas'),gl=canvas.getContext('webgl2',{antialias:false,preserveDrawingBuffer:true});c.equal(Boolean(gl),true,'independent hardware WebGL2 context');const debug=gl.getExtension('WEBGL_debug_renderer_info'),renderer=gl.getParameter(debug.UNMASKED_RENDERER_WEBGL);c.equal(/swiftshader|llvmpipe|softpipe|lavapipe/i.test(renderer),false,'independent physical GPU');
 const cases=[];for(const format of [233,2,67])for(const seed of [0x12345,0xbadcafe,0x77c001])cases.push(await partial(gl,format,seed,c));const roles=await hardwareRoles(gl,c),budgets=await partialBudgets(gl,c);return{status:'passed',renderer,cases,roles,budgets,assertions:c.rows};
}
