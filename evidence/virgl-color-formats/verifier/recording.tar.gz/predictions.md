# Fresh verifier predictions — 2026-10-04

These predictions are recorded after reading the task/diff and before opening any evidence.

P1 AUTHENTICITY: The sealed archive SHA256 is ef5cd601c77585b597b85fda5f77e227694d6ddb1a3041dd50ae398b6920b273, contains exactly 60 regular relative members without traversal/duplicates, and every member matches records.json. Every runtime/input binding matches frozen f0770a386271513fac56df8da26057e256a6ae8b; source-identical later log/seal commits do not excuse stale code.

P2 ORIGINALS: Recorded BGRX surface event176 and packed10 surface event5115 retain their exact packet/create metadata. Recorded RGBA CPU upload event140 physically hashes to the authenticated original backing, not a renderer-generated image.

P3 PHYSICAL CHANNELS/PRECISION/ORIGIN: Literal asymmetric rows must physically sample in lower-left order as [231,5,37,255] first BGRX texel, [37,5,231,12] first RGBA texel, and [1,257,1022,3] first packed10 texel. Attachments report [8,8,8,0], [8,8,8,8], [10,10,10,2]. Arbitrary X bits cannot change sampled alpha.

P4 INVERSE/OWNERSHIP: Sync and staged async guest readback must retain all original RGB bits and canonicalize only X bits to ones. Odd stride17, offset5, split backing and staging copies preserve every 0xa7 padding byte. Conversions cannot mutate attached caller bytes; cloned async input remains valid after caller poison. Three varied read-fence schedules converge to the same literal bytes.

P5 ROLES/REINTERPRETATION: Binds2/8/10 admit only their render/sampler roles; allowed hints grant neither role. Unsupported format, bind bits, target/flags/levels/arrays/MSAA fail before publishing storage. Surface-format reinterpretation, stale/foreign/released leases and scanout of new formats must reject.

P6 ALPHA: Packed10 allocation stores alpha3, BGRX has implicit alpha255. Production CLEAR and actual guest-command DRAW with zero source alpha retain X destination alpha, while ordinary RGBA destination alpha becomes0. Physical DST_ALPHA blends yield red [1023,0,0,3] / [255,0,0,255] for X formats and [0,0,0,0] for RGBA. SRC_ALPHA with zero fragment alpha leaves zero RGB, preserving X alpha.

P7 GENERATIONS: A pending read and retained view survive public ID reuse without adopting the new format. Its conversion uses the old storage format; old GPU+new GPU+PBO are charged72, falling to24 only after both old references release. Revoked leases fail before PBO collection.

P8 BUDGETS/ROLLBACK: Exact24-byte dense conversion scratch and48-byte GPU including PBO fit; one-byte-short CPU/GPU/scratch fail before a readPixels call and restore budgets. Failed packed initialization deletes unpublished texture, restores host mask/scissor state and leaves no GPU charge/GL error.

P9 REGRESSION/ENVIRONMENT: All five affected decoder/resources/state/draw/async regressions pass at frozen source with no hidden skips or browser errors. The one pristine clone has exact f0770a38 head, empty status before/after, scrubbed relevant environment, and identical source/input/generated-WASM bindings; no repeat is needed unless isolation fails.

P10 FAULT SENSITIVITY: Independently swapping packed channel order or permitting forced-alpha writes in scratch served runtime must fail at an independent physical oracle rather than imports, syntax or quotas. Tracked implementation must remain byte-identical.

P11 COVERAGE: Every changed runtime hunk has a source-bound nonzero V8 range in hardware or affected regression coverage. Any missed behavior is needs-evidence; declarative/docs/testing/receipt glue may be waived with reasoning. Positive range hits do not by themselves prove all semantic branches.

P12 NOVEL ATTACK: Independently seeded arbitrary packed10/byte texels with nonzero partial rectangles, odd stride/dataOffset and split buffers must retain sampled channels and native 10-bit precision, untouched physical neighbor pixels and guest padding; a subsequent source-fault replay must refute its physical oracle.
