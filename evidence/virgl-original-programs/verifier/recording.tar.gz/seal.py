from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-original-programs-verifier';DEST=ROOT/'evidence/virgl-original-programs/verifier';sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
for directory in ['independent','interfaces-v8','final-custody-v8','page-hooks','guard-open']:
 for p in (OUT/directory).rglob('*'):
  if p.is_file():files[p.relative_to(OUT).as_posix()]=p.read_bytes()
for name in ['predictions.json','authenticate.py','authentication.json','gates.sh','independent-gates.log','hot-readback-audit.log','cold-readback-audit.log','tgsi-audit.mjs','tgsi-audit.json','tgsi-audit.log','carry-forward.json','interfaces.json','final-custody.json','final-custody.stderr','independent-browser.mjs','page-hooks.log','guard-open.log','sabotage-plan.json','sabotage-build.log','prefix-native-build.log','prefix-native.out','prefix-native.stderr','prefix-native.profraw','prefix-native.profdata','prefix-native-coverage.json','predecessor-prefix-native.out','coverage-audit.json','final-audit.py','final-audit.json','final-audit.log','seal.py']:
 files[name]=(OUT/name).read_bytes()
for name in ['bridge.c','bridge.h','raw_bits.c','raw_bits.h','private_92cb_inputs.h','build.sh','UPSTREAM.json','build/wasm/virgl-shader.mjs','build/wasm/virgl-shader.wasm']:
 files['sabotage/guard-open/'+name]=(OUT/'sabotage/guard-open'/name).read_bytes()
newtest='renderer/virgl-shader/tests/original-programs-custody.mjs';files['promoted/'+newtest]=(ROOT/newtest).read_bytes()
files['reviewed-diff.patch']=subprocess.check_output(['git','diff','f18232d88fa0cc4673c5af7c0d414046803c0883','3f0db236825e4389c4cd78e82192f81dc9b5cf90'])
receipt=json.loads((OUT/'independent/receipt.json').read_text())
for name,digest in receipt['generated'].items():
 data=(ROOT/name).read_bytes();assert sha(data)==digest;files['fresh-generated/'+name]=data
assert json.loads(files['final-audit.json'])['status']=='passed'
records={'schema':'virgl-original-programs-verifier-records-v1','task':'E6-T12g6m','workerSourceHead':'3f0db236825e4389c4cd78e82192f81dc9b5cf90','records':[{'path':name,'bytes':len(data),'sha256':sha(data)}for name,data in sorted(files.items())]}
index=(json.dumps(records,indent=2)+'\n').encode();packed=io.BytesIO()
with gzip.GzipFile(fileobj=packed,mode='wb',mtime=0)as compressed:
 with tarfile.open(fileobj=compressed,mode='w')as archive:
  for name,data in sorted(files.items()):
   info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
raw=packed.getvalue();DEST.mkdir(parents=True,exist_ok=True);(DEST/'records.json').write_bytes(index);(DEST/'recording.tar.gz').write_bytes(raw)
manifest={'schema':'virgl-original-programs-verifier-seal-v1','task':'E6-T12g6m','verdict':'verified','workerSourceHead':records['workerSourceHead'],'reviewedSubmissionHead':'b5e91fe302cbc55f594ac6aa779c68367f182547','workerArchiveSha256':'a90cd34bf49f9dbe9dc8ebb54e2f0a95f544a1f72c78d28e436f1ba16beb5a12','records':len(files),'archiveBytes':len(raw),'archiveSha256':sha(raw),'recordIndexSha256':sha(index),'predictionsSha256':sha(files['predictions.json']),'finalAuditSha256':sha(files['final-audit.json']),'coverageAuditSha256':sha(files['coverage-audit.json']),'promotedTest':{'path':newtest,'sha256':sha((ROOT/newtest).read_bytes())},'guestExecution':False,'productionDrawAuthority':False,'portableAccuracyAuthority':False}
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
