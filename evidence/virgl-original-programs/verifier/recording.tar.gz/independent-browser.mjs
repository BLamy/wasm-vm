import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createServer} from 'node:http';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const root=process.cwd(),mode=process.argv[2]??'page-hooks',out=path.join(root,'target/evidence/virgl-original-programs-verifier',mode);
fs.mkdirSync(out,{recursive:true});assert.ok(['page-hooks','guard-open'].includes(mode));
const {chromium}=await import(pathToFileURL(path.join(root,'web/node_modules/playwright/index.mjs')).href);
const sha=raw=>createHash('sha256').update(raw).digest('hex'),served=new Map(),chrome='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const allowedInput=new Set(['target/evidence/virgl-92cb-raster/geometry.bin','target/evidence/virgl-92cb-raster/raster.json',...['7bf4d0d0f981a9feb958d6595302b15d564fc846e6d5ee71874f0921b31e613e','92cb866af48f952b719c54959a439c7330333c6d32897430bc3d4a0a2f63bfba'].map(hash=>`evidence/virgl-workload-inventory/captures/es2gears/shaders/${hash}.tgsi`)]);
const report={task:'E6-T12g6m',mode,gitHead:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),status:'running',expected:mode==='page-hooks'?'passed with zero page-realm GPU/fetch hooks':'failed at a literal guard rejection after actual copied compiler emits an open guard',browserErrors:{console:[],page:[],requests:[]},workers:[],served:[]};
const server=createServer((request,response)=>{try{
 const pathname=new URL(request.url,'http://localhost').pathname;if(pathname==='/favicon.ico'){response.writeHead(204).end();return;}
 if(pathname==='/'){response.writeHead(200,{'Content-Type':'text/html'}).end('<!doctype html><meta charset="utf-8"><title>Independent original program verification</title><p id="status"></p><p id="renderer"></p><canvas id="gpu"></canvas>');return;}
 const relative=decodeURIComponent(pathname).slice(1);assert.ok(!relative.includes('..')&&(relative.startsWith('renderer/virgl-shader/')||relative.startsWith('tools/virgl-original-programs/')||allowedInput.has(relative)));
 let file=path.join(root,relative);const override=mode==='guard-open'&&['renderer/virgl-shader/build/wasm/virgl-shader.mjs','renderer/virgl-shader/build/wasm/virgl-shader.wasm'].includes(relative);
 if(override)file=path.join(root,'target/evidence/virgl-original-programs-verifier/sabotage/guard-open/build/wasm',path.basename(file));
 const bytes=fs.readFileSync(file);served.set(relative,{url:relative,file:path.relative(root,file),sha256:sha(bytes),bytes:bytes.length,override});
 response.writeHead(200,{'Content-Type':relative.endsWith('.wasm')?'application/wasm':relative.endsWith('.mjs')?'text/javascript':relative.endsWith('.json')?'application/json':'text/plain','Cache-Control':'no-store'}).end(bytes);
 }catch(error){response.writeHead(404).end(String(error));}});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));let browser,page;
try{
 browser=await chromium.launch({executablePath:chrome,headless:false,args:['--enable-gpu']});const session=await browser.newBrowserCDPSession();
 report.browser={version:await session.send('Browser.getVersion'),gpu:await session.send('SystemInfo.getInfo'),commandLine:await session.send('Browser.getBrowserCommandLine')};
 assert.equal(report.browser.gpu.gpu.featureStatus.webgl,'enabled');assert.ok(!report.browser.commandLine.arguments.some(arg=>/swiftshader|llvmpipe|softpipe|lavapipe|--disable-gpu(?:$|=)/i.test(arg)));
 page=await browser.newPage({viewport:{width:1120,height:920}});page.on('console',message=>{if(message.type()==='error')report.browserErrors.console.push(message.text());});page.on('pageerror',error=>report.browserErrors.page.push(error.message));page.on('requestfailed',request=>report.browserErrors.requests.push(request.url()));page.on('worker',worker=>report.workers.push(worker.url()));
 if(mode==='page-hooks')await page.addInitScript(()=>{
  const hits=window.__verifierPageHooks={getUniform:0,uniform4uiv:0,drawArrays:0,getBufferSubData:0,offscreenContext:0,fetch:0};
  for(const name of ['getUniform','uniform4uiv','drawArrays','getBufferSubData']){const original=WebGL2RenderingContext.prototype[name];WebGL2RenderingContext.prototype[name]=function(...args){hits[name]++;return Reflect.apply(original,this,args);};}
  const context=OffscreenCanvas.prototype.getContext;OffscreenCanvas.prototype.getContext=function(...args){hits.offscreenContext++;return Reflect.apply(context,this,args);};
  const originalFetch=window.fetch;window.fetch=function(...args){hits.fetch++;return Reflect.apply(originalFetch,this,args);};
 });
 await page.goto(`http://127.0.0.1:${server.address().port}`,{waitUntil:'load'});
 try{const raw=await page.evaluate(async()=>JSON.stringify(await(await import('/renderer/virgl-shader/tests/original-programs.mjs')).runAcceptance()));report.acceptance=JSON.parse(raw);}
 catch(error){report.failure={message:error.message,stack:error.stack};}
 if(mode==='page-hooks'){
  assert.equal(report.acceptance?.status,'passed');const after=await page.evaluate(async()=>{let direct;try{await(await import('/renderer/virgl-shader/tests/original-programs.mjs')).runPhysicalAcceptance();direct='unexpected admission';}catch(error){direct=error.message;}return {pageHooks:window.__verifierPageHooks,direct};});
  report.pageHooks=after.pageHooks;report.directPageResult=after.direct;assert.ok(Object.values(after.pageHooks).every(value=>value===0));assert.equal(after.direct,'isolated physical WebGL worker');
  report.physicalReadbacks=report.acceptance.banks.map(b=>({bank:b.bank,sha256:b.readbackSha256,covered:b.covered,survived:b.survived,discarded:b.discarded}));
 }else{assert.equal(report.acceptance,undefined);assert.match(report.failure?.message??'',/literal numerical guard and emitted power zero-zero/);assert.ok(!/timeout/i.test(report.failure.message));}
 assert.ok(report.workers.some(url=>url.endsWith('/renderer/virgl-shader/tests/original-programs-worker.mjs')));assert.deepEqual(report.browserErrors,{console:[],page:[],requests:[]});
 await page.screenshot({path:path.join(out,'browser.png'),fullPage:true});report.screenshotSha256=sha(fs.readFileSync(path.join(out,'browser.png')));report.status='passed';
}catch(error){report.status='failed';report.verifierFailure={message:error.message,stack:error.stack};process.exitCode=1;}
finally{report.served=[...served.values()];for(const file of report.served)assert.equal(sha(fs.readFileSync(path.join(root,file.file))),file.sha256);fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');await browser?.close();await new Promise(resolve=>server.close(resolve));}
console.log(JSON.stringify({mode,status:report.status,pageHooks:report.pageHooks,failure:report.failure?.message,verifierFailure:report.verifierFailure?.message}));
