from pathlib import Path
import hashlib,json,subprocess
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-original-programs-verifier';sha=lambda b:hashlib.sha256(b).hexdigest();HEAD='3f0db236825e4389c4cd78e82192f81dc9b5cf90'
load=lambda p:json.loads(p.read_text())
auth=load(OUT/'authentication.json');assert auth['status']=='passed'
fresh=load(OUT/'independent/receipt.json');assert fresh['status']=='passed' and fresh['gitHead']=='b5e91fe302cbc55f594ac6aa779c68367f182547'
for name,digest in fresh['files'].items():assert sha((OUT/'independent'/name).read_bytes())==digest,name
for name,digest in fresh['generated'].items():assert sha((ROOT/name).read_bytes())==digest,name
for name,digest in fresh['sources'].items():assert sha((ROOT/name).read_bytes())==digest,name
old=load(OUT/'unpacked/hot/browser/report.json')['acceptance'];new=load(OUT/'independent/browser/report.json')['acceptance']
assert [r['readbackSha256']for r in old['banks']]==[r['readbackSha256']for r in new['banks']]
assert [p['readbackSha256']for r in old['banks']for p in r['probes']]==[p['readbackSha256']for r in new['banks']for p in r['probes']]
assert (OUT/'prefix-native.out').read_bytes()==(OUT/'predecessor-prefix-native.out').read_bytes()
assert load(OUT/'tgsi-audit.json')['status']=='passed'
assert load(OUT/'carry-forward.json')['status']=='passed'
assert load(OUT/'page-hooks/report.json')['status']==load(OUT/'guard-open/report.json')['status']=='passed'
custody=load(OUT/'final-custody.json');assert custody['status']=='passed' and custody['cases']==471
assert len(custody['prefixRecords'])==3 and not (OUT/'final-custody.stderr').read_bytes()
assert load(OUT/'interfaces.json')['status']=='passed'
for fault in ['source','bank','negative','nonfinite','geometry','zero-crossing','post-source','post-bank','post-geometry','post-parsed-bank','post-parsed-quad','post-sample','viewport','post-bound-exponent','post-bound-vertex','post-bound-attribute','post-bound-color','post-buffer-exponent','post-clear-exponent','output','discard','power-value','power-negative','power-subnormal','power-nan','power-zero','power-envelope']:
 r=load(OUT/'independent'/f'fault-{fault}'/'report.json');assert r['status']=='failed' and r['browserErrors']=={'console':[],'page':[],'requests':[]}
 assert 'timeout'not in r['failure']['message'].lower()
assert not subprocess.check_output(['git','diff','--name-only'],text=True).strip()
functions={}
for label,p in [('worker',OUT/'unpacked/hot/native-coverage.json'),('fresh',OUT/'independent/native-coverage.json'),('prefix',OUT/'prefix-native-coverage.json')]:
 for f in load(p)['data'][0]['functions']:
  if f['name'] in ['bridge_translate_original_92cb_complete','raw_record','raw_emit'] or f['name'].endswith((':power_contract',':pair_exact_finish',':float_snapshot')):
   functions.setdefault(f['name'],{})[label]={'calls':f['count'],'entry':f['regions'][0][:4]}
coverage={'status':'passed','nativeFunctions':functions,'hunks':[
 {'path':'renderer/virgl-shader/bridge.c','lines':'1673-1684,2023-2041,2195-2234','result':'executed','evidence':'worker/fresh complete native coverage, nine allocation faults, literal full-source native/Wasm results'},
 {'path':'renderer/virgl-shader/bridge.c','lines':'2015-2022','result':'executed','evidence':'fresh prefix native coverage and all three unchanged verified whole-response fingerprints'},
 {'path':'renderer/virgl-shader/raw_bits.c','lines':'537-559,1072-1083,1240-1262,1270-1275,1421-1422','result':'executed','evidence':'complete/prefix C source coverage; all 29 literal live site readbacks; original KILL in default and diagnostic modes; literal guard boundaries and source sabotage'},
 {'path':'renderer/virgl-shader/index.mjs','lines':'117-179','result':'executed','evidence':'real Wasm caller/interfaces executions with native allocation cleanup, whole-input snapshots and partial-result rejection; independent V8 coverage'},
 {'path':'renderer/virgl-shader/tests/original-programs-worker.mjs','lines':'1-10','result':'executed','evidence':'dedicated target URL/served worker digest; complete success, 27 fault messages and physical readbacks; page CDP alone correctly has no worker hit counts'},
 {'path':'renderer/virgl-shader/tests/original-programs.mjs','lines':'1-527','result':'executed','evidence':'three raw primary images, 87 power images, 22 literal cases, 27 fault paths, object disposal, independent page success/direct rejection and guard-open failure'},
 {'path':'Makefile,renderer/virgl-shader/build.sh,bridge.h,raw_bits.h','result':'executed/waived','reason':'native/Wasm/production build logs and binaries prove active commands/exports; declarations and source constants carry no separate runtime behavior'},
 {'path':'tools/virgl-original-programs/*.py,*.mjs;tools/verify-virgl-original-programs.sh','result':'executed','evidence':'authenticated original final hot/cold acceptance and seal; fresh complete gate, interfaces, oracle/readback audit and cold-source receipts'},
 {'path':'tasks/QUEUE.md,task markdown,README.md','result':'waived','reason':'descriptive task state/claim and boundary documentation; no executable behavior'}
 ],'defensiveWaivers':[
 {'point':'bridge.c:2220','reason':'The two component lists are constructed from bounded integer loop indices, counts 16/148 and monotonically increasing canonical keys. Given the complete pins, canonicalization rejection is unreachable; no caller controls this list.'},
 {'point':'bridge.c:2232','reason':'Only three fully pinned source/bank choices can succeed; observed output JSON sizes are under 100 KiB against 3,179,520-byte pair storage. Allocation failures are independently covered; this residual overflow guard cannot trigger under the fixed source/geometry envelope.'},
 {'point':'C comments/blank declarations and old unrelated uncovered blocks','reason':'No runtime operation; unchanged lower paths retain their cited HELD facts. No new user-visible behavior is waived.'}
 ]}
(OUT/'coverage-audit.json').write_text(json.dumps(coverage,indent=2)+'\n')
retained={}
for name in ['retained-originals/native/report.json','retained-originals/wasm/report.json','retained-gears/compiler.json','retained-gears/retained-f6/report.json','c580/receipt.json']:
 r=load(OUT/'independent'/name);assert r['status']=='passed';retained[name]={k:r[k]for k in ['status','gitHead','calls','checkedPixels','survivors','discards']if k in r}
for seed in [1648868771,254715103,3281536249]:
 r=load(OUT/'independent/retained-gears'/f'gpu-{seed}/report.json');assert r['status']=='passed' and r['browserErrors']=={'console':[],'page':[],'requests':[]}
for fault in ['lighting','auxiliary','forced-alpha']:
 r=load(OUT/'independent/retained-gears'/f'fault-{fault}/report.json');assert r['status']=='failed' and 'independent'in r['failure']['message']
result={'status':'passed','workerSourceHead':HEAD,'freshHead':fresh['gitHead'],'workerRecordCount':415,'primaryAnd87ProbeDigestsUnchanged':True,'freshFaults':27,'TGSIExtraCoordinates':sum(p['checked']for p in load(OUT/'tgsi-audit.json')['points']),'promotedCallerCases':custody['cases'],'actualBrowser':load(OUT/'unpacked/hot/browser/report.json')['browser']['version'],'carryForward':retained,'coverageSha256':sha((OUT/'coverage-audit.json').read_bytes()),'sabotage':'Actual copied C emitter with open domain guard rejected by literal zero-zero physical test','coldClone':'Authenticated final exact-head proof carried; no portability finding and no redundant rerun.'}
(OUT/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
