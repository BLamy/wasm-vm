from pathlib import Path,PurePosixPath
import hashlib,json,subprocess,tarfile
ROOT=Path.cwd(); OUT=ROOT/'target/evidence/virgl-original-programs-verifier'; WORKER=ROOT/'evidence/virgl-original-programs/worker'
HEAD='3f0db236825e4389c4cd78e82192f81dc9b5cf90'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
manifest=json.loads((WORKER/'manifest.json').read_bytes()); index_raw=(WORKER/'records.json').read_bytes(); index=json.loads(index_raw)
archive_raw=(WORKER/'recording.tar.gz').read_bytes()
assert sha(archive_raw)=='a90cd34bf49f9dbe9dc8ebb54e2f0a95f544a1f72c78d28e436f1ba16beb5a12'==manifest['archiveSha256']
assert sha(index_raw)=='f4f0cb900be5582b9fc29270304d045ac458ae2e926baaac726a65a315cf8e96'==manifest['recordIndexSha256']
assert len(archive_raw)==manifest['archiveBytes']; assert manifest['sourceHead']==index['sourceHead']==HEAD
records={row['path']:row for row in index['records']}; assert len(records)==len(index['records'])==415==manifest['records']
unpacked=OUT/'unpacked'; unpacked.mkdir(parents=True,exist_ok=True)
with tarfile.open(WORKER/'recording.tar.gz','r:gz') as archive:
 members=archive.getmembers(); assert len(members)==len(records); assert set(m.name for m in members)==set(records)
 for member in members:
  assert member.isfile() and not PurePosixPath(member.name).is_absolute() and '..' not in PurePosixPath(member.name).parts
  raw=archive.extractfile(member).read(); row=records[member.name]; assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
  target=unpacked/member.name; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(raw)
results=[]
for prefix in ['hot','cold']:
 receipt=json.loads((unpacked/prefix/'receipt.json').read_bytes()); assert receipt['gitHead']==HEAD and receipt['status']=='passed'
 assert receipt['guestExecution'] is False and receipt['productionDrawAuthority'] is False
 for name,digest in receipt['files'].items(): assert sha((unpacked/prefix/name).read_bytes())==digest,(prefix,name)
 for name,digest in receipt['sources'].items():
  raw=subprocess.check_output(['git','show',HEAD+':'+name]); assert sha(raw)==digest,(prefix,name)
 for name,digest in receipt['generated'].items(): assert sha((unpacked/(prefix+'-generated')/name).read_bytes())==digest,(prefix,name)
 results.append({'prefix':prefix,'receiptSha256':sha((unpacked/prefix/'receipt.json').read_bytes()),'files':len(receipt['files']),'sources':len(receipt['sources']),'binaries':len(receipt['generated'])})
cold=json.loads((unpacked/'cold/report.json').read_bytes()); assert cold['status']=='passed' and cold['cloneHead']==cold['gitHead']==HEAD
assert cold['exitCode']==0 and cold['statusBefore']==cold['statusAfter']==''
assert cold['receiptSha256']==sha((unpacked/'cold/receipt.json').read_bytes()) and cold['logSha256']==sha((unpacked/'cold/cold.log').read_bytes())
assert cold['command']==['make','verify-E6-T12g6m']
assert results[0]['receiptSha256']==manifest['hotReceiptSha256'] and results[1]['receiptSha256']==manifest['coldReceiptSha256']
assert sha((unpacked/'cold/report.json').read_bytes())==manifest['coldReportSha256']
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
changes=subprocess.check_output(['git','diff','--name-only',HEAD,head],text=True).splitlines()
assert all(name.startswith('evidence/') or name in ['tasks/QUEUE.md','tasks/epic-6-transcendence/E6-T12g6m-larger-original-programs.md'] for name in changes),changes
result={'status':'passed','task':'E6-T12g6m','sourceHead':HEAD,'submissionHead':head,'archiveSha256':sha(archive_raw),'indexSha256':sha(index_raw),'members':len(records),'receipts':results,'cold':cold,'sourceToSubmissionChanges':changes}
(OUT/'authentication.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key not in ['cold','sourceToSubmissionChanges']},indent=2))
