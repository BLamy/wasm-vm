import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import {originalOracle,powerPrediction,POWER_SITES} from '../../../tools/virgl-original-programs/oracle.mjs';
const directory='target/evidence/virgl-original-programs-verifier';
const sourcePath='evidence/virgl-workload-inventory/captures/es2gears/shaders/92cb866af48f952b719c54959a439c7330333c6d32897430bc3d4a0a2f63bfba.tgsi';
const source=fs.readFileSync(sourcePath,'utf8'),sha=raw=>createHash('sha256').update(raw).digest('hex');
const register=/^(-?)(IMM|TEMP|CONST|IN|OUT)\[(\d+)\](?:\.([xyzw]{1,4}))?$/;
const immediates=[...source.matchAll(/^IMM\[(\d+)\] UINT32 \{([^}]+)\}$/gm)].map(match=>match[2].split(',').map(Number));
const code=[...source.matchAll(/^[ \t]*(\d+):[ \t]+([A-Z0-9_]+)(?:[ \t]+([^\n]*))?$/gm)].map(match=>({pc:Number(match[1]),op:match[2],args:(match[3]??'').replace(/\s*:\d+$/,'').split(',').map(s=>s.trim()).filter(Boolean)}));
assert.equal(code.length,716);assert.ok(code.every((i,n)=>i.pc===n));
const stack=[],flow=new Map();
for(const i of code){if(i.op==='UIF')stack.push({pc:i.pc});else if(i.op==='ELSE')stack.at(-1).else=i.pc;else if(i.op==='ENDIF'){const item=stack.pop();flow.set(item.pc,{else:item.else,end:i.pc});if(item.else!==undefined)flow.set(item.else,{end:i.pc});}}
assert.equal(stack.length,0);
const tempDestinations=[181,198,217,234],fadePcs=[231,260,293,319];
const uses=[];
for(let n=0;n<fadePcs.length;n++){
 const pc=fadePcs[n],destination=tempDestinations[n];
 const references=code.filter(i=>i.args.slice(1).some(a=>new RegExp(`^TEMP\\[${destination}\\]`).test(a)));
 assert.deepEqual(references.map(i=>i.pc),[pc+2]);
 assert.equal(code[pc+2].op,'UCMP');assert.equal(code[pc+4].op,'UCMP');
 assert.equal(code[pc+4].args[2],'IMM[0].yyyy');
 uses.push({pc,destination,soleUsePc:pc+2,zeroSelectionPc:pc+4,sourceLines:[pc+39,pc+41,pc+43]});
}
const buffer=new ArrayBuffer(4),floats=new Float32Array(buffer),words=new Uint32Array(buffer);
const f=word=>{words[0]=word;return floats[0];},w=value=>{floats[0]=value;return words[0];},signed=word=>word|0;
function execute(bank,u,v,negativeResult=NaN){
 const file={IMM:immediates,TEMP:[],CONST:Array.from({length:37},(_,r)=>bank.fragment.slice(r*4,r*4+4)),IN:[[w(u),w(v),bank.vertex[12],bank.vertex[13]],[bank.vertex[14],bank.vertex[15]]],OUT:[]};
 const histories=[],powers=[];
 function read(arg,lane){const m=arg.match(register);assert.ok(m,`unsupported executed operand ${arg}`);const swizzle=m[4]??'xyzw';const component='xyzw'.indexOf(swizzle[lane]??swizzle[0]);const value=file[m[2]][Number(m[3])]?.[component];assert.notEqual(value,undefined,`uninitialized ${arg} lane ${lane}`);return m[1]?((value^0x80000000)>>>0):value;}
 for(let pc=0;pc<code.length;pc++){
  const i=code[pc];histories.push(pc);if(i.op==='END')break;
  if(i.op==='UIF'){if(read(i.args[0],0)===0)pc=(flow.get(pc).else??flow.get(pc).end);continue;}
  if(i.op==='ELSE'){pc=flow.get(pc).end;continue;}
  if(i.op==='ENDIF')continue;
  if(i.op==='KILL')return {discard:true,history:histories,powers};
  const d=i.args[0].match(register);assert.ok(d);const mask=d[4]??'xyzw',results={};
  const op=i.op.replace('_PRECISE','');
  let power;
  if(op==='POW'){const base=f(read(i.args[1],0)),exponent=f(read(i.args[2],0));power=base<0?negativeResult:Math.pow(base,exponent);powers.push({pc,base,exponent,result:Math.fround(power)});}
  for(const ch of mask){const lane='xyzw'.indexOf(ch),a=()=>read(i.args[1],lane),b=()=>read(i.args[2],lane);let result;
   switch(op){
    case 'MOV':result=a();break;
    case 'MOV_SAT':result=w(Math.min(1,Math.max(0,f(a()))));break;
    case 'MUL':result=w(f(a())*f(b()));break;
    case 'ADD':result=w(f(a())+f(b()));break;
    case 'DIV':result=w(f(a())/f(b()));break;
    case 'MIN':result=w(Math.min(f(a()),f(b())));break;
    case 'MAX':result=w(Math.max(f(a()),f(b())));break;
    case 'POW':result=w(power);break;
    case 'RCP':result=w(1/f(read(i.args[1],0)));break;
    case 'FSLT':result=f(a())<f(b())?0xffffffff:0;break;
    case 'FSGE':result=f(a())>=f(b())?0xffffffff:0;break;
    case 'FSEQ':result=f(a())===f(b())?0xffffffff:0;break;
    case 'IMAX':result=signed(a())>=signed(b())?a():b();break;
    case 'ISLT':result=signed(a())<signed(b())?0xffffffff:0;break;
    case 'ISGE':result=signed(a())>=signed(b())?0xffffffff:0;break;
    case 'USEQ':result=a()===b()?0xffffffff:0;break;
    case 'USNE':result=a()!==b()?0xffffffff:0;break;
    case 'NOT':result=(~a())>>>0;break;
    case 'AND':result=(a()&b())>>>0;break;
    case 'OR':result=(a()|b())>>>0;break;
    case 'UCMP':result=read(i.args[read(i.args[1],lane)?2:3],lane);break;
    default:throw new Error(`Unexpected live opcode ${i.op} at ${pc}`);
   }
   results[lane]=result;
  }
  const target=file[d[2]][Number(d[3])]??=[];for(const [lane,result]of Object.entries(results))target[lane]=result;
 }
 return {discard:false,color:file.OUT[0].map(f),history:histories,powers};
}
const original=JSON.parse(fs.readFileSync(`${directory}/unpacked/hot/browser/report.json`)).acceptance;
const binary=fs.readFileSync(`${directory}/unpacked/hot/geometry.bin`);
let seed=0x5a17c9e3;const initialSeed=seed,next=()=>{seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return seed>>>0;};
const points=[];
for(const row of original.banks){
 const at=72+row.bank*656,bank={vertex:Array.from({length:16},(_,i)=>binary.readUInt32LE(at+i*4)),fragment:Array.from({length:148},(_,i)=>binary.readUInt32LE(at+64+i*4))};
 const axis=(lane,size)=>{const half=size/2,start=half*(f(bank.vertex[8+lane])+1),end=half*(f(bank.vertex[lane?5:0])+f(bank.vertex[8+lane])+1);return {start,end,center:f(bank.fragment[lane]),extent:f(bank.fragment[16+lane])};};
 const xs=axis(0,1024),ys=axis(1,768),primaryBytes=gunzipSync(Buffer.from(row.readbackGzipBase64,'base64'));
 assert.equal(sha(primaryBytes),row.readbackSha256);const primary=new Float32Array(primaryBytes.buffer.slice(primaryBytes.byteOffset,primaryBytes.byteOffset+primaryBytes.byteLength));
 const probes=new Map(row.probes.map(p=>{const b=gunzipSync(Buffer.from(p.readbackGzipBase64,'base64'));assert.equal(sha(b),p.readbackSha256);return [p.pc,new Float32Array(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength))];}));
 const corners=[[xs.start+.5,ys.start+.5],[xs.start+.5,ys.end-.5],[xs.end-.5,ys.start+.5],[xs.end-.5,ys.end-.5]];
 const candidates=corners.flatMap(([x,y])=>Array.from({length:16},(_,i)=>[Math.floor(x)+(i%4)*(x===xs.start+.5?1:-1),Math.floor(y)+Math.floor(i/4)*(y===ys.start+.5?1:-1)]));
 for(let n=0;n<512;n++)candidates.push([next()%1024,next()%768]);
 let checked=0,maskedCases=0,maxColorError=0,maxReferenceError=0,maxPowerInputError=0;
 const exercised=new Set();
 for(const [x,y] of candidates){if(x<0||y<0||x>=1024||y>=768||x+.5<xs.start||x+.5>xs.end||y+.5<ys.start||y+.5>ys.end)continue;
  const u=(x+.5-xs.start)/(xs.end-xs.start),v=(y+.5-ys.start)/(ys.end-ys.start),cx=xs.extent*u,cy=ys.extent*v;
  const predicted=execute(bank,u,v),expected=originalOracle(bank.fragment,cx,cy);
  assert.equal(predicted.discard,expected.discard,`discard at bank${row.bank} ${x},${y}`);
  const alt=execute(bank,u,v,1e25);assert.equal(predicted.discard,alt.discard);if(!predicted.discard)assert.deepEqual(predicted.color,alt.color,'negative power arbitrary result cannot survive the UCMP selection');
  for(const pc of predicted.history)exercised.add(pc);
  if(!predicted.discard){for(let lane=0;lane<4;lane++){
    const err=Math.abs(primary[(y*1024+x)*4+lane]-predicted.color[lane]),ref=Math.abs(expected.color[lane]-predicted.color[lane]);
    assert.ok(err<=0.0001,`independent TGSI output bank${row.bank} ${x},${y} lane${lane}: ${err}`);assert.ok(ref<=0.0001);maxColorError=Math.max(maxColorError,err);maxReferenceError=Math.max(maxReferenceError,ref);
  }}else for(let lane=0;lane<4;lane++)assert.equal(primary[(y*1024+x)*4+lane],-10000);
  for(const power of predicted.powers){const physical=probes.get(power.pc);assert.ok(physical,`live TGSI power${power.pc}`);const at=(y*1024+x)*4;
    const model=powerPrediction(bank.fragment,cx,cy,power.pc);assert.ok(model);assert.equal(model.masked,power.base<0);assert.equal(physical[at+3],power.base<0?2:1);assert.equal(physical[at+1],power.exponent);
    const error=Math.abs(physical[at]-power.base);assert.ok(error<=((power.pc<=107||power.pc>=535)?0.000001:0.001));maxPowerInputError=Math.max(maxPowerInputError,error);if(power.base<0)maskedCases++;
  }
  checked++;
 }
 points.push({bank:row.bank,checked,maskedCases,maxColorError,maxReferenceError,maxPowerInputError,exercisedPcs:[...exercised].sort((a,b)=>a-b)});
}
for(const pc of POWER_SITES)assert.ok(points.some(p=>p.exercisedPcs.includes(pc)),`independent original TGSI live power pc${pc}`);
const result={status:'passed',sourcePath,sourceSha256:sha(source),seed:initialSeed,interpreter:'Independent original-source TGSI binary32 execution; scalar powers replicate; UCMP uses raw uint truth; every source read precedes destination publication',uses,points};
fs.writeFileSync(`${directory}/tgsi-audit.json`,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({status:result.status,seed:initialSeed,uses,points:points.map(({exercisedPcs,...row})=>({...row,executedPcs:exercisedPcs.length}))},null,2));
