// Preparation only: run at the independently verified D62 head.
import {checker,makeRig,header,context,idCommand,submission} from '/renderer/virgl-command/tests/submit-acceptance.mjs';
import {createVirglStandardDimensionalShadowSubmitBridge} from '/renderer/virgl-command/control-bridge.mjs';
import {createVirglStandardDimensionalShadowTextureShaderBridge} from '/renderer/virgl-shader/standard.mjs';
import {packet} from '/tools/virgl-command/standard-image-fixtures.mjs';
const META=['id','target','format','bind','width','height','depth','arraySize','lastLevel','nrSamples','flags'];
const hex=bytes=>[...bytes].map(v=>v.toString(16).padStart(2,'0')).join('');
const copy=value=>JSON.parse(JSON.stringify(value,(_,v)=>ArrayBuffer.isView(v)?[...v]:typeof v==='bigint'?v.toString(16):v));
export async function run(WasmVirglSubmitProof){
 const c=checker(),gl=document.querySelector('#gpu').getContext('webgl2',{antialias:false,failIfMajorPerformanceCaveat:true});c.truth(gl,'actual hardware WebGL2');
 const nativeCalls=[],objects=new WeakMap();let next=1;
 const describe=v=>{if(v===null||typeof v!=='object')return v===undefined?{undefined:true}:v;if(ArrayBuffer.isView(v))return {type:v.constructor.name,bytes:hex(new Uint8Array(v.buffer,v.byteOffset,v.byteLength))};if(!objects.has(v))objects.set(v,next++);return {object:objects.get(v),type:v.constructor.name};};
 const recordedGl=new Proxy(gl,{get(target,key){const method=Reflect.get(target,key,target);if(typeof method!=='function')return method;return(...args)=>{const before=args.map(describe),result=method.apply(target,args);nativeCalls.push({sequence:nativeCalls.length,name:key,before,after:args.map(describe),result:describe(result)});return result;};}});
 const compiler=await createVirglStandardDimensionalShadowTextureShaderBridge(),Selected=class{constructor(callback){return WasmVirglSubmitProof.standardDimensionalDepth(callback);}};
 const meta=(target,format)=>({id:6,target,format,bind:format===67?10:9,width:4,height:4,depth:target===3?4:1,arraySize:target===4?6:target===7?5:1,lastLevel:2,nrSamples:0,flags:0});
 const cases=[...[3,4,7].map(target=>meta(target,67)),...[4,7].flatMap(target=>[16,18,20,21,126].map(format=>meta(target,format)))],rows=[];window.__surfaceReadiness={rows,nativeCalls};
 for(const metadata of cases){
  const name=`target${metadata.target}/format${metadata.format}`,rig=makeRig(Selected,createVirglStandardDimensionalShadowSubmitBridge,recordedGl,compiler,c,0,true,false,true),row={name,metadata,probes:[]};rows.push(row);
  window.__surfaceReadinessActive=()=>({name,native:copy(rig.q.vm.inspect()),host:copy(rig.host.bridge.inspect()),records:rig.q.records,events:rig.events});
  const allocate=m=>{const wire=header(0x204,0,72),dv=new DataView(wire.buffer);META.forEach((key,i)=>dv.setUint32(24+i*4,m[key],true));return wire;};
  try{
   await rig.expect(name+' original context',context(1));
   const allocation=allocate(metadata);row.allocationWire=hex(allocation);row.allocation=await rig.expect(name+' qualified native dimensional storage',allocation);await rig.expect(name+' membership',idCommand(0x202,1,6));
   for(const level of [0,1,2])for(const layer of metadata.target===3&&Math.max(1,metadata.depth>>level)===1?[0]:[0,1]){
    const wire=submission(1,packet(1,8,[70,6,metadata.format,level,layer|layer<<16]));
    const before={native:copy(rig.q.vm.inspect()),host:copy(rig.host.bridge.inspect()),objects:rig.trace.objects.size,nativeCalls:nativeCalls.length};
    const record=await rig.expect(name+` mip${level} layer${layer} surface refusal`,wire,0x1205);
    const after={native:copy(rig.q.vm.inspect()),host:copy(rig.host.bridge.inspect()),objects:rig.trace.objects.size,nativeCalls:nativeCalls.length};
    c.same(after.host.store,before.host.store,'refusal preserves ownership and budgets');c.equal(after.objects,before.objects,'refusal publishes no native object');
    c.truth(!nativeCalls.slice(before.nativeCalls).some(call=>call.name==='framebufferTextureLayer'||call.name==='framebufferTexture2D'&&call.before[2]>=gl.TEXTURE_CUBE_MAP_POSITIVE_X&&call.before[2]<=gl.TEXTURE_CUBE_MAP_NEGATIVE_Z),'refusal precedes dimensional attachment work');
    row.probes.push({level,layer,wire:hex(wire),record,before,after});
   }
   const control={id:1,target:2,format:metadata.format,bind:metadata.format===67?2:9,width:4,height:4,depth:1,arraySize:1,lastLevel:2,nrSamples:0,flags:0},wire=allocate(control);
   row.controlMetadata=control;row.controlAllocationWire=hex(wire);row.controlAllocation=await rig.expect(name+' 2D storage control',wire);await rig.expect(name+' 2D membership',idCommand(0x202,1,1));
   const surface=submission(1,packet(1,8,[70,1,metadata.format,1,0]));row.controlWire=hex(surface);row.control=await rig.expect(name+' original 2D mip surface control',surface);await rig.expect(name+' retire 2D surface',submission(1,packet(3,8,[70])));row.status='passed';
  }catch(error){row.status='failed';row.failure={message:error.message,stack:error.stack};throw error;}
  finally{row.hostBeforeDispose=copy(rig.host.bridge.inspect());row.nativeBeforeDispose=copy(rig.q.vm.inspect());row.records=copy(rig.q.records);row.events=copy(rig.events);row.guestTrace=rig.q.vm.commandTrace();row.machineDigest=rig.q.vm.machineDigest();rig.dispose();row.cleaned=rig.trace.snapshot();c.equal(rig.trace.objects.size,0,'all native owners retire');window.__surfaceReadinessActive=null;}
 }
 c.equal(gl.getError(),gl.NO_ERROR,'zero terminal hardware error');
 return {status:'passed',claim:'Qualified native dimensional storage admits; original single-layer dimensional surfaces refuse before dimensional attachment work; matching original 2D mip surfaces admit.',actualLinuxGuest:false,positiveCapsetAuthority:false,rows,nativeCalls,assertions:c.assertions,summary:{status:'passed',nativeStorageControls:rows.length,dimensionalSurfacesRefused:rows.reduce((n,r)=>n+r.probes.length,0),ordinary2DSurfaceControls:rows.length,nativeCalls:nativeCalls.length,assertions:c.assertions}};
}
