from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[2]).resolve()
head=sys.argv[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads((root/p).read_bytes())
def pr(p):
    return {k:p[k] for k in ['id','number','node_id','state','draft','merged_at','html_url']}|{
      'head':{k:p['head'][k] for k in ['ref','sha']},'base':{k:p['base'][k] for k in ['ref','sha']}}
before=read('prs-before-page1.json')+read('prs-before-page2.json')
after=read('prs-after-page1.json')+read('prs-after-page2.json')
assert len(before)==140 and len(after)==141
old={p['number']:pr(p) for p in before};new={p['number']:pr(p) for p in after}
assert len(old)==140 and len(new)==141
for number,p in old.items():assert new[number]==p,(number,p,new[number])
added=set(new)-set(old);assert len(added)==1;number=added.pop();added=new[number]
assert added['head']=={'ref':'codex/virgl-dimensional-shadow-samplers','sha':head}
assert added['base']=={'ref':'codex/virgl-dimensional-shadow-shaders','sha':'93021c5a28b99357532844de6ea4944291774099'}
assert all(p['state']=='open' and p['draft'] and p['merged_at'] is None for p in new.values())
stacks=[]
for n in [499,500]:
    name=f'stack{n}-';a=read(name+'before.json');b=read(name+'after.json')
    for k in ['id','number','node_id','url','base','open','created_at']:assert a[k]==b[k],(n,k)
    aa=[pr(p) for p in a['pull_requests']];bb=[pr(p) for p in b['pull_requests']]
    if n==499:assert aa==bb and len(bb)==50
    else:assert aa==bb[:-1] and bb[-1]==added and len(bb)==91
    stacks.append({'number':n,'id':a['id'],'previousPrCount':len(aa),'publishedPrCount':len(bb),
      'beforeSha256':sha(root/(name+'before.json')),'afterSha256':sha(root/(name+'after.json'))})
a=read('local-before.json');b=read('local-after.json');assert a['trunk']==b['trunk'] and a['currentBranch']==b['currentBranch']
assert len(a['branches'])==len(b['branches'])==91
for aa,bb in zip(a['branches'][:-1],b['branches'][:-1]):assert aa==bb,(aa['name'],aa,bb)
last=b['branches'][-1];assert last['name']=='codex/virgl-dimensional-shadow-samplers' and last['head']==head
assert last['pr']['number']==number and last['pr']['state']=='OPEN' and not last['isMerged'] and not last['isQueued'] and not last['needsRebase']
result={'schema':'d62-native-stack-append-only-continuity-v1','status':'passed','head':head,
 'existingPrCount':140,'existingPrIdentitiesOrderHeadsBasesStatesHeld':True,'stackIdentitiesHeld':True,
 'allOpenDraftUnmerged':True,'addition':added,'stacks':stacks,'checkerSha256':sha(Path(__file__))}
(root/'checker.py').write_bytes(Path(__file__).read_bytes())
(root/'continuity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'passed','existingPrCount':140,'stackIdentitiesHeld':True,'newPr':number,'allOpenDraftUnmerged':True}))
