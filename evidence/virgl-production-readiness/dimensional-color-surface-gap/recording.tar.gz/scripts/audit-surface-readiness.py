from pathlib import Path
import hashlib,json,struct,subprocess

repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
root=repo/'target/evidence/dimensional-surface-gap-2691b24e'
head='2691b24e6c00478f8d69f81180b6827761de246a'
sha=lambda b:hashlib.sha256(b).hexdigest()
report=json.loads((root/'report.json').read_bytes())
assert report['head']==head and report['status']=='passed'
assert report['actualLinuxGuest'] is False and report['positiveCapsetAuthority'] is False
assert report['browserErrors']==dict(console=[],page=[],requests=[])
assert report['browser']['headless'] is False and 'Metal' in json.dumps(report['browser']['gpu'])
assert report['browser']['gpu']['featureStatus'].get('webgl2',report['browser']['gpu']['featureStatus'].get('webgl'))=='enabled'
assert not any(x in json.dumps(report['browser']['commandLine']).lower() for x in ['swiftshader','llvmpipe','softpipe','lavapipe','--disable-gpu'])
held=json.loads((repo/'target/evidence/dimensional-shadow-samplers-cold-persistent/recording/hardware-27467/report.json').read_bytes())
generated={r['path']:r for r in held['sources']}
for pin in report['sources']:
    body=(root/'source'/pin['path']).read_bytes()
    assert len(body)==pin['bytes'] and sha(body)==pin['sha256']
    tracked=subprocess.run(['git','show',head+':'+pin['path']],cwd=repo,capture_output=True)
    if tracked.returncode==0:assert body==tracked.stdout,pin['path']
    elif pin['path'].startswith('web/pkg/'):
        committed='web/dist/pkg/'+pin['path'][len('web/pkg/'):]
        assert body==subprocess.check_output(['git','show',head+':'+committed],cwd=repo),pin['path']
    else:
        authority=generated[pin['path']]
        assert authority['bytes']==len(body) and authority['sha256']==sha(body),pin['path']
for pin in report['servedFiles']:
    body=(root/pin['bodyPath']).read_bytes()
    assert len(body)==pin['bytes'] and sha(body)==pin['sha256']
for key in ['browserCoverage','screenshot']:
    pin=report[key];assert sha((root/pin['path']).read_bytes())==pin['sha256']
assert sha((root/'readiness-body.mjs').read_bytes())==report['probe']['bodySha256']
assert sha((root/'readiness-runner.mjs').read_bytes())==report['probe']['runnerSha256']
result=report['browserResult']['result'];calls=result['nativeCalls'];rows=result['rows']
assert len(rows)==13 and len(calls)==13140
assert {(r['metadata']['target'],r['metadata']['format']) for r in rows}=={(t,67) for t in [3,4,7]}|{(t,f) for t in [4,7] for f in [16,18,20,21,126]}
keys=['id','target','format','bind','width','height','depth','arraySize','lastLevel','nrSamples','flags']
refusals=0;controls=0;citations=[]
for row in rows:
    meta=row['metadata'];wire=bytes.fromhex(row['allocationWire'])
    assert struct.unpack_from('<I',wire)[0]==0x204
    assert list(struct.unpack_from('<11I',wire,24))==[meta[k] for k in keys]
    assert struct.unpack_from('<I',bytes.fromhex(row['allocation']['response']))[0]==0x1100
    assert row['status']=='passed'
    expected={(level,layer) for level in [0,1,2] for layer in ([0] if meta['target']==3 and max(1,meta['depth']>>level)==1 else [0,1])}
    assert {(p['level'],p['layer']) for p in row['probes']}==expected
    for i,p in enumerate(row['probes']):
        raw=bytes.fromhex(p['wire']);assert struct.unpack_from('<I',raw)[0]==0x207
        assert struct.unpack_from('<6I',raw,32)==(0x00050801,70,6,meta['format'],p['level'],p['layer']|(p['layer']<<16))
        assert p['record']['request']==p['wire']
        assert struct.unpack_from('<I',bytes.fromhex(p['record']['response']))[0]==0x1205
        assert p['before']['host']['store']==p['after']['host']['store']
        assert p['before']['objects']==p['after']['objects']
        for call in calls[p['before']['nativeCalls']:p['after']['nativeCalls']]:
            assert call['name']!='framebufferTextureLayer'
            assert not(call['name']=='framebufferTexture2D' and 34069<=call['before'][2]<=34074)
        refusals+=1
        citations.append(dict(row=row['name'],probe=i,level=p['level'],layer=p['layer'],wireSha256=sha(raw),responseSha256=sha(bytes.fromhex(p['record']['response']))))
    raw=bytes.fromhex(row['controlWire'])
    assert struct.unpack_from('<6I',raw,32)==(0x00050801,70,1,meta['format'],1,0)
    assert struct.unpack_from('<I',bytes.fromhex(row['controlAllocation']['response']))[0]==0x1100
    assert struct.unpack_from('<I',bytes.fromhex(row['control']['response']))[0]==0x1100
    assert row['cleaned']['liveObjects']==row['cleaned']['liveSyncs']==0
    assert row['guestTrace'] and row['machineDigest'];controls+=1
assert refusals==77 and controls==13
audit=dict(schema='dimensional-surface-negative-wire-audit-v1',status='passed',head=head,reportSha256=sha((root/'report.json').read_bytes()),storageControls=len(rows),singleLayerSurfaceRefusals=refusals,ordinary2DMipSurfaceControls=controls,nativeCalls=len(calls),sourceBodies=len(report['sources']),servedBodies=len(report['servedFiles']),citations=citations,actualLinuxGuest=False,positiveCapsetAuthority=False)
(root/'original-wire-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({k:audit[k] for k in ['status','storageControls','singleLayerSurfaceRefusals','ordinary2DMipSurfaceControls','nativeCalls','sourceBodies','servedBodies']}))
