from pathlib import Path
import gzip,hashlib,io,json,tarfile,sys
repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
root=repo/'target/evidence/dimensional-surface-gap-2691b24e'
publication=repo/'target/evidence/dimensional-shadow-samplers-publication'
sha=lambda b:hashlib.sha256(b).hexdigest()
head='2691b24e6c00478f8d69f81180b6827761de246a'
r=json.loads((root/'report.json').read_bytes());a=json.loads((root/'original-wire-audit.json').read_bytes());c=json.loads((publication/'continuity.json').read_bytes())
assert r['head']==a['head']==c['head']==head and r['status']==a['status']==c['status']=='passed'
assert a['singleLayerSurfaceRefusals']==77 and a['ordinary2DMipSurfaceControls']==13
assert c['existingPrCount']==140 and c['stackIdentitiesHeld'] and c['existingPrIdentitiesOrderHeadsBasesStatesHeld']
assert c['allOpenDraftUnmerged'] and c['addition']['base']['sha']=='93021c5a28b99357532844de6ea4944291774099'
files={'probe/'+p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file()}
files.update({'publication/'+p.relative_to(publication).as_posix():p for p in publication.rglob('*') if p.is_file()})
for name in ['audit-surface-readiness.py','seal-surface-readiness.py']:
    files['scripts/'+name]=repo/'target/evidence/d62-continuation-tools'/name
out=repo/'evidence/virgl-production-readiness/dimensional-color-surface-gap';assert not out.exists();out.mkdir(parents=True)
rows=[];first={}
for name,file in sorted(files.items()):
    body=file.read_bytes();pin=len(body),sha(body);row=dict(path=name,bytes=pin[0],sha256=pin[1],kind='hardlink' if pin in first else 'file')
    if pin in first:row['target']=first[pin]
    else:first[pin]=name
    rows.append(row)
raw=(json.dumps(dict(schema='dimensional-color-surface-readiness-index-v1',head=head,records=rows),indent=2)+'\n').encode();(out/'records.json').write_bytes(raw)
archive=out/'recording.tar.gz'
with archive.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
    for row in rows:
        info=tarfile.TarInfo(row['path']);info.mode,info.mtime=0o644,0
        if row['kind']=='hardlink':info.type,info.linkname=tarfile.LNKTYPE,row['target'];tar.addfile(info)
        else:
            body=files[row['path']].read_bytes();assert len(body)==row['bytes'] and sha(body)==row['sha256'];info.size=len(body);tar.addfile(info,io.BytesIO(body))
count=0;seen={}
with gzip.open(archive,'rb') as decoded:
    with tarfile.open(fileobj=decoded,mode='r|') as tar:
        for member in tar:
            row=rows[count];count+=1;assert member.name==row['path']
            if member.islnk():assert member.linkname==row['target'] and member.linkname in seen;body=seen[member.linkname]
            else:assert member.isfile();body=tar.extractfile(member).read()
            assert len(body)==row['bytes'] and sha(body)==row['sha256'];seen[member.name]=body
    while decoded.read(1024*1024):pass
assert count==len(rows)
manifest=dict(schema='dimensional-color-surface-readiness-seal-v1',head=head,records=len(rows),uniqueBodies=len(first),backwardLinks=len(rows)-len(first),recordIndexSha256=sha(raw),archiveSha256=sha(archive.read_bytes()),archiveBytes=archive.stat().st_size,reopenedMembers=count,gzipEofChecked=True,originalSingleLayerRefusals=77,ordinary2DMipSurfaceControls=13,existingPrContinuityHeld=140,addition=c['addition']['number'],actualLinuxGuest=False,positiveCapsetAuthority=False)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(dict(manifestSha256=sha((out/'manifest.json').read_bytes()),**manifest)))
