from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path('/tmp/wasmvm-dimensional-shadow-consumer-gap-93021c5a')
publication=Path('/tmp/wasmvm-d61-stack-continuity')
out=Path('/tmp/wasmvm-d62-readiness-seal');out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
source_sets=[('readiness',root),('publication',publication)]
items=[]
for prefix,directory in source_sets:
    for p in sorted(directory.rglob('*')):
        if p.is_file():items.append((prefix+'/'+str(p.relative_to(directory)),p))
items.append(('seal.py',Path(__file__)))
pins=[];canonical={};stored=0;links=0
archive=out/'recording.tar.gz'
with archive.open('wb') as f,gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=9) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,p in items:
        body=p.read_bytes();key=(sha(body),len(body));info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0
        pin={'path':name,'bytes':len(body),'sha256':key[0]}
        if key in canonical:
            info.type=tarfile.LNKTYPE;info.linkname=canonical[key];tar.addfile(info);pin['link']=info.linkname;links+=1
        else:
            info.size=len(body);tar.addfile(info,io.BytesIO(body));canonical[key]=name;stored+=1
        pins.append(pin)
index={'schema':'complete-body-backward-link-index-v1','members':pins}
index_body=(json.dumps(index,indent=2)+'\n').encode();(out/'records.json').write_bytes(index_body)
expected={p['path']:p for p in pins};seen={};order=[]
with archive.open('rb') as f,gzip.GzipFile(fileobj=f,mode='rb') as gz:
    with tarfile.open(fileobj=gz,mode='r|') as tar:
        for member in tar:
            pin=expected[member.name];assert member.name not in seen
            if member.islnk():
                assert member.linkname in seen and pin['link']==member.linkname
                body_pin=seen[member.linkname];assert (pin['bytes'],pin['sha256'])==body_pin
            else:
                assert member.isfile() and member.size==pin['bytes'] and 'link' not in pin
                h=hashlib.sha256();n=0;stream=tar.extractfile(member)
                while chunk:=stream.read(1024*1024):h.update(chunk);n+=len(chunk)
                assert n==pin['bytes'] and h.hexdigest()==pin['sha256'];body_pin=(n,h.hexdigest())
            seen[member.name]=body_pin;order.append(member.name)
    while gz.read(1024*1024):pass
assert order==[p['path'] for p in pins]
audit=json.loads((root/'audit.json').read_bytes());continuity=json.loads((publication/'continuity.json').read_bytes());assert audit['status']==continuity['status']=='passed'
manifest={'schema':'d62-original-dimensional-comparison-consumer-readiness-seal-v1','status':'sealed-and-reopened',
 'head':audit['head'],'claim':'D61 original dimensional comparison compiler passes; existing D60 consumer refuses before native shader allocation. Ordinary controls and native depth views pass.',
 'negativeConsumerCases':40,'ordinaryControls':40,'nativeDepthViews':40,'actualLinuxGuest':False,'productionAuthority':False,
 'priorPr':'https://github.com/BLamy/wasm-vm/pull/539','appendOnlyContinuity':continuity,
 'd61Verifier':{'head':'93021c5a28b99357532844de6ea4944291774099','manifestSha256':'77ef1511cf4ff3a2aceccbdb89c99bce55a6ae89ade0af6cbb9c2ceeb6ec024a','indexSha256':'e58839a053fe147e81b1ded7efd30023f8dae1fd1bdd97e49ca85ca251df647e','archiveSha256':'3fd875a25de06b25221241934b515993e0f54dfe839a8ec1c66dbad22e88f3d6'},
 'logicalMembers':len(pins),'storedBodies':stored,'backwardLinks':links,'logicalBytes':sum(p['bytes'] for p in pins),
 'index':{'path':'records.json','bytes':len(index_body),'sha256':sha(index_body)},
 'archive':{'path':'recording.tar.gz','bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'allCompleteBodiesReopened':True,'gzipEofChecked':True}
manifest_body=(json.dumps(manifest,indent=2)+'\n').encode();(out/'manifest.json').write_bytes(manifest_body)
print(json.dumps({'members':len(pins),'storedBodies':stored,'backwardLinks':links,'archiveBytes':archive.stat().st_size,
 'manifestSha256':sha(manifest_body),'indexSha256':sha(index_body),'archiveSha256':manifest['archive']['sha256']}))
