from pathlib import Path
import hashlib,json,struct
root=Path('/tmp/wasmvm-dimensional-shadow-consumer-gap-93021c5a')
report_body=(root/'report.json').read_bytes();d=json.loads(report_body)
sha=lambda b:hashlib.sha256(b).hexdigest()
assert d['head']=='93021c5a28b99357532844de6ea4944291774099' and d['status']=='passed'
assert d['browserErrors']=={'console':[],'page':[],'requests':[]}
assert d['browser']['headless'] is False and d['browser']['gpu']['featureStatus'].get('webgl2',d['browser']['gpu']['featureStatus'].get('webgl'))=='enabled'
assert not any(any(t in a.lower() for t in ['swiftshader','llvmpipe','softpipe','lavapipe','--disable-gpu']) for a in d['browser']['commandLine'])
sources={}
for p in d['sources']:
    body=(root/'source'/p['path']).read_bytes();assert len(body)==p['bytes'] and sha(body)==p['sha256'];sources[p['path']]=p
for p in d['servedFiles']:
    if p['path'] in ['/', '/readiness.mjs']:
        body=(root/('readiness-page.html' if p['path']=='/' else 'readiness-body.mjs')).read_bytes();assert len(body)==p['bytes'] and sha(body)==p['sha256']
    else:
        source=sources[p['path'].lstrip('/')];assert p['bytes']==source['bytes'] and p['sha256']==source['sha256']
for pin in d['primary']['sources']:
    assert sources[pin['path']]['bytes']==pin['bytes'] and sources[pin['path']]['sha256']==pin['sha256']
result=d['browserResult']['result'];assert d['browserResult']['status']=='passed'
rows=result['rows'];assert len(rows)==40
assert {(r['stage'],r['target'],r['metadata']['format'],r['metadata']['bind']) for r in rows}=={
 (s,t,f,b) for s in ['vertex','fragment'] for t in ['CUBE','2D_ARRAY'] for f in [16,18,20,21,126] for b in [8,9]}
citations=[]
for i,r in enumerate(rows):
    raw=bytes.fromhex(r['shaderWire']);words=struct.unpack_from('<8I',raw);assert words[0]==0x207 and words[4]==1 and words[6]==len(raw)-32
    command=struct.unpack_from('<6I',raw,32);assert command[0]&0xff==1 and command[0]>>8&0xff==4 and command[1]==10 and command[2]==int(r['stage']=='fragment')
    text_bytes=raw[56:56+command[3]];assert text_bytes[-1]==0 and text_bytes[:-1].decode('ascii')==r['shaderText']
    assert 'DCL SVIEW[7], SHADOW'+r['target']+', FLOAT\n' in r['shaderText'] and 'SAMP[7], SHADOW'+r['target'] in r['shaderText']
    calls=r['compilerCalls'];assert len(calls)==2
    first=calls[0];assert first['factory']=='D61-comparison' and first['result']['ok'] is True
    metadata=first['result']['metadata'];assert metadata['profile']=='virgl-webgl2-standard-dimensional-shadow-texture-gles3-v1'
    assert metadata['samplers']==[{'index':7,'name':('vs' if r['stage']=='vertex' else 'fs')+'samp7','type':'sampler'+('Cube' if r['target']=='CUBE' else '2DArray')+'Shadow'}]
    assert calls[1]['factory']=='D57-ordinary' and calls[1]['result']['ok'] is True
    assert calls[1]['result']['metadata']['profile']=='virgl-webgl2-standard-dimensional-texture-gles3-v1'
    for name,code in [('allocation',0x1100),('view',0x1100),('record',0x1205),('control',0x1100)]:
        body=bytes.fromhex(r[name]['response']);assert len(body)==24 and struct.unpack_from('<I',body)[0]==code
    assert r['before']['host']['store']==r['after']['host']['store'] and r['before']['objects']==r['after']['objects']
    before=r['before']['host']['renderer']['work'];after=r['after']['host']['renderer']['work']
    assert after['shaderCompiles']==before['shaderCompiles']==0 and after['drawCalls']==before['drawCalls']==0 and after['translations']==before['translations']+1
    start,end=r['before']['nativeCalls'],r['after']['nativeCalls']
    assert not any(v['name'].startswith('create') or v['name'] in ['compileShader','linkProgram','drawArrays','drawElements'] for v in result['nativeCalls'][start:end])
    assert r['status']=='passed' and r['cleaned']['liveObjects']==r['cleaned']['liveSyncs']==0
    assert len(r['records'])==len(r['guestTrace']['records'])==7 and len(r['machineDigest'])==64
    citations.append({'row':i,'name':r['name'],'originalShaderWireSha256':sha(raw),'compilerSampler':metadata['samplers'][0],
      'refusal':r['record']['response'],'nativeRange':[start,end],'guestTraceSha256':sha(json.dumps(r['guestTrace'],sort_keys=True,separators=(',',':')).encode()),'machineDigest':r['machineDigest']})
out={'schema':'d62-original-consumer-gap-audit-v1','status':'passed','head':d['head'],'reportSha256':sha(report_body),
 'completeSources':len(sources),'completeServedBodies':len(d['servedFiles']),'primaryBodies':len(d['primary']['sources']),
 'originalComparisonRefusals':40,'ordinaryControls':40,'depthViews':40,'allBeforeNativeShaderAllocation':True,'allOwnersRetired':True,'citations':citations}
(root/'audit.json').write_text(json.dumps(out,indent=2)+'\n');(root/'audit.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({k:v for k,v in out.items() if k!='citations'}))
