import {checker,makeRig,header,context,idCommand,submission} from '/renderer/virgl-command/tests/submit-acceptance.mjs';
import {createVirglStandardDimensionalDepthViewSubmitBridge} from '/renderer/virgl-command/control-bridge.mjs';
import {createVirglStandardDimensionalTextureShaderBridge,createVirglStandardDimensionalShadowTextureShaderBridge} from '/renderer/virgl-shader/standard.mjs';
import {comparisonText} from '/tools/virgl-dimensional-shadow-shaders/fixtures.mjs';
import {packet,join,shader,sampler} from '/tools/virgl-command/standard-image-fixtures.mjs';
const copy=value=>JSON.parse(JSON.stringify(value,(_,v)=>ArrayBuffer.isView(v)?[...v]:typeof v==='bigint'?v.toString(16):v));
const META=['id','target','format','bind','width','height','depth','arraySize','lastLevel','nrSamples','flags'];
const hex=bytes=>[...bytes].map(v=>v.toString(16).padStart(2,'0')).join('');
export async function run(WasmVirglSubmitProof){
 const c=checker(),gl=document.querySelector('#gpu').getContext('webgl2',{antialias:false,failIfMajorPerformanceCaveat:true});c.truth(gl,'actual hardware WebGL2');
 const nativeCalls=[],objects=new WeakMap();let next=1;
 const describe=value=>{if(value===null||typeof value!=='object')return value===undefined?{undefined:true}:value;if(ArrayBuffer.isView(value))return {type:value.constructor.name,bytes:hex(new Uint8Array(value.buffer,value.byteOffset,value.byteLength))};if(!objects.has(value))objects.set(value,next++);return {object:objects.get(value),type:value.constructor.name};};
 const recordedGl=new Proxy(gl,{get(target,key){const method=Reflect.get(target,key,target);if(typeof method!=='function')return method;return(...args)=>{const before=args.map(describe),result=method.apply(target,args);nativeCalls.push({sequence:nativeCalls.length,name:key,before,after:args.map(describe),result:describe(result)});return result;};}});
 const held=await createVirglStandardDimensionalTextureShaderBridge(),comparison=await createVirglStandardDimensionalShadowTextureShaderBridge();
 const Selected=class{constructor(callback){return WasmVirglSubmitProof.standardDimensionalDepth(callback);}};
 const rows=[],limits={cube:gl.getParameter(gl.MAX_CUBE_MAP_TEXTURE_SIZE),arrayLayers:gl.getParameter(gl.MAX_ARRAY_TEXTURE_LAYERS)};
 window.__depthReadiness={rows,nativeCalls,limits};
 for(const stage of ['vertex','fragment'])for(const target of ['CUBE','2D_ARRAY'])for(const format of [16,18,20,21,126])for(const bind of [8,9]){
  const name=`${stage}/${target}/format${format}/bind${bind}`,metadata={id:6,target:target==='CUBE'?4:7,format,bind,width:4,height:4,depth:1,arraySize:target==='CUBE'?6:5,lastLevel:2,nrSamples:0,flags:0};
  let current=comparison;const compilerCalls=[];
  const compiler=new Proxy({}, {get(_,key){const method=current[key];if(typeof method!=='function')return method;return request=>{const result=method.call(current,request);compilerCalls.push({factory:current===comparison?'D61-comparison':'D57-ordinary',method:key,request:copy(request),result:copy(result)});return result;};}});
  const rig=makeRig(Selected,createVirglStandardDimensionalDepthViewSubmitBridge,recordedGl,compiler,c,0,true,false,true),row={name,stage,target,metadata,compilerCalls};rows.push(row);
  window.__depthReadinessActive=()=>({name,native:copy(rig.q.vm.inspect()),host:copy(rig.host.bridge.inspect()),records:rig.q.records,events:rig.events});
  try{
   await rig.expect(name+' context',context(1));
   const raw=header(0x204,0,72),dv=new DataView(raw.buffer);META.forEach((key,j)=>dv.setUint32(24+j*4,metadata[key],true));
   row.allocationWire=hex(raw);row.allocation=await rig.expect(name+' qualified native depth allocation',raw);
   await rig.expect(name+' original resource membership',idCommand(0x202,1,6));
   const originalView=join(sampler(50,{mip:0,min:0,mag:0}),packet(1,6,[51,6,format|metadata.target<<24,(metadata.arraySize-1)<<16,2<<8,0x688]),packet(10,0,[stage==='vertex'?0:1,7,51]),packet(18,0,[stage==='vertex'?0:1,7,50]));
   row.viewWire=hex(originalView);row.view=await rig.expect(name+' retained original dimensional depth view',submission(1,originalView));
   const before={native:copy(rig.q.vm.inspect()),host:copy(rig.host.bridge.inspect()),objects:rig.trace.objects.size,nativeCalls:nativeCalls.length};
   const text=comparisonText(stage,{target,opcode:'TEX',slot:7,explicit:true}),request=submission(1,shader(10,stage==='vertex'?0:1,text));
   row.shaderText=text;row.shaderWire=hex(request);row.record=await rig.expect(name+' original comparison shader refused',request,0x1205);
   const after={native:copy(rig.q.vm.inspect()),host:copy(rig.host.bridge.inspect()),objects:rig.trace.objects.size,nativeCalls:nativeCalls.length};
   c.truth(compilerCalls.at(-1).result.ok,'D61 compiler admitted original comparison shader');
   c.equal(compilerCalls.at(-1).result.metadata.profile,'virgl-webgl2-standard-dimensional-shadow-texture-gles3-v1','actual separately selected compiler profile');
   c.same(after.host.store,before.host.store,'refused comparison shader preserves native depth ownership and budgets');
   c.equal(after.objects,before.objects,'refused comparison shader publishes no native object');
   c.equal(after.host.renderer.work.shaderCompiles,before.host.renderer.work.shaderCompiles,'profile refusal precedes native compilation');
   row.before=before;row.after=after;
   current=held;const ordinary=comparisonText(stage,{target,opcode:'TEX',slot:7,ordinary:true,explicit:false});
   row.controlText=ordinary;row.controlWire=hex(submission(1,shader(10,stage==='vertex'?0:1,ordinary)));
   row.control=await rig.expect(name+' unchanged ordinary dimensional shader control',submission(1,shader(10,stage==='vertex'?0:1,ordinary)));
   c.truth(compilerCalls.at(-1).result.ok,'qualified ordinary compiler control');
   await rig.expect(name+' retire admitted shader and original view/state',submission(1,join(packet(3,4,[10]),packet(3,6,[51]),packet(3,7,[50]))));
   row.status='passed';
  }catch(error){row.status='failed';row.failure={message:error.message,stack:error.stack};throw error;}
  finally{
   row.hostBeforeDispose=copy(rig.host.bridge.inspect());row.nativeBeforeDispose=copy(rig.q.vm.inspect());row.records=copy(rig.q.records);row.events=copy(rig.events);row.guestTrace=rig.q.vm.commandTrace();row.machineDigest=rig.q.vm.machineDigest();rig.dispose();
   row.cleaned=rig.trace.snapshot();c.equal(rig.trace.objects.size,0,'all original native owners retire');window.__depthReadinessActive=null;
  }
 }
 c.equal(gl.getError(),gl.NO_ERROR,'zero terminal hardware error');
 return {status:'passed',claim:'Original dimensional comparison shaders compile, but the retained D60 consumer refuses their profile before native shader allocation. Matching ordinary shaders and native depth views pass.',actualLinuxGuest:false,positiveCapsetAuthority:false,nativeGpuExecution:true,rows,nativeCalls,limits,assertions:c.assertions,
  summary:{status:'passed',comparisonShadersRefused:rows.length,ordinaryControlsAdmitted:rows.length,nativeDepthViewsAdmitted:rows.length,nativeCalls:nativeCalls.length,assertions:c.assertions}};
}
