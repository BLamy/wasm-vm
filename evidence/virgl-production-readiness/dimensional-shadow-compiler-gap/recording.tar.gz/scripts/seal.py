"""Seal original shadow-dimension refusals and append-only D60 publication."""
from pathlib import Path
import gzip, hashlib, io, json, subprocess, sys, tarfile

repo = Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
raw, output = map(Path, sys.argv[1:])
stack = Path('/tmp/wasmvm-d60-stack-continuity')
sha = lambda body: hashlib.sha256(body).hexdigest()
report = json.loads((raw / 'report.json').read_bytes())
continuity = json.loads((stack / 'continuity.json').read_bytes())
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert report['status'] == continuity['status'] == 'passed'
assert report['head'] == continuity['head'] == head
assert report['refused'] == 16 and report['controls'] == 6
assert report['actualLinuxGuest'] is False and report['productionAuthority'] is False
assert continuity['existingPrCount'] == 138
assert continuity['existingPrIdentitiesOrderHeadsBasesStatesHeld'] is True
published = json.loads((stack / 'pull538-described.json').read_bytes())
assert published['number'] == continuity['addition']['number'] == 538
assert published['head']['sha'] == head
assert published['base']['ref'] == 'codex/virgl-dimensional-depth-transfers'
assert published['state'] == 'open' and published['draft'] is True and published['merged'] is False
assert published['title'] == 'Execute original cube and array depth sampler views'
assert published['body'] == Path('/tmp/wasmvm-d60-pr-body-draft.md').read_text()
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=repo)
assert not output.exists()
files = {'admission/' + p.relative_to(raw).as_posix(): p for p in raw.rglob('*') if p.is_file()}
files.update({'publication/' + p.relative_to(stack).as_posix(): p for p in stack.rglob('*') if p.is_file()})
files['scripts/seal.py'] = Path(__file__)
files['scripts/stack.py'] = Path('/tmp/wasmvm-check-d60-stack-continuity.py')
files['publication/description.md'] = Path('/tmp/wasmvm-d60-pr-body-draft.md')
files['cleanup/clone-custody.json'] = Path('/tmp/wasmvm-d60-clone-cleanup-custody.json')
files['cleanup/clone-script.py'] = Path('/tmp/wasmvm-clean-owned-d60-cold.py')
files['cleanup/verifier-release.json'] = Path('/tmp/wasmvm-d60-verifier-release.json')
files['cleanup/incremental-cache.json'] = Path('/tmp/wasmvm-d60-incremental-cache-relief.json')
files['cleanup/staging-deduplication.json'] = Path('/tmp/wasmvm-d60-unpublished-staging-deduplication.json')
for family in ('worker', 'verifier', 'deployment'):
    for name in ('manifest.json', 'records.json'):
        files[f'dependencies/{family}/{name}'] = repo / 'evidence/virgl-dimensional-depth-views' / family / name
for pin in report['sources']:
    body = (raw / 'sources' / pin['path']).read_bytes()
    assert len(body) == pin['bytes'] and sha(body) == pin['sha256']
rows = [dict(path=name, bytes=p.stat().st_size, sha256=sha(p.read_bytes())) for name, p in sorted(files.items())]
output.mkdir(parents=True)
index = (json.dumps(dict(schema='dimensional-shadow-readiness-index-v1', head=head, records=rows), indent=2) + '\n').encode()
(output / 'records.json').write_bytes(index)
archive = output / 'recording.tar.gz'
with archive.open('wb') as stream, gzip.GzipFile(fileobj=stream, mode='wb', mtime=0, filename='') as zipped, tarfile.open(fileobj=zipped, mode='w') as tar:
    for row in rows:
        body = files[row['path']].read_bytes()
        assert len(body) == row['bytes'] and sha(body) == row['sha256']
        entry = tarfile.TarInfo(row['path'])
        entry.size, entry.mode, entry.mtime = len(body), 0o644, 0
        tar.addfile(entry, io.BytesIO(body))
with tarfile.open(archive, 'r:gz') as tar:
    assert tar.getnames() == [row['path'] for row in rows]
    for row in rows:
        body = tar.extractfile(row['path']).read()
        assert len(body) == row['bytes'] and sha(body) == row['sha256']
manifest = dict(schema='dimensional-shadow-readiness-seal-v1', head=head, records=len(rows), reopenedMembers=len(rows), recordIndexSha256=sha(index), archiveSha256=sha(archive.read_bytes()), archiveBytes=archive.stat().st_size, refused=16, controls=6, actualLinuxGuest=False, productionAuthority=False, originalStackPrsUnchanged=138, newPr=continuity['addition']['number'])
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(manifest=manifest, manifestSha256=sha((output / 'manifest.json').read_bytes()))))
