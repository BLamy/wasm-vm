from pathlib import Path
import hashlib, json, shutil, subprocess

repo = Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
clone = Path('/private/var/folders/nr/cyvk1qc14jj5c081vj1xts000000gn/T/wasm-vm-dimensional-depth-views-cold-vfzeh3m8/repo')
directory = Path('/tmp/wasmvm-dimensional-depth-views-cold-configuration-final')
release = json.loads(Path('/tmp/wasmvm-d60-verifier-release.json').read_bytes())
assert release['verdict'] == 'verified' and all(release[k] for k in ('gpuLeaseReleased','nativeBuildLeaseReleased','gitLeaseReleased'))
assert 'status: verified' in (repo/'tasks/epic-6-transcendence/E6-T11d60-dimensional-depth-sampler-views.md').read_text().split('## Boundary')[0]
report_raw = (directory/'report.json').read_bytes()
report = json.loads(report_raw)
assert Path(report['clone']).resolve() == clone and clone.parent.name == 'wasm-vm-dimensional-depth-views-cold-vfzeh3m8'
assert not clone.is_symlink() and not clone.parent.is_symlink()
assert report['exitCode'] == 0 and report['cleanBefore'] == report['cleanAfter'] == ''
assert report['head'] == '9698c0a91086cd419087154875d7200efcfded69'
assert hashlib.sha256((directory/'recording/receipt.json').read_bytes()).hexdigest() == report['receiptSha256'] == 'af7182fa12ca6e359a770f329368ef4545b7105141eb9141e3575510f1cd3254'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip() == report['head']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=clone)
cache = {}
def digest(p):
    st=p.stat(); key=(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)
    if key not in cache:
        h=hashlib.sha256()
        with p.open('rb') as stream:
            for body in iter(lambda:stream.read(1024*1024),b''): h.update(body)
        cache[key]=h.hexdigest()
    return cache[key]
preserved=[]; known=set()
for source_directory in sorted(Path('/tmp').glob('wasmvm-dimensional-depth-views-cold-*')):
    source_report=source_directory/'report.json'
    if not source_report.is_file(): continue
    r=json.loads(source_report.read_bytes())
    if Path(r.get('clone','/')).resolve()!=clone: continue
    proof=Path(r['evidenceOutput']).resolve()
    assert proof.parent==clone/'target/evidence'
    if not proof.exists(): continue
    count=0
    for source in proof.rglob('*'):
        if source.is_file():
            retained=source_directory/'recording'/source.relative_to(proof)
            assert retained.is_file() and source.stat().st_size==retained.stat().st_size
            assert digest(source)==digest(retained),str(source)
            count+=1
    known.add(proof)
    preserved.append(dict(head=r['head'],bodies=count,recording=str(source_directory/'recording')))
assert known == {p.resolve() for p in (clone/'target/evidence').iterdir()}
owned_kib=int(subprocess.check_output(['du','-sk',str(clone.parent)],text=True).split()[0])
receipt=dict(schema='owned-d60-cold-cleanup-v1',clone=str(clone),head=report['head'],reportSha256=hashlib.sha256(report_raw).hexdigest(),receiptSha256=report['receiptSha256'],freshVerifierCommit=release['commit'],allExistingRawProofBodiesPreserved=True,preserved=preserved,uniqueCompleteBodiesHashed=len(cache),ownedKiB=owned_kib,freeBefore=shutil.disk_usage(repo).free)
out=Path('/tmp/wasmvm-d60-clone-cleanup-custody.json');assert not out.exists()
out.write_text(json.dumps(receipt,indent=2)+'\n')
shutil.rmtree(clone.parent)
receipt['freeAfter']=shutil.disk_usage(repo).free
out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
