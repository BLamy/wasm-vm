import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const repo='/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm', [head,out]=process.argv.slice(2), sha=b=>createHash('sha256').update(b).digest('hex');
assert.equal(process.argv.length,4);assert.equal(execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim(),head);
assert.equal(execFileSync('git',['status','--porcelain','--untracked-files=no'],{cwd:repo,encoding:'utf8'}),'');
assert.equal(await fs.stat(out).then(()=>true,()=>false),false);await fs.mkdir(out,{recursive:true});
const files=['renderer/virgl-shader/standard.mjs','renderer/virgl-shader/standard_guard.h','renderer/virgl-shader/standard_guard.c','renderer/virgl-shader/standard_emit.c','renderer/virgl-shader/bridge.c','renderer/virgl-shader/vendor/src/gallium/include/pipe/p_shader_tokens.h','renderer/virgl-shader/build/wasm/virgl-shader.mjs','renderer/virgl-shader/build/wasm/virgl-shader.wasm'];
const sources=[];for(const name of files){const raw=await fs.readFile(path.join(repo,name));const dest=path.join(out,'sources',name);await fs.mkdir(path.dirname(dest),{recursive:true});await fs.writeFile(dest,raw);sources.push({path:name,bytes:raw.length,sha256:sha(raw)});}
assert.equal(sources.find(x=>x.path.endsWith('build/wasm/virgl-shader.mjs')).sha256,'4ade0ffb9ffb661a729179525e7937c4695230dc57a7f79db63a1538119a95f2');
assert.equal(sources.find(x=>x.path.endsWith('build/wasm/virgl-shader.wasm')).sha256,'8749da215131646f0b7d53d59fe7ee19fa68b2fab2e9bec80446c4af3e84e100');
const {createVirglStandardDimensionalTextureShaderBridge}=await import(pathToFileURL(path.join(repo,'renderer/virgl-shader/standard.mjs'))), bridge=await createVirglStandardDimensionalTextureShaderBridge();
const records=[];
for(const stage of ['vertex','fragment'])for(const base of ['CUBE','2D_ARRAY'])for(const declarationShadow of [false,true])for(const opcode of ['TEX','TXQ']){
 const target='SHADOW'+base,declaration=declarationShadow?target:base;
 const declarations=stage==='vertex'?'VERT\nDCL IN[0]\nDCL IN[1]\nDCL OUT[0], POSITION\nDCL OUT[1], GENERIC[0]\n':'FRAG\nDCL IN[1], GENERIC[0], CONSTANT\nDCL OUT[0], COLOR\n';
 const first=stage==='vertex'?['MOV OUT[0], IN[0]']:[], dst=stage==='vertex'?'OUT[1]':'OUT[0]';
 const text=declarations+'DCL SAMP[7]\nDCL SVIEW[7], '+declaration+', FLOAT\n'+[...first,opcode+' '+dst+', IN[1], SAMP[7], '+target,'END'].map((s,i)=>i+': '+s+'\n').join('');
 const result=bridge.translate({stage,text});assert.equal(result.ok,false);assert.equal(result.error.code,'unsupported-feature');records.push({stage,target,declaration,opcode,prediction:'unsupported-feature',text,result});
}
for(const stage of ['vertex','fragment'])for(const target of ['CUBE','2D_ARRAY','SHADOW2D']){
 const declarations=stage==='vertex'?'VERT\nDCL IN[0]\nDCL IN[1]\nDCL OUT[0], POSITION\nDCL OUT[1], GENERIC[0]\n':'FRAG\nDCL IN[1], GENERIC[0], CONSTANT\nDCL OUT[0], COLOR\n';
 const first=stage==='vertex'?['MOV OUT[0], IN[0]']:[], dst=stage==='vertex'?'OUT[1]':'OUT[0]';
 const text=declarations+'DCL SAMP[7]\nDCL SVIEW[7], '+(target==='SHADOW2D'?'2D':target)+', FLOAT\n'+[...first,'TEX '+dst+', IN[1], SAMP[7], '+target,'END'].map((s,i)=>i+': '+s+'\n').join('');
 const result=bridge.translate({stage,text});assert.equal(result.ok,true);const expectedType={CUBE:'samplerCube','2D_ARRAY':'sampler2DArray',SHADOW2D:'sampler2DShadow'}[target];assert.equal(result.metadata.samplers[0].type,expectedType);records.push({stage,target,prediction:expectedType,text,result});
}
const recordBytes=Buffer.from(JSON.stringify({records},null,2)+'\n');await fs.writeFile(path.join(out,'records.json'),recordBytes);
await fs.copyFile(import.meta.filename,path.join(out,'runner.mjs'));
const report={schema:'dimensional-shadow-readiness-v1',head,status:'passed',actualLinuxGuest:false,productionAuthority:false,compilerAuthority:'unchanged verified D57',refused:16,controls:6,sources,recordsSha256:sha(recordBytes),command:[process.execPath,...process.argv.slice(1)]};await fs.writeFile(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({head,status:report.status,refused:report.refused,controls:report.controls}));
