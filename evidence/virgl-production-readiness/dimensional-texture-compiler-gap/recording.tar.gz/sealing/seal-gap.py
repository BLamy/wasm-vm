import gzip,hashlib,io,json,tarfile
from pathlib import Path
root=Path('/tmp/wasmvm-dimensional-texture-gap-48b2ba0c')
out=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm/evidence/virgl-production-readiness/dimensional-texture-compiler-gap')
sha=lambda b:hashlib.sha256(b).hexdigest()
report=json.loads((root/'readiness.json').read_bytes());assert report['status']=='passed'
assert report['head']=='48b2ba0c7ee90d13093f7782e5a2502e44095753'
assert len(report['observations'])==114
assert json.loads((root/'stack-continuity.json').read_bytes())['existingPRsUnchanged']==134
assert sha((root/'source/renderer/virgl-shader/build/wasm/virgl-shader.mjs').read_bytes())=='4da9f1ed30cff697193e0688a26ee93e48a3e1216485d5184301fec6c31d4879'
assert sha((root/'source/renderer/virgl-shader/build/wasm/virgl-shader.wasm').read_bytes())=='aba0c891ad406ef876da6f1a86883b3fcdd98de12c1137a4f2feff566f5459f2'
out.mkdir(parents=True,exist_ok=False)
files={str(p.relative_to(root)):p.read_bytes() for p in root.rglob('*') if p.is_file()}
files['sealing/seal-gap.py']=Path(__file__).read_bytes()
rows=[{'path':name,'bytes':len(body),'sha256':sha(body)} for name,body in sorted(files.items())]
index=(json.dumps({'schema':'dimensional-shader-readiness-index-v1','head':report['head'],'records':rows},indent=2)+'\n').encode();(out/'records.json').write_bytes(index)
with (out/'recording.tar.gz').open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as zipped,tarfile.open(fileobj=zipped,mode='w') as packed:
 for row in rows:
  body=files[row['path']];info=tarfile.TarInfo(row['path']);info.size,info.mode,info.mtime=len(body),0o644,0;packed.addfile(info,io.BytesIO(body))
with tarfile.open(out/'recording.tar.gz','r:gz') as packed:
 assert packed.getnames()==[r['path'] for r in rows]
 for row in rows:
  body=packed.extractfile(row['path']).read();assert len(body)==row['bytes'] and sha(body)==row['sha256']
manifest={'schema':'dimensional-shader-readiness-seal-v1','head':report['head'],'records':len(rows),'reopenedMembers':len(rows),'recordIndexSha256':sha(index),'archiveSha256':sha((out/'recording.tar.gz').read_bytes()),'archiveBytes':(out/'recording.tar.gz').stat().st_size,'reportSha256':sha((root/'readiness.json').read_bytes()),'existingPRsUnchanged':134,'productionAuthority':False,'runtimeChanges':False}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest));print('manifestSha256='+sha((out/'manifest.json').read_bytes()))
