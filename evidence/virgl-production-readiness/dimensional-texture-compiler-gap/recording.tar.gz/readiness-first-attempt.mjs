import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const root='/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm',output='/tmp/wasmvm-dimensional-texture-gap-48b2ba0c';
const hash=b=>createHash('sha256').update(b).digest('hex');
const {shadowText}=await import(pathToFileURL(root+'/tools/virgl-shadow-shaders/fixtures.mjs'));
const factories=await import(pathToFileURL(root+'/renderer/virgl-shader/standard.mjs'));
const head=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
assert.equal(head,'48b2ba0c7ee90d13093f7782e5a2502e44095753');
assert.equal(execFileSync('git',['status','--porcelain','--untracked-files=no'],{cwd:root,encoding:'utf8'}).trim(),'');
const sources=[];for(const file of ['renderer/virgl-shader/standard.mjs','renderer/virgl-shader/standard_guard.c','renderer/virgl-shader/standard_guard.h','renderer/virgl-shader/standard_emit.c','renderer/virgl-shader/bridge.c','renderer/virgl-shader/bridge.h','renderer/virgl-shader/build/wasm/virgl-shader.mjs','renderer/virgl-shader/build/wasm/virgl-shader.wasm']){
 const bytes=await fs.readFile(root+'/'+file),destination=output+'/source/'+file;await fs.mkdir(path.dirname(destination),{recursive:true});await fs.writeFile(destination,bytes);sources.push({path:file,bytes:bytes.length,sha256:hash(bytes)});
}
const observations=[];
for(const factory of ['createVirglStandardShaderBridge','createVirglStandardUniformShaderBridge','createVirglStandardTextureShaderBridge','createVirglStandardIntegerImageShaderBridge','createVirglStandardInstanceBaseShaderBridge','createVirglStandardShadowTextureShaderBridge']){
 const bridge=await factories[factory]();
 for(const target of ['3D','CUBE','2D_ARRAY'])for(const stage of ['vertex','fragment'])for(const opcode of ['TEX','TXL','TXQ']){
  const request={stage,text:shadowText(stage,{opcode,declaration:target,target,type:'FLOAT'})},result=bridge.translate(request);
  assert.equal(result.ok,false,factory+'/'+target+'/'+stage+'/'+opcode);assert.equal(result.error.code,'unsupported-profile');
  observations.push({factory,target,stage,opcode,request,result});
 }
 const request={stage:'fragment',text:shadowText('fragment',{opcode:'TEX',declaration:'2D',target:'2D',type:'FLOAT'})},result=bridge.translate(request);assert.equal(result.ok,true);observations.push({factory,positive2D:true,request,result});
}
await fs.copyFile('/tmp/wasmvm-dimensional-texture-readiness.mjs',output+'/readiness-runner.mjs');
await fs.writeFile(output+'/readiness.json',JSON.stringify({status:'passed',head,liveGuest3d:false,claim:'Original dimensional shader text is refused by every historical selected facet; ordinary 2D remains admitted.',sources,observations},null,2)+'\n');
console.log(JSON.stringify({status:'passed',head,refusals:observations.filter(o=>!o.positive2D).length,positive2D:6,sources:sources.length}));
