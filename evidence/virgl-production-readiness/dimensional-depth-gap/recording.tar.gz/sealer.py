from pathlib import Path
import gzip,hashlib,io,json,tarfile
repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
destination=repo/'evidence/virgl-production-readiness/dimensional-depth-gap'
assert not destination.exists()
head='fa4692ab33c0bd91e4d2cedddc8003df29354108'
sources={}
for label,root in [('layout',Path('/tmp/wasmvm-dimensional-depth-layout-gap-fa4692ab')),('native',Path('/tmp/wasmvm-dimensional-depth-native-gap-fa4692ab-final')),('harness-precheck',Path('/tmp/wasmvm-dimensional-depth-native-gap-fa4692ab'))]:
 report=json.loads((root/'report.json').read_bytes());assert report['head']==head
 if label!='harness-precheck':assert report['status']=='passed'
 for source in sorted(root.rglob('*')):
  if source.is_file():sources[label+'/'+source.relative_to(root).as_posix()]=source.read_bytes()
stack=Path('/tmp/wasmvm-d58-stack-continuity')
continuity=json.loads((stack/'continuity.json').read_bytes())
assert continuity['head']==head and continuity['existingPrCount']==136 and continuity['allOpenDraftUnmerged'] and continuity['addition']['number']==536
for name in ['stack499-before.json','stack499-after.json','stack500-before.json','stack500-after.json','continuity.json','attachment.json','submit.log','local-before-submit.json']:
 sources['publication/'+name]=(stack/name).read_bytes()
sources['publication/continuity-checker.py']=Path('/tmp/wasmvm-check-d58-stack-continuity.py').read_bytes()
sources['sealer.py']=Path(__file__).read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
records=[dict(path=name,bytes=len(body),sha256=sha(body)) for name,body in sorted(sources.items())]
index=(json.dumps(records,indent=2)+'\n').encode()
output=io.BytesIO()
with gzip.GzipFile(fileobj=output,mode='wb',compresslevel=9,mtime=0) as compressed:
 with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT) as archive:
  for record in records:
   info=tarfile.TarInfo(record['path']);info.size=record['bytes'];info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(sources[record['path']]))
body=output.getvalue()
with tarfile.open(fileobj=io.BytesIO(body),mode='r:gz') as archive:
 assert len(archive.getmembers())==len(records)
 for record in records:
  reopened=archive.extractfile(record['path']).read();assert len(reopened)==record['bytes'] and sha(reopened)==record['sha256']
native=json.loads(sources['native/report.json']);assert native['browserErrors']==dict(console=[],page=[],requests=[])
manifest=dict(schema='dimensional-depth-gap-seal-v1',head=head,records=len(records),reopenedMembers=len(records),recordIndexSha256=sha(index),archiveSha256=sha(body),archiveBytes=len(body),summary=native['browserResult']['result']['summary'],layoutDimensionalDepthRefusals=60,layout2DDepthControls=30,previousPrsUnchanged=136,newPr=536,productionAuthority=False)
destination.mkdir(parents=True)
(destination/'record-index.json').write_bytes(index);(destination/'recording.tar.gz').write_bytes(body);(destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest))
