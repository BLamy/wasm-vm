import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';

// Negative public layout admission only. No GPU, guest boot or capset claim.
const root='/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm';
const [expectedHead,output]=process.argv.slice(2);
assert.match(expectedHead??'',/^[a-f0-9]{40}$/);assert.ok(output);
const sha=b=>createHash('sha256').update(b).digest('hex');
const git=(...a)=>execFileSync('git',a,{cwd:root,encoding:'utf8'}).trim();
assert.equal(git('rev-parse','HEAD'),expectedHead);
assert.equal(git('status','--porcelain','--untracked-files=no'),'');
await fs.mkdir(output,{recursive:false});
const sources=new Map();
async function collect(name){
 if(sources.has(name))return;
 const bytes=await fs.readFile(path.join(root,name));sources.set(name,bytes);
 if(/\.m?js$/.test(name))for(const match of bytes.toString().matchAll(/(?:from|import)\s*['"](\.\.?\/[^'"]+)['"]/g))
  await collect(path.posix.normalize(path.posix.join(path.posix.dirname(name),match[1])));
}
await collect('renderer/virgl-command/resources.mjs');
const primary=JSON.parse(await fs.readFile(root+'/tools/virgl-floating-depth/primary.json'));
await collect('tools/virgl-floating-depth/primary.json');
for(const pin of primary.sources.filter(s=>/\/(version|st_extensions|virgl_screen)\.c$|\/u_format\.yaml$|\/es-3\.0\.6\.pdf$|\/webgl2\.html$/.test(s.path))){
 const bytes=await fs.readFile(root+'/'+pin.path);assert.equal(bytes.length,pin.bytes);assert.equal(sha(bytes),pin.sha256);sources.set(pin.path,bytes);
}
const {computeStandardDimensionalTransferLayout:layout}=await import(pathToFileURL(root+'/renderer/virgl-command/resources.mjs'));
const observations=[];let id=100;
for(const target of [2,4,7])for(const format of [16,18,20,21,126])for(const bind of [1,8,9])for(const direction of [1,2]){
 const meta={id:id++,target,format,bind,width:4,height:4,depth:1,arraySize:target===4?6:target===7?3:1,lastLevel:2,nrSamples:0,flags:0};
 const input={resourceHandle:meta.id,level:0,usage:0,stride:0,layerStride:0,box:{x:0,y:0,z:0,width:4,height:4,depth:target===2?1:meta.arraySize},dataOffset:5,direction};
 const packet=[(13<<16)|43,meta.id,0,0,0,0,0,0,0,4,4,input.box.depth,5,direction];
 const raw=Buffer.alloc(packet.length*4);packet.forEach((word,i)=>raw.writeUInt32LE(word>>>0,i*4));
 const result=layout(meta,input,8192);
 assert.equal(result.ok,target===2,JSON.stringify({meta,input,result}));
 if(target!==2)assert.equal(result.error.code,'unsupported-resource');
 observations.push({metadata:meta,input,backingBytes:8192,originalTransferDwords:packet,originalTransferHex:raw.toString('hex'),result});
}
for(const target of [3,4,7]){
 const meta={id:id++,target,format:67,bind:10,width:4,height:4,depth:target===3?4:1,arraySize:target===4?6:target===7?3:1,lastLevel:2,nrSamples:0,flags:0};
 const input={resourceHandle:meta.id,level:0,usage:0,stride:0,layerStride:0,box:{x:0,y:0,z:0,width:4,height:4,depth:target===3?4:meta.arraySize},dataOffset:5,direction:1};
 const result=layout(meta,input,8192);assert.equal(result.ok,true);observations.push({positiveRGBA8:true,metadata:meta,input,backingBytes:8192,result});
}
const pins=[];for(const [name,bytes]of sources){const dest=path.join(output,'source',name);await fs.mkdir(path.dirname(dest),{recursive:true});await fs.writeFile(dest,bytes);pins.push({path:name,bytes:bytes.length,sha256:sha(bytes)});assert.equal(sha(await fs.readFile(root+'/'+name)),sha(bytes));}
await fs.copyFile('/tmp/wasmvm-dimensional-depth-readiness.mjs',output+'/readiness-runner.mjs');
const report={schema:'dimensional-depth-negative-layout-readiness-v1',head:expectedHead,command:[process.execPath,...process.argv.slice(1)],status:'passed',actualLinuxGuest:false,nativeGpuExecution:false,positiveCapsetAuthority:false,claim:'All original selected 2D depth layouts admit; matching cube and array depth layouts refuse before storage or DMA. RGBA8 dimensional controls remain admitted.',primary,sources:pins,observations};
await fs.writeFile(output+'/report.json',JSON.stringify(report,null,2)+'\n');
assert.equal(git('status','--porcelain','--untracked-files=no'),'');
console.log(JSON.stringify({status:'passed',head:expectedHead,dimensionalDepthRefusals:60,positive2DDepthLayouts:30,positiveRGBA8DimensionalLayouts:3,sources:pins.length}));
