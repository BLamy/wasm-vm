import {checker,makeRig,header} from '/renderer/virgl-command/tests/submit-acceptance.mjs';
import {createVirglStandardDimensionalViewSubmitBridge} from '/renderer/virgl-command/control-bridge.mjs';
import {createVirglStandardDimensionalTextureShaderBridge} from '/renderer/virgl-shader/standard.mjs';
import {createStandardDimensionalViewResourceStore,createStandardDimensionalViewTransferBackend} from '/renderer/virgl-command/resources.mjs';
const copy=value=>JSON.parse(JSON.stringify(value,(_,v)=>ArrayBuffer.isView(v)?[...v]:typeof v==='bigint'?v.toString():v));
const META=['id','target','format','bind','width','height','depth','arraySize','lastLevel','nrSamples','flags'];
export async function run(WasmVirglSubmitProof) {
 const c=checker(),gl=document.querySelector('#gpu').getContext('webgl2',{antialias:false,failIfMajorPerformanceCaveat:true});
 c.truth(gl,'hardware WebGL2');
 const nativeCalls=[],objects=new WeakMap();let nextObject=1;
 const describe=value=>{
  if(value===null||typeof value!=='object')return value===undefined?{undefined:true}:value;
  if(ArrayBuffer.isView(value))return {type:value.constructor.name,bytes:[...new Uint8Array(value.buffer,value.byteOffset,value.byteLength)].map(v=>v.toString(16).padStart(2,'0')).join('')};
  if(!objects.has(value))objects.set(value,nextObject++);return {object:objects.get(value),type:value.constructor?.name??'object'};
 };
 const recordedGl=new Proxy(gl,{get(target,key){const value=Reflect.get(target,key,target);if(typeof value!=='function')return value;return(...args)=>{
  const before=args.map(describe),result=value.apply(target,args);nativeCalls.push({sequence:nativeCalls.length,name:key,before,after:args.map(describe),result:describe(result)});return result;
 };}});
 const limits={texture2D:recordedGl.getParameter(gl.MAX_TEXTURE_SIZE),texture3D:recordedGl.getParameter(gl.MAX_3D_TEXTURE_SIZE),cube:recordedGl.getParameter(gl.MAX_CUBE_MAP_TEXTURE_SIZE),arrayLayers:recordedGl.getParameter(gl.MAX_ARRAY_TEXTURE_LAYERS)};
 const compiler=await createVirglStandardDimensionalTextureShaderBridge();
 const Selected=class {constructor(callback,enabled){return enabled?WasmVirglSubmitProof.standardDimensional(callback):new WasmVirglSubmitProof(callback,false);}};
 const specs=[];
 for(const target of [2,4,7])for(const format of [16,18,20,21,126])for(const bind of [1,8,9])
  specs.push({name:`depth target${target} format${format} bind${bind}`,admit:target===2,meta:{id:100+specs.length,target,format,bind,width:4,height:4,depth:1,arraySize:target===4?6:target===7?3:1,lastLevel:2,nrSamples:0,flags:0}});
 for(const target of [3,4,7])specs.push({name:`RGBA8 positive target${target}`,admit:true,rgba8:true,meta:{id:100+specs.length,target,format:67,bind:10,width:4,height:4,depth:target===3?4:1,arraySize:target===4?6:target===7?3:1,lastLevel:2,nrSamples:0,flags:0}});
 const rows=[];window.__depthReadiness={rows,nativeCalls,limits};
 for(const spec of specs){
  const {name,admit,meta}=spec,rig=makeRig(Selected,createVirglStandardDimensionalViewSubmitBridge,recordedGl,compiler,c,0,true,false,true);
  window.__depthReadinessActive=()=>({case:name,native:copy(rig.q.vm.inspect()),host:copy(rig.host.bridge.inspect()),records:rig.q.records,events:rig.events});
  const before={native:copy(rig.q.vm.inspect()),host:copy(rig.host.bridge.inspect()),events:rig.events.length,objects:rig.trace.objects.size,nativeCalls:nativeCalls.length};
  const raw=header(0x204,0,72),view=new DataView(raw.buffer);META.forEach((key,j)=>view.setUint32(24+j*4,meta[key],true));
  const nativeRecord=await rig.expect(name+' original resource',raw,admit?0x1100:0x1205);
  const afterNative={native:copy(rig.q.vm.inspect()),host:copy(rig.host.bridge.inspect()),events:rig.events.length,objects:rig.trace.objects.size,nativeCalls:nativeCalls.length};
  let hostEvent=null,hostResult=null;
  if(admit){c.equal(afterNative.host.resources.length,1,name+' actual callback allocation');c.truth(afterNative.events>before.events,name+' host callback');}
  else{
   c.same(afterNative.native,before.native,name+' native refusal rollback');c.same(afterNative.host,before.host,name+' no host owner mutation');
   c.equal(afterNative.events,before.events,name+' refusal before callback');c.equal(afterNative.objects,before.objects,name+' no allocation');
   hostEvent={type:'createResource',epoch:'0000000000000001',resource:{id:meta.id,generation:'0000000000000001'},metadata:meta};
   hostResult=rig.host.bridge.apply(hostEvent);c.equal(hostResult.ok,false,name+' independent host refusal');
   c.same(rig.host.bridge.inspect(),before.host,name+' host refusal rollback');c.equal(rig.trace.objects.size,before.objects,name+' host refusal no allocation');
  }
  const backend=c.ok(createStandardDimensionalViewTransferBackend(recordedGl),'selected backend').backend;
  const selected=c.ok(createStandardDimensionalViewResourceStore({backend}),'selected store');
  const selectedBefore=copy(selected.store.inspect()),selectedResult=selected.store.createResource(meta);
  c.equal(selectedResult.ok,admit,name+' independent store admission');
  if(!admit)c.same(selected.store.inspect(),selectedBefore,name+' independent store refusal rollback');
  const selectedAfter=copy(selected.store.inspect());c.ok(selected.store.dispose(),name+' independent store dispose');
  const row={name,admit,rgba8:Boolean(spec.rgba8),metadata:meta,wire:[...raw],before,afterNative,nativeRecord,hostEvent,hostResult,hostAfter:copy(rig.host.bridge.inspect()),selectedBefore,selectedResult:copy(selectedResult),selectedAfter,events:copy(rig.events),queueRecords:copy(rig.q.records),guestTrace:rig.q.vm.commandTrace(),machineDigest:rig.q.vm.machineDigest(),nativeCallsEnd:nativeCalls.length};
  rig.dispose();row.disposed={nativeObjects:rig.trace.objects.size,nativeCallsEnd:nativeCalls.length};rows.push(row);window.__depthReadinessActive=null;
 }
 c.equal(gl.getError(),gl.NO_ERROR,'final hardware GL error');
 return {status:'passed',claim:'Original cube and array depth allocation refuses in the actual selected Wasm control owner and independent host owner. Qualified 2D depth and dimensional RGBA8 controls allocate.',actualLinuxGuest:false,positiveCapsetAuthority:false,nativeGpuExecution:true,rows,nativeCalls,limits,assertions:c.assertions,
  summary:{status:'passed',depth2DAdmitted:rows.filter(r=>r.admit&&!r.rgba8).length,dimensionalDepthRefused:rows.filter(r=>!r.admit).length,dimensionalRGBA8Admitted:rows.filter(r=>r.rgba8).length,nativeCalls:nativeCalls.length,assertions:c.assertions}};
}
