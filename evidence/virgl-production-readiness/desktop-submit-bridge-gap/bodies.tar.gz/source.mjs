import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { createServer } from 'node:http';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
const repo='/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm';
const output='/tmp/wasmvm-desktop-bridge-readiness-verified';
const sha=raw=>crypto.createHash('sha256').update(raw).digest('hex');
await fs.mkdir(output,{recursive:true});
const sources=new Map(),served=new Map(),inputs=[];
for(const name of ['compositor','kmscube','glmark2-es2']){
 const directory='evidence/virgl-corpus/captures/'+name;
 const manifestPath=directory+'/manifest.json',manifestRaw=await fs.readFile(path.join(repo,manifestPath)),manifest=JSON.parse(manifestRaw);
 const eventPath=directory+'/'+manifest.events.path,raw=await fs.readFile(path.join(repo,eventPath));
 assert.equal(sha(raw),manifest.events.sha256);assert.equal(raw.length,manifest.events.bytes);
 const events=raw.toString().trim().split('\n').map(JSON.parse);
 const pending=new Map(),calls=[];
 for(const e of events){if(!['resource_create','resource_unref'].includes(e.type))continue;if(e.phase==='enter'){assert.ok(!pending.has(e.seq));pending.set(e.seq,e);}else{const enter=pending.get(e.callSeq);assert.ok(enter&&enter.type===e.type);assert.equal(e.result,0);pending.delete(e.callSeq);calls.push({enter,returned:e});}}
 assert.equal(pending.size,0);const excluded=calls.filter(c=>c.enter.resourceId===2);assert.equal(excluded.length,1);assert.equal(excluded[0].enter.seq,10);assert.equal(excluded[0].enter.flags,1);
 sources.set(manifestPath,manifestRaw);sources.set(eventPath,raw);
 inputs.push({name,eventPath,eventSha256:sha(raw),bootstrap2D:excluded[0],calls:calls.filter(c=>c.enter.resourceId!==2)});
}
const report={schema:'original-desktop-bridge-readiness-v1',head:execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim(),guestExecution:false,productionNegotiation:false,status:'running',command:[process.execPath,...process.argv.slice(1)],inputs,sources:[],servedFiles:[],browserErrors:{console:[],page:[],requests:[]}};
let browser,server,page;
async function retain(name,raw){sources.set(name,raw);const destination=path.join(output,'source',name);await fs.mkdir(path.dirname(destination),{recursive:true});await fs.writeFile(destination,raw);}
try{
 server=createServer(async(req,res)=>{try{
  const name=new URL(req.url,'http://localhost').pathname;
  if(name==='/favicon.ico'){res.writeHead(204).end();return;}
  if(name==='/'){res.writeHead(200,{'Content-Type':'text/html'}).end('<!doctype html><meta charset="utf-8"><title>Desktop bridge readiness</title><canvas id="gpu" width="8" height="8"></canvas><pre id="result"></pre>');return;}
  assert.ok(name.startsWith('/renderer/')&&!name.includes('..'));
  const relative=name.slice(1),filename=path.join(repo,relative),raw=await fs.readFile(filename);
  await retain(relative,raw);served.set(relative,{path:relative,bytes:raw.length,sha256:sha(raw)});
  res.writeHead(200,{'Content-Type':name.endsWith('.wasm')?'application/wasm':'text/javascript','Cache-Control':'no-store'}).end(raw);
 }catch(e){res.writeHead(404).end(String(e));}});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
 const {chromium}=await import(pathToFileURL(path.join(repo,'web/node_modules/playwright/index.mjs')));
 const chrome='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
 browser=await chromium.launch({executablePath:chrome,headless:false,args:['--enable-gpu']});
 const session=await browser.newBrowserCDPSession(),system=await session.send('SystemInfo.getInfo'),command=await session.send('Browser.getBrowserCommandLine');
 assert.equal(system.gpu.featureStatus.webgl2??system.gpu.featureStatus.webgl,'enabled');
 assert.ok(!command.arguments.some(a=>/swiftshader|llvmpipe|softpipe|lavapipe|--disable-gpu(?:$|=)/i.test(a)));
 report.browser={executable:chrome,sha256:sha(await fs.readFile(chrome)),version:browser.version(),gpu:system.gpu,commandLine:command.arguments};
 page=await browser.newPage({viewport:{width:1000,height:720}});
 page.on('console',m=>{if(m.type()==='error')report.browserErrors.console.push({text:m.text(),location:m.location()});});
 page.on('pageerror',e=>report.browserErrors.page.push(e.message));page.on('requestfailed',r=>report.browserErrors.requests.push({url:r.url(),error:r.failure()?.errorText}));
 await page.goto('http://127.0.0.1:'+server.address().port+'/');
 report.result=await page.evaluate(async inputs=>{
  const {createVirglSubmitBridge}=await import('/renderer/virgl-command/control-bridge.mjs');
  const {createVirglStandardShadowTextureShaderBridge}=await import('/renderer/virgl-shader/standard.mjs');
  const shaderBridge=await createVirglStandardShadowTextureShaderBridge();
  const gl=document.querySelector('#gpu').getContext('webgl2',{antialias:false,failIfMajorPerformanceCaveat:true});
  const ext=gl.getExtension('WEBGL_debug_renderer_info'),rows=[],native=[];let transportCalls=0;
  const checked=(condition,label)=>{if(!condition)throw Error(label);};
  const wrapped=new Proxy(gl,{get(target,name){const value=Reflect.get(target,name,target);if(typeof value!=='function')return value;return(...args)=>{
   const result=value.apply(target,args);if(/^create(Buffer|Texture|Framebuffer|VertexArray|Program|Shader|Sampler)$/.test(name))native.push({name,allocated:result!==null});
   if(/^delete(Buffer|Texture|Framebuffer|VertexArray|Program|Shader|Sampler)$/.test(name))native.push({name});return result;};}});
  const fresh=()=>{const result=createVirglSubmitBridge({gl:wrapped,shaderBridge,transport:{gatherInput(){transportCalls++;throw Error('unexpected DMA');},scatterOutput(){transportCalls++;throw Error('unexpected DMA');},complete(){transportCalls++;throw Error('unexpected completion');}}});checked(result.ok,'existing bridge constructs with actual compiler');return result.bridge;};
  const copy=value=>JSON.parse(JSON.stringify(value));
  for(const input of inputs){const bridge=fresh(),live=new Map();let generation=0,firstRefusal=null;const steps=[];
   const row={workload:input.name,steps};rows.push(row);window.__bridgeReadinessPartial={rows,counts:[],native,transportCalls};
   for(const call of input.calls){const e=call.enter;let event;
    if(e.type==='resource_create'){
     const metadata={id:e.resourceId,target:e.target,format:e.format,bind:e.bind,width:e.width,height:e.height,depth:e.depth,arraySize:e.arraySize,lastLevel:e.lastLevel,nrSamples:e.nrSamples,flags:e.flags};
     const identity={id:e.resourceId,generation:(++generation).toString(16).padStart(16,'0')};checked(!live.has(e.resourceId),'original unique live identity');
     event={type:'createResource',epoch:'0000000000000001',resource:identity,metadata};
    }else{checked(live.has(e.resourceId),'original unref targets live identity');event={type:'unrefResource',epoch:'0000000000000001',resource:live.get(e.resourceId)};}
    const before=copy(bridge.inspect()),callStart=native.length,response=bridge.apply(event),after=copy(bridge.inspect());
    steps.push({originalEnter:e,originalReturn:call.returned,event,before,response,after,nativeCalls:native.slice(callStart)});
    if(!response.ok){checked(JSON.stringify(before)===JSON.stringify(after),'original refusal leaves complete owners unchanged');checked(native.length===callStart,'original refusal precedes native allocation');firstRefusal={event:e.seq,response};break;}
    if(e.type==='resource_create')live.set(e.resourceId,event.resource);else live.delete(e.resourceId);
   }
   row.firstRefusal=firstRefusal;row.beforeDispose=copy(bridge.inspect());checked(bridge.dispose().ok,'original bridge disposes');row.afterDispose=copy(bridge.inspect());checked(row.afterDispose.store.budgets.gpuBytes===0,'original allocations released');
   checked((input.name==='kmscube')===(firstRefusal===null),'kmscube completes; larger original lifetimes explicitly refuse');
  }
  const bridge=fresh(),counts=[];
  for(let i=1;i<=17;i++){
   const metadata={id:100+i,target:0,format:64,bind:16,width:8,height:1,depth:1,arraySize:1,lastLevel:0,nrSamples:0,flags:0};
   const event={type:'createResource',epoch:'0000000000000001',resource:{id:metadata.id,generation:i.toString(16).padStart(16,'0')},metadata};
   const before=copy(bridge.inspect()),callStart=native.length,response=bridge.apply(event),after=copy(bridge.inspect());
   counts.push({count:i,event,before,response,after,nativeCalls:native.slice(callStart)});
   checked(response.ok===(i<=16),'old accepted count remains16');
   if(i===17){checked(response.error.code==='out-of-memory','count17 explicit OOM');checked(JSON.stringify(before)===JSON.stringify(after),'count refusal leaves complete owners unchanged');checked(native.length===callStart,'count refusal precedes native allocation');}
  }
  const beforeDispose=copy(bridge.inspect());checked(bridge.dispose().ok,'count owner disposes');
  const afterDispose=copy(bridge.inspect());checked(afterDispose.resources.length===0&&afterDispose.store.budgets.gpuBytes===0,'all actual count allocations released');checked(transportCalls===0,'no DMA/job completion executed');
  const result={gpu:gl.getParameter(ext.UNMASKED_RENDERER_WEBGL),rows,counts,beforeDispose,afterDispose,native,transportCalls};document.querySelector('#result').textContent=JSON.stringify({gpu:result.gpu,originalWorkloads:rows.length,originalRefusals:rows.filter(r=>r.firstRefusal!==null).length,accepted:16,refused:17},null,2);return result;
 },inputs);
 assert.deepEqual(report.browserErrors,{console:[],page:[],requests:[]});assert.ok(report.result.gpu.includes('Metal'));
 await page.screenshot({path:path.join(output,'browser.png'),fullPage:true});report.screenshot={path:'browser.png',sha256:sha(await fs.readFile(path.join(output,'browser.png')))};
 report.status='passed';
}catch(e){report.status='failed';report.failure={message:e.message,stack:e.stack};if(page)report.partial=await page.evaluate(()=>window.__bridgeReadinessPartial??null).catch(()=>null);process.exitCode=1;console.error(e.stack);}
finally{
 await browser?.close();if(server)await new Promise(resolve=>server.close(resolve));
 for(const [name,raw]of sources){assert.equal(sha(await fs.readFile(path.join(repo,name))),sha(raw));await retain(name,raw);report.sources.push({path:name,bytes:raw.length,sha256:sha(raw)});}
 report.servedFiles=[...served.values()];await fs.copyFile('/tmp/wasmvm-desktop-bridge-readiness.mjs',path.join(output,'source.mjs'));
 await fs.writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({status:report.status,head:report.head,originalWorkloads:report.result?.rows.length,originalRefusals:report.result?.rows.filter(r=>r.firstRefusal!==null).length,accepted:report.result?.counts.filter(r=>r.response.ok).length,reportSha256:sha(await fs.readFile(path.join(output,'report.json')))}));
}
