Original single-layer RGBA8 surfaces for volume, cube and array resources previously returned unsupported-feature. This selected consumer preserves the original mip/layer and retained resource generation, and attaches the matching native layer or cube face for CLEAR, DRAW_VBO and sparse MRT.

Validation: make verify-E6-T11d63 passes from the final scrubbed pristine clone, with original Wasm VirtIO queues, hardware WebGL2, complete guarded DMA image checks, varied schedules, retention/reset tests and physical wrong-layer/wrong-face controls. A fresh adversarial verifier authenticated the complete recordings and audited the changed runtime. Built and deployed ordinary demo:127 passed,0 failed,zero browser errors.

Production negotiation remains gated by E6-T11d. This layer continues the existing native stack above PR540.
