from pathlib import Path
import datetime,json,subprocess,sys
repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
root=repo/'target/evidence/dimensional-color-surfaces-publication'
phase,head=sys.argv[1:3]
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
assert len(head)==40 and all(c in '0123456789abcdef' for c in head)
assert git('rev-parse','HEAD')==head
assert git('branch','--show-current')=='codex/virgl-dimensional-color-surfaces'
assert git('status','--porcelain','--untracked-files=no')==''
task=(repo/'tasks/epic-6-transcendence/E6-T11d63-dimensional-color-surfaces.md').read_text()
assert '\nstatus: verified\n' in task.split('\n---\n',1)[0]
folder=root/phase
folder.mkdir(parents=True,exist_ok=False)
(folder/'driver.py').write_bytes(Path(__file__).read_bytes())
rows=[]
def run(name,args):
    stdout,stderr=folder/(name+'.stdout'),folder/(name+'.stderr')
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with stdout.open('wb') as out,stderr.open('wb') as err:
        result=subprocess.run(args,cwd=repo,stdout=out,stderr=err)
    rows.append({'name':name,'argv':args,'cwd':str(repo),'head':head,'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode,'stdout':stdout.name,'stderr':stderr.name})
    (folder/'commands.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps({'name':name,'exitCode':result.returncode}),flush=True)
    if result.returncode:sys.exit(result.returncode)
if phase=='submit':run('submit',['gh','stack','submit','--auto','--remote','origin'])
elif phase=='edit':
    body='Original single-layer RGBA8 surfaces for volume, cube and array resources previously returned unsupported-feature. This selected consumer preserves the original mip/layer and retained resource generation, and attaches the matching native layer or cube face for CLEAR, DRAW_VBO and sparse MRT.\n\nValidation: make verify-E6-T11d63 passes from the final scrubbed pristine clone, with original Wasm VirtIO queues, hardware WebGL2, complete guarded DMA image checks, varied schedules, retention/reset tests and physical wrong-layer/wrong-face controls. A fresh adversarial verifier authenticated the complete recordings and audited the changed runtime. Built and deployed ordinary demo:127 passed,0 failed,zero browser errors.\n\nProduction negotiation remains gated by E6-T11d. This layer continues the existing native stack above PR540.\n'
    bodyfile=folder/'body.md';bodyfile.write_text(body)
    run('edit',['gh','pr','edit','codex/virgl-dimensional-color-surfaces','--title','Render original single-layer dimensional color surfaces','--body-file',str(bodyfile)])
elif phase=='after':
    for name,args in [
      ('stack-local',['gh','stack','view','--json']),
      ('stack-499',['gh','api','repos/BLamy/wasm-vm/stacks/499']),
      ('stack-500',['gh','api','repos/BLamy/wasm-vm/stacks/500']),
      ('open-1',['gh','api','repos/BLamy/wasm-vm/pulls?state=open&per_page=100&page=1']),
      ('open-2',['gh','api','repos/BLamy/wasm-vm/pulls?state=open&per_page=100&page=2'])]:run(name,args)
else:raise ValueError(phase)
assert git('rev-parse','HEAD')==head
assert git('status','--porcelain','--untracked-files=no')==''
