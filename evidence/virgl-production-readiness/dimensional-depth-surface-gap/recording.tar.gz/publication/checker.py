from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[2]).resolve()
head=sys.argv[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads((root/p).read_bytes())
def pr(p):
    return {k:p[k] for k in ['id','number','node_id','title','state','draft','merged_at','html_url']}|{
      'head':{k:p['head'][k] for k in ['ref','sha']},'base':{k:p['base'][k] for k in ['ref','sha']}}
before=read('before/open-1.stdout')+read('before/open-2.stdout')
after=read('after/open-1.stdout')+read('after/open-2.stdout')
assert len(before)==141 and len(after)==142
old={p['number']:pr(p) for p in before};new={p['number']:pr(p) for p in after}
assert len(old)==141 and len(new)==142
for number,p in old.items():assert new[number]==p,(number,p,new.get(number))
full_after={p['number']:p for p in after}
for p in before:assert full_after[p['number']]['body']==p['body'],('prior PR body changed',p['number'])
added=set(new)-set(old);assert len(added)==1;number=added.pop();added=new[number]
assert added['head']=={'ref':'codex/virgl-dimensional-color-surfaces','sha':head}
assert added['base']=={'ref':'codex/virgl-dimensional-shadow-samplers','sha':'2691b24e6c00478f8d69f81180b6827761de246a'}
assert all(p['state']=='open' and p['draft'] and p['merged_at'] is None for p in new.values())
stacks=[]
for n in [499,500]:
    name=f'stack-{n}';a=read('before/'+name+'.stdout');b=read('after/'+name+'.stdout')
    for k in ['id','number','node_id','url','base','open','created_at']:assert a[k]==b[k],(n,k)
    aa=[pr(p) for p in a['pull_requests']];bb=[pr(p) for p in b['pull_requests']]
    if n==499:assert aa==bb and len(bb)==50
    else:assert aa==bb[:-1] and bb[-1]==added and len(bb)==92
    stacks.append({'number':n,'id':a['id'],'previousPrCount':len(aa),'publishedPrCount':len(bb),
      'beforeSha256':sha(root/('before/'+name+'.stdout')),'afterSha256':sha(root/('after/'+name+'.stdout'))})
a=read('before/stack-local.stdout');b=read('after/stack-local.stdout')
assert a['trunk']==b['trunk'] and a['currentBranch']==b['currentBranch']
assert len(a['branches'])==len(b['branches'])==92
for aa,bb in zip(a['branches'][:-1],b['branches'][:-1]):assert aa==bb,(aa['name'],aa,bb)
last=b['branches'][-1];assert last['name']=='codex/virgl-dimensional-color-surfaces' and last['head']==head
assert last['base']==a['branches'][-1]['base']=='2691b24e6c00478f8d69f81180b6827761de246a'
assert last['pr']['number']==number and last['pr']['state']=='OPEN'
assert not last['isMerged'] and not last['isQueued'] and not last['needsRebase']
result={'schema':'d63-native-stack-append-only-continuity-v1','status':'passed','head':head,
 'existingPrCount':141,'existingPrIdentitiesOrderTitlesBodiesHeadsBasesStatesHeld':True,'stackIdentitiesHeld':True,
 'allOpenDraftUnmerged':True,'addition':added,'stacks':stacks,'checkerSha256':sha(Path(__file__))}
(root/'checker.py').write_bytes(Path(__file__).read_bytes())
(root/'continuity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'passed','existingPrCount':141,'stackIdentitiesHeld':True,'newPr':number,'allOpenDraftUnmerged':True}))
