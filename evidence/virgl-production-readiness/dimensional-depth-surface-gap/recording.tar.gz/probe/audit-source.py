from pathlib import Path
import hashlib,json,struct,subprocess,sys

repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
head=sys.argv[1]
root=Path(sys.argv[2]).resolve()
assert len(head)==40 and all(c in '0123456789abcdef' for c in head)
sha=lambda b:hashlib.sha256(b).hexdigest()
report=json.loads((root/'report.json').read_bytes())
assert report['head']==head and report['status']=='passed'
assert report['actualLinuxGuest'] is False and report['positiveCapsetAuthority'] is False
assert report['browserErrors']==dict(console=[],page=[],requests=[])
assert report['browser']['headless'] is False and 'Metal' in json.dumps(report['browser']['gpu'])
assert report['browser']['gpu']['featureStatus'].get('webgl2',report['browser']['gpu']['featureStatus'].get('webgl'))=='enabled'
assert not any(x in json.dumps(report['browser']['commandLine']).lower() for x in ['swiftshader','llvmpipe','softpipe','lavapipe','--disable-gpu'])
held_bytes=(repo/'target/evidence/dimensional-color-surfaces-cold-final-6a600d7c/recording/hardware-54831/report.json').read_bytes()
held=json.loads(held_bytes)
worker=repo/'evidence/virgl-dimensional-color-surfaces/worker'
manifest_bytes=(worker/'manifest.json').read_bytes();index_bytes=(worker/'records.json').read_bytes()
assert sha(manifest_bytes)=='cdcaa8ba0a2a80d789c7df623818b31cdd491af575ac9a92540b8df25d39cc4e'
assert sha(index_bytes)=='43558e49104803535ea74b29dae6b145bdd8c762163013087f5cb475e22ef624'
held_pin=next(row for row in json.loads(index_bytes)['records'] if row['path']=='cold/recording/hardware-54831/report.json')
assert len(held_bytes)==held_pin['bytes'] and sha(held_bytes)==held_pin['sha256']
authority=root/'authority';authority.mkdir(exist_ok=False)
for name,body in [('d63-worker-manifest.json',manifest_bytes),('d63-worker-records.json',index_bytes),('d63-frozen-hardware-report.json',held_bytes)]: (authority/name).write_bytes(body)
generated={r['path']:r for r in held['sources']}
for pin in report['sources']:
    body=(root/'source'/pin['path']).read_bytes()
    assert len(body)==pin['bytes'] and sha(body)==pin['sha256']
    tracked=subprocess.run(['git','show',head+':'+pin['path']],cwd=repo,capture_output=True)
    if tracked.returncode==0:assert body==tracked.stdout,pin['path']
    elif pin['path'].startswith('web/pkg/'):
        committed='web/dist/pkg/'+pin['path'][len('web/pkg/'):]
        assert body==subprocess.check_output(['git','show',head+':'+committed],cwd=repo),pin['path']
    else:
        authority=generated[pin['path']]
        assert authority['bytes']==len(body) and authority['sha256']==sha(body),pin['path']
for pin in report['servedFiles']:
    body=(root/pin['bodyPath']).read_bytes()
    assert len(body)==pin['bytes'] and sha(body)==pin['sha256']
for key in ['browserCoverage','screenshot']:
    pin=report[key];assert sha((root/pin['path']).read_bytes())==pin['sha256']
assert sha((root/'readiness-body.mjs').read_bytes())==report['probe']['bodySha256']
assert sha((root/'readiness-runner.mjs').read_bytes())==report['probe']['runnerSha256']
result=report['browserResult']['result'];calls=result['nativeCalls'];rows=result['rows']
assert len(rows)==10 and len(calls)>0
assert not any(call['name']=='finish' for call in calls)
assert {(r['metadata']['target'],r['metadata']['format']) for r in rows}=={(t,f) for t in [4,7] for f in [16,18,20,21,126]}
keys=['id','target','format','bind','width','height','depth','arraySize','lastLevel','nrSamples','flags']
refusals=0;controls=0;citations=[]
for row in rows:
    meta=row['metadata'];wire=bytes.fromhex(row['allocationWire'])
    assert struct.unpack_from('<I',wire)[0]==0x204
    assert list(struct.unpack_from('<11I',wire,24))==[meta[k] for k in keys]
    assert struct.unpack_from('<I',bytes.fromhex(row['allocation']['response']))[0]==0x1100
    assert row['status']=='passed'
    expected={(level,layer) for level in [0,1,2] for layer in ([0] if meta['target']==3 and max(1,meta['depth']>>level)==1 else [0,1])}
    assert {(p['level'],p['layer']) for p in row['probes']}==expected
    for i,p in enumerate(row['probes']):
        raw=bytes.fromhex(p['wire']);assert struct.unpack_from('<I',raw)[0]==0x207
        assert struct.unpack_from('<6I',raw,32)==(0x00050801,70,6,meta['format'],p['level'],p['layer']|(p['layer']<<16))
        assert p['record']['request']==p['wire']
        assert struct.unpack_from('<I',bytes.fromhex(p['record']['response']))[0]==0x1205
        assert p['before']['host']['store']==p['after']['host']['store']
        assert p['before']['objects']==p['after']['objects']
        for call in calls[p['before']['nativeCalls']:p['after']['nativeCalls']]:
            assert call['name']!='framebufferTextureLayer'
            assert not(call['name']=='framebufferTexture2D' and 34069<=call['before'][2]<=34074)
        refusals+=1
        citations.append(dict(row=row['name'],probe=i,level=p['level'],layer=p['layer'],wireSha256=sha(raw),responseSha256=sha(bytes.fromhex(p['record']['response']))))
    raw=bytes.fromhex(row['controlWire'])
    assert struct.unpack_from('<6I',raw,32)==(0x00050801,70,1,meta['format'],1,0)
    assert struct.unpack_from('<I',bytes.fromhex(row['controlAllocation']['response']))[0]==0x1100
    assert struct.unpack_from('<I',bytes.fromhex(row['control']['response']))[0]==0x1100
    assert row['cleaned']['liveObjects']==row['cleaned']['liveSyncs']==0
    assert row['guestTrace'] and row['machineDigest'];controls+=1
assert refusals==60 and controls==10
audit=dict(schema='dimensional-depth-surface-negative-wire-audit-v1',status='passed',head=head,reportSha256=sha((root/'report.json').read_bytes()),storageControls=len(rows),singleLayerSurfaceRefusals=refusals,ordinary2DMipSurfaceControls=controls,nativeCalls=len(calls),sourceBodies=len(report['sources']),servedBodies=len(report['servedFiles']),citations=citations,actualLinuxGuest=False,positiveCapsetAuthority=False)
(root/'audit-source.py').write_bytes(Path(__file__).read_bytes())
(root/'original-wire-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({k:audit[k] for k in ['status','storageControls','singleLayerSurfaceRefusals','ordinary2DMipSurfaceControls','nativeCalls','sourceBodies','servedBodies']}))
