from pathlib import Path
import gzip,hashlib,io,json,tarfile

repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
raw=Path('/tmp/wasmvm-dimensional-depth-view-gap-bc2fb1e4')
stack=Path('/tmp/wasmvm-d59-stack-continuity')
sha=lambda b:hashlib.sha256(b).hexdigest()
report=json.loads((raw/'report.json').read_bytes())
continuity=json.loads((stack/'continuity.json').read_bytes())
assert report['status']=='passed' and report['head']==continuity['head']=='bc2fb1e49575b8b1a399ca7729fcec4853a48287'
assert continuity['existingPrCount']==137 and continuity['existingPrIdentitiesOrderHeadsBasesStatesHeld'] is True
assert json.loads((raw/'audit.json').read_bytes())['status']=='passed'
files={'admission/'+p.relative_to(raw).as_posix():p for p in raw.rglob('*') if p.is_file()}
files.update({'publication/'+p.relative_to(stack).as_posix():p for p in stack.rglob('*') if p.is_file()})
files.update({'scripts/body.mjs':Path('/tmp/wasmvm-dimensional-depth-view-gap-body.mjs'),'scripts/browser.mjs':Path('/tmp/wasmvm-dimensional-depth-view-readiness.mjs'),'scripts/audit.py':Path('/tmp/wasmvm-audit-dimensional-depth-view-gap.py'),'scripts/stack.py':Path('/tmp/wasmvm-check-d59-stack-continuity.py'),'scripts/seal.py':Path(__file__),'publication/description.md':Path('/tmp/wasmvm-d59-pr-body.md'),'cleanup/custody.json':Path('/tmp/wasmvm-dimensional-depth-cold-ca9481eb/cleanup-custody.json'),'cleanup/script.py':Path('/tmp/wasmvm-clean-owned-d59-cold.py')})
for family in ['worker','verifier','deployment']:
 for name in ['manifest.json','records.json']:
  files[f'dependencies/{family}/{name}']=repo/'evidence/virgl-dimensional-depth'/family/name
for pin in report['sources']:
 b=(raw/'source'/pin['path']).read_bytes();assert len(b)==pin['bytes'] and sha(b)==pin['sha256']
rows=[dict(path=n,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for n,p in sorted(files.items())]
out=repo/'evidence/virgl-production-readiness/dimensional-depth-view-gap';assert not out.exists();out.mkdir(parents=True)
index=(json.dumps(dict(schema='dimensional-depth-view-readiness-index-v1',head=report['head'],records=rows),indent=2)+'\n').encode();(out/'records.json').write_bytes(index)
archive=out/'recording.tar.gz'
with archive.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
 for row in rows:
  body=files[row['path']].read_bytes();entry=tarfile.TarInfo(row['path']);entry.size,entry.mode,entry.mtime=len(body),0o644,0;tar.addfile(entry,io.BytesIO(body))
with tarfile.open(archive,'r:gz') as tar:
 assert tar.getnames()==[r['path'] for r in rows]
 for row in rows:
  b=tar.extractfile(row['path']).read();assert len(b)==row['bytes'] and sha(b)==row['sha256']
manifest=dict(schema='dimensional-depth-view-readiness-seal-v1',head=report['head'],records=len(rows),reopenedMembers=len(rows),recordIndexSha256=sha(index),archiveSha256=sha(archive.read_bytes()),archiveBytes=archive.stat().st_size,negativeOriginalViews=20,positiveOriginalControls=13,nativeGpuCalls=13858,assertions=15581,actualLinuxGuest=False,positiveCapsetAuthority=False,originalStackPrsUnchanged=137,newPr=continuity['addition']['number'])
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest));print('manifestSha256',sha((out/'manifest.json').read_bytes()))
