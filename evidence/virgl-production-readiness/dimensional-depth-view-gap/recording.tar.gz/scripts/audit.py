from pathlib import Path
import hashlib,json,struct
root=Path('/tmp/wasmvm-dimensional-depth-view-gap-bc2fb1e4')
raw=(root/'report.json').read_bytes();d=json.loads(raw);r=d['browserResult']['result']
assert d['status']==r['status']=='passed'
assert d['head']=='bc2fb1e49575b8b1a399ca7729fcec4853a48287'
assert d['browserErrors']==dict(console=[],page=[],requests=[])
for pin in d['sources']:
 b=(root/'source'/pin['path']).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256']
for row in r['rows']:
 assert row['disposed']['nativeObjects']==0
 assert len(row['allocationWire'])==72 and struct.unpack_from('<I',bytes(row['allocationWire']))[0]==0x204
 assert int.from_bytes(bytes.fromhex(row['allocation']['response'])[:4],'little')==0x1100
 wire=bytes(row['viewWire']);assert struct.unpack_from('<I',wire)[0]==0x207
 commands=wire[32:];assert struct.unpack_from('<I',commands)[0]==1|(6<<8)|(6<<16)
 handle,owner,fmt,layers,levels,swizzle=struct.unpack_from('<6I',commands,4)
 assert handle==40 and owner==6 and fmt==(row['metadata']['target']<<24)|row['metadata']['format']
 assert levels==2<<8 and swizzle==0x688
 response=int.from_bytes(bytes.fromhex(row['record']['response'])[:4],'little')
 assert response==(0x1100 if row['admit'] else 0x1205)
 if not row['admit']:
  assert row['metadata']['target'] in [4,7] and row['metadata']['format'] in [16,18,20,21,126]
  assert row['after']['host']['store']==row['before']['host']['store']
  assert row['after']['objects']==row['before']['objects']
assert len(r['rows'])==33 and sum(not row['admit'] for row in r['rows'])==20
assert r['summary']==dict(status='passed',depth2DViewsAdmitted=10,dimensionalDepthViewsRefused=20,dimensionalRGBA8ViewsAdmitted=3,nativeCalls=13858,assertions=15581)
result=dict(schema='dimensional-depth-view-gap-audit-v1',status='passed',head=d['head'],completeSourcesReopened=len(d['sources']),originalWireRows=33,refusedViews=20,positiveControls=13,allAllocated=True,allTerminalNativeObjectsZero=True,reportSha256=hashlib.sha256(raw).hexdigest(),scriptSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),earlierParserAttempt='A read-only audit expected a nonexistent record.expected field; the complete raw response field above is the authority. No runtime or browser recording changed.')
(root/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
