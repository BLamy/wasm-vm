"""Authenticate append-only publication against both complete native stack bodies."""
from pathlib import Path
import hashlib,json,subprocess,sys

repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
directory=Path('/tmp/wasmvm-d59-stack-continuity')
sha=lambda b:hashlib.sha256(b).hexdigest()
columns=('url','id','number','head','base','node_id','state','merged_at','draft','html_url')
pins=[];held=0;prior=set();addition=None
for number in (499,500):
 beforeRaw=(directory/f'stack{number}-before.json').read_bytes()
 afterRaw=(directory/f'stack{number}-after.json').read_bytes()
 before,after=map(json.loads,(beforeRaw,afterRaw))
 for key in ('id','number','node_id','url','base','open','created_at'):
  assert after[key]==before[key],(number,key)
 oldRows,newRows=before['pull_requests'],after['pull_requests']
 assert len(oldRows)==(50 if number==499 else 87)
 assert len(newRows)==len(oldRows)+(number==500)
 for index,(old,new) in enumerate(zip(oldRows,newRows)):
  assert {k:old[k] for k in columns}=={k:new[k] for k in columns},(number,index,old['number'])
  assert new['state']=='open' and new['draft'] is True and new['merged_at'] is None
  assert old['id'] not in prior;prior.add(old['id']);held+=1
 if number==500:
  addition=newRows[-1];assert addition['id'] not in prior
  assert addition['head']['ref']=='codex/virgl-dimensional-depth-transfers'
  assert addition['base']['ref']==oldRows[-1]['head']['ref']
  assert addition['base']['sha']==oldRows[-1]['head']['sha']
  assert addition['state']=='open' and addition['draft'] is True and addition['merged_at'] is None
 pins.append(dict(number=number,beforeSha256=sha(beforeRaw),afterSha256=sha(afterRaw),previousPrCount=len(oldRows),publishedPrCount=len(newRows)))
assert held==137 and addition
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert addition['head']['sha']==head,(addition['head']['sha'],head)
report=dict(schema='d59-native-stack-append-only-continuity-v1',status='passed',head=head,existingPrCount=held,existingPrIdentitiesOrderHeadsBasesStatesHeld=True,stackIdentitiesHeld=True,allOpenDraftUnmerged=True,addition={k:addition[k] for k in columns},sources=pins,checkerSha256=sha(Path(__file__).read_bytes()))
(directory/'continuity.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],existingPrCount=held,newPr=addition['number'],url=addition['html_url'],head=head)))
