from pathlib import Path
import hashlib,json,shutil,subprocess
directory=Path('/tmp/wasmvm-dimensional-depth-cold-ca9481eb')
repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
assert 'status: verified' in (repo/'tasks/epic-6-transcendence/E6-T11d59-dimensional-depth-transfers.md').read_text().split('## Boundary')[0]
report_raw=(directory/'report.json').read_bytes()
report=json.loads(report_raw)
clone=Path(report['clone'])
assert str(clone)=='/private/var/folders/nr/cyvk1qc14jj5c081vj1xts000000gn/T/wasm-vm-dimensional-depth-cold-r4ea2d9r/repo'
assert clone.parent.name=='wasm-vm-dimensional-depth-cold-r4ea2d9r'
assert report['exitCode']==0 and report['cleanBefore']==report['cleanAfter']==''
assert report['head']=='ca9481ebe67cb0678939996d5f796552c6a1bf3b'
assert hashlib.sha256((directory/'recording/receipt.json').read_bytes()).hexdigest()==report['receiptSha256']=='404537349eced26a90d267a66b79e502cc3954294560732dd8d3735798051491'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==report['head']
assert subprocess.check_output(['git','status','--porcelain'],cwd=clone,text=True)==''
proof=Path(report['evidenceOutput'])
preserved=[]
for frozen in ['ac6e174b','4208c7b8','ca9481eb']:
 oldDirectory=Path('/tmp/wasmvm-dimensional-depth-cold-'+frozen)
 oldReport=json.loads((oldDirectory/'report.json').read_text())
 assert Path(oldReport['clone']).resolve()==clone.resolve()
 proof=Path(oldReport['evidenceOutput'])
 assert proof.is_dir()
 count=0
 for source in proof.rglob('*'):
  if source.is_file():
   retained=oldDirectory/'recording'/source.relative_to(proof)
   assert retained.is_file() and source.stat().st_size==retained.stat().st_size
   assert hashlib.sha256(source.read_bytes()).digest()==hashlib.sha256(retained.read_bytes()).digest(),str(source)
   count+=1
 preserved.append(dict(head=oldReport['head'],bodies=count,recording=str(oldDirectory/'recording')))
size=subprocess.check_output(['du','-sk',str(clone.parent)],text=True).split()[0]
cleanup=dict(schema='owned-d59-cold-cleanup-v1',clone=str(clone),head=report['head'],reportSha256=hashlib.sha256(report_raw).hexdigest(),receiptSha256=report['receiptSha256'],allRawProofBodiesPreserved=True,preserved=preserved,ownedKiB=int(size),freshVerifierLeaseReleased=True)
(directory/'cleanup-custody.json').write_text(json.dumps(cleanup,indent=2)+'\n')
shutil.rmtree(clone.parent)
print(json.dumps(cleanup))
