import {checker,makeRig,header,context,idCommand,submission} from '/renderer/virgl-command/tests/submit-acceptance.mjs';
import {createVirglStandardDimensionalDepthSubmitBridge} from '/renderer/virgl-command/control-bridge.mjs';
import {createVirglStandardDimensionalTextureShaderBridge} from '/renderer/virgl-shader/standard.mjs';
const copy=value=>JSON.parse(JSON.stringify(value,(_,v)=>ArrayBuffer.isView(v)?[...v]:typeof v==='bigint'?v.toString():v));
const META=['id','target','format','bind','width','height','depth','arraySize','lastLevel','nrSamples','flags'];
function packet(op,type,words){const bytes=new Uint8Array((words.length+1)*4),view=new DataView(bytes.buffer);view.setUint32(0,op|(type<<8)|(words.length<<16),true);words.forEach((v,i)=>view.setUint32(4+i*4,v,true));return bytes;}
export async function run(WasmVirglSubmitProof) {
 const c=checker(),gl=document.querySelector('#gpu').getContext('webgl2',{antialias:false,failIfMajorPerformanceCaveat:true});c.truth(gl,'hardware WebGL2');
 const nativeCalls=[],objects=new WeakMap();let nextObject=1;
 const describe=value=>{if(value===null||typeof value!=='object')return value===undefined?{undefined:true}:value;if(ArrayBuffer.isView(value))return {type:value.constructor.name,bytes:[...new Uint8Array(value.buffer,value.byteOffset,value.byteLength)].map(v=>v.toString(16).padStart(2,'0')).join('')};if(!objects.has(value))objects.set(value,nextObject++);return {object:objects.get(value),type:value.constructor?.name??'object'};};
 const recordedGl=new Proxy(gl,{get(target,key){const value=Reflect.get(target,key,target);if(typeof value!=='function')return value;return(...args)=>{const before=args.map(describe),result=value.apply(target,args);nativeCalls.push({sequence:nativeCalls.length,name:key,before,after:args.map(describe),result:describe(result)});return result;};}});
 const limits={texture2D:recordedGl.getParameter(gl.MAX_TEXTURE_SIZE),cube:recordedGl.getParameter(gl.MAX_CUBE_MAP_TEXTURE_SIZE),arrayLayers:recordedGl.getParameter(gl.MAX_ARRAY_TEXTURE_LAYERS)};
 const compiler=await createVirglStandardDimensionalTextureShaderBridge();
 const Selected=class {constructor(callback,enabled){return enabled?WasmVirglSubmitProof.standardDimensionalDepth(callback):new WasmVirglSubmitProof(callback,false);}};
 const specs=[];
 for(const target of [2,4,7])for(const format of [16,18,20,21,126])for(const bind of [8,9])specs.push({name:`depth view target${target} format${format} bind${bind}`,admit:target===2,meta:{id:6,target,format,bind,width:4,height:4,depth:1,arraySize:target===4?6:target===7?3:1,lastLevel:2,nrSamples:0,flags:0}});
 for(const target of [3,4,7])specs.push({name:`RGBA8 view positive target${target}`,admit:true,rgba8:true,meta:{id:6,target,format:67,bind:10,width:4,height:4,depth:target===3?4:1,arraySize:target===4?6:target===7?3:1,lastLevel:2,nrSamples:0,flags:0}});
 const rows=[];window.__depthReadiness={rows,nativeCalls,limits};
 for(const spec of specs){
  const {name,admit,meta}=spec,rig=makeRig(Selected,createVirglStandardDimensionalDepthSubmitBridge,recordedGl,compiler,c,0,true,false,true);
  window.__depthReadinessActive=()=>({case:name,native:copy(rig.q.vm.inspect()),host:copy(rig.host.bridge.inspect()),records:rig.q.records,events:rig.events});
  await rig.expect(name+' context',context(1));
  const raw=header(0x204,0,72),view=new DataView(raw.buffer);META.forEach((key,j)=>view.setUint32(24+j*4,meta[key],true));
  const allocation=await rig.expect(name+' allocation',raw);c.equal(rig.host.bridge.inspect().resources.length,1,name+' actual allocation');
  await rig.expect(name+' membership',idCommand(0x202,1,meta.id));
  const before={native:copy(rig.q.vm.inspect()),host:copy(rig.host.bridge.inspect()),objects:rig.trace.objects.size,nativeCalls:nativeCalls.length};
  const layerWord=meta.target===4?5<<16:meta.target===7?(meta.arraySize-1)<<16:0;
  const create=packet(1,6,[40,6,(meta.target<<24)|meta.format,layerWord,2<<8,0x688]);
  const request=submission(1,create),record=await rig.expect(name+' original sampler view',request,admit?0x1100:0x1205);
  const after={native:copy(rig.q.vm.inspect()),host:copy(rig.host.bridge.inspect()),objects:rig.trace.objects.size,nativeCalls:nativeCalls.length};
  if(!admit){c.same(after.host.store,before.host.store,name+' refused view preserves owner and budgets');c.equal(after.objects,before.objects,name+' refused view creates no GPU objects');}
  else await rig.expect(name+' retire view',submission(1,packet(3,6,[40])));
  const row={name,admit,rgba8:Boolean(spec.rgba8),metadata:meta,allocationWire:[...raw],allocation,viewWire:[...request],before,after,record,events:copy(rig.events),queueRecords:copy(rig.q.records),guestTrace:rig.q.vm.commandTrace(),machineDigest:rig.q.vm.machineDigest(),nativeCallsEnd:nativeCalls.length};
  rig.dispose();row.disposed={nativeObjects:rig.trace.objects.size,nativeCallsEnd:nativeCalls.length};rows.push(row);window.__depthReadinessActive=null;
 }
 c.equal(gl.getError(),gl.NO_ERROR,'final hardware GL error');
 return {status:'passed',claim:'Original cube and array depth storage allocates, but original retained sampler views refuse in the selected actual Wasm queue and hardware bridge. Qualified 2D depth and dimensional RGBA8 view controls pass.',actualLinuxGuest:false,positiveCapsetAuthority:false,nativeGpuExecution:true,rows,nativeCalls,limits,assertions:c.assertions,summary:{status:'passed',depth2DViewsAdmitted:rows.filter(r=>r.admit&&!r.rgba8).length,dimensionalDepthViewsRefused:rows.filter(r=>!r.admit).length,dimensionalRGBA8ViewsAdmitted:rows.filter(r=>r.rgba8).length,nativeCalls:nativeCalls.length,assertions:c.assertions}};
}
