import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const repo=execFileSync('git',['rev-parse','--show-toplevel'],{encoding:'utf8'}).trim();
const head=execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim();
assert.equal(head,'deb7b3113f9adeb2e6e80449a6710dd3295093ea');
assert.equal(execFileSync('git',['status','--porcelain','--untracked-files=no'],{cwd:repo,encoding:'utf8'}).trim(),'');
const output=process.argv[2];assert.ok(output);
await fs.mkdir(output);
const mod=name=>import(pathToFileURL(path.join(repo,name)));
const shader=await mod('renderer/virgl-shader/standard.mjs');
const metadata=await mod('renderer/virgl-command/constant-domain.mjs');
const decoders=await mod('renderer/virgl-command/decoder.mjs');
const fixtures=await mod('tools/virgl-dimensional-shaders/fixtures.mjs');
const selected=await shader.createVirglStandardDimensionalTextureShaderBridge();
const old=await shader.createVirglStandardShadowTextureShaderBridge();
const sha=b=>createHash('sha256').update(b).digest('hex');
const report={schema:'original-dimensional-view-consumer-gap-v1',head,actualLinuxGuest:false,productionAuthority:false,shaderRows:[],viewRows:[],positiveControls:[],sources:[]};
for(const stage of ['vertex','fragment'])for(const target of fixtures.targets)for(const type of fixtures.returns)for(const opcode of ['TEX','TXL','TXQ']){
 const request={stage,text:fixtures.dimensionalText(stage,{target,type,opcode,slot:7})};
 const response=selected.translate(request);assert.equal(response.ok,true);
 const parsed=metadata.parseStandardShadowTextureShaderMetadata(response.metadata,stage);
 assert.equal(parsed.ok,false);assert.equal(parsed.error.code,'shader-domain-error');
 const normalized=metadata.normalizeStandardShadowTextureShaderResult(response,stage);assert.equal(normalized.ok,false);
 const diagnostic={...response.metadata,profile:metadata.STANDARD_SHADOW_TEXTURE_SHADER_PROFILE};
 const isolated=metadata.parseStandardShadowTextureShaderMetadata(diagnostic,stage);assert.equal(isolated.ok,false);
 report.shaderRows.push({stage,target,type,opcode,request,response,parsed,normalized,diagnostic:{purpose:'Isolate native dimension type refusal after the distinct-profile refusal; this edited record has no shader admission authority.',input:diagnostic,result:isolated}});
}
const packet=(target,firstLayer,lastLayer,lastLevel=2)=>{
 const words=[(6<<16)|(6<<8)|1,51,6,67|(target<<24),((lastLayer<<16)|firstLayer)>>>0,lastLevel<<8,0|(1<<3)|(2<<6)|(3<<9)];
 const raw=Buffer.alloc(words.length*4);words.forEach((v,i)=>raw.writeUInt32LE(v>>>0,i*4));return{words,bytes:raw,hex:raw.toString('hex')};
};
for(const [name,invoke]of Object.entries(decoders).filter(([n,v])=>n.startsWith('decode')&&typeof v==='function')){
 for(const [target,firstLayer,lastLayer]of [[3,0,0],[4,0,5],[7,1,4]]){
  const original=packet(target,firstLayer,lastLayer),response=invoke(new Uint8Array(original.bytes));assert.equal(response.ok,false);
  report.viewRows.push({decoder:name,target,firstLayer,lastLayer,words:original.words,hex:original.hex,response});
 }
 const original=packet(2,0,0,0),response=invoke(new Uint8Array(original.bytes));assert.equal(response.ok,true);
 report.positiveControls.push({kind:'historical-2D-view',decoder:name,words:original.words,hex:original.hex,response});
}
for(const stage of ['vertex','fragment'])for(const opcode of ['TEX','TXL','TXQ']){
 const request={stage,text:fixtures.dimensionalText(stage,{target:'2D',type:'FLOAT',opcode,slot:7})};
 const response=old.translate(request);assert.equal(response.ok,true);
 const parsed=metadata.parseStandardShadowTextureShaderMetadata(response.metadata,stage);assert.equal(parsed.ok,true);
 report.positiveControls.push({kind:'actual-historical-2D-shader',stage,opcode,request,response,parsed});
}
const sources=new Set();
async function source(name){
 if(sources.has(name))return;sources.add(name);
 const body=await fs.readFile(path.join(repo,name));
 const destination=path.join(output,'source',name);await fs.mkdir(path.dirname(destination),{recursive:true});await fs.writeFile(destination,body);
 report.sources.push({path:name,bytes:body.length,sha256:sha(body)});
 if(name.endsWith('.mjs'))for(const match of body.toString().matchAll(/(?:from|import)\s*['"](\.\.?\/[^'"]+)['"]/g))await source(path.posix.normalize(path.posix.join(path.posix.dirname(name),match[1])));
}
for(const name of ['renderer/virgl-shader/standard.mjs','renderer/virgl-shader/standard_guard.c','renderer/virgl-shader/standard_guard.h','renderer/virgl-shader/standard_emit.c','renderer/virgl-shader/bridge.c','renderer/virgl-shader/bridge.h','renderer/virgl-shader/build/wasm/virgl-shader.mjs','renderer/virgl-shader/build/wasm/virgl-shader.wasm','renderer/virgl-command/constant-domain.mjs','renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs','renderer/virgl-command/resources.mjs','renderer/virgl-command/control-bridge.mjs','tools/virgl-dimensional-shaders/fixtures.mjs','tools/virgl-floating-depth-consumer/primary.json','tools/virgl-floating-depth-consumer/primary/src/mesa/state_tracker/st_sampler_view.c','tools/virgl-floating-depth-consumer/primary/vrend_renderer.c','renderer/virgl-shader/vendor/src/virgl_protocol.h'])await source(name);
const script=await fs.readFile(process.argv[1]);await fs.writeFile(path.join(output,'runner.mjs'),script);report.runner={bytes:script.length,sha256:sha(script)};
report.status='passed-negative-readiness';report.summary={positiveDimensionalCompilerResponses:report.shaderRows.length,consumerMetadataRefusals:report.shaderRows.length,originalViewRefusals:report.viewRows.length,positiveHistoricalControls:report.positiveControls.length};
await fs.writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report.summary));
