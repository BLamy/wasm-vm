import gzip,hashlib,io,json,shutil,subprocess,tarfile
from pathlib import Path
repo=Path.cwd();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='deb7b3113f9adeb2e6e80449a6710dd3295093ea'
source=Path('/tmp/wasmvm-dimensional-view-gap-deb7b311-final')
first=Path('/tmp/wasmvm-dimensional-view-gap-deb7b311')
assert json.loads((source/'report.json').read_bytes())['head']==head
shutil.copytree(first,source/'initial-recording')
for name in ['stack499-before.json','stack500-before.json','stack499-after.json','stack500-after.json','stack-continuity.json']:
 shutil.copyfile(first/name,source/name)
shutil.copyfile('/tmp/wasmvm-dimensional-shader-cold-cleanup.json',source/'owned-cold-cleanup.json')
for n in [499,500]:
 before=json.loads((source/f'stack{n}-before.json').read_bytes());after=json.loads((source/f'stack{n}-after.json').read_bytes())
 assert (before['id'],before['node_id'],before['base'])==(after['id'],after['node_id'],after['base'])
 keys=['id','number','node_id','head','base','state','draft','merged_at']
 for x,y in zip(before['pull_requests'],after['pull_requests']):assert {k:x[k] for k in keys}=={k:y[k] for k in keys}
 assert len(after['pull_requests'])==len(before['pull_requests'])+(n==500)
 assert all(p['state']=='open' and p['draft'] and p['merged_at'] is None for p in after['pull_requests'])
 if n==500:assert after['pull_requests'][-1]['number']==535 and after['pull_requests'][-1]['head']['sha']==head
out=repo/'evidence/virgl-production-readiness/dimensional-sampler-view-gap';assert not out.exists();out.mkdir(parents=True)
files={p.relative_to(source).as_posix():p for p in source.rglob('*') if p.is_file()};files['sealing/seal.py']=Path(__file__)
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[dict(path=n,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for n,p in sorted(files.items())]
raw=(json.dumps(dict(schema='dimensional-view-gap-index-v1',head=head,records=rows),indent=2)+'\n').encode();(out/'records.json').write_bytes(raw)
archive=out/'recording.tar.gz'
with archive.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
 for r in rows:
  body=files[r['path']].read_bytes();info=tarfile.TarInfo(r['path']);info.size,info.mode,info.mtime=len(body),0o644,0;tar.addfile(info,io.BytesIO(body))
with tarfile.open(archive,'r:gz') as tar:
 assert tar.getnames()==[r['path'] for r in rows]
 for r in rows:
  body=tar.extractfile(r['path']).read();assert len(body)==r['bytes'] and sha(body)==r['sha256']
manifest=dict(schema='dimensional-view-gap-seal-v1',head=head,records=len(rows),reopenedMembers=len(rows),recordIndexSha256=sha(raw),archiveSha256=sha(archive.read_bytes()),archiveBytes=archive.stat().st_size,summary=json.loads((source/'report.json').read_bytes())['summary'],previousPrsUnchanged=135,newPr=535,productionAuthority=False)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest));print('manifestSha256',sha((out/'manifest.json').read_bytes()))
