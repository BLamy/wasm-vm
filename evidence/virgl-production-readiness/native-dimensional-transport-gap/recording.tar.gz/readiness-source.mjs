
import { createVirglStandardShadowTextureShaderBridge } from '../../virgl-shader/standard.mjs';
import { checker, makeRig, header } from './submit-acceptance.mjs';
import { createStandardDimensionalResourceStore, createStandardDimensionalTransferBackend } from '../resources.mjs';
import { decodeStandardDimensionalSubmission, decodeStandardShadowSamplerSubmission } from '../decoder.mjs';
const copy=value=>JSON.parse(JSON.stringify(value,(_,v)=>v instanceof Uint8Array?[...v]:v));
const META=['id','target','format','bind','width','height','depth','arraySize','lastLevel','nrSamples','flags'];
export async function runDesktopAcceptance({WasmVirglSubmitProof,createVirglStandardDesktopSubmitBridge}) {
  const c=checker(),gl=document.querySelector('#gpu').getContext('webgl2',{antialias:false,failIfMajorPerformanceCaveat:true});
  c.truth(gl,'hardware WebGL2 context');
  const nativeCalls=[],objects=new WeakMap();let nextObject=1;
  const describe=value=>{
    if(value===null||typeof value!=='object')return value===undefined?{undefined:true}:value;
    if(ArrayBuffer.isView(value))return {type:value.constructor.name,bytes:[...new Uint8Array(value.buffer,value.byteOffset,value.byteLength)].map(v=>v.toString(16).padStart(2,'0')).join('')};
    if(!objects.has(value))objects.set(value,nextObject++);return {object:objects.get(value),type:value.constructor?.name??'object'};
  };
  const recordedGl=new Proxy(gl,{get(target,key){const value=Reflect.get(target,key,target);if(typeof value!=='function')return value;return(...args)=>{
    const before=args.map(describe),result=value.apply(target,args);nativeCalls.push({sequence:nativeCalls.length,name:key,before,after:args.map(describe),result:describe(result)});return result;
  };}});
  const limits={texture2D:recordedGl.getParameter(gl.MAX_TEXTURE_SIZE),texture3D:recordedGl.getParameter(gl.MAX_3D_TEXTURE_SIZE),
    cube:recordedGl.getParameter(gl.MAX_CUBE_MAP_TEXTURE_SIZE),arrayLayers:recordedGl.getParameter(gl.MAX_ARRAY_TEXTURE_LAYERS)};
  const shaderBridge=await createVirglStandardShadowTextureShaderBridge();
  const Selected=class {constructor(callback,enabled){return enabled?WasmVirglSubmitProof.standardDesktop(callback):new WasmVirglSubmitProof(callback,false);}};
  const base={format:67,bind:10,nrSamples:0,flags:0,lastLevel:2};
  const cases=[
    {name:'2D positive control',tgsi:'2D',admit:true,target:2,width:5,height:3,depth:1,arraySize:1},
    {name:'original 3D volume',tgsi:'3D',admit:false,target:3,width:5,height:3,depth:7,arraySize:1},
    {name:'original six-face cube',tgsi:'CUBE',admit:false,target:4,width:5,height:5,depth:1,arraySize:6},
    {name:'original 2D array',tgsi:'2D_ARRAY',admit:false,target:7,width:5,height:3,depth:1,arraySize:7}
  ],rows=[];
  window.__desktopProof={rows,nativeCalls,limits};
  for(let i=0;i<cases.length;i++) {
    const {name,tgsi,admit,...shape}=cases[i],id=100+i,m={id,...base,...shape};
    const rig=makeRig(Selected,createVirglStandardDesktopSubmitBridge,recordedGl,shaderBridge,c);
    window.__desktopActive=()=>({case:name,native:copy(rig.q.vm.inspect()),host:copy(rig.host.bridge.inspect()),records:rig.q.records,events:rig.events});
    const before={native:copy(rig.q.vm.inspect()),host:copy(rig.host.bridge.inspect()),events:rig.events.length,objects:rig.trace.objects.size};
    const raw=header(0x204,0,72),v=new DataView(raw.buffer);META.forEach((key,j)=>v.setUint32(24+j*4,m[key],true));
    const nativeRecord=await rig.expect(name+' native original resource',raw,admit?0x1100:0x1205);
    const nativeAfter=copy(rig.q.vm.inspect()),hostAfterNative=copy(rig.host.bridge.inspect());
    let hostEvent=null,hostResult=null;
    if(admit) {
      c.equal(hostAfterNative.resources.length,1,name+' qualified native-to-host allocation');
      c.truth(rig.events.length>before.events,name+' actual host callback');
    } else {
      c.same(nativeAfter,before.native,name+' native owner rollback');
      c.same(hostAfterNative,before.host,name+' host owner rollback');
      c.equal(rig.events.length,before.events,name+' no host callback before native refusal');
      c.equal(rig.trace.objects.size,before.objects,name+' no native allocation before refusal');
      hostEvent={type:'createResource',epoch:'0000000000000001',resource:{id,generation:'0000000000000001'},metadata:m};
      hostResult=rig.host.bridge.apply(hostEvent);
      c.equal(hostResult.ok,false,name+' host refuses original target');
      c.same(rig.host.bridge.inspect(),before.host,name+' host refusal rollback');
      c.equal(rig.trace.objects.size,before.objects,name+' no host allocation after refusal');
    }
    const backend=c.ok(createStandardDimensionalTransferBackend(recordedGl),'qualified dimensional backend').backend;
    const selected=c.ok(createStandardDimensionalResourceStore({backend}),'qualified dimensional store');
    const created=c.ok(selected.store.createResource(m),name+' verified host admission');
    c.equal(selected.store.inspect().resources.length,1,name+' selected host allocation');
    const selectedHost={created:copy(created),state:copy(selected.store.inspect())};
    c.ok(selected.store.dispose(),name+' selected host retirement');
    const commands=[];
    if(!admit) {
      const words=[(13<<16)|43,id,0,0,0,0,0,0,0,shape.width,shape.height,shape.target===3?shape.depth:shape.arraySize,0,1];
      const wire=new Uint8Array(words.length*4),view=new DataView(wire.buffer);
      words.forEach((word,j)=>view.setUint32(j*4,word,true));
      const legacy=decodeStandardShadowSamplerSubmission(wire),qualified=decodeStandardDimensionalSubmission(wire);
      c.equal(legacy.ok,false,name+' current native bridge consumer refuses layered transfer');
      c.equal(qualified.ok,true,name+' verified dimensional wire decoder admits');
      commands.push({words,wire:[...wire],legacy,qualified});
    }
    const shaders=[];
    for(const stage of ['vertex','fragment']) {
      const text=(stage==='vertex'?'VERT\nDCL OUT[0], POSITION\n':'FRAG\nDCL OUT[0], COLOR\n')+
        'DCL SAMP[3]\nDCL SVIEW[3], '+tgsi+', FLOAT\nIMM[0] FLT32 {1.0,0.5,0.25,0.0}\n0: TEX OUT[0], IMM[0], SAMP[3], '+tgsi+'\n1: END\n';
      const request={stage,text},result=shaderBridge.translate(request);c.equal(result.ok,admit,name+' original '+stage+' shader readiness');shaders.push({request,result});
    }
    rows.push({name,metadata:m,tgsi,admit,wire:[...raw],before,nativeRecord,nativeAfter,hostAfterNative,hostEvent,hostResult,
      hostAfter:copy(rig.host.bridge.inspect()),selectedHost,commands,shaders,guestTrace:rig.q.vm.commandTrace(),machineDigest:rig.q.vm.machineDigest(),nativeCallsEnd:nativeCalls.length});
    window.__desktopActive=null;rig.dispose();c.equal(rig.trace.objects.size,0,name+' hardware owners disposed');
  }
  c.equal(gl.getError(),gl.NO_ERROR,'final native GL error zero');
  const result={status:'passed',kind:'selected-native-dimensional-transport-negative-readiness',liveGuest3d:false,nativeGpuExecution:true,
    productionAuthority:false,rows,nativeCalls,limits,assertions:c.assertions};
  result.summary={status:result.status,positiveControl:rows[0].name,refusedShapes:rows.slice(1).map(r=>r.name),hostAdmittedShapes:rows.map(r=>r.name),layeredConsumerRefusals:rows.slice(1).reduce((n,r)=>n+r.commands.length,0),
    shaderRefusals:rows.slice(1).reduce((n,r)=>n+r.shaders.length,0),nativeCalls:nativeCalls.length,limits,liveGuest3d:false};
  return result;
}
