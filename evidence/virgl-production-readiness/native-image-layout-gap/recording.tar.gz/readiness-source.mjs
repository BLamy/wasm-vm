
import { createVirglStandardShadowTextureShaderBridge } from '../../virgl-shader/standard.mjs';
import { checker, makeRig, header } from './submit-acceptance.mjs';
const copy = value => JSON.parse(JSON.stringify(value,(_,v)=>v instanceof Uint8Array?[...v]:v));
const META=['id','target','format','bind','width','height','depth','arraySize','lastLevel','nrSamples','flags'];
export async function runDesktopAcceptance({WasmVirglSubmitProof,createVirglStandardDesktopSubmitBridge}) {
  const c=checker(), gl=document.querySelector('#gpu').getContext('webgl2',{antialias:false,failIfMajorPerformanceCaveat:true});
  c.truth(gl,'hardware WebGL2 context');
  const nativeCalls=[], objects=new WeakMap();let nextObject=1;
  const describe=value=>{
    if(value===null||typeof value!=='object')return value===undefined?{undefined:true}:value;
    if(ArrayBuffer.isView(value))return {type:value.constructor.name,bytes:[...new Uint8Array(value.buffer,value.byteOffset,value.byteLength)].map(v=>v.toString(16).padStart(2,'0')).join('')};
    if(!objects.has(value))objects.set(value,nextObject++);return {object:objects.get(value),type:value.constructor?.name??'object'};
  };
  const recordedGl=new Proxy(gl,{get(target,key){const value=Reflect.get(target,key,target);if(typeof value!=='function')return value;return(...args)=>{
    const before=args.map(describe),result=value.apply(target,args);nativeCalls.push({sequence:nativeCalls.length,name:key,before,after:args.map(describe),result:describe(result)});return result;
  };}});
  const shaderBridge=await createVirglStandardShadowTextureShaderBridge();
  const Selected=class {constructor(callback,enabled){return enabled?WasmVirglSubmitProof.standardDesktop(callback):new WasmVirglSubmitProof(callback,false);}};
  const cases=[{"name":"RGBA8 complete mip chain","target":2,"format":67,"bind":10,"width":8,"height":4,"depth":1,"arraySize":1,"lastLevel":3,"nrSamples":0,"flags":0},{"name":"RG8 plane","target":2,"format":65,"bind":10,"width":3,"height":2,"depth":1,"arraySize":1,"lastLevel":0,"nrSamples":0,"flags":0},{"name":"RGB8 plane","target":2,"format":66,"bind":10,"width":3,"height":2,"depth":1,"arraySize":1,"lastLevel":0,"nrSamples":0,"flags":0},{"name":"floating RGBA plane","target":2,"format":31,"bind":10,"width":3,"height":2,"depth":1,"arraySize":1,"lastLevel":0,"nrSamples":0,"flags":0},{"name":"Z16 depth plane","target":2,"format":16,"bind":1,"width":3,"height":2,"depth":1,"arraySize":1,"lastLevel":0,"nrSamples":0,"flags":0}], rows=[]; window.__desktopProof={rows,nativeCalls};
  for(let i=0;i<cases.length;i++) {
    const {name,...shape}=cases[i], id=100+i,m={id,...shape};
    const rig=makeRig(Selected,createVirglStandardDesktopSubmitBridge,recordedGl,shaderBridge,c);
    window.__desktopActive=()=>({case:name,native:copy(rig.q.vm.inspect()),host:copy(rig.host.bridge.inspect()),records:rig.q.records,events:rig.events});
    const before={native:copy(rig.q.vm.inspect()),host:copy(rig.host.bridge.inspect()),events:rig.events.length,objects:rig.trace.objects.size};
    const raw=header(0x204,0,72),v=new DataView(raw.buffer);
    META.forEach((key,j)=>v.setUint32(24+j*4,m[key],true));
    const record=await rig.expect(name+' native resource refusal',raw,0x1205);
    c.same(rig.q.vm.inspect(),before.native,name+' native owner state unchanged');
    c.same(rig.host.bridge.inspect(),before.host,name+' host owner state unchanged');
    c.equal(rig.events.length,before.events,name+' no host callback before native refusal');
    c.equal(rig.trace.objects.size,before.objects,name+' no native GPU allocation before refusal');
    const hostEvent={type:'createResource',epoch:'0000000000000001',resource:{id,generation:'0000000000000001'},metadata:m};
    const hostResult=rig.host.bridge.apply(hostEvent);
    c.ok(hostResult,name+' qualified host allocation');
    const after=copy(rig.host.bridge.inspect());
    c.equal(after.resources.length,1,name+' one host allocation');
    rows.push({name,metadata:m,wire:[...raw],before,nativeRecord:record,nativeAfter:copy(rig.q.vm.inspect()),hostEvent,hostResult,hostAfter:after,
      guestTrace:rig.q.vm.commandTrace(),machineDigest:rig.q.vm.machineDigest(),nativeCallsEnd:nativeCalls.length});
    window.__desktopActive=null; rig.dispose();
    c.equal(rig.trace.objects.size,0,name+' hardware resources disposed');
  }
  c.equal(gl.getError(),gl.NO_ERROR,'final native GL error zero');
  const result={status:'passed',kind:'selected-native-storage-negative-readiness',liveGuest3d:false,nativeGpuExecution:true,productionAuthority:false,rows,nativeCalls,assertions:c.assertions};
  result.summary={status:result.status,refusedNativeShapes:rows.map(r=>r.name),positiveHostShapes:rows.length,nativeCalls:nativeCalls.length,liveGuest3d:false};
  return result;
}
