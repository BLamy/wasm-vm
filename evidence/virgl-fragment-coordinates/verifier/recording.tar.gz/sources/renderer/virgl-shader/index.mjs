export const LIMITS = Object.freeze({
  textBytes: 49152,
  tokens: 8192,
  glslBytes: 262144,
  instructions: 768,
  registerIndex: 7,
  temporaryRegisterIndex: 511,
  constantRegisterIndex: 45,
  immediateRegisterIndex: 31,
  conditionalDepth: 16,
  lines: 1536,
  lineBytes: 512,
});

const failure = (code, message) => ({ ok: false, error: { code, message } });

/** Create an isolated compiler instance. Each translate result owns its JS
 * strings/metadata; no views into Wasm memory escape. The Wasm API is synchronous
 * and calls are serialized by the JavaScript event loop. */
export async function createVirglShaderBridge(options = {}) {
  const { default: createModule } = await import("./build/wasm/virgl-shader.mjs");
  const module = await createModule(options);
  return Object.freeze({
    translatePair(request) {
      let vertexText, fragmentText;
      try {
        if (!request || typeof request !== "object" || Array.isArray(request)) {
          return failure("invalid-input", "Provide vertexText and fragmentText own string fields.");
        }
        const keys = Reflect.ownKeys(request);
        if (keys.some((key) => key !== "vertexText" && key !== "fragmentText")) {
          return failure("unsupported-feature", "This profile does not accept shader-key overrides.");
        }
        const vertex = Object.getOwnPropertyDescriptor(request, "vertexText");
        const fragment = Object.getOwnPropertyDescriptor(request, "fragmentText");
        if (keys.length !== 2 || !vertex || !fragment || !("value" in vertex) || !("value" in fragment) ||
            typeof vertex.value !== "string" || typeof fragment.value !== "string") {
          return failure("invalid-input", "Provide vertexText and fragmentText own string fields.");
        }
        vertexText = vertex.value; fragmentText = fragment.value;
      } catch {
        return failure("invalid-input", "Pair request reflection failed.");
      }
      for (const text of [vertexText, fragmentText]) {
        if (text.length > LIMITS.textBytes) return failure("input-too-large", "TGSI text exceeds 49152 bytes.");
        if (/[^\x09\x0a\x0d\x20-\x7e]/.test(text)) {
          return failure("invalid-input", "TGSI must be printable ASCII without NUL bytes.");
        }
      }
      const vertex = module._malloc(vertexText.length + 1);
      if (!vertex) return failure("allocation-failed", "Wasm input allocation failed.");
      let fragment = 0;
      try {
        fragment = module._malloc(fragmentText.length + 1);
        if (!fragment) return failure("allocation-failed", "Wasm input allocation failed.");
        for (const [ptr, text] of [[vertex, vertexText], [fragment, fragmentText]]) {
          for (let i = 0; i < text.length; ++i) module.HEAPU8[ptr + i] = text.charCodeAt(i);
          module.HEAPU8[ptr + text.length] = 0;
        }
        const result = module._bridge_translate_pair(vertex, vertexText.length, fragment, fragmentText.length);
        return JSON.parse(module.UTF8ToString(result));
      } finally {
        if (fragment) module._free(fragment);
        module._free(vertex);
      }
    },
    translate(request) {
      if (!request || typeof request !== "object" || typeof request.text !== "string") {
        return failure("invalid-input", "Provide a stage and TGSI text string.");
      }
      const { stage, text } = request;
      if (stage !== "vertex" && stage !== "fragment") {
        return failure("unsupported-stage", "Only vertex and fragment stages are supported.");
      }
      if (Object.keys(request).some((key) => key !== "stage" && key !== "text")) {
        return failure("unsupported-feature", "This profile does not accept shader-key overrides.");
      }
      if (text.length > LIMITS.textBytes) return failure("input-too-large", "TGSI text exceeds 49152 bytes.");
      if (/[^\x09\x0a\x0d\x20-\x7e]/.test(text)) {
        return failure("invalid-input", "TGSI must be printable ASCII without NUL bytes.");
      }
      const ptr = module._malloc(text.length + 1);
      if (!ptr) return failure("allocation-failed", "Wasm input allocation failed.");
      try {
        for (let i = 0; i < text.length; ++i) module.HEAPU8[ptr + i] = text.charCodeAt(i);
        module.HEAPU8[ptr + text.length] = 0;
        const result = module._bridge_translate(stage === "vertex" ? 0 : 1, ptr, text.length);
        return JSON.parse(module.UTF8ToString(result));
      } finally {
        module._free(ptr);
      }
    },
  });
}
