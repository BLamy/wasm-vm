#!/usr/bin/env python3
"""Bind the actual critic outcomes; never replace the pre-observation plan."""
import hashlib
import json
from fractions import Fraction
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
RAW = ROOT / 'target/evidence/virgl-fragment-coordinates-critic-current'
RUNTIME = 'c947442bad912ebcd46d3ff30a0e4c71be87ca4a'
PROMOTION = '0eb794639b408c80aa6f35688bf85e15a433a845'
RUNTIME_PATHS = ['renderer/virgl-shader/bridge.c', 'renderer/virgl-shader/raw_bits.c',
                 'renderer/virgl-shader/raw_bits.h', 'renderer/virgl-command/constant-domain.mjs',
                 'renderer/virgl-command/state.mjs']

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def point(name, pointer='', worker=False, acceptance=False):
    path = (OUT / 'unpacked' / name) if worker else (RAW / name if acceptance else OUT / name)
    prefix = 'worker-recording/' if worker else 'acceptance/' if acceptance else 'critic/'
    return dict(path=prefix + name, pointer=pointer, sha256=sha(path))

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == PROMOTION
bindings = []
for path in RUNTIME_PATHS:
    original = subprocess.check_output(['git', 'show', RUNTIME + ':' + path], cwd=ROOT)
    assert original == (ROOT / path).read_bytes(), path
    bindings.append(dict(path=path, sha256=sha(ROOT / path), bytes=len(original)))

coverage = read(OUT / 'coverage-audit.json')
waivers = {
    ('renderer/virgl-shader/bridge.c', 988): 'Comment only; the fixed COLOR0 check executes on lines 987 and 989.',
    ('renderer/virgl-shader/bridge.c', 1013): 'Comment only; the direct MOV return expression executes on line 1014.',
    ('renderer/virgl-shader/bridge.c', 1334): 'Comment only; GENERIC enumeration and pair matching execute on lines 1343, 1351 and 1363.',
    ('renderer/virgl-shader/bridge.c', 1531): 'Function signature has no LLVM instruction region. The original coordinate_contract body region 1532:1-1534:2 executes 1138 times in each original profile.',
    ('renderer/virgl-shader/bridge.c', 1535): 'Blank separator after the executed coordinate_contract body.',
    ('renderer/virgl-shader/raw_bits.h', 36): 'Comment only; no executable code.',
    ('renderer/virgl-shader/raw_bits.h', 37): 'Compile-time feature bit definition; consumers at bridge.c:1014, 1387 and 1577 are executed. Native/Wasm v38 descriptors agree.',
    ('renderer/virgl-shader/raw_bits.h', 38): 'Compile-time opcode/feature separation assertion; original hot/cold native and Wasm compilation passes. It generates no executable region.',
    ('renderer/virgl-shader/raw_bits.h', 153): 'Struct field declaration; property reads/writes are covered at bridge.c:981-985 and 1009. Complete native/Wasm descriptors agree.',
}
review = [(row['path'], row['line']) for row in coverage['lines'] if row['classification'] in {'REVIEW', 'WAIVED'}]
assert set(review) == set(waivers)
functions = []
for prefix in ['hot', 'cold-acceptance']:
    export = read(OUT / (prefix + '-coverage-reexport.json'))
    found = [f for d in export['data'] for f in d['functions'] if f['name'] == 'bridge.c:coordinate_contract']
    assert len(found) == 1 and found[0]['count'] == 1138
    functions.append(dict(record=prefix + '-coverage-reexport.json', sha256=sha(OUT / (prefix + '-coverage-reexport.json')),
                          name=found[0]['name'], count=1138, regions=found[0]['regions']))
for row in coverage['lines']:
    if row['classification'] in {'REVIEW', 'WAIVED'}:
        row['classification'] = 'WAIVED'
        row['reason'] = waivers[(row['path'], row['line'])]
coverage.update(status='passed', executedLines=118, waivedLines=9, unprovenExecutableLines=0,
                functionSignatureEvidence=functions, runtimeBindings=bindings)
assert sum(row['classification'] == 'EXECUTED' for row in coverage['lines']) == 118
write('coverage-audit.json', coverage)

primary = read(OUT / 'unpacked/generated/coordinate-primary.json')
assert len(primary) == 285
for row in primary:
    witness = row['primary']
    position = [d for d in witness['declarations'] if d['semantic'] == 0]
    assert position == [dict(index=0, last=0, semantic=0, semanticIndex=0, mask=15, interpolation=1)]
    assert [p for p in witness['properties'] if p['name'] == 3] == [dict(name=3, value=1)]
    assert [p for p in witness['properties'] if p['name'] == 4] == [dict(name=4, value=0)]
    assert witness['interstageCount'] == sum(d['semantic'] == 5 for d in witness['declarations'])
    assert witness['lowerLeftKey'] == 1 and 'gl_FragCoord' in witness['glsl']
original = 'evidence/virgl-workload-inventory/captures/es2gears/shaders/c5806d5f8fd74bf2d3ce5ccf32bdc255ec13ad9447eec5896a3c96a591a5c68f.tgsi'
lines = (ROOT / original).read_text().splitlines()
assert sha(ROOT / original) == Path(original).stem
assert lines[:4] == ['FRAG', 'PROPERTY FS_COORD_ORIGIN LOWER_LEFT', 'PROPERTY FS_COORD_PIXEL_CENTER HALF_INTEGER', 'DCL IN[0], POSITION, LINEAR']
vendor = 'renderer/virgl-shader/vendor/src/vrend/vrend_shader.c'
tokens = 'renderer/virgl-shader/vendor/src/gallium/include/pipe/p_shader_tokens.h'
write('source-semantics.json', dict(status='passed', original=dict(path=original, sha256=sha(ROOT / original), headerLines=[1, 2, 3, 4], coordinateUses=[22, 29]),
    primaryWitnesses=285, primaryPoint=point('generated/coordinate-primary.json', '/0/primary', worker=True),
    vendor=dict(path=vendor, sha256=sha(ROOT / vendor), positionLines=[1519, 1535], propertyLines=[2039, 2044], glesBuiltinLines=[7247, 7263]),
    tokenDefinitions=dict(path=tokens, sha256=sha(ROOT / tokens), interpolationLine=111, positionLine=175, propertyLines=[303,304], originLines=[340,341], centerLines=[345,346]),
    primaryDocumentation=[dict(url='https://docs.mesa3d.org/gallium/tgsi.html', sections=['TGSI_SEMANTIC_POSITION','FS_COORD_ORIGIN','FS_COORD_PIXEL_CENTER']),
                          dict(url='https://registry.khronos.org/OpenGL/specs/es/3.0/GLSL_ES_Specification_3.00.pdf', section='7.2', pdfPage=88, printedPage=82)],
    interpretation='Original explicit lower-left/half-integer POSITION corresponds to intrinsic highp gl_FragCoord window x/y/z and reciprocal clip-w. The property does not choose a different raster sample center. GENERIC exports stay separate.'))

receipt = read(RAW / 'receipt.json')
assert receipt['status'] == 'passed' and receipt['gitHead'] == PROMOTION and receipt['checkedPixels'] == 495128
for artifact in receipt['sources']:
    assert sha(ROOT / artifact['path']) == artifact['sha256'], artifact['path']
for artifact in receipt['records']:
    assert sha(RAW / artifact['path']) == artifact['sha256'], artifact['path']
fresh = read(OUT / 'gpu-3737844652/report.json')
assert fresh['status'] == 'passed' and fresh['gitHead'] == PROMOTION and fresh['trackedChanges'] == []
assert fresh['browserErrors'] == dict(console=[], page=[], requests=[])
for entry in fresh['sources'] + fresh['servedFiles']:
    assert sha(ROOT / entry['path']) == entry['sha256'], entry['path']
assert fresh['browser']['launch']['headless'] is False
assert fresh['browser']['gpu']['auxAttributes']['displayType'] == 'ANGLE_METAL'
assert 'Apple M4 Max' in fresh['acceptance']['renderer']['renderer']
assert fresh['acceptance']['checkedPixels'] == 162568 and fresh['acceptance']['objects'] == dict(created=8173, live=0)
assert all(c['commandsPerStep'] == 2 for c in fresh['acceptance']['consumers'])
assert sha(OUT / 'gpu-3737844652/browser.png') == fresh['screenshot']['sha256']
assert sha(OUT / 'gpu-3737844652/browser-coverage.json') == fresh['browserCoverage']['sha256']
guard = read(RAW / 'independent-coordinate-guards.json')
assert guard['status'] == 'passed' and guard['cases'] == 380 and guard['metadataAttacks'] == 32 and guard['bankAttacks'] == 480 and guard['getterInvocations'] == 0
write('final-acceptance.json', dict(status='passed', command='VIRGL_COORDINATE_EVIDENCE_DIR=target/evidence/virgl-fragment-coordinates-critic-current make verify-E6-T12g6k',
    sourceHead=PROMOTION, unchangedRuntime=RUNTIME, receipt=point('receipt.json', acceptance=True), checkedWords=495128,
    independentCases=380, metadataAttacks=32, bankAttacks=480, getterInvocations=0,
    freshReport=point('gpu-3737844652/report.json'), freshCapture=point('fourth-capture.json'), freshSeed=3737844652,
    commandsPerStep=2, freshCheckedWords=162568, freshRejections=48, freshSourceBindings=len(fresh['sources']),
    freshServedBindings=len(fresh['servedFiles']), trackedChanges=[], runtimeBindings=bindings))

audits = [read(OUT / name) for name in ['hot-capture-2654435769.json','hot-capture-gpu-608135816.json','hot-capture-gpu-2242054355.json','fourth-capture.json']]
assert all(a['status'] == 'passed' and a['fault'] is None for a in audits)
maximum = max(((Fraction(t['maximumAbsoluteError']), a['seed'], t) for a in audits for t in a['transcript']), key=lambda x:x[0])
assert maximum[0] == Fraction(1, 2**21)
for name in ['authentication.json','carry-forward.json','native-replays.json','sabotage.json']:
    assert read(OUT / name)['status'] == 'passed'

predictions = [
    ('P1', 'All 127 safe unique worker members and 795 source bindings authenticate; distinct actual hot/cold binaries and profiles match their indexes.', [point('authentication.json','/members'), point('native-replays.json','/records')]),
    ('P2', 'Literal original header, 285 unmodified Mesa token/GLSL witnesses, pinned properties and primary TGSI/ESSL conventions agree.', [point('source-semantics.json'), point('generated/coordinate-primary.json','/0/primary',worker=True)]),
    ('P3', 'Original and reordered headers accept; unsupported conventions and numerical authority laundering reject in 380 complete independent native/Wasm singles and pairs. Original complete bodies retain their admission results.', [point('independent-coordinate-guards.json','/native',acceptance=True), point('carry-forward.json','/rejectedCompleteBodies')]),
    ('P4', 'Strict inert v38 wrapper retains all simultaneous underlying obligations; 561 original metadata forgeries plus 32 independent metadata attacks invoke zero getters; four combined probes and 480 independent bank cases preserve owned copies and restrictions.', [point('hot/consumer.json','/combined',worker=True), point('independent-coordinate-guards.json','/banks',acceptance=True)]),
    ('P5', 'POSITION never becomes a GENERIC producer obligation; POSITION+GENERIC0/7 pairs bind the exact convention suffix, and actual forged source/pair/convention selectors reject atomically.', [point('independent-coordinate-guards.json','/native',acceptance=True), point('gpu-3737844652/report.json','/acceptance/consumers/0/pairRequests')]),
    ('P6', 'Independent determinant barycentrics and literal clip geometry check 657696 complete words across four distinct seeds. Exact XY/dyadic cases hold; maximum variable-derived absolute error is 2^-21 within 2^-20; every outside viewport sentinel holds.', [point('hot-capture-2654435769.json','/transcript/294'), point('fourth-capture.json','/transcript/294')]),
    ('P7', 'Forward literal TGSI source execution snapshots every operand before masked destination writes. Reverse aliases, saved/live/killed lane versions, copied/raw/numeric uses and UIF agree with physical words and 300 independent conversion/transcendental version guards.', [point('fourth-capture.json','/transcript'), point('independent-coordinate-guards.json','/predictions',acceptance=True)]),
    ('P8', 'Headed WebGL2 on physical Apple M4 Max Metal compiles/links both implementations, reflects no FragCoord uniform, maps COLOR0 to zero and disposes all 8173 created objects with zero errors.', [point('gpu-3737844652/report.json','/browser'), point('gpu-3737844652/report.json','/acceptance/events'), point('fourth-capture.json','/nativeObjects')]),
    ('P9', 'Both actual indexed consumers restore poisoned raster/viewport/depth state, own poisoned packets, and reproduce A/B/A source predictions. Each rejects 24 attacks; asynchronous completion-fence-only events stay bounded; all final budgets are zero.', [point('gpu-3737844652/report.json','/acceptance/consumers'), point('fourth-capture.json','/rejections')]),
    ('P10', 'Every original hot/cold X/Y/Z/W emitted-source fault contradicts the independent original pixel prediction. Isolated actual runtime source admission, promoted-test metadata expectation, and jointly forged pixel/cache word each cause the intended deterministic failure.', [point('hot-capture-fault-x.json','/transcript/0/failurePoints'), point('hot-capture-fault-w.json','/transcript'), point('sabotage.json','/records')]),
    ('P11', '118 of 127 changed runtime lines execute in authenticated original LLVM/V8/Node recordings; nine nonexecuting comments, declaration/macro/static-assert/signature lines have individual reasons. Zero executable gap. Ten unchanged predecessor HELD predictions carry by boundary and digest.', [point('coverage-audit.json','/lines'), point('carry-forward.json','/priorVerdict/predictions')]),
    ('P12', 'The authenticated pristine c947442b clone passes the same acceptance command with scrubbed environment and clean before/after status. Promotions only alter the harness/tests; portability proof carries without another clone.', [point('authentication.json','/cold'), point('final-acceptance.json')]),
    ('P13', 'Novel eight-register POSITION+GENERIC0/7, missing producer/ninth-register, masked version, signed-zero/subnormal/nonfinite bank and inert metadata attacks hold. Fresh seed 3737844652 with step size two checks 162568 words and 48 actual rejections.', [point('independent-coordinate-guards.json','/predictions',acceptance=True), point('fourth-command.json'), point('fourth-capture.json')]),
]
write('verdict.json', dict(schema='virgl-fragment-coordinate-critic-verdict-v1', task='E6-T12g6k', verdict='verified',
    prerequisite='574d633c17c7436545195c63e534d9fa7859ac74', frozenRuntime=RUNTIME, workerSubmissionHead='c72a5ead0aa67e3ba51fd99923d4df29d6f09abd', criticGuardHead=PROMOTION,
    predictionsMadeBeforeInspection=True, predictionsSha256=sha(OUT / 'predictions.md'),
    predictions=[dict(id=i,status='HELD',observed=o,citations=c) for i,o,c in predictions],
    changedRuntimeLines=127, executedRuntimeLines=118, individuallyWaivedLines=9, unprovenExecutableLines=0,
    carriedPredecessorPredictions=10, independentNativeWasmCases=380, independentMetadataAttacks=32, independentBankCases=480,
    uniquePhysicalSeeds=[a['seed'] for a in audits], uniqueScheduleComponentWords=sum(a['totalPixels'] for a in audits),
    maximumObservedAbsoluteError=str(maximum[0]), measuredAbsoluteBudget='1/1048576',
    maximumPoint=dict(seed=maximum[1], reportPointer=maximum[2]['pointer'], rawSha256=maximum[2]['rawSha256'], point=maximum[2]['maximumPoint']),
    coldProofCarried=True, productionNegotiation=False, guestExecution=False,
    suite=['tools/virgl-fragment-coordinates/independent-guards.mjs','tools/virgl-fragment-coordinates/capture-check.py','make verify-E6-T12g6k'],
    qualifications=['Physical accuracy is measured for this headed Chrome/Apple M4 Max Metal configuration, not a portable guarantee.',
                    'The synthetic combined ports and copied-bank probe preserve underlying obligations; they do not admit the original full compositor bodies.',
                    'No production GPU capability, public/demo imports, live guest integration, FPS or MIPS claim is made.']))
print('13 HELD predictions; original coverage complete; final acceptance and fresh physical bindings authenticate.')
