#!/usr/bin/env python3
"""Re-export original binaries/profiles and map the runtime diff to real hits."""
import bisect
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
UNPACKED = OUT/'unpacked'
BASE = '574d633c17c7436545195c63e534d9fa7859ac74'
HEAD = 'c947442bad912ebcd46d3ff30a0e4c71be87ca4a'
RUNTIME = ['renderer/virgl-shader/bridge.c','renderer/virgl-shader/raw_bits.c',
           'renderer/virgl-shader/raw_bits.h','renderer/virgl-command/constant-domain.mjs',
           'renderer/virgl-command/state.mjs']

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def check(value, label):
    if not value:
        raise AssertionError(label)

def added_lines():
    diff = subprocess.check_output(['git','diff','--unified=0',BASE,HEAD,'--',*RUNTIME],cwd=ROOT,text=True)
    filename = None
    added = {}
    line = 0
    for text in diff.splitlines():
        if text.startswith('+++ b/'):
            filename = text[6:]
            added[filename] = []
        elif text.startswith('@@'):
            line = int(re.search(r'\+(\d+)',text)[1])
        elif text.startswith('+') and filename:
            added[filename].append((line,text[1:]))
            line += 1
        elif text.startswith(' ') and filename:
            line += 1
    return added

def filtered(export):
    for data in export['data']:
        data['files']=[f for f in data['files'] if any(f['filename'].endswith('/'+n) for n in
                         ['bridge.c','raw_bits.c','native_tests/fragment_coordinates.c'])]
        data['functions']=[f for f in data['functions'] if any(any(p.endswith('/'+n) for n in
                             ['bridge.c','raw_bits.c','native_tests/fragment_coordinates.c']) for p in f['filenames'])]
    return export

def native_counts(segments, line):
    # LLVM segments describe half-open intervals. Count only non-gap measured
    # intervals actually overlapping this source line; do not borrow a function
    # entry's count across a zero-count subregion.
    counts=[]
    for current,nxt in zip(segments,segments[1:]+[[10**9,1,0,False,False,False]]):
        if current[0]>line:
            break
        if current[3] and not current[5] and current[0]<=line<=nxt[0] and not (nxt[0]==line and nxt[1]==1):
            counts.append(current[2])
    return max(counts,default=None)

def js_count(functions, position):
    hits=[]
    for function in functions:
        containing=[r for r in function['ranges'] if r['startOffset']<=position<r['endOffset']]
        if containing:
            leaf=min(containing,key=lambda r:r['endOffset']-r['startOffset'])
            hits.append((leaf['endOffset']-leaf['startOffset'],leaf['count'],function.get('functionName','')))
    return min(hits)[1] if hits else None

def main():
    native={}
    original_bindings=[]
    for prefix,generated in [('hot','generated'),('cold/acceptance','cold-generated')]:
        binary=UNPACKED/generated/'coordinate-sanitize/coordinate-test'
        raw_profile=UNPACKED/prefix/'native/native.profraw'
        merged=OUT/(prefix.replace('/','-')+'-original.profdata')
        subprocess.check_call(['xcrun','llvm-profdata','merge','-sparse',str(raw_profile),'-o',str(merged)])
        result=subprocess.check_output(['xcrun','llvm-cov','export',str(binary),'-instr-profile='+str(merged)])
        export=filtered(json.loads(result))
        recorded=json.loads((UNPACKED/prefix/'native/coverage.json').read_bytes())
        check(export==recorded,'authentic original coverage re-export '+prefix)
        destination=OUT/(prefix.replace('/','-')+'-coverage-reexport.json')
        destination.write_text(json.dumps(export,indent=2)+'\n')
        original_bindings.append(dict(prefix=prefix,binarySha256=sha(binary.read_bytes()),
                                     rawProfileSha256=sha(raw_profile.read_bytes()),
                                     exportSha256=sha(destination.read_bytes())))
        for data in export['data']:
            for f in data['files']:
                for filename in RUNTIME:
                    if f['filename'].endswith('/'+filename):
                        native.setdefault(filename,[]).append((prefix,f['segments']))
    js={}
    for recording in sorted(UNPACKED.glob('**/browser-coverage.json')):
        for script in json.loads(recording.read_bytes())['scripts']:
            filename=script['source']
            if filename in RUNTIME:
                source=subprocess.check_output(['git','show',HEAD+':'+filename],cwd=ROOT)
                check(sha(source)==script['sha256'],'V8 source digest '+filename)
                js.setdefault(filename,[]).append((str(recording.relative_to(UNPACKED)),script['coverage']['functions']))
    for recording in sorted(UNPACKED.glob('**/node-consumer-coverage/*.json')):
        for script in json.loads(recording.read_bytes())['result']:
            for filename in RUNTIME:
                if script['url'].endswith('/'+filename):
                    js.setdefault(filename,[]).append((str(recording.relative_to(UNPACKED)),script['functions']))
    observations=[]
    for filename,lines in added_lines().items():
        source=subprocess.check_output(['git','show',HEAD+':'+filename],cwd=ROOT).decode()
        starts=[0]
        for line in source.splitlines(keepends=True):
            starts.append(starts[-1]+len(line.encode('utf-16-le'))//2)
        for number,text in lines:
            stripped=text.strip()
            row=dict(path=filename,line=number,text=text,sourceSha256=sha(source.encode()),hits=[])
            if filename.endswith('.c'):
                row['hits']=[dict(record=p,count=native_counts(s,number)) for p,s in native.get(filename,[])]
            elif filename.endswith('.mjs'):
                position=starts[number-1]+len(text)-len(text.lstrip())
                row['hits']=[dict(record=p,count=js_count(f,position)) for p,f in js.get(filename,[])]
            row['maximumCount']=max((h['count'] for h in row['hits'] if h['count']is not None),default=None)
            row['classification']='EXECUTED' if row['maximumCount'] and row['maximumCount']>0 else 'REVIEW'
            observations.append(row)
    report=dict(schema='fragment-coordinate-critic-coverage-v1',status='review',sourceHead=HEAD,base=BASE,
                originalProfileBindings=original_bindings,changedLines=len(observations),lines=observations)
    (OUT/'coverage-audit.json').write_text(json.dumps(report,indent=2)+'\n')
    for row in observations:
        if row['classification']=='REVIEW':
            print(f'{row["path"]}:{row["line"]}: count={row["maximumCount"]} {row["text"]}')
    print(f'{len(observations)} changed runtime lines mapped; original hot/cold exports match exactly.')

if __name__=='__main__':
    main()
