#!/usr/bin/env python3
"""Authenticate predecessor proofs and compare unchanged complete responses."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent

def sha(raw):return hashlib.sha256(raw).hexdigest()

def authenticate(directory):
    m=json.loads((directory/'manifest.json').read_bytes())
    index_raw=(directory/'records.json').read_bytes();archive=directory/m['archive']['path']
    assert sha(index_raw)==m['recordIndex']['sha256'] and sha(archive.read_bytes())==m['archive']['sha256']
    records=json.loads(index_raw)['records'];indexed={r['path']:r for r in records};assert len(indexed)==len(records)==m['records']
    found={}
    with tarfile.open(archive)as tar:
        for member in tar:
            assert member.isfile()and not member.name.startswith('/')and '..'not in Path(member.name).parts and member.name not in found
            raw=tar.extractfile(member).read();row=indexed[member.name];assert len(raw)==row['bytes']and sha(raw)==row['sha256'];found[member.name]=raw
    assert set(found)==set(indexed)
    return m,indexed,found

def main():
    critic,critic_index,c=authenticate(ROOT/'evidence/virgl-power/verifier')
    assert critic['verdict']=='verified' and critic['archive']['sha256']=='587e4a7e29d643d241a8db44f9021ad7d79dfe9f05ec8cfa0888871efb026394'
    assert sha(c['verdict.json'])==critic['verdictSha256']
    verdict=json.loads(c['verdict.json'])
    worker,worker_index,w=authenticate(ROOT/'evidence/virgl-power/worker')
    assert critic['workerArchiveSha256']==worker['archive']['sha256']and critic['workerRecordIndexSha256']==worker['recordIndex']['sha256']
    predecessor=json.loads(w['hot/retained/report.json'])
    current=json.loads((OUT/'unpacked/hot/retained/report.json').read_bytes())
    assert predecessor['originals']==current['originals']and predecessor['historical']==current['historical']and current['changedRejections']==[]
    old_native=json.loads(w['hot/native/report.json'])
    old_held=json.loads(w['hot/legacy.json'])
    legacy=json.loads((OUT/'unpacked/hot/legacy.json').read_bytes())
    expected=[]
    for kind,cases in [('power',old_native['cases']),('held',old_held['cases'])]:
        for case in cases:
            result=case['result']if kind=='power'else case['old']
            expected.append(dict(name=kind+'/'+case['name'],stage=case['stage'],textSha256=sha(case['text'].encode()),resultSha256=sha(json.dumps(result,separators=(',',':'),ensure_ascii=False).encode()),ok=result['ok']))
    assert len(expected)==8034 and expected==legacy['cases']
    runtime=['renderer/virgl-shader/bridge.c','renderer/virgl-shader/raw_bits.c','renderer/virgl-shader/raw_bits.h','renderer/virgl-command/state.mjs','renderer/virgl-command/constant-domain.mjs']
    root_base='574d633c17c7436545195c63e534d9fa7859ac74'
    # Earlier final verification changed tests and proof wiring, not runtime.
    before_runtime=[p for p in subprocess.check_output(['git','diff','--name-only',critic['frozenRuntime'],root_base],cwd=ROOT,text=True).splitlines()if p in runtime]
    assert before_runtime==[]
    guard_counts={}
    for path in (OUT/'unpacked/hot').glob('independent-*-guards.json'):
        r=json.loads(path.read_bytes());assert r['status']=='passed'and len(r['native'])==len(r['wasm'])==r['cases'];guard_counts[path.name]=r['cases']
    assert sum(guard_counts.values())==17170
    result=dict(schema='fragment-coordinate-carried-proof-v1',status='passed',base=root_base,
                priorCriticManifest=critic,authenticatedPriorCriticMembers=len(critic_index),authenticatedPriorWorkerMembers=len(worker_index),
                priorVerdict=verdict,retainedOriginals=len(current['originals']),retainedHistorical=len(current['historical']),
                completeLegacyResponses=8034,promotedPredecessorGuards=guard_counts,
                rejectedCompleteBodies=[r['path']for r in current['originals']if not r['native']['ok']],
                priorVerificationRuntimeChanges=before_runtime,
                pointBindings=[critic_index['verdict.json'],worker_index['hot/retained/report.json'],worker_index['hot/native/report.json'],worker_index['hot/legacy.json']])
    (OUT/'carry-forward.json').write_text(json.dumps(result,indent=2)+'\n')
    print('Authenticated and carried 118 critic members, 8034 complete prior responses, 17170 guards and unchanged full-body gates.')

if __name__=='__main__':main()
