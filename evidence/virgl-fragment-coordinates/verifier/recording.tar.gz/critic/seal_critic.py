#!/usr/bin/env python3
"""Seal the actual critic artifacts, both original coverage binaries and rerun."""
import gzip
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
RAW = ROOT / 'target/evidence/virgl-fragment-coordinates-critic-current'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def binding(path):
    return dict(path=path.name, bytes=path.stat().st_size, sha256=digest(path))

def load(path):
    return json.loads(path.read_text())

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

members = {}
def include(path, name):
    assert path.is_file() and not path.is_symlink(), path
    assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
    members[name] = path

for path in OUT.rglob('*'):
    relative = path.relative_to(OUT)
    if not path.is_file() or relative.parts[0] in {'unpacked', '__pycache__'}:
        continue
    if str(relative).startswith('sabotage/source/'):
        continue
    if relative.name in {'README.md','manifest.json','records.json','recording.tar.gz','baseline-untracked.json'}:
        continue
    include(path, 'critic/' + str(relative))
for path in RAW.rglob('*'):
    if path.is_file() and '__pycache__' not in path.parts:
        include(path, 'acceptance/' + str(path.relative_to(RAW)))

for prefix, generated in [('hot','generated'), ('cold/acceptance','cold-generated')]:
    include(OUT / 'unpacked' / generated / 'coordinate-sanitize/coordinate-test',
            'original/' + prefix + '/coordinate-test')
    for suffix in ['profraw', 'profdata']:
        include(OUT / 'unpacked' / prefix / ('native/native.' + suffix),
                'original/' + prefix + '/native.' + suffix)
receipt = load(RAW / 'receipt.json')
for source in receipt['sources']:
    if source['path'].startswith('renderer/virgl-shader/build/'):
        path = ROOT / source['path']
        assert digest(path) == source['sha256'], source['path']
        include(path, 'generated/' + str(Path(source['path']).relative_to('renderer/virgl-shader/build')))
include(ROOT / 'renderer/virgl-shader/build/coordinate-reference-3737844652.json',
        'generated/coordinate-reference-3737844652.json')
for source in receipt['sources']:
    if source['path'].startswith('renderer/virgl-shader/build/'):
        continue
    if source['path'].startswith(('renderer/','tools/')):
        path = ROOT / source['path']
        assert digest(path) == source['sha256'], source['path']
        include(path, 'sources/' + source['path'])
original_path = 'evidence/virgl-workload-inventory/captures/es2gears/shaders/c5806d5f8fd74bf2d3ce5ccf32bdc255ec13ad9447eec5896a3c96a591a5c68f.tgsi'
include(ROOT / original_path, 'sources/' + original_path)

records = [dict(path=name, bytes=path.stat().st_size, sha256=digest(path)) for name,path in sorted(members.items())]
archive = OUT / 'recording.tar.gz'
with archive.open('wb') as output:
    with gzip.GzipFile(filename='', fileobj=output, mode='wb', compresslevel=6, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name,path in sorted(members.items()):
                info = tar.gettarinfo(str(path), arcname=name)
                assert info.isfile()
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                with path.open('rb') as source:
                    tar.addfile(info, source)
write(OUT / 'records.json', dict(schema=1, task='E6-T12g6k', records=records))

# Authenticate every actual emitted member, independently of the tar-writing loop.
index = {r['path']:r for r in records}
with tarfile.open(archive, 'r:gz') as tar:
    seen = set()
    for entry in tar:
        assert entry.isfile() and entry.name not in seen and entry.name in index
        seen.add(entry.name)
        data = tar.extractfile(entry).read()
        assert len(data) == index[entry.name]['bytes']
        assert hashlib.sha256(data).hexdigest() == index[entry.name]['sha256']
    assert seen == set(index)

worker = ROOT / 'evidence/virgl-fragment-coordinates/worker'
verdict = load(OUT / 'verdict.json')
write(OUT / 'manifest.json', dict(schema='virgl-fragment-coordinate-critic-seal-v1',task='E6-T12g6k',verdict='verified',
    prerequisite=verdict['prerequisite'], frozenRuntime=verdict['frozenRuntime'], workerSubmissionHead=verdict['workerSubmissionHead'], criticHead=verdict['criticGuardHead'],
    records=len(records), archive=binding(archive), recordIndex=binding(OUT / 'records.json'),
    verdictPath='critic/verdict.json', verdictSha256=digest(OUT / 'verdict.json'),
    predictionsPath='critic/predictions.md', predictionsSha256=digest(OUT / 'predictions.md'),
    workerManifestSha256=digest(worker / 'manifest.json'), workerArchiveSha256=digest(worker / 'recording.tar.gz'), workerRecordIndexSha256=digest(worker / 'records.json'),
    authenticationSha256=digest(OUT / 'authentication.json'), coverageAuditSha256=digest(OUT / 'coverage-audit.json'),
    finalAcceptanceReceiptSha256=digest(RAW / 'receipt.json'), freshReportSha256=digest(OUT / 'gpu-3737844652/report.json'),
    freshCaptureSha256=digest(OUT / 'fourth-capture.json'), sabotageSha256=digest(OUT / 'sabotage.json'),
    independentNativeWasmCases=380, independentMetadataAttacks=32, independentBankCases=480,
    uniquePhysicalSeeds=verdict['uniquePhysicalSeeds'], uniqueScheduleComponentWords=verdict['uniqueScheduleComponentWords'],
    maximumObservedAbsoluteError=verdict['maximumObservedAbsoluteError'], measuredAbsoluteBudget=verdict['measuredAbsoluteBudget'],
    changedRuntimeLines=127, executedRuntimeLines=118, individuallyWaivedLines=9, unprovenExecutableLines=0,
    coldProof=dict(sourceHead=verdict['frozenRuntime'],reportSha256='821210827dd50ba460b65a279b79f257da68a558ac79f8c8a15454913b474130',incremental=True,additionalClone=False),
    carriedPredecessorPredictions=10, productionNegotiation=False, guestExecution=False, qualifications=verdict['qualifications']))
manifest = load(OUT / 'manifest.json')
print(json.dumps(dict(records=len(records), archive=manifest['archive'], recordIndex=manifest['recordIndex'], verdictSha256=manifest['verdictSha256'])))
