#!/usr/bin/env python3
"""Fresh critic authentication; never imports the worker's receipt validator."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
WORKER = OUT.parent / 'worker'
HEAD = 'c947442bad912ebcd46d3ff30a0e4c71be87ca4a'
BASE = '574d633c17c7436545195c63e534d9fa7859ac74'
EXPECTED_ARCHIVE = '8bba25788029785c57fd48b2f1a47a522856b178f4b3d5025f14adce43c7d8e2'
EXPECTED_INDEX = 'e6c6ab2af48ff5ca58e0794e163ee38075ead285f04c3df6ee822bb33d521bad'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def check(ok, label):
    if not ok:
        raise AssertionError(label)

def main():
    plan = (OUT / 'predictions.md').read_bytes()
    manifest = json.loads((WORKER / 'manifest.json').read_bytes())
    index_raw = (WORKER / 'records.json').read_bytes()
    archive_raw = (WORKER / 'recording.tar.gz').read_bytes()
    check(manifest['sourceHead'] == HEAD and manifest['base'] == BASE, 'frozen head/base')
    for entry, raw, digest in [(manifest['recordIndex'], index_raw, EXPECTED_INDEX),
                               (manifest['archive'], archive_raw, EXPECTED_ARCHIVE)]:
        check(len(raw) == entry['bytes'] and sha(raw) == entry['sha256'] == digest,
              'outer immutable digest ' + entry['path'])
    index = json.loads(index_raw)
    check(index['sourceHead'] == HEAD and index['task'] == manifest['task'] == 'E6-T12g6k', 'index identity')
    rows = index['records']
    check(len(rows) == manifest['records'] == 127, 'exact recorded member count')
    check(len({r['path'] for r in rows}) == len(rows), 'unique index paths')
    indexed = {r['path']: r for r in rows}
    unpacked = OUT / 'unpacked'
    seen = set()
    with tarfile.open(WORKER / 'recording.tar.gz', 'r:gz') as tar:
        for member in tar:
            path = PurePosixPath(member.name)
            check(not path.is_absolute() and '..' not in path.parts and str(path) == member.name,
                  'safe canonical member ' + member.name)
            check(member.isfile() and member.name not in seen and member.name in indexed,
                  'unique regular indexed member ' + member.name)
            raw = tar.extractfile(member).read()
            row = indexed[member.name]
            check(len(raw) == member.size == row['bytes'] and sha(raw) == row['sha256'],
                  'member digest ' + member.name)
            destination = unpacked / member.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(raw)
            seen.add(member.name)
    check(seen == set(indexed), 'no missing indexed member')
    bindings = []
    for name, field in [('hot/receipt.json', 'hotReceiptSha256'),
                        ('cold/report.json', 'coldReportSha256'),
                        ('cold/acceptance/receipt.json', 'coldReceiptSha256')]:
        raw = (unpacked / name).read_bytes()
        check(sha(raw) == manifest[field], 'receipt seal ' + name)
        receipt = json.loads(raw)
        check(receipt['gitHead'] == HEAD and receipt['status'] == 'passed', 'recorded frozen outcome ' + name)
        for source in receipt.get('sources', []):
            filename = source['path']
            if filename.startswith('renderer/virgl-shader/build/'):
                prefix = 'generated/' if name.startswith('hot/') else 'cold-generated/'
                generated = prefix + filename.removeprefix('renderer/virgl-shader/build/')
                source_raw = (unpacked / generated).read_bytes()
            else:
                source_raw = subprocess.check_output(['git', 'show', f'{HEAD}:{filename}'], cwd=ROOT)
                check(source_raw == (ROOT / filename).read_bytes(), 'unchanged recorded source ' + filename)
            check(sha(source_raw) == source['sha256'] and len(source_raw) == source['bytes'],
                  'source object binding ' + filename)
            bindings.append({'record': name, **source})
        prefix = 'hot/' if name.startswith('hot/') else 'cold/acceptance/'
        for artifact in receipt.get('records', []):
            sealed = indexed[prefix + artifact['path']]
            check(sealed['bytes'] == artifact['bytes'] and sealed['sha256'] == artifact['sha256'],
                  'artifact receipt binding ' + artifact['path'])
    cold = json.loads((unpacked / 'cold/report.json').read_bytes())
    check(cold['cloneHead'] == HEAD and cold['statusBefore'] == cold['statusAfter'] == '' and cold['exitCode'] == 0,
          'pristine exact-head clone')
    check(cold['command'] == ['make', 'verify-E6-T12g6k'], 'identical cold command')
    check(sha((unpacked / 'cold/cold.log').read_bytes()) == cold['logSha256'], 'cold log binding')
    check(sha((unpacked / 'cold/acceptance/receipt.json').read_bytes()) == cold['receiptSha256'], 'cold receipt binding')
    changed = subprocess.check_output(['git', 'diff', '--name-only', HEAD, 'HEAD'], cwd=ROOT, text=True).splitlines()
    check(all(p.startswith('evidence/virgl-fragment-coordinates/worker/') or p in
              ['tasks/QUEUE.md', 'tasks/epic-6-transcendence/E6-T12g6k-fragment-coordinates.md'] for p in changed),
          'post-runtime seal/prose boundary')
    report = {'schema': 'fragment-coordinate-critic-authentication-v1', 'status': 'passed',
              'sourceHead': HEAD, 'base': BASE, 'predictionsSha256': sha(plan),
              'archiveSha256': sha(archive_raw), 'recordIndexSha256': sha(index_raw),
              'members': rows, 'sourceBindings': bindings, 'postRuntimeChangedPaths': changed,
              'cold': cold}
    (OUT / 'authentication.json').write_text(json.dumps(report, indent=2) + '\n')
    print(f'Authenticated {len(rows)} exact original members and {len(bindings)} source bindings.')

if __name__ == '__main__':
    main()
