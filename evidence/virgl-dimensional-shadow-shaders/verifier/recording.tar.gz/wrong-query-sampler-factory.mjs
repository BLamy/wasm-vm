import {createVirglStandardDimensionalShadowTextureShaderBridge as actual} from 'file:///Users/blamy/.codex/worktrees/mips-throughput/wasm-vm/renderer/virgl-shader/standard.mjs';
export async function createVirglStandardDimensionalShadowTextureShaderBridge(options) {
 const real=await actual(options);
 return {...real, translatePairImages(request) {
  const result=real.translatePairImages(request);
  if(result.ok) result.fragment.metadata.samplers.find(s=>s.index===15).type='sampler2DArrayShadow';
  return result;
 },translateImages(request) {
  const result=real.translateImages(request);
  if(result.ok) result.metadata.samplers.find(s=>s.index===15).type='sampler2DArrayShadow';
  return result;
 }};
}
