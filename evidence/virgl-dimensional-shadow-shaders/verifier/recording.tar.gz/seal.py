import json,hashlib,gzip,tarfile,io
from pathlib import Path
root=Path(__file__).parent;output=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm/evidence/virgl-dimensional-shadow-shaders/verifier')
sha=lambda b:hashlib.sha256(b).hexdigest();assert not output.exists();verdict=json.loads((root/'verdict.json').read_bytes());assert verdict['verdict']=='verified';output.mkdir(parents=True)
files={p.relative_to(root).as_posix():p for p in sorted(root.rglob('*')) if p.is_file()};rows=[];unique={}
for name,p in files.items():
 body=p.read_bytes();key=(len(body),sha(body));row=dict(path=name,bytes=key[0],sha256=key[1],kind='hardlink' if key in unique else 'file')
 if key in unique:row['target']=unique[key]
 else:unique[key]=name
 rows.append(row)
index=dict(schema='E6-T11d61-independent-verifier-index-v1',task='E6-T11d61',submission=verdict['submission'],frozenSource=verdict['frozenSource'],records=rows)
raw=(json.dumps(index,indent=2)+'\n').encode();(output/'records.json').write_bytes(raw);archive=output/'recording.tar.gz'
with archive.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
 for row in rows:
  info=tarfile.TarInfo(row['path']);info.mode,info.mtime=0o644,0
  if row['kind']=='hardlink':info.type,info.linkname=tarfile.LNKTYPE,row['target'];tar.addfile(info)
  else:
   body=files[row['path']].read_bytes();assert len(body)==row['bytes'] and sha(body)==row['sha256'];info.size=len(body);tar.addfile(info,io.BytesIO(body))
seen={};count=0
with gzip.open(archive,'rb') as zipped:
 with tarfile.open(fileobj=zipped,mode='r|') as tar:
  for member in tar:
   row=rows[count];assert row['path']==member.name;count+=1
   if member.islnk():assert row['kind']=='hardlink' and member.linkname==row['target'] and seen[member.linkname]==(row['bytes'],row['sha256'])
   else:
    assert member.isfile() and row['kind']=='file';body=tar.extractfile(member).read();assert len(body)==row['bytes'] and sha(body)==row['sha256']
   seen[member.name]=(row['bytes'],row['sha256'])
 while zipped.read(1048576):pass
assert count==len(rows)
for row in rows:
 body=files[row['path']].read_bytes();assert len(body)==row['bytes'] and sha(body)==row['sha256'],'Input changed during sealing'
manifest=dict(schema='E6-T11d61-independent-verifier-seal-v1',task='E6-T11d61',submission=verdict['submission'],runtime=verdict['runtime'],frozenSource=verdict['frozenSource'],verdict='verified',records=len(rows),uniqueBodies=len(unique),backwardLinks=len(rows)-len(unique),reopenedMembers=count,gzipEofChecked=True,recordIndexSha256=sha(raw),archiveSha256=sha(archive.read_bytes()),archiveBytes=archive.stat().st_size,logicalBytes=sum(r['bytes'] for r in rows),predictionsSha256=verdict['predictionsSha256'],verdictSha256=sha((root/'verdict.json').read_bytes()),workerManifestSha256='862ccad57dcd39ef940c2ba495c4a638e3e30f82fd4b34546240937b7ce550f1',deploymentManifestSha256='02252e62162ee1eefcc5a56cf854123e4a5c99b37aa62a63899682676c5362b6',freshGpuSeed=314159265,promotedTest=verdict['promotedTest'],guestExecution=False,productionAuthority=False)
(output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(dict(manifestSha256=sha((output/'manifest.json').read_bytes()),**manifest)))
