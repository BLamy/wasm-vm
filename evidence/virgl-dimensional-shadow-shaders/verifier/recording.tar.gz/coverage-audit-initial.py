import json,re,subprocess,hashlib
from pathlib import Path
repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');root=Path('/tmp/wasmvm-dimensional-shadow-cold-7e515708/recording');out=Path(__file__).parent;base='04ab18042036bf0ab19864bbe38e787dd4aadf48'
sha=lambda b:hashlib.sha256(b).hexdigest();added={};hunks=[];path=None;line=0
names=['renderer/virgl-shader/'+p for p in ['bridge.c','standard_guard.c','standard_emit.c','standard_guard.h','standard.mjs']]
for row in subprocess.check_output(['git','diff','--unified=0',base,'HEAD','--',*names],cwd=repo,text=True).splitlines():
 if row.startswith('+++ b/'):path=row[6:]
 elif row.startswith('@@'):
  line=int(re.search(r'\+(\d+)',row)[1]);hunks.append(dict(path=path,at=line,header=row))
 elif row.startswith('+'):added.setdefault(path,[]).append(line);line+=1
 elif row.startswith(' '):line+=1
native=[]
for p in [root/'coverage/matrix.json',root/'coverage/allocations.json']:
 j=json.loads(p.read_bytes());assert j['type']=='llvm.coverage.json.export'
 for fn in j['data'][0]['functions']:
  for r in fn['regions']:
   filename=fn['filenames'][r[5]];key='renderer/virgl-shader/'+filename.split('/renderer/virgl-shader/')[-1]
   if key not in names or r[7]!=0:continue
   native.append(dict(path=key,start=(r[0],r[1]),end=(r[2],r[3]),count=r[4],function=fn['name'],record=p.relative_to(root).as_posix(),original=r))
scripts=[]
for p in root.glob('*/browser-coverage.json'):
 if p.parent.name.startswith('fault'):continue
 for s in json.loads(p.read_bytes())['scripts']:
  if s['source'] in names:scripts.append(dict(path=s['source'],functions=s['coverage']['functions'],digest=s['sha256'],record=p.relative_to(root).as_posix()))
for p in (root/'node-coverage').glob('coverage-*.json'):
 for s in json.loads(p.read_bytes())['result']:
  if s['url'].endswith('/renderer/virgl-shader/standard.mjs'):scripts.append(dict(path='renderer/virgl-shader/standard.mjs',functions=s['functions'],record=p.relative_to(root).as_posix(),digest=sha((root/'sources/renderer/virgl-shader/standard.mjs').read_bytes())))
for s in scripts:assert s['digest']==sha((repo/s['path']).read_bytes())
partitions=[];waivers=[]
for path,lines in added.items():
 text=(repo/path).read_text();ls=text.splitlines(keepends=True);offsets=[0]
 for l in ls:offsets.append(offsets[-1]+len(l.encode('utf-16-le'))//2 if path.endswith('.mjs') else offsets[-1]+len(l))
 scopes=[]
 if path.endswith('.mjs'):
  for s in scripts:
   if s['path']!=path:continue
   for fn in s['functions']:
    scopes.append((s['record'],fn['functionName'],[dict(start=r['startOffset'],end=r['endOffset'],count=r['count']) for r in fn['ranges']]))
 else:
  for r in native:
   if r['path']==path:
    start=offsets[r['start'][0]-1]+r['start'][1]-1;end=offsets[r['end'][0]-1]+r['end'][1]-1
    scopes.append((r['record'],r['function'],[dict(start=start,end=end,count=r['count'])]))
 for line in lines:
  a,b=offsets[line-1:line+1];points=sorted({a,b}|{z for _,_,rs in scopes for r in rs for z in [r['start'],r['end']] if a<z<b})
  for x,y in zip(points,points[1:]):
   chunk=text[x:y]
   if not chunk.strip():continue
   governing={}
   for record,fn,rs in scopes:
    for r in rs:
     if r['start']<=x and y<=r['end']:
      key=(record,fn);old=governing.get(key)
      if old is None or (r['end']-r['start'],r['count'])<(old['end']-old['start'],old['count']):governing[key]=r
   if not governing:
    # No generic catch-all waiver: identify the exact declaration/signature lines.
    assert path=='renderer/virgl-shader/bridge.c' and line in [2580,2612,2775,2776,2780,2781,2782,2783,2784] or path=='renderer/virgl-shader/standard_guard.h' and line==48,(path,line,chunk)
    waivers.append(dict(path=path,line=line,start=x,end=y,text=chunk,classification='WAIVED',reason='C ABI signature or bool profile field declaration; no executable region; ABI/layout compiled in optimized native, ASan and fixed-memory Wasm.'))
   else:
    counters=[dict(record=k[0],function=k[1],**r) for k,r in governing.items()];maximum=max(r['count'] for r in governing.values());assert maximum>0,(path,line,chunk,counters)
    partitions.append(dict(path=path,line=line,start=x,end=y,text=chunk,status='HELD',maximum=maximum,governing=counters))
# Worker partitions can include whitespace; compare its asserted finest counters against independent scope reconstruction.
worker=json.loads((root/'coverage-audit.json').read_bytes());assert not worker['zero'] and not worker['nativeZero']
for p in worker['nativePartitions']:
 matching=[x for x in partitions if x['path']==p['source'] and x['start']==p['start'] and x['end']==p['end']];assert len(matching)==1 and matching[0]['maximum']==p['maxCount']
for p in worker['partitions']:
 matching=[x for x in partitions if x['path']==p['source'] and x['start']==p['startOffset'] and x['end']==p['endOffset']]
 if matching:assert matching[0]['maximum']==p['maxCount']
 assert p['maxCount']>0
assert len(waivers)==10
# Ledger every task diff hunk, including harnesses and declarative/evidence files.
ledger=[];p=None
receipt=json.loads((root/'receipt.json').read_bytes());commands=[c['name'] for c in receipt['commands']]
for row in subprocess.check_output(['git','diff','--unified=0',base,'HEAD'],cwd=repo,text=True).splitlines():
 if row.startswith('+++ b/'):p=row[6:]
 elif row.startswith('@@'):
  at=int(re.search(r'\+(\d+)',row)[1]);end=at+int(re.search(r'\+\d+(?:,(\d+))?',row)[1] or 1)-1
  if p in names:reason='Finest positive LLVM/V8 partitions or explicit ten C signature/type waivers above.';classification='HELD'
  elif p.startswith('evidence/') or p.startswith('tasks/'):reason='Recorded evidence/task metadata only; complete seals reopened; task/frontmatter checked by policy.';classification='WAIVED'
  elif p in ['renderer/virgl-shader/bridge.h','web/roadmap.js','web/dist/roadmap.js','web/dist/sw.js','Makefile']:reason='Declarations, truthful roadmap/service-worker cache data or acceptance recipe; native/wasm compilation, built/live bodies and explicit make acceptance prove direct result.';classification='WAIVED'
  elif p=='renderer/virgl-shader/build.sh':reason='New native, sanitizer, allocation and Wasm export branches executed by receipt commands19–30; existing build targets outside task are unchanged HELD.';classification='HELD'
  elif p.startswith('renderer/virgl-shader/native_tests/'):reason='Complete compiler matrix and genuine fault/caller-mutation runs exercised new harness; assertions/refusals retained in full streams; stale or unused old branches copied from D57 carried HELD.';classification='HELD'
  elif p.startswith('renderer/virgl-shader/tests/'):reason='Actual Metal compile/link/reflection, three full-plane schedules plus physical layer sabotage executed browser harness paths; capture/cleanup and compressed bodies independently audited.';classification='HELD'
  elif p=='tools/verify-virgl-default-demo.mjs':reason='Both newly admitted task argument and D61 text assertion executed in default-demo.';classification='HELD'
  elif p.startswith('tools/virgl-dimensional-shadow-shaders/'):
   reason='Executable recording/harness entrypoints run by complete41-command cold acceptance, preserved earlier failure, seal+reopen and current independent audit; declarations/imports/argument plumbing statically scoped.';classification='HELD'
  else:raise AssertionError(p)
  ledger.append(dict(path=p,start=at,end=end,hunk=row,classification=classification,reason=reason))
result=dict(status='HELD',fineRuntimePartitions=len(partitions),nativePartitions=sum(not p['path'].endswith('.mjs') for p in partitions),javascriptNonWhitespacePartitions=sum(p['path'].endswith('.mjs') for p in partitions),workerPositiveV8=worker['positive'],workerPositiveLLVM=worker['nativePositive'],declarationWaivers=waivers,zeroRegions=[],fullNestedAuthority=True,partitions=partitions,hunks=ledger,commands=commands)
(out/'coverage-audit.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k not in ['partitions','hunks','commands','declarationWaivers']})
