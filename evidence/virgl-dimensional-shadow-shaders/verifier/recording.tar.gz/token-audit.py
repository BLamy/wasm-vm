import json,re,struct,hashlib
from pathlib import Path
root=Path('/tmp/wasmvm-dimensional-shadow-cold-7e515708/recording');out=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest();h=(root/'sources/renderer/virgl-shader/vendor/src/gallium/include/pipe/p_shader_tokens.h').read_text()
def enums(name):
 body=re.search(r'enum '+name+r'\s*\{(.*?)\};',h,re.S)[1];body=re.sub(r'/\*.*?\*/','',body,flags=re.S);result={};v=0
 for term in body.split(','):
  m=re.match(r'\s*(\w+)(?:\s*=\s*(\d+))?',term)
  if m:
   if m[2]:v=int(m[2])
   result[m[1]]=v;v+=1
 return result
ops=enums('tgsi_opcode');targets=enums('tgsi_texture_type');types=enums('tgsi_return_type');files={'IMM':7,'IN':2,'TEMP':4,'CONST':1,'SAMP':5,'SV':9}
def operand(s):
 m=re.fullmatch(r'(-)?(\|)?(IMM|IN|TEMP|CONST|SAMP|SV)\[(\d+)\](?:\[(\d+)\])?(?:\.([xyzw]+))?(\|)?',s);assert m,s
 sw=m[6] or 'xyzw';assert len(sw) in [1,4];assert bool(m[2])==bool(m[7]);sw=(sw*4)[:4]
 return dict(file=files[m[3]],index=int(m[5] or m[4]),slot=int(m[4]) if m[5] else 0,negate=int(bool(m[1])),absolute=int(bool(m[2])),swizzle=['xyzw'.index(x) for x in sw],indirect=0)
def literal(text):
 result=[]
 for n,op,quals,args in re.findall(r'^(\d+): (TEX|TXL2|TXL|TXF|TXD|TXB2|TXB|TXQ|TXP)((?:_SAT|_PRECISE)*) (.+)$',text,re.M):
  parts=[p.strip() for p in args.split(',')];dst=parts.pop(0);target=parts.pop();mask=dst.split('.')[-1] if '.' in dst else 'xyzw'
  result.append(dict(instruction=int(n),opcode=ops['TGSI_OPCODE_'+op],target=targets['TGSI_TEXTURE_'+target],writeMask=sum(1<<'xyzw'.index(l) for l in mask),saturate=int('_SAT' in quals),precise=int('_PRECISE' in quals),offsets=0,sources=[operand(p) for p in parts]))
 declarations=[]
 for a,b,target,ty in re.findall(r'^DCL SVIEW\[(\d+)(?:\.\.(\d+))?\], (\w+), ((?:FLOAT|SINT|UINT)(?:, (?:FLOAT|SINT|UINT))*)$',text,re.M):
  ts=ty.split(', ');assert len(set(ts))==1
  declarations.append(dict(first=int(a),last=int(b or a),target=targets['TGSI_TEXTURE_'+target],returnTypes=[types['TGSI_RETURN_TYPE_'+ts[0]]]*4))
 return result,declarations
def signed(v):return v-65536 if v&32768 else v
def raw_decode(w):
 assert (w[0]&255)+(w[0]>>8)==len(w);cursor=w[0]&255;instructions=[];decls=[];imms=[];ordinal=0
 while cursor<len(w):
  start=cursor;head=w[cursor];kind=head&15;length=(head>>4)&(511 if kind==2 else 16383 if kind==1 else 255);length+=int(kind==2);assert length>0
  if kind==0 and ((head>>12)&15)==11:
   pos=cursor+2;pos+=(head>>20)&1;pos+=(head>>22)&1;pos+=(head>>21)&1
   view=w[pos];rg=w[cursor+1];decls.append(dict(first=rg&65535,last=rg>>16,target=view&255,returnTypes=[(view>>(8+i*6))&63 for i in range(4)]))
  if kind==1:imms.append(dict(index=len(imms),type=(head>>18)&15,words=w[cursor+1:cursor+length]))
  if kind==2:
   if (head>>29)&1:
    pos=cursor+1+((head>>28)&1);tex=w[pos];pos+=1+(tex>>8&15);pos+=(head>>30)&1
    count=(head>>22)&3;assert count==1;dst=w[pos];pos+=1+((dst>>8)&1)+((dst>>9)&1);sources=[]
    for i in range((head>>24)&15):
     src=w[pos];pos+=1;ind=(src>>4)&1;dim=(src>>5)&1;pos+=ind;slot=0
     if dim:slot=signed(w[pos]>>16);pos+=1+int(bool(w[pos]&1))
     sources.append(dict(file=src&15,index=signed((src>>6)&65535),slot=slot,negate=src>>31,absolute=(src>>30)&1,swizzle=[(src>>(22+2*k))&3 for k in range(4)],indirect=ind))
    assert pos==cursor+length
    instructions.append(dict(instruction=ordinal,opcode=(head>>13)&255,target=tex&255,writeMask=(dst>>4)&15,saturate=(head>>21)&1,precise=head>>31,offsets=(tex>>8)&15,sources=sources))
   ordinal+=1
  cursor=start+length
 assert cursor==len(w)
 return instructions,decls,imms,w[1]&15
cases=json.loads((root/'native/cases.json').read_bytes())['cases'];nativeLines=(root/'native/native.jsonl').read_text().splitlines();san=(root/'native/sanitize.jsonl').read_bytes();assert san==(root/'native/native.jsonl').read_bytes();wasmLines=(root/'native/wasm.jsonl').read_text().splitlines();assert len(cases)==len(nativeLines)==len(wasmLines)==20927
count=0;accepted=refused=0;selected=0;samples=[]
paired={2,9,10,11,14,17,24,31,38,45};vertices={0,7,12,15,22,29,36,43}
for index,(c,line,wl) in enumerate(zip(cases,nativeLines,wasmLines)):
 row=json.loads(line);wasm=json.loads(wl);result=row['result'];assert wasm['result']==result
 whole=line.split(',"result":',1)[1].rsplit(',"originalTokens":',1)[0];assert whole==wasm['response']
 if not result['ok']:
  assert list(result)==['ok','error'];assert isinstance(result['error']['message'],str) and len(result['error']['message'])<512;refused+=1;assert row['originalTokens'] is None
  if c['name'].startswith('signature/'):
   _,stage,target,decl,ty,slot,op=c['name'].split('/');assert ty!='FLOAT' or op not in ['TEX','TXD','TXQ'] and not(stage=='fragment' and target=='SHADOWCUBE' and op=='TXB2')
  continue
 accepted+=1
 texts=[c['a'],c['b']] if c['kind'] in paired else [c['a']]
 for n,text in enumerate(texts):
  record=row['originalTokens'][n];ins,decls,imms,processor=raw_decode(record['rawWords']);expected,views=literal(text)
  assert ins==record['textureInstructions']==expected,(index,c['name']);assert decls==record['samplerViews']==views;assert imms==record['immediates'];assert processor==(1 if text.startswith('VERT') else 0);count+=len(ins)
  if c['kind']<43:continue
  selected+=1;body=result[['vertex','fragment'][n]] if c['kind']==45 else result;meta=body['metadata'];stage='vertex' if text.startswith('VERT') else 'fragment';prefix='vs' if stage=='vertex' else 'fs';assert meta['stage']==stage and meta['profile']=='virgl-webgl2-standard-dimensional-shadow-texture-gles3-v1'
  controls=[];queries=[]
  for sampler in meta['samplers']:
   slot=sampler['index'];d=next(d for d in decls if d['first']<=slot<=d['last']);ss=[i for i in ins if i['sources'][-1]['index']==slot];shadow=lambda i:i['target'] in [7,12,13];query=lambda i:i['opcode']==ops['TGSI_OPCODE_TXQ'];sampleShadow=any(shadow(i) and not query(i) for i in ss);ordinary=any(not shadow(i) and not query(i) for i in ss);viewShadow=d['target'] in [7,12,13];isShadow=viewShadow or sampleShadow or(any(shadow(i) and query(i) for i in ss) and not ordinary)
   target={2:'2D',7:'2D',3:'3D',4:'Cube',13:'Cube',10:'2DArray',12:'2DArray'}[d['target']];ty=('' if d['returnTypes'][0]==4 else 'i' if d['returnTypes'][0]==2 else 'u')+'sampler'+target+('Shadow' if isShadow else '')
   assert sampler==dict(index=slot,name=prefix+'samp'+str(slot),type=ty)
   if sampleShadow:controls.extend([dict(index=slot,name=prefix+'shadmask'+str(slot),type='vec4',semantic='SHADOW_MASK'),dict(index=slot,name=prefix+'shadadd'+str(slot),type='vec4',semantic='SHADOW_ADD')])
   if any(query(i) and i['writeMask']&8 for i in ss):queries.append(dict(index=slot,name=prefix+'samplevels'+str(slot),type='int',semantic='TEXTURE_LEVELS'))
  assert meta['shadowUniforms']==controls;assert meta['textureQueries']==queries
  if c['name']=='hardware/fragment/CUBE/TXB2/7/plain-view/':samples.append(dict(line=index+1,name=c['name'],tokens=ins,metadata=meta,wholeResponseSha256=sha(whole.encode())))
assert accepted==14009 and refused==6918 and count==13735
hist=[json.loads(l) for l in (root/'native/historical-abi.jsonl').read_text().splitlines()];assert len(hist)==15612
indices=[i for i,c in enumerate(cases) if c['kind']<43];assert len(indices)==len(hist)
for item,i in zip(hist,indices):
 assert item['name']==cases[i]['name']
 assert item['originalResponse']==item['currentResponse']==json.loads(wasmLines[i])['response']
result=dict(status='HELD',completeResponseCases=len(cases),admitted=accepted,refused=refused,rawWordTextureInstructions=count,selectedStages=selected,historicalWholeBytes=len(hist),nativeDigest=sha((root/'native/native.jsonl').read_bytes()),wasmDigest=sha((root/'native/wasm.jsonl').read_bytes()),samples=samples)
(out/'token-audit.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k!='samples'})
