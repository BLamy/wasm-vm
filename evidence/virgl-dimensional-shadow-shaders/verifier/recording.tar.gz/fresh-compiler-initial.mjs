import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {spawnSync} from 'node:child_process';
const out=new URL('.',import.meta.url).pathname;
const root='/private/var/folders/nr/cyvk1qc14jj5c081vj1xts000000gn/T/wasm-vm-dimensional-shadow-cold-wm94tnul/repo';
const proof='/tmp/wasmvm-dimensional-shadow-cold-7e515708/recording';
const {default:create}=await import(pathToFileURL(root+'/renderer/virgl-shader/build/wasm/virgl-shader.mjs'));
const factories=await import(pathToFileURL(root+'/renderer/virgl-shader/standard.mjs'));
const hash=b=>createHash('sha256').update(b).digest('hex');
const zero={signedMask:0,unsignedMask:0,packedSignedMask:0,packedNormalizedMask:0,bufferZeroMask:0,signedColorMask:0,unsignedColorMask:1};
const vertex=`VERT
DCL IN[0]
DCL IN[1]
DCL IN[2]
DCL OUT[0], POSITION
DCL OUT[1], GENERIC[0]
DCL OUT[2], GENERIC[1]
0: MOV OUT[0], IN[0]
1: MOV OUT[1], IN[1]
2: MOV OUT[2], IN[2]
3: END
`;
function fragment(after,bias='-|IN[2].wzyx|') {
 const q='TXQ TEMP[1].yw, IMM[0], SAMP[15], SHADOW2D_ARRAY';
 const sample='TEX TEMP[0], IN[1], SAMP[15], 2D_ARRAY';
 const ops=[...(after?[sample,q]:[q,sample]),'TXB2_SAT_PRECISE TEMP[0].xz, IN[1], '+bias+', SAMP[7], SHADOWCUBE','TXQ TEMP[2].xzw, IMM[0], SAMP[7], CUBE','MOV OUT[0], TEMP[0]','END'];
 return `FRAG
DCL IN[1], GENERIC[0], CONSTANT
DCL IN[2], GENERIC[1], CONSTANT
DCL OUT[0], COLOR
DCL TEMP[0..2]
DCL SAMP[7]
DCL SVIEW[7], CUBE, FLOAT
DCL SAMP[15]
DCL SVIEW[15], 2D_ARRAY, FLOAT
IMM[0] INT32 {2,0,0,0}
`+ops.map((s,i)=>i+': '+s+'\n').join('');
}
const cases=[];let first;
let aRuntime,bRuntime;const bridge=await factories.createVirglStandardDimensionalShadowTextureShaderBridge({onRuntimeInitialized(){aRuntime=this;}}),peer=await factories.createVirglStandardDimensionalShadowTextureShaderBridge({onRuntimeInitialized(){bRuntime=this;}});
assert.notEqual(aRuntime.HEAPU8.buffer,bRuntime.HEAPU8.buffer);assert.equal(aRuntime.HEAPU8.byteLength,16777216);assert.equal(bRuntime.HEAPU8.byteLength,16777216);
for(const after of [false,true])for(const bias of ['-|IN[2].wzyx|','IN[2].yyyy','-|IN[2].xxxx|']) {
 const text=fragment(after,bias),request={vertexText:vertex,fragmentText:text,...zero},pair=bridge.translatePairImages(request),stage=bridge.translateImages({stage:'fragment',text,signedColorMask:0,unsignedColorMask:1});
 assert.equal(pair.ok,true);assert.equal(stage.ok,true);assert.deepEqual(stage,pair.fragment);assert.deepEqual(peer.translatePairImages(request),pair);const metadata=stage.metadata;
 assert.deepEqual(metadata.samplers,[{index:7,name:'fssamp7',type:'samplerCubeShadow'},{index:15,name:'fssamp15',type:'sampler2DArray'}]);
 assert.deepEqual(metadata.shadowUniforms,[{index:7,name:'fsshadmask7',type:'vec4',semantic:'SHADOW_MASK'},{index:7,name:'fsshadadd7',type:'vec4',semantic:'SHADOW_ADD'}]);
 assert.deepEqual(metadata.textureQueries,[{index:7,name:'fssamplevels7',type:'int',semantic:'TEXTURE_LEVELS'},{index:15,name:'fssamplevels15',type:'int',semantic:'TEXTURE_LEVELS'}]);
 cases.push({name:'cross-slot/order-'+after+'/bias-'+bias,kind:45,a:vertex,b:text,selectors:zero,result:pair,okay:true});first??=request;
 for(const bad of [text.replace('2D_ARRAY\n','SHADOW2D_ARRAY\n'),text.replace('SHADOWCUBE\n','SHADOW2D_ARRAY\n'),text.replace('CUBE, FLOAT','CUBE, UINT'),text.replace('TXB2_SAT_PRECISE','TXL2_SAT_PRECISE')]) {
  const request={vertexText:vertex,fragmentText:bad,...zero},r=bridge.translatePairImages(request);assert.deepEqual(Object.keys(r),['ok','error']);assert.equal(r.ok,false);assert.equal(r.error.code,'unsupported-feature');cases.push({name:'cross-slot/refusal-'+cases.length,kind:45,a:vertex,b:bad,selectors:zero,result:r,okay:false});
 }
}
const original=bridge.translatePairImages(first);let reflected=0;const trap=new Proxy({...first},{getOwnPropertyDescriptor(t,k){const own=Reflect.getOwnPropertyDescriptor(t,k);if(++reflected===9){t.fragmentText='\0';t.unsignedColorMask=16;}return own;}});assert.deepEqual(bridge.translatePairImages(trap),original);assert.equal(reflected,9);
const pointer=aRuntime._malloc(32);assert.ok(pointer);aRuntime.HEAPU8.fill(0xa7,pointer,pointer+32);assert.deepEqual(peer.translatePairImages(first),original);aRuntime._free(pointer);
const word=n=>{const b=Buffer.alloc(4);b.writeUInt32LE(n);return b;};const keys=['signedMask','unsignedMask','packedSignedMask','packedNormalizedMask','bufferZeroMask','signedColorMask','unsignedColorMask'],parts=[word(cases.length)];
for(const c of cases){const a=Buffer.from(c.a),b=Buffer.from(c.b);parts.push(word(c.kind),...keys.map(k=>word(c.selectors[k])),word(a.length),a,word(b.length),b);}
fs.writeFileSync(out+'novel-cases.bin',Buffer.concat(parts));fs.writeFileSync(out+'novel-cases.json',JSON.stringify({cases},null,2)+'\n');
for(const [kind,path] of [['native','standard-dimensional-shadow-texture-native/standard-dimensional-shadow-texture-test'],['sanitized','standard-dimensional-shadow-texture-sanitize/standard-dimensional-shadow-texture-test']]){
 const run=spawnSync(root+'/renderer/virgl-shader/build/'+path,[out+'novel-cases.bin'],{env:{PATH:process.env.PATH,HOME:process.env.HOME,ASAN_OPTIONS:'abort_on_error=1',UBSAN_OPTIONS:'halt_on_error=1',LLVM_PROFILE_FILE:out+'novel.profraw'},maxBuffer:12*1024*1024});fs.writeFileSync(out+'novel-'+kind+'.stdout',run.stdout);fs.writeFileSync(out+'novel-'+kind+'.stderr',run.stderr);assert.equal(run.status,0);const rows=run.stdout.toString().trim().split('\n').map(JSON.parse);assert.equal(rows.length,cases.length);rows.forEach((r,i)=>assert.deepEqual(r.result,cases[i].result));
}
assert.deepEqual(fs.readFileSync(out+'novel-native.stdout'),fs.readFileSync(out+'novel-sanitized.stdout'));
// Directly replay every historical call against the authenticated original module.
const baseline=JSON.parse(fs.readFileSync(proof+'/native/predecessor/authentication.json'));assert.equal(baseline.predecessor,'04ab18042036bf0ab19864bbe38e787dd4aadf48');
const {default:createOld}=await import(pathToFileURL(proof+'/native/predecessor/virgl-shader.mjs'));const old=await createOld();
const {direct}=await import(pathToFileURL(root+'/tools/virgl-dimensional-shaders/abi.mjs'));
const matrix=JSON.parse(fs.readFileSync(proof+'/native/cases.json')).cases,lines=fs.readFileSync(proof+'/native/historical-abi.jsonl','utf8').trim().split('\n');let count=0;
for(const c of matrix)if(c.kind<43){const row=JSON.parse(lines[count++]),response=direct(old,c);assert.equal(c.name,row.name);assert.equal(response,row.originalResponse);assert.equal(response,row.currentResponse);}
assert.equal(count,15612);
const report={status:'HELD',novelCases:cases.length,admitted:cases.filter(c=>c.okay).length,refused:cases.filter(c=>!c.okay).length,historicalReexecuted:count,peerBuffersDistinct:true,heapBytes:aRuntime.HEAPU8.byteLength,reflectionSnapshotHeld:true,novelNativeSha256:hash(fs.readFileSync(out+'novel-native.stdout')),originalHistoricalModuleSha256:hash(fs.readFileSync(proof+'/native/predecessor/virgl-shader.wasm'))};fs.writeFileSync(out+'fresh-compiler.json',JSON.stringify(report,null,2)+'\n');console.log(report);
