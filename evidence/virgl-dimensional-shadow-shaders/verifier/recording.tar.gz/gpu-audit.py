# Independent literal-field, projection and full-plane oracle; imports no worker oracle.
import json,gzip,hashlib,struct,math,sys
from pathlib import Path
out=Path(__file__).parent;cold=Path('/tmp/wasmvm-dimensional-shadow-cold-7e515708/recording');sha=lambda b:hashlib.sha256(b).hexdigest()
def words(b):return list(struct.unpack('<'+str(len(b)//4)+'I',b))
def floats(b):return list(struct.unpack('<'+str(len(b)//4)+'f',b))
def raw(v):return struct.unpack('<I',struct.pack('<f',v))[0]
def vec(b,p):return floats(b)[p*4:p*4+4]
def cube(c):
 a=max(range(3),key=lambda i:abs(c[i]));m=abs(c[a]);face=2*a+int(c[a]<0)
 sc,tc=[(-c[2],-c[1]),(c[2],-c[1]),(c[0],c[2]),(c[0],-c[2]),(c[0],-c[1]),(-c[0],-c[1])][face]
 return face,m,sc,tc,(sc/m+1)/2,(tc/m+1)/2,a
results=[]
inputs=[cold/n for n in ['hardware-27461','hardware-82013','hardware-164021','fault-wrong-layer']]
inputs+=[Path(p) for p in sys.argv[1:]]
for directory in inputs:
 report=json.loads((directory/'report.json').read_bytes());a=report['acceptance'];fault=bool(a['frames'][0].get('corruption'))
 assert report['browserErrors']==dict(console=[],page=[],requests=[]);assert report['browser']['launch']['headless']==False;assert 'Apple M4 Max' in a['gl']['renderer'] and 'Metal' in a['gl']['renderer'];assert a['productionNegotiation']==a['guestExecution']==False
 blobs={}
 for row in a['blobs']:
  compressed=(directory/row['path']).read_bytes();assert sha(compressed)==row['gzipSha256'];body=gzip.decompress(compressed);assert len(body)==row['bytes'] and sha(body)==row['sha256'];assert row['key'] not in blobs;blobs[row['key']]=body
 events=a['events'];planeResults=[];history=[]
 for f in a['frames']:
  # Prove actual native source, original attribute bytes and texture controls.
  pair=f['pair'];text=f['vertexText'] if f['stage']=='vertex' else f['fragmentText'];region=events[f['firstEvent']:f['lastEvent']+1]
  sourceEvents=events[(history[-1] if history else 0):f['firstEvent']];uploadedSources=[e['args'][1] for e in sourceEvents if e['method']=='shaderSource'];assert pair['vertex']['glsl'] in uploadedSources and pair['fragment']['glsl'] in uploadedSources;history.append(f['lastEvent']+1)
  coord=blobs[f['originalInputs']['coordinates']];dx=blobs[f['originalInputs']['dx']];dy=blobs[f['originalInputs']['dy']];pos=blobs[f['originalInputs']['positions']]
  inputsMap={0:pos,1:coord,2:dx,3:dy}
  for at in f['attributes']:
   if at['location']<0:continue
   pointer=next(e for e in region if e['method'] in ['vertexAttribPointer','vertexAttribIPointer'] and e['args'][0]==at['location']);up=next(e for e in reversed(region) if e['id']<pointer['id'] and e['method']=='bufferData' and e['args'][0]==34962);assert blobs[up['args'][1]['key']]==inputsMap[at['index']]
  sampler=next(s for s in pair[f['stage']]['metadata']['samplers'] if s['index']==f['slot']);shadow=sampler['type'].endswith('Shadow');nativeType={'samplerCubeShadow':36293,'sampler2DArrayShadow':36292,'samplerCube':35680,'sampler2DArray':36289}[sampler['type']]
  control=next(u for u in f['uniforms'] if u['name']==sampler['name']);assert control['type']==nativeType and control['value']==8
  for u in f['uniforms']:
   if not u.get('active'):continue
   location=next(e for e in region if e['method']=='getUniformLocation' and e['args'][1]==u['name'])['result']['handle']
   if u['type']==35666:
    value=[1,2,.5,4] if u['semantic']=='SHADOW_MASK' else [-.5,.25,.125,-2];assert u['value']==value and u['initial']==[0,0,0,0];setter=next(e for e in region if e['method']=='uniform4fv' and e['args'][0]['handle']==location);assert floats(blobs[setter['args'][1]['key']])==value
   else:
    value=3-f.get('baseLevel',0) if u.get('semantic')=='TEXTURE_LEVELS' else 8;assert u['value']==value;assert any(e['method']=='uniform1i' and e['args']==[{'handle':location,'type':'WebGLUniformLocation'},value] for e in region)
  target=34067 if f['target']=='CUBE' else 35866
  params={e['args'][1]:e['args'][2] for e in region if e['method']=='texParameteri' and e['args'][0]==target};assert params[33084]==f.get('baseLevel',0) and params[33085]==2 and params[34892]==(34894 if shadow else 0) and params[34893]==515
  levels={};uploads=[]
  for level in f['levels']:
   l=level['level'];b=blobs[level['originalBytesKey']];vals=floats(b);width,height,layers=level['width'],level['height'],level['layers'];assert width==height==max(1,4>>l) and layers==(6 if f['target']=='CUBE' else 5)
   for z in range(layers):
    for y in range(height):
     for x in range(width):assert vals[(z*height+y)*width+x]==.0625+(l*128+z*16+y*4+x+(a['seed']&31))/1024
   levels[l]=(width,height,layers,vals)
   for face,id in enumerate(level['uploadEvents']):
    e=events[id];data=blobs[e['args'][-1]['key']];assert e['method']==('texSubImage2D' if f['target']=='CUBE' else 'texSubImage3D')
    plane=width*height*4
    if f['target']=='CUBE':assert e['args'][0]==34069+face and data==b[face*plane:(face+1)*plane]
    elif fault:
     assert data[0:plane]==b[-plane:] and data[-plane:]==b[:plane] and data[plane:-plane]==b[plane:-plane]
    else:assert data==b
    uploads.append(dict(event=id,sha256=sha(data)))
  textureLine=next(line for line in text.splitlines() if ': '+f['opcode']+' TEMP[0]' in line);dst=textureLine.split(' TEMP[0]',1)[1].split(',')[0];writeMask=dst[1:] if dst.startswith('.') else 'xyzw';assert writeMask==(f.get('mask') or 'xyzw')
  expected=[];W,H=f['width'],f['height'];op=f['opcode'].split('_')[0];sentinels=[305419896,2147483649,3735928559,4294967295]
  for y in range(H):
   for x in range(W):
    p=y*W+x
    if op=='TXQ':
     l=words(coord)[p*4];w,h,layers,_=levels[l];sample=[w,h,0 if f['target']=='CUBE' else layers,3-f.get('baseLevel',0)]
    else:
     if f.get('biasProbe'):
      t=(x+.5)/W;start,end=vec(coord,0),vec(coord,1);c=[v+(end[k]-v)*t for k,v in enumerate(start)];gradient=[(end[k]-v)/W for k,v in enumerate(start)];bias=vec(dx,0)[0]
     else:c=vec(coord,p);gradient=None;bias=0
     source=f.get('source','IN[1]')
     if source.endswith('wzyx'):c=c[::-1]
     if source.startswith('|'):c=list(map(abs,c))
     if source.startswith('-|'):c=[-abs(v) for v in c]
     base=f.get('baseLevel',0)
     if op=='TXD' or f.get('biasProbe'):
      derivs=[gradient,[0,0,0,0]] if gradient is not None else [vec(dx,p),vec(dy,p)];rhos=[]
      for d in derivs:
       if f['target']=='CUBE':
        face,m,sc,tc,u,v,axis=cube(c);dsc,dtc=[(-d[2],-d[1]),(d[2],-d[1]),(d[0],d[2]),(d[0],-d[2]),(d[0],-d[1]),(-d[0],-d[1])][face];dm=d[axis]*(1 if c[axis]>0 else -1);du=(dsc*m-sc*dm)/(2*m*m);dv=(dtc*m-tc*dm)/(2*m*m)
       else:du,dv=d[:2]
       rhos.append(math.hypot(du,dv)*levels[base][0])
      lod=math.log2(max(rhos)) if max(rhos)>0 else -100;l=max(base,min(2,base+math.floor(lod+bias+.5)))
     else:l=base
     w,h,layers,depths=levels[l]
     if f['target']=='CUBE':layer,major,sc,tc,u,v,_=cube(c)
     else:layer=max(0,min(layers-1,math.floor(c[2]+.5)));u,v=c[:2]
     tx=max(0,min(w-1,math.floor(u*w)));ty=max(0,min(h-1,math.floor(v*h)));depth=depths[(layer*h+ty)*w+tx]
     if shadow:
      compared=int(c[3]<=depth);sample=[compared*m+a for m,a in zip([1,2,.5,4],[-.5,.25,.125,-2])]
      if '_SAT' in f['opcode']:sample=[max(0,min(1,v)) for v in sample]
     else:sample=[depth,0,0,1]
     sample=list(map(raw,sample))
    result=[sample[k] if 'xyzw'[k] in writeMask else sentinels[k] for k in range(4)]
    if f.get('query'):
     w,h,layers,_=levels[f.get('baseLevel',0)];result[1:]=[h,0 if f['target']=='CUBE' else layers,3-f.get('baseLevel',0)]
    expected.extend(result)
  actual=words(blobs[f['output']['bytesKey']]);misses=[dict(word=k,expected=v,actual=actual[k]) for k,v in enumerate(expected) if v!=actual[k]];assert bool(misses)==fault,(directory.name,f['name'],misses[:12]);assert f['audit']['held']==(not fault)
  assert words(blobs[f['audit']['expectedBytesKey']])==expected
  complete=f['gpuComplete'];assert complete['writerEvent']<complete['createdEvent']<complete['consumedEvent']<f['output']['readEvent'];assert events[complete['createdEvent']]['method']=='fenceSync' and events[complete['consumedEvent']]['method']=='clientWaitSync' and events[complete['consumedEvent']]['result'] in [37146,37148];assert events[f['output']['readEvent']]['method']=='readPixels';assert f['cleaned'];assert all(e['result']==0 for e in region if e['method']=='getError')
  planeResults.append(dict(name=f['name'],words=len(expected),sourceSha256=sha(text.encode()),outputSha256=sha(blobs[f['output']['bytesKey']]),expectedSha256=sha(struct.pack('<'+str(len(expected))+'I',*expected)),mismatches=misses,fence=complete,readEvent=f['output']['readEvent'],uploads=uploads))
 assert len(planeResults)==(1 if fault else 182);assert len({f['name'] for f in planeResults})==len(planeResults)
 results.append(dict(path=str(directory),reportSha256=sha((directory/'report.json').read_bytes()),seed=a['seed'],status='EXPECTED FAULT' if fault else 'HELD',planes=planeResults,fullBodies=len(blobs)))
 print(directory.name,len(planeResults),'planes independently checked',flush=True)
(out/'gpu-audit.json').write_text(json.dumps(dict(status='HELD',results=results),indent=2)+'\n')
