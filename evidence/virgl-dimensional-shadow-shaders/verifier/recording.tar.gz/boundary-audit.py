import json,hashlib,tarfile,subprocess
from pathlib import Path
repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');cold=Path('/tmp/wasmvm-dimensional-shadow-cold-7e515708/recording');out=Path(__file__).parent;stage=Path('/tmp/wasmvm-dimensional-shadow-pages-7e515708');live=Path('/tmp/wasmvm-dimensional-shadow-live-7e515708');oldStage=Path('/tmp/wasmvm-dimensional-depth-view-pages-9698c0a9')
sha=lambda b:hashlib.sha256(b).hexdigest();head='7e51570851ef46eb10e8054f3a49b3bea8b79141'
# Original native signatures predict the Metal admission count and reflected types.
sig=json.loads((cold/'native/signature-inputs/cases.json').read_bytes())['cases'];native=[json.loads(l) for l in (cold/'native/signature-inputs/native.jsonl').read_text().splitlines()];report=json.loads((cold/'compile-link/report.json').read_bytes());a=report['acceptance'];assert report['browserErrors']==dict(console=[],page=[],requests=[]);assert report['browser']['launch']['headless']==False and 'Apple M4 Max' in a['gl']['renderer'] and 'Metal' in a['gl']['renderer'];assert len(a['compiles'])==78 and len(a['refusals'])==498
accepted={r['index']:r for r in a['compiles']};refused={r['index']:r for r in a['refusals']}
for i,c in enumerate(sig):
 _,st,target,decl,ty,slot,op=c['name'].split('/');okay=ty=='FLOAT' and (op in ['TEX','TXD','TXQ'] or st=='fragment' and target=='SHADOWCUBE' and op=='TXB2');assert native[i]['result']['ok']==okay
 if okay:
  r=accepted[i];assert r['result']==native[i]['result'] and r['stage']==st and r['text']==c['a'];assert all(s['okay'] for s in r['shaders']) and r['link']['okay'] and r['cleaned'];assert len(r['uniforms'])==1;u=r['uniforms'][0];assert u['name']==('vs' if st=='vertex' else 'fs')+'samp'+slot and u['index']==int(slot) and u['size']==1 and u['type']==(36293 if target=='SHADOWCUBE' else 36292)
 else:assert refused[i]['result']==native[i]['result'] and list(refused[i]['result'])==['ok','error']
# Actual fault execution and exact recovery assertions are repeated from pinned sanitizer binary.
workerAlloc=(cold/'native/allocations.jsonl').read_bytes();freshAlloc=(out/'fresh-allocations.jsonl').read_bytes();assert freshAlloc==workerAlloc
rows=[json.loads(l) for l in freshAlloc.splitlines()];baseline={r['mode']:r for r in rows if r['kind']=='baseline'};faults=[r for r in rows if 'fault' in r['kind']];mutations=[r for r in rows if r['kind']=='caller-custody'];assert len(faults)==181 and len(mutations)==5
for mode,r in baseline.items():
 sites=[f for f in faults if f['mode']==mode];assert len(sites)==r['allocations']+r['callocs'];assert sorted(f['site'] for f in sites if f['kind']=='upstream-fault')==list(range(1,r['allocations']+1));assert sorted(f['site'] for f in sites if f['kind']=='calloc-fault')==list(range(1,r['callocs']+1))
 for f in sites:assert list(f['result'])==['ok','error'] and f['result']['ok']==False
assert rows[-1]['faults']==rows[-1]['recoveries']==181 and rows[-1]['partialResults']==False
facade=json.loads((cold/'native/facade.json').read_bytes());assert facade['getters']==0 and facade['ownedSnapshots'] and facade['peerIsolation'] and facade['pressure']['recovered']
for r in facade['rejections']:assert list(r['result'])==['ok','error'] and r['result']['ok']==False
assert facade['pressure']['result']['error']['code']=='allocation-failed' and facade['pressure']['scratchFailure']['error']['message']=='Checked upstream TGSI parsing failed.'
receipt=json.loads((cold/'receipt.json').read_bytes());frames={}
for p in (cold/'stack').glob('*.su'):
 for row in p.read_text().splitlines():
  bits=row.split('\t');frames[bits[0].rsplit(':',1)[1]]=int(bits[1])
for mode,item in receipt['stack'].items():
 assert all(frames[n]==s for n,s in item['frames'].items());assert sum(item['frames'].values())==item['selectedFrameSumBytes']<262144
# Authenticate source-only checkout selection and rebuilt module exact bounds.
source=json.loads(Path('/tmp/wasmvm-dimensional-shadow-cold-7e515708/report.json').read_bytes());clone=Path(source['clone']);expectedDirs=set(subprocess.check_output(['git','ls-tree','-d','--name-only',head],cwd=repo,text=True).splitlines())-{'evidence','releases'};assert expectedDirs<=set(source['sourceCheckout']['included']);assert {'releases/kernel','releases/initramfs','releases/boot-snapshot'}<=set(source['sourceCheckout']['included']);assert source['sourceCheckout']['borrowedGeneratedArtifacts']==False
# File-for-file staging equivalence against unchanged qualified deployment.
staging=json.loads((stage/'staging-index.json').read_bytes());previous=json.loads((oldStage/'staging-index.json').read_bytes());assert sha((oldStage/'staging-index.json').read_bytes())==staging['heldIndexSha256'];assert len(staging['records'])==304
prior={r['path']:r for r in previous['records']};current={r['path']:r for r in staging['records']};assert set(prior)==set(current)
for directory,index in [(stage,staging),(oldStage,previous)]:
 for row in index['records']:
  b=(directory/'web/dist'/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
changed=[n for n in prior if prior[n]!=current[n]];assert sorted(changed)==['roadmap.js','sw.js']
assert sha((stage/'frozen-web-dist.tar').read_bytes())==staging['sourceArchiveSha256']
with tarfile.open(stage/'frozen-web-dist.tar') as tar:
 for entry in tar:
  if not entry.isfile():continue
  b=tar.extractfile(entry).read();assert b==subprocess.check_output(['git','show',head+':'+entry.name],cwd=repo)
  name=entry.name[len('web/dist/'):]
  carry=next((r for r in staging['carriedBootManifests'] if r['path']==name),None)
  if carry:assert sha(b)==carry['sourceSha256'] and current[name]['sha256']==carry['stagedSha256']
  else:assert sha(b)==current[name]['sha256']
confirm=json.loads((stage/'cloudflare-cli-confirmation.json').read_bytes());pub=json.loads((stage/'publish.json').read_bytes());assert pub['exitCode']==0;assert sha((stage/'publish.json').read_bytes())==confirm['publishReceiptSha256'];assert sha((stage/'deployment-list.stdout').read_bytes())==confirm['listSha256'];assert confirm['head']==head
for name in ['stdout','stderr']:assert sha((stage/('publish.'+name)).read_bytes())==pub[name+'Sha256']
assert confirm['id']=='7112b2df-1f4f-4f2a-a039-b429e39f5835' and confirm['id'] in (stage/'deployment-list.stdout').read_text() and confirm['url'] in (stage/'publish.stdout').read_text()
browserResults=[]
for folder in [cold/'default-demo',live,out/'fresh-canonical']:
 r=json.loads((folder/'report.json').read_bytes());assert r['status']=='passed' and r['passed']==127 and r['failed']==0 and not r['errors'] and r['proofExportAbsent'] and r['graphicsRoadmapPip']=='cap-pip partial' and r['roadmapPip']=='cap-pip live';assert r['servedWasmSha256']=='d45b575207e0035b5c518698e7b6793b2bf12da635531723fad70813a5956c36'
 served=r['served']
 if folder!=cold/'default-demo':
  for row in served:
   name=row['path'].lstrip('/');b=(folder/'bodies'/name).read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes'];name='app.html' if name=='app' else name;assert sha(b)==current[name]['sha256'];assert not r['httpErrors']
  roadmap=(folder/'bodies/roadmap.js').read_text();assert 'selected original cube/array comparison shader compilation (E6-T11d61)' in roadmap and 'production acceleration disabled' in roadmap
 browserResults.append(dict(path=str(folder),reportSha256=sha((folder/'report.json').read_bytes()),passed=127,failed=0,errors=0,partial=True,wholeServedBodies=len(served)))
result=dict(status='HELD',nativeMetalSignatures=576,compiled=78,refused=498,hostFacadeRefusals=len(facade['rejections']),genuineFaults=181,exactFreshRecovery=True,callerMutationModes=5,stack=receipt['stack'],cleanCheckoutIncludesAllSourceDirectories=True,sourceAndRequiredDemoInputsOnly=True,stagingBodies=304,changedStagedBodies=changed,deployment=confirm,browsers=browserResults)
(out/'boundary-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
