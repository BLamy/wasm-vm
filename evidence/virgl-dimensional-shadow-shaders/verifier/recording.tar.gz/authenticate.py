import json,hashlib,gzip,tarfile,subprocess
from pathlib import Path
repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');out=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
pins={
'worker':('862ccad57dcd39ef940c2ba495c4a638e3e30f82fd4b34546240937b7ce550f1','7211cf03b9264aa5215d8d90474fececa5d748bd35a43a0bed2fb1a1d89aac01','d0a39567532a609f313ef2d2a39bea3473d05e7d4d1a43bf5a29edf03221d337'),
'deployment':('02252e62162ee1eefcc5a56cf854123e4a5c99b37aa62a63899682676c5362b6','460526f4a3b2713c2f605c85eefdab8c9022da016396255bf7d181f43cdc8252','13141c907e5b6d55f80ba0059b2e4cc6cc6dc6307dd27f925ddfabe77192ea21')}
results=[]
for name,expected in pins.items():
 s=repo/'evidence/virgl-dimensional-shadow-shaders'/name
 for path,digest in zip(['manifest.json','records.json','recording.tar.gz'],expected):assert sha((s/path).read_bytes())==digest,path
 manifest=json.loads((s/'manifest.json').read_bytes());index=json.loads((s/'records.json').read_bytes());seen={};count=real=links=raw=0
 with gzip.open(s/'recording.tar.gz','rb') as gz:
  with tarfile.open(fileobj=gz,mode='r|') as tar:
   for entry in tar:
    row=index['records'][count];assert entry.name==row['path'];assert not entry.name.startswith('/') and '..' not in Path(entry.name).parts
    if entry.islnk():assert entry.linkname==row['target'] and row['kind']=='hardlink' and entry.linkname in seen;assert seen[entry.linkname]==(row['bytes'],row['sha256']);links+=1
    else:
     assert entry.isfile();body=tar.extractfile(entry).read();assert len(body)==row['bytes'] and sha(body)==row['sha256'];real+=1
    seen[entry.name]=(row['bytes'],row['sha256']);count+=1
    # Independently bind authoritative raw custody to every sealed logical path.
    mappings={'cold/':'/tmp/wasmvm-dimensional-shadow-cold-7e515708/','earlier-failed/':'/tmp/wasmvm-dimensional-shadow-cold-b555747b/','publication/':'/tmp/wasmvm-dimensional-shadow-pages-7e515708/','live/':'/tmp/wasmvm-dimensional-shadow-live-7e515708/'}
    for prefix,path in mappings.items():
     if entry.name.startswith(prefix):
      p=Path(path)/entry.name[len(prefix):];body=p.read_bytes();assert (len(body),sha(body))==seen[entry.name],str(p);raw+=1;break
  while gz.read(1024*1024):pass
 assert count==len(index['records'])==manifest['records'];assert manifest['archiveSha256']==expected[2] and manifest['recordIndexSha256']==expected[1]
 results.append(dict(seal=name,manifest=expected[0],index=expected[1],archive=expected[2],logicalMembers=count,realBodies=real,backwardLinks=links,rawLogicalBodiesRebound=raw,gzipEof=True))
 print(results[-1],flush=True)
cold=Path('/tmp/wasmvm-dimensional-shadow-cold-7e515708');report=json.loads((cold/'report.json').read_bytes());r=cold/'recording';receipt=json.loads((r/'receipt.json').read_bytes());head=receipt['head'];assert head==report['head']=='7e51570851ef46eb10e8054f3a49b3bea8b79141';assert sha((r/'receipt.json').read_bytes())==report['receiptSha256']=='d6ece2048e9883a812ab09d646e8fa1ab6331446a5758d5ef373eda57e1bb87f'
clone=Path(report['clone']);git=lambda *args:subprocess.check_output(['git',*args],cwd=clone,text=True).strip()
assert git('rev-parse','HEAD')==head and not git('status','--porcelain','--untracked-files=no');assert not report['cleanBefore'] and not report['cleanAfter'] and report['exitCode']==0
assert len(receipt['commands'])==41
for command in receipt['commands']:
 assert command['exitCode']==command['expected'];assert sha((r/(command['name']+'.stdout')).read_bytes())==command['stdoutSha256'];assert sha((r/(command['name']+'.stderr')).read_bytes())==command['stderrSha256']
for name,pin in receipt['sources'].items():
 body=(r/'sources'/name).read_bytes();assert len(body)==pin['bytes'] and sha(body)==pin['sha256'];assert body==subprocess.check_output(['git','show',head+':'+name],cwd=clone);assert body==(clone/name).read_bytes()
for name,pin in receipt['generated'].items():
 for p in [r/'generated'/name,clone/name]:body=p.read_bytes();assert len(body)==pin['bytes'] and sha(body)==pin['sha256']
assert not subprocess.check_output(['git','diff','--name-only','b555747b0b51786e087a43e27b5021e4e7a1838c','HEAD','--','renderer/virgl-shader'],cwd=repo)
assert not subprocess.check_output(['git','diff','--name-only','04ab18042036bf0ab19864bbe38e787dd4aadf48','HEAD','--','crates','renderer/virgl-command','tools/guest'],cwd=repo)
failed=json.loads(Path('/tmp/wasmvm-dimensional-shadow-cold-b555747b/report.json').read_bytes());assert failed['exitCode']!=0
result=dict(status='HELD',seals=results,sourcePins=len(receipt['sources']),generatedPins=len(receipt['generated']),commands=41,receipt=sha((r/'receipt.json').read_bytes()),cloneHead=head,cloneTrackedClean=True,runtimeUnchangedSince='b555747b',consumerRustGuestUnchangedSince='04ab1804',earlierFailurePreserved=failed)
(out/'authentication.json').write_text(json.dumps(result,indent=2)+'\n')
