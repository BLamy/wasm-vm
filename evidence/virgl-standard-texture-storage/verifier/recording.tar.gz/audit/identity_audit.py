from pathlib import Path
import json,hashlib,subprocess,tarfile,traceback
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=Path('/tmp/wasm-vm-e6-t11d20-critic-20261010');U=OUT/'unpacked';HEAD='cde73ac477b4cab52e84f7a8995c701bf71cdca6';BASE='52d3cc4e2f0f28d82a2900ff33ab855ae118e66e'
sha=lambda b:hashlib.sha256(b).hexdigest();rows=[];cache={}
def committed(h,n):
 k=(h,n)
 if k not in cache:cache[k]=subprocess.check_output(['git','show',h+':'+n],cwd=ROOT)
 return cache[k]
def main():
 for side in ['hot','cold']:
  r=json.loads((U/side/'receipt.json').read_text())
  for n,d in r['files'].items():assert sha((U/side/n).read_bytes())==d,(side,n)
  for n,d in r['sources'].items():assert sha(committed(HEAD,n))==d,(side,n)
  for n,d in r['generated'].items():assert sha((U/(side+'-generated')/n).read_bytes())==d,(side,n)
  for n,d in r['carriedVerifiedEvidence'].items():assert sha(committed(BASE,n))==sha(committed(HEAD,n))==d,(side,n)
  for name in ['wire','hardware','fault-upload-level','fault-read-level','retained-command-decoder','retained-resource-transfers','retained-color-formats']:
   report=json.loads((U/side/name/'report.json').read_text());assert report['gitHead']==HEAD
   for s in report['sources']:
    raw=(U/(side+'-generated')/s['path']).read_bytes() if '/build/' in s['path'] else committed(HEAD,s['path'])
    assert sha(raw)==s['sha256'] and ('bytes' not in s or len(raw)==s['bytes']),(side,name,s['path'])
   served={s['path']:s for s in report.get('servedFiles',[])}
   for s in report['sources']:
    if '/'+s['path'] in served:assert served['/'+s['path']]['sha256']==s['sha256'] and ('bytes' not in s or served['/'+s['path']]['bytes']==s['bytes'])
   if 'browserCoverage' in report:
    coverage=json.loads((U/side/name/report['browserCoverage']['path']).read_text())
    for s in coverage.get('scripts', [coverage] if 'source' in coverage else []):assert s['sha256']==served['/'+s['source']]['sha256'] and s['coverage']['url'].endswith('/'+s['source'])
   rows.append({'side':side,'path':name+'/report.json','sha256':sha((U/side/name/'report.json').read_bytes()),'status':report['status'],'sources':len(report['sources'])})
 prefixes=['evidence/virgl-standard-sampler-state','evidence/virgl-standard-buffer-roles','evidence/virgl-standard-uniform-bindings','evidence/virgl-standard-uniform']
 names=subprocess.check_output(['git','ls-tree','-r','--name-only',BASE,'--',*prefixes],cwd=ROOT,text=True).splitlines()
 for n in names:
  a=subprocess.check_output(['git','rev-parse',BASE+':'+n],cwd=ROOT,text=True);b=subprocess.check_output(['git','rev-parse',HEAD+':'+n],cwd=ROOT,text=True);assert a==b,n
 for n in names:
  if not n.endswith('/manifest.json'):continue
  prefix=n[:-len('manifest.json')];m=json.loads((ROOT/n).read_text());idxraw=(ROOT/(prefix+'records.json')).read_bytes();archive=ROOT/(prefix+'recording.tar.gz');archive_hash=sha(archive.read_bytes())
  assert sha(idxraw)==m['recordIndexSha256'] and archive_hash==m['archiveSha256'],prefix
  idx=json.loads(idxraw);records={p['path']:p for p in idx['records']};assert len(records)==len(idx['records'])
  with tarfile.open(archive,mode='r:gz') as t:
   members=t.getmembers();assert len(members)==len(records)
   for member in members:
    assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
    raw=t.extractfile(member).read();p=records[member.name];assert len(raw)==p['bytes'] and sha(raw)==p['sha256'],(prefix,member.name)
  rows.append({'inherited':prefix,'records':len(records),'archiveSha256':archive_hash,'indexSha256':sha(idxraw),'sourceBoundary':'exact-identical-to-D19'})
  print('Authenticated',prefix,len(records),flush=True)
 result={'status':'passed','sourceHead':HEAD,'reports':rows,'frozenSourceFiles':len(json.loads((U/'hot/receipt.json').read_text())['sources'])}
 (OUT/'identity-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
try:main()
except BaseException as error:
 (OUT/'identity-audit-failure.json').write_text(json.dumps({'status':'audit-harness-failed','error':str(error),'traceback':traceback.format_exc(),'verifiedBeforeFailure':rows},indent=2)+'\n')
 raise
