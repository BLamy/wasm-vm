from pathlib import Path
import json,subprocess,re,hashlib
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=Path('/tmp/wasm-vm-e6-t11d20-critic-20261010');U=OUT/'unpacked';HEAD='cde73ac477b4cab52e84f7a8995c701bf71cdca6';BASE='52d3cc4e2f0f28d82a2900ff33ab855ae118e66e';sha=lambda b:hashlib.sha256(b).hexdigest()
records=[]
for side in ['hot','cold']:
 for file in (U/side).rglob('browser-coverage.json'):
  content=json.loads(file.read_text())
  for row in content.get('scripts',[content]if'source'in content else[]):records.append(dict(record=str(file.relative_to(U)),**row))
 for file in (U/side/'node-coverage').glob('coverage-*.json'):
  for row in json.loads(file.read_text())['result']:
   for name in ['renderer/virgl-command/decoder.mjs','renderer/virgl-command/resources.mjs','renderer/virgl-command/tests/standard-texture-storage.mjs']:
    if row['url'].endswith('/'+name):records.append(dict(record=str(file.relative_to(U)),source=name,coverage=row))
for file in (ROOT/'target/evidence/virgl-standard-texture-storage-critic').rglob('browser-coverage.json'):
 if 'fresh-2463613825/' in str(file):continue
 for row in json.loads(file.read_text())['scripts']:
  if row['source']!='attack.mjs':records.append(dict(record=str(file.relative_to(ROOT)),**row))
textdiff=subprocess.check_output(['git','diff','--unified=0',BASE,HEAD,'--','renderer/virgl-command'],cwd=ROOT,text=True);name=None;hunks=[]
for line in textdiff.splitlines():
 if line.startswith('+++ b/'):name=line[6:]
 elif line.startswith('@@'):
  m=re.search(r'\+(\d+)(?:,(\d+))?',line);hunks.append(dict(source=name,line=int(m[1]),count=int(m[2]or 1),header=line))
texts={n:subprocess.check_output(['git','show',HEAD+':'+n],cwd=ROOT,text=True) for n in {h['source']for h in hunks}}
functions=[]
for name,text in texts.items():
 if not name.endswith('.mjs'):continue
 related=[r for r in records if r['source']==name]
 for record in related:
  if 'sha256' in record:assert record['sha256']==sha(text.encode())
 keyed={}
 for record in related:
  for fn in record['coverage']['functions']:
   top=fn['ranges'][0];key=(fn['functionName'],top['startOffset'],top['endOffset']);keyed.setdefault(key,[]).append((record['record'],fn))
 lineof=lambda i:text[:i].count('\n')+1
 for (fn,start,end),runs in keyed.items():
  if not start:continue
  if not any(h['source']==name and lineof(start)<=h['line']+h['count']-1 and lineof(end)>=h['line']for h in hunks):continue
  if name.endswith('resources.mjs') and fn not in ['normalizeMetadata','layoutFor','createStore','initializeXAlpha','allocate','upload','readback','beginReadback','createStandardTextureResourceStore','computeStandardTextureTransferLayout'] and end-start>2000:continue
  ranges={}
  for record,f in runs:
   for r in f['ranges']:ranges.setdefault((r['startOffset'],r['endOffset']),[]).append(dict(record=record,count=r['count']))
  classified=[]
  for (a,b),counters in ranges.items():
   # Compare the narrowest region at each endpoint atom in every capture. A
   # containing hit cannot cover an unexecuted nested branch.
   endpoints=sorted({a,b,*[p for record in related for f in record['coverage']['functions']for r in f['ranges']for p in [r['startOffset'],r['endOffset']]if a<p<b]})
   atoms=[]
   for left,right in zip(endpoints,endpoints[1:]):
    sample=(left+right)//2;counts=[]
    for record in related:
     containing=[r for f in record['coverage']['functions']for r in f['ranges']if r['startOffset']<=sample<r['endOffset']]
     if containing:counts.append(dict(record=record['record'],count=min(containing,key=lambda r:r['endOffset']-r['startOffset'])['count']))
    atoms.append(dict(start=left,end=right,maxCount=max((r['count']for r in counts),default=0),counters=counts))
   zeros=[r for r in atoms if not r['maxCount'] and text[r['start']:r['end']].strip()]
   for zero in zeros:zero.update(lineStart=lineof(zero['start']),lineEnd=lineof(zero['end']),text=text[zero['start']:zero['end']])
   classified.append(dict(start=a,end=b,lineStart=lineof(a),lineEnd=lineof(b),maxRecordedRangeCount=max(r['count']for r in counters),zeroAtoms=zeros,counters=counters))
  functions.append(dict(source=name,function=fn,start=start,end=end,lineStart=lineof(start),lineEnd=lineof(end),ranges=classified))
zeros={}
for fn in functions:
 for region in fn['ranges']:
  for z in region['zeroAtoms']:zeros[(fn['source'],z['start'],z['end'])]=z
for (name,a,b),zero in zeros.items():print(name,zero['lineStart'],zero['lineEnd'],repr(zero['text'][:240]))
(OUT/'coverage-regions.json').write_text(json.dumps(dict(sourceHead=HEAD,predecessor=BASE,hunks=hunks,scripts=records,functions=functions,zeroAtoms=[dict(source=k[0],**v)for k,v in zeros.items()]),indent=2)+'\n');print('Functions',len(functions),'nested ranges',sum(len(x['ranges'])for x in functions),'zero atoms',len(zeros))
