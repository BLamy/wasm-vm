from pathlib import Path
import json,subprocess,re,hashlib
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=Path('/tmp/wasm-vm-e6-t11d20-critic-20261010');BASE='52d3cc4e2f0f28d82a2900ff33ab855ae118e66e';SUBMISSION='a229993e20de3e8b14d64b5c9004292f9c41f614'
audit=json.loads((OUT/'coverage-regions.json').read_text());waivers=[]
for z in audit['zeroAtoms']:
 name=z['source'];a,b=z['lineStart'],z['lineEnd'];reason=None
 if name.endswith('/tests/standard-texture-storage.mjs'):
  if a==13:reason='Admission-only tiny fixture stub is not a GPU result oracle; full actual native storage/transfer proof exercises corresponding admitted behavior.'
  elif a in [8,52,79,82,161]:reason='Harness diagnostic, buffer-only identity fallback, absent-hardware renderer fallback or watchdog failure; no admitted mip product semantics are delegated to this branch.'
  elif a==164:reason='Optional smoke shortcut is outside the deterministic full acceptance command; full matrix path executed.'
 elif name.endswith('decoder.mjs'):
  if a in [561,567,570,571,580,591,595,600]:reason='Exact unchanged pre-existing byte-input guard, uniform-command dispatch or unexpected-defect propagation; D20 only adds the host-selected facet and transfer-level admission. Decoder source diff and authenticated D16/D17/D19 seals retain this separate boundary; affected legacy decoder acceptance passed hot/cold.'
 elif name.endswith('resources.mjs'):
  if a==85 or 528<=a<=535 or 751<=a<=788 or 599<=a<=601:reason='Exact unchanged standard-buffer/uniform/depth role or uniform range branch outside selected color mip boundary; D16/D17/D18/D19 whole sealed archives and dependency sources authenticate unchanged. Old factories retain level0-only metadata; view/surface new mip role branches execute.'
  elif a in [90,177,196,200,958,1009,1050,1052,1056,1057,1061]:reason='Pre-existing depth16 allocation/conversion branch has no multilevel admission. New selected-level expressions evaluate their qualified color arm; the converted depth texture still selects literal level0. Exact depth code outside this level selector is unchanged.'
  elif a in [342,434,479]:reason='Pre-existing scratch/input-reflection or backend-retirement host-defect fallback; outside changed storage metadata/layout/native-level semantics. Actual native mip allocation/upload/readPixels/fence faults and cleanup execute under recorded native captures.'
  elif a in [594,654,702,745,1063]:reason='Exact unchanged storage-read/scanout/inspection or element/other-data async buffer-copy path; selected mip scanout remains rejected, and new original mip PBO transfer disposal/revocation/native failure paths execute. Authenticated previous owner/buffer proof retains this separate unchanged dependency boundary.'
 if not reason:raise ValueError(('unclassified nested region',name,a,b,z['text']))
 waivers.append(dict(**z,classification='waived',reason=reason))
diff=subprocess.check_output(['git','diff','--unified=0',BASE,SUBMISSION],cwd=ROOT,text=True);name=None;hunks=[]
for row in diff.splitlines():
 if row.startswith('+++ b/'):name=row[6:]
 elif row.startswith('@@'):
  m=re.search(r'\+(\d+)(?:,(\d+))?',row);line=int(m[1]);count=int(m[2]or 1)
  if name in ['renderer/virgl-command/decoder.mjs','renderer/virgl-command/resources.mjs']:classification='executed';reason='Full nested V8 regions are authenticated across worker wire/native/fault/legacy hot/cold and fresh native schedules; every zero atom has an explicit unchanged-boundary waiver. All changed selected metadata, checked level/layout, new factory/profile, native allocation/alpha/upload/read/PBO selector and view/surface mip-role arms execute.'
  elif name.endswith('/standard-texture-storage.mjs'):classification='executed-with-harness-waivers';reason='Full acceptance wire and headed native/fault modules execute; only explicitly listed tiny fixture, absent-hardware, timeout/diagnostic, and optional smoke branches waive.'
  elif name.startswith('tools/')or name=='Makefile':classification='executed-with-harness-waivers';reason='Exact frozen make acceptance hot and pristine scrubbed cold, record audits, complete source/served/generated/native/V8 receipts, and seal execute this harness. Negative verifier oracle sources are independent. Assertion/error-report/control plumbing has no product admission authority; read scripts fully.'
  elif name.startswith('evidence/'):classification='waived';reason='Immutable declarative proof/index/archive/negative-gap data; every worker archive member and index/source identity authenticated, rather than executed as product code.'
  else:classification='waived';reason='Documentation or task/dependency/status/queue metadata only; no runtime behavior. Claim remains isolated mip storage/transfers and production successors remain gated.'
  hunks.append(dict(source=name,line=line,count=count,header=row,classification=classification,reason=reason))
result=dict(status='passed',sourceHead=audit['sourceHead'],reviewedSubmission=SUBMISSION,fullNestedRegions=True,functions=len(audit['functions']),nestedRegions=sum(len(f['ranges'])for f in audit['functions']),zeroAtoms=len(waivers),unclassifiedChangedProductRegions=0,deadChangedProductRegions=0,needsEvidenceChangedProductRegions=0,hunks=hunks,waivers=waivers)
(OUT/'coverage-classification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in['hunks','waivers']},indent=2));print('classified diff hunks',len(hunks))
