from pathlib import Path
import json,hashlib,gzip,struct,traceback
OUT=Path('/tmp/wasm-vm-e6-t11d20-critic-20261010');U=OUT/'unpacked';sha=lambda b:hashlib.sha256(b).hexdigest()
def chain(m):return [dict(level=l,width=max(1,m['width']//2**l),height=max(1,m['height']//2**l),byteLength=4*max(1,m['width']//2**l)*max(1,m['height']//2**l)) for l in range(m['lastLevel']+1)]
def canon(fmt,raw):
 b=bytearray(raw)
 if fmt==2:b[3::4]=bytes([255])*(len(b)//4)
 if fmt==233:
  for i in range(3,len(b),4):b[i]|=192
 return b
def native(fmt,raw):
 if fmt==233:
  return b''.join(struct.pack('<I',(w//1048576)%1024+(w//1024)%1024*1024+w%1024*1048576+3221225472) for (w,) in struct.iter_unpack('<I',raw))
 if fmt==2:
  return b''.join(bytes([raw[i+2],raw[i+1],raw[i],255]) for i in range(0,len(raw),4))
 return bytes(raw)
def wire(raw):
 b=bytes.fromhex(raw);header=struct.unpack_from('<I',b)[0];op=header%256;n=header//65536;assert len(b)==4*(n+1) and op in [9,43,45];w=struct.unpack_from('<'+'I'*n,b,4)
 return dict(op=op,id=w[0],level=w[1],usage=w[2],stride=w[3],layerStride=w[4],x=w[5],y=w[6],z=w[7],width=w[8],height=w[9],depth=w[10],offset=0 if op==9 else w[11] if op==43 else w[12],upload=op==9 or (w[12]==1 if op==43 else w[13]==1),inline=b[48:] if op==9 else None)
def image(fmt,w,h,lev,seed):
 raw=bytearray()
 for y in range(h):
  for x in range(w):
   r=(seed+17*x+31*y+53*lev)&0xffffffff;g=(seed+71*x+11*y+97*lev)&0xffffffff;b=(seed+41*x+83*y+19*lev)&0xffffffff;a=(seed+23*x+61*y+37*lev)&0xffffffff
   if fmt==233:raw+=struct.pack('<I',b%1024+g%1024*1024+r%1024*1048576+a%4*1073741824)
   else:raw+=bytes([b%256,g%256,r%256,a%256] if fmt==2 else [r%256,g%256,b%256,a%256])
 return raw
def main():
 summary=[]
 for side in ['hot','cold']:
  wr=json.loads((U/side/'wire/report.json').read_text());assert len(wr['wire']['records'])==1062;assert all(p['held'] and p['expected']==p['observed'] for p in wr['wire']['predictions'])
  for row in wr['wire']['records']:assert row['levels']==chain(row['metadata']) and row['byteLength']==sum(l['byteLength'] for l in chain(row['metadata']))
  report=json.loads((U/side/'hardware/report.json').read_text());e=report['browserResult']['result'];assert report['browserErrors']==dict(console=[],page=[],requests=[]);assert not report['browser']['headless'];assert 'Metal' in e['gpu']['renderer'] and 'M4' in e['gpu']['renderer'];assert all(p['held'] and p['expected']==p['observed'] for p in e['predictions'])
  records=[];outputs=[];nativeUploads=[];states=[];blobs={}
  for b in e['blobs']:
   gz=(U/side/'hardware'/b['path']).read_bytes();raw=gzip.decompress(gz);assert sha(gz)==b['gzipSha256'] and sha(raw)==b['sha256'] and len(raw)==b['bytes'];blobs[b['key']]=raw
  for ri,run in enumerate(e['runs']):
   m=run['originalMetadata'];ch=chain(m);state=[canon(m['format'],bytes(l['byteLength'])) for l in ch];versions=[[bytes(b) for b in state]];uploadindex=0
   allocationCalls=[c for c in run['calls'] if c['op']=='texStorage2D'];
   for c in allocationCalls:
    if c['args'][1]==0:continue
    assert c['args'][1:]==[m['lastLevel']+1,{2:32849,67:32856,233:32857}[m['format']],m['width'],m['height']],(side,ri,c)
   for oi,o in enumerate(run['operations']):
    w=wire(o['wire']);l=ch[w['level']];stride=w['stride'] or l['width']*4;layer=w['layerStride'] or stride*l['height'];footprint=(w['height']-1)*stride+w['width']*4;layout=o['layout'];assert w['id']==m['id'] and w['z']==0 and w['depth']==1
    assert [layout.get('level',0),layout.get('levelWidth',m['width']),layout.get('levelHeight',m['height'])]==[w['level'],l['width'],l['height']]
    assert [layout['rowBytes'],layout['rowCount'],layout['rowStride'],layout['layerStride'],layout['footprintBytes'],layout['requiredEnd'],layout['tightBytes']]==[w['width']*4,w['height'],stride,layer,footprint,w['offset']+footprint,w['width']*w['height']*4]
    if not o.get('rejected') and not o.get('cancelled'):
     if o.get('gpuOnly'):
      color=o['gpuOnly']['rgba'];assert o['gpuOnly']['level']==w['level'];r,g,b,a=[int(v*(1023 if m['format']==233 else 255)+.5) for v in color]
      pix=struct.pack('<I',b+g*1024+r*1048576+3221225472) if m['format']==233 else bytes([b,g,r,255] if m['format']==2 else [r,g,b,a]);state[w['level']][:]=pix*(l['width']*l['height'])
     if w['upload']:
      raw=blobs[o['input']]
      if w['op']==9:assert w['inline'][:len(raw)]==raw and len(w['inline'])==4*((footprint+3)//4);raw=w['inline']
      dense=bytearray()
      for y in range(w['height']):
       start=y*w['width']*4 if o['asynchronous'] and w['op']!=9 else w['offset']+y*stride;row=raw[start:start+w['width']*4];assert len(row)==w['width']*4;dense+=row;start2=((w['y']+y)*l['width']+w['x'])*4;state[w['level']][start2:start2+len(row)]=canon(m['format'],row)
      recorded=run['uploads'][uploadindex];uploadindex+=1;expected=native(m['format'],canon(m['format'],dense))
      if m['format']==2:expected=b''.join(expected[i:i+3] for i in range(0,len(expected),4))
      assert recorded['level']==recorded['nativeLevel']==w['level'];assert blobs[recorded['blob']]==expected,(side,ri,oi,'original upload native bytes')
      nativeUploads.append(dict(side=side,run=ri,operation=oi,level=w['level'],bytes=len(expected),sha256=sha(expected)))
     elif o.get('output'):
      tight=b''.join(state[w['level']][((w['y']+y)*l['width']+w['x'])*4:((w['y']+y)*l['width']+w['x']+w['width'])*4] for y in range(w['height']));observed=blobs[o['output']]
      if o['asynchronous']:expected=tight;assert o['fenceCompleted'] and o['polls']>=1
      else:
       expected=bytearray([0xa7])*(w['offset']+footprint)
       for y in range(w['height']):expected[w['offset']+y*stride:w['offset']+y*stride+w['width']*4]=tight[y*w['width']*4:(y+1)*w['width']*4]
      assert bytes(expected)==observed,(side,ri,oi,'complete original inverse/padding')
      outputs.append(dict(side=side,run=ri,operation=oi,level=w['level'],bytes=len(observed),sha256=sha(observed),fenceCompleted=o.get('fenceCompleted',False)))
    versions.append([bytes(b) for b in state])
   assert all(v==0 for v in run['final']['budgets'].values());assert all(o['deleted']==1 for o in run['objects']);states.append(versions)
  for i,row in enumerate(e['levels']):
   m=row['metadata'];l=chain(m)[row['level']];expected=states[row['run']][row['operationCount']][row['level']];observed=blobs[row['native']];assert row['width']==l['width'] and row['height']==l['height'];assert observed==native(m['format'],expected);assert blobs[row['expectedGuest']]==expected
   words=[w[0] for w in struct.iter_unpack('<I',observed)] if m['format']==233 else list(observed);assert row['nativeWords']==words
   records.append(dict(side=side,record='hardware/report.json',jsonPoint=f'/browserResult/result/levels/{i}',run=row['run'],operationCount=row['operationCount'],level=row['level'],label=row['label'],texels=l['width']*l['height'],nativeSha256=sha(observed),expectedGuestSha256=sha(expected),held=True))
  (OUT/(side+'-native-audit.jsonl')).write_text(''.join(json.dumps(r)+'\n' for r in records));(OUT/(side+'-inverse-audit.jsonl')).write_text(''.join(json.dumps(r)+'\n' for r in outputs));(OUT/(side+'-upload-audit.jsonl')).write_text(''.join(json.dumps(r)+'\n' for r in nativeUploads))
  summary.append(dict(side=side,runs=len(e['runs']),levels=len(records),texels=sum(r['texels'] for r in records),inverseTransfers=len(outputs),fencedInverseTransfers=sum(r['fenceCompleted'] for r in outputs),nativeUploads=len(nativeUploads),wireRecords=len(wr['wire']['records']),wirePredictions=len(wr['wire']['predictions'])))
 (OUT/'recording-audit.json').write_text(json.dumps({'status':'passed','reports':summary},indent=2)+'\n');print(json.dumps(summary,indent=2))
try:main()
except BaseException as error:(OUT/'recording-audit-failure.json').write_text(json.dumps({'status':'failed','error':str(error),'traceback':traceback.format_exc()},indent=2)+'\n');raise
