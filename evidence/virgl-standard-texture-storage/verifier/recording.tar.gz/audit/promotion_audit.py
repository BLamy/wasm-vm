from pathlib import Path
import gzip,hashlib,json,subprocess

ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
OUT=Path('/tmp/wasm-vm-e6-t11d20-critic-20261010')
E=ROOT/'target/evidence/virgl-standard-texture-storage-critic'
P=E/'promoted'
HEAD='835ccfcfcbfe31c4c22a799b1c521841df4d1352'
STORAGE='cde73ac477b4cab52e84f7a8995c701bf71cdca6'
sha=lambda b:hashlib.sha256(b).hexdigest()
committed=lambda h,n:subprocess.check_output(['git','show',h+':'+n],cwd=ROOT)

receipt=json.loads((P/'receipt.json').read_text())
assert receipt['gitHead']==HEAD and receipt['status']=='passed'
for name,digest in receipt['sources'].items():
    assert sha((ROOT/name).read_bytes())==sha(committed(HEAD,name))==digest,name
for name in ['renderer/virgl-command/resources.mjs','renderer/virgl-command/decoder.mjs']:
    assert committed(STORAGE,name)==committed(HEAD,name),name
assert (ROOT/'tools/virgl-command/standard-texture-adversarial.mjs').read_bytes()==(OUT/'attack.mjs').read_bytes()
assert (ROOT/'tools/virgl-command/standard-texture-adversarial-audit.py').read_bytes()==(OUT/'audit_attack.py').read_bytes()
for name,digest in receipt['files'].items():assert sha((P/name).read_bytes())==digest,name

rows=[]
for name,earlier in [('seed-2463613825','complete-2463613825'),('seed-2135583533','complete-2135583533'),('seed-3091592025','complete-3091592025'),('fault-native-level','sabotage-complete-native-level')]:
    directory=P/name
    r=json.loads((directory/'report.json').read_text())
    assert r['gitHead']==r['runtimeHead']==HEAD and r['reviewedStorageHead']==STORAGE
    for s in r['sources']:
        source=(ROOT/'tools/virgl-command/standard-texture-adversarial.mjs').read_bytes() if s['name']=='attack.mjs' else committed(HEAD,s['name'])
        assert sha(source)==s['sha256'] and len(source)==s['bytes']
    assert r['runner']['sha256']==receipt['sources']['tools/verify-virgl-standard-texture-storage-adversarial.mjs']
    assert not r['browser']['headless'] and not any('headless' in arg.lower() for arg in r['browser']['commandLine'])
    assert sha(Path(r['browser']['executable']).read_bytes())==r['browser']['sha256']
    assert sha(Path(r['host']['executable']).read_bytes())==r['host']['sha256']
    current=r.get('partial',r['browserResult'].get('result'))
    past=json.loads((E/earlier/'report.json').read_text());past=past.get('partial',past['browserResult'].get('result'))
    assert len(current['blobs'])==len(past['blobs']) and len(current['runs'])==len(past['runs'])
    for a,b in zip(current['blobs'],past['blobs']):
        assert a['key']==b['key']
        assert sha(gzip.decompress((directory/a['path']).read_bytes()))==a['sha256']
        assert sha(gzip.decompress((E/earlier/b['path']).read_bytes()))==b['sha256']
    for a,b in zip(current['runs'],past['runs']):
        assert a['originalMetadata']==b['originalMetadata'] and a['replacementMetadata']==b['replacementMetadata']
        assert [(x['label'],x['level'],x['operationCount'],x['held']) for x in a['observations']]==[(x['label'],x['level'],x['operationCount'],x['held']) for x in b['observations']]
    pastproof=json.loads((E/earlier/'independent-audit.json').read_text())
    assert pastproof['status']=='passed'
    calls=current['nativeCalls'];fences={};allfences=[];reads=0;gets=0
    for i,c in enumerate(calls):
        if c['op']=='readPixels':reads+=1
        if c['op']=='fenceSync':
            assert c['returned'] not in fences or fences[c['returned']]['deleted'] is not None
            assert any(x['op']=='readPixels' for x in calls[max(0,i-3):i]),'actual native read precedes fence'
            fences[c['returned']]=dict(created=i,completed=None,deleted=None)
            allfences.append(fences[c['returned']])
        elif c['op']=='clientWaitSync':
            f=fences[c['args'][0]];assert f['created']<i and c['returned'] in [37146,37147,37148]
            if c['returned']!=37147:f['completed']=i
        elif c['op']=='getBufferSubData':
            gets+=1;previous=calls[i-1]
            assert previous['op']=='clientWaitSync' and previous['returned'] in [37146,37148],'physical bytes publish after completed native fence'
            assert fences[previous['args'][0]]['completed']==i-1
        elif c['op']=='deleteSync':
            f=fences[c['args'][0]];assert f['deleted'] is None;f['deleted']=i
    assert all(f['deleted'] is not None and f['deleted']>f['created'] for f in allfences)
    proof=json.loads((directory/'independent-audit.json').read_text());assert proof['status']=='passed'
    assert sha((directory/'report.json').read_bytes())==proof['reportSha256']
    rows.append(dict(record=name,sha256=proof['reportSha256'],unchangedOriginalOracle=True,sameProofSourceAndSeedsWithVariedPhysicalCompletionSchedules=True,bothCapturesIndependentlyHoldLiteralOriginalData=True,originalOperations=proof['operations'],nativeObservations=proof['nativeObservations'],texels=proof['texels'],originalFencedReads=proof['originalFencedReads'],nativeReads=reads,nativeFences=len(allfences),completedPhysicalPboCopies=gets,sourceHead=HEAD,storageSourceHead=STORAGE))

def hunks():
    import re
    diff=subprocess.check_output(['git','diff','--unified=0','a229993e20de3e8b14d64b5c9004292f9c41f614',HEAD],cwd=ROOT,text=True)
    name=None;result=[]
    for line in diff.splitlines():
        if line.startswith('+++ b/'):name=line[6:]
        elif line.startswith('@@'):
            assert name.startswith('tools/') or name=='Makefile','only proof promotion changed'
            m=re.search(r'\+(\d+)(?:,(\d+))?',line)
            result.append(dict(source=name,line=int(m[1]),count=int(m[2]or 1),header=line,classification='executed-with-harness-waivers',reason='Promoted headed make target executes literal original-wire/word/retention proof, full nested actual runtime V8 capture, offline Python audit and required completed-fence native sabotage. Remaining harness diagnostics/optional parameter defaults/error-report plumbing do not confer product admission authority.'))
    return result

inherited=json.loads((OUT/'identity-audit.json').read_text())
inherited=[r for r in inherited['reports']if'inherited'in r]
result=dict(status='passed',promotedHead=HEAD,storageHead=STORAGE,receiptSha256=sha((P/'receipt.json').read_bytes()),completeAcceptanceLogSha256=sha((P/'acceptance.log').read_bytes()),sources=receipt['sources'],proofs=rows,promotedHunks=hunks(),inheritedAuthenticatedSeals=len(inherited),inheritedAuthenticatedRecords=sum(r['records']for r in inherited),noProductChanges=True)
(OUT/'promotion-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
