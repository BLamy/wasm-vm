from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile

ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
OUT=Path('/tmp/wasm-vm-e6-t11d20-critic-20261010')
E=ROOT/'target/evidence/virgl-standard-texture-storage-critic'
DEST=ROOT/'evidence/virgl-standard-texture-storage/verifier'
HEAD='835ccfcfcbfe31c4c22a799b1c521841df4d1352'
RUNTIME='cde73ac477b4cab52e84f7a8995c701bf71cdca6'
BASE='52d3cc4e2f0f28d82a2900ff33ab855ae118e66e'
SUBMISSION='a229993e20de3e8b14d64b5c9004292f9c41f614'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda args:subprocess.check_output(['git',*args],cwd=ROOT)

assert git(['rev-parse','HEAD']).decode().strip()==HEAD
assert not git(['diff','--name-only','HEAD']).strip(),'tracked freeze before evidence seal'
worker=ROOT/'evidence/virgl-standard-texture-storage/worker'
ref=json.loads((OUT/'worker-reference.json').read_text())
assert sha((worker/'recording.tar.gz').read_bytes())==ref['archiveSha256']=='69b3ab4a2a7bddb01a3301dd17c4996bb7535d458c72eb644bd07307c59d3d6d'
assert sha((worker/'records.json').read_bytes())==ref['indexSha256']=='9ee4efd09f6c3a7ebc0f87d5fe0eee53f3816add57e40a5c2511fd9cb83e73c9'
assert sha((worker/'manifest.json').read_bytes())==ref['manifestSha256']
receipt=json.loads((OUT/'unpacked/hot/receipt.json').read_text())
for name,digest in receipt['sources'].items():assert sha(git(['show',HEAD+':'+name]))==digest,name
for name in ['renderer/virgl-command/resources.mjs','renderer/virgl-command/decoder.mjs']:
    assert git(['show',RUNTIME+':'+name])==git(['show',HEAD+':'+name])==(ROOT/name).read_bytes(),name
proof=json.loads((E/'promoted/receipt.json').read_text())
assert proof['gitHead']==HEAD and proof['status']=='passed'
for name,digest in proof['files'].items():assert sha((E/'promoted'/name).read_bytes())==digest,name
verdict=json.loads((OUT/'verdict.json').read_text());assert verdict['verdict']=='verified'
assert all(p['status']=='HELD'for p in verdict['predictions'])

members={}
def add(name,data):
    assert name not in members and not Path(name).is_absolute() and '..'not in Path(name).parts
    members[name]=data
for file in sorted(OUT.iterdir()):
    if file.is_file()and file.name not in ['seal-result.json','seal-recheck.json','seal-recheck.log']:
        add('audit/'+file.name,file.read_bytes())
for file in sorted(E.rglob('*')):
    if file.is_file():add('fresh/'+file.relative_to(E).as_posix(),file.read_bytes())
for name in ['manifest.json','records.json']:add('worker-reference/'+name,(worker/name).read_bytes())
add('review/AGENTS.md',git(['show',HEAD+':AGENTS.md']))
add('review/task-before-verdict.md',git(['show',SUBMISSION+':tasks/epic-6-transcendence/E6-T11d20-standard-texture-storage.md']))
add('review/worker.diff',git(['diff',BASE,SUBMISSION]))
add('review/promotion.diff',git(['diff',SUBMISSION,HEAD]))
for name in proof['sources']:add('review/promoted-sources/'+name,git(['show',HEAD+':'+name]))
index=(json.dumps(dict(schema='original-mip-storage-critic-records-v1',task='E6-T11d20',role='fresh-adversarial-verifier',promotedTestHead=HEAD,records=[dict(path=n,bytes=len(b),sha256=sha(b))for n,b in sorted(members.items())]),indent=2)+'\n').encode()
archive=io.BytesIO()
with gzip.GzipFile(fileobj=archive,mode='wb',mtime=0)as zipped:
    with tarfile.open(fileobj=zipped,mode='w')as tar:
        for name,data in sorted(members.items()):
            info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644
            tar.addfile(info,io.BytesIO(data))
raw=archive.getvalue()
manifest=dict(schema='original-mip-storage-critic-evidence-v1',task='E6-T11d20',role='fresh-adversarial-verifier',verdict='verified',predecessor=BASE,reviewedSubmission=SUBMISSION,frozenRuntimeAndWorkerHarness=RUNTIME,promotedTestHead=HEAD,records=len(members),uncompressedRecordBytes=sum(len(b)for b in members.values()),archiveBytes=len(raw),archiveSha256=sha(raw),recordIndexSha256=sha(index),verdictMember='audit/verdict.json',verdictSha256=sha((OUT/'verdict.json').read_bytes()),predictionsSha256=sha((OUT/'predictions.json').read_bytes()),workerArchive='../worker/recording.tar.gz',workerArchiveSha256=ref['archiveSha256'],workerRecordIndexSha256=ref['indexSha256'],workerManifestSha256=ref['manifestSha256'],promotedReceiptSha256=sha((E/'promoted/receipt.json').read_bytes()),sourceHashes=proof['sources'],healthyIndependentSeeds=[2463613825,2135583533,3091592025],healthyIndependentRuns=54,healthyIndependentNativeObservations=1404,healthyIndependentTexels=46863,healthyIndependentOriginalOperations=1566,healthyIndependentOriginalFencedReads=333,healthyIndependentCompletedPhysicalPboCopies=1629,originalWorkerNativeTexelsPerHotCold=380450,originalWorkerNativeLevelsPerHotCold=1201,fullNestedFunctions=63,fullNestedRegions=375,explicitUnchangedBoundaryOrHarnessWaivers=59,classifiedOriginalDiffHunks=48,inheritedAuthenticatedSeals=10,authority='Only isolated host-selected original mipmapped2D color storage/transfers and bounded resource lifetime. Historical view/draw/scanout consumers remain gated. No production guest graphics/caps/API/deployment/performance authority.',guestExecution=False,productionNegotiation=False,productionDrawAuthority=False,completeApiAuthority=False,capsetAuthority=False,performanceClaim=False,deploymentClaim=False,productChanges=False,coldProof='Original exact frozen pristine scrubbed acceptance ran once; code/dependency/evidence digests unchanged after worker submission. No unrelated gauntlet replay.',preservedFailures='All initial critic harness failures, correction explanations, source snapshots, rejected native captures, expected native sabotages and complete rechecks are sealed. Product unchanged.',referenceMapping=ref['mapping'])
DEST.mkdir(parents=True,exist_ok=True)
assert not any(DEST.iterdir()),'new verifier seal only'
(DEST/'records.json').write_bytes(index);(DEST/'recording.tar.gz').write_bytes(raw);(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
result=dict(manifestSha256=sha((DEST/'manifest.json').read_bytes()),**manifest)
(OUT/'seal-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k]for k in ['verdict','records','archiveBytes','uncompressedRecordBytes','archiveSha256','recordIndexSha256','manifestSha256']},indent=2))
