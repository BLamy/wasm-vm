#!/usr/bin/env python3
"""Fresh critic custody check: reopen every sealed body before state inspection."""
import hashlib,json,pathlib,subprocess,tarfile
ROOT=pathlib.Path(__file__).resolve().parent
REPO=ROOT.parents[2]
BASE='0211566e662a3512b374c69ab915c563e7daf0cc'
FREEZE='6799137b1df9601f02cb7347e609095553bd8951'
SHA=lambda b:hashlib.sha256(b).hexdigest()
def gitbody(head,p):return subprocess.check_output(['git','show',head+':'+p],cwd=REPO)
def seal(directory,expected=None,extract=False):
    directory=REPO/directory
    raw=(directory/'manifest.json').read_bytes();m=json.loads(raw)
    index=(directory/'records.json').read_bytes();idx=json.loads(index)
    archive=(directory/'recording.tar.gz').read_bytes()
    if expected:
        assert [SHA(raw),SHA(index),SHA(archive)]==expected
    assert SHA(index)==m['recordIndexSha256'] and SHA(archive)==m['archiveSha256']
    records=idx['records'] if isinstance(idx,dict) else idx
    rows={v['path']:v for v in records};assert len(rows)==len(records)
    bodies,links={},{}
    with tarfile.open(directory/'recording.tar.gz','r|gz') as t:
        for v in t:
            assert v.name in rows and v.name not in bodies and v.name not in links
            parts=pathlib.PurePosixPath(v.name)
            assert not parts.is_absolute() and '..' not in parts.parts
            if v.isfile():bodies[v.name]=t.extractfile(v).read()
            else:assert v.islnk();links[v.name]=v.linkname
    assert set(bodies)|set(links)==set(rows)
    def body(name,seen=frozenset()):
        if name in bodies:return bodies[name]
        assert name in links and name not in seen
        bodies[name]=body(links[name],seen|{name});return bodies[name]
    for name,v in rows.items():
        b=body(name);assert len(b)==v['bytes'] and SHA(b)==v['sha256'],name
        if extract:
            p=ROOT/'unpacked'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    result={'directory':str(directory.relative_to(REPO)),'manifestSha256':SHA(raw),'indexSha256':SHA(index),
            'archiveSha256':SHA(archive),'bodies':len(rows),'bodyBytes':sum(v['bytes'] for v in records)}
    print(json.dumps(result),flush=True)
    return result,m,bodies
out={}
out['worker'],worker,wb=seal('evidence/virgl-native-image/worker',[
    '760e7cec92d98d9cf2104e534f296429d6f8305e0d24e013a62c4eff91dfd624',
    'ca2681aab7fe795ffc508441f0b0c7db306f78ae32de55aa524109b68f85c99b',
    '438ecaf1c7eb936ea785d93ba37792460963f7a39ce1277aaed6cc0d7878c5c2'],True)
out['dependencies']=[];dependency_bodies={}
for dep in worker['dependencySeals']:
    rel='evidence/'+dep['family']+'/'+dep['role']
    result,m,b=seal(rel,[dep['manifestSha256'],dep['indexSha256'],dep['archiveSha256']])
    assert result['bodies']==dep['reopenedBodies']
    assert (REPO/rel/'manifest.json').read_bytes()==gitbody(BASE,rel+'/manifest.json')
    if dep['role']=='verifier':assert m['verdict']=='verified'
    out['dependencies'].append(result)
    dependency_bodies[(dep['family'],dep['role'])]=b
cold=json.loads(wb['cold/report.json']);receipt=json.loads(wb['cold/recording/receipt.json']);hardware=json.loads(wb['cold/recording/hardware/report.json'])
assert cold['head']==receipt['head']==hardware['gitHead']==worker['head']==FREEZE
assert not cold['cleanBefore'] and not cold['cleanAfter'] and cold['exitCode']==0
assert cold['receiptSha256']==SHA(wb['cold/recording/receipt.json'])=='9c63c3e0bcc7f466a4915467594585752b37f263256077115ccd2225e560eece'
assert len(receipt['commands'])==26
for command in receipt['commands']:
    assert command['exitCode']==command['expected']
    for channel in ['stdout','stderr']:
        assert SHA(wb['cold/recording/'+command['name']+'.'+channel])==command[channel+'Sha256']
source_pins=[]
for rel,pin in receipt['sources'].items():
    b=wb['cold/recording/sources/'+rel]
    assert len(b)==pin['bytes'] and SHA(b)==pin['sha256']
    assert b==gitbody(FREEZE,rel)==(REPO/rel).read_bytes(),rel
    source_pins.append({'path':rel,'sha256':pin['sha256']})
assert SHA(wb['cold/recording/native-test-binary'])==receipt['binary']['sha256']
assert SHA(wb['cold/recording/hardware/report.json'])==receipt['hardwareReportSha256']
assert SHA(wb['cold/recording/integration-audit.json'])==receipt['auditSha256']
for v in hardware['sources']:
    b=wb['cold/recording/hardware/source/'+v['path']]
    assert len(b)==v['bytes'] and SHA(b)==v['sha256']
carry=[]
for rel,d in receipt['carriedHostSources'].items():
    assert SHA((REPO/rel).read_bytes())==d
    carry.append({'path':rel,'sha256':d})
assert len(carry)==314
buf=dependency_bodies['virgl-native-buffer','worker']
for rel in ['renderer/virgl-shader/build/wasm/virgl-shader.wasm','renderer/virgl-shader/build/wasm/virgl-shader.mjs']:
    assert buf['cold/recording/hardware/source/'+rel]==wb['cold/recording/hardware/source/'+rel]==(REPO/rel).read_bytes()
manifest_path=REPO/'evidence/virgl-native-image/deployment/manifest.json'
deploy=json.loads(manifest_path.read_bytes())
for rel,v in deploy['files'].items():
    b=(manifest_path.parent/rel).read_bytes();assert len(b)==v['bytes'] and SHA(b)==v['sha256'],rel
out.update({'freeze':FREEZE,'coldReport':cold,'receiptSha256':cold['receiptSha256'],'sources':source_pins,'carriedSources':carry,
    'commands':[{'name':v['name'],'command':v['command'],'exitCode':v['exitCode'],'expected':v['expected']} for v in receipt['commands']],
    'deploymentManifestSha256':SHA(manifest_path.read_bytes()),'deploymentFiles':len(deploy['files'])})
(ROOT/'authentication.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'authenticated','sources':len(source_pins),'carried':len(carry),'dependencyBodies':sum(v['bodies'] for v in out['dependencies'])}))
