#!/usr/bin/env python3
"""Critic's literal packet/cost/word/RAM model, independent of product conversion."""
import collections,hashlib,json,pathlib,struct,sys
ROOT=pathlib.Path(__file__).resolve().parent
REPO=ROOT.parents[2]
SHA=lambda b:hashlib.sha256(b).hexdigest()
LAYOUTS={r['format']:r for r in json.loads((REPO/'tools/virgl-native-image/original-layouts.json').read_bytes())['rows']}
FIELDS=['id','target','format','bind','width','height','depth','arraySize','lastLevel','nrSamples','flags']
def decode_control(raw):
    pos=0
    def take(n):
        nonlocal pos
        b=raw[pos:pos+n];assert len(b)==n;pos+=n;return b
    def number(n):return int.from_bytes(take(n),'little')
    def identity():return {'id':number(4),'generation':f'{number(8):016x}'}
    assert take(8)==b'WV3DCTL2'
    v=dict(zip(['epoch','nextGeneration','nextBackingGeneration','logicalBytes','gpuBytes','backingBytes'],[number(8) for _ in range(6)]))
    v['poisoned']=bool(number(1));v['contexts']=[];v['resources']=[]
    for _ in range(number(4)):
        c={'identity':identity()};c['debugName']=list(take(number(4)));c['resources']=[identity() for _ in range(number(4))];v['contexts'].append(c)
    for _ in range(number(4)):
        r={'identity':identity(),'metadata':dict(zip(FIELDS,[number(4) for _ in FIELDS]))}
        if number(1):r['backingGeneration']=f'{number(8):016x}';r['backing']=[{'address':f'{number(8):016x}','length':number(4)} for _ in range(number(4))]
        else:r['backingGeneration']=None;r['backing']=None
        v['resources'].append(r)
    assert pos==len(raw);return v

def record(v):
    for kind in ['transport','submit']:assert SHA(bytes.fromhex(v[kind+'Canonical']))==v[kind+'Digest']
    req=bytes.fromhex(v['request']);reply=bytes.fromhex(v['response']);assert len(reply)==24
    expected=bytearray(req[:24]);expected[21:24]=b'\0'*3
    flags=int.from_bytes(req[4:8],'little')&1;expected[4:8]=flags.to_bytes(4,'little')
    if not flags:expected[8:16]=b'\0'*8
    if reply==bytes([0xa5])*24:
        assert any(word in v['case'] for word in ['pending','begin','reset','fault','poison','used','dma']), v['case']
    else:
        assert reply[4:]==expected[4:], v['case']
    assert bytes.fromhex(v['ring']['used'])[2:4]==v['usedIndex'].to_bytes(2,'little')
    return decode_control(bytes.fromhex(v['transportCanonical']))

def inverse(fmt,src,pixel):
    # Source-derived original fields; no fixture result nor runtime importer.
    dst=bytearray(src)
    alpha={2:3,4:0,68:0,99:0,101:3,103:0,134:3,230:3}
    if fmt in alpha:dst[alpha[fmt]::4]=bytes([255])*(len(dst)//4)
    fill={122:32768,135:61440,407:61440,409:32768,233:3221225472,308:3221225472}
    if fmt in fill:
        for i in range(0,len(dst),pixel):dst[i:i+pixel]=(int.from_bytes(src[i:i+pixel],'little')|fill[fmt]).to_bytes(pixel,'little')
    if fmt==21:dst[3::4]=bytes(len(dst)//4)
    if fmt==126:
        for i in range(0,len(dst),8):dst[i+5:i+8]=b'\0'*3
    if fmt==125:
        for i in range(0,len(dst),4):
            word=int.from_bytes(src[i:i+4],'little');exponent=word>>27
            channels=[(word>>shift)&511 for shift in [0,9,18]]
            while exponent>0 and max(channels)<256 and max(channels)>0:
                exponent-=1;channels=[v*2 for v in channels]
            if max(channels)==0:exponent=0
            assert all(0<=x<=511 for x in channels)
            result=sum(v<<shift for v,shift in zip(channels,[0,9,18]))|(exponent<<27)
            dst[i:i+4]=result.to_bytes(4,'little')
    return bytes(dst)

def mask_allowed(fmt,bind):
    masks={'depth':{1,8,9},'shared':{8},'snorm':{8,262152,1048584,1310728},'color':{2,8,10,262146,262152,262154,1048578,1048584,1048586,1310722,1310728,1310730}}
    return bind in masks[LAYOUTS[fmt]['kind']]

def audit_browser(path):
    raw=path.read_bytes();report=json.loads(raw);r=report['browserResult']['result']
    assert report['status']==r['status']=='passed' and report['browserErrors']=={'console':[],'page':[],'requests':[]} and not report['trackedChanges']
    assert 'Metal' in r['gpu'] and not r['guestExecution'] and not r['productionNegotiation']
    assert not any(any(x in a.lower() for x in ['swiftshader','llvmpipe','softpipe','lavapipe','--disable-gpu']) for a in report['browser']['commandLine'])
    seeds={run['seed'] for run in r['runs']};assert len(seeds)==3 and len(r['runs'])==243
    assert {(v['seed'],v['format']) for v in r['runs']}=={(s,f) for s in seeds for f in LAYOUTS}
    points=[];pixels=0;records=0;checkpoints=[]
    for run in r['runs']:
        original=run['original'];m=original['metadata'];fmt=run['format'];layout=LAYOUTS[fmt];p=layout['publicPixelBytes'];g=layout['gpuPixelBytes']
        assert m['width']==9 and m['height']==5 and m['lastLevel']==3 and m['format']==fmt
        assert original['layout']==layout
        cost=sum(max(1,m['width']//(2**k))*max(1,m['height']//(2**k)) for k in range(m['lastLevel']+1))
        assert cost==56 and original['costs']=={'pixels':cost,'publicBytes':cost*p,'gpuBytes':cost*g}
        for v in run['states']+[run['recreated']]:
            n=v['native'];h=v['host'];assert n['logicalBytes']==p*cost and n['gpuBytes']==g*cost==h['store']['budgets']['gpuBytes']
            assert n['resources'][0]['metadata']==m and n['resources'][0]['identity']==h['resources'][0]['transport']
            canon=decode_control(bytes(n['canonicalBytes']));assert canon['resources'][0]['metadata']==m and canon['logicalBytes']==p*cost
            assert canon['epoch']==int(n['epoch'],16) and SHA(bytes(n['canonicalBytes']))==n['digest']
        assert run['recreated']['native']['epoch']!=run['states'][0]['native']['epoch']
        old_id=run['states'][0]['native']['resources'][0]['identity'];new_id=run['recreated']['native']['resources'][0]['identity']
        # Reset can reuse the generation counter; epoch is the revocation identity.
        assert old_id['id']==new_id['id']==6
        backing=bytes.fromhex(original['backing']);after=bytearray([0xc7]*len(backing));assert sum(v['length'] for v in run['entries'])==len(backing)
        for predicted,actual in zip(original['planes'],run['planes']):
            k=predicted['level'];w=max(1,9//2**k);h=max(1,5//2**k);row=w*p
            assert [w,h]==[predicted['width'],predicted['height']]==[actual['width'],actual['height']]
            at=predicted['offset'];stride=predicted['stride'];src=b''.join(backing[at+y*stride:at+y*stride+row] for y in range(h));dst=inverse(fmt,src,p)
            assert src==bytes.fromhex(predicted['input'])==bytes.fromhex(actual['input']['bytes'])
            assert dst==bytes.fromhex(actual['output']['bytes'])==bytes.fromhex(predicted['expected'])
            assert actual['input']['args'][-3:]==actual['output']['args'][-3:]==[row,stride,h]
            assert actual['input']['usedIndex']==actual['upload']['number']
            packet=bytes(actual['upload']['request']);assert struct.unpack_from('<I',packet,60)[0]==k
            for y in range(h):after[at+y*stride:at+y*stride+row]=dst[y*row:(y+1)*row]
            assert bytes(after)==bytes.fromhex(actual['backingAfter'])
            assert all(v['prefix']==v['suffix']=='a3'*8 for v in actual['guards'])
            points.append({'format':fmt,'seed':run['seed'],'level':k,'sourceSha256':SHA(src),'predictedOutputSha256':SHA(dst)});pixels+=w*h
        for point in run['records']:
            state=record(point);assert point['responseGuard']=='a5'*40;records+=1
            if point['case']=='image release':assert [state[x] for x in ['logicalBytes','gpuBytes','backingBytes']]==[0,0,0] and not state['resources']
        assert any(e['type']=='cancelJob' for e in run['events']) and run['snapshot']['liveSyncs']==0 and run['snapshot']['pboReads']>=4
        if run['memoryCheckpoint']:
            cp=run['memoryCheckpoint'];assert SHA(bytes.fromhex(cp['memory']))==cp['sha256'];checkpoints.append(cp['sha256'])
    b=r['boundaries']
    for v in b['rows']:
        state=record(v['record']);before=v['before']['native'];assert state==decode_control(bytes(before['canonicalBytes']))
        assert int.from_bytes(bytes.fromhex(v['record']['response'])[:4],'little')==v['type']
    for v in b['transfers']:
        assert record(v['record'])==decode_control(bytes(v['before']['native']['canonicalBytes']))
        assert int.from_bytes(bytes.fromhex(v['record']['response'])[:4],'little')==0x1205
    for v in b['roles']:
        m=v['native']['resources'][0]['metadata'];assert mask_allowed(m['format'],m['bind'])
    assert b['gpuBudget'][-1]['gpuBytes']==33554432 and b['gpuBudget'][-1]['logicalBytes']==16777216
    assert len(r['owners']['accepted']['resources'])==64 and len(r['owners']['historical']['events'][-1]['resources'])==16
    for a,z in enumerate(r['nativeCalls']):assert z['sequence']==a
    names=collections.Counter(v['name'] for v in r['nativeCalls']);assert names['finish']==0
    for name in ['texStorage2D','texSubImage2D','readPixels','fenceSync','clientWaitSync','getBufferSubData','deleteSync']:assert names[name]>0
    assert len(points)==972 and pixels==13608 and len(checkpoints)==3
    result={'path':str(path.relative_to(REPO)),'sha256':SHA(raw),'seeds':sorted(seeds),'points':points,'planes':len(points),'pixels':pixels,'records':records,'checkpoints':checkpoints,'calls':len(r['nativeCalls']),'callCounts':dict(names)}
    return result

def audit_native(path):
    raw=path.read_bytes();lines=raw.decode().splitlines();counts=collections.Counter();creates=[];points=[];records=[]
    for i,line in enumerate(lines,1):
        if line.startswith('SUBMIT3D_PORTABLE_RECORD '):
            v=json.loads(line.split(' ',1)[1]);state=record(v);records.append(v);counts[v['case']]+=1
            packet=bytes.fromhex(v['request'])
            if v['case']=='image-create':
                fmt=struct.unpack_from('<I',packet,32)[0];l=LAYOUTS[fmt];assert state['logicalBytes']==56*l['publicPixelBytes'] and state['gpuBytes']==56*l['gpuPixelBytes']
                creates.append({'line':i,'format':fmt,'public':state['logicalBytes'],'owned':state['gpuBytes'],'digest':v['transportDigest']})
            if v['case']=='image-bind-boundary':
                fmt,bind=struct.unpack_from('<II',packet,32);assert int.from_bytes(bytes.fromhex(v['response'])[:4],'little')==(0x1100 if mask_allowed(fmt,bind) else 0x1205)
        if line.startswith('NATIVE_IMAGE_DMA_POINT '):
            v=json.loads(line.split(' ',1)[1]);p=LAYOUTS[v['format']]['publicPixelBytes'];k=v['level'];w=max(1,9//2**k);h=max(1,5//2**k);stride=w*p+(7 if k%2 else 0)
            assert [v['width'],v['height'],v['rowStride'],v['publicPixelBytes']]==[w,h,stride,p]
            src=bytes.fromhex(v['source']);assert src==bytes(((i*71)^v['format']^(k*43))&255 for i in range(len(src)))
            tight=b''.join(src[5+y*stride:5+y*stride+w*p] for y in range(h));out=bytes(b^0x57 for b in tight)
            assert tight==bytes.fromhex(v['gathered']) and out==bytes.fromhex(v['output'])
            after=bytearray(src)
            for y in range(h):after[5+y*stride:5+y*stride+w*p]=out[y*w*p:(y+1)*w*p]
            assert bytes(after)==bytes.fromhex(v['completeBacking']);points.append({'line':i,'format':v['format'],'level':k,'sourceSha256':SHA(src),'completeSha256':SHA(after)})
        if line.startswith('NATIVE_IMAGE_GUARD_POINT '):assert json.loads(line.split(' ',1)[1])['guard']=='a5'*40;counts['guards']+=1
        if line.startswith('SUBMIT3D_GUEST_TRACE '):counts['traces']+=1
        if line.startswith('NATIVE_IMAGE_MEMORY_CHECKPOINT '):
            cp=json.loads(line.split(' ',1)[1]);assert SHA(bytes.fromhex(cp['memory']))==cp['sha256'];counts['checkpoints']+=1
    assert len(creates)==81 and len(points)==324 and counts['image-bind-boundary']==1458
    assert counts['guards']==sum(v for k,v in counts.items() if k.startswith('image-'))
    return {'path':str(path.relative_to(REPO)),'sha256':SHA(raw),'creates':creates,'dmaPoints':points,'counts':dict(counts),'records':len(records)}
if __name__=='__main__':
    cold=ROOT/'unpacked/cold/recording'
    out={'schema':'native-image-critic-recording-audit-v1','workerBrowser':audit_browser(cold/'hardware/report.json'),'workerNative':audit_native(cold/'native-submit.stderr')}
    if len(sys.argv)>1:out['freshBrowser']=audit_browser(pathlib.Path(sys.argv[1]).resolve())
    if (ROOT/'fresh-native-submit.stderr').exists():out['freshNative']=audit_native(ROOT/'fresh-native-submit.stderr')
    (ROOT/'recording-audit.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:{s:v[s] for s in ['pixels','planes','records','calls'] if s in v} for k,v in out.items() if isinstance(v,dict)}))
