#!/usr/bin/env python3
"""Reclassify guard tokens; use the unchanged export, never line maxima."""
import hashlib,json,pathlib,re,subprocess
ROOT=pathlib.Path(__file__).resolve().parent
REPO=ROOT.parents[2]
COLD=ROOT/'unpacked/cold/recording'
worker=json.loads((COLD/'changed-coverage.json').read_bytes())
export=json.loads((COLD/'native-coverage.json').read_bytes())
files={pathlib.Path(v['filename']).name:v for d in export['data'] for v in d['files']}
checks=[];waivers=[];guards=[]
def segment(path,line,column):
    prior=[s for s in files[pathlib.Path(path).name]['segments'] if (s[0],s[1])<=(line,column)]
    assert prior;return prior[-1]
def checked(path,line,column,token,original=None):
    s=segment(path,line,column);assert s[3] and not s[5] and s[2]>0,(path,line,column,token,s)
    if original is not None:assert s==original
    checks.append({'path':path,'line':line,'column':column,'token':token,'segment':s,'count':s[2],'status':'HELD'})
for row in worker['runtimeLines']:
    for v in row['operands']:checked(row['path'],row['line'],v['column'],v['token'],v['segment'])
for v in worker['waivers']:
    # These are expressions guarding a match arm, not structural match patterns.
    dynamic=(v['line']==61 and 'column' in v) or (v['line']==65 and v.get('column',0)>=40) or (v['line']==68 and v.get('token')=='desktop_resources')
    if dynamic:
        s=segment(v['path'],v['line'],v['column'])
        if s[3] and not s[5]:checked(v['path'],v['line'],v['column'],v['token'])
        elif v['token']=='desktop_resources':
            # Rust emits no separate region for this dispatcher condition. The
            # finest arm-entry region plus literal selected/historical queue
            # outcomes prove it dynamically; it is not a structural waiver.
            entry=segment(v['path'],68,50);fallback=segment(v['path'],84,20)
            assert entry==[68,50,1658,True,True,False] and fallback==[84,20,2,True,True,False]
            native=(COLD/'native-submit.stderr').read_text().splitlines();historic=[]
            for line_no,line in enumerate(native,1):
                if not line.startswith('SUBMIT3D_PORTABLE_RECORD '):continue
                point=json.loads(line.split(' ',1)[1])
                if point['case']=='image-historical':
                    req=bytes.fromhex(point['request']);fmt=int.from_bytes(req[32:36],'little');response=int.from_bytes(bytes.fromhex(point['response'])[:4],'little')
                    assert response==(0x1100 if fmt==67 else 0x1205)
                    historic.append({'line':line_no,'format':fmt,'response':response,'digest':point['transportDigest']})
            assert len(historic)==81
            guards.append({'path':v['path'],'line':68,'column':34,'token':'desktop_resources','status':'HELD','finestSelectedEntry':entry,'finestHistoricalFallback':fallback,'historicalPoints':historic,
                'reason':'No standalone LLVM condition token exists. Actual selected arm entry and ordinary-constructor responses demonstrate both profiles; source condition is never waived as static syntax.'})
        else:
            assert v['token'] in ['&&','==','if'],v
            waivers.append({**v,'reason':'Only keyword/operator syntax lacks an independent LLVM token region; adjacent dynamic guard values have positive finest counts.'})
    else:waivers.append(v)
assert not worker['uncoveredOperands']
# Ensure all diff runtime lines are accounted for; empty operand rows must be
# literal dispatch patterns or a separately demonstrated dynamic guard.
empty=[]
for v in worker['runtimeLines']:
    if not v['operands']:
        assert v['line'] in [61,65,68,163] and v['path'].endswith('control3d.rs'),v
        empty.append({'path':v['path'],'line':v['line'],'status':'HELD' if v['line']!=163 else 'WAIVED','reason':'Guard expressions independently checked above' if v['line']!=163 else 'Range pattern is static; all24 matched formats and cost operands execute.'})
base='0211566e662a3512b374c69ab915c563e7daf0cc';head='e4de0514066e391713298c187047c3727c830362'
names=subprocess.check_output(['git','diff','--name-only',base,head],cwd=REPO,text=True).splitlines()
hunks=[]
for path in names:
    diff=subprocess.check_output(['git','diff','--unified=0',base,head,'--',path],cwd=REPO,text=True)
    spans=re.findall(r'^@@.*?\+(\d+)(?:,(\d+))? @@',diff,re.M)
    for line,count in spans:
        if path in ['crates/core/src/dev/virtio/gpu/control3d.rs','crates/core/src/dev/virtio/gpu/submit3d.rs']:
            classification='HELD';reason='Full native queues exercise changed layout/cost/transfer operands; finest LLVM checks and explicit static syntax waivers.'
        elif path.startswith('crates/core/tests/'):
            classification='HELD';reason='Affected full native/control test recordings execute success, refusal, rollback, guards and cost outcomes; literal constants/signatures are static.'
        elif path=='renderer/virgl-command/tests/native-image-acceptance.mjs':
            classification='HELD';reason='All243 actual hardware runs and scoped boundary/owner/DMA/fault attacks execute; independent original words/inverse checked.'
        elif path.startswith('tools/virgl-native-image/') or path.startswith('tools/virgl-desktop-submit/') or path=='tools/verify-virgl-default-demo.mjs' or path=='Makefile':
            classification='WAIVED';reason='Recording/acceptance/coverage/fixtures/sealing tooling introduces no runtime semantics. Complete invocation/result/source authenticated; fixture and coverage assumptions independently audited.'
        elif path.startswith('web/'):
            classification='WAIVED';reason='Declarative roadmap/cached asset version; exact served body/digest and partial pip authenticated in default/live proof.'
        else:
            classification='WAIVED';reason='Evidence or task/lifecycle documentation is static; complete bodies authenticate and claim scope reviewed.'
        hunks.append({'path':path,'line':int(line),'count':int(count or 1),'classification':classification,'reason':reason})
result={'schema':'native-image-critic-coverage-v1','exportSha256':hashlib.sha256((COLD/'native-coverage.json').read_bytes()).hexdigest(),
 'workerReportSha256':hashlib.sha256((COLD/'changed-coverage.json').read_bytes()).hexdigest(),'runtimeLines':len(worker['runtimeLines']),
 'directOperands':len(checks),'dynamicGuardsWithoutStandaloneRegion':len(guards),'staticWaivers':len(waivers),'uncovered':[],
 'operands':checks,'dynamicGuards':guards,'waivers':waivers,'emptyOperandRows':empty,'hunks':hunks}
(ROOT/'coverage-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['runtimeLines','directOperands','dynamicGuardsWithoutStandaloneRegion','staticWaivers','uncovered']}))
