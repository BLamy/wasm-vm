#!/usr/bin/env python3
"""Independent sabotage of public RGB8 cost, in a disposable separate checkout."""
import hashlib,json,os,pathlib,subprocess,tempfile
ROOT=pathlib.Path(__file__).resolve().parent
REPO=ROOT.parents[2]
output=ROOT/'sabotage-public-pixel';assert not output.exists();output.mkdir()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
clone=pathlib.Path(tempfile.mkdtemp(prefix='native-image-critic-public-pixel-'))/'repo'
subprocess.run(['git','clone','--quiet','--shared','--no-checkout',str(REPO),str(clone)],check=True)
subprocess.run(['git','checkout','--quiet','--detach',head],cwd=clone,check=True)
rel='crates/core/src/dev/virtio/gpu/control3d.rs'
source=(clone/rel).read_bytes();anchor=b'66 | 317 => (3, 3),';assert source.count(anchor)==1
mutant=source.replace(anchor,b'66 => (4, 3),\n        317 => (3, 3),')
(clone/rel).write_bytes(mutant);(output/'original.rs').write_bytes(source);(output/'mutant.rs').write_bytes(mutant)
command=['cargo','test','--offline','-p','wasm-vm-core','--features','virgl-control-proof,gpu-trace,trace','--test','virtio_gpu_submit3d','selected_desktop_image_layouts_live_mip_dma_and_guards','--','--nocapture','--test-threads=1']
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','RUST','LLVM_PROFILE'))}
env['CARGO_TARGET_DIR']=str(REPO/'target/virgl-native-image-critic-public-pixel')
print('public-pixel sabotage: running',flush=True)
p=subprocess.run(command,cwd=clone,env=env,capture_output=True,timeout=600)
(output/'stdout').write_bytes(p.stdout);(output/'stderr').write_bytes(p.stderr)
assert p.returncode==101,p.stderr[-3000:]
s=p.stderr.decode();assert 'NATIVE_IMAGE_PREDICTION format=66 public=168 gpu=168 levels=4' in s
assert 'left: (224, 168)' in s and 'right: (168, 168)' in s
lines=s.splitlines();points=[(i,json.loads(l.split(' ',1)[1])) for i,l in enumerate(lines,1) if l.startswith('SUBMIT3D_PORTABLE_RECORD ')]
line_no,point=points[-1];assert point['case']=='image-create'
raw=bytes.fromhex(point['request']);assert int.from_bytes(raw[32:36],'little')==66
sha=lambda b:hashlib.sha256(b).hexdigest()
for kind in ['transport','submit']:assert sha(bytes.fromhex(point[kind+'Canonical']))==point[kind+'Digest']
assert tuple(int.from_bytes(bytes.fromhex(point['transportCanonical'])[at:at+8],'little') for at in [32,40])==(224,168)
report={'schema':'native-image-critic-sabotage-v1','head':head,'clone':str(clone),'command':command,'environmentOverrides':{'CARGO_TARGET_DIR':env['CARGO_TARGET_DIR']},'exitCode':p.returncode,
 'originalSha256':sha(source),'mutantSha256':sha(mutant),'stderrSha256':sha(p.stderr),'pointLine':line_no,'point':point,
 'prediction':{'format':66,'public':168,'owned':168},'observed':{'public':224,'owned':168},'status':'HELD: independent literal oracle fails the public-pixel mutant'}
(output/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['exitCode','pointLine','prediction','observed']}))
