#!/usr/bin/env python3
"""Seal all new critic bodies; carried worker bodies remain in their original seal."""
import gzip,hashlib,io,json,pathlib,tarfile
ROOT=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not (ROOT/'recording.tar.gz').exists()
exclude={'manifest.json','records.json','recording.tar.gz'}
files=[]
for p in ROOT.rglob('*'):
    rel=p.relative_to(ROOT)
    if p.is_file() and rel.parts[0] not in ['unpacked','__pycache__'] and str(rel) not in exclude:
        files.append(p)
rows=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(files)]
index={'schema':'native-image-critic-index-v1','task':'E6-T11d54','records':rows}
raw=(json.dumps(index,indent=2)+'\n').encode();(ROOT/'records.json').write_bytes(raw)
with (ROOT/'recording.tar.gz').open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w') as t:
    for p,row in zip(sorted(files),rows):
        b=p.read_bytes();info=tarfile.TarInfo(row['path']);info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b))
with tarfile.open(ROOT/'recording.tar.gz','r:gz') as t:
    members=t.getmembers();assert len(members)==len(rows)
    for m,row in zip(members,rows):
        b=t.extractfile(m).read();assert m.name==row['path'] and len(b)==row['bytes'] and sha(b)==row['sha256']
auth=json.loads((ROOT/'authentication.json').read_bytes());coverage=json.loads((ROOT/'coverage-audit.json').read_bytes())
manifest={'schema':'native-image-critic-seal-v1','task':'E6-T11d54','verdict':'verified','sourceHead':'e4de0514066e391713298c187047c3727c830362','runtimeProofHead':'6799137b1df9601f02cb7347e609095553bd8951',
 'records':len(rows),'reopenedMembers':len(rows),'recordIndexSha256':sha(raw),'archiveSha256':sha((ROOT/'recording.tar.gz').read_bytes()),'archiveBytes':(ROOT/'recording.tar.gz').stat().st_size,
 'workerAuthentication':auth['worker'],'dependencyAuthentication':auth['dependencies'],'carriedSourceBoundaries':314,
 'predictionsSha256':sha((ROOT/'predictions.json').read_bytes()),'verdictSha256':sha((ROOT/'verdict.json').read_bytes()),
 'correctedCoverage':{k:coverage[k] for k in ['runtimeLines','directOperands','dynamicGuardsWithoutStandaloneRegion','staticWaivers','uncovered']},'guestExecution':False,'productionAuthority':False}
(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ['records','archiveBytes','recordIndexSha256','archiveSha256']}))
print('manifestSha256',sha((ROOT/'manifest.json').read_bytes()))
