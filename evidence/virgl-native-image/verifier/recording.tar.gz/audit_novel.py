#!/usr/bin/env python3
"""Independent literal oracle for the critic's actual hardware subrectangle."""
import collections,hashlib,json,pathlib,struct
from audit_recordings import decode_control,record
ROOT=pathlib.Path(__file__).resolve().parent
path=ROOT/'novel-hardware/report.json';raw=path.read_bytes();report=json.loads(raw);r=report['browserResult']['result']
sha=lambda b:hashlib.sha256(b).hexdigest()
assert report['status']==r['status']=='passed' and report['browserErrors']=={'console':[],'page':[],'requests':[]}
assert 'Metal' in r['gpu'] and not r['productionNegotiation'] and not r['guestExecution']
assert report['trackedChanges']==['?? renderer/virgl-command/tests/native-image-critic.mjs']
words=[0x3e800000,0x3f000000,0x3f400000,0x3f800000,0xbf800000,0xc0000000]
def pixels(count,start):return b''.join(struct.pack('<I',words[(i+start)%6]) for i in range(count*3))
tight=pixels(4,4);baseline=pixels(12,1)
expected_plane=bytearray(baseline)
for y in range(2):expected_plane[((y+1)*4+1)*12:((y+1)*4+3)*12]=tight[y*24:(y+1)*24]
citations=[]
for run in r['runs']:
    capacity=run['capacity'];before=run['before'];native=before['native'];assert [native['logicalBytes'],native['gpuBytes'],native['backingBytes']]==[936,1248,capacity]
    assert before['host']['store']['budgets']['gpuBytes']==1248
    expected=bytearray([0xb7]*capacity);expected[5:29]=tight[:24];expected[53:]=tight[24:24+capacity-53]
    assert expected==bytes.fromhex(run['source'])
    for event in run['events']:
        if event['type']=='attachBacking':
            assert sum(s['length'] for s in event['segments']) in [149,capacity]
            for s in event['segments']:
                data=s['data'];assert isinstance(data,dict) and set(data)=={str(i) for i in range(s['length'])} and set(data.values())=={0xa3}
        if event['type']=='beginJob':
            metadata=event['resources'][0]['metadata'];assert [metadata[k] for k in ['format','width','height','lastLevel']]==[30,9,7,3]
    for point in run['records']:
        state=record(point)
        if 'one-byte-short' in point['case']:
            assert int.from_bytes(bytes.fromhex(point['response'])[:4],'little')==0x1205
            assert state==decode_control(bytes(before['native']['canonicalBytes']))
        if 'subrectangle' in point['case']:
            packet=bytes.fromhex(point['request']);assert struct.unpack_from('<6I',packet,24)==(1,1,0,2,2,1)
            assert struct.unpack_from('<Q',packet,48)[0]==5 and struct.unpack_from('<3I',packet,60)==(1,0,0)
        citations.append({'capacity':capacity,'case':point['case'],'requestSha256':sha(bytes.fromhex(point['request'])),'transportDigest':point['transportDigest'],'submitDigest':point['submitDigest'],'usedIndex':point['usedIndex']})
    if capacity==76:
        assert len(run['events'])==before['events'] and len([e for e in run['events'] if e['type']=='beginJob'])==1
    else:
        assert capacity==77
        assert bytes.fromhex(run['tight'])==tight and bytes.fromhex(run['input']['bytes'])==bytes.fromhex(run['output']['bytes'])==tight
        assert run['input']['args'][-3:]==run['output']['args'][-3:]==[24,48,2]
        assert run['fullOutput']['args'][-3:]==[48,48,3] and bytes.fromhex(run['initialPlane'])==baseline
        assert bytes.fromhex(run['expectedPlane'])==bytes.fromhex(run['fullOutput']['bytes'])==expected_plane
        complete=bytearray([0xc7]*77);complete[5:29]=tight[:24];complete[53:77]=tight[24:]
        assert bytes.fromhex(run['completeBacking'])==complete
        full=bytes([0xc7])*5+expected_plane;assert bytes.fromhex(run['fullBacking'])==full
        assert all(v['prefix']==v['suffix']=='a3'*8 for v in run['smallGuards'])
        assert run['snapshot']['liveSyncs']==0 and run['snapshot']['pboReads']==2 and run['snapshot']['fences']==4
    assert all(v['prefix']==v['suffix']=='a3'*8 for v in run['guards'])
names=collections.Counter(v['name'] for v in r['nativeCalls']);assert names['finish']==0 and names['readPixels']==names['getBufferSubData']==2
for kind in ['Buffer','Texture','Framebuffer','VertexArray','Sampler','Program','Shader','Sync']:
    assert names['create'+kind]+(names['fenceSync'] if kind=='Sync' else 0)==names['delete'+kind],kind
for source in report['sources']:
    file=ROOT/'novel-hardware/source'/source['path'];assert len(file.read_bytes())==source['bytes'] and sha(file.read_bytes())==source['sha256']
result={'schema':'native-image-critic-novel-audit-v1','reportSha256':sha(raw),'status':'HELD','seed':r['seed'],'capacityCases':[76,77],'defaultStride':48,'publicRow':24,'exactEnd':77,
 'inputSha256':sha(tight),'fullExpectedPlaneSha256':sha(expected_plane),'nativeCalls':len(r['nativeCalls']),'callCounts':dict(names),'citations':citations}
(ROOT/'novel-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['status','capacityCases','defaultStride','exactEnd','nativeCalls']}))
