#!/usr/bin/env python3
"""Check unchanged dependency, cold isolation, sabotage and default/live custody."""
import ast,hashlib,json,pathlib,subprocess
ROOT=pathlib.Path(__file__).resolve().parent
REPO=ROOT.parents[2]
COLD=ROOT/'unpacked/cold/recording'
SHA=lambda b:hashlib.sha256(b).hexdigest()
freeze='6799137b1df9601f02cb7347e609095553bd8951'
receipt=json.loads((COLD/'receipt.json').read_bytes())
assert receipt['head']==freeze and len(receipt['commands'])==26
cold_runner=(COLD/'sources/tools/virgl-native-image/cold.py').read_text()
assert 'clean_before' in cold_runner and 'clean_after' in cold_runner and all(v in cold_runner for v in ['CARGO_','RUST','LLVM_PROFILE','VIRGL_','NODE_','npm_','CHROME'])
assert '["make", "verify-E6-T11d54"]' in cold_runner
for v in receipt['commands']:assert v['exitCode']==v['expected']
counts={}
for name,n in [('native-submit',16),('native-control',13),('native-gpu',80),('native-machine',4)]:
    body=(COLD/(name+'.stdout')).read_text();assert f'{n} passed; 0 failed; 0 ignored' in body;counts[name]=n
for name in ['wasm-core-default','wasm-core-selected','wasm-proof','clippy-default','clippy-selected','clippy-wasm']:
    assert next(v for v in receipt['commands'] if v['name']==name)['exitCode']==0
assert any(v['name']=='npm-dependencies' and v['command']==['npm','--prefix','web','ci','--no-audit','--no-fund'] for v in receipt['commands'])
fixture=(COLD/'sources/tools/virgl-native-image/fixtures.mjs').read_text();audit=(COLD/'sources/tools/virgl-native-image/audit.py').read_text()
assert all('renderer/' not in line and 'fixtures.mjs' in line for line in fixture.splitlines() if line.startswith('import '))
imports=[n for n in ast.walk(ast.parse(audit)) if isinstance(n,(ast.Import,ast.ImportFrom))]
assert all((n.module if isinstance(n,ast.ImportFrom) else n.names[0].name) in ['hashlib','json','pathlib','struct','sys'] for n in imports)
# The recording's byte inverse is independently recomputed by audit_recordings;
# normal dyadic floats and unique SNORM words are explicit transport inputs.
assert "p.input[i]===128)p.input[i]=129" in fixture and 'normalFloats' in fixture
fault=COLD/'fault-native-image';f=json.loads((fault/'report.json').read_bytes())
assert f['head']==freeze and f['exitCode']==101 and f['observed']=={'public':720,'gpu':720} and f['prediction']=={'format':1,'public':224,'gpu':224}
source=(fault/'original.rs').read_bytes();mutant=(fault/'mutant.rs').read_bytes()
assert source==(COLD/'sources/crates/core/src/dev/virtio/gpu/control3d.rs').read_bytes()
anchor=b'Ok(((self.width >> level).max(1), (self.height >> level).max(1)))';assert source.count(anchor)==1 and mutant==source.replace(anchor,b'Ok((self.width, self.height))')
assert SHA(source)==f['originalSha256'] and SHA(mutant)==f['mutantSha256']
point=f['point'];canon=bytes.fromhex(point['transportCanonical']);assert SHA(canon)==point['transportDigest']
assert int.from_bytes(canon[32:40],'little')==int.from_bytes(canon[40:48],'little')==720
stderr=(fault/'stderr').read_text().splitlines();line=next(i for i,l in enumerate(stderr,1) if l.startswith('SUBMIT3D_PORTABLE_RECORD ') and json.loads(l.split(' ',1)[1])==point)
assert any('left: (720, 720)' in s for s in stderr) and any('right: (224, 224)' in s for s in stderr)

def demo(path,live=False):
    r=json.loads(path.read_bytes());assert r['gitHead']==freeze and r['status']=='passed' and [r['passed'],r['failed']]==[127,0]
    assert not r['errors'] and r['proofExportAbsent'] and 'partial' in r['graphicsRoadmapPip'] and 'live' in r['roadmapPip']
    checked=[]
    for item in r['served']:
        rel=item['path'].lstrip('/') if live else item['path'].removeprefix('web/dist/')
        if live and rel=='app':rel='app.html'
        if rel in ['artifacts.json','artifacts-alpine.json','artifacts-node-alpine.json','artifacts-omarchy.json']:
            raw=(REPO/'evidence/virgl-native-image/deployment/generated'/rel).read_bytes() if live else subprocess.check_output(['git','show',freeze+':web/dist/'+rel],cwd=REPO)
        else:raw=subprocess.check_output(['git','show',freeze+':web/dist/'+rel],cwd=REPO)
        assert SHA(raw)==item['sha256'] and len(raw)==item['bytes'],rel
        checked.append({'path':rel,'sha256':item['sha256']})
    assert r['servedWasmSha256']==SHA((REPO/'web/dist/pkg/wasm_vm_wasm_bg.wasm').read_bytes())
    if live:assert 'https://wasm-vm.pages.dev/' in r['url']
    screenshot=path.parent/r['screenshot']['path'];assert SHA(screenshot.read_bytes())==r['screenshot']['sha256']
    return {'reportSha256':SHA(path.read_bytes()),'screenshotSha256':r['screenshot']['sha256'],'served':checked,'result':[127,0],'proofExportsAbsent':True,'graphicsPartial':True}
result={'schema':'native-image-critic-environment-v1','coldCounts':counts,'coldCommands':len(receipt['commands']),'workerSabotage':{'reportSha256':SHA((fault/'report.json').read_bytes()),'pointLine':line,'digest':point['transportDigest'],'prediction':[224,224],'observed':[720,720]},
 'default':demo(COLD/'default-demo/report.json'),'deployment':demo(REPO/'evidence/virgl-native-image/deployment/final/report.json',True),'productionAuthority':False,'guestExecution':False}
(ROOT/'environment-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'coldCommands':26,'default':[127,0],'deployment':[127,0],'servedBodies':len(result['default']['served'])+len(result['deployment']['served']),'workerSabotageLine':line}))
