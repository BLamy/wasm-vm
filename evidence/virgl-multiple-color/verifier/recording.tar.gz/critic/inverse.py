#!/usr/bin/env python3
"""Fresh critic replay: literal packet/TGSI → plane/backing/native-state, no product imports."""
import gzip,hashlib,json,math,re,struct,sys
from pathlib import Path
sha=lambda b:hashlib.sha256(b).hexdigest()
f32=lambda b:struct.unpack('<f',struct.pack('<I',b))[0]
u32=lambda n:struct.unpack('<I',struct.pack('<f',n))[0]
def shape(fmt):
 if 177<=fmt<=200:
  group,rem=divmod(fmt-177,8);return {'bits':(8,16,32)[group],'lanes':rem%4+1,'signed':rem>=4,'integer':True}
 if 28<=fmt<=31:return {'bits':32,'lanes':fmt-27,'integer':False}
 if 91<=fmt<=94:return {'bits':16,'lanes':fmt-90,'integer':False}
 if fmt==124:return {'bits':32,'lanes':3,'integer':False,'packed':True}
 assert fmt==67,fmt
 return {'bits':8,'lanes':4,'integer':False}
def converted(fmt,word,lane,is_clear=False):
 d=shape(fmt)
 if lane>=d['lanes']:return (1 if d['integer'] else u32(1)) if lane==3 else 0
 if d['integer']:
  n=word if not d['signed'] or word<0x80000000 else word-0x100000000
  if is_clear:
   lo=-(1<<(d['bits']-1)) if d['signed'] else 0;hi=(1<<(d['bits']-int(d['signed'])))-1;n=min(hi,max(lo,n))
  return n&0xffffffff
 n=f32(word)
 if fmt==67:return int(min(1,max(0,n))*255+.5)
 if d['bits']==16:return u32(struct.unpack('<e',struct.pack('<e',n))[0])
 if d.get('packed'):
  if not n:return 0
  mant=5 if lane==2 else 6;e=(word>>23&255)-112;frac=word&0x7fffff
  assert 0<e<31 and not frac&((1<<(23-mant))-1)
 return word
def packed(words):
 out=0
 for lane,bits in enumerate(words[:3]):
  n=f32(bits);m=5 if lane==2 else 6
  if n==0:part=0
  else:
   assert n>0;fraction,exp=math.frexp(n);exponent=exp+14;mantissa=round((2*fraction-1)*(1<<m));assert 0<exponent<31;part=exponent*(1<<m)+mantissa
  out+=part<<(0,11,22)[lane]
 return out
def wire(text):
 raw=bytes.fromhex(text);pos=0
 while pos<len(raw):
  header=struct.unpack_from('<I',raw,pos)[0];length=header>>16;size=4*(length+1);assert pos+size<=len(raw)
  yield header&255,header>>8&255,list(struct.unpack_from('<'+'I'*length,raw,pos+4)),raw[pos:pos+size]
  pos+=size
 assert pos==len(raw)
def tgsi(text):
 decl={};imm={};writes={}
 for line in text.splitlines():
  match=re.fullmatch(r'DCL OUT\[(\d+)\], COLOR(?:\[(\d+)\])?',line)
  if match:decl[int(match[1])]=int(match[2] or 0)
  match=re.fullmatch(r'IMM\[(\d+)\] UINT32 \{([^}]+)\}',line)
  if match:imm[int(match[1])]=[int(n)&0xffffffff for n in match[2].split(',')]
  match=re.fullmatch(r'\d+: MOV OUT\[(\d+)\], IMM\[(\d+)\]',line)
  if match:writes[decl[int(match[1])]]=imm[int(match[2])]
 assert writes and len(writes)==len(decl)
 broadcast='PROPERTY FS_COLOR0_WRITES_ALL_CBUFS 1' in text
 if broadcast:assert set(writes)=={0};writes={slot:list(writes[0]) for slot in range(4)}
 return writes,'KILL' in text,broadcast,decl
class Replay:
 def __init__(self,directory):
  self.directory=Path(directory);self.raw=(self.directory/'report.json').read_bytes();self.report=json.loads(self.raw);self.e=self.report.get('browserResult',{}).get('result') or self.report['partial']
  assert self.report['browserErrors']=={'console':[],'page':[],'requests':[]}
  self.blobs={b['key']:b for b in self.e['blobs']};assert len(self.blobs)==len(self.e['blobs']);self.decoded={};self.diffs=[];self.rows=[]
  self.counts={k:0 for k in ['runs','frames','targets','words','planes','backingBytes','syncs','polls','cpuReads','draws','retiredTargets']}
  self.sabotage=bool(self.report.get('fault'))
 def load(self,ref):
  b=self.blobs[ref['key']];assert b['sha256']==ref['sha256']
  if b['key'] not in self.decoded:
   raw=(self.directory/b['path']).read_bytes();assert sha(raw)==b['gzipSha256'];raw=gzip.decompress(raw);assert sha(raw)==b['sha256'] and len(raw)==b['bytes'];self.decoded[b['key']]=raw
  return self.decoded[b['key']]
 def custody(self,run):
  syncs={s['id']:s for s in run['fenceObjects']};assert len(syncs)==len(run['fenceObjects']);events=run['events'];assert all(events[i]['sequence']<events[i+1]['sequence'] for i in range(len(events)-1))
  writer=0;polls=[];cpu=[]
  for ev in events:
   seq=ev['sequence']
   if ev['name'] in ['drawArrays','drawElements','drawArraysInstanced','drawElementsInstanced','clearBufferfv','clearBufferiv','clearBufferuiv','clear','bufferSubData','texSubImage2D','copyBufferSubData']:writer=seq
   if ev['name']=='fenceSync':assert syncs[ev['sync']]['createdSequence']==seq
   if ev['name']=='clientWaitSync':polls.append(ev)
   if ev['name'] in ['readPixels','getBufferSubData'] and ev['cpu']:
    c=ev['completion'];s=syncs[c['sync']];assert s['createdSequence']>writer and seq>c['sequence']>s['createdSequence'];assert c['actual'] in (37146,37148) and c['delivered'] in (37146,37148)
    assert any(p['sequence']==c['sequence'] and p['actual']==c['actual'] and p['delivered']==c['delivered'] for p in s['polls']);cpu.append(ev)
  assert len(polls)==sum(len(s['polls']) for s in syncs.values())
  for s in syncs.values():
   assert s['identity']=='WebGLSync' and s['deleted']==1
   assert sum(ev['name']=='deleteSync' and ev['sync']==s['id'] for ev in events)==1
  assert len({o['id'] for o in run['nativeObjects']})==len(run['nativeObjects']) and all(o['deleted']==1 for o in run['nativeObjects'])
  assert all(value==0 for row in [run['final']['renderer']['budgets'],run['final']['resources']['budgets']] for value in row.values())
  recorded={row['sequence']:row for row in run['readbacks']};native_reads=[ev for ev in events if ev['name'] in ['readPixels','getBufferSubData']]
  assert len(recorded)==len(run['readbacks'])==len(native_reads)
  for ev in native_reads:
   row=recorded[ev['sequence']];assert all(row[k]==v for k,v in ev.items() if k!='bytes')
   if ev['cpu']:assert row['bytes']['bytes']==ev['bytes'] and len(self.load(row['bytes']))==ev['bytes']
   else:assert row['bytes'] is None
  self.counts['syncs']+=len(syncs);self.counts['polls']+=len(polls);self.counts['cpuReads']+=len(cpu)
 def native_state(self,draw,state,bound,outputs,discard,planes):
  n=draw['native'];self.counts['draws']+=1
  assert n['scissor']==state['scissor'] and n['viewport']==state['viewport'] and n['depthTest']==state['depthEnabled'] and n['depthMask']==state['depthWrite']
  assert n['depthFunction']==512+state['depthFunction']
  historical=state['historical'];blend=state['blend'] and not historical;assert n['blend']==blend
  frag=next(s['glsl'] for s in draw['shaders'] if s['type']==35632)
  for slot,color in enumerate(n['colors']):
   target=bound.get(slot);identity=target['texture'] if target else None
   if color['attachment']!=identity:self.diffs.append({'label':draw['label'],'slot':slot,'kind':'native-attachment','observed':color['attachment'],'expected':identity})
   loc=n['outputs'][slot]['location'];assert loc in (slot,-1) and (slot in outputs or loc==-1)
   assert discard or loc==(slot if slot in outputs else -1)
   assert color['drawBuffer']==(36064+slot if target and loc==slot else 0)
   implicit=target and shape(target['metadata']['format'])['lanes']<4
   assert color['mask']==[bool(state['mask']&(1<<lane)) and not (implicit and lane==3) for lane in range(4)]
   if target:
    d=shape(target['metadata']['format']);assert color['level']==target['level'];assert color['componentType']==((5124 if d['signed'] else 5125) if d['integer'] else 35863 if target['metadata']['format']==67 else 5126)
    if slot in outputs:assert re.search(r'layout\s*\(\s*location\s*=\s*'+str(slot)+r'\s*\)\s*out\s+'+('ivec4' if d['integer'] and d['signed'] else 'uvec4' if d['integer'] else 'vec4')+r'\s+fsout_c'+str(slot)+r'\b',frag)
  assert n['blendEquations']==[32774,32774]
  enum={1:1,7:32769,8:32771,23:32770,24:32772};fold=n['blendFold'] is not None
  if blend:
   assert n['blendColor']==state['color'];assert n['blendFactors']==[1 if fold else enum[state['src']],enum[state['dst']],enum[state['asrc']],enum[state['adst']]]
   if fold:
    factor=[self.factor(state['src'],state['color'],lane) for lane in range(3)];assert n['blendFold']==factor+[1]
  else:assert n['blendFactors']==[1,0,1,0]
 def factor(self,code,color,lane):return {1:1,7:color[lane],8:color[3],23:1-color[lane],24:1-color[3]}[code]
 def run(self,run,ri):
  self.counts['runs']+=1;owners={};resources={};planes={};contexts={};draws={d['label']:d for d in run['draws']};assert len(draws)==len(run['draws'])
  assert len(run['created'])==len(run['allocations'])
  for created,allocation in zip(run['created'],run['allocations']):
   m=created['metadata'];assert all(allocation['metadata'][k]==v for k,v in m.items())
   owner={'metadata':m,'generation':created['generation'],'texture':allocation['texture']};resources.setdefault(m['id'],owner)
   if owner['texture'] is None:continue
   owners[owner['texture']]=owner
   if m['format']==16:continue
   for level in range(m['lastLevel']+1):
    w,h=max(1,m['width']>>level),max(1,m['height']>>level);planes[owner['texture'],level]=[converted(m['format'],0,lane) for _ in range(w*h) for lane in range(4)]
  frames={}
  for fi in run['frames']:frames.setdefault(self.e['frames'][fi]['historyIndex'],[]).append((fi,self.e['frames'][fi]))
  for hi,history in enumerate(run['history']):
   state=contexts.setdefault(history['ctx'],dict(shaders={},surfaces={},objects={},bound={},fragment=None,mask=15,blend=False,src=1,dst=1,asrc=1,adst=1,color=[0,0,0,0],scissor=False,box=[0,0,0,0],viewport=[0,0,0,0],depthEnabled=False,depthWrite=False,depthFunction=0,depth=1,z=.5,historical=run.get('kind')=='historical-integer-blend-bypass'))
   commands=list(wire(history['hex']));limit=history['result'].get('appliedCommands',0)
   for ci,(op,kind,w,raw) in enumerate(commands):
    if ci>=limit:break
    if op==1 and kind==4:state['shaders'][w[0]]=raw[24:24+w[2]-1].decode('ascii')
    elif op==1 and kind==8:state['surfaces'][w[0]]={**resources[w[1]],'level':w[3]};assert resources[w[1]]['metadata']['format']==w[2]
    elif op==1 and kind==1:
     bits=w[3];state['objects'][kind,w[0]]=dict(mask=bits>>27&15,blend=bool(bits&1),src=bits>>4&31,dst=bits>>9&31,asrc=bits>>17&31,adst=bits>>22&31)
    elif op==1 and kind==2:state['objects'][kind,w[0]]=dict(scissor=bool(w[1]&(1<<14)))
    elif op==1 and kind==3:state['objects'][kind,w[0]]=dict(depthEnabled=bool(w[1]&1),depthWrite=bool(w[1]&2),depthFunction=w[1]>>2&7)
    elif op==2 and kind in (1,2,3):state.update(state['objects'][kind,w[0]])
    elif op==5:assert len(w)==2+w[0];state['bound']={slot:state['surfaces'][handle] for slot,handle in enumerate(w[2:]) if handle}
    elif op==4:
     v=[f32(a) for a in w[1:]];state['viewport']=[v[3]-v[0],v[4]-abs(v[1]),2*v[0],2*abs(v[1])];state['z']=v[5]
    elif op==14:state['color']=[f32(a) for a in w]
    elif op==15:state['box']=[w[1]&65535,w[1]>>16,w[2]&65535,w[2]>>16]
    elif op==31 and w[1]==1:state['fragment']=state['shaders'][w[0]]
    elif op in (7,8):
     outputs,discard,broadcast,registers=tgsi(state['fragment']) if op==8 else ({},False,False,{})
     if op==7 and w[0]&1:state['depth']=struct.unpack_from('<d',raw,24)[0]
     if op==8:self.native_state(draws[history['label']],state,state['bound'],outputs,discard,planes)
     passed=not state['depthEnabled'] or state['depthFunction']==1 and state['z']<state['depth']
     for slot,target in state['bound'].items():
      if op==7 and not w[0]&(4<<slot) or op==8 and (discard or slot not in outputs or not passed):continue
      m=target['metadata'];fmt=m['format'];d=shape(fmt);level=target['level'];width,height=max(1,m['width']>>level),max(1,m['height']>>level);plane=planes[target['texture'],level];words=w[1:5] if op==7 else outputs[slot]
      for y in range(height):
       for x in range(width):
        if op==8 and state['scissor'] and not(state['box'][0]<=x<state['box'][2] and state['box'][1]<=y<state['box'][3]):continue
        for lane in range(4):
         if op==8 and not state['mask']&(1<<lane) or lane==3 and d['lanes']<4:continue
         at=(y*width+x)*4+lane;value=words[lane]
         if op==8 and state['blend'] and not d['integer']:
          source=f32(value);dest=plane[at]/255 if fmt==67 else f32(plane[at]);a=state['asrc'] if lane==3 else state['src'];b=state['adst'] if lane==3 else state['dst']
          value=u32((min(1,max(0,source)) if fmt==67 else source)*self.factor(a,state['color'],lane)+dest*self.factor(b,state['color'],lane))
         plane[at]=converted(fmt,value,lane,op==7)
   for fi,frame in frames.get(hi,[]):
    assert frame['run']==ri;self.counts['frames']+=1
    for target in frame['targets']:
     owner=owners[target['texture']];assert owner['generation']==target['generation'] and all(target['metadata'][k]==v for k,v in owner['metadata'].items())
     fmt=owner['metadata']['format'];d=shape(fmt);expected=planes[target['texture'],target['level']];raw=self.load(target['native']);actual=list(raw) if fmt==67 else list(struct.unpack('<'+'I'*(len(raw)//4),raw))
     if actual!=expected:self.diffs.append(dict(frame=fi,label=frame['label'],slot=target['slot'],kind='native',miss=[{'at':j,'actual':a,'expected':b} for j,(a,b) in enumerate(zip(actual,expected)) if a!=b][:16]))
     self.counts['targets']+=1;self.counts['words']+=len(actual)
     if frame.get('retired'):self.counts['retiredTargets']+=1
     for p in target['planes']:
      raw=self.load(p['native']);actual=list(raw) if fmt==67 else list(struct.unpack('<'+'I'*(len(raw)//4),raw));assert actual==planes[target['texture'],p['level']];self.counts['planes']+=1
     if 'backing' in target:
      ops=list(wire(run['history'][target['publicHistory']]['hex']));assert len(ops)==1;op,kind,w,raw=ops[0];assert op==43 and w[0]==owner['metadata']['id'] and w[1]==target['level'] and w[12]==2
      backing=self.load(target['backing']);want=bytearray([0x2e])*len(backing);pixel=4 if d.get('packed') else d['lanes']*d['bits']//8
      for y in range(w[9]):
       for x in range(w[8]):
        values=expected[(y*w[8]+x)*4:(y*w[8]+x+1)*4];at=w[11]+y*(w[3] or w[8]*pixel)+x*pixel
        if d.get('packed'):want[at:at+4]=packed(values).to_bytes(4,'little')
        else:
         for lane in range(d['lanes']):
          size=d['bits']//8;start=at+lane*size;value=values[lane]
          encoded=struct.pack('<e',f32(value)) if not d['integer'] and d['bits']==16 else (value&((1<<(size*8))-1)).to_bytes(size,'little');want[start:start+size]=encoded
      if backing!=want:self.diffs.append(dict(frame=fi,label=frame['label'],slot=target['slot'],kind='public-backing'))
      self.counts['backingBytes']+=len(backing)
  self.custody(run);self.rows.append(dict(run=ri,name=run.get('kind',run['name']),frames=len(run['frames']),history=len(run['history']),nativeDraws=len(run['draws']),sourceReportSha256=sha(self.raw),originalInputsReplayed=True))
 def main(self):
  for row in self.e['blobs']:self.load(row)
  for ri,run in enumerate(self.e['runs']):self.run(run,ri)
  result=dict(status='refuted' if self.diffs else 'passed',counts=self.counts,differences=self.diffs,reportSha256=sha(self.raw),oracle='fresh-independent-original-wire-TGSI',ignoresWorkerExpectedArrays=True,productImports=False,rows=self.rows)
  print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
  return result
if __name__=='__main__':
 directory=Path(sys.argv[1]);out=Path(sys.argv[2]);result=Replay(directory).main();out.write_text(json.dumps(result,indent=2)+'\n')
