import hashlib,json,tarfile,subprocess,io,time
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
OUT=Path('/tmp/wasm-vm-multiple-color-critic-20261011')
HEAD='fd425d1052ab139e89178729bbb72ce89a3521f1'
D33='1206a5beb3026de10457cd395d249daf8aff9966'
D32='c64c3325c15d8978f455d57fc103559eec1b9d20'
sha=lambda b:hashlib.sha256(b).hexdigest()
def filehash(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def gitbytes(ref,name):return subprocess.check_output(['git','cat-file','blob',ref+':'+name],cwd=ROOT)
def auth(base,expect=None,ref=None,extract=None):
 manifest_raw=(base/'manifest.json').read_bytes();index_raw=(base/'records.json').read_bytes();manifest=json.loads(manifest_raw)
 hashes=dict(manifest=sha(manifest_raw),index=sha(index_raw),archive=filehash(base/'recording.tar.gz'))
 if expect:assert hashes==expect,('seal expected digests',base,hashes)
 assert hashes['index']==manifest['recordIndexSha256'] and hashes['archive']==manifest['archiveSha256']
 if ref:
  for name,digest in [('manifest.json',hashes['manifest']),('records.json',hashes['index']),('recording.tar.gz',hashes['archive'])]:
   assert sha(gitbytes(ref,(base/name).relative_to(ROOT).as_posix()))==digest
 rows=json.loads(index_raw)['records'];wanted={r['path']:r for r in rows};assert len(wanted)==len(rows)==manifest['records'];seen=set();total=0
 with tarfile.open(base/'recording.tar.gz','r|gz') as tar:
  for member in tar:
   assert member.isfile() and member.name in wanted and member.name not in seen
   path=Path(member.name);assert not path.is_absolute() and '..' not in path.parts
   data=tar.extractfile(member).read();row=wanted[member.name]
   assert len(data)==row['bytes'] and sha(data)==row['sha256'],member.name
   if extract:
    dest=extract/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
   seen.add(member.name);total+=len(data)
 assert seen==set(wanted)
 print('authenticated',str(base.relative_to(ROOT)),len(seen),total,flush=True)
 return dict(path=str(base.relative_to(ROOT)),members=len(seen),bytes=total,**hashes,sourceHead=manifest.get('sourceHead'),records=rows)
worker=auth(ROOT/'evidence/virgl-multiple-color/worker',dict(manifest='cc3d8bf50dac64c46bff5e83ce54ad50e21928993830896cc11fdb1af7e511b2',archive='5a2bb69d86959fa0eda75da40342a31c760cae2b713dc2a956e9451490d322b9',index='59df1f7b0a68ea9e1cbe790edc67932b5962a095542d4abc3dca79032d790d99'),extract=OUT/'unpacked')
assert worker['members']==102863 and worker['bytes']==1084770847 and worker['sourceHead']==HEAD
seals=[]
for task,ref in [('virgl-integer-image-consumer',D33),('virgl-integer-image-shader',D32)]:
 for role in ['worker','verifier']:seals.append(auth(ROOT/'evidence'/task/role,ref=ref))
u=OUT/'unpacked';hot=json.loads((u/'hot/receipt.json').read_bytes());cold=json.loads((u/'cold/receipt.json').read_bytes());coldreport=json.loads((u/'cold/report.json').read_bytes())
assert hot['gitHead']==cold['gitHead']==coldreport['gitHead']==coldreport['cloneHead']==HEAD
assert hot['sources']==cold['sources'] and hot['generated']==cold['generated']
assert not coldreport['statusBefore'] and not coldreport['statusAfter'] and coldreport['exitCode']==0 and coldreport['command']==['make','verify-E6-T11d34']
assert sha((u/'cold/receipt.json').read_bytes())==coldreport['receiptSha256']
for prefix,receipt in [('hot',hot),('cold',cold)]:
 for name,digest in receipt['files'].items():assert sha((u/prefix/name).read_bytes())==digest
 for name,digest in receipt['generated'].items():assert sha((u/(prefix+'-generated')/name).read_bytes())==digest
 for name,digest in receipt['sources'].items():
  raw=(u/'source'/name).read_bytes();assert sha(raw)==digest and raw==gitbytes(HEAD,name),name
 assert receipt['status']=='passed'
assert len(hot['sources'])==805
for name in hot['generated']:
 raw=(u/'hot-generated'/name).read_bytes()
 assert raw==(ROOT/name).read_bytes() and raw==(u/'cold-generated'/name).read_bytes()
 if name.endswith('.wasm'):assert sha(raw)=='acbe036afcdc4f1d8aa8cfb0fb107f48ba27759a6af4a7b9d6c83e3aa679d6cc'
assert (ROOT/'renderer/virgl-command/constant-domain.mjs').read_bytes().startswith(gitbytes(D33,'renderer/virgl-command/constant-domain.mjs'))
for prefix in ['renderer/virgl-shader','renderer/virgl-command/resources.mjs','renderer/virgl-command/integer-images.mjs','renderer/virgl-command/shared-exponent-gpu.mjs','renderer/virgl-command/color-images.mjs','renderer/virgl-command/float-images.mjs','renderer/virgl-command/packed-float-images.mjs','renderer/virgl-command/shared-exponent-images.mjs']:
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',D32,'--',prefix],cwd=ROOT,text=True).splitlines()
 for name in paths:assert (ROOT/name).read_bytes()==gitbytes(D32,name),name
 for name in paths:assert gitbytes(D33,name)==gitbytes(D32,name),name
summary=dict(status='passed',worker={k:v for k,v in worker.items() if k!='records'},dependencies=[{k:v for k,v in s.items() if k!='records'} for s in seals],sources=hot['sources'],generated=hot['generated'],cold=coldreport,allArchiveMembersReopened=True,compilerStorageHeldCarried=True,oldContractPrefixUnchanged=True)
(OUT/'authentication.json').write_text(json.dumps(summary,indent=2)+'\n')
print('complete source closure',len(hot['sources']),'authentic; exact cold clone and compiler/storage carry held',flush=True)
