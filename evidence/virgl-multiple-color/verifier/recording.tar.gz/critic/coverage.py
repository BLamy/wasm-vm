import hashlib,json,re,subprocess,sys
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');U=Path('/tmp/wasm-vm-multiple-color-critic-20261011/unpacked');BASE='1206a5beb3026de10457cd395d249daf8aff9966';HEAD='fd425d1052ab139e89178729bbb72ce89a3521f1'
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=['renderer/virgl-command/'+n+'.mjs' for n in ['constant-domain','decoder','state']]
diff=subprocess.check_output(['git','diff','--unified=0',BASE,HEAD,'--',*paths],cwd=ROOT,text=True);added={};oldhunks={};source=None;new=0;old=[]
for row in diff.splitlines():
 if row.startswith('+++ b/'):source=row[6:]
 elif row.startswith('@@'):
  new=int(re.search(r'\+(\d+)',row)[1]);old=[];oldhunks.setdefault(source,[]).append((new,old))
 elif row.startswith('-') and not row.startswith('---'):old.append(row[1:])
 elif row.startswith('+') and source:added.setdefault(source,[]).append(new);new+=1
scripts=[]
for side in ['hot','cold']:
 for p in (U/side).rglob('browser-coverage.json'):
  if any(part.startswith('fault-') for part in p.parts):continue
  for row in json.loads(p.read_text())['scripts']:
   if row['source'] not in paths:continue
   assert row['sha256']==sha((U/'source'/row['source']).read_bytes());scripts.append(dict(record=p.relative_to(U).as_posix(),**row))
 for p in (U/side/'node-coverage').glob('coverage-*.json'):
  for row in json.loads(p.read_text())['result']:
   for name in paths:
    if row['url'].endswith('/'+name):scripts.append(dict(record=p.relative_to(U).as_posix(),source=name,sha256=sha((U/'source'/name).read_bytes()),coverage=row))
waivers=json.loads((U/'source/tools/virgl-multiple-color/coverage-waivers.json').read_text())['waivers'];lookup={(w['source'],w['startOffset'],w['endOffset']):w for w in waivers};assert len(lookup)==len(waivers)==36
partitions=[];heldwaivers=[];gaps=[]
for name,lines in added.items():
 text=(U/'source'/name).read_text();assert (ROOT/name).read_text()==text;raw=text.encode('utf-16-le');offsets=[0]
 for line in text.splitlines(keepends=True):offsets.append(offsets[-1]+len(line.encode('utf-16-le'))//2)
 relevant=[s for s in scripts if s['source']==name]
 for line in lines:
  a,b=offsets[line-1],offsets[line];cuts={a,b}
  for s in relevant:
   for fn in s['coverage']['functions']:
    for r in fn['ranges']:
     cuts.update(n for n in [r['startOffset'],r['endOffset']] if a<n<b)
  cuts=sorted(cuts)
  for start,end in zip(cuts,cuts[1:]):
   observations=[]
   for s in relevant:
    governing=[]
    for fi,fn in enumerate(s['coverage']['functions']):
     for ri,r in enumerate(fn['ranges']):
      if r['startOffset']<=start and end<=r['endOffset']:governing.append((r['endOffset']-r['startOffset'],fi,ri,r))
    if governing:
     span=min(t[0] for t in governing);narrow=[t for t in governing if t[0]==span]
     assert len({t[3]['count'] for t in narrow})==1,('ambiguous equal governing span',name,line)
     _,fi,ri,r=narrow[0];observations.append(dict(record=s['record'],function=fi,range=ri,**r))
   cell=dict(source=name,line=line,startOffset=start,endOffset=end,text=raw[start*2:end*2].decode('utf-16-le'),maxCount=max([c['count'] for c in observations],default=0),smallestCounters=observations)
   partitions.append(cell)
   if cell['maxCount']:continue
   w=lookup.get((name,start,end))
   if not w:gaps.append(cell);continue
   assert w['text']==cell['text'] and w['sha256']==sha(cell['text'].encode()) and w['predecessorLiteralUnchanged']
   startline,removed=max((h for h in oldhunks[name] if h[0]<=line),key=lambda h:h[0])
   exact=cell['text'] in '\n'.join(removed)+'\n'
   assert exact or not cell['text'].strip(),('waiver not in corresponding old hunk',name,line,w)
   heldwaivers.append(dict(**cell,decision='WAIVED: unchanged predecessor operand',oldHunkStart=startline,oldRemovedText=removed,independentReason=w['reason']))
assert len(heldwaivers)==36 and not gaps,(len(heldwaivers),gaps)
result=dict(status='passed',sourceHead=HEAD,predecessor=BASE,addedLines=added,partitions=partitions,positive=sum(p['maxCount']>0 for p in partitions),waivers=heldwaivers,gaps=gaps,scripts=scripts,smallestNestedRangesAreAuthority=True,everyWaiverInCorrespondingPredecessorHunk=True)
(ROOT/'evidence/virgl-multiple-color/verifier/coverage-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(positive=result['positive'],waivers=len(heldwaivers),gaps=len(gaps),scripts=len(scripts))))
