import json,hashlib,re,struct
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');v=ROOT/'evidence/virgl-multiple-color/verifier';u=Path('/tmp/wasm-vm-multiple-color-critic-20261011/unpacked');results=[];sha=lambda b:hashlib.sha256(b).hexdigest()
cases=json.loads((u/'hot/predecessor/cases.json').read_text())['cases'];native=[json.loads(line)['result'] for line in (u/'hot/predecessor/native.jsonl').read_text().splitlines()]
assert len(cases)==len(native)==2586
for side in ['hot','cold']:
 node=json.loads((u/side/'node/report.json').read_text());browser=json.loads((u/side/'contracts/report.json').read_text())['browserResult']['result']
 assert node['contract']==browser
 c=node['contract'];assert len(c['historical'])==957 and all(row['current']==row['original'] for row in c['historical'])
 assert len(c['attacks'])==161 and all(row['answer']['ok'] is False and row['answer']['error']['code'] in ['shader-domain-error','shader-link-error'] for row in c['attacks']) and c['getters']==0
 accepted=0
 for row in c['records']:
  case=cases[row['case']];response=native[row['case']];sel=case['selectors'];paired=case['kind'] in [17,18,19];vertex=not paired and case['kind']!=16
  text=case['b'] if paired else case['a'];decl=[int(m or 0) for m in re.findall(r'^DCL OUT\[\d+(?:\.[xyzw]+)?\], COLOR(?:\[(\d+)\])?\s*$',text,re.M)]
  host=sel['signedColorMask'],sel['unsignedColorMask'];expected=response['ok'] and (not any(host) if vertex else 1<=len(decl)<=4 and max(decl)<4 and 0<=host[0]<=15 and 0<=host[1]<=15 and not(host[0]&host[1]))
  assert row['normalized']['ok']==bool(expected),(side,case['name'],row['normalized']['ok'],expected)
  if expected:
   accepted+=1;body=row['normalized']['fragment'] if paired else row['normalized'];metadata=body['metadata'];assert metadata['colorOutputMasks']==dict(signedMask=host[0],unsignedMask=host[1])
   for output in metadata['outputs']:
    if vertex:continue
    slot=output['semanticIndex'];assert slot in decl and output['name']=='fsout_c'+str(slot) and output['type']==('ivec4' if host[0]&(1<<slot) else 'uvec4' if host[1]&(1<<slot) else 'vec4')
 assert accepted==1325
 wire=node['wire']['records'];assert len(wire)==17
 for row in wire:
  if row['kind']=='framebuffer':
   raw=bytes.fromhex(row['hex']);w=struct.unpack('<'+'I'*(len(raw)//4),raw);count=w[1];assert row['selected']['commands'][0]['fields']==dict(colorBufferCount=count,depthStencilSurface=0,colorSurfaces=list(w[3:]))
   assert row['prior']['ok']==(count<=1)
  elif row['kind']=='clear':
   assert row['selected']['commands'][0]['fields']['buffers']==row['buffers'] and row['selected']['commands'][0]['fields']['colorWords']==[0xffffffff,0x80000000,0x7fc01234,1]
   assert row['prior']['ok']==(row['buffers']==4)
  else:assert row['result']['ok'] is False
 results.append(dict(side=side,cases=2586,selected=1629,accepted=accepted,historical=957,attacks=161,wireCases=17,getters=0,nodeReportSha256=sha((u/side/'node/report.json').read_bytes()),browserReportSha256=sha((u/side/'contracts/report.json').read_bytes())))
fresh=json.loads((v/'fresh-contract/report.json').read_text());assert fresh['status']=='passed' and fresh['contract']==json.loads((u/'hot/node/report.json').read_text())['contract'];assert fresh['wire']==json.loads((u/'hot/node/report.json').read_text())['wire']
results.append(dict(freshNodeSha256=sha((v/'fresh-contract/report.json').read_bytes()),exactContractAndWireEquality=True))
p=ROOT/'evidence/virgl-production-readiness/standard-multiple-color-gap.json';gap=json.loads(p.read_text());assert sha(p.read_bytes())=='4e3f7aeb5c1bcdc9d31161d44a8315bdb82bbd0bc7d2d96254e0d887799cf57b'
assert all(not row['result']['ok'] for row in gap['wire']) and len(gap['wire'])==6
for row in gap['compiler']:assert row['stage']['ok'] and row['pair']['ok'] and not row['metadataResult']['ok'] and not row['pairResult']['ok']
out=dict(status='passed',results=results,originalD33NegativeReopened=True,packetConstants='p_defines.h:217-220',productImports=False)
(v/'contract-wire-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
