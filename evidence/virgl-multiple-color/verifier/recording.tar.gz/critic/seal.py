import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');V=ROOT/'evidence/virgl-multiple-color/verifier';U=Path('/tmp/wasm-vm-multiple-color-critic-20261011/unpacked');W=ROOT/'evidence/virgl-multiple-color/worker';HEAD='fd425d1052ab139e89178729bbb72ce89a3521f1';sha=lambda b:hashlib.sha256(b).hexdigest()
assert json.loads((V/'verdict.json').read_text())['verdict']=='verified'
for name in ['constant-domain','decoder','state']:assert (ROOT/f'renderer/virgl-command/{name}.mjs').read_bytes()==(U/f'source/renderer/virgl-command/{name}.mjs').read_bytes()
files={}
for p in V.rglob('*'):
 if p.is_file() and '__pycache__' not in p.parts and p.name not in ['manifest.json','records.json','recording.tar.gz']:files['critic/'+p.relative_to(V).as_posix()]=p
for p in (U/'source').rglob('*'):
 if p.is_file():files['original-source/'+p.relative_to(U/'source').as_posix()]=p
for name in ['manifest.json','records.json','recording.tar.gz']:files['original-worker/'+name]=W/name
for task in ['virgl-integer-image-consumer','virgl-integer-image-shader']:
 for role in ['worker','verifier']:
  for name in ['manifest.json','records.json']:files[f'dependency/{task}/{role}/{name}']=ROOT/'evidence'/task/role/name
promoted=['renderer/virgl-command/tests/standard-multiple-color-critic.mjs','renderer/virgl-command/tests/standard-multiple-color.mjs','tools/verify-virgl-standard-multiple-color.mjs','tools/verify-virgl-standard-multiple-color.sh','tools/virgl-multiple-color/receipt.py']
for name in promoted:files['promoted-source/'+name]=ROOT/name
for name in json.loads((U/'hot/receipt.json').read_text())['generated']:files['generated/'+name]=ROOT/name
records=[]
with (V/'recording.tar.gz').open('wb') as dest:
 with gzip.GzipFile(fileobj=dest,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|') as tar:
   for name,p in sorted(files.items()):
    data=p.read_bytes();entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;entry.mtime=0;tar.addfile(entry,io.BytesIO(data));records.append(dict(path=name,bytes=len(data),sha256=sha(data)))
index=(json.dumps(dict(schema='original-multiple-color-critic-records-v1',task='E6-T11d34',runtimeSourceHead=HEAD,records=records),indent=2)+'\n').encode();(V/'records.json').write_bytes(index)
indexed={r['path']:r for r in records};seen=set();total=0
with tarfile.open(V/'recording.tar.gz','r|gz') as tar:
 for entry in tar:
  assert entry.isfile() and entry.name in indexed and entry.name not in seen;data=tar.extractfile(entry).read();row=indexed[entry.name]
  assert len(data)==row['bytes'] and sha(data)==row['sha256'];seen.add(entry.name);total+=len(data)
  if entry.name=='original-worker/recording.tar.gz':
   wanted={r['path']:r for r in json.loads((W/'records.json').read_text())['records']};innerseen=set()
   with tarfile.open(fileobj=io.BytesIO(data),mode='r|gz') as inner:
    for member in inner:
     assert member.isfile() and member.name in wanted and member.name not in innerseen;raw=inner.extractfile(member).read();r=wanted[member.name];assert len(raw)==r['bytes'] and sha(raw)==r['sha256'];innerseen.add(member.name)
   assert len(innerseen)==102863 and innerseen==set(wanted)
assert seen==set(indexed)
archive=(V/'recording.tar.gz').read_bytes()
manifest=dict(schema='original-multiple-color-critic-seal-v1',task='E6-T11d34',verdict='verified',runtimeSourceHead=HEAD,workerSubmissionHead='d1d5c3914b020c90e91fd633ccfe0adf2dc57d29',predecessor='1206a5beb3026de10457cd395d249daf8aff9966',records=len(records),reopenedMembers=len(seen),uncompressedBytes=total,archiveBytes=len(archive),archiveSha256=sha(archive),recordIndexSha256=sha(index),workerArchiveSha256=sha((W/'recording.tar.gz').read_bytes()),nestedWorkerReopenedMembers=len(innerseen),completeDependencyAuthentication=json.loads((V/'authentication.json').read_text())['dependencies'],predictionsSha256=sha((V/'predictions.json').read_bytes()),verdictSha256=sha((V/'verdict.json').read_bytes()),sourceClosureIncluded=True,promotedSources={n:sha((ROOT/n).read_bytes()) for n in promoted},actualWasmSha256=sha((ROOT/'renderer/virgl-shader/build/wasm/virgl-shader.wasm').read_bytes()),guestExecution=False,productionNegotiation=False,productionDrawAuthority=False,remainingOwnedProcesses=[])
(V/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k not in ['completeDependencyAuthentication','promotedSources']}));print('manifestSha256',sha((V/'manifest.json').read_bytes()))
