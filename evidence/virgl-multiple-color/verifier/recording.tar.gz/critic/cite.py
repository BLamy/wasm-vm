import bisect,hashlib,json
from pathlib import Path
V=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm/evidence/virgl-multiple-color/verifier');U=Path('/tmp/wasm-vm-multiple-color-critic-20261011/unpacked');decoder=json.JSONDecoder();rows=[]
def cite(file,pointer,label):
 raw=Path(file).read_bytes();text=raw.decode();parts=tuple(pointer.strip('/').split('/')) if pointer else ();newlines=[i for i,c in enumerate(text) if c=='\n'];position=None
 def ws(pos):
  while pos<len(text) and text[pos].isspace():pos+=1
  return pos
 def walk(pos,path):
  nonlocal position
  pos=ws(pos)
  if path==parts:position=pos;return decoder.raw_decode(text,pos)[1]
  if parts[:len(path)]!=path:return decoder.raw_decode(text,pos)[1]
  if text[pos]=='{':
   pos=ws(pos+1)
   if text[pos]=='}':return pos+1
   while True:
    key,end=decoder.raw_decode(text,pos);pos=ws(end);assert text[pos]==':';pos=walk(pos+1,path+(key,));pos=ws(pos)
    if text[pos]=='}':return pos+1
    assert text[pos]==',';pos=ws(pos+1)
  if text[pos]=='[':
   pos=ws(pos+1);index=0
   if text[pos]==']':return pos+1
   while True:
    pos=walk(pos,path+(str(index),));index+=1;pos=ws(pos)
    if text[pos]==']':return pos+1
    assert text[pos]==',';pos=ws(pos+1)
  return decoder.raw_decode(text,pos)[1]
 walk(0,());assert position is not None
 value=decoder.raw_decode(text,position)[0]
 relative='worker/'+Path(file).relative_to(U).as_posix() if Path(file).is_relative_to(U) else 'critic/'+Path(file).relative_to(V).as_posix()
 rows.append(dict(label=label,path=relative,line=bisect.bisect_left(newlines,position)+1,pointer=pointer,sha256=hashlib.sha256(raw).hexdigest(),value=value))
hot=U/'hot/hardware/report.json';e=json.loads(hot.read_text())['browserResult']['result'];loc={r['name']:i for i,r in enumerate(e['runs'])}
base='/browserResult/result/runs/'
cite(hot,base+str(loc['original-sparse-slot3'])+'/draws/0/native/outputs/3/location','P03 sparse COLOR3 original location')
cite(hot,base+str(loc['original-mixed-native-types'])+'/draws/0/native/colors/0/componentType','P04 actual SINT component type')
cite(hot,base+str(loc['original-mixed-native-types'])+'/draws/0/native/colors/1/componentType','P04 actual FLOAT component type')
cite(hot,base+str(loc['original-mixed-native-types'])+'/draws/0/native/colors/2/componentType','P04 actual UINT component type')
cite(hot,base+str(loc['original-mixed-blend-constant-7'])+'/draws/0/native/blendFold','P07 native FLOAT factor uniform')
cite(hot,'/browserResult/result/host','P12 measured actual native host')
fresh=V/'fresh-3141592653/report.json';fe=json.loads(fresh.read_text())['browserResult']['result'];k={r['kind']:i for i,r in enumerate(fe['runs'])}
cite(fresh,base+str(k['queued-complete'])+'/actions/0/before/budgets/imageHolds','P10 four original target generations retained')
cite(fresh,base+str(k['queued-cancel'])+'/actions/1/result/error/code','P10 original cancellation terminal')
cite(fresh,base+str(k['measured-host-closed-config'])+'/actions/1/result/error/code','P12 measured below-bound draw buffers refusal')
for i,p in enumerate(fe['predictions']):
 if p['prediction']=='unsupported native capability refuses before any allocation':cite(fresh,'/browserResult/result/predictions/'+str(i)+'/observed','P12 zero allocation before native host refusal');break
fault=V/'promoted-sabotage/report.json';cite(fault,'/partial/frames/6/originalCompletion','P15 original real physical completion');cite(fault,'/partial/frames/6/sabotageCompletion','P15 distinct corruption physical completion')
cite(V/'promoted-sabotage-inverse.json','/differences/0/miss/0','P15 independently detected actual COLOR3 corruption')
cite(V/'promoted/report.json',base+'0/draws/0/native/program','P11 novel first A native program');cite(V/'promoted/report.json',base+'0/draws/3/native/program','P11 novel restored A native program')
cite(U/'cold/report.json','/cloneHead','P14 pristine exact-head clone');cite(V/'coverage-audit.json','/positive','P13 positive smallest nested partitions');cite(V/'contract-wire-audit.json','/results/0','P02/P04 independent original contract and wire counts')
(V/'citations.json').write_text(json.dumps(dict(status='passed',citations=rows),indent=2)+'\n');print(json.dumps(rows))
