import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {parseConstantDomain,checkConversionBank,checkIndirectBank,checkRasterBank,checkRadialBank,checkLoopBank} from '../../../renderer/virgl-command/constant-domain.mjs';
const out=new URL('.',import.meta.url).pathname;
const native=JSON.parse(fs.readFileSync(out+'unpacked/hot/native/report.json'));
const hash=b=>createHash('sha256').update(b).digest('hex');
const rows=[],good=[],banks=[];let invoked=0;
const inert=v=>{if(v===null||typeof v!=='object')return v;const r=Array.isArray(v)?[]:{};for(const [k,d]of Object.entries(Object.getOwnPropertyDescriptors(v)))if(d.enumerable)r[k]=Object.hasOwn(d,'value')?inert(d.value):'[accessor]';return r;};
const reject=(name,value,stage)=>{const result=parseConstantDomain(value,stage);assert.equal(result.ok,false,name);assert.equal(result.error.code,'shader-domain-error');rows.push({name,stage,value:inert(value),result});};
const unique=new Map(native.cases.filter(c=>c.ok&&c.fraction!==false).map(c=>[JSON.stringify(c.result.metadata),c]));
for(const c of unique.values()){
 const original=c.result.metadata,contract=parseConstantDomain(original,c.stage);assert.equal(contract.ok,true);good.push({name:c.name,metadata:original,contract});
 for(const key of ['profile','fractionBaseProfile','fractionWordContract']){
  const x=structuredClone(original);Object.defineProperty(x,key,{enumerable:true,get(){invoked++;return original[key];}});reject(c.name+' accessor '+key,x,c.stage);
 }
 for(const key of Reflect.ownKeys(original.fractionWordContract)){
  const x=structuredClone(original);Object.defineProperty(x.fractionWordContract,key,{enumerable:true,get(){invoked++;return original.fractionWordContract[key];}});reject(c.name+' policy accessor '+key,x,c.stage);
 }
 for(const value of [null,undefined,true,1,'33',{},['FRC_PRECISE']]){const x=structuredClone(original);x.fractionWordContract=value;reject(c.name+' policy shape '+String(value),x,c.stage);}
 for(const key of ['equation','rounding','specials','subnormals','zero','modifiers','authority'])for(const value of [null,true,0,'',new String(original.fractionWordContract[key])]){
  const x=structuredClone(original);x.fractionWordContract[key]=value;reject(c.name+' field '+key+' '+String(value),x,c.stage);
 }
 for(const change of ['extra-policy-symbol','extra-operations-symbol','accessor-operation','sparse-operation','own-nonenumerable-extra','self-wrap','higher-base','invent-base']){
  const x=structuredClone(original),s=Symbol('hostile');
  if(change==='extra-policy-symbol')x.fractionWordContract[s]=true;
  if(change==='extra-operations-symbol')x.fractionWordContract.operations[s]=true;
  if(change==='accessor-operation')Object.defineProperty(x.fractionWordContract.operations,'0',{enumerable:true,get(){invoked++;return 'FRC_PRECISE';}});
  if(change==='sparse-operation')delete x.fractionWordContract.operations[0];
  if(change==='own-nonenumerable-extra')Object.defineProperty(x.fractionWordContract,'hidden',{value:0});
  if(change==='self-wrap')x.fractionBaseProfile='virgl-webgl2-raw-bits-v33';
  if(change==='higher-base')x.fractionBaseProfile='virgl-webgl2-raw-bits-v34';
  if(change==='invent-base')x.fractionBaseProfile='virgl-webgl2-raw-bits-v0';
  reject(c.name+' '+change,x,c.stage);
 }
 for(const baseField of ['minimumWordContract','minimumBaseProfile','scalarWordContract','scalarBaseProfile','signedConversionContract','conversionBaseProfile','constantConversionDomains','preciseArithmeticContract','arithmeticBaseProfile','preciseWordContract','constantDomains','constantRadialDomains','constantRasterDomains','rasterBaseProfile','constantConstraints','constantAccesses'])if(Object.hasOwn(original,baseField)){
  const x=structuredClone(original);delete x[baseField];reject(c.name+' erased '+baseField,x,c.stage);
 }
 const x=structuredClone(original),owned=parseConstantDomain(x,c.stage),before=JSON.stringify(owned);x.fractionWordContract.operations[0]='FRC';x.fractionWordContract.equation='x';assert.equal(JSON.stringify(owned),before);assert.equal(Object.isFrozen(owned.fraction),true);assert.equal(Object.isFrozen(owned.fraction.operations),true);
 if(!contract.domain&&!contract.conversionDomain&&!original.uniforms.length)continue;
 const count=(contract.domain??contract.conversionDomain)?.count??original.uniforms[0].count;
 const check=w=>contract.conversionDomain?checkConversionBank(w,contract.conversionDomain,contract):contract.rasterDomain?checkRasterBank(w,contract.rasterDomain,!!contract.constraint,!!contract.radialDomain):contract.radialDomain?checkRadialBank(w,count,!!contract.constraint):contract.constraint?checkLoopBank(w,count):checkIndirectBank(w,count,contract.domain!==null);
 const caller=Array(Math.min(count,46)*4).fill(0);if(contract.radialDomain)caller[16]=0x3f800000;
 const valid=check(caller);assert.equal(valid.ok,true);const old=valid.words.slice();caller.fill(0x7fffffff);assert.deepEqual(valid.words,old);assert.equal(Object.isFrozen(valid.words),true);
 assert.equal(check(old.slice(0,-4)).ok,false,'full prefix survives fraction');
 const checks=[];if(contract.conversionDomain)for(const component of contract.conversionDomain.components)for(let lane=0;lane<4;lane++)if(component.mask&(1<<lane)){
  for(const w of [0x4f000000,0x4f000001,0xcf000001,0x7f7fffff,0xff7fffff]){const attack=old.slice();attack[component.register*4+lane]=w;const result=check(attack);assert.equal(result.ok,false);checks.push({component,lane,w,result});}
 }
 banks.push({name:c.name,count,contract,owned:old,rangeAttacks:checks});
}
assert.equal(invoked,0);
const report={schema:'virgl-fraction-critic-consumer-attacks-v1',task:'E6-T12g6g2',status:'passed',nativeReportSha256:hash(fs.readFileSync(out+'unpacked/hot/native/report.json')),good,attacks:rows,banks,accessorsInvoked:invoked};
fs.writeFileSync(out+'consumer-attacks.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:'passed',contracts:good.length,attacks:rows.length,banks:banks.length,invoked}));
