#!/usr/bin/env python3
import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
shown={};native=[]
for name,prefix,gen in [('hot','hot','generated'),('cold','cold/acceptance','cold-generated')]:
 binary=OUT/'unpacked'/gen/'precise-fraction-sanitize/precise-fraction-test';profile=OUT/'unpacked'/prefix/'native/native.profdata';cov=json.loads((OUT/(name+'-coverage-export.json')).read_bytes());summaries=[]
 for d in cov['data']:
  for f in d['files']:
   original=f['filename'].split('/renderer/virgl-shader/')[0]
   cmd=['xcrun','llvm-cov','show',str(binary),'-instr-profile='+str(profile),'-path-equivalence='+original+','+str(ROOT),f['filename'],'-show-line-counts-or-regions']
   raw=subprocess.check_output(cmd,text=True);filename=Path(f['filename']).name
   (OUT/(name+'-coverage-'+filename+'.txt')).write_text(raw)
   lines={}
   for row in raw.splitlines():
    m=re.match(r'^\s*(\d+)\|\s*([^|]*)\|(.*)$',row)
    if m:lines[int(m[1])]={'count':m[2].strip(),'source':m[3]}
   shown[name,filename]=lines;summaries.append({'file':filename,'summary':f['summary']})
   if filename=='raw_fraction.h':assert f['summary']['lines']['percent']==f['summary']['branches']['percent']==f['summary']['regions']['percent']==100
 native.append({'name':name,'binarySha256':sha(binary.read_bytes()),'profileSha256':sha(profile.read_bytes()),'summaries':summaries})
js='renderer/virgl-command/constant-domain.mjs';text=(ROOT/js).read_text();ranges=[]
for p in (OUT/'unpacked').glob('**/browser-coverage.json'):
 for s in json.loads(p.read_bytes())['scripts']:
  if s['source']==js:
   assert s['sha256']==sha(text.encode())
   for f in s['coverage']['functions']:
    for r in f['ranges']:ranges.append((str(p.relative_to(OUT)),r))
for p in (OUT/'node-consumer-coverage').glob('*.json'):
 for s in json.loads(p.read_bytes())['result']:
  if s['url'].endswith('/'+js):
   for f in s['functions']:
    for r in f['ranges']:ranges.append((str(p.relative_to(OUT)),r))
paths=['renderer/virgl-shader/bridge.c','renderer/virgl-shader/raw_bits.c','renderer/virgl-shader/raw_bits.h','renderer/virgl-shader/raw_fraction.h',js]
patch=subprocess.check_output(['git','diff','--unified=0','5ec49cbc','be4ff41b','--',*paths],cwd=ROOT,text=True)
(OUT/'runtime.diff').write_text(patch);added=[];file=None;line=0;hunks=0
for row in patch.splitlines():
 if row.startswith('+++ b/'):file=row[6:]
 elif row.startswith('@@'):line=int(re.search(r'\+(\d+)',row)[1]);hunk=row;hunks+=1
 elif row.startswith('+') and not row.startswith('+++'):
  source=row[1:];item={'file':file,'line':line,'hunk':hunk,'source':source};s=source.strip()
  if file.endswith('.c') or file.endswith('/raw_fraction.h') and line<46:
   counts=[shown[name,Path(file).name].get(line,{}).get('count','') for name in ['hot','cold']];item['recordedCounts']=counts
   if any(c and c!='0' for c in counts):item.update(classification='executed',reason='Positive line/region count from the actual archived binary and original profile in both recorded environments.')
   elif not s or s in ['{','}'] or s.startswith(('/*','*','#')) or s.startswith(('static void fraction_contract','static uint32_t raw_frc_')):item.update(classification='waived',reason='Declaration, directive, delimiter or comment; called function body/recorded helper counts establish the behavioral path.')
   else:item.update(classification='needs-evidence',reason='No positive recorded native region; inspect before verdict.')
  elif file.endswith('.h'):
   item.update(classification='waived',reason='Static opcode declarations/mask/assertion or emitted GLSL source data. Actual helper export has 100% 36-line/32-branch/81-region coverage; exact emitted data is bound to shaderSource and independently checked physical outputs, including fault sensitivity.')
  else:
   offsets=[m.start() for m in re.finditer('^',text,re.M)];at=offsets[line-1]+len(source)-len(source.lstrip());hit=[]
   per_record={}
   for p,r in ranges:
    if r['startOffset']<=at<r['endOffset']:
     old=per_record.get(p)
     if old is None or r['endOffset']-r['startOffset']<old['endOffset']-old['startOffset']:per_record[p]=r
   for p,r in per_record.items():
    if r['count']>0:hit.append({'record':p,**r})
   # Report the tightest positive range; declaration initialization is also
   # covered by module evaluation. Runtime body checks have direct consumer
   # and physical parseConstantDomain executions, not only root evaluation.
   hit.sort(key=lambda r:r['endOffset']-r['startOffset']);item['v8Range']=hit[:1]
   if not s or s.startswith('//'):item.update(classification='waived',reason='Non-executable comment/blank.')
   elif hit:item.update(classification='executed',reason='Exact-source recorded V8 range plus independent live consumer attack recording.')
   else:item.update(classification='needs-evidence',reason='No positive exact-source JS range.')
  added.append(item);line+=1
result={'schema':'virgl-fraction-critic-coverage-v1','task':'E6-T12g6g2','status':'passed' if all(r['classification']!='needs-evidence' for r in added) else 'needs-evidence','hunks':hunks,'addedRuntimeLines':len(added),'nativeBindings':native,'lines':added,'needsEvidence':[r for r in added if r['classification']=='needs-evidence'],'dead':[]}
(OUT/'coverage-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'hunks':hunks,'lines':len(added),'needsEvidence':result['needsEvidence']},indent=2))
