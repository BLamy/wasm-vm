#!/usr/bin/env python3
"""Interpret the recorded TGSI source, never compiler IR or emitted GLSL."""
import hashlib, itertools, json, math, re, struct
from pathlib import Path

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
sha=lambda b:hashlib.sha256(b).hexdigest()
number=lambda w:struct.unpack('<f',struct.pack('<I',w))[0]
word=lambda x:struct.unpack('<I',struct.pack('<f',x))[0]
u32=lambda x:x&0xffffffff
signed=lambda x:x if x<0x80000000 else x-0x100000000

from functools import lru_cache

def nearest_even(n,d):
    q,r=divmod(n,d)
    return q+int(2*r>d or 2*r==d and q&1)

@lru_cache(maxsize=None)
def fraction(word):
    exponent=(word>>23)&255
    if exponent==255:return 0x7fc00000
    significand=(word&0x7fffff)|(0x800000 if exponent else 0)
    shift=exponent-150 if exponent else -149
    n,d=(significand<<shift,1) if shift>=0 else (significand,1<<-shift)
    if word&0x80000000:n=-n
    n=n%d
    if not n:return 0
    e=n.bit_length()-d.bit_length()
    if (n<d<<e if e>=0 else n<<-e<d):e-=1
    if e<-126:return nearest_even(n<<149,d)
    q=nearest_even(n<<(23-e),d)
    if q==1<<24:q>>=1;e+=1
    return ((e+127)<<23)|(q-0x800000)

def interpret(text, inputs, bank=None, backend='owned'):
    storage={}
    operations=[]
    def literal(w):
        return {w, w^0x80000000} if backend=='mesa' and w&0x7fffffff==0 else {w}
    for index,values in inputs.items():
        storage['IN',index]=[literal(w) for w in values]
    if bank is not None:
        for at in range(0,len(bank),4):storage['CONST',at//4]=[literal(w) for w in bank[at:at+4]]
    def operand(text):
        m=re.fullmatch(r'(-?)(IMM|TEMP|CONST|IN|OUT)\[(\d+)\](?:\.([xyzw]{4}))?',text)
        assert m,text
        values=storage[m[2],int(m[3])]
        result=[set(values['xyzw'.index(c)]) for c in (m[4] or 'xyzw')]
        return [{w^0x80000000 for w in lane} for lane in result] if m[1] else result
    def operation(op, values):
        result=set()
        for v in itertools.product(*values):
            a=v[0];b=v[1] if len(v)>1 else 0
            if op=='MOV':r=a
            elif op=='AND':r=a&b
            elif op=='OR':r=a|b
            elif op=='UADD':r=u32(a+b)
            elif op=='USHR':r=a>>(b&31)
            elif op=='UCMP':r=v[1] if a else v[2]
            elif op in ['MIN','MIN_PRECISE']:
                first,second=number(a),number(b)
                if op=='MIN' or backend=='mesa':
                    assert math.isfinite(first) and math.isfinite(second),'numeric/primary source domain'
                    if first==second==0:
                        result.update([0,0x80000000]);continue
                r=a if first<second else b
            elif op in ['FRC','FRC_PRECISE']:
                if op=='FRC' or backend=='mesa':assert (a&0x7f800000)!=0x7f800000
                r=fraction(a)
                if r==0 and (op=='FRC' or backend=='mesa'):
                    result.update([0,0x80000000]);continue
            elif op=='F2I':
                value=number(a);assert -2**31<=value<2**31 and math.isfinite(value)
                r=u32(math.trunc(value))
            elif op=='I2F':r=word(signed(a))
            elif op=='TRUNC':
                x=number(a);assert math.isfinite(x)
                r=(a&0x80000000) if math.trunc(x)==0 else word(math.trunc(x))
            elif op=='SSG':
                x=number(a);assert math.isfinite(x);r=word(-1 if x<0 else 1 if x>0 else 0)
            else:raise AssertionError(op)
            result.add(u32(r))
        return result
    flow=[];active=True
    for line in text.splitlines():
        line=line.strip()
        if not line or line in ['FRAG','VERT','END'] or line.startswith('DCL '):continue
        m=re.fullmatch(r'IMM\[(\d+)\] (UINT32|FLT32) \{([^}]+)\}',line)
        if m:
            values=[int(x) if m[2]=='UINT32' else word(float(x)) for x in m[3].split(',')]
            storage['IMM',int(m[1])]=[literal(w) for w in values];continue
        if line.startswith('UIF '):
            source=operand(line[4:])[0];assert len(source)==1,'concrete predecessor'
            enabled=bool(next(iter(source)));flow.append((active,enabled));active=active and enabled;continue
        if line=='ELSE':active=flow[-1][0] and not flow[-1][1];continue
        if line=='ENDIF':active=flow.pop()[0];continue
        if not active:continue
        op,rest=line.split(' ',1);parts=rest.split(', ');destination=re.fullmatch(r'(TEMP|OUT)\[(\d+)\](?:\.([xyzw]+))?',parts[0]);assert destination,line
        sources=[operand(x) for x in parts[1:]]
        # Capture every source lane before any aliased destination is published.
        lanes=list(destination[3] or 'xyzw');result={}
        for c in lanes:
            lane='xyzw'.index(c);result[lane]=operation(op,[source[lane] for source in sources])
        key=destination[1],int(destination[2]);old=storage.get(key,[set() for _ in range(4)])
        storage[key]=[result.get(i,old[i]) for i in range(4)]
        operations.append({'sourceInstruction':line,'destination':parts[0],'writtenLanes':lanes,'selectedWords':[sorted(storage[key][i]) for i in range(4)]})
    assert not flow
    return storage,operations

def hardware(report_path):
    raw=report_path.read_bytes();report=json.loads(raw);a=report['acceptance'];assert report['status']=='passed' and a['status']=='passed'
    assert report['browserErrors']=={'console':[],'page':[],'requests':[]}
    assert report['browser']['launch']['headless'] is False
    assert report['browser']['gpu']['featureStatus'][report['browser']['webglFeature']]=='enabled'
    assert not re.search('swiftshader|software|llvmpipe|softpipe',a['renderer']['renderer'],re.I)
    vertices=[];fragments=[];draws=[];words=pixels=0
    source_pairs=json.loads((OUT/'source-pairs.json').read_bytes())['pairs']
    expected_sources=[]
    for v in a['vertices']:
        expected_sources += [v['primary']['glsl'] if v['backend']=='mesa' else v['pair']['vertex']['glsl'],v['pair']['fragment']['glsl']]
    for f in a['fragments']:
        expected_sources += [f['pair']['vertex']['glsl'],f['primary']['glsl'] if f['backend']=='mesa' else f['pair']['fragment']['glsl']]
    for c in a['consumers']:
        pair=source_pairs[json.dumps(c['sources'],separators=(',',':'))]
        expected_sources += [pair['vertex']['glsl'],pair['fragment']['glsl']]
    for d in a['bankDraws']:expected_sources += [d['pair']['vertex']['glsl'],d['pair']['fragment']['glsl']]
    actual_sources=[e['source'] for e in a['events'] if e['call']=='shaderSource']
    assert actual_sources==expected_sources,'actual shaderSource sequence is exactly the returned sources and pinned primary shaders'
    live={};compiled=set();source_ids=set()
    for ei,event in enumerate(a['events']):
        call=event['call'];identity=event.get('id')
        if call.startswith('create') or call=='fenceSync':assert identity not in live;live[identity]=call
        if call=='shaderSource':assert identity in live;source_ids.add(identity)
        if call=='compileShader':assert identity in source_ids and event['status'] is True;compiled.add(identity)
        if call=='linkProgram':assert identity in live and event['status'] is True
        if call.startswith('delete'):assert identity in live;del live[identity]
    assert not live and len(source_ids)==len(compiled)==len(expected_sources) and a['objects']['live']==0
    for index,v in enumerate(a['vertices']):
        assert sha(v['text'].encode())==v['textSha256']
        vectors=[]
        for vi,x in enumerate(v['vectors']):
            inputs={0:[word(p) for p in x['position']]}
            if v['inputSource']:inputs[1]=x['input']['a'][:];assert x['inputWords']==inputs[1]
            bank=[0]*184
            bank[:4]=x['input']['a'];bank[180:184]=x['input']['b'];bank[172]=x['condition']
            if x['bankUpload']:
                r=v['uniformReflection'];assert r['type']==36296 and 1<=r['count']<=r['declaredCount'] and r['declaredCount'] in [46,47]
                assert x['bankUpload']['words']==bank
                assert x['bankUpload']['observedA']==x['input']['a']
                assert x['bankUpload']['observedB'] in [None,x['input']['b']]
                assert all(w==0xdeadbeef for w in x['bankUpload']['callerAfter'])
            state,ops=interpret(v['text'],inputs,bank,v['backend'])
            wanted=state['OUT',0]+state['OUT',1]+state['OUT',2]
            actual=list(struct.unpack('<12I',bytes(x['bytes'])))
            assert sha(bytes(x['bytes']))==x['sha256']
            assert all(w in expected for w,expected in zip(actual,wanted)),(report_path,index,vi,actual,wanted)
            assert actual==x['observed'] and x['checkedWords']==12
            reconstructed=[((actual[8+i]&511)<<23)|(actual[4+i]&0x7fffff) for i in range(4)]
            selected=next(o for o in ops if o['sourceInstruction'].startswith(v['op']+' '))
            vectors.append({'vector':vi,'input':x['input'],'condition':x['condition'],'sourceOperation':selected,
                'predictedCarrierWords':[sorted(s) for s in wanted],'reconstructedWords':reconstructed,'captureSha256':x['sha256']})
            words+=12
        assert [(r['name'],r['type'],r['size']) for r in v['reflection']]==[('gl_Position',35666,1),('vso_g0',35666,1),('vso_g1',35666,1)]
        vertices.append({'record':index,'op':v['op'],'variant':v['variant'],'backend':v['backend'],'textSha256':v['textSha256'],'vectors':vectors})
    for index,f in enumerate(a['fragments']):
        assert sha(f['text'].encode())==f['textSha256']
        state,ops=interpret(f['text'],{},None,f['backend']);wanted=state['OUT',0]
        rgba=[{round(number(w)*255) for w in s} for s in wanted]
        captured=bytes(f['rgbaBytes']);assert sha(captured)==f['sha256'] and len(captured)==64
        assert all(w in rgba[i%4] for i,w in enumerate(captured)),(report_path,index,rgba)
        assert f['checkedPixels']==16
        fragments.append({'record':index,'op':f['op'],'backend':f['backend'],'plane':f['plane'],'expectedRGBA':[sorted(s) for s in rgba],'captureSha256':f['sha256']})
        pixels+=16
    assert [(d['stage'],d['asynchronous']) for d in a['bankDraws']]==[(0,False),(0,True),(1,False),(1,True)]
    for index,d in enumerate(a['bankDraws']):
        assert len(d['draws'])==5 and len(d['attacks'])==6 and not d['oracleStops']
        metadata=d['pair']['vertex' if d['stage']==0 else 'fragment']['metadata']
        assert metadata['minimumWordContract']['operations']==['MIN','MIN_PRECISE']
        assert metadata['fractionWordContract']['operations']==['FRC_PRECISE']
        assert metadata['constantConversionDomains'][0]['components']==[{'register':45 if d['stage']==0 else 0,'mask':10 if d['stage']==0 else 5}]
        captured_draws=[]
        for x in d['draws']:
            stage=d['stage'];text=d['sources']['vertex' if stage==0 else 'fragment']
            state,ops=interpret(text,{0:[word(0),word(0),word(0),word(1)]},x['words'])
            selected=state['OUT',1 if stage==0 else 0]
            expected=[{round(number(w)*255) for w in s} for s in selected]
            raw=bytes(x['rgbaBytes']);assert sha(raw)==x['sha256'] and len(raw)==64
            assert all(w in expected[i%4] for i,w in enumerate(raw)),(report_path,index,x['label'],expected)
            assert x['uniformWords']==x['source']==x['words'][(45 if stage==0 else 0)*4:((45 if stage==0 else 0)+1)*4]
            assert x['snapshot']['contexts'][0]['subContexts'][0]['bindings']['constants'][stage]==x['words']
            captured_draws.append({'label':x['label'],'sourceEquations':ops,'expectedRGBA':[sorted(s) for s in expected],'captureSha256':x['sha256']})
            pixels+=16
        for attack in d['attacks'][:5]:
            assert attack['before']==attack['after'] and attack['pixelsBefore']==attack['pixelsAfter']
            assert not attack['result']['ok'] and attack['result']['error']['code']=='constant-conversion-domain-error' and attack['result']['appliedCommands']==0
            assert not any(e['call'] in ['uniform4uiv','drawElements','getBufferSubData','copyBufferSubData'] for e in attack['events'])
        assert d['attacks'][-1]['result']['error']['code']=='incomplete-draw'
        assert len(d['yieldAttacks'])==(1 if d['asynchronous'] else 0)
        for x in d['yieldAttacks']:
            assert x['before']==x['after'] and x['before']['jobs']['status']=='waiting-index'
            assert all(not r['ok'] and r['error']['code']=='busy' for r in x['attempts'])
        assert all(n==0 for n in d['finalBudgets'].values()) and all(n==0 for n in d['finalResourceBudgets'].values())
        draws.append({'record':index,'stage':d['stage'],'asynchronous':d['asynchronous'],'draws':captured_draws,'guardedAttacks':len(d['attacks']),'asyncWaits':len(d['yieldAttacks'])})
    for consumer in a['consumers']:
        assert len(consumer['captures'])==6 and all(x==0 for x in consumer['finalBudgets'].values()) and all(x==0 for x in consumer['finalResourceBudgets'].values())
        for capture in consumer['captures']:
            banks=capture['snapshot']['contexts'][0]['subContexts'][0]['bindings']['constants']
            assert banks[0]==banks[1] and len(banks[0])==184
            for uniform in capture['native']:assert uniform['words']==banks[0][uniform['index']*4:uniform['index']*4+4]
        r=consumer['rejection'];assert r['before']==r['after'] and not r['result']['ok'] and r['result']['appliedCommands']==0
    assert words==a['checkedWords'] and pixels==a['checkedPixels'] and a['objects']['live']==0
    return {'path':str(report_path.relative_to(OUT)),'reportSha256':sha(raw),'seed':a['seed'],'renderer':a['renderer'],'checkedWords':words,'checkedPixels':pixels,'shaderSourcesBound':len(expected_sources),'vertices':vertices,'fragments':fragments,'draws':draws}

def main():
    import sys
    runs=[]
    paths=list((OUT/'unpacked/hot').glob('gpu-*/report.json'))+list((OUT/'unpacked/cold/acceptance').glob('gpu-*/report.json'))
    if '--fourth' in sys.argv:paths=[OUT/'gpu-610839776/report.json']
    for p in sorted(paths):runs.append(hardware(p))
    result={'task':'E6-T12g6g2','status':'passed','oracle':'Independent TGSI execution: exact source Euclidean remainder with integer-scale nearest-even rounding; no compiler helper or returned expectedWords supplies truth. Only ordinary or primary floating zero signs vary; owned precise and unwritten raw lanes remain exact.','runs':runs,'checkedWords':sum(r['checkedWords'] for r in runs),'checkedPixels':sum(r['checkedPixels'] for r in runs)}
    output=OUT/('fourth-seed-semantics.json' if '--fourth' in sys.argv else 'source-semantics.json')
    output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'passed','runs':len(runs),'words':result['checkedWords'],'pixels':result['checkedPixels']}))

if __name__=='__main__':main()
