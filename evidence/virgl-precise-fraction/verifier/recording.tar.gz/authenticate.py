#!/usr/bin/env python3
import hashlib,json,subprocess,tarfile
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
WORKER=OUT.parent/'worker'
FROZEN='8a721921e16375ccc6ee30f46e772f245a4a17ac'
SUBMISSION='be4ff41ba8e99047796d9c41e13b34b0965c8e6c'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
man=json.loads((WORKER/'manifest.json').read_bytes())
idx=(WORKER/'records.json').read_bytes(); arc=(WORKER/'recording.tar.gz').read_bytes()
assert man['sourceHead']==FROZEN and man['records']==95
assert sha(arc)=='4d4636dc00d88c0a9bb073e2fbc35afba741f51d460912430e4c8fe1b24c562d'
assert sha(idx)=='a0d424b132263e40d61e497f2416f2927c285f0b57896f0a7ae4d4311f0ec623'
for key,b in [('archive',arc),('recordIndex',idx)]: assert len(b)==man[key]['bytes'] and sha(b)==man[key]['sha256']
index=json.loads(idx); entries={r['path']:r for r in index['records']}
assert index['sourceHead']==FROZEN and len(entries)==len(index['records'])==95
unpacked=OUT/'unpacked'; unpacked.mkdir(exist_ok=True); names=[]
with tarfile.open(WORKER/'recording.tar.gz','r:gz') as tf:
 for m in tf.getmembers():
  assert m.isfile() and m.name in entries and m.name not in names
  p=PurePosixPath(m.name);assert not p.is_absolute() and '..' not in p.parts
  b=tf.extractfile(m).read();r=entries[m.name];assert len(b)==r['bytes'] and sha(b)==r['sha256'],m.name
  d=unpacked/m.name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b);names.append(m.name)
assert set(names)==set(entries)
for path,key in [('hot/receipt.json','hotReceiptSha256'),('cold/report.json','coldReportSha256'),('cold/acceptance/receipt.json','coldReceiptSha256')]: assert sha((unpacked/path).read_bytes())==man[key]
changes=git('diff','--name-only',FROZEN,SUBMISSION).decode().splitlines()
assert all(p.startswith(('evidence/','tasks/')) for p in changes),changes
summaries=[]
for prefix,gen in [('hot','generated'),('cold/acceptance','cold-generated')]:
 base=unpacked/prefix; receipt=json.loads((base/'receipt.json').read_bytes()); assert receipt['status']=='passed' and receipt['gitHead']==FROZEN
 rs={r['path']:r for r in receipt['records']}; ss={r['path']:r for r in receipt['sources']}
 for r in rs.values():
  b=(base/r['path']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256'],r['path']
 for p,r in ss.items():
  if p.startswith('renderer/virgl-shader/build/'):b=(unpacked/gen/p.removeprefix('renderer/virgl-shader/build/')).read_bytes()
  else:
   b=git('show',FROZEN+':'+p);assert b==git('show',SUBMISSION+':'+p)==(ROOT/p).read_bytes(),p
  assert len(b)==r['bytes'] and sha(b)==r['sha256'],p
 checks=[]
 for f in sorted(base.rglob('*.json')):
  val=json.loads(f.read_bytes())
  if not isinstance(val,dict):continue
  if 'gitHead' in val:assert val['gitHead']==FROZEN,(f,val['gitHead'])
  for r in val.get('sources',[])+val.get('servedFiles',[]):
   assert r['path'] in ss,(f,r['path']);assert r['sha256']==ss[r['path']]['sha256'];assert r.get('size',r.get('bytes'))==ss[r['path']]['bytes']
  if 'browserCoverage' in val:
   r=val['browserCoverage'];b=(f.parent/r['path']).read_bytes();assert sha(b)==r['sha256']
   cov=json.loads(b)
   for c in cov['scripts']:assert c['sha256']==ss[c['source']]['sha256'],c['source']
   for key in ['screenshot','failureScreenshot']:
    if val.get(key):r=val[key];assert sha((f.parent/r['path']).read_bytes())==r['sha256']
  checks.append(str(f.relative_to(unpacked)))
 native=json.loads((base/'native/report.json').read_bytes())
 for key,path in [('fixtureSha256','cases.bin'),('logSha256','native.log'),('stderrSha256','native.stderr'),('coverageSha256','coverage.json')]:assert sha((base/'native'/path).read_bytes())==native[key]
 assert not (base/'native/native.stderr').read_bytes()
 for key in ['binary','primaryFile']:
  r=native[key];p=r['path'];b=(unpacked/gen/p.removeprefix('renderer/virgl-shader/build/')).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256']
 for path in ['wasm/report.json','consumer.json']:assert json.loads((base/path).read_bytes())['nativeSha256']==sha((base/'native/report.json').read_bytes())
 for p in ['independent-joins.json','independent-hex-guards.json','independent-signed-guards.json','independent-conversion-guards.json','independent-scalar-guards.json','independent-minimum-guards.json']:
  v=json.loads((base/p).read_bytes());assert v['nativeBinary']['sha256']==sha((unpacked/gen/'native/virgl-shader').read_bytes())
  if v.get('testSha256'):
   candidates=[r for r in ss.values() if r['sha256']==v['testSha256']];assert candidates,p
 legacy=json.loads((base/'legacy.json').read_bytes())
 for r in legacy['fixtures']+[legacy['migration']]:assert sha((ROOT/r['path']).read_bytes())==r['sha256']
 summaries.append({'prefix':prefix,'records':len(rs),'sources':len(ss),'reports':checks,'nativeBinary':native['binary'],'nativeFixtureSha256':native['fixtureSha256'],'sourceHashes':{p:r['sha256'] for p,r in ss.items() if not p.startswith('renderer/virgl-shader/build/')}})
cold=json.loads((unpacked/'cold/report.json').read_bytes());assert cold['gitHead']==cold['cloneHead']==FROZEN and cold['status']=='passed' and cold['exitCode']==0 and cold['statusBefore']==cold['statusAfter']==''
assert cold['receiptSha256']==man['coldReceiptSha256'] and cold['logSha256']==sha((unpacked/'cold/cold.log').read_bytes())
assert 'RUST_LOG' in cold['removedEnvironmentNames']
result={'schema':'virgl-fraction-critic-authentication-v1','task':'E6-T12g6g2','status':'passed','submission':SUBMISSION,'sourceHead':FROZEN,'manifestSha256':sha((WORKER/'manifest.json').read_bytes()),'archive':man['archive'],'index':man['recordIndex'],'members':95,'changedAfterFreeze':changes,'authenticated':summaries,'cold':cold}
(OUT/'authentication.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'passed','members':95,'records':[r['records'] for r in summaries],'sources':[r['sources'] for r in summaries],'coldHead':cold['cloneHead']}))
