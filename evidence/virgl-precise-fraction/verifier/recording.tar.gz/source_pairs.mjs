import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createVirglShaderBridge} from '../../../renderer/virgl-shader/index.mjs';
const out=path.dirname(new URL(import.meta.url).pathname),bridge=await createVirglShaderBridge(),hash=b=>createHash('sha256').update(b).digest('hex');
const reports=fs.readdirSync(out+'/unpacked/hot').filter(x=>x.startsWith('gpu-')).map(x=>out+'/unpacked/hot/'+x+'/report.json');
if(fs.existsSync(out+'/gpu-610839776/report.json'))reports.push(out+'/gpu-610839776/report.json');
const results={};
for(const p of reports){const a=JSON.parse(fs.readFileSync(p)).acceptance;
 for(const c of a.consumers){const key=JSON.stringify(c.sources),result=bridge.translatePair(c.sources);assert.equal(result.ok,true);results[key]=result;}
}
const hashes={};for(const name of ['virgl-shader.mjs','virgl-shader.wasm']){const p='renderer/virgl-shader/build/wasm/'+name;hashes[p]=hash(fs.readFileSync(p));assert.equal(hashes[p],hash(fs.readFileSync(out+'/unpacked/generated/wasm/'+name)));}
fs.writeFileSync(out+'/source-pairs.json',JSON.stringify({status:'passed',wasmHashes:hashes,pairs:results},null,2)+'\n');
console.log(JSON.stringify({status:'passed',pairs:Object.keys(results).length}));
