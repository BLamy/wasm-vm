#!/usr/bin/env python3
import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
new=OUT/'gpu-610839776/report.json';fourth=json.loads(new.read_bytes());assert fourth['status']=='passed' and fourth['gitHead']=='be4ff41ba8e99047796d9c41e13b34b0965c8e6c' and not fourth['trackedChanges']
source_map={r['path']:r for r in fourth['sources']}
for r in fourth['sources']+fourth['servedFiles']:
 b=(ROOT/r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b)==r.get('size',r.get('bytes')),r['path']
for r in json.loads((new.parent/fourth['browserCoverage']['path']).read_bytes())['scripts']:assert r['sha256']==source_map[r['source']]['sha256']
for key in ['screenshot','browserCoverage']:
 r=fourth[key];assert sha((new.parent/r['path']).read_bytes())==r['sha256']
proofs=[]
for p in list((OUT/'unpacked').glob('**/gpu-*/report.json'))+list((OUT/'unpacked').glob('**/fault-*/report.json'))+[new]:
 a=json.loads(p.read_bytes())['acceptance'];assert a['guestExecution'] is False and a['productionNegotiation'] is False and a['objects']['live']==0
 for c in a['consumers']+a['bankDraws']:
  assert all(v==0 for v in c['finalBudgets'].values()) and all(v==0 for v in c['finalResourceBudgets'].values())
 proofs.append({'path':str(p.relative_to(OUT)),'sha256':sha(p.read_bytes()),'status':a['status'],'objectsCreated':a['objects']['created'],'objectsLive':0,'consumers':len(a['consumers']),'drawConsumers':len(a['bankDraws'])})
# New GLSL helper is static bounded source with only bounded unsigned shifts and
# bounded normalization. Record its mechanical source bounds and new IR enum.
fraction=(ROOT/'renderer/virgl-shader/raw_fraction.h').read_text();assert 'step < 23' in fraction and 'sizeof(raw_binary32_fraction) <= 3072' in fraction
assert 'fraction' not in (ROOT/'renderer/virgl-shader/raw_conversions.h').read_text()
# Integration was never touched: hash exact production boundary bytes against
# the independently verified predecessor rather than inferring from runtime flags.
gates=[]
for p in ['web/main.js','web/index.html','web/dist/main.js','web/dist/index.html','web/roadmap.js','crates/core/Cargo.toml','crates/core/src/dev/virtio/gpu/mod.rs']:
 b=(ROOT/p).read_bytes();assert git('show','5ec49cbc:'+p)==b;gates.append({'path':p,'sha256':sha(b)})
gpu=(ROOT/'crates/core/src/dev/virtio/gpu/mod.rs').read_text();assert 'pub const DEFAULT_NUM_CAPSETS: u32 = 0;' in gpu
assert re.search(r'fn device_features\(&self\).*?VIRTIO_GPU_F_EDID\n    }',gpu,re.S)
for p in ['web/main.js','web/index.html','web/dist/main.js','web/dist/index.html']:assert not re.search(r'(?:import|from).*?(?:renderer/virgl|virgl-shader|virgl-command)',(ROOT/p).read_text())
checks=[]
for cmd in [['node','--check','renderer/virgl-shader/tests/precise-fraction-regressions.mjs'],['git','diff','--check'],['python3','tools/check_task_policy.py']]:
 r=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True);assert r.returncode==0;checks.append({'command':cmd,'exitCode':0,'stdout':r.stdout,'stderr':r.stderr})
result={'schema':'virgl-fraction-critic-final-checks-v1','task':'E6-T12g6g2','status':'passed','cleanup':proofs,'productionGates':gates,'fourthSourceBindings':len(source_map),'checks':checks,'coldPolicy':'Reuse the one authenticated pristine exact-frozen-head proof. Runtime and dependencies did not change; no portability/environment isolation failure occurred. No additional cold clone was needed.','harnessScope':'The 28 hunks/145 added runtime lines have native/V8 execution or static/type/data justification. Added fixture/oracle/recording scripts were exercised by the sealed full acceptance; their deliberate failure/shape-guard branches are evidence validation, not newly admitted shader behavior. No tests were ignored or debug assertions disabled in the task diff.'}
(OUT/'final-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'passed','cleanupRuns':len(proofs),'productionGatesUnchanged':len(gates),'fourthSources':len(source_map)}))
