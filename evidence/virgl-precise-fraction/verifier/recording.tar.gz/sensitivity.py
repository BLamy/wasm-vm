#!/usr/bin/env python3
import hashlib,json,struct
from pathlib import Path
from source_semantics import interpret,word
OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
points=[]
for prefix in ['hot','cold/acceptance']:
 for fault in ['negative','rounding','special']:
  p=OUT/'unpacked'/prefix/('fault-'+fault)/'report.json';raw=p.read_bytes();r=json.loads(raw);a=r['acceptance']
  assert r['status']==a['status']=='failed' and r['browserErrors']=={'console':[],'page':[],'requests':[]} and a['fault']==fault and a['objects']['live']==0
  assert r['browser']['launch']['headless'] is False and 'independent scalar word mismatch' in a['failure']['message']
  expected_sources=[];mutated=[]
  for vi,v in enumerate(a['vertices']):
   mutation=v.get('mutation');source=v['primary']['glsl'] if v['backend']=='mesa' else v['pair']['vertex']['glsl']
   if mutation:
    assert v['op']=='FRC_PRECISE' and v['backend']=='owned' and mutation['original']==source and source.count(mutation['needle'])==1
    assert mutation['served']==source.replace(mutation['needle'],mutation['replacement'],1)
    source=mutation['served'];mutated.append(vi)
   expected_sources.extend([source,v['pair']['fragment']['glsl']])
  assert [e['source'] for e in a['events'] if e['call']=='shaderSource']==expected_sources and len(mutated)==1
  vi=mutated[0];v=a['vertices'][vi];failures=[]
  for xi,x in enumerate(v['vectors']):
   state,ops=interpret(v['text'],{0:[word(p) for p in x['position']]},None,'owned')
   wanted=state['OUT',0]+state['OUT',1]+state['OUT',2];actual=list(struct.unpack('<12I',bytes(x['bytes'])))
   assert sha(bytes(x['bytes']))==x['sha256'] and actual==x['observed']
   wrong=[i for i,(a,b) in enumerate(zip(actual,wanted)) if a not in b]
   if wrong:
    f=x['failure'];assert f['lane'] in wrong and f['actual']==actual[f['lane']] and f['expected'] in wanted[f['lane']]
    failures.append({'vertex':vi,'vector':xi,'input':x['input'],'actualShaderSourceSha256':sha(source.encode()),'captureSha256':x['sha256'],'failure':f,'prediction':[sorted(y) for y in wanted]})
  assert len(failures)==1
  # Trace every GL creation/deletion; a fault must not escape lifetime cleanup.
  live={}
  for e in a['events']:
   if e['call'].startswith('create') or e['call']=='fenceSync':assert e['id'] not in live;live[e['id']]=e['call']
   if e['call'].startswith('delete'):assert e['id'] in live;del live[e['id']]
  assert not live
  points.append({'prefix':prefix,'mode':fault,'path':str(p.relative_to(OUT)),'reportSha256':sha(raw),'objects':a['objects'],'point':failures[0]})
s=json.loads((OUT/'sabotage-regressions.json').read_bytes());assert s['status']=='failed' and s['failure']['counterexample']['name']=='fraction-1-true-bit-0'
c=s['failure']['counterexample'];assert c['source']==0x80000001 and c['expected']==0x3f800000 and c['expectedBit']==0 and c['result']['ok'] is False
capture_good=json.loads((OUT/'independent-capture-regressions.json').read_bytes());capture_bad=json.loads((OUT/'emitted-sabotage-capture-regressions.json').read_bytes())
assert capture_good['status']=='passed' and capture_good['physical']['words']==36096
assert capture_bad['status']=='failed' and capture_bad['failure']['counterexample']['record']==175 and capture_bad['failure']['counterexample']['vector']==0
assert capture_bad['failure']['counterexample']['captureSha256']=='9389931471ca43ba88af7b8bd37a8f8f4bb61a7107ca422d9aad1bd167d9079f'
result={'schema':'virgl-fraction-critic-sensitivity-v1','task':'E6-T12g6g2','status':'passed','physicalFaults':points,'promotedGuardSabotage':{'path':'sabotage-regressions.json','sha256':sha((OUT/'sabotage-regressions.json').read_bytes()),'counterexample':c,'prediction':'FRC_PRECISE(-min-subnormal) is 1.0 with bit 0 clear, hence raw bit output 0 is admitted. Sabotage incorrectly retains min-subnormal, bit 0 becomes unsafe output word 1 and the public result closes.'}}
result['promotedCaptureGuard']={'source':'renderer/virgl-shader/tests/precise-fraction-capture-regressions.mjs','good':{'path':'independent-capture-regressions.json','sha256':sha((OUT/'independent-capture-regressions.json').read_bytes()),'words':36096},'emittedFault':{'path':'emitted-sabotage-capture-regressions.json','sha256':sha((OUT/'emitted-sabotage-capture-regressions.json').read_bytes()),'counterexample':capture_bad['failure']['counterexample']}}
(OUT/'sensitivity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'passed','physicalFaults':len(points),'lanes':[p['point']['failure']['lane'] for p in points],'sabotage':c['name']}))
