#!/usr/bin/env python3
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
verdict=json.loads((OUT/'verdict.json').read_bytes());assert verdict['verdict']=='verified' and verdict['failed']==verdict['needsEvidence']==0
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head==verdict['workerSubmission']
members={}
for p in sorted(OUT.iterdir()):
 if p.is_file() and p.name not in ['manifest.json','records.json','recording.tar.gz'] and p.suffix in ['.json','.py','.mjs','.txt','.log','.stderr','.profraw','.profdata','.diff']:
  members[p.name]=p.read_bytes()
for folder in ['gpu-610839776','node-consumer-coverage']:
 for p in sorted((OUT/folder).rglob('*')):
  if p.is_file():members[str(p.relative_to(OUT))]=p.read_bytes()
for r in verdict['promoted']:
 b=(ROOT/r['path']).read_bytes();assert sha(b)==r['testSha256'];members['promoted/'+Path(r['path']).name]=b
for name,p in [('sabotage/raw_fraction.h',OUT/'sabotage/renderer/virgl-shader/raw_fraction.h'),('sabotage/virgl-shader',OUT/'sabotage/renderer/virgl-shader/build/native/virgl-shader')]:members[name]=p.read_bytes()
index={'schema':'virgl-fraction-critic-records-v1','task':'E6-T12g6g2','sourceHead':head,'runtimeHead':verdict['runtimeHead'],'records':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())]}
idx=(json.dumps(index,indent=2)+'\n').encode();(OUT/'records.json').write_bytes(idx)
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0) as zipped:
 with tarfile.open(fileobj=zipped,mode='w') as tf:
  for name,b in sorted(members.items()):
   t=tarfile.TarInfo(name);t.size=len(b);t.mode=0o644;t.mtime=0;tf.addfile(t,io.BytesIO(b))
arc=buffer.getvalue();(OUT/'recording.tar.gz').write_bytes(arc)
manifest={'schema':'virgl-fraction-critic-seal-v1','task':'E6-T12g6g2','verdict':'verified','sourceHead':head,'runtimeHead':verdict['runtimeHead'],'workerSubmission':verdict['workerSubmission'],'base':verdict['verifiedPredecessor'],'records':len(members),'archive':{'path':'recording.tar.gz','bytes':len(arc),'sha256':sha(arc)},'recordIndex':{'path':'records.json','bytes':len(idx),'sha256':sha(idx)},'verdictRecord':{'path':'verdict.json','bytes':(OUT/'verdict.json').stat().st_size,'sha256':sha((OUT/'verdict.json').read_bytes())},'workerDependencies':verdict['workerSeal'],'priorHeldSeals':verdict['priorHeldSeals'],'promoted':verdict['promoted'],'held':8,'failed':0,'needsEvidence':0,'coverage':verdict['coverage'],'recordedPhysicalWords':775392,'recordedPhysicalPixels':67456,'fourthPhysicalWords':128832,'fourthPhysicalPixels':11072,'productionNegotiation':False,'guestExecution':False}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'status':'sealed','members':len(members),'archive':manifest['archive'],'indexSha256':sha(idx),'verdictSha256':manifest['verdictRecord']['sha256']}))
