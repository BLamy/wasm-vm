#!/usr/bin/env python3
import hashlib,json,re,subprocess,tarfile
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
parent='5ec49cbce92fc809498c601dc5e3a0e165e435ba';head='be4ff41ba8e99047796d9c41e13b34b0965c8e6c';seals=[]
for name in ['virgl-minimum-selection','virgl-scalar-operations','virgl-signed-conversions','virgl-signed-integers','virgl-hex-literals','virgl-compiler-bounds']:
 p=ROOT/'evidence'/name/'verifier';m=json.loads((p/'manifest.json').read_bytes());idx=m.get('recordIndex',m.get('index'));a=(p/m['archive']['path']).read_bytes();i=(p/idx['path']).read_bytes()
 assert len(a)==m['archive']['bytes'] and sha(a)==m['archive']['sha256'];assert sha(i)==idx['sha256'];assert m['verdict']=='verified'
 rows={r['path']:r for r in json.loads(i)['records']};seen=set()
 with tarfile.open(p/m['archive']['path'],'r:gz') as t:
  for f in t.getmembers():
   n=PurePosixPath(f.name);assert f.isfile() and f.name in rows and f.name not in seen and not n.is_absolute() and '..' not in n.parts
   b=t.extractfile(f).read();r=rows[f.name];assert sha(b)==r['sha256'] and len(b)==r['bytes'];seen.add(f.name)
 assert seen==set(rows)
 for suffix in ['manifest.json',m['archive']['path'],idx['path']]:assert git('show',parent+':evidence/'+name+'/verifier/'+suffix)==(p/suffix).read_bytes()
 seals.append({'boundary':name,'manifestSha256':sha((p/'manifest.json').read_bytes()),'archiveSha256':sha(a),'indexSha256':sha(i),'members':len(rows),'verdict':'verified'})
changed=set(git('diff','--name-only',parent,head).decode().splitlines());unchanged=[]
for path in git('ls-files','renderer/virgl-shader','renderer/virgl-command','tools/lib/virgl-browser-runner.mjs','tools/setup-virgl-emsdk.sh').decode().splitlines():
 if path in changed:continue
 assert git('show',parent+':'+path)==(ROOT/path).read_bytes();unchanged.append({'path':path,'sha256':sha((ROOT/path).read_bytes())})
def function(text,name):
 m=re.search(r'^.*\b'+name+r'\([^;]*?\)\n\{',text,re.M);assert m,name
 begin=m.start();at=m.end();depth=1
 while depth:
  if text[at]=='{':depth+=1
  if text[at]=='}':depth-=1
  at+=1
 return text[begin:at]
helpers=[]
for path,names in [('renderer/virgl-shader/raw_bits.c',['ordered_float_mask','equal_float_mask','safe_raw_float','float_mode','output_legal','raw_join','selected','raw_consumed_mask','precise_source','raster_source']),('renderer/virgl-shader/bridge.c',['precise_profile','arithmetic_contract','raster_contract','conversion_contract','scalar_contract','minimum_contract'])]:
 before=git('show',parent+':'+path).decode();after=(ROOT/path).read_text()
 for name in names:
  a=function(before,name);assert a==function(after,name);helpers.append({'path':path,'function':name,'sha256':sha(a.encode())})
prior=ROOT/'evidence/virgl-minimum-selection/worker';prior_m=json.loads((prior/'manifest.json').read_bytes());prior_i=json.loads((prior/'records.json').read_bytes());assert sha((prior/'recording.tar.gz').read_bytes())==prior_m['archive']['sha256'] and sha((prior/'records.json').read_bytes())==prior_m['recordIndex']['sha256']
with tarfile.open(prior/'recording.tar.gz','r:gz') as t:
 old=t.extractfile('hot/retained/report.json').read();r=next(r for r in prior_i['records'] if r['path']=='hot/retained/report.json');assert sha(old)==r['sha256'];retained=json.loads(old)
current=[]
for prefix in ['hot','cold/acceptance']:
 b=OUT/'unpacked'/prefix;r=json.loads((b/'retained/report.json').read_bytes());assert r['originals']==retained['originals'] and r['historical']==retained['historical']
 assert len(r['originals'])==25 and sum(c['native']['ok'] for c in r['originals'])==23 and len(r['historical'])==112 and sum(c['native']['ok'] for c in r['historical'])==5
 guards=[]
 for filename,count,test in [('independent-joins.json',402,'compiler-bounds-joins.mjs'),('independent-hex-guards.json',49,'hex-literal-regressions.mjs'),('independent-signed-guards.json',108,'signed-integer-regressions.mjs'),('independent-conversion-guards.json',1575,'signed-conversion-regressions.mjs'),('independent-scalar-guards.json',1427,'scalar-operation-regressions.mjs'),('independent-minimum-guards.json',4524,'minimum-selection-regressions.mjs')]:
  g=json.loads((b/filename).read_bytes());assert g['status']=='passed' and g['cases']==len(g['native'])==len(g['wasm'])==count
  for a,z in zip(g['native'],g['wasm']):assert a['result']==z['result'] or a['result'].get('error',{}).get('code')==z['result'].get('error',{}).get('code')=='invalid-input'
  path='renderer/virgl-shader/tests/'+test;test_bytes=(ROOT/path).read_bytes();assert git('show',parent+':'+path)==test_bytes
  if g.get('testSha256'):assert g['testSha256']==sha(test_bytes)
  guards.append({'path':filename,'cases':count,'reportSha256':sha((b/filename).read_bytes()),'unchangedTestSha256':sha(test_bytes)})
 current.append({'prefix':prefix,'retainedOriginals':25,'retainedAdmissions':23,'historical':112,'historicalAdmissions':5,'guards':guards})
result={'schema':'virgl-fraction-critic-carry-v1','task':'E6-T12g6g2','status':'passed','parent':parent,'submission':head,'priorHeldSeals':seals,'unchangedDependencies':unchanged,'unchangedHelpers':helpers,'currentRecordedGuards':current,'policy':'Unchanged source, dependency and evidence digests preserve prior HELD results. Changed parser/dispatcher and fraction wrapper have fresh current proof; inherited result compatibility is independently re-executed against the sealed predecessor.'}
(OUT/'carry-forward.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'passed','priorSeals':len(seals),'unchangedDependencies':len(unchanged),'unchangedHelpers':len(helpers)}))
