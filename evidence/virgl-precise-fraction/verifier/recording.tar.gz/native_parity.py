#!/usr/bin/env python3
import hashlib,json,re,struct,subprocess,tarfile
from pathlib import Path
from source_semantics import fraction
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
unpack=OUT/'unpacked';reports=[]
parentdir=ROOT/'evidence/virgl-minimum-selection/worker';m=json.loads((parentdir/'manifest.json').read_bytes());i=json.loads((parentdir/'records.json').read_bytes());row=next(r for r in i['records'] if r['path']=='generated/native/virgl-shader')
with tarfile.open(parentdir/'recording.tar.gz','r:gz') as t:b=t.extractfile(row['path']).read();assert sha(b)==row['sha256']
parent=OUT/'recorded-parent-native';parent.write_bytes(b);parent.chmod(0o700)
def translate(binary,stage,text):return json.loads(subprocess.check_output([str(binary),stage],input=text.encode()))
for name,prefix,gen in [('hot','hot','generated'),('cold','cold/acceptance','cold-generated')]:
 base=unpack/prefix;native=json.loads((base/'native/report.json').read_bytes());wasm=json.loads((base/'wasm/report.json').read_bytes());fixture=(base/'native/cases.bin').read_bytes();at=4;assert fixture[:4]==b'VFR1'
 def u():
  global at
  n=struct.unpack_from('<I',fixture,at)[0];at+=4;return n
 count=u();assert count==len(native['helperWords'])==7968;points=[]
 for index in range(count):
  word,expected=u(),u();truth=fraction(word);actual=native['helperWords'][index];assert expected==truth and actual=={'index':index,'word':word,'expected':truth,'actual':truth}
  if word in [0,0x80000000,1,0x80000001,0xb3000000,0xb3000001,0xbf7fffff,0xbf800001,0x3f800001,0x7f800000]:points.append({'nativeLogLine':index+1,**actual})
 request_count=u();assert request_count==len(native['cases'])==len(wasm['cases'])==len(wasm['pairs'])==1919
 binary=unpack/gen/'native/virgl-shader';binary.chmod(0o700);rows=[]
 for index,c in enumerate(native['cases']):
  stage,expected,primary,bytes_count=u(),u(),u(),u();text=fixture[at:at+bytes_count].decode();at+=bytes_count
  assert stage==(0 if c['stage']=='vertex' else 1) and expected==c['ok'] and primary==c['primary'] and text==c['text'] and sha(text.encode())==c['textSha256']
  actual=translate(binary,c['stage'],text);assert actual==c['result']==wasm['cases'][index]['result'];assert wasm['pairs'][index]['result']['ok']==bool(expected)
  if not expected:assert not any(k in actual for k in ['glsl','metadata']) and not any(k in wasm['pairs'][index]['result'] for k in ['vertex','fragment','metadata'])
  if primary:
   ops=[]
   for line in text.splitlines():
    r=re.match(r'\s*(?:\d+:\s*)?(FRC(?:_PRECISE)?)\s+(?:OUT|TEMP)\[\d+\](?:\.([xyzw]+))?,',line)
    if r:ops.append({'opcode':r[1],'sourceType':4,'destinationType':4,'mask':sum(1<<'xyzw'.index(x) for x in (r[2] or 'xyzw'))})
   assert ops==c['primaryResult']['fractionInstructions'],c['name']
  rows.append({'index':index,'name':c['name'],'textSha256':c['textSha256'],'ok':actual['ok'],'completeResponseSha256':sha(json.dumps(actual,sort_keys=True,separators=(',',':')).encode())})
 assert at==len(fixture)
 legacy=json.loads((base/'legacy.json').read_bytes());ledger=json.loads((ROOT/'tools/virgl-precise-fraction/legacy-migrations.json').read_bytes());migrations=[]
 for c in legacy['cases']:
  observed=translate(binary,c['stage'],c['text']);prior=translate(parent,c['stage'],c['text']);added=translate(binary,c['stage'],c['fractionText']);assert observed==c['old'] and prior==c['parent'] and added==c['added']
  if c['migration']:
   assert c['migration'] in ledger and sha(c['text'].encode())==c['migration']['inputSha256'] and prior['ok'] is False and observed['ok'] is True;migrations.append(c['name'])
  else:assert observed==prior,c['name']
 assert len(legacy['cases'])==1014 and migrations==[r['name'] for r in ledger]
 reports.append({'name':name,'binarySha256':sha(binary.read_bytes()),'fixtureSha256':sha(fixture),'helperPredictions':count,'primaryComparisons':1897,'requests':request_count,'anchorPoints':points,'requestResponses':rows,'legacyResponses':len(legacy['cases']),'migrations':migrations})
(OUT/'native-source-parity.json').write_text(json.dumps({'schema':'virgl-fraction-critic-native-parity-v1','task':'E6-T12g6g2','status':'passed','parentBinarySha256':sha(b),'reports':reports},indent=2)+'\n');print(json.dumps({'status':'passed','helperPredictions':15936,'nativeRequests':3838,'legacyResponses':2028,'exactMigrations':len(migrations)}))
