#!/usr/bin/env python3
import hashlib,json,os,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
records=[]
for name,prefix,generated in [('hot','hot','generated'),('cold','cold/acceptance','cold-generated')]:
 base=OUT/'unpacked'/prefix; binary=OUT/'unpacked'/generated/'precise-fraction-sanitize/precise-fraction-test'; binary.chmod(0o700)
 env=dict(os.environ,LLVM_PROFILE_FILE=str(OUT/(name+'-replay.profraw')),ASAN_OPTIONS='abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
 for key in ['RUSTFLAGS','RUST_LOG','NODE_OPTIONS','DYLD_INSERT_LIBRARIES']:env.pop(key,None)
 with (base/'native/cases.bin').open('rb') as inp,(OUT/(name+'-native-replay.log')).open('wb') as log,(OUT/(name+'-native-replay.stderr')).open('wb') as err:
  run=subprocess.run([str(binary)],input=None,stdin=inp,stdout=log,stderr=err,env=env)
 assert run.returncode==0,(name,run.returncode)
 log=(OUT/(name+'-native-replay.log')).read_bytes();err=(OUT/(name+'-native-replay.stderr')).read_bytes()
 assert not err and log==(base/'native/native.log').read_bytes(),name
 # Coverage authority is the original recording's exact archived binary and
 # profile, not the newly generated replay profile nor a local rebuild.
 merged=base/'native/native.profdata'
 exported=subprocess.check_output(['xcrun','llvm-cov','export',str(binary),'-instr-profile='+str(merged)])
 cov=json.loads(exported)
 for data in cov['data']:
  data['files']=[f for f in data['files'] if f['filename'].endswith(('/bridge.c','/raw_bits.c','/raw_fraction.h','/native_tests/precise_fraction.c'))]
  data['functions']=[f for f in data['functions'] if any(p.endswith(('/bridge.c','/raw_bits.c','/raw_fraction.h','/native_tests/precise_fraction.c')) for p in f['filenames'])]
 recorded=json.loads((base/'native/coverage.json').read_bytes());assert cov==recorded,name+' original coverage export must be exact'
 (OUT/(name+'-coverage-export.json')).write_text(json.dumps(cov,indent=2)+'\n')
 # Independently merge the actual original profraw, proving the sealed profdata
 # binds these raw execution counts as well.
 fresh=OUT/(name+'-recorded-merged.profdata')
 subprocess.run(['xcrun','llvm-profdata','merge','-sparse',str(base/'native/native.profraw'),'-o',str(fresh)],check=True)
 check=json.loads(subprocess.check_output(['xcrun','llvm-cov','export',str(binary),'-instr-profile='+str(fresh)]))
 for data in check['data']:
  data['files']=[f for f in data['files'] if f['filename'].endswith(('/bridge.c','/raw_bits.c','/raw_fraction.h','/native_tests/precise_fraction.c'))]
  data['functions']=[f for f in data['functions'] if any(p.endswith(('/bridge.c','/raw_bits.c','/raw_fraction.h','/native_tests/precise_fraction.c')) for p in f['filenames'])]
 assert check==recorded,name+' raw profile binding'
 records.append({'name':name,'binary':str(binary.relative_to(OUT)),'binarySha256':sha(binary.read_bytes()),'fixtureSha256':sha((base/'native/cases.bin').read_bytes()),'replayLogSha256':sha(log),'recordedProfileSha256':sha(merged.read_bytes()),'recordedRawProfileSha256':sha((base/'native/native.profraw').read_bytes()),'coverageSha256':sha((base/'native/coverage.json').read_bytes()),'exit':run.returncode,'stderrBytes':len(err),'exactTranscript':True,'exactProfileExport':True})
(OUT/'native-replays.json').write_text(json.dumps({'status':'passed','task':'E6-T12g6g2','replays':records},indent=2)+'\n')
print(json.dumps({'status':'passed','replayed':len(records),'binaryHashes':[r['binarySha256'] for r in records]}))
