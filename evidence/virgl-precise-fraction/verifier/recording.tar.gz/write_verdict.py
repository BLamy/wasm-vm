#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads((OUT/p).read_bytes())
pred=load('predictions.json');outcomes=[]
evidence={
 'P1':('authentication.json','95 unique regular members match the index, archive and cited digests; hot/cold 243/236 sources bind unchanged frozen runtime to submission. Original exact-head cold clone was pristine and scrubbed.'),
 'P2':('native-source-parity.json','Independent integer-scale rational equation confirms 15,936 helper predictions and literal predeclared anchors, including -minimum-subnormal => 0x3f800000 at hot/cold native/native.log:4 and -2^-25 => 0x3f800000 at line 10. Every complete archived native response matches Wasm.'),
 'P3':('consumer-attacks.json','17 distinct authentic contracts survive; 1,118 independent hostile metadata mutations close without invoking an accessor. 13 banks preserve ownership, range and whole-prefix checks; private unknown/output/F2I predictions hold in the promoted 4,469-case guard.'),
 'P4':('independent-regressions.json','All 4,469 native/Wasm word-bit, negation, mask/swizzle, alias, killed/saved version, conditional, malformed syntax and no-new-range predictions hold. Native token replay checks all 1,897 actual FLOAT/FLOAT unary FRC primary conversions and masks per recording.'),
 'P5':('carry-forward.json','Six verified critic seals, 247 byte-identical dependencies and 16 unchanged helpers are carried forward. Independent native/legacy replay preserves 1,014 complete predecessor responses per recording except exactly the two digest-ledger migrations; current retained original/historical partitions remain 23/25 and 5/112. Seven production gate files remain byte-identical.'),
 'P6':('source-semantics.json','Independent TGSI source interpretation confirms all six sealed recordings: 775,392 words and 67,456 pixels. Exact actual shaderSource sequences, GL compile/link status and reflection, attributes, banks, indexed geometry, source-dependent pixels, async waiting-index plans, closed hostile draws and zero GL/resource lifetimes bind the observations. Fourth physical seed separately confirms 128,832 words and 11,072 pixels.'),
 'P7':('coverage-audit.json','Actual archived hot/cold ASan/UBSan binaries replay with byte-identical transcripts and no diagnostics. Re-exporting their original raw/merged profiles is exact. All 36 helper lines, 32 branches and 81 regions are covered; 28 runtime hunks/145 added lines have positive LLVM/V8 counts or explicit static/type/source-data justification, with zero proof gaps or dead hunks.'),
 'P8':('sensitivity.json','Independent seed 324,508,637 and physical seed 610,839,776 hold. The native promotion detects deleted negative complement at fraction-1-true-bit-0. The permanent capture promotion independently confirms 36,096 private words and refutes the real emitted negative-complement fault at record 175/vector 0, carrier lane 7, capture 9389931471ca43ba88af7b8bd37a8f8f4bb61a7107ca422d9aad1bd167d9079f. All six sealed physical faults contradict concrete words (lanes 7/5/6) and dispose objects.')
}
for p in pred['predictions']:
 path,note=evidence[p['id']];outcomes.append({**p,'result':'HELD','observation':note,'evidence':{'path':path,'bytes':(OUT/path).stat().st_size,'sha256':sha((OUT/path).read_bytes())}})
commands=[
 ['python3','evidence/virgl-precise-fraction/verifier/authenticate.py'],
 ['python3','evidence/virgl-precise-fraction/verifier/replay.py'],
 ['python3','evidence/virgl-precise-fraction/verifier/native_parity.py'],
 ['python3','evidence/virgl-precise-fraction/verifier/source_semantics.py'],
 ['node','tools/virgl-precise-fraction/browser.mjs','--output','evidence/virgl-precise-fraction/verifier/gpu-610839776','--seed','610839776'],
 ['python3','evidence/virgl-precise-fraction/verifier/source_semantics.py','--fourth'],
 ['node','renderer/virgl-shader/tests/precise-fraction-regressions.mjs','--native','evidence/virgl-precise-fraction/verifier/unpacked/generated/native/virgl-shader','--output','evidence/virgl-precise-fraction/verifier/independent-regressions.json'],
 ['node','renderer/virgl-shader/tests/precise-fraction-capture-regressions.mjs','--report','evidence/virgl-precise-fraction/verifier/gpu-610839776/report.json','--output','evidence/virgl-precise-fraction/verifier/independent-capture-regressions.json'],
 ['node','renderer/virgl-shader/tests/precise-fraction-regressions.mjs','--native','evidence/virgl-precise-fraction/verifier/sabotage/renderer/virgl-shader/build/native/virgl-shader','--native-only','--output','evidence/virgl-precise-fraction/verifier/sabotage-regressions.json'],
 ['node','renderer/virgl-shader/tests/precise-fraction-capture-regressions.mjs','--report','evidence/virgl-precise-fraction/verifier/unpacked/hot/fault-negative/report.json','--output','evidence/virgl-precise-fraction/verifier/emitted-sabotage-capture-regressions.json'],
 ['node','evidence/virgl-precise-fraction/verifier/consumer_attacks.mjs'],
 ['python3','evidence/virgl-precise-fraction/verifier/coverage_audit.py'],
 ['python3','evidence/virgl-precise-fraction/verifier/carry_forward.py'],
 ['python3','evidence/virgl-precise-fraction/verifier/sensitivity.py'],
 ['python3','evidence/virgl-precise-fraction/verifier/final_audits.py']
]
promoted=[]
for file,report,key,count in [('precise-fraction-regressions.mjs','independent-regressions.json','cases',4469),('precise-fraction-capture-regressions.mjs','independent-capture-regressions.json','physicalWords',36096)]:
 path='renderer/virgl-shader/tests/'+file;r=load(report);assert r['status']=='passed';promoted.append({'path':path,'testSha256':sha((ROOT/path).read_bytes()),key:count,'report':report,'reportSha256':sha((OUT/report).read_bytes()),'schema':r['schema']})
result={'schema':'virgl-fraction-critic-verdict-v1','task':'E6-T12g6g2','verdict':'verified','runtimeHead':pred['frozenHead'],'workerSubmission':pred['submission'],'verifiedPredecessor':pred['verifiedPredecessor'],'held':8,'failed':0,'needsEvidence':0,'predictions':outcomes,'commands':commands,'promoted':promoted,'coverage':{'hunks':28,'addedRuntimeLines':145,'needsEvidence':0,'dead':0},'workerSeal':{'manifestSha256':sha((OUT.parent/'worker/manifest.json').read_bytes()),'archiveSha256':sha((OUT.parent/'worker/recording.tar.gz').read_bytes()),'indexSha256':sha((OUT.parent/'worker/records.json').read_bytes())},'priorHeldSeals':load('carry-forward.json')['priorHeldSeals'],'recordedPhysicalWords':775392,'recordedPhysicalPixels':67456,'fourthPhysicalWords':128832,'fourthPhysicalPixels':11072,'productionNegotiation':False,'guestExecution':False,'residualLimits':['Isolated instruction-local compiler and consumer boundary; no guest offload, full compositor admission, throughput/FPS/MIPS or production deployment claim.','Actual Apple M4 Max hardware proves the captured route. Other hardware is outside this bounded claim.','The two complete original shaders remain rejected.','Permanent promotions are recorded and committed here; the next saturation acceptance target will carry both guards forward. Frozen worker target/receipt are unchanged.'],'coldClone':'Authenticated one pristine exact-head proof carried forward unchanged; not repeated.','criticRepairs':['The inherited source interpreter was extended for the newly present UADD operation before running the complete audit.','The fault-source binder was corrected to use primary Mesa sources for preceding Mesa records; this was an auditor script correction, not a program refutation.']}
(OUT/'verdict.json').write_text(json.dumps(result,indent=2)+'\n');print('VERDICT: verified\n8 HELD; 0 FAILED; 0 NEEDS EVIDENCE')
