import gzip,hashlib,json,pathlib,struct
ROOT=pathlib.Path.cwd();OUT=ROOT/'evidence/virgl-dimensional-shaders/verifier';sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_bytes());prediction=load(OUT/'novel-prediction.json');expected=bytes.fromhex(prediction['fixedExpectedBytes']);assert len(expected)==16
results=[]
for name in ['novel-3141592653','novel-2718281829','novel-1414213562','promoted','novel-sabotage']:
 p=OUT/name;report=load(p/'report.json');a=report['acceptance'];assert report['browserErrors']==dict(console=[],page=[],requests=[]);assert not report['browser']['launch']['headless'];assert report['browser']['gpu']['featureStatus'][report['browser']['webglFeature']]=='enabled';assert 'Metal'in a['renderer'] and 'Apple M4 Max'in a['renderer'];assert a['cleaned'] and not a['productionNegotiation'] and not a['guestExecution'];bodies={}
 for blob in a['blobs']:
  z=(p/blob['path']).read_bytes();body=gzip.decompress(z);assert sha(z)==blob['gzipSha256'] and sha(body)==blob['sha256'] and len(body)==blob['bytes'];assert blob['key'] not in bodies;bodies[blob['key']]=body
 assert a['expectedWords']==prediction['fixedExpectedWords'];assert a['request']['vertexText']==load(OUT/'novel-3141592653/report.json')['acceptance']['request']['vertexText'];events=a['events'];completion=a['completion'];ids=[completion['writer'],completion['created'],completion['consumed'],a['readEvent']];assert ids==sorted(set(ids));assert [events[x]['method'] for x in ids]==['drawArrays','fenceSync','clientWaitSync','readPixels'];assert events[ids[2]]['result'] in [37146,37148];assert events[ids[1]]['result']['handle']==events[ids[2]]['args'][0]['handle'];assert all(e['result']==0 for e in events if e['method']=='getError')
 actual=bodies[events[a['readEvent']]['after'][-1]['key']];assert actual==struct.pack('<4I',*a['actualWords']);matches=actual==expected;assert matches==(name!='novel-sabotage')and matches==a['matches'];assert report['status']==('passed' if matches else 'failed')
 assert {(r['name'],r['value']) for r in a['reflection']}=={('vssamp7',6),('fssamp7',9),('vssamplevels7',3),('fssamplevels7',2)}
 for u in a['uploads']:
  vertex=u['stage']=='vertex';l=u['level'];w=max(1,(5 if vertex else 3)>>l);h=max(1,(3 if vertex else 5)>>l);d=max(1,7>>l)if vertex else 4
  assert (u['width'],u['height'],u['layers'])==(w,h,d);words=[]
  for z in range(d):
   for y in range(h):
    for x in range(w):
     for k in range(4):words.append((0xe0000000+l*0x10000+z*0x1000+y*0x100+x*4+k)if vertex else(-(0x1000000+l*0x10000+z*0x1000+y*0x100+x*4+k))&0xffffffff)
  original=struct.pack('<'+'I'*len(words),*words);assert bodies[u['originalKey']]==original;uploaded=bodies[events[u['event']]['args'][-1]['key']]
  if name=='novel-sabotage'and not vertex:
   plane=w*h*16;assert u['swappedLayers']==[0,d-1];assert uploaded==original[-plane:]+original[plane:-plane]+original[:plane]
  else:assert uploaded==original and not u['swappedLayers']
 results.append(dict(name=name,status=report['status'],seed=a['seed'],readEvent=ids[3],completion=completion,expectedWords=a['expectedWords'],actualWords=a['actualWords'],expectedSha256=sha(expected),actualSha256=sha(actual),completeBlobs=len(bodies),reportSha256=sha((p/'report.json').read_bytes()),oracleFailure=not matches,cleaned=True,errors=[]))
source=ROOT/'tools/virgl-dimensional-shaders/stage-isolation-test.mjs';sourceSha=sha(source.read_bytes());assert all(any(s['path']=='tools/virgl-dimensional-shaders/stage-isolation-test.mjs'and s['sha256']==sourceSha for s in load(OUT/r['name']/'report.json')['sources'])for r in results)
(OUT/'novel-audit.json').write_text(json.dumps(dict(status='passed',prediction=prediction,unchangedOracleSourceSha256=sourceSha,results=results),indent=2)+'\n');print(json.dumps(dict(status='passed',schedules=4,physicalSabotage='refuted',checkedPlaneBytes=16,sourceSha256=sourceSha)))
