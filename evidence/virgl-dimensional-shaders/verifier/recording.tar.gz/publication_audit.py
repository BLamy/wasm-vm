import hashlib,json,pathlib,subprocess,tarfile
ROOT=pathlib.Path.cwd();OUT=ROOT/'evidence/virgl-dimensional-shaders/verifier';P=OUT/'publication';COLD=pathlib.Path('/tmp/wasmvm-dimensional-shaders-cold-ebd460b3/recording');FREEZE='ebd460b325f5a3b97798a9450ab3c7f879b9ca26';BASE='48b2ba0c7ee90d13093f7782e5a2502e44095753';sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_bytes())
i=load(P/'publication/staging-index.json');assert i['head']==FREEZE and i['fileCount']==304 and i['bytes']==66437568;assert sha((P/'publication/staging-index.json').read_bytes())=='474738c0b03a2974247a260479f3cd959de3fe0f6e0a69e2c9dd48814893f619';assert sha((P/'publication/frozen-web-dist.tar').read_bytes())==i['sourceArchiveSha256'];pins={r['path']:r for r in i['records']};assert len(pins)==304;assert all(r['bytes']<25*1024*1024 for r in pins.values())
# Only two delivered files changed from the independently held default bundle.
changes=subprocess.check_output(['git','diff','--name-only',BASE,FREEZE,'--','web/dist'],cwd=ROOT,text=True).splitlines();assert changes==['web/dist/roadmap.js','web/dist/sw.js']
frozen={}
with tarfile.open(P/'publication/frozen-web-dist.tar')as t:
 for m in t:
  if m.isfile():
   assert m.name.startswith('web/dist/');name=m.name.removeprefix('web/dist/');body=t.extractfile(m).read();frozen[name]=body
   tracked=subprocess.check_output(['git','cat-file','-e',FREEZE+':web/dist/'+name],cwd=ROOT,stderr=subprocess.DEVNULL) if False else None
   try:gitbody=subprocess.check_output(['git','show',FREEZE+':web/dist/'+name],cwd=ROOT,stderr=subprocess.DEVNULL)
   except subprocess.CalledProcessError:continue
   assert body==gitbody
api=load(P/'publication/wasmvm-dimensional-shader-cloudflare-success.json');assert api['id']=='96df17e7-0547-4890-9078-b4a397452eae'and api['latest_stage']['status']=='success'and api['environment']=='production';assert api['deployment_trigger']['metadata']['commit_hash']==FREEZE
checks=[]
for where,report in [('built',load(COLD/'default-demo/report.json')),('canonical-live',load(P/'live/report.json'))]:
 assert report['gitHead']==FREEZE and report['status']=='passed' and report['passed']==127 and report['failed']==0 and not report['errors'];assert report['proofExportAbsent'] and report['graphicsRoadmapPip']=='cap-pip partial' and report['roadmapPip']=='cap-pip live';assert report['servedWasmSha256']=='8b49c7912ff6ce0157552dfa01b8649d7cce81287fdd31f4e7a6506d14a1e308'
 if where=='canonical-live':
  assert report['url'].startswith('https://wasm-vm.pages.dev/app.html?')and not report['httpErrors']
  assert sha((P/'live/report.json').read_bytes())=='9c2131ca6614bb8052638a9099a3ac21bb9d84d62953afc294de73df99a9425e'
  for r in report['served']:
   body=(P/'live/bodies'/r['path'].lstrip('/')).read_bytes();assert len(body)==r['bytes']and sha(body)==r['sha256']
   name=r['path'].lstrip('/');name='app.html'if name=='app'else name
   assert r['sha256']==pins[name]['sha256'],name
  screenshot=P/'live'/report['screenshot']['path']
 else:screenshot=COLD/'default-demo'/report['screenshot']['path']
 assert sha(screenshot.read_bytes())==report['screenshot']['sha256'];checks.append(dict(where=where,passed=127,failed=0,errors=[],proofExports=False,graphicsStatus='partial',httpBodies=len(report['served']),wasmSha256=report['servedWasmSha256']))
roadmap=frozen['roadmap.js'];assert b'original typed volume, cube and array shader compilation (E6-T11d57); production acceleration disabled'in roadmap
# Original default negotiation remains unchanged in held consumer/Rust/source bytes.
assert not subprocess.check_output(['git','diff','--name-only',BASE,FREEZE,'--','crates','renderer/virgl-command','web/main.js','web/linux-worker.js'],cwd=ROOT)
result=dict(status='passed',checks=checks,stagingFiles=304,stagingBytes=i['bytes'],changedDefaultFiles=changes,api=api,workerColdExactHead=FREEZE,proofOfProductionOffload=False,heldConsumerAuthority=False)
(OUT/'publication-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status='passed',built='127/0',canonicalLive='127/0',stagingFiles=304,disabledProduction=True)))
