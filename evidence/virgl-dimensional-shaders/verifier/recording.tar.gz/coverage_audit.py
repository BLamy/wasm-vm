import hashlib,json,pathlib,re,subprocess
ROOT=pathlib.Path.cwd();OUT=ROOT/'evidence/virgl-dimensional-shaders/verifier';COLD=pathlib.Path('/tmp/wasmvm-dimensional-shaders-cold-ebd460b3/recording');CLONE=pathlib.Path('/var/folders/nr/cyvk1qc14jj5c081vj1xts000000gn/T/wasm-vm-dimensional-shaders-cold-9y9mvjdz/repo').resolve();BASE='48b2ba0c7ee90d13093f7782e5a2502e44095753';HEAD='f880e934b9278af86c1f28f3d05d34c581b5bf9f'
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_bytes())
paths=['renderer/virgl-shader/'+n for n in ['standard.mjs','bridge.c','standard_emit.c','standard_guard.c','standard_guard.h']];added={};name=None;line=0
patch=subprocess.check_output(['git','diff','--unified=0',BASE,HEAD,'--',*paths],text=True);(OUT/'runtime.diff').write_text(patch)
for row in patch.splitlines():
 if row.startswith('+++ b/'):name=row[6:]
 elif row.startswith('@@'):line=int(re.search(r'\+(\d+)',row)[1])
 elif row.startswith('+') and name:added.setdefault(name,[]).append(line);line+=1
 elif row.startswith(' '):line+=1
native=[];branches=[]
for mode in ['matrix','allocations']:
 p=OUT/('reexport-'+mode+'.json');assert p.read_bytes()==(COLD/('coverage/'+mode+'.json')).read_bytes(),'LLVM reexport changed'
 for fn in load(p)['data'][0]['functions']:
  filenames=[pathlib.Path(n).resolve() for n in fn['filenames']]
  if any(n.is_relative_to(CLONE) and n.relative_to(CLONE).as_posix() in added for n in filenames):
   native.append({'record':p.name,**fn})
   for b in fn['branches']:
    if filenames[b[6]].is_relative_to(CLONE):
     source=filenames[b[6]].relative_to(CLONE).as_posix()
     if source in added and any(b[0]<=l<=b[2] for l in added[source]):branches.append(dict(record=p.name,function=fn['name'],source=source,branch=b))
scripts=[]
for p in COLD.rglob('browser-coverage.json'):
 if '/fault-' in str(p):continue
 report=load(p.parent/'report.json');assert report['browserCoverage']['sha256']==sha(p.read_bytes())
 for s in load(p)['scripts']:
  if s['source'] in added:
   assert s['sha256']==sha((ROOT/s['source']).read_bytes());scripts.append(dict(record=p.relative_to(COLD).as_posix(),**s))
for p in (COLD/'node-coverage').glob('coverage-*.json'):
 for s in load(p)['result']:
  if s['url'].startswith(CLONE.as_uri()+'/'):
   name=s['url'][len(CLONE.as_uri())+1:]
   if name in added:scripts.append(dict(source=name,sha256=sha((ROOT/name).read_bytes()),record=p.relative_to(COLD).as_posix(),coverage=s))
partitions=[];waivers=[]
for name,lines in added.items():
 js=name.endswith('.mjs');source=(ROOT/name).read_text();offsets=[0]
 for line in source.splitlines(keepends=True):offsets.append(offsets[-1]+(len(line.encode('utf-16-le'))//2 if js else len(line)))
 scopes=[]
 if js:
  for script in scripts:
   if script['source']!=name:continue
   scopes.append(dict(record=script['record'],function='V8',regions=[dict(start=r['startOffset'],end=r['endOffset'],count=r['count']) for fn in script['coverage']['functions'] for r in fn['ranges']]))
 else:
  for fn in native:
   regions=[]
   for r in fn['regions']:
    if r[7]!=0 or pathlib.Path(fn['filenames'][r[5]]).resolve()!=CLONE/name:continue
    a=offsets[r[0]-1]+r[1]-1;b=offsets[r[2]-1]+r[3]-1
    if a<b:regions.append(dict(start=a,end=b,count=r[4],raw=r))
   if regions:scopes.append(dict(record=fn['record'],function=fn['name'],regions=regions))
 for l in lines:
  start,end=offsets[l-1:l+1];points={start,end}
  for scope in scopes:
   for r in scope['regions']:
    for t in [r['start'],r['end']]:
     if start<t<end:points.add(t)
  points=sorted(points)
  for a,b in zip(points,points[1:]):
   text=source[a:b]
   if not text.strip() and not js:continue
   counters=[]
   for scope in scopes:
    containing=[r for r in scope['regions'] if r['start']<=a and b<=r['end']]
    if containing:
     innermost=min(containing,key=lambda r:(r['end']-r['start'],r['count']));counters.append(dict(record=scope['record'],function=scope['function'],**innermost))
   if counters:
    best=max(c['count'] for c in counters);assert best>0,(name,l,text)
    partitions.append(dict(source=name,line=l,start=a,end=b,text=text,maxCount=best,allInnermostCounters=counters))
   else:
    assert not js;assert name.endswith('.h') and l in [21,38,48] or 'const char *' in text or 'bool ' in text or 'uint32_t ' in text or not text.strip('{}() ;\n'),(name,l,text)
    waivers.append(dict(source=name,line=l,text=text,reason='C type/signature/declaration; direct new stage/pair ABI and actual typed sampler reflection exercise its uses.'))
countjs=sum(p['source'].endswith('.mjs') for p in partitions);countnative=len(partitions)-countjs;assert (countjs,countnative,len(waivers))==(29,251,16)
static=[dict(source='renderer/virgl-shader/standard_guard.h',lines=list(range(76,82)),reason='Static typed sampler lookup entries have no executable initialization; all nine dimension/return values are independently checked and physically reflected in every schedule.')]
# Every submission hunk is assigned concrete authority, not left implicit.
files=subprocess.check_output(['git','diff','--name-only',BASE,HEAD],text=True).splitlines();hunks=[]
for name in files:
 diff=subprocess.check_output(['git','diff','--unified=0',BASE,HEAD,'--',name],text=True);headers=re.findall(r'^@@.*$',diff,re.M)
 if name in paths:kind='executed';reason='Every changed LLVM/V8 innermost runtime partition positive; static declarations recorded individually above.'
 elif name=='renderer/virgl-shader/bridge.h':kind='waived';reason='C declarations; actual stage/pair linkage and invalid/null ABI exercised by native/sanitized/Wasm matrix.'
 elif name=='renderer/virgl-shader/build.sh':kind='executed';reason='Frozen receipt native/sanitized/allocation/Wasm/stack build commands; exported functions used on actual Wasm.'
 elif '/native_tests/' in name:kind='executed';reason='Complete 11580 native/sanitized output bodies plus 213 genuine failures, exact recovery and all5 source-mutation modes.'
 elif name=='renderer/virgl-shader/tests/standard-dimensional-texture-browser.mjs':kind='executed';reason='Three396-plane schedules plus wrong-layer physical sabotage execute assertions, cleanup and failure catch; complete native event/blobs retained.'
 elif name.startswith('tools/virgl-dimensional-shaders/') or name=='tools/verify-virgl-default-demo.mjs' or name=='Makefile':kind='executed';reason='Recorded acceptance/cold37 commands, pristine receipt, complete seals, and saved successful/failing browser results; constant fixtures directly interrogated from raw inputs.'
 elif name.startswith('web/'):kind='executed';reason='Frozen committed dist/source pins, built127/0 and canonical live HTTP bodies/screenshot; service worker version is a deterministic static cache key.'
 elif name.startswith('evidence/'):kind='waived';reason='Evidence recording/index/manifest data; every complete archive body authenticated and reopened.'
 elif name.startswith('tasks/'):kind='waived';reason='Lifecycle/queue and scope documentation metadata; no runtime behavior.'
 else:raise AssertionError(name)
 for h in headers or ['binary or added-data body']:hunks.append(dict(source=name,hunk=h,classification=kind,reason=reason))
result=dict(status='passed',base=BASE,submission=HEAD,cloneCanonical=str(CLONE),javascriptPartitions=countjs,nativePartitions=countnative,uncovered=[],declarationWaivers=waivers,staticLookupWaivers=static,partitions=partitions,branches=branches,fullRawNative=native,fullRawV8=scripts,changedFiles=len(files),hunks=hunks,unchangedHeldBoundaries=['crates','renderer/virgl-command','tools/guest','original compiler behavior over7163 identical responses'])
(OUT/'coverage-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k in ['status','javascriptPartitions','nativePartitions','uncovered','changedFiles']}))
