import gzip,hashlib,json,math,pathlib,re,struct,subprocess
ROOT=pathlib.Path.cwd();OUT=ROOT/'evidence/virgl-dimensional-shaders/verifier';COLD=pathlib.Path('/tmp/wasmvm-dimensional-shaders-cold-ebd460b3/recording')
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_bytes())
rows=lambda p:[json.loads(line) for line in p.read_text().splitlines()]
header=(ROOT/'renderer/virgl-shader/vendor/src/gallium/include/pipe/p_shader_tokens.h').read_text()
def enums(name):
 text=re.search(r'enum '+name+r'\s*\{(.*?)\};',header,re.S)[1]; text=re.sub(r'/\*.*?\*/','',text,flags=re.S);n=0;out={}
 for piece in text.split(','):
  m=re.match(r'\s*(\w+)(?:\s*=\s*(\d+))?',piece)
  if m:
   if m[2]:n=int(m[2])
   out[m[1]]=n;n+=1
 return out
files=enums('tgsi_file_type');opcodes=enums('tgsi_opcode');types=enums('tgsi_texture_type');returns=enums('tgsi_return_type')
signed16=lambda x:x-65536 if x&32768 else x

def decode(raw):
 assert (raw[0]&255)+(raw[0]>>8)==len(raw);pos=raw[0]&255;inst=0;views=[];textures=[];immediates=[]
 while pos<len(raw):
  w=raw[pos];kind=w&15;length=(w>>4)&(16383 if kind==1 else 511 if kind==2 else 255);length+=int(kind==2);assert length>0 and pos+length<=len(raw)
  if kind==0 and (w>>12)&15==files['TGSI_FILE_SAMPLER_VIEW']:
   assert length==3;r,v=raw[pos+1:pos+3];views.append({'first':r&65535,'last':r>>16,'target':v&255,'returnTypes':[(v>>(8+6*i))&63 for i in range(4)]})
  if kind==1:
   assert length==5;immediates.append({'index':len(immediates),'type':(w>>18)&15,'words':raw[pos+1:pos+5]})
  if kind==2:
   texture=(w>>29)&1
   if texture:
    assert ((w>>28)&1)==0 and ((w>>30)&1)==0
    t=raw[pos+1];assert ((t>>8)&15)==0;nd=(w>>22)&3;ns=(w>>24)&15;assert nd==1;d=raw[pos+2];assert d&((1<<8)|(1<<9))==0
    sources=[];at=pos+3
    for i in range(ns):
     s=raw[at];at+=1;indirect=(s>>4)&1;dim=(s>>5)&1;assert not indirect;slot=0
     if dim:
      dimension=raw[at];at+=1;assert not dimension&3;slot=signed16(dimension>>16)
     sources.append({'file':s&15,'index':signed16((s>>6)&65535),'slot':slot,'negate':s>>31,'absolute':(s>>30)&1,'swizzle':[(s>>(22+2*k))&3 for k in range(4)],'indirect':indirect})
    assert at==pos+length
    textures.append({'instruction':inst,'opcode':(w>>13)&255,'target':t&255,'writeMask':(d>>4)&15,'saturate':(w>>21)&1,'precise':w>>31,'offsets':0,'sources':sources})
   inst+=1
  pos+=length
 assert pos==len(raw);return views,textures,immediates

def literal(text):
 seen=[]
 for line in text.splitlines():
  m=re.match(r'^(\d+): (TEX|TXL|TXD|TXB|TXP|TXF|TXQ)(_SAT)?(_PRECISE)? (.*)$',line)
  if not m:continue
  args=[x.strip() for x in m[5].split(',')];d=args.pop(0);target=args.pop();mask=d.split('.')[-1] if '.' in d else 'xyzw';sources=[]
  for a in args:
   q=re.fullmatch(r'(-)?(\|)?(IN|IMM|SAMP|TEMP|CONST|SV)\[(\d+)\](?:\[(\d+)\])?(?:\.([xyzw]{1}|[xyzw]{4}))?(\|)?',a);assert q,a
   assert bool(q[2])==bool(q[7]);sw=q[6] or 'xyzw';sw=sw*4 if len(sw)==1 else sw
   f={'IN':'INPUT','IMM':'IMMEDIATE','SAMP':'SAMPLER','TEMP':'TEMPORARY','CONST':'CONSTANT','SV':'SYSTEM_VALUE'}[q[3]]
   sources.append(dict(file=files['TGSI_FILE_'+f],index=int(q[5] or q[4]),slot=int(q[4]) if q[5] else 0,negate=int(bool(q[1])),absolute=int(bool(q[2])),swizzle=['xyzw'.index(x) for x in sw],indirect=0))
  seen.append(dict(instruction=int(m[1]),opcode=opcodes['TGSI_OPCODE_'+m[2]],target=types['TGSI_TEXTURE_'+target],writeMask=sum(1<<'xyzw'.index(x) for x in mask),saturate=int(bool(m[3])),precise=int(bool(m[4])),offsets=0,sources=sources))
 return seen
cases=load(COLD/'native/cases.json')['cases'];native=rows(COLD/'native/native.jsonl');wasm=rows(COLD/'native/wasm.jsonl');assert (COLD/'native/native.jsonl').read_bytes()==(COLD/'native/sanitize.jsonl').read_bytes();assert len(cases)==len(native)==len(wasm)==11580
accepted=0;texturecount=0;points=[];selectedtargets=set()
for n,(c,r,w) in enumerate(zip(cases,native,wasm)):
 assert n==r['case'] and c['name']==w['name'] and r['result']==w['result'] and json.loads(w['response'])==r['result']
 result=r['result']
 if not result['ok']:
  assert list(result)==['ok','error'] and r['originalTokens'] is None;continue
 accepted+=1;paired='vertex' in result;stages=[result['vertex'],result['fragment']] if paired else [result];texts=[c['a'],c['b']] if paired else [c['a']]
 assert len(r['originalTokens'])==len(stages)
 for body,text,original in zip(stages,texts,r['originalTokens']):
  views,tx,imm=decode(original['rawWords']);assert views==original['samplerViews'] and tx==original['textureInstructions'] and imm==original['immediates'];assert tx==literal(text);texturecount+=len(tx)
  declarations=[]
  for m in re.finditer(r'^DCL SVIEW\[(\d+)(?:\.\.(\d+))?\], (\w+), ([^\n]+)$',text,re.M):
   rtypes=[s.strip() for s in m[4].split(',')];rtypes=rtypes+[rtypes[-1]]*(4-len(rtypes))
   declarations.append(dict(first=int(m[1]),last=int(m[2] or m[1]),target=types['TGSI_TEXTURE_'+m[3]],returnTypes=[returns['TGSI_RETURN_TYPE_'+t] for t in rtypes]))
  assert views==declarations,(n,c['name'],views,declarations)
  if c['kind']>=36:
   assert body['metadata']['profile']=='virgl-webgl2-standard-dimensional-texture-gles3-v1'
   for sampler in body['metadata']['samplers']:
    d=next(d for d in declarations if d['first']<=sampler['index']<=d['last']);target=next(k.removeprefix('TGSI_TEXTURE_') for k,v in types.items() if v==d['target']);selectedtargets.add(target)
    if 'Shadow' not in sampler['type']:
     prefix={returns['TGSI_RETURN_TYPE_FLOAT']:'',returns['TGSI_RETURN_TYPE_SINT']:'i',returns['TGSI_RETURN_TYPE_UINT']:'u'}[d['returnTypes'][0]]
     assert sampler['type']==prefix+'sampler'+{'2D':'2D','3D':'3D','CUBE':'Cube','2D_ARRAY':'2DArray'}[target]
    assert sampler['name']==('vs' if body['metadata']['stage']=='vertex' else 'fs')+'samp'+str(sampler['index'])
 if c['name'].startswith(('target-conflict/','same-slot-mixed','unsupported-target/')):raise AssertionError('forbidden selected form admitted')
 if c['name'] in ['vertex/3D/UINT/TXF/15','fragment/2D_ARRAY/SINT/TXD/7']:points.append({'caseLine':n+1,'name':c['name'],'originalTokens':r['originalTokens'],'result':r['result']})
assert accepted==9791 and texturecount==9526
historical=rows(COLD/'native/historical-abi.jsonl');assert len(historical)==7163;assert all(r['originalResponse']==r['currentResponse'] for r in historical)
facade=load(COLD/'native/facade.json');assert facade['getters']==0 and facade['ownedSnapshots'] and facade['peerIsolation'];assert all(list(x['result'])==['ok','error'] and not x['result']['ok'] for x in facade['rejections']);assert facade['pressure']['bytes']==16777216 and facade['pressure']['recovered']
alloc=rows(COLD/'native/allocations.jsonl');assert alloc[-1]['faults']==alloc[-1]['recoveries']==213;assert len([r for r in alloc if 'fault' in r['kind']])==213;assert all(not r['result']['ok'] and list(r['result'])==['ok','error'] for r in alloc if 'fault' in r['kind']);assert len([r for r in alloc if r['kind']=='caller-custody' and r['mutatedBeforeAllocation'] and r['recovered']])==5

# Physical oracle uses the recorded original input words and pinned texture literals,
# never the worker expectedWords or emitter output to predict values.
def texel(type,level,layer,x,y):
 code=level*256+layer*32+y*4+x
 return [struct.unpack('<I',struct.pack('<f',code+k/4))[0] if type=='FLOAT' else (-(8192+code*4+k))&0xffffffff if type=='SINT' else (0x81234000+code*4+k)&0xffffffff for k in range(4)]
def extent(target,level):
 w=max(1,4>>level);return w,w,w if target=='3D' else 6 if target=='CUBE' else 5

def cube(c,w):
 axis=max(range(3),key=lambda i:abs(c[i]));major=abs(c[axis]);face=axis*2+(c[axis]<0)
 sc,tc=((-c[2] if c[0]>0 else c[2]),-c[1]) if axis==0 else (c[0],c[2] if c[1]>0 else -c[2]) if axis==1 else (c[0] if c[2]>0 else -c[0],-c[1])
 return face,max(0,min(w-1,math.floor((sc/major+1)*w/2))),max(0,min(w-1,math.floor((tc/major+1)*w/2)))
physical=[]
for name in ['fresh-hardware-final-3141592653']:
 p=OUT/name;report=load(p/'report.json');a=report['acceptance'];assert report['browserErrors']==dict(console=[],page=[],requests=[]);assert report['browser']['launch']['headless'] is False and report['browser']['gpu']['featureStatus'][report['browser']['webglFeature']]=='enabled';assert 'Apple M4 Max' in a['gl']['renderer'] and 'Metal' in a['gl']['renderer']
 assert not a['productionNegotiation'] and not a['guestExecution'];blobs={}
 for blob in a['blobs']:
  z=(p/blob['path']).read_bytes();b=gzip.decompress(z);assert sha(z)==blob['gzipSha256'] and sha(b)==blob['sha256'] and len(b)==blob['bytes'];assert blob['key'] not in blobs;blobs[blob['key']]=b
 fps=[]
 for fi,f in enumerate(a['frames']):
  assert f['pair']==native[f['nativeIndex']]['result'];coords=blobs[f['originalInputs']['coordinates']];format='I' if f['opcode'] in ['TXF','TXQ'] else 'f';cc=[struct.unpack_from('<4'+format,coords,n) for n in range(0,len(coords),16)];dxbody=blobs[f['originalInputs']['dx']];dybody=blobs[f['originalInputs']['dy']];dx=[struct.unpack_from('<4f',dxbody,n) for n in range(0,len(dxbody),16)];dy=[struct.unpack_from('<4f',dybody,n) for n in range(0,len(dybody),16)]
  expected=[]
  for y in range(f['height']):
   for x in range(f['width']):
    if f.get('biasProbe'):
     s,t=(x+.5)/f['width'],(y+.5)/f['height'];c=[cc[0][k]+s*(cc[1][k]-cc[0][k])+t*(cc[2][k]-cc[0][k]) for k in range(4)];level=2
    else:c=list(cc[y*f['width']+x]);level=int(c[0]) if f['opcode']=='TXQ' else int(c[3]) if f['opcode'] in ['TXL','TXF'] else 0
    if f.get('source'):
     source=f['source'];sw=re.search(r'\.([xyzw]{4})',source);c=[c['xyzw'.index(k)] for k in sw[1]] if sw else c
     if '|' in source:c=[abs(v) for v in c]
     if source.startswith('-'):c=[-v for v in c]
    if f['opcode']=='TXD':
     d=dx[y*f['width']+x][:3 if f['target'] in ['3D','CUBE'] else 2];e=dy[y*f['width']+x][:len(d)]
     if f['target']=='CUBE':
      axis=max(range(3),key=lambda k:abs(c[k]));major=abs(c[axis]);d=[(d[k]*major-c[k]*d[axis])/(major*major)*2 for k in range(3) if k!=axis];e=[(e[k]*major-c[k]*e[axis])/(major*major)*2 for k in range(3) if k!=axis]
     else:d=[v*4 for v in d];e=[v*4 for v in e]
     rho=max(math.sqrt(sum(v*v for v in d)),math.sqrt(sum(v*v for v in e)));level=min(2,max(0,math.floor(math.log2(rho)+.5)))
    w,h,layers=extent(f['target'],level)
    if f['opcode']=='TXQ':sample=[w,h,0 if f['target']=='CUBE' else layers,3]
    else:
     if f['opcode']=='TXP':c=[v/c[3] for v in c[:3]]+[c[3]]
     if f['target']=='CUBE':layer,tx,ty=cube(c,w)
     elif f['opcode']=='TXF':tx,ty,layer=c[:3]
     else:tx=max(0,min(w-1,math.floor(c[0]*w)));ty=max(0,min(h-1,math.floor(c[1]*h)));layer=max(0,min(layers-1,math.floor(c[2]*layers) if f['target']=='3D' else math.floor(c[2]+.5)))
     sample=texel(f['type'],level,int(layer),int(tx),int(ty))
    mask=f.get('mask') or 'xyzw';sentinel=[0x12345678,0x80000001,0xdeadbeef,0xffffffff];expected.extend(sample[k] if 'xyzw'[k] in mask else sentinel[k] for k in range(4))
  body=struct.pack('<'+'I'*len(expected),*expected);actual=blobs[f['output']['bytesKey']];assert body==blobs[f['audit']['expectedBytesKey']];matches=body==actual;assert matches==(name!='fault-wrong-layer');assert matches==f['audit']['held'];assert f['cleaned']
  events=a['events'];done=f['gpuComplete'];ids=[done['writerEvent'],done['createdEvent'],done['consumedEvent'],f['output']['readEvent']];assert ids==sorted(set(ids));assert [events[i]['method'] for i in ids]==['drawArrays','fenceSync','clientWaitSync','readPixels'];assert events[ids[2]]['result'] in [37146,37148];assert events[ids[1]]['result']['handle']==done['handle']==events[ids[2]]['args'][0]['handle'];assert events[ids[3]]['after'][-1]['key']==f['output']['bytesKey'];assert all(e['result']==0 for e in events[f['firstEvent']:f['lastEvent']+1] if e['method']=='getError')
  for level in f['levels']:
   ww,hh,ll=extent(f['target'],level['level']);literalbody=struct.pack('<'+'I'*(ww*hh*ll*4),*[v for z in range(ll) for yy in range(hh) for xx in range(ww) for v in texel(f['type'],level['level'],z,xx,yy)]);assert blobs[level['originalBytesKey']]==literalbody
   for face,eventid in enumerate(level['uploadEvents']):
    event=events[eventid];uploaded=blobs[event['args'][-1]['key']];plane=ww*hh*16
    intended=literalbody[face*plane:(face+1)*plane] if f['target']=='CUBE' else literalbody
    if name=='fault-wrong-layer':intended=literalbody[-plane:]+literalbody[plane:-plane]+literalbody[:plane]
    assert uploaded==intended
  fps.append(dict(name=f['name'],frame=fi,readEvent=ids[3],outputBytes=len(actual),expectedSha256=sha(body),actualSha256=sha(actual),matches=matches))
 assert len(fps)==(1 if name=='fault-wrong-layer' else 396) and len(set(f['name'] for f in fps))==len(fps)
 physical.append(dict(name=name,status=report['status'],seed=a['seed'],completeBlobs=len(blobs),frames=fps,reportSha256=sha((p/'report.json').read_bytes())))
result=dict(status='passed',compilerCases=len(cases),accepted=accepted,refused=len(cases)-accepted,rawTextureInstructions=texturecount,historicalByteResponses=len(historical),strictRequestRejections=len(facade['rejections']),genuineFaults=213,callerCustodyModes=5,selectedTargets=sorted(selectedtargets),points=points,physical=physical)
(OUT/'fresh-interrogation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['physical','points']}))
