import gzip,hashlib,io,json,pathlib,subprocess,tarfile
ROOT=pathlib.Path.cwd();OUT=ROOT/'evidence/virgl-dimensional-shaders/verifier';sha=lambda b:hashlib.sha256(b).hexdigest();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head=='f880e934b9278af86c1f28f3d05d34c581b5bf9f'
assert all(json.loads((OUT/(name+'.json')).read_bytes())['status']=='passed' for name in ['authentication','interrogation','fresh-interrogation','coverage-audit','publication-audit','novel-audit']);assert json.loads((OUT/'verdict.json').read_bytes())['verdict']=='verified'
excluded={'manifest.json','records.json','recording.tar.gz'};files={str(p.relative_to(OUT)):p for p in OUT.rglob('*') if p.is_file() and str(p.relative_to(OUT)) not in excluded};assert not any((OUT/x).exists()for x in excluded),'preserve existing seals'
rows=[dict(path=name,bytes=p.stat().st_size,sha256=sha(p.read_bytes()))for name,p in sorted(files.items())];index=dict(schema='dimensional-shader-fresh-verifier-index-v1',workerSubmission=head,frozenRuntimeHarness='ebd460b325f5a3b97798a9450ab3c7f879b9ca26',records=rows);raw=(json.dumps(index,indent=2)+'\n').encode();(OUT/'records.json').write_bytes(raw)
with (OUT/'recording.tar.gz').open('wb')as stream,gzip.GzipFile(fileobj=stream,mode='wb',filename='',mtime=0)as zipped,tarfile.open(fileobj=zipped,mode='w')as t:
 for row in rows:
  body=files[row['path']].read_bytes();item=tarfile.TarInfo(row['path']);item.size=len(body);item.mode=0o644;item.mtime=0;t.addfile(item,io.BytesIO(body))
with tarfile.open(OUT/'recording.tar.gz','r|gz')as t:
 count=0
 for pos,item in enumerate(t):
  assert pos<len(rows);row=rows[pos];assert item.isfile() and item.name==row['path'] and item.size==row['bytes'];body=t.extractfile(item).read();assert sha(body)==row['sha256'];count+=1
 assert count==len(rows)
manifest=dict(schema='dimensional-shader-fresh-verifier-seal-v1',task='E6-T11d57',verdict='verified',workerSubmission=head,frozenRuntimeHarness='ebd460b325f5a3b97798a9450ab3c7f879b9ca26',verifiedBase='48b2ba0c7ee90d13093f7782e5a2502e44095753',records=len(rows),reopenedMembers=count,recordIndexSha256=sha(raw),archiveSha256=sha((OUT/'recording.tar.gz').read_bytes()),archiveBytes=(OUT/'recording.tar.gz').stat().st_size,workerBodiesAuthenticated=75642,predictionsSha256=sha((OUT/'predictions.json').read_bytes()),verdictSha256=sha((OUT/'verdict.json').read_bytes()),novelOracleSourceSha256=sha((OUT/'promoted-sources/stage-isolation-test.mjs').read_bytes()),changedRuntime=False,productionAuthority=False,promotionDoesNotChangeRuntime=True,diagnosticsPreserved=True)
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(dict(manifestSha256=sha((OUT/'manifest.json').read_bytes()),**manifest)))
