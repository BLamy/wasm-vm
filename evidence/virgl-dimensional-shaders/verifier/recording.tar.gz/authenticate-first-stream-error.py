import hashlib,json,pathlib,subprocess,tarfile
ROOT=pathlib.Path.cwd(); OUT=ROOT/'evidence/virgl-dimensional-shaders/verifier';COLD=pathlib.Path('/tmp/wasmvm-dimensional-shaders-cold-ebd460b3');FREEZE='ebd460b325f5a3b97798a9450ab3c7f879b9ca26'
sha=lambda b:hashlib.sha256(b).hexdigest()
expected={'worker':('0c698861a17b341265e35b6c6d223ea0390ea495cb942c0e469d4ecb1201602f','ce50cc6e695c5a8dacebc006e88c661967f2fa1e5a1e646b4ae5809d9c54976f','0476287955b27dd7ffca49c3be190acfa6f2b809c86f0b7f9339c995ec84970c'),'diagnostic':('e324de4aa3350de51528ae97d5a01baa17b8f58aecae72d493b7b6ae635ae870','8743090aa0ab239776508120a2f9574e38fefe354c2d9a5c894c1a96b2a8f0f0','12efb7befedfee0b9b8b57dee249fb99d0a6da030e61d4d5db9a62c060a747e0'),'deployment':('f852585081506fe1e0c97417da06ea2cd3435d484e0d5d2f15cb81bf404fa650','3eb8743404017d746e8f3ffc46462d99fea9e0e15fb99e77f153c5c7d8fcd5a9','36a70ec88dbeeac94c4d55f50800d3a302d10d2057b3c2b0405b7eae0a0d683a')}
checks={};reopened=0
for facet,digests in expected.items():
 seal=ROOT/'evidence/virgl-dimensional-shaders'/facet
 for name,digest in zip(['manifest.json','records.json','recording.tar.gz'],digests):assert sha((seal/name).read_bytes())==digest,(facet,name)
 m=json.loads((seal/'manifest.json').read_bytes());rows=json.loads((seal/'records.json').read_bytes())['records'];assert m['head']==FREEZE and m['recordIndexSha256']==digests[1] and m['archiveSha256']==digests[2]
 assert len(rows)==m['records']==m['reopenedMembers'];assert len(set(r['path'] for r in rows))==len(rows)
 with tarfile.open(seal/'recording.tar.gz','r|gz') as archive:
  count=0
  for item,row in zip(archive,rows):
   assert item.isfile() and item.name==row['path'] and item.size==row['bytes'];body=archive.extractfile(item).read();assert sha(body)==row['sha256'],item.name
   if facet=='worker' and item.name.startswith('cold/'):
    raw=COLD/item.name.removeprefix('cold/');assert raw.is_file() and sha(raw.read_bytes())==row['sha256'],str(raw)
   if facet=='deployment':
    dest=OUT/'publication'/item.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(body)
   count+=1
  assert count==len(rows) and archive.next() is None
 checks[facet]={'completeMembers':count,'manifestSha256':digests[0],'indexSha256':digests[1],'archiveSha256':digests[2]};reopened+=count
receipt=json.loads((COLD/'recording/receipt.json').read_bytes());report=json.loads((COLD/'report.json').read_bytes());assert receipt['head']==report['head']==FREEZE and report['receiptSha256']==sha((COLD/'recording/receipt.json').read_bytes())=='9aa4603cafc7cb70967bbee56bf15b0a10a48918a3253877c33d784e8d035894'
assert not report['cleanBefore'] and not report['cleanAfter'] and report['exitCode']==0
clone=pathlib.Path(report['clone']);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==FREEZE;assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=clone)
for name,pin in receipt['sources'].items():
 body=(COLD/'recording/sources'/name).read_bytes();assert len(body)==pin['bytes'] and sha(body)==pin['sha256'];assert body==subprocess.check_output(['git','show',FREEZE+':'+name],cwd=ROOT)
for name,pin in receipt['generated'].items():
 body=(COLD/'recording/generated'/name).read_bytes();assert len(body)==pin['bytes'] and sha(body)==pin['sha256'];assert sha((clone/name).read_bytes())==pin['sha256']
for cmd in receipt['commands']:
 assert cmd['exitCode']==cmd['expected'];assert sha((COLD/('recording/'+cmd['name']+'.stdout')).read_bytes())==cmd['stdoutSha256'];assert sha((COLD/('recording/'+cmd['name']+'.stderr')).read_bytes())==cmd['stderrSha256']
assert not subprocess.check_output(['git','diff','--name-only','48b2ba0c7ee90d13093f7782e5a2502e44095753','HEAD','--','crates','renderer/virgl-command','tools/guest'],cwd=ROOT)
result={'status':'passed','completeMembers':reopened,'seals':checks,'sourcePins':len(receipt['sources']),'generatedPins':len(receipt['generated']),'commands':len(receipt['commands']),'cleanClone':report,'unchangedBoundaries':['crates','renderer/virgl-command','tools/guest']}
(OUT/'authentication.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'passed','completeMembers':reopened,'sourcePins':len(receipt['sources']),'commands':len(receipt['commands'])}))
