import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import * as factories from '../../../renderer/virgl-shader/standard.mjs';
const root=process.cwd(),out=path.resolve('evidence/virgl-dimensional-shaders/verifier'),record='/tmp/wasmvm-dimensional-shaders-cold-ebd460b3/recording',hash=b=>createHash('sha256').update(b).digest('hex');
const {default:oldFactory}=await import(pathToFileURL(record+'/native/predecessor/virgl-shader.mjs')),{default:newFactory}=await import(pathToFileURL(root+'/renderer/virgl-shader/build/wasm/virgl-shader.mjs')),old=await oldFactory(),raw=await newFactory();
const retained=[];
function call(m,entry,stage,text,images){const p=m._malloc(text.length+1);assert.ok(p);try {m.HEAPU8.set(Buffer.from(text),p);m.HEAPU8[p+text.length]=0;return m.UTF8ToString(images?m[entry](stage,p,text.length,0,0):m[entry](stage,p,text.length));} finally{m._free(p);}}
for (const [name,entry,images] of [['createVirglStandardShaderBridge','_bridge_translate_standard',false],['createVirglStandardUniformShaderBridge','_bridge_translate_standard_uniform',false],['createVirglStandardTextureShaderBridge','_bridge_translate_standard_texture',false],['createVirglStandardIntegerImageShaderBridge','_bridge_translate_standard_integer_image',true],['createVirglStandardInstanceBaseShaderBridge','_bridge_translate_standard_instance_base',true],['createVirglStandardShadowTextureShaderBridge','_bridge_translate_standard_shadow_texture',true]]) {
 const bridge=await factories[name]();
 for(const [stage,header]of [[0,'VERT'],[1,'FRAG']])for(const target of ['3D','CUBE','2D_ARRAY'])for(const opcode of ['TEX','TXL','TXQ']) {
  const source=header+'\n'+(stage===0?'DCL IN[0]\nDCL OUT[0], POSITION\n':'DCL IN[0], GENERIC[0], CONSTANT\nDCL OUT[0], COLOR\n')+'DCL SAMP[7]\nDCL SVIEW[7], '+target+', FLOAT\n0: '+opcode+' OUT[0], IN[0], SAMP[7], '+target+'\n1: END\n';
  const before=call(old,entry,stage,source,images),now=call(raw,entry,stage,source,images),result=JSON.parse(now);assert.equal(before,now);assert.equal(result.ok,false);assert.equal(result.error.code,'unsupported-feature');assert.deepEqual(Object.keys(result),['ok','error']);assert.deepEqual(bridge.translate({stage:stage===0?'vertex':'fragment',text:source}),result);retained.push({factory:name,stage,target,opcode,source,before,now,facade:result});
 }
}
assert.equal(retained.length,108);await fs.writeFile(out+'/historical-dimensions.json',JSON.stringify({status:'passed',cases:retained},null,2)+'\n');
// Independent C ABI confirmation of the physical critic test using exact frozen executables.
// Importing its constants in Node is deliberately avoided because it is also an executable.
const text=await fs.readFile(root+'/tools/virgl-dimensional-shaders/stage-isolation-test.mjs','utf8');const vertexText=JSON.parse('"'+text.match(/export const vertexText = '([^']*)';/)[1]+'"'),fragmentText=JSON.parse('"'+text.match(/export const fragmentText = '([^']*)';/)[1]+'"');
const uint=n=>{const b=Buffer.alloc(4);b.writeUInt32LE(n);return b;};const a=Buffer.from(vertexText),b=Buffer.from(fragmentText),body=Buffer.concat([uint(1),uint(38),...Array.from({length:7},(_,i)=>uint(i===6?1:0)),uint(a.length),a,uint(b.length),b]);await fs.writeFile(out+'/novel-native.bin',body);
for(const [mode,entry] of [['native','standard-dimensional-texture-native/standard-dimensional-texture-test'],['sanitize','standard-dimensional-texture-sanitize/standard-dimensional-texture-test']]) {
 const binary=record+'/generated/renderer/virgl-shader/build/'+entry;const pinned=await fs.readFile(binary);const clean='/var/folders/nr/cyvk1qc14jj5c081vj1xts000000gn/T/wasm-vm-dimensional-shaders-cold-9y9mvjdz/repo/renderer/virgl-shader/build/'+entry;assert.equal(hash(pinned),hash(await fs.readFile(clean)));
 const output=execFileSync(clean,[out+'/novel-native.bin'],{env:{...process.env,ASAN_OPTIONS:'abort_on_error=1',UBSAN_OPTIONS:'halt_on_error=1',LLVM_PROFILE_FILE:out+'/novel-native.profraw'}});await fs.writeFile(out+'/novel-'+mode+'.jsonl',output);
 const parsed=JSON.parse(output.toString());assert.equal(parsed.result.ok,true);const hardware=JSON.parse(await fs.readFile(out+'/novel-3141592653/report.json'));assert.deepEqual(parsed.result,hardware.acceptance.pair);
}
assert.equal((await fs.readFile(out+'/novel-native.jsonl')).toString(),(await fs.readFile(out+'/novel-sanitize.jsonl')).toString());console.log('All108 historical dimension refusals and exact novel native/sanitized/browser pair identities held.');
