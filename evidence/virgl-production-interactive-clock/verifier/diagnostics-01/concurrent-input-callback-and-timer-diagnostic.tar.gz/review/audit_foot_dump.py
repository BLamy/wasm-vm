#!/usr/bin/env python3
"""Decode only recorded diagnostic bytes; never contacts or changes a VM."""
import argparse, base64, hashlib, json, re, struct
from collections import defaultdict
from pathlib import Path
HEADER=0x57564d464f4f5432
END=0x57564d46454e4432
LIMIT=32768

def signed(value):
    return value-(1<<64) if value>=(1<<63) else value

def identity(path):
    body=path.read_bytes()
    return {"path":str(path),"bytes":len(body),"sha256":hashlib.sha256(body).hexdigest()}

def decode_frames(body):
    frames=[]
    offset=0
    while offset<len(body):
        if len(body)-offset<64:raise ValueError(f"truncated frame at {offset}")
        magic,count,overflow,size=struct.unpack_from("<4Q",body,offset)
        if magic!=HEADER or size!=96 or count>LIMIT:raise ValueError(f"invalid header at {offset}")
        stop=None
        for written in range(count+1):
            pos=offset+32+96*written
            if pos+32>len(body):break
            end_magic,end_count,end_overflow,end_written=struct.unpack_from("<4Q",body,pos)
            if (end_magic,end_count,end_overflow,end_written)==(END,count,overflow,written):
                stop=pos+32
                break
        if stop is None:raise ValueError(f"missing END at {offset}")
        records=[]
        for index in range(written):
            values=struct.unpack_from("<12Q",body,offset+32+96*index)
            records.append({"index":index,"type":values[0],"mono_ns":values[1],"thread_cpu_ns":values[2],"tid":values[3],"args":list(values[4:])})
        frames.append({"offset":offset,"endOffset":stop,"count":count,"overflow":overflow,"written":written,"complete":written==count and overflow==0,"records":records})
        offset=stop
    return frames

def analyze(records):
    by_tid=defaultdict(list)
    for row in records:by_tid[row["tid"]].append(row)
    per_tid={str(tid):{"count":len(rows),"monoPositive":all(r["mono_ns"]>0 for r in rows),"monoMonotonic":all(a["mono_ns"]<=b["mono_ns"] for a,b in zip(rows,rows[1:])),"threadCpuMonotonic":all(a["thread_cpu_ns"]<=b["thread_cpu_ns"] for a,b in zip(rows,rows[1:]))} for tid,rows in by_tid.items()}
    stacks=defaultdict(list)
    key_pairs=[]
    mismatches=[]
    created={}
    creation_generation=defaultdict(int)
    arm_stacks=defaultdict(list)
    arms=[]
    reads=[]
    for row in records:
        kind=row["type"];args=row["args"];tid=row["tid"]
        if kind==3:stacks[tid].append(row)
        elif kind==4:
            if not stacks[tid] or stacks[tid][-1]["args"][:5]!=args[:5]:
                mismatches.append({"kind":"key-return","row":row});continue
            before=stacks[tid].pop()
            key_pairs.append({"enterIndex":before["index"],"returnIndex":row["index"],"tid":tid,"proxy":args[0],"serial":args[1],"source_ms":args[2],"code":args[3],"state":args[4],"entered_mono_ns":before["mono_ns"],"returned_mono_ns":row["mono_ns"],"callback_mono_ns":row["mono_ns"]-before["mono_ns"],"callback_thread_cpu_ns":row["thread_cpu_ns"]-before["thread_cpu_ns"]})
        elif kind==6:
            fd=signed(args[0])
            if fd>=0:
                creation_generation[fd]+=1
                created[fd]={"index":row["index"],"fd":fd,"clockid":signed(args[1]),"flags":args[2],"generation":creation_generation[fd]}
        elif kind==7:
            arm_stacks[(tid,signed(args[0]))].append(row)
        elif kind==8:
            fd=signed(args[0]);stack=arm_stacks[(tid,fd)]
            if not stack:mismatches.append({"kind":"arm-return","row":row});continue
            before=stack.pop();a=before["args"]
            arms.append({"enterIndex":before["index"],"returnIndex":row["index"],"tid":tid,"fd":fd,"create":created.get(fd),"flags":a[1],"initial_ns":a[2]*1000000000+a[3],"interval_ns":a[4]*1000000000+a[5],"result":signed(args[1]),"errno":args[2],"entered_mono_ns":before["mono_ns"],"returned_mono_ns":row["mono_ns"]})
        elif kind==9:
            fd=signed(args[0])
            reads.append({"index":row["index"],"tid":tid,"fd":fd,"create":created.get(fd),"count":args[1],"mono_ns":row["mono_ns"],"thread_cpu_ns":row["thread_cpu_ns"]})
    return {"perTid":per_tid,"ready":[r for r in records if r["type"]==1],"listeners":[r for r in records if r["type"]==2],"repeatInfo":[r for r in records if r["type"]==5],"focus":[r for r in records if r["type"] in (10,11)],"keyPairs":key_pairs,"keyEntriesUnreturned":{str(tid):rows for tid,rows in stacks.items() if rows},"armEntriesUnreturned":{str(key):rows for key,rows in arm_stacks.items() if rows},"mismatches":mismatches,"timerArms":arms,"timerSuccessful8ByteReads":reads}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("dump",type=Path)
    parser.add_argument("output",type=Path)
    args=parser.parse_args()
    doc=json.loads(args.dump.read_text())
    stdout=doc.get("stdout",doc.get("result",{}).get("stdout",""))
    chunks=re.findall(r"^FOOT_OBSERVER_BEGIN:(\d+)\r?\n(.*?)^FOOT_OBSERVER_END:\1\r?$",stdout,re.M|re.S)
    if not chunks:raise ValueError("no complete FOOT_OBSERVER envelope")
    decoded=[]
    for pid_text,section in chunks:
        pid=int(pid_text);lines=[line.removesuffix("\r") for line in section.split("\n")]
        signal=[re.fullmatch(r"SIGNAL_EXIT:(-?\d+)",line) for line in lines]
        signal=[int(m[1]) for m in signal if m]
        sizes=[re.fullmatch(r"\s*(\d+)\s+/tmp/wvm-foot-observer-(\d+)\.bin",line) for line in lines]
        sizes=[(int(m[1]),int(m[2])) for m in sizes if m]
        hashes=[re.fullmatch(r"([0-9a-f]{64})\s+/tmp/wvm-foot-observer-(\d+)\.bin",line) for line in lines]
        hashes=[(m[1],int(m[2])) for m in hashes if m]
        candidates=[line for line in lines if re.fullmatch(r"[A-Za-z0-9+/]+={0,2}",line)]
        result={"pid":pid,"signalExits":signal,"guestSizes":sizes,"guestHashes":hashes}
        if signal!=[0] or len(sizes)!=1 or len(hashes)!=1 or sizes[0][1]!=pid or hashes[0][1]!=pid or len(candidates)!=1:
            result["error"]="invalid envelope/signal/size/hash/base64 extent";decoded.append(result);continue
        try:
            body=base64.b64decode(candidates[0],validate=True)
            result["bytes"]=len(body);result["sha256"]=hashlib.sha256(body).hexdigest()
            if len(body)!=sizes[0][0] or result["sha256"]!=hashes[0][0]:raise ValueError("guest bytes/hash mismatch")
            binary=args.output.parent/f"foot-observer-{pid}.bin"
            if binary.exists() and binary.read_bytes()!=body:raise ValueError("refuse overwrite of different original binary")
            binary.write_bytes(body)
            frames=decode_frames(body)
            result["frames"]=[{**frame,"analysis":analyze(frame["records"])} for frame in frames]
            result["allFramesComplete"]=all(frame["complete"] for frame in frames)
        except ValueError as error:result["error"]=str(error)
        decoded.append(result)
    output={"schema":1,"scope":"Concurrent passive diagnostic only, not stock acceptance or exclusive cause proof","identity":identity(args.dump),"producerExit":doc.get("exit",doc.get("result",{}).get("exit")),"processes":decoded,"limitations":["Only successful8-byte timer reads are logged; no inference from absence.","Each repeated dump frame is a separate cumulative snapshot; never add duplicate frames.","Atomic record reservation may interleave between threads, so compare clocks perTID.","Original signal dump changes scheduling only after the first helper has closed."]}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(output,indent=2)+"\n")
    print(json.dumps({"path":str(args.output),"sha256":hashlib.sha256(args.output.read_bytes()).hexdigest(),"processes":[{"pid":p["pid"],"error":p.get("error"),"bytes":p.get("bytes"),"allFramesComplete":p.get("allFramesComplete"),"frames":[{"count":f["count"],"written":f["written"],"overflow":f["overflow"],"keys":len(f["analysis"]["keyPairs"]),"reads":len(f["analysis"]["timerSuccessful8ByteReads"])} for f in p.get("frames",[])]} for p in decoded]}))

if __name__=="__main__":main()
