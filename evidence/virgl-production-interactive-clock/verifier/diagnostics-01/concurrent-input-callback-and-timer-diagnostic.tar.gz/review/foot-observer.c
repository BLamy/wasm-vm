#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/timerfd.h>
#include <time.h>
#include <unistd.h>
#include <wayland-client.h>

/* Diagnostic only. Never injects input or changes repeat/timer parameters.
 * Each record is 12 little-endian uint64s. Events are buffered until SIGUSR2.
 * 1 ready, 2 keyboard listener, 3 key-enter, 4 key-return, 5 repeat_info,
 * 6 timer create, 7 timer arm-enter, 8 timer arm-return, 9 timer read,
 * 10 keyboard focus enter, 11 keyboard focus leave.
 * Clock domains are the actual guest CLOCK_MONOTONIC and THREAD_CPUTIME_ID. */
struct record { uint64_t field[12]; };
enum { LIMIT = 32768, KEYBOARDS = 8, FDS = 4096 };
static struct record records[LIMIT];
static _Atomic unsigned used;
static _Atomic unsigned ready[LIMIT];
static _Atomic unsigned overflow;
static _Atomic unsigned char timer_fds[FDS];
static int output_fd = -1;
static ssize_t (*real_read)(int, void *, size_t);
static int (*real_create)(int, int);
static int (*real_arm)(int, int, const struct itimerspec *, struct itimerspec *);
static int (*real_close)(int);
static int (*real_listener)(struct wl_proxy *, void (**)(void), void *);
struct keyboard {
    struct wl_proxy *proxy;
    struct wl_keyboard_listener original;
    struct wl_keyboard_listener wrapped;
};
static struct keyboard keyboards[KEYBOARDS];

static uint64_t nanos(clockid_t id) {
    struct timespec t = {0};
    clock_gettime(id, &t);
    return (uint64_t)t.tv_sec * 1000000000ULL + (uint64_t)t.tv_nsec;
}
static void note(uint64_t type, uint64_t a, uint64_t b, uint64_t c,
                 uint64_t d, uint64_t e, uint64_t f, uint64_t g, uint64_t h) {
    int saved = errno;
    unsigned i = atomic_fetch_add(&used, 1);
    if (i >= LIMIT) { atomic_fetch_add(&overflow, 1); errno = saved; return; }
    records[i] = (struct record){{type, nanos(CLOCK_MONOTONIC),
        nanos(CLOCK_THREAD_CPUTIME_ID), (uint64_t)gettid(), a,b,c,d,e,f,g,h}};
    atomic_store_explicit(&ready[i], 1, memory_order_release);
    errno = saved;
}
static int write_all(const void *data, size_t size) {
    const unsigned char *bytes=data;
    while (size) {
        ssize_t n=write(output_fd,bytes,size);
        if (n<0 && errno==EINTR) continue;
        if (n<=0) return -1;
        bytes+=n;size-=(size_t)n;
    }
    return 0;
}
static void dump(int sig) {
    (void)sig;
    int saved = errno;
    uint64_t header[4] = {0x57564d464f4f5432ULL,
        atomic_load(&used), atomic_load(&overflow), sizeof(struct record)};
    if (header[1] > LIMIT) header[1] = LIMIT;
    if (output_fd >= 0) {
        if (write_all(header,sizeof(header))) { errno=saved;return; }
        unsigned written=0;
        for (unsigned i = 0; i < header[1]; ++i) {
            if (!atomic_load_explicit(&ready[i], memory_order_acquire)) break;
            if (write_all(&records[i],sizeof(records[i]))) { errno=saved;return; }
            written++;
        }
        uint64_t end[4]={0x57564d46454e4432ULL,header[1],header[2],written};
        (void)write_all(end,sizeof(end));
    }
    errno = saved;
}
__attribute__((constructor)) static void init(void) {
    /* Instrument only this Foot process, never its fork/exec shell or helpers. */
    unsetenv("LD_PRELOAD");
    real_read = dlsym(RTLD_NEXT, "read");
    real_create = dlsym(RTLD_NEXT, "timerfd_create");
    real_arm = dlsym(RTLD_NEXT, "timerfd_settime");
    real_close = dlsym(RTLD_NEXT, "close");
    real_listener = dlsym(RTLD_NEXT, "wl_proxy_add_listener");
    if (!real_read || !real_create || !real_arm || !real_close || !real_listener) _exit(121);
    char name[128];
    snprintf(name, sizeof(name), "/tmp/wvm-foot-observer-%ld.bin", (long)getpid());
    output_fd = open(name, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0600);
    struct sigaction action = {.sa_handler = dump, .sa_flags = SA_RESTART};
    sigemptyset(&action.sa_mask);
    if (output_fd < 0 || sigaction(SIGUSR2, &action, NULL)) _exit(122);
    note(1, getpid(), getuid(), 0, 0, 0, 0, 0, 0);
}
static struct keyboard *find(struct wl_keyboard *kbd) {
    for (unsigned i = 0; i < KEYBOARDS; ++i)
        if (keyboards[i].proxy == (struct wl_proxy *)kbd) return &keyboards[i];
    _exit(123);
}
static void keymap(void *data, struct wl_keyboard *kbd, uint32_t fmt, int32_t fd, uint32_t size) {
    find(kbd)->original.keymap(data,kbd,fmt,fd,size);
}
static void enter(void *data, struct wl_keyboard *kbd, uint32_t serial, struct wl_surface *surface, struct wl_array *keys) {
    note(10,(uintptr_t)kbd,serial,keys->size,0,0,0,0,0);
    find(kbd)->original.enter(data,kbd,serial,surface,keys);
}
static void leave(void *data, struct wl_keyboard *kbd, uint32_t serial, struct wl_surface *surface) {
    note(11,(uintptr_t)kbd,serial,0,0,0,0,0,0);
    find(kbd)->original.leave(data,kbd,serial,surface);
}
static void key(void *data, struct wl_keyboard *kbd, uint32_t serial, uint32_t time, uint32_t code, uint32_t state) {
    note(3,(uintptr_t)kbd,serial,time,code,state,0,0,0);
    find(kbd)->original.key(data,kbd,serial,time,code,state);
    note(4,(uintptr_t)kbd,serial,time,code,state,0,0,0);
}
static void modifiers(void *data, struct wl_keyboard *kbd, uint32_t serial, uint32_t depressed, uint32_t latched, uint32_t locked, uint32_t group) {
    find(kbd)->original.modifiers(data,kbd,serial,depressed,latched,locked,group);
}
static void repeat(void *data, struct wl_keyboard *kbd, int32_t rate, int32_t delay) {
    note(5,(uintptr_t)kbd,(uint32_t)rate,(uint32_t)delay,0,0,0,0,0);
    if (find(kbd)->original.repeat_info) find(kbd)->original.repeat_info(data,kbd,rate,delay);
}
int wl_proxy_add_listener(struct wl_proxy *proxy, void (**listener)(void), void *data) {
    if (!real_listener) real_listener = dlsym(RTLD_NEXT, "wl_proxy_add_listener");
    if (strcmp(wl_proxy_get_class(proxy), "wl_keyboard")) return real_listener(proxy,listener,data);
    struct keyboard *slot = NULL;
    for (unsigned i = 0; i < KEYBOARDS; ++i) if (!keyboards[i].proxy) { slot=&keyboards[i];break; }
    if (!slot) _exit(124);
    slot->proxy=proxy;
    memcpy(&slot->original,listener,sizeof(slot->original));
    slot->wrapped=(struct wl_keyboard_listener){keymap,enter,leave,key,modifiers,repeat};
    note(2,(uintptr_t)proxy,0,0,0,0,0,0,0);
    return real_listener(proxy,(void (**)(void))&slot->wrapped,data);
}
int timerfd_create(int clockid, int flags) {
    if (!real_create) real_create=dlsym(RTLD_NEXT,"timerfd_create");
    int fd=real_create(clockid,flags), saved=errno;
    if (fd>=0 && fd<FDS) timer_fds[fd]=1;
    note(6,fd,clockid,flags,0,0,0,0,0);errno=saved;return fd;
}
int timerfd_settime(int fd, int flags, const struct itimerspec *value, struct itimerspec *old) {
    if (!real_arm) real_arm=dlsym(RTLD_NEXT,"timerfd_settime");
    note(7,fd,flags,value->it_value.tv_sec,value->it_value.tv_nsec,
         value->it_interval.tv_sec,value->it_interval.tv_nsec,0,0);
    int result=real_arm(fd,flags,value,old), saved=errno;
    note(8,fd,(uint64_t)(int64_t)result,saved,0,0,0,0,0);errno=saved;return result;
}
ssize_t read(int fd, void *data, size_t size) {
    if (!real_read) real_read=dlsym(RTLD_NEXT,"read");
    ssize_t result=real_read(fd,data,size);int saved=errno;
    if (fd>=0 && fd<FDS && timer_fds[fd] && result==8) {
        uint64_t count;memcpy(&count,data,8);note(9,fd,count,0,0,0,0,0,0);
    }
    errno=saved;return result;
}
int close(int fd) {
    if (!real_close) real_close=dlsym(RTLD_NEXT,"close");
    if (fd>=0 && fd<FDS) timer_fds[fd]=0;
    return real_close(fd);
}
