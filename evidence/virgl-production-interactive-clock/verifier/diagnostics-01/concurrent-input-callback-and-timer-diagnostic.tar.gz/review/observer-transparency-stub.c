#include <assert.h>
#include <errno.h>
#include <wayland-client.h>
extern const struct wl_keyboard_listener *captured;
extern void *expected;
extern struct wl_keyboard *keyboard;
const char *wl_proxy_get_class(struct wl_proxy *proxy) {
    assert(proxy==(struct wl_proxy *)keyboard);return "wl_keyboard";
}
int wl_proxy_add_listener(struct wl_proxy *proxy, void (**listener)(void), void *data) {
    assert(proxy==(struct wl_proxy *)keyboard && data==expected);
    captured=(const struct wl_keyboard_listener *)listener;errno=EIO;return 73;
}
