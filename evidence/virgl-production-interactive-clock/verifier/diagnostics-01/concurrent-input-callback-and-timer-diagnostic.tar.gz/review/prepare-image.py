from pathlib import Path
import hashlib, json, os, subprocess

repo=Path.cwd(); out=Path(__file__).resolve().parent
previous=repo/'target/evidence/production-stock-repeat-investigation01/image'
original=repo/'target/virgl-production/image-12'
dst=out/'image';dst.mkdir(exist_ok=False)
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
assert sha(previous/'guest.ext4')=='4e5f773870bc91b744ec78cf71dd09ce4153681ff09f1b1f6149792491c119a3'
subprocess.run(['cp','-c',str(previous/'guest.ext4'),str(dst/'guest.ext4')],check=True)
base=['docker','run','--rm','-v',str(dst/'guest.ext4')+':/disk/guest.ext4',
      '-v',str(out)+':/work:ro','wasm-vm-virgl-reference:1.3.0']
foot=subprocess.check_output(base+['debugfs','-R','cat /usr/bin/foot','/disk/guest.ext4'],stderr=subprocess.DEVNULL)
assert foot[:4]==b'\x7fELF'
(out/'foot-original').write_bytes(foot)
commands=('write /work/foot-original /usr/lib/wvm-foot-observed-original\n'
          'set_inode_field /usr/lib/wvm-foot-observed-original mode 0100755\n'
          'rm /usr/bin/foot\n'
          'write /work/foot-wrapper /usr/bin/foot\n'
          'set_inode_field /usr/bin/foot mode 0100755\n'
          'write /work/foot-observer.so /opt/virgl-proof/foot-observer.so\n')
(out/'image-commands.txt').write_text(commands)
r=subprocess.run(base+['debugfs','-w','-f','/work/image-commands.txt','/disk/guest.ext4'],capture_output=True,check=True)
(out/'image-debugfs.log').write_bytes(r.stdout+r.stderr)
for src,target in [('foot-original','/usr/lib/wvm-foot-observed-original'),('foot-wrapper','/usr/bin/foot'),('foot-observer.so','/opt/virgl-proof/foot-observer.so')]:
    b=subprocess.check_output(base+['debugfs','-R','cat '+target,'/disk/guest.ext4'],stderr=subprocess.DEVNULL)
    assert b==(out/src).read_bytes(),target
manifest=json.loads((original/'manifest.json').read_text())
chunks=dst/'chunks';chunks.mkdir();digests=[];changed=[]
with (dst/'guest.ext4').open('rb') as f:
    for i,data in enumerate(iter(lambda:f.read(manifest['chunk_size']),b'')):
        h=hashlib.sha256(data).hexdigest();digests.append(h)
        if h!=manifest['chunks'][i]:changed.append(i)
        output=chunks/(h+'.bin')
        if output.exists():continue
        for cached in [previous/'chunks'/output.name,original/'chunks'/output.name]:
            if cached.exists():os.link(cached,output);break
        else:output.write_bytes(data)
(dst/'manifest.json').write_text(json.dumps({**manifest,'chunks':digests},indent=2)+'\n')
assert sha(previous/'guest.ext4')=='4e5f773870bc91b744ec78cf71dd09ce4153681ff09f1b1f6149792491c119a3'
receipt={'scope':'Disposable passive diagnostic. Not stock acceptance or publication.',
 'originalFootSha256':hashlib.sha256(foot).hexdigest(),'observerSourceSha256':sha(out/'foot-observer.c'),
 'observerLibrarySha256':sha(out/'foot-observer.so'),'wrapperSha256':sha(out/'foot-wrapper'),
 'parentImageSha256':'4e5f773870bc91b744ec78cf71dd09ce4153681ff09f1b1f6149792491c119a3',
 'imageSha256':sha(dst/'guest.ext4'),'manifestSha256':sha(dst/'manifest.json'),
 'changedChunksVsProduction12':changed,'newClientBoundary':'original binary relocated byte-identically; launcher exec with listener/timerfd observer, unset preload before child forks; unchanged user/config/repeat/compositor/GPU'}
(out/'image-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
