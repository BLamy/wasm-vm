#define _GNU_SOURCE
#include <assert.h>
#include <errno.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/timerfd.h>
#include <time.h>
#include <unistd.h>
#include <wayland-client.h>

const struct wl_keyboard_listener *captured;
void *expected=(void *)0x1234;
struct wl_keyboard *keyboard=(struct wl_keyboard *)0x5678;
static struct wl_surface *surface=(struct wl_surface *)0x9012;
static struct wl_array array;
static unsigned calls;
static void keymap(void *d,struct wl_keyboard *k,uint32_t fmt,int32_t fd,uint32_t size) {
    assert(d==expected && k==keyboard && fmt==1 && fd==42 && size==100);++calls;
}
static void enter(void *d,struct wl_keyboard *k,uint32_t serial,struct wl_surface *s,struct wl_array *keys) {
    assert(d==expected && k==keyboard && serial==2 && s==surface && keys==&array);++calls;
}
static void leave(void *d,struct wl_keyboard *k,uint32_t serial,struct wl_surface *s) {
    assert(d==expected && k==keyboard && serial==3 && s==surface);++calls;
}
static void key(void *d,struct wl_keyboard *k,uint32_t serial,uint32_t time,uint32_t code,uint32_t state) {
    assert(d==expected && k==keyboard && serial==4 && time==123 && code==20 && state==1);++calls;
}
static void modifiers(void *d,struct wl_keyboard *k,uint32_t serial,uint32_t dep,uint32_t lat,uint32_t lock,uint32_t group) {
    assert(d==expected && k==keyboard && serial==5 && dep==1 && lat==2 && lock==3 && group==4);++calls;
}
static void repeat(void *d,struct wl_keyboard *k,int32_t rate,int32_t delay) {
    assert(d==expected && k==keyboard && rate==40 && delay==250);++calls;
}
int main(void) {
    assert(!getenv("LD_PRELOAD"));
    struct wl_keyboard_listener original={keymap,enter,leave,key,modifiers,repeat};
    assert(wl_proxy_add_listener((struct wl_proxy *)keyboard,(void (**)(void))&original,expected)==73);
    assert(errno==EIO);
    captured->keymap(expected,keyboard,1,42,100);
    captured->enter(expected,keyboard,2,surface,&array);
    captured->leave(expected,keyboard,3,surface);
    captured->key(expected,keyboard,4,123,20,1);
    captured->modifiers(expected,keyboard,5,1,2,3,4);
    captured->repeat_info(expected,keyboard,40,250);
    assert(calls==6);
    int fd=timerfd_create(CLOCK_MONOTONIC,TFD_NONBLOCK|TFD_CLOEXEC);assert(fd>=0);
    uint64_t count;errno=0;assert(read(fd,&count,8)==-1 && errno==EAGAIN);
    struct itimerspec timer={.it_value={0,1000000}};
    assert(timerfd_settime(fd,0,&timer,NULL)==0);
    usleep(10000);assert(read(fd,&count,8)==8 && count==1);
    errno=0;assert(timerfd_settime(-1,0,&timer,NULL)==-1 && errno==EBADF);
    assert(close(fd)==0);
    assert(system("test -z \"${LD_PRELOAD+x}\"")==0);
    raise(SIGUSR2);
    puts("listener arguments/data/order/result/errno, timerfd success/errors and child preload exclusion held");
    return 0;
}
