import base64,hashlib,json,os,struct,sys,time

# Read only the passive probe's explicitly named arrays in our disposable VM.
# This does not install a handler, stop a process, or write process memory.
pid=int(sys.argv[1]);assert pid>1
library='/opt/virgl-proof/foot-observer.so'
offsets={'used':0x3440,'overflow':0x3444,'ready':0x4470,'records':0x24470}
maps=[s for s in open('/proc/%d/maps'%pid) if library in s]
assert maps
first=next(s for s in maps if int(s.split()[2],16)==0)
base=int(first.split('-')[0],16)
fd=os.open('/proc/%d/mem'%pid,os.O_RDONLY)
def read(name,size):
    result=os.pread(fd,size,base+offsets[name]);assert len(result)==size
    return result
def number(b):return struct.unpack('<I',b)[0]
def b64(b):return base64.b64encode(b).decode('ascii')
for attempt in range(32):
    started=time.monotonic_ns()
    before=read('used',4);over_before=read('overflow',4);count=number(before)
    assert 0<count<=32768 and number(over_before)==0
    ready1=read('ready',count*4);records1=read('records',count*96)
    middle=read('used',4)
    ready2=read('ready',count*4);records2=read('records',count*96)
    after=read('used',4);over_after=read('overflow',4)
    if (ready1==ready2==struct.pack('<I',1)*count and records1==records2
        and count<=number(middle)<=number(after)<=32768 and number(over_after)==0):
        break
    time.sleep(0.02)
else:raise RuntimeError('No complete stable published prefix')
os.close(fd)
result={'schema':1,'scope':'Read-only remote memory snapshot of our passive probe, not a signal dump or stock acceptance',
 'captureMethod':'os.open O_RDONLY + os.pread; no signal/stop/ptrace/write',
 'pid':pid,'readerUid':os.getuid(),'base':base,'offsets':offsets,'maps':maps,
 'monotonicReadStartNs':started,'monotonicReadEndNs':time.monotonic_ns(),'attempt':attempt,
 'rowBytes':96,'countRows':count,
 'raw':{k:b64(v) for k,v in {'usedBefore':before,'usedMiddle':middle,'usedAfter':after,
     'overflowBefore':over_before,'overflowAfter':over_after,
     'readyFirst':ready1,'readySecond':ready2,'recordsFirst':records1,'recordsSecond':records2}.items()},
 'executableSha256':hashlib.sha256(open('/proc/%d/exe'%pid,'rb').read()).hexdigest(),
 'librarySha256':hashlib.sha256(open(library,'rb').read()).hexdigest()}
print(json.dumps(result,separators=(',',':')))
