from pathlib import Path
import hashlib, json, os, subprocess

repo = Path.cwd()
out = Path(__file__).resolve().parent
image_dir = out / 'image'
image_dir.mkdir(exist_ok=False)
source = repo / 'target/virgl-production/image-12/guest.ext4'
image = image_dir / 'guest.ext4'
def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''): h.update(block)
    return h.hexdigest()
base_sha = sha(source)
assert base_sha == 'f0a72ae2e4433df266fe57dd2443a567dd93396b98c96825b5ce6b3dc4ac9e8c'
subprocess.run(['cp', '-c', str(source), str(image)], check=True)
commands = out / 'image-commands.txt'
commands.write_text('write /work/observer.riscv64 /opt/virgl-proof/stock-keyboard-observer\n'
                    'set_inode_field /opt/virgl-proof/stock-keyboard-observer mode 0100755\n'
                    'write /work/wvm-stock-keyboard.service /etc/systemd/system/wvm-stock-keyboard.service\n'
                    'symlink /etc/systemd/system/multi-user.target.wants/wvm-stock-keyboard.service /etc/systemd/system/wvm-stock-keyboard.service\n')
args = ['docker', 'run', '--rm', '-v', str(image) + ':/disk/guest.ext4',
        '-v', str(out) + ':/work:ro', 'wasm-vm-virgl-reference:1.3.0']
r = subprocess.run(args + ['debugfs', '-w', '-f', '/work/image-commands.txt', '/disk/guest.ext4'],
                   capture_output=True, text=True, check=True)
(out/'image-debugfs.log').write_text(r.stdout+r.stderr)
for src, dst in [('observer.riscv64','/opt/virgl-proof/stock-keyboard-observer'),
                 ('wvm-stock-keyboard.service','/etc/systemd/system/wvm-stock-keyboard.service')]:
    data = subprocess.check_output(args+['debugfs','-R','cat '+dst,'/disk/guest.ext4'], stderr=subprocess.DEVNULL)
    assert data == (out/src).read_bytes(), dst
original = json.loads((repo/'target/virgl-production/image-12/manifest.json').read_text())
chunks = image_dir/'chunks'; chunks.mkdir()
hashes = []; changed = []
with image.open('rb') as f:
    for index, data in enumerate(iter(lambda:f.read(256*1024),b'')):
        h=hashlib.sha256(data).hexdigest();hashes.append(h)
        if h != original['chunks'][index]: changed.append(index)
        dst=chunks/(h+'.bin')
        if dst.exists():continue
        old=repo/'target/virgl-production/image-12/chunks'/dst.name
        if old.exists():os.link(old,dst)
        else:dst.write_bytes(data)
manifest={**original,'chunks':hashes}
(image_dir/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert sha(source)==base_sha
receipt={'scope':'Disposable diagnostic image only, no production claim/publication',
         'changes':'Adds passive evdev observer root service; opens device and then drops to uid/gid1000; no grab, injected events, repeat changes, compositor/user/graphics changes',
         'baseSha256':base_sha,'imageSha256':sha(image),'manifestSha256':sha(image_dir/'manifest.json'),
         'changedChunkIndices':changed,'observerSha256':sha(out/'observer.riscv64'),
         'sourceSha256':sha(out/'observer.c')}
(out/'image-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
