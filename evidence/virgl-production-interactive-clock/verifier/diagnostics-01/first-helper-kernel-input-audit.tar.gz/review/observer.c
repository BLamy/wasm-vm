#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <grp.h>
#include <inttypes.h>
#include <linux/input.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>

static volatile sig_atomic_t done;
static struct row { struct input_event event; uint64_t read_us; } rows[8192];
static size_t used;
static void finish(int signal_number) { (void)signal_number; done = 1; }
static uint64_t monotonic_us(void) {
    struct timespec now;
    if (clock_gettime(CLOCK_MONOTONIC, &now)) return 0;
    return (uint64_t)now.tv_sec * 1000000 + (uint64_t)now.tv_nsec / 1000;
}

int main(void) {
    int fd = -1;
    char path[64], name[256] = {0};
    for (int index = 0; index < 32; index++) {
        unsigned char bits[(KEY_MAX + 8) / 8] = {0};
        snprintf(path, sizeof(path), "/dev/input/event%d", index);
        fd = open(path, O_RDONLY | O_CLOEXEC);
        if (fd < 0) continue;
        if (ioctl(fd, EVIOCGBIT(EV_KEY, sizeof(bits)), bits) >= 0 &&
            (bits[KEY_A / 8] & (1u << (KEY_A % 8))) &&
            (bits[KEY_ENTER / 8] & (1u << (KEY_ENTER % 8)))) break;
        close(fd); fd = -1;
    }
    if (fd < 0) { perror("keyboard evdev open"); return 1; }
    if (ioctl(fd, EVIOCGNAME(sizeof(name)), name) < 0) return 2;
    int clock_id = CLOCK_MONOTONIC;
    if (ioctl(fd, EVIOCSCLOCKID, &clock_id) < 0) return 3;
    int log = open("/tmp/wvm-stock-keyboard.log", O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644);
    int pid = open("/tmp/wvm-stock-keyboard.pid", O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644);
    if (log < 0 || pid < 0) return 4;
    if (setgroups(0, NULL) || setgid(1000) || setuid(1000)) return 5;
    if (getuid() != 1000 || geteuid() != 1000) return 6;
    if (dup2(log, STDOUT_FILENO) < 0) return 7;
    close(log);
    dprintf(pid, "%jd\n", (intmax_t)getpid()); close(pid);
    struct sigaction action = {.sa_handler = finish};
    sigemptyset(&action.sa_mask);
    if (sigaction(SIGUSR1, &action, NULL)) return 8;
    printf("OBSERVER_READY path=%s name=%s uid=%jd mono_us=%" PRIu64 "\n",
           path, name, (intmax_t)getuid(), monotonic_us());
    fflush(stdout);
    int result = 0;
    while (!done) {
        struct input_event events[32];
        ssize_t count = read(fd, events, sizeof(events));
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0 || count % sizeof(events[0])) { result = 9; break; }
        uint64_t observed = monotonic_us();
        for (size_t i = 0; i < (size_t)count / sizeof(events[0]); i++) {
            if (used == sizeof(rows) / sizeof(rows[0])) { result = 10; done = 1; break; }
            rows[used++] = (struct row){.event = events[i], .read_us = observed};
        }
    }
    close(fd);
    for (size_t i = 0; i < used; i++) {
        const struct input_event *e = &rows[i].event;
        printf("EVDEV sec=%jd usec=%jd type=%u code=%u value=%d read_us=%" PRIu64 "\n",
               (intmax_t)e->time.tv_sec, (intmax_t)e->time.tv_usec,
               e->type, e->code, e->value, rows[i].read_us);
    }
    printf("OBSERVER_END count=%zu result=%d mono_us=%" PRIu64 "\n", used, result, monotonic_us());
    return result;
}
