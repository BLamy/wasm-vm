from pathlib import Path
import hashlib,json,subprocess,re
R=Path('target/evidence/critic-paced-keyboard-policy72');B=Path('target/evidence/production-paced-policy-private-window04');G=B/'browser'
sha=lambda b:hashlib.sha256(b).hexdigest()
report=json.loads((B/'report.json').read_text());assert report['status']=='passed' and report['exitCode']==0
pins=[]
for pin in report['files']:
 p=B/pin['path'];data=p.read_bytes();assert len(data)==pin['bytes'] and sha(data)==pin['sha256'];pins.append(pin)
a=json.loads((G/'acceptance.json').read_text());assert a['status']=='passed' and a['hyprland']is True and a['probe']=={'pixels':768,'draws':3}and a['cube']=={'frames':1000}
state=json.loads((G/'final-state.json').read_text());assert state==a['final'] and state['errors']==[]
gpu=state['gpu'];assert gpu['qualified']is True and gpu['lost']is False and gpu['poisoned']is False and gpu['disposed']is False and gpu['lastFailure']is None
c=gpu['counters'];assert c['failed']==c['cancelled']==0 and c['begun']-c['completed']==(1 if gpu['pending'] else 0)
assert c['begun']==3269 and c['completed']==3268 and c['draws']==31192
trace=gpu['guestCommands'];assert trace['dropped']==0
records=trace['records'];assert all(row['response']<0x1200 for row in records)
disp=state['display'];assert disp['drawnPresents']==1439 and disp['errors']==[] and disp['droppedFrames']==0
jit=json.loads((G/'final-jit.json').read_text());assert jit['hasExecutor']is True and jit['executedBlocks']>0 and jit['retiredViaJit']>0
assert json.loads((G/'environment.json').read_text())['crossOriginIsolated']is True
serial=(G/'serial.log').read_text()
for marker in ['TEXTURED_SCENE_END status=pass draws=3 checked_pixels=768','EGL_INDEX_PASS count=83 forbidden=0 gl_error=0x0','GL_CORE_NUMERIC_PASS','GL_REQUIRED_MULTISAMPLE_PASS','GL_MESA_ORIGINAL_RESOLVE_PASS','HYPRLAND_IPC_RC=0','CLIENT_MAPPING_RC=0','GPU rendering verified','Real Mesa + Hyprland on WebGL2']:
 assert marker in serial,marker
assert not re.search(r'\*ERROR\*\s+response\s+0x',serial,re.I)
points=[]
for i,line in enumerate(serial.splitlines(),1):
 if any(m in line for m in ['SCENE_RC=0','EGL_INDEX_PASS','GL_CORE_NUMERIC_PASS','GL_REQUIRED_MULTISAMPLE_PASS','GL_MESA_ORIGINAL_RESOLVE_PASS','Rendered 1000 frames','KMSCUBE_RC=0','HYPRLAND_IPC_RC=0','CLIENT_MAPPING_RC=0','"title": "GPU rendering verified"']):points.append({'line':i,'text':line})
plan=json.loads((B/'plan.json').read_text());sourceRoot=Path(plan['sourceRoot']);assert plan['runtimeHead']=='e17f8caf47712cbbc9ab863f2c161c56432118ad'
bodyPins=json.loads((G/'served-source.json').read_text())
for pin in bodyPins:
 q=sourceRoot/pin['path'];data=q.read_bytes();assert len(data)==pin['bytes']and sha(data)==pin['sha256']
 if pin['path'].startswith('web/'):
  assert data==subprocess.check_output(['git','show','e17f8caf:'+pin['path']])
handshake=json.loads((B/'original-handshake.json').read_text());assert handshake['status']=='passed' and len(handshake['coverage'])==13
assert handshake['guestAcceptanceSha256']==sha((G/'acceptance.json').read_bytes())
assert all(v['guestResponses']>0 and v['referenceCalls']>0 for v in handshake['coverage'].values())
assert handshake['guestFencedSubmissions']==1347
# Record the exact readiness-only harness delta, not a relabeled old run.
harness='7732f9bb09af2355654584d36b8a23094fbc8bff'
patch=subprocess.check_output(['git','diff','fba69588..'+harness,'--','tools/virgl-production/acceptance.mjs'])
assert b'900000' in patch
for p in ['web','crates','renderer','Cargo.toml','Cargo.lock']:assert not subprocess.check_output(['git','diff','e17f8caf..'+harness,'--',p])
(R/'private-ready-budget.patch').write_bytes(patch)
result={'schema':1,'status':'HELD','scope':'Closed missing private functional Mesa/Hyprland/Foot scanout component, original pristine e17product/image with explicitly isolated recording and900000ms bounded hostreadiness','runtimeHead':plan['runtimeHead'],'harnessHead':harness,'reportSha256':sha((B/'report.json').read_bytes()),'authenticatedFiles':pins,'sourceRoot':str(sourceRoot),'servedBodyPins':bodyPins,'serialPoints':points,'guestDigest':a['guestDigest'],'finalGpu':{k:gpu[k]for k in ['qualified','lost','poisoned','disposed','pending','lastFailure','counters']},'allOriginalCoreResponsesPositive':{'records':len(records),'dropped':0,'maxResponse':max(v['response']for v in records)},'display':{'drawnPresents':disp['drawnPresents'],'drawnBytes':disp['drawnBytes'],'errors':[]},'actualJit':{k:jit[k]for k in ['hasExecutor','executedBlocks','retiredViaJit','guestRetired']},'handshake':handshake,'budgetPatchSha256':sha(patch),'visualInspection':'OriginalhyprlandPNGcontainsuprightreadablegreenRealMesa+HyprlandonWebGL2Footline. Warningsaboutminimalrootcompositor/legacyconfigareordinarytestfixtureoutput, notstocksession. BrowserfullPNGisblankcanvasatdifferent/cleanupcapturepoint andisnotusedasrenderproof.','limitations':['Privateinit=/bin/bash/customrootconfigcomponent only. ActualdefaultUID1000/bar/trustedinputisaseparatestockcapture.','Finalactivependingreadyseq0xcc5isonephysicalowner, notdrainedcapture;3269begun/3268completed/31192drawsaretiedtothisfinal-state. LaterfullGPUtracecountersscopeisnotassumed.','Hostdeadline900000msisdocumentedboundedmissingfunctionalproof;originalguesttimeout180unchanged. Both300000msnegativesarepreserved; nocauseorlatency/300MIPSclaim.']}
(R/'private-window04-authentication.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'HELD','fileCount':len(pins),'bodyCount':len(bodyPins),'guestDigest':a['guestDigest'],'records':len(records),'draws':c['draws'],'pending':gpu['pending'],'serialPoints':points,'jit':result['actualJit']},indent=2))
