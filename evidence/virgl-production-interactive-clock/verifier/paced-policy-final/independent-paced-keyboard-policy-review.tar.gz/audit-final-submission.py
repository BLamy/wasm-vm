from pathlib import Path, PurePosixPath
import hashlib, json, math, re, subprocess, tarfile

repo=Path.cwd(); out=repo/'target/evidence/critic-paced-keyboard-policy72'
head='61eeb1b59902c9c52f0c4fdf3880a0081ebb2db2'
base='e17f8caf47712cbbc9ab863f2c161c56432118ad'
wasm='d055c473b686ce543d8b87da68034e240ba0f66cf8aacbb482e03a405a64363f'
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args,cwd=repo): return subprocess.check_output(['git',*args],cwd=cwd).decode().strip()
def pin(p):
 b=p.read_bytes(); return {'path':str(p.relative_to(repo)), 'bytes':len(b),'sha256':sha(b)}
def document(p): return json.loads(p.read_text())
def authenticate(p):
 d=document(p)
 for f in d.get('files',[]):
  b=(p.parent/f['path']).read_bytes(); assert len(b)==f['bytes'] and sha(b)==f['sha256'],(p,f['path'])
 return {'report':pin(p),'authenticatedFiles':len(d.get('files',[])),'status':d.get('status'),'commands':[(c['name'],c['exitCode']) for c in d.get('commands',[])]}

result={'schema':1,'task':'E6-T11d72','prediction':'Final hot and pristine incremental evidence must be frozen61 with all changed-boundary checks passed, exact original Wasm, no alternates, and all sealed member identities intact. Failed earlier wrappers must remain failed.','status':'running','frozenHead':head,'baseStockRuntime':base}
try:
 assert git('rev-parse','HEAD')=='294a570f'+git('rev-parse','HEAD')[8:]
 assert not git('diff','--name-only',head,'HEAD','--','web','crates','renderer','Cargo.toml','Cargo.lock')
 assert not git('diff','--name-only',base,head,'--','crates','renderer','Cargo.toml','Cargo.lock')
 result['submissionHead']=git('rev-parse','HEAD')
 result['postFreezeProductDiff']=[]
 result['nativeRendererDependencyDiff']=[]
 clone=repo/'target/evidence/production-paced-policy-guard-cold01/clone'
 assert git('rev-parse','HEAD',cwd=clone)==head
 assert not git('status','--porcelain','--untracked-files=no',cwd=clone)
 assert not (clone/'.git/objects/info/alternates').exists()
 clone_command=document(clone.parent/'report.json')['commands'][0]['command']
 assert clone_command[:4]==['git','clone','--no-local','--single-branch']
 launch=repo/'target/evidence/production-paced-policy-guard-cold-launch01/run.py'
 launch_text=launch.read_text()
 for required in ["('RUSTFLAGS','RUST_LOG')", "('CARGO_','VIRGL_','CRITIC_')", "['make','web-dist']", "assert not (clone/'.git/objects/info/alternates').exists()"]: assert required in launch_text
 result['coldIsolation']={'head':head,'trackedClean':True,'alternates':False,'ordinaryClone':clone_command,'scrubAndBuildLauncher':pin(launch)}
 result['coldOuter']=authenticate(clone.parent/'report.json')
 assert result['coldOuter']['status']=='passed' and len(result['coldOuter']['commands'])==3 and all(c[1]==0 for c in result['coldOuter']['commands'])
 rows=[]
 for name,folder,source in [('hot',repo/'target/evidence/production-paced-policy-guard-frozen01',repo),('cold',clone.parent/'boundary',clone)]:
  auth=authenticate(folder/'report.json'); d=document(folder/'report.json')
  assert d['head']==head and d['inputBoundaryOnly'] and d['status']=='passed' and len(d['commands'])==4 and all(c['exitCode']==0 for c in d['commands'])
  log=(folder/'clock-protocol.stdout').read_text()
  for suffix in ['tests 89','pass 89','fail 0','skipped 0']: assert suffix in log
  c=document(folder/'worker/clock.json'); assert c['status']=='passed' and not c['errors']
  initial={'mode':'icount','mtime':'0','timebaseHz':10000000,'clockDiv':64}
  assert c['before']==initial and c['retiredBefore']==0
  assert c['selected']==dict(initial,mode='paced-icount') and c['retiredSelected']==0 and c['stillPaused'] is True
  assert c['initialJit']['hasExecutor'] is True and c['initialJit']['guestRetired']==0
  assert len(c['numericRows'])==17
  for r in c['numericRows'][:14]: assert r['accepted'] is False and r['inputBefore']==r['inputAfter'] and r['clock']==initial
  for i,r in enumerate(c['numericRows'][14:]):
   assert r['frame']==[4,4,[-2147483648,-1,2147483647][i]] and r['accepted'] is True and r['clock']==initial
   assert r['inputAfter']['pendingEvents']-r['inputBefore']['pendingEvents']==2 and r['inputAfter']['pendingFrames']-r['inputBefore']['pendingFrames']==1
  assert c['input']['pendingEvents']==10 and c['input']['pendingFrames']==5
  for k in ['droppedEvents','droppedFrames','rejectedEvents']: assert c['input'][k]==0
  g=c['gpu']; assert g['qualified'] is True and g['lost'] is False and g['poisoned'] is False and g['disposed'] is False
  bounds=[]
  for r in c['rows']:
   assert r['beforePause']==r['afterPause'] and r['retired']['beforePause']==r['retired']['afterPause']
   for key in ['beforePause','afterPause','resumed','progressed']:
    assert r[key]['mode']=='paced-icount' and r[key]['clockDiv']==64 and r[key]['timebaseHz']==10000000 and re.fullmatch(r'\d+',r[key]['mtime'])
   assert int(r['progressed']['mtime'])>=int(r['resumed']['mtime'])>=int(r['afterPause']['mtime'])
   assert 0<r['progressReceived']-r['resumeSent']<r['pauseMillis']
   delta=r['retired']['progressed']-r['retired']['afterPause']; assert delta>=0 and delta<2**53
   retirement=(delta+63)//64
   elapsed=r['progressReceived']-r['resumeSent']
   actual=int(r['progressed']['mtime'])-int(r['afterPause']['mtime'])
   maximum=math.ceil(elapsed*10000)+retirement+10000
   assert actual==int(r['bound']['actualTicks']) and retirement==int(r['bound']['retirementTicks']) and maximum==int(r['bound']['maximumTicks']) and actual<=maximum
   bounds.append({'pausedMillis':r['pauseMillis'],'actualTicks':actual,'retirementTicks':retirement,'elapsedMillis':elapsed,'maximumTicks':maximum})
  served=document(folder/'worker/served.json'); assert len(served)==49
  for f in served:
   b=(source/f['path']).read_bytes(); assert len(b)==f['bytes'] and sha(b)==f['sha256']
   assert sha(subprocess.check_output(['git','show',head+':'+f['path']],cwd=repo))==f['sha256']
  assert sha((source/'web/dist/pkg/wasm_vm_wasm_bg.wasm').read_bytes())==wasm
  demo=document(folder/'default/report.json')
  assert demo['gitHead']==head and demo['status']=='passed' and demo['passed']==127 and demo['failed']==0 and demo['errors']==[] and demo['proofExportAbsent'] is True and demo['servedWasmSha256']==wasm
  assert demo['roadmapPip']=='cap-pip live' and demo['graphicsRoadmapPip']=='cap-pip partial'
  for f in demo['served']:
   b=(source/f['path']).read_bytes(); assert len(b)==f['bytes'] and sha(b)==f['sha256']
  rows.append({'name':name,'report':auth,'clock':pin(folder/'worker/clock.json'),'tests':89,'actualNumericRows':17,'malformedRows':14,'signedMscRows':3,'selected':c['selected'],'selectedRetired':0,'stillPaused':True,'pendingUnconsumedEvents':10,'pendingUnconsumedFrames':5,'pauses':bounds,'servedBodies':len(served),'default':pin(folder/'default/report.json'),'defaultPassed':127,'defaultFailed':0,'workerErrors':[],'pageErrors':[]})
 result['finalBoundary']=rows
 a=repo/'evidence/virgl-production-interactive-clock/worker/paced-keyboard-policy-submission.tar.gz'
 assert a.stat().st_size==9318782 and sha(a.read_bytes())=='01f6feaca7b0079b0a4dfa83fc4bdfeb757ca8b258af26c9bd8882273374a37d'
 with tarfile.open(a,'r:gz') as t:
  members=t.getmembers(); assert len(members)==416 and len(set(m.name for m in members))==416
  for m in members: assert m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts
  manifest=json.load(t.extractfile('manifest.json')); assert manifest['head']==head and manifest['baseStockRuntime']==base and manifest['wasmSha256']==wasm
  assert len(manifest['files'])==415 and set(m.name for m in members)=={'manifest.json'}|{f['path'] for f in manifest['files']}
  source_matches=[]
  for f in manifest['files']:
   b=t.extractfile(f['path']).read(); assert len(b)==f['bytes'] and sha(b)==f['sha256']
   if f['path'].startswith('source/'):
    p=f['path'][7:]; assert b==subprocess.check_output(['git','show',head+':'+p],cwd=repo),p;source_matches.append(p)
  expected={'cold-guard/report.json':'passed','cold-guard/boundary/report.json':'passed','cold-original-failed/report.json':'failed','cold-original-failed/acceptance/report.json':'failed','cold-original-failed/acceptance/production/report.json':'failed','production-paced-policy-cold-stock02/report.json':'failed','production-paced-policy-cold-stock02/browser/report.json':'passed','production-paced-policy-private-diagnostic02/report.json':'interrupted-recording-harness','production-paced-policy-private-window04/report.json':'passed'}
  for p,status in expected.items(): assert json.load(t.extractfile(p))['status']==status
  for prefix,path in [('cold-guard',clone.parent),('production-paced-policy-guard-frozen01',repo/'target/evidence/production-paced-policy-guard-frozen01')]:
   for f in manifest['files']:
    if f['path'].startswith(prefix+'/'):
     p=path/f['path'][len(prefix)+1:];assert p.read_bytes()==t.extractfile(f['path']).read()
  result['workerArchive']={**pin(a),'members':416,'authenticatedIdentities':415,'sourceMatchesAtFrozenHead':len(source_matches),'sourcePaths':source_matches,'preservedStatuses':expected,'scope':manifest['scope']}
 result['status']='HELD'
 result['limits']=['The final worker component leaves ten original events in five frames staged; it does not prove Linux consumption.','Valid stock/private/software paths carry independently authenticated e17 results only across the exact guard equivalence and unchanged native/renderer/Wasm boundaries.','Earlier failed and interrupted wrappers remain negative. No whole original wrapper is relabelled passed.','No stock cursor-plane recovery, deployment, full parent or 300-MIPS claim.']
except BaseException as e:
 result['status']='FAILED';result['failure']=repr(e);raise
finally:
 (out/'final-submission-authentication.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'reports':len(rows),'archiveMembers':416,'sourceMatches':len(source_matches),'coldTrackedClean':True,'default':'127/0 both','wasm':wasm}))
