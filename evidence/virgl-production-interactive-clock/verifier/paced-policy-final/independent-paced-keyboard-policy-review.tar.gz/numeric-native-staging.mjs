import {readFileSync,writeFileSync} from 'node:fs';
import vm from 'node:vm';
import {initSync,WasmLinux} from '../../../web/dist/pkg/wasm_vm_wasm.js';
import {createGuestClockLifecycle} from '../../../web/guest-clock.js';
initSync({module:readFileSync(new URL('../../../web/dist/pkg/wasm_vm_wasm_bg.wasm',import.meta.url))});
const loader=readFileSync(new URL('../../../web/loader.js',import.meta.url),'utf8');
const body=loader.match(/      sendKeyboardEvent: \(eventType, code, value\) => \{([\s\S]*?)\n      \},/)?.[1];
if(!body)throw Error('original loader callback notfound');
const kernel=new Uint8Array([0x73,0x00,0x50,0x10,0x6f,0x00,0x00,0x00]);
const rows=[];
for(const code of [30,30.5]) {
  const machine=new WasmLinux(8,kernel,new Uint8Array(),'',()=>{},false);
  try {
    const lifecycle=createGuestClockLifecycle(machine,'icount',64,'paced-on-keyboard');
    const context=vm.createContext({machine,guestClockLifecycle:lifecycle,stopped:false,
      finish(){context.stopped=true;},onState(){},onError(error){console.error('original lifecycle refusal:',error);}});
    const send=vm.runInContext(`(eventType,code,value)=>{${body}\n}`,context);
    const before=machine.guestClockState(),inputBefore=machine.inputDeviceStats();
    let accepted,error;try{accepted=send(1,code,1);machine.syncKeyboard();}catch(e){error=String(e);}
    rows.push({code,before,after:machine.guestClockState(),inputBefore,inputAfter:machine.inputDeviceStats(),accepted,error});
  }finally{machine.free();}
}
writeFileSync(new URL('./numeric-native-staging-result.json',import.meta.url),JSON.stringify({scope:'Original shippingWasm underNode, actualloader callback; noCPUexecution',rows},null,2)+'\n');
console.log(JSON.stringify(rows));
