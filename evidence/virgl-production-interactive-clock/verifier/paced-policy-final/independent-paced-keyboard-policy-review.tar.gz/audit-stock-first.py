from pathlib import Path
import hashlib,json,math,re,subprocess,collections
R=Path('target/evidence/critic-paced-keyboard-policy72');B=Path('target/evidence/production-paced-policy-cold-stock02/browser')
sha=lambda b:hashlib.sha256(b).hexdigest()
record=json.loads((B/'report.json').read_text());s=json.loads((B/'public-desktop-input.json').read_text());final=json.loads((B/'public-desktop-final.json').read_text())
assert record['status']==s['status']=='passed' and record['head']=='e17f8caf47712cbbc9ab863f2c161c56432118ad'
assert s==record['publicDesktopInput'] and final==record['publicDesktopFinal']
assert s['uid']=='1000' and s['interactivePolicy']=='paced-on-keyboard'
assert s['initialClock']=={'mode':'icount','mtime':'931966984','timebaseHz':10000000,'clockDiv':64}
assert s['foot']['pid']==s['immediateFocus']['pid']==s['activeWindow']['pid']==762
assert s['foot']['visible'] is True and s['foot']['acceptsInput'] is True
assert s['typedText']=='touch /tmp/gpukeyboard42touch' and s['options']=={}
e=s['browserInput']['events'];frames=s['browserInput']['frames'];assert len(e)==60 and len(frames)==62
keycodes=[20,24,22,46,35,57,53,20,50,25,53,34,25,22,37,18,21,48,24,30,19,32,5,3,20,24,22,46,35,28]
keys=list(s['typedText'])+['Enter']
assert len(keys)==30 and len(keycodes)==30
holds=[]
for i,(key,code) in enumerate(zip(keys,keycodes)):
 down,up=e[2*i:2*i+2]
 assert down['type']=='keydown' and up['type']=='keyup' and down['key']==up['key']==key
 for v in [down,up]:
  assert v['trusted'] is True and v['repeat'] is False and v['target']==v['focus']=='ide-display-canvas'
  assert not any(v[k]for k in ['shift','ctrl','alt','meta'])
 holds.append(up['time']-down['time'])
 fdown,fup=frames[2+2*i:2+2*i+2]
 assert (fdown['eventType'],fdown['evdev'],fdown['value'],fdown['sync'])==(1,code,1,0)
 assert (fup['eventType'],fup['evdev'],fup['value'],fup['sync'])==(1,code,0,0)
assert [(v['eventType'],v['evdev'],v['value'],v['sync'])for v in frames[:2]]==[(1,69,1,0),(1,69,0,0)]
assert min(holds[:-1])>=50
assert s['browserInput']['held']==[] and s['browserInput']['debug']['lockRepairs']==1
for f in ['inputBefore','inputAfter']:
 for k in ['pendingEvents','pendingFrames','droppedFrames','droppedEvents','rejectedEvents']:assert s[f][k]==0
wire=final['wire'];sends=[v for v in wire if v.get('direction')=='send'and v.get('method')in ['sendKeyboardEvent','syncKeyboard']]
received={v['id']:v for v in wire if v.get('direction')=='receive'and v.get('type')=='result'}
assert len(sends)==124
for i in range(62):assert [v['method']for v in sends[2*i:2*i+2]]==['sendKeyboardEvent','syncKeyboard']
latencies=[]
for v in sends:
 assert v['id']in received and received[v['id']]['time']>=v['time'];latencies.append(received[v['id']]['time']-v['time'])
serial=final['serial'];assert 'touch /tmp/gpukeyboard42touch'not in serial
assert not re.search(r'\*ERROR\*\s+response\s+0x',serial,re.I)
clean=re.sub(r'\x1b\][\s\S]*?(?:\x07|\x1b\\)','',serial)
clean=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',clean).replace('\r','')
blocks={}
for m in re.finditer(r'(?m)^__WVBEGIN_([A-Za-z0-9]+)\n([\s\S]*?)^__WVEND_\1_(\d+)\s*$',clean):
 blocks[m[1]]={'stdout':m[2].strip(),'exit':int(m[3]),'cleanLine':clean[:m.start()].count('\n')+1}
commands={}
for line in clean.splitlines():
 m=re.search(r'__WVBEGIN_([A-Za-z0-9]+)\\n',line)
 if m and ('test -f /tmp/gpukeyboard42touch' in line or 'test ! -e /tmp/gpukeyboard42touch'in line):commands[m[1]]=line
absent=[(tag,blocks[tag]) for tag,line in commands.items()if 'test ! -e'in line]
reads=[(tag,blocks[tag])for tag,line in commands.items()if 'test -f'in line]
assert len(absent)==1 and absent[0][1]['exit']==0 and absent[0][1]['stdout']==''
assert len(reads)==5 and [v[1]['exit']for v in reads]==[1,1,1,1,0]
assert reads[-1][1]['stdout']=='TRUSTED_TOUCH_42'
assert s['markerAbsent']['exit']==0 and s['marker']['exit']==0 and s['marker']['stdout'].strip()=='TRUSTED_TOUCH_42'
coords=tuple(map(int,re.match(r'(\d+),\s*(\d+)',s['cursor']).groups()));assert coords==(430,412)
distance=math.hypot(coords[0]-s['initialCursor']['x'],coords[1]-s['initialCursor']['y']);assert distance>=16
assert abs(coords[0]-s['target']['x'])<=4 and abs(coords[1]-s['target']['y'])<=4
cp=s['clockProbe'];assert cp['beforePause']==cp['afterPause']
assert cp['retired']['beforePause']==cp['retired']['afterPause']
assert all(cp[k]['mode']=='paced-icount'and cp[k]['clockDiv']==64 and cp[k]['timebaseHz']==10000000 for k in ['beforePause','afterPause','resumed','progressed'])
actual=int(cp['progressed']['mtime'])-int(cp['afterPause']['mtime']);elapsed=cp['progressReceived']-cp['resumeSent']
ret=(cp['retired']['progressed']-cp['retired']['afterPause']+63)//64
maximum=math.ceil(elapsed*10000)+ret+10000
assert cp['pauseMillis']>=5000 and elapsed<cp['pauseMillis'] and 0<actual<=maximum
assert cp['bound']=={'actualTicks':str(actual),'maximumTicks':str(maximum),'retirementTicks':str(ret),'elapsedMillis':elapsed}
g=final['gpu'];assert g['qualified'] is True and g['lost'] is False and g['poisoned'] is False and g['disposed'] is False and g['lastFailure']is None and g['pending']is None
assert g['counters']['begun']==g['counters']['completed']==657 and g['counters']['draws']==308
assert g['counters']['failed']==g['counters']['cancelled']==0
assert final['workerErrors']==final['pageErrors']==final['timerGaps']==record['errors']==[]
bar=s['barContent'];assert bar['capture']['bounds']=={'x':0,'y':0,'width':1280,'height':26}
assert bar['layer']['namespace']=='omarchy-bar'and bar['layer']['pid']==773 and bar['layer']['alpha']==1
assert bar['overlappingClients']==[] and len(s['barProbes'])==22
stem='public-desktop-input-bar-content-021';pixels=(B/(stem+'.rgba')).read_bytes();png=(B/(stem+'.png')).read_bytes()
assert len(pixels)==1280*26*4 and sha(pixels)==bar['capture']['rgbaSha256'] and sha(png)==bar['capture']['pngSha256']
# Independent contrast detector plus direct inspection of the exact original PNG.
points=[]
for y in range(2,24):
 for x in range(2,1278):
  i=4*(y*1280+x);rgb=tuple(pixels[i:i+3])
  if pixels[i+3]>=128 and max(abs(a-b)for a,b in zip(rgb,(26,27,38)))>20:points.append((x,y))
assert len(points)>200 and len({p[1]for p in points})>=4 and max(x for x,y in points)-min(x for x,y in points)>1000
blank=(B/'public-desktop-input-bar-content-000.rgba').read_bytes();assert len(blank)==len(pixels)
assert all(tuple(blank[i:i+3])==(26,27,38) for i in range(0,len(blank),4))
# Pure new guard accepts all original frames; removing only the exact new hunk restores old source.
new=Path('web/loader.js').read_text();old=subprocess.check_output(['git','show','e17f8caf:web/loader.js'],text=True)
needle='''        // The Wasm u16/i32 ABI coerces fractions and wraps out-of-range values.
        // Require exact wire integers before either clock eligibility or staging.
        if (!Number.isInteger(eventType) || eventType < 0 || eventType > 0xffff ||
            !Number.isInteger(code) || code < 0 || code > 0xffff ||
            !Number.isInteger(value) || value < -0x80000000 || value > 0x7fffffff) return false;
'''
assert new.count(needle)==1 and new.replace(needle,'',1)==old
for v in frames:
 t,c,x=v['eventType'],v['evdev'],v['value'];assert all(isinstance(z,int)and not isinstance(z,bool) for z in [t,c,x])and 0<=t<=65535 and 0<=c<=65535 and -(2**31)<=x<2**31
carry=[]
for p in ['web/main.js','web/guest-clock.js','web/linux-worker.js','web/linux-worker-protocol.js','web/linux-worker-host.js','web/dist/pkg/wasm_vm_wasm_bg.wasm','crates/core/src/lib.rs','crates/core/src/time.rs','crates/wasm/src/lib.rs']:
 b=Path(p).read_bytes();assert b==subprocess.check_output(['git','show','e17f8caf:'+p]);carry.append({'path':p,'sha256':sha(b)})
# The failed enclosing continuation remains distinct from its passed public subrecord.
outer=json.loads((B.parent/'report.json').read_text());assert outer['status']=='failed' and outer['commands'][0]['exitCode']==0 and outer['commands'][1]['exitCode']==1
files=[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in sorted(B.rglob('*'))if p.is_file()]
result={'schema':1,'status':'HELD','scope':'Closed original stock interaction/publicfinal and valid-frame incrementalcarry; finalnewguardcold/worker seal stillrequired','originalHead':record['head'],'guardHead':'61eeb1b59902c9c52f0c4fdf3880a0081ebb2db2','trustedEvents':60,'originalFrames':62,'literalKeycodesIncludingEnter':keycodes,'firstTHoldMs':holds[0],'textHoldMinMs':min(holds[:-1]),'textHoldMaxMs':max(holds[:-1]),'rpcCalls':124,'rpcMaxRoundtripMs':max(latencies),'rpcCaveat':'RPCcompletion doesnotproveLinuxdeliverytiming; actualmarkerandnativequeuefactsseparatelyrequired. Wire ringdoesnotretainargs; originalonFrame/sourceforwardingchainmatchesliteral62frames.','absentBefore':absent,'markerReads':reads,'cursor':{'initial':s['initialCursor'],'target':s['target'],'actual':coords,'distance':distance,'caveat':'Guesthyprctlposition/visiblecompositedpointer only; hostCursorControllerremainsresource0, nooriginalcursorplane/E6erecoveryclaim.'},'pause':{'pauseMillis':cp['pauseMillis'],'actualTicks':actual,'maximumTicks':maximum,'retirementTicks':ret,'elapsedMillis':elapsed},'gpu':{k:g[k]for k in ['qualified','lost','poisoned','disposed','lastFailure','pending','counters']},'bar':{'reported':bar['content'],'independentContrastPixels':len(points),'rgbaSha256':sha(pixels),'pngSha256':sha(png),'visualInspection':'Directoriginalcrop showsThursday02:53,workspace digits/glyphs andsound/network/displayicons; finaloriginaldesktopPNG showsonecorrecttouchcommandandnewprompt with no repeatedt.'},'unchangedSourcePins':carry,'onlyLoaderDeltaIsPureGuard':True,'all62FramesPassNewGuard':True,'originalFiles':files,'outerFailure':'Originalpublicsubcommandexit0. Enclosingwrapperfaileddefaulttaskallowlistbeforeitsbrowseropened; notrelabeledpassed. Newguardroot/defaultandnewcoldmustsupplymissingdefaultproof.','recordedPreflight':'Oneoriginalserialreadonlyps/tail/unit-statuscontrolbeforetyping; originalimage12/noobserver/preload/config/repeat/typingchange. Request/responseincludedamongfilepins.','note':'Immediate-typedPNGprecedesmarkerpollsandisstilloldprompt; finalpublic-desktop-inputPNGafteractualmarkercontainssinglecorrecttouchcommand. Early21blankbarcropsand4absentmarkerreadchecksretained.'}
(R/'stock-success-and-valid-frame-authentication.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'HELD','firstTHoldMs':holds[0],'rpcMaxRoundtripMs':max(latencies),'cursorDistance':distance,'markerReads':reads,'pause':result['pause'],'barPixels':len(points),'fileCount':len(files),'stockFileSha256':sha((B/'public-desktop-input.json').read_bytes())},indent=2))
