from pathlib import Path
import gzip,hashlib,io,json,tarfile
repo=Path.cwd(); src=repo/'target/evidence/critic-paced-keyboard-policy72'
out=repo/'evidence/virgl-production-interactive-clock/verifier/paced-policy-final';out.mkdir(parents=True,exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads((src/p).read_text())
assert read('final-submission-authentication.json')['status']=='HELD'
pre=read('pre-data-predictions.json')
results={
'A1':('HELD',['frontend-and-worker-authentication.json','report.json','final-submission-authentication.json'],'Exact accelerated ephemeral Omarchy selection, realm receiver/API admission and original prefetch ordering are covered by the independent extracted production-body tests and selected89; software/persist/no-worker branches retain their prior behavior.'),
'A2':('HELD after repair',['numeric-native-staging-result.json','keyboard-abi-report.json','final-submission-authentication.json','stock-success-and-valid-frame-authentication.json'],'The original fractional-code claim FAILED: actual shippingWasm admitted code30.5 as30 without selection. Final pure guard rejects all nonrepresentable u16/u16/i32 fields before lifecycle/native calls. Five independent actual-Wasm tests exercise26 malformed cases acrosspaced/wall/omitted plus exact signedMSC and KEY positives. Original paused lock make ordering/idempotence remains held; all62 realstock frames satisfy the new guard.'),
'A3':('HELD',['report.json','frontend-and-worker-authentication.json','final-submission-authentication.json'],'Stale modes, null/readback drift, thrown selection, stopped/paused/quota barriers and failed rebase paths are covered by actual extracted callbacks and89 selected tests. Real-worker handoff preserves time; no model substitutes for native clock behavior.'),
'A4':('HELD',['frontend-and-worker-authentication.json','final-submission-authentication.json'],'Both final root and pristine hardware workers admit14 invalid-no-effect and3 signedMSC rows, remain paused at mtime0/retired0, then selectpaced before canonical original make. Both served49 exact bodies and ordinaryd055. Ten events/five frames remain staged, explicitly not Linux consumption proof.'),
'A5':('HELD',['report.json','frontend-and-worker-authentication.json','final-submission-authentication.json','stock-success-and-valid-frame-authentication.json'],'Independent nonzero divider-phase and one-excess-tick oracle control, actual root/cold two-pause components, and realstock five-second pause all hold conservative measured-host+ceil(actualretired/divider)+slack bounds; exact paused retirement/time freeze and monotonic progress are checked.'),
'A6':('HELD by explicit incremental components',['cold-software-warm-authentication.json','private-window04-authentication.json','stock-success-and-valid-frame-authentication.json','final-submission-authentication.json'],'Unchanged nominal50ms stock typing creates absent-before marker at originalserial5577 after four failed read-only marker observations, actual bar021 and210px guest cursor move. FinalGPU657/657,308draws,no pending/errors. All10 software phases, actualMesa/cube/Hypr/Foot and13-family handshake hold. Original private300000ms negatives remain failed; bounded900000ms missing-path component holds without latency claim. Final exact guard clone rebuild/89tests/17workerrows/default127/0 closes changed input boundary; valid-domain equivalence carries the original stock/private results.'),
'A7':('HELD',['handoff-negative-report.json','keyboard-abi-negative-report.json','final-submission-authentication.json'],'Single-hunk handoff removal fails selected paused-lock ordering, and ABI-guard removal fails the first actual-Wasm fractional-type row; originals remain unchanged. Earlier taskwall repeats, timeouts, recording interruptions and faileddefault-option wrapper remain genuine negatives, not silently retried positive evidence.')}
predictions=[]
for p in pre['predictions']:
 status,evidence,observation=results[p['id']];predictions.append({**p,'outcome':status,'evidence':evidence,'observation':observation})
ledger={
'schema':1,'task':'E6-T11d72','verdict':'verified','frozenHead':'61eeb1b59902c9c52f0c4fdf3880a0081ebb2db2','workerSubmissionHead':'294a570f','baseStockRuntime':'e17f8caf47712cbbc9ab863f2c161c56432118ad','predictions':predictions,
'coverage':[
 {'hunk':'web/guest-clock.js:4-29 mode/realm/policy admission','classification':'executed','proof':'Independent directpaced exactrealm/API/prefetch tests; selected89 hot and cold, wrongsource/API/label negatives.'},
 {'hunk':'web/guest-clock.js:59-111 API shape, mutablemode, pre-key selection/readback, pause/resume','classification':'executed','proof':'Independent lock/quota/readback/failure/lifecycle controls; original productionworker pausedhandoff, repeatedpause; nativeD73 carried unchanged. Compatibilitywall tests remain executed.'},
 {'hunk':'web/loader.js:1207-1216 exact ABI guard before lifecycle and forwarding','classification':'executed','proof':'Actual ordinaryWasm26malformedcases×3policies, signedMSC and omittedKEY positives; finalhardware17rows plus validmake and untouchedstock62frame domain equivalence.'},
 {'hunk':'web/main.js:2102 default policy','classification':'executed','proof':'Independent actual bootOmarchy sourcebody scope tests; originaldefaultimage12UID1000 stock startsICount thenpaced; actualsoftware warm paths omitpolicy.'},
 {'hunk':'tools/virgl-production/critic-fast-boots-final.mjs:39 retirement-aware oracle and input-final snapshot','classification':'executed','proof':'Independent phase37 oracle boundary and excess-tick refusal; realstock five-second pause/postinputfinalGPU; root/cold two measuredpauseintervals. Rawstate retained before assertions.'},
 {'hunk':'tools/virgl-production/browser.mjs rootCOOP/COEP/JIT custody; acceptance.mjs readiness budget','classification':'executed','proof':'Actual pairedisolation admissionfalse/true atretired0; corrected realJIT execution retained. Private03stillfails300000ms, privatewindow04succeeds900000ms with allsemanticassertions unchanged. No exclusivecause/latency claim.'},
 {'hunk':'tools/virgl-production/interactive-clock-worker.mjs, verify-interactive-clock.py, default-task72 allowlist','classification':'executed','proof':'Finalhot+newpristine ownbuild each4gates0/89tests/17rows/default127/0; ownservedsourcehashverification. Earlier outerwrapperdefaultoptionfailure preserved.'},
 {'hunk':'web/tests/* D72 and protocol/oracle tests','classification':'executed','proof':'Final89 selected tests pass and skipped0; independent7policy+5actualWasm tests promoted byte-for-byte. Isolated controls fail semantically.'},
 {'hunk':'docs/timekeeping.md and task/roadmap wording','classification':'waived as declarative metadata','proof':'No executableclock semantics. Defaultdemo checks liveISApip/partialgraphics; no recovery/deployment/300MIPS completion advertised.'},
 {'hunk':'web/dist generated mirrors and SW','classification':'executed generated bytes','proof':'Finalroot/cold servedbodypins matchfrozen61objects; sources matchgeneratedloader/clock/main; rebuilt ordinaryWasm remainsd055.'}
],
'preservedLimits':[
 'Originale17 fullcold wrapper failedprivate readiness; its passed selected/native/software prefixes are components, not a passed full wrapper.',
 'Private03 corrected-isolation readiness timeout remains negative and refutes an exclusive header-fix explanation. Private04 proves functional rendering within the longer bounded window, not performance.',
 'Originalstock browser report passes; its outerdefault-task allowlist failure remains failed. Finalroot/cold default127/0 is separate missing-path proof.',
 'The independent audit initially expected TAP # labels while Node emitted Unicode summary labels; the preserved audit-preparation failure was fixed only in the reader. No product run changed.',
 'Original helper nominaldelay50ms unchanged. Observed firstT51.825ms and range49.550..52.345ms are retained; no invented exactminimum50ms condition.',
 'Finalstock hostCursor resource0/hidden does not prove cursor-plane/recovery. Guest cursor displacement is the D72 claim.',
 'Private finalstate31192draws/3269begun/3268complete/one pendingready is not a drained-owner assertion; laterfulltrace31516DRAWpackets is a different point.',
 'No finalD71,parentD,E6erecovery,deployment,300MIPS or completeoffload verdict here.'
],
'suite':[{'path':'web/tests/e6-t11d72-paced-policy-critic.test.mjs','tests':7,'sha256':'56f628cd8d48cfe6825cec980838144112e1ec2e03a42bf464928ae897db4e17'},{'path':'web/tests/e6-t11d72-keyboard-abi-critic.test.mjs','tests':5,'sha256':'26bab2706a66a646a202651f60caebb3ee632486a42aac33f3bbe97ae7c96746'}],
'unchangedNativeCarry':{'task':'E6-T11d73','verifierCommit':'7e2739f28b9c539be894ecd8f693cf743c35258e','ordinaryWasmSha256':'d055c473b686ce543d8b87da68034e240ba0f66cf8aacbb482e03a405a64363f','archive':'evidence/virgl-production-paced-idle-clock/verifier/independent-paced-idle-clock-review.tar.gz','sha256':'496e53dbccffd922e1fd63287cf1b2038f62f3abd6c82ef360eadac35935a14f'},
'workerArchive':read('final-submission-authentication.json')['workerArchive'],
'commands':['node --test target/evidence/critic-paced-keyboard-policy72/paced-policy-critic.test.mjs','node --test target/evidence/critic-paced-keyboard-policy72/keyboard-abi-critic.test.mjs','Original recorded isolated controls in handoff-negative-report.json and keyboard-abi-negative-report.json','python3 target/evidence/critic-paced-keyboard-policy72/audit-private-component.py','python3 target/evidence/critic-paced-keyboard-policy72/audit-stock-and-carry.py','python3 target/evidence/critic-paced-keyboard-policy72/audit-final-submission.py']}
(src/'prediction-and-coverage.json').write_text(json.dumps(ledger,indent=2)+'\n')
(src/'audit-preparation-classification.json').write_text(json.dumps({'scope':'Verifier reader only','initial':'audit-final-submission-initial.py expected # tests89 TAP labels','observed':'Actual unchanged Node output uses Unicode info labels; counts89/89/0/skip0 are exact','repair':'Reader matches summary fieldstrings without imposing reporter prefix; no product/evidence source changed','files':['audit-final-submission-initial.py','final-submission-authentication-initial.json','audit-final-submission.py','final-submission-authentication.json']},indent=2)+'\n')
files=[]
for p in sorted(src.rglob('*')):
 if not p.is_file():continue
 assert not p.is_symlink()
 b=p.read_bytes();files.append({'path':str(p.relative_to(src)),'bytes':len(b),'sha256':sha(b)})
manifest={'schema':1,'task':'E6-T11d72','verdict':'verified','frozenHead':ledger['frozenHead'],'scope':'Independent paced-policy review, originalnumeric coercion negative and repairedguard tests, explicit heldcomponent/valid-domain carry, authenticated finalroot+pristine guard proof; noD71/parent/recovery/deployment verdict','workerArchive':ledger['workerArchive'],'files':files}
m=(json.dumps(manifest,indent=2)+'\n').encode();archive=out/'independent-paced-keyboard-policy-review.tar.gz'
with archive.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as g:
  with tarfile.open(fileobj=g,mode='w') as t:
   for name,b in [('manifest.json',m)]+[(r['path'],(src/r['path']).read_bytes()) for r in files]:
    info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as t:
 assert len(t.getmembers())==len(files)+1 and t.extractfile('manifest.json').read()==m
 for row in files:
  b=t.extractfile(row['path']).read();assert len(b)==row['bytes'] and sha(b)==row['sha256']
receipt={'schema':1,'task':'E6-T11d72','verdict':'verified','path':str(archive.relative_to(repo)),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'membersReopened':len(files)+1,'identities':len(files),'manifestSha256':sha(m),'files':files}
(archive.with_suffix('').with_suffix('.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='files'}))
