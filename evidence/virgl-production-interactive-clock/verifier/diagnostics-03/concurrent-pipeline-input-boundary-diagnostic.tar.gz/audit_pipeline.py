#!/usr/bin/env python3
"""Independent, read-only audit of our diagnostic03 published memory prefixes.

This does not import the worker parser, operate the VM, or infer socket delivery
from Wayland serialization.  All outputs go to the critic's evidence directory.
"""
import argparse
import base64
import collections
import hashlib
import json
from pathlib import Path
import re
import struct
import zlib

LIBRARY = "d03b8ce36e1ba2082482d9093d9e6a7962649ff1f1fa098e19e3b94b9ba7e941"
EXECUTABLES = {
    "foot": "4de65e70b1ef4fd293640678687c7b348f3f33d3a8db963344d99cf3115b5416",
    "compositor": "7e95fa01b98b0d1670c247cf687e7da4996ae112a5d6b303ce9137c13c4bfca1",
}
OFFSETS = {"used": 13328, "overflow": 13332, "ready": 17592, "records": 279736}
KINDS = set(range(1, 12)) | {20, 21, 22, 30, 31, 32, 40, 41, 50, 51, 52, 53}


def digest(body):
    return hashlib.sha256(body).hexdigest()


def identity(path):
    body = path.read_bytes()
    return {"path": str(path), "bytes": len(body), "sha256": digest(body)}


def word32(raw):
    assert len(raw) == 4
    return struct.unpack("<I", raw)[0]


def audit_role(path, role, output):
    envelope = json.loads(path.read_bytes())
    result = envelope.get("result", envelope)
    assert result["exit"] == 0, (role, "guest command failed", result)
    wrapped = json.loads(result["stdout"])
    assert wrapped["encoding"] == "zlib-base64"
    assert isinstance(wrapped["bytes"], int) and 0 < wrapped["bytes"] < 20_000_000
    packed = base64.b64decode(wrapped["data"], validate=True)
    stream = zlib.decompressobj()
    payload = stream.decompress(packed, 20_000_001)
    assert stream.eof and not stream.unused_data and not stream.unconsumed_tail
    assert len(payload) == wrapped["bytes"] and digest(payload) == wrapped["sha256"]
    memory = json.loads(payload)
    assert memory["schema"] == 1 and memory["rowBytes"] == 96
    assert memory["offsets"] == OFFSETS
    assert memory["executableSha256"] == EXECUTABLES[role]
    assert memory["librarySha256"] == LIBRARY
    count = memory["countRows"]
    assert isinstance(count, int) and 0 < count <= 65536
    assert isinstance(memory["pid"], int) and memory["pid"] > 1
    assert memory["readerUid"] == 1000
    assert 0 <= memory["attempt"] < 32
    assert 0 < memory["monotonicReadStartNs"] <= memory["monotonicReadEndNs"]
    raw = {key: base64.b64decode(value, validate=True) for key, value in memory["raw"].items()}
    assert set(raw) == {"usedBefore", "usedMiddle", "usedAfter", "overflowBefore", "overflowAfter",
                        "readyFirst", "readySecond", "recordsFirst", "recordsSecond"}
    before, middle, after = [word32(raw[key]) for key in ("usedBefore", "usedMiddle", "usedAfter")]
    assert count == before <= middle <= after <= 65536
    assert word32(raw["overflowBefore"]) == word32(raw["overflowAfter"]) == 0
    assert raw["readyFirst"] == raw["readySecond"] == struct.pack("<I", 1) * count
    assert len(raw["recordsFirst"]) == count * 96
    assert raw["recordsFirst"] == raw["recordsSecond"]
    initial_mapping = []
    for line in memory["maps"]:
        fields = line.split()
        assert fields[-1] == "/opt/virgl-proof/input-pipeline-observer.so"
        if int(fields[2], 16) == 0:
            initial_mapping.append(line)
            assert int(fields[0].split("-")[0], 16) == memory["base"]
    assert len(initial_mapping) == 1
    rows = []
    for ordinal, fields in enumerate(struct.iter_unpack("<12Q", raw["recordsFirst"])):
        kind, mono, cpu, tid, *args = fields
        assert kind in KINDS, (role, ordinal, "unknown record kind", kind)
        assert mono > 0 and cpu > 0 and tid > 1
        rows.append({"index": ordinal, "type": kind, "monoNs": mono, "cpuNs": cpu,
                     "tid": tid, "args": args})
    ready = [row for row in rows if row["type"] == 1]
    expected_role = 1 if role == "foot" else 2
    assert len(ready) == 1 and ready[0]["args"][:3] == [memory["pid"], 1000, expected_role]
    assert ready[0]["tid"] == memory["pid"]
    per_thread = collections.defaultdict(list)
    for row in rows:
        per_thread[row["tid"]].append(row)
    reversed_clocks = []
    for tid, own in per_thread.items():
        for first, second in zip(own, own[1:]):
            if first["monoNs"] > second["monoNs"] or first["cpuNs"] > second["cpuNs"]:
                reversed_clocks.append({"tid": tid, "first": first, "second": second})
    output.mkdir(parents=True, exist_ok=True)
    (output / (role + ".published.json")).write_bytes(payload)
    (output / (role + ".records.bin")).write_bytes(raw["recordsFirst"])
    (output / (role + ".rows.jsonl")).write_text("".join(json.dumps(row, separators=(",", ":")) + "\n" for row in rows))
    return memory, rows, {"role": role, "source": identity(path), "count": count,
                          "pid": memory["pid"], "used": [before, middle, after],
                          "payloadBytes": len(payload), "payloadSha256": digest(payload),
                          "packedBytes": len(packed), "recordsSha256": digest(raw["recordsFirst"]),
                          "kinds": dict(sorted(collections.Counter(r["type"] for r in rows).items())),
                          "threadIds": sorted(per_thread), "reversedPerThreadClocks": reversed_clocks}


def key_fields(row, role):
    a = row["args"]
    if role == "client":
        return (a[1], a[2], a[3], a[4])  # serial, source milliseconds, code, state
    return (a[1], a[2], a[3], a[4])


def native_calls(rows):
    """Pair the actually intercepted calls per thread; never invent a return."""
    names = {31: "libinput_dispatch", 40: "wl_display_flush_clients",
             50: "wl_display_read_events", 52: "wl_display_dispatch_pending"}
    returns = {32: 31, 41: 40, 51: 50, 53: 52}
    stacks = collections.defaultdict(list)
    pairs, issues = [], []
    for row in rows:
        kind, tid = row["type"], row["tid"]
        if kind in names:
            stacks[tid].append(row)
        elif kind in returns:
            if not stacks[tid]:
                issues.append({"kind": "return-without-entry", "row": row})
                continue
            entry = stacks[tid][-1]
            if entry["type"] != returns[kind] or entry["args"][0] != row["args"][0]:
                issues.append({"kind": "return-context-mismatch", "entry": entry, "return": row})
                continue
            stacks[tid].pop()
            call = {"name": names[entry["type"]], "entry": entry, "return": row,
                    "monoDurationNs": row["monoNs"] - entry["monoNs"],
                    "threadCpuNs": row["cpuNs"] - entry["cpuNs"]}
            if entry["type"] != 40:
                unsigned = row["args"][1]
                call["signedResult"] = unsigned if unsigned < 2**63 else unsigned - 2**64
                call["errnoAfter"] = row["args"][2]
                call["errnoMeaningfulForFailure"] = call["signedResult"] < 0
            pairs.append(call)
    return {"matched": pairs, "issues": issues,
            "openAtPrefixEnd": [entry for stack in stacks.values() for entry in stack]}


def analyze(browser, output):
    foot_memory, foot, foot_summary = audit_role(browser / "foot-memory-response.json", "foot", output)
    comp_memory, comp, comp_summary = audit_role(browser / "compositor-memory-response.json", "compositor", output)
    assert foot_memory["pid"] != comp_memory["pid"]
    input_path = browser / "public-desktop-input.json"
    inp = json.loads(input_path.read_bytes())
    assert inp["foot"]["pid"] == foot_memory["pid"]
    frames = inp["browserInput"]["frames"]
    expected = [(int(row["evdev"]), int(row["value"])) for row in frames if int(row["eventType"]) == 1]
    # Independent literal command/key map; the actual frames are not their own oracle.
    literal = "touch /tmp/gpukeyboard42touch"
    assert inp["typedText"] == literal
    keymap = {"t": 20, "o": 24, "u": 22, "c": 46, "h": 35, " ": 57,
              "/": 53, "m": 50, "p": 25, "g": 34, "k": 37, "e": 18,
              "y": 21, "b": 48, "a": 30, "r": 19, "d": 32, "4": 5, "2": 3}
    literal_codes = [keymap[character] for character in literal] + [28]
    literal_frames = [(code, state) for code in literal_codes for state in (1, 0)]
    assert expected in (literal_frames, [(69, 1), (69, 0)] + literal_frames)
    assert all(int(row["eventType"]) == 1 and int(row["sync"]) == 0 for row in frames)
    dom = inp["browserInput"]["events"]
    assert len(dom) == len(literal_frames)
    dom_holds = []
    for ordinal, character in enumerate(list(literal) + ["Enter"]):
        make, release = dom[ordinal * 2:ordinal * 2 + 2]
        assert make["type"] == "keydown" and release["type"] == "keyup"
        assert make["key"] == release["key"] == character
        assert make["code"] == release["code"]
        assert all(row["trusted"] and not row["repeat"] for row in (make, release))
        assert all(not row[modifier] for row in (make, release) for modifier in ("shift", "ctrl", "alt", "meta"))
        assert 0 < release["time"] - make["time"]
        dom_holds.append({"character": character, "code": make["code"], "makeMs": make["time"],
                          "breakMs": release["time"], "holdMs": release["time"] - make["time"]})
    obs_path = browser / "observer-dump.json"
    obs = json.loads(obs_path.read_bytes())
    result = obs.get("result", obs)
    assert result["exit"] == 0
    text = result["stdout"]
    kernel = []
    raw_rows = 0
    for line_no, line in enumerate(text.split("\n"), 1):
        if not line.startswith("EVDEV"):
            continue
        match = re.fullmatch(r"EVDEV sec=(-?\d+) usec=(-?\d+) type=(\d+) code=(\d+) value=(-?\d+) read_us=(\d+)", line)
        assert match, (line_no, line)
        raw_rows += 1
        sec, usec, kind, code, value, read_us = map(int, match.groups())
        assert sec >= 0 and 0 <= usec < 1000000
        if kind == 1:
            kernel.append({"stdoutLine": line_no, "sourceUs": sec * 1000000 + usec,
                           "code": code, "state": value, "observerReadUs": read_us})
    ends = re.findall(r"^OBSERVER_END count=(\d+) result=(\d+) mono_us=(\d+)$", text, re.M)
    assert len(ends) == 1 and int(ends[0][0]) == raw_rows and int(ends[0][1]) == 0
    assert [(r["code"], r["state"]) for r in kernel] == expected
    backend = [row for row in comp if row["type"] == 30]
    emitted_all = [row for row in comp if row["type"] == 20]
    emitted = [row for row in emitted_all if row["args"][5] == foot_memory["pid"]]
    client = [row for row in foot if row["type"] == 3]
    returned = [row for row in foot if row["type"] == 4]
    loggers = [row for row in comp if row["type"] == 22]
    assert loggers and all(row["args"][0] and row["args"][1] for row in loggers)
    assert len(kernel) == len(backend) == len(emitted) == len(client) == len(returned)
    assert all(row["args"][1] == 300 for row in backend)
    chains = []
    for ordinal, (k, b, e, c, ret) in enumerate(zip(kernel, backend, emitted, client, returned)):
        assert (b["args"][2], b["args"][3], b["args"][4]) == (k["sourceUs"], k["code"], k["state"])
        assert e["args"][6] == 1000
        assert key_fields(e, "server") == key_fields(c, "client") == key_fields(ret, "client")
        assert c["args"][2:5] == [k["sourceUs"] // 1000 % (2**32), k["code"], k["state"]]
        assert c["args"][0] == ret["args"][0] and c["tid"] == ret["tid"]
        assert b["monoNs"] <= e["monoNs"] <= c["monoNs"] <= ret["monoNs"]
        chains.append({"ordinal": ordinal, "kernel": k, "backend": b, "serialized": e,
                       "client": c, "clientReturn": ret,
                       "kernelToBackendNs": b["monoNs"] - k["sourceUs"] * 1000,
                       "backendToSerializationNs": e["monoNs"] - b["monoNs"],
                       "serializationToCallbackNs": c["monoNs"] - e["monoNs"],
                       "callbackNs": ret["monoNs"] - c["monoNs"]})
    assert chains
    first_make = next(row for row in chains if row["kernel"]["code"] == 20 and row["kernel"]["state"] == 1)
    first_break = next(row for row in chains[first_make["ordinal"] + 1:] if row["kernel"]["code"] == 20 and row["kernel"]["state"] == 0)
    selected = {"make": first_make, "break": first_break}
    for name, row in selected.items():
        c = row["client"]
        e = row["serialized"]
        row["clientContextBefore"] = [r for r in foot if r["index"] < c["index"]][-16:]
        row["clientContextAfter"] = [r for r in foot if r["index"] > c["index"]][:16]
        row["serverContextBefore"] = [r for r in comp if r["index"] < e["index"]][-12:]
        row["serverContextAfter"] = [r for r in comp if r["index"] > e["index"]][:12]
    holds = {}
    for boundary in ("kernel", "backend", "serialized", "client"):
        key = "sourceUs" if boundary == "kernel" else "monoNs"
        scale = 1000 if boundary == "kernel" else 1
        holds[boundary + "HoldNs"] = (first_break[boundary][key] - first_make[boundary][key]) * scale
    result = {
        "schema": 1, "scope": "Passive scheduling-altered diagnostic only, never a stock acceptance verdict",
        "roles": [foot_summary, comp_summary], "inputIdentity": identity(input_path), "observerIdentity": identity(obs_path),
        "inputStatus": inp.get("status"), "typedText": inp.get("typedText"), "marker": inp.get("marker"),
        "literalOracle": {"command": literal, "evdevCodes": literal_codes, "frames": expected,
                          "trustedDomHolds": dom_holds, "held": inp["browserInput"].get("held"),
                          "stats": inp["browserInput"].get("stats")},
        "matchingKeyCount": len(chains), "allServerEmissions": len(emitted_all),
        "targetPid": foot_memory["pid"], "compositorPid": comp_memory["pid"], "loggers": loggers,
        "holds": holds, "firstT": selected, "chains": chains,
        "focusEntries": [r for r in foot if r["type"] == 10], "focusLeaves": [r for r in foot if r["type"] == 11],
        "repeatInfo": [r for r in foot if r["type"] == 5],
        "nativeCalls": {"foot": native_calls(foot), "compositor": native_calls(comp)},
        "limits": ["Protocol logger locates serialization, not successful socket delivery.",
                   "A void flush return cannot attest an individual client's write.",
                   "Only positive intercepted calls are measured; an absent hook does not prove absence of a native call.",
                   "Thread CPU compares only one PID/TID. Probe and observer scheduling differs from stock."]}
    (output / "pipeline-audit.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"roles": result["roles"], "matchingKeyCount": result["matchingKeyCount"],
                      "inputStatus": result["inputStatus"], "holds": holds}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("browser", type=Path)
    parser.add_argument("output", type=Path)
    arguments = parser.parse_args()
    analyze(arguments.browser, arguments.output)
