#!/usr/bin/env python3
"""Independent integer timer bound on authenticated recorded diagnostic rows."""
import argparse,json,hashlib
from collections import defaultdict
from pathlib import Path

def signed(value):return value-(1<<64) if value>=(1<<63) else value

def bounds(rows):
    generation=defaultdict(int);created={};pending=defaultdict(list);active={}
    checked=[];excluded=[];arms=[]
    for row in rows:
        kind=row["type"];a=row["args"];tid=row["tid"];index=row["index"]
        if kind==6:
            fd=signed(a[0])
            if fd>=0:
                generation[fd]+=1
                created[fd]={"fd":fd,"generation":generation[fd],"clockid":signed(a[1]),"index":index}
                active.pop(fd,None)
        elif kind==7:pending[(tid,signed(a[0]))].append(row)
        elif kind==8:
            fd=signed(a[0]);stack=pending[(tid,fd)]
            if not stack:
                excluded.append({"index":index,"reason":"unmatched arm return","fd":fd});continue
            before=stack.pop()
            if signed(a[1])!=0:continue
            args=before["args"]
            new={"fd":fd,"generation":created.get(fd),"enterIndex":before["index"],"returnIndex":index,"tid":tid,"armEnterMonoNs":before["mono_ns"],"armReturnMonoNs":row["mono_ns"],"flags":args[1],"initialNs":args[2]*1000000000+args[3],"intervalNs":args[4]*1000000000+args[5],"count":0,"ambiguous":any(other_fd==fd and entries for (other_tid,other_fd),entries in pending.items())}
            active[fd]=new;arms.append(new)
        elif kind==9:
            fd=signed(a[0]);state=active.get(fd)
            if state is None:
                excluded.append({"index":index,"fd":fd,"reason":"no successful observed arm"});continue
            state["count"]+=a[1]
            if any(other_fd==fd and entries for (other_tid,other_fd),entries in pending.items()) or state["tid"]!=tid:
                state["ambiguous"]=True
            reason=None
            if state["ambiguous"]:reason="cross-thread/overlapping arm-read ordering"
            elif not state["generation"] or state["generation"]["clockid"]!=1:reason="unknown generation or non-MONOTONIC clock"
            elif state["flags"]!=0:reason="nonrelative timer arm"
            elif not state["armEnterMonoNs"] or row["mono_ns"]<state["armReturnMonoNs"]:reason="bad/zero monotonic clock"
            if reason:
                excluded.append({"index":index,"fd":fd,"reason":reason,"count":a[1]});continue
            elapsed=row["mono_ns"]-state["armEnterMonoNs"]
            initial=state["initialNs"];interval=state["intervalNs"]
            if not initial:upper=0
            elif not interval:upper=int(elapsed>=initial)
            else:upper=max(0,1+(elapsed-initial)//interval)
            checked.append({"index":index,"fd":fd,"generation":state["generation"],"tid":tid,"armEnterIndex":state["enterIndex"],"armReturnIndex":state["returnIndex"],"armEnterMonoNs":state["armEnterMonoNs"],"postReadMonoNs":row["mono_ns"],"elapsedUpperNs":elapsed,"initialNs":initial,"intervalNs":interval,"readCount":a[1],"cumulativeCount":state["count"],"maximumExpirations":upper,"held":state["count"]<=upper})
    return {"successfulArms":len(arms),"checkedReads":checked,"excludedReads":excluded,"violations":[row for row in checked if not row["held"]]}

def main():
    parser=argparse.ArgumentParser();parser.add_argument("decoded",type=Path);parser.add_argument("output",type=Path)
    args=parser.parse_args();raw=args.decoded.read_bytes();d=json.loads(raw)
    results=[]
    for process in d["processes"]:
        for ordinal,frame in enumerate(process.get("frames",[])):
            if not frame["complete"]:
                results.append({"pid":process["pid"],"frame":ordinal,"status":"NEEDS EVIDENCE incomplete/overflow frame"});continue
            results.append({"pid":process["pid"],"frame":ordinal,"status":"bounded recorded rows only",**bounds(frame["records"])})
    out={"schema":1,"scope":"Diagnostic counts only; a bounded count is not a stock-positive or exclusive cause proof","source":{"path":str(args.decoded),"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()},"results":results}
    args.output.write_text(json.dumps(out,indent=2)+"\n")
    print(json.dumps({"path":str(args.output),"sha256":hashlib.sha256(args.output.read_bytes()).hexdigest(),"rows":[{"pid":v["pid"],"frame":v["frame"],"checked":len(v.get("checkedReads",[])),"excluded":len(v.get("excludedReads",[])),"violations":len(v.get("violations",[]))} for v in results]}))

if __name__=="__main__":main()
