#!/usr/bin/env python3
"""Read-only original diagnostic-event audit. Does not run or alter any VM."""
import argparse, collections, hashlib, json, re
from pathlib import Path

def identity(path):
    body=path.read_bytes()
    return {"path":str(path),"bytes":len(body),"sha256":hashlib.sha256(body).hexdigest()}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("browser",type=Path)
    parser.add_argument("output",type=Path)
    args=parser.parse_args()
    source=args.browser/"observer-dump.json"
    doc=json.loads(source.read_text())
    stdout=doc.get("stdout",doc.get("result",{}).get("stdout",""))
    ready=re.findall(r"^OBSERVER_READY path=(\S+) name=(.*?) uid=(\d+) mono_us=(\d+)$",stdout,re.M)
    end=re.findall(r"^OBSERVER_END count=(\d+) result=(\d+) mono_us=(\d+)$",stdout,re.M)
    rows=[]
    malformed=[]
    for line_number,line in enumerate(stdout.split("\n"),1):
        if not line.startswith("EVDEV"):
            continue
        match=re.fullmatch(r"EVDEV sec=(-?\d+) usec=(-?\d+) type=(\d+) code=(\d+) value=(-?\d+) read_us=(\d+)",line)
        if not match:
            malformed.append({"line":line_number,"text":line})
            continue
        sec,usec,kind,code,value,read_us=map(int,match.groups())
        event_us=sec*1000000+usec
        rows.append({"line":line_number,"sec":sec,"usec":usec,"type":kind,"code":code,"value":value,"event_us":event_us,"read_us":read_us,"read_lag_us":read_us-event_us})
    inp_path=args.browser/"public-desktop-input.json"
    inp=json.loads(inp_path.read_text())
    frame=inp.get("browserInput",{}).get("frames",[])
    expected=[(int(v["eventType"]),int(v["evdev"]),int(v["value"])) for v in frame]
    keys=[v for v in rows if v["type"]==1]
    nonrepeat=[(v["type"],v["code"],v["value"]) for v in keys if v["value"]!=2]
    mismatch=[]
    for i in range(max(len(expected),len(nonrepeat))):
        a=expected[i] if i<len(expected) else None
        b=nonrepeat[i] if i<len(nonrepeat) else None
        if a!=b:mismatch.append({"ordinal":i,"expected":a,"observed":b})
    expected_packets=[item for kind,code,value in expected for item in ((kind,code,value),(0,0,0))]
    observed_packets=[(v["type"],v["code"],v["value"]) for v in rows]
    packet_mismatch=[]
    for i in range(max(len(expected_packets),len(observed_packets))):
        a=expected_packets[i] if i<len(expected_packets) else None
        b=observed_packets[i] if i<len(observed_packets) else None
        if a!=b:packet_mismatch.append({"ordinal":i,"expected":a,"observed":b})
    down={}
    intervals=[]
    anomalies=[]
    for index,row in enumerate(keys):
        code=row["code"]
        if row["value"]==1:
            if code in down:anomalies.append({"kind":"duplicate-make","index":index,"previous":down[code],"row":row})
            down[code]=row
        elif row["value"]==0:
            start=down.pop(code,None)
            if start is None:anomalies.append({"kind":"break-without-make","index":index,"row":row})
            else:intervals.append({"code":code,"make_line":start["line"],"break_line":row["line"],"make_us":start["event_us"],"break_us":row["event_us"],"hold_us":row["event_us"]-start["event_us"],"make_read_lag_us":start["read_lag_us"],"break_read_lag_us":row["read_lag_us"]})
    syn_dropped=[v for v in rows if v["type"]==0 and v["code"]==3]
    key_counts=collections.Counter(v["value"] for v in keys)
    result={
      "schema":1,"scope":"Diagnostic observer only; does not discharge original untouched-stock refutation",
      "identities":[identity(source),identity(inp_path)],
      "producerExit":doc.get("exit",doc.get("result",{}).get("exit")),
      "ready":ready,"end":end,"rows":len(rows),"malformed":malformed,
      "complete":len(ready)==1 and len(end)==1 and int(end[0][0])==len(rows) and int(end[0][1])==0 and not malformed,
      "keyValueCounts":dict(key_counts),"syncCounts":dict(collections.Counter(v["code"] for v in rows if v["type"]==0)),
      "synDropped":syn_dropped,"frameCount":len(expected),"kernelKeyCountExcludingRepeats":len(nonrepeat),"frameMismatch":mismatch,"nominalPacketsExpected":len(expected_packets),"nominalPacketMismatch":packet_mismatch,
      "eventTimesValid":all(v["sec"]>=0 and 0<=v["usec"]<1000000 and v["read_us"]>0 and v["read_lag_us"]>=0 for v in rows),
      "eventTimesMonotonic":all(a["event_us"]<=b["event_us"] for a,b in zip(rows,rows[1:])),
      "intervals":intervals,"unreleased":down,"keyAnomalies":anomalies,
      "kernelRepeatRows":[v for v in keys if v["value"]==2],
      "rowsExact":rows,
      "interpretation":"Kernel event/read timestamps share this accepted CLOCK_MONOTONIC client. Compare actual intervals with observed Wayland repeat_info, not an assumed package default. Extra reader/service/client timing is diagnostic."
    }
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({key:result[key] for key in ("scope","complete","producerExit","rows","keyValueCounts","syncCounts","frameCount","kernelKeyCountExcludingRepeats","eventTimesValid","eventTimesMonotonic","frameMismatch","keyAnomalies")}))

if __name__=="__main__":main()
