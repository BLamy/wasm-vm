#include <assert.h>
#include <errno.h>
#include <wayland-client.h>
#include <wayland-server-core.h>
extern const struct wl_keyboard_listener *captured;
extern void *expected;
extern struct wl_keyboard *keyboard;
const char *wl_proxy_get_class(struct wl_proxy *proxy) {
    assert(proxy==(struct wl_proxy *)keyboard);return "wl_keyboard";
}
int wl_proxy_add_listener(struct wl_proxy *proxy, void (**listener)(void), void *data) {
    assert(proxy==(struct wl_proxy *)keyboard && data==expected);
    captured=(const struct wl_keyboard_listener *)listener;errno=EIO;return 73;
}

unsigned creates,flushes,reads,dispatches,lib_dispatches,gets;
static wl_protocol_logger_func_t logger_cb;
static void *logger_data;
struct wl_display *wl_display_create(void) { ++creates;errno=EBUSY;return (void*)0x1111; }
struct wl_protocol_logger *wl_display_add_protocol_logger(struct wl_display *d,wl_protocol_logger_func_t cb,void *data) {
 assert(d==(void*)0x1111);logger_cb=cb;logger_data=data;return (void*)0x1122;
}
const char *wl_resource_get_class(const struct wl_resource *r) { return r==(void*)0x2222?"wl_keyboard":"wl_pointer"; }
struct wl_client *wl_resource_get_client(struct wl_resource *r) { (void)r;return (void*)0x4444; }
uint32_t wl_resource_get_id(const struct wl_resource *r) { (void)r;return 27; }
void wl_client_get_credentials(const struct wl_client *c,pid_t *p,uid_t *u,gid_t *g) { assert(c==(void*)0x4444);*p=777;*u=1000;*g=1000; }
void wl_display_flush_clients(struct wl_display *d) { assert(d==(void*)0x1111);++flushes;errno=ENOTTY; }
int wl_display_read_events(struct wl_display *d) { assert(d==(void*)0x1111);++reads;errno=EAGAIN;return -1; }
int wl_display_dispatch_pending(struct wl_display *d) { assert(d==(void*)0x1111);++dispatches;errno=EIO;return 7; }
struct libinput;struct libinput_event;struct libinput_event_keyboard;
int libinput_dispatch(struct libinput *p) { assert(p==(void*)0x6666);++lib_dispatches;errno=EFAULT;return -1; }
struct libinput_event *libinput_get_event(struct libinput *p) { assert(p==(void*)0x6666);++gets;errno=EINTR;return (void*)0x5555; }
int libinput_event_get_type(struct libinput_event *e) { assert(e==(void*)0x5555);return 300; }
struct libinput_event_keyboard *libinput_event_get_keyboard_event(struct libinput_event *e) { assert(e==(void*)0x5555);return (void*)0x7777; }
uint64_t libinput_event_keyboard_get_time_usec(struct libinput_event_keyboard *e) { assert(e==(void*)0x7777);return 123456; }
uint32_t libinput_event_keyboard_get_key(struct libinput_event_keyboard *e) { assert(e==(void*)0x7777);return 20; }
int libinput_event_keyboard_get_key_state(struct libinput_event_keyboard *e) { assert(e==(void*)0x7777);return 0; }
void emit_fixture(int expected) {
 assert((logger_cb!=0)==expected);if(!logger_cb)return;
 union wl_argument a[4]={{.u=99},{.u=123},{.u=20},{.u=0}};
 struct wl_protocol_logger_message m={.resource=(void*)0x2222,.message_opcode=3,.arguments_count=4,.arguments=a};
 errno=ENOSPC;logger_cb(logger_data,WL_PROTOCOL_LOGGER_EVENT,&m);assert(errno==ENOSPC);
 a[1].o=0;m.resource=(void*)0x3333;m.message_opcode=0;
 logger_cb(logger_data,WL_PROTOCOL_LOGGER_REQUEST,&m);assert(errno==ENOSPC);
}
