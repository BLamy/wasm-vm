#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/timerfd.h>
#include <time.h>
#include <unistd.h>
#include <wayland-client.h>
#include <wayland-server-core.h>

/* Diagnostic only. Never injects input or changes repeat/timer parameters.
 * Each record is 12 little-endian uint64s. Events stay buffered for a separately authenticated read-only /proc memory snapshot.
 * Installs no signal handlers (Foot owns SIGUSR2 itself).
 * 1 ready, 2 keyboard listener, 3 key-enter, 4 key-return, 5 repeat_info,
 * 6 timer create, 7 timer arm-enter, 8 timer arm-return, 9 timer read,
 * 10 keyboard focus enter, 11 keyboard focus leave.
 * Clock domains are the actual guest CLOCK_MONOTONIC and THREAD_CPUTIME_ID. */
struct record { uint64_t field[12]; };
enum { LIMIT = 65536, KEYBOARDS = 8, FDS = 4096 };
/* Remote readers are outside this translation unit; keep every published row. */
static volatile struct record records[LIMIT];
static _Atomic unsigned used;
static _Atomic unsigned ready[LIMIT];
static _Atomic unsigned overflow;
static _Atomic unsigned char timer_fds[FDS];
static unsigned probe_role;
static ssize_t (*real_read)(int, void *, size_t);
static int (*real_create)(int, int);
static int (*real_arm)(int, int, const struct itimerspec *, struct itimerspec *);
static int (*real_close)(int);
static int (*real_listener)(struct wl_proxy *, void (**)(void), void *);
struct keyboard {
    struct wl_proxy *proxy;
    struct wl_keyboard_listener original;
    struct wl_keyboard_listener wrapped;
};
static struct keyboard keyboards[KEYBOARDS];

static uint64_t nanos(clockid_t id) {
    struct timespec t = {0};
    clock_gettime(id, &t);
    return (uint64_t)t.tv_sec * 1000000000ULL + (uint64_t)t.tv_nsec;
}
static void note(uint64_t type, uint64_t a, uint64_t b, uint64_t c,
                 uint64_t d, uint64_t e, uint64_t f, uint64_t g, uint64_t h) {
    int saved = errno;
    unsigned i = atomic_fetch_add(&used, 1);
    if (i >= LIMIT) { atomic_fetch_add(&overflow, 1); errno = saved; return; }
    records[i] = (struct record){{type, nanos(CLOCK_MONOTONIC),
        nanos(CLOCK_THREAD_CPUTIME_ID), (uint64_t)gettid(), a,b,c,d,e,f,g,h}};
    atomic_store_explicit(&ready[i], 1, memory_order_release);
    errno = saved;
}
__attribute__((constructor)) static void init(void) {
    const char *role=getenv("WVM_PROBE_ROLE");
    if (!role) _exit(120);
    probe_role=!strcmp(role,"foot")?1:!strcmp(role,"compositor")?2:0;
    if (!probe_role) _exit(120);
    unsetenv("LD_PRELOAD");unsetenv("WVM_PROBE_ROLE");
    real_read = dlsym(RTLD_NEXT, "read");
    real_create = dlsym(RTLD_NEXT, "timerfd_create");
    real_arm = dlsym(RTLD_NEXT, "timerfd_settime");
    real_close = dlsym(RTLD_NEXT, "close");
    real_listener = dlsym(RTLD_NEXT, "wl_proxy_add_listener");
    if (!real_read || !real_create || !real_arm || !real_close) _exit(121);
    note(1,getpid(),getuid(),probe_role,0,0,0,0,0);
}
static struct keyboard *find(struct wl_keyboard *kbd) {
    for (unsigned i = 0; i < KEYBOARDS; ++i)
        if (keyboards[i].proxy == (struct wl_proxy *)kbd) return &keyboards[i];
    _exit(123);
}
static void keymap(void *data, struct wl_keyboard *kbd, uint32_t fmt, int32_t fd, uint32_t size) {
    find(kbd)->original.keymap(data,kbd,fmt,fd,size);
}
static void enter(void *data, struct wl_keyboard *kbd, uint32_t serial, struct wl_surface *surface, struct wl_array *keys) {
    note(10,(uintptr_t)kbd,serial,keys->size,0,0,0,0,0);
    find(kbd)->original.enter(data,kbd,serial,surface,keys);
}
static void leave(void *data, struct wl_keyboard *kbd, uint32_t serial, struct wl_surface *surface) {
    note(11,(uintptr_t)kbd,serial,0,0,0,0,0,0);
    find(kbd)->original.leave(data,kbd,serial,surface);
}
static void key(void *data, struct wl_keyboard *kbd, uint32_t serial, uint32_t time, uint32_t code, uint32_t state) {
    note(3,(uintptr_t)kbd,serial,time,code,state,0,0,0);
    find(kbd)->original.key(data,kbd,serial,time,code,state);
    note(4,(uintptr_t)kbd,serial,time,code,state,0,0,0);
}
static void modifiers(void *data, struct wl_keyboard *kbd, uint32_t serial, uint32_t depressed, uint32_t latched, uint32_t locked, uint32_t group) {
    find(kbd)->original.modifiers(data,kbd,serial,depressed,latched,locked,group);
}
static void repeat(void *data, struct wl_keyboard *kbd, int32_t rate, int32_t delay) {
    note(5,(uintptr_t)kbd,(uint32_t)rate,(uint32_t)delay,0,0,0,0,0);
    if (find(kbd)->original.repeat_info) find(kbd)->original.repeat_info(data,kbd,rate,delay);
}
int wl_proxy_add_listener(struct wl_proxy *proxy, void (**listener)(void), void *data) {
    if (!real_listener) real_listener = dlsym(RTLD_NEXT, "wl_proxy_add_listener");
    if (strcmp(wl_proxy_get_class(proxy), "wl_keyboard")) return real_listener(proxy,listener,data);
    struct keyboard *slot = NULL;
    for (unsigned i = 0; i < KEYBOARDS; ++i) if (!keyboards[i].proxy) { slot=&keyboards[i];break; }
    if (!slot) _exit(124);
    slot->proxy=proxy;
    memcpy(&slot->original,listener,sizeof(slot->original));
    slot->wrapped=(struct wl_keyboard_listener){keymap,enter,leave,key,modifiers,repeat};
    note(2,(uintptr_t)proxy,0,0,0,0,0,0,0);
    return real_listener(proxy,(void (**)(void))&slot->wrapped,data);
}
int timerfd_create(int clockid, int flags) {
    if (!real_create) real_create=dlsym(RTLD_NEXT,"timerfd_create");
    int fd=real_create(clockid,flags), saved=errno;
    if (fd>=0 && fd<FDS) timer_fds[fd]=1;
    if (probe_role==1) note(6,fd,clockid,flags,0,0,0,0,0);
    errno=saved;return fd;
}
int timerfd_settime(int fd, int flags, const struct itimerspec *value, struct itimerspec *old) {
    if (!real_arm) real_arm=dlsym(RTLD_NEXT,"timerfd_settime");
    if (probe_role==1) note(7,fd,flags,value->it_value.tv_sec,value->it_value.tv_nsec,
         value->it_interval.tv_sec,value->it_interval.tv_nsec,0,0);
    int result=real_arm(fd,flags,value,old), saved=errno;
    if (probe_role==1) note(8,fd,(uint64_t)(int64_t)result,saved,0,0,0,0,0);
    errno=saved;return result;
}
ssize_t read(int fd, void *data, size_t size) {
    if (!real_read) real_read=dlsym(RTLD_NEXT,"read");
    ssize_t result=real_read(fd,data,size);int saved=errno;
    if (probe_role==1 && fd>=0 && fd<FDS && timer_fds[fd] && result==8) {
        uint64_t count;memcpy(&count,data,8);note(9,fd,count,0,0,0,0,0,0);
    }
    errno=saved;return result;
}
int close(int fd) {
    if (!real_close) real_close=dlsym(RTLD_NEXT,"close");
    if (fd>=0 && fd<FDS) timer_fds[fd]=0;
    return real_close(fd);
}

/* Server record20: wl_keyboard.key serialization (resource,serial,source_ms,
 * key,state,client_pid,client_uid,resource_id).
 * Server21: wl_pointer.set_cursor request (serial,surface,hotx,hoty,pid,uid,id).
 * Server22: logger attached. Backend30: returned keyboard event (event,type,
 * source_us,key,state).31/32: libinput_dispatch entry/return.
 * Server40/41: flush_clients entry/return. Client50/51: read_events entry/return;
 * client52/53: dispatch_pending entry/return. Native calls remain once/in order. */
static const char *(*resource_class)(const struct wl_resource *);
static struct wl_client *(*resource_client)(struct wl_resource *);
static uint32_t (*resource_id)(const struct wl_resource *);
static void (*client_credentials)(const struct wl_client *,pid_t *,uid_t *,gid_t *);
static void protocol_log(void *data, enum wl_protocol_logger_type direction,
                         const struct wl_protocol_logger_message *m) {
    (void)data;int saved=errno;
    const char *name=resource_class(m->resource);
    if ((direction==WL_PROTOCOL_LOGGER_EVENT && m->message_opcode==3 &&
         m->arguments_count==4 && !strcmp(name,"wl_keyboard")) ||
        (direction==WL_PROTOCOL_LOGGER_REQUEST && m->message_opcode==0 &&
         m->arguments_count==4 && !strcmp(name,"wl_pointer"))) {
        pid_t pid=0;uid_t uid=0;gid_t gid=0;
        client_credentials(resource_client(m->resource),&pid,&uid,&gid);
        const union wl_argument *a=m->arguments;
        if (direction==WL_PROTOCOL_LOGGER_EVENT)
            note(20,(uintptr_t)m->resource,a[0].u,a[1].u,a[2].u,a[3].u,
                 pid,uid,resource_id(m->resource));
        else
            note(21,a[0].u,(uintptr_t)a[1].o,(uint32_t)a[2].i,(uint32_t)a[3].i,
                 pid,uid,resource_id(m->resource),0);
    }
    errno=saved;
}
struct wl_display *wl_display_create(void) {
    int incoming=errno;
    struct wl_display *(*original)(void)=dlsym(RTLD_NEXT,"wl_display_create");
    struct wl_protocol_logger *(*add)(struct wl_display *,wl_protocol_logger_func_t,void *)=
        dlsym(RTLD_NEXT,"wl_display_add_protocol_logger");
    resource_class=dlsym(RTLD_NEXT,"wl_resource_get_class");
    resource_client=dlsym(RTLD_NEXT,"wl_resource_get_client");
    resource_id=dlsym(RTLD_NEXT,"wl_resource_get_id");
    client_credentials=dlsym(RTLD_NEXT,"wl_client_get_credentials");
    if (!original || !add || !resource_class || !resource_client || !resource_id || !client_credentials) _exit(125);
    errno=incoming;struct wl_display *display=original();int saved=errno;
    if (display && probe_role==2) {
        struct wl_protocol_logger *logger=add(display,protocol_log,NULL);
        note(22,(uintptr_t)display,(uintptr_t)logger,0,0,0,0,0,0);
    }
    errno=saved;return display;
}
void wl_display_flush_clients(struct wl_display *display) {
    int incoming=errno;
    static void (*original)(struct wl_display *);
    if (!original) original=dlsym(RTLD_NEXT,"wl_display_flush_clients");
    if (!original) _exit(126);
    int saved=incoming;
    if (probe_role==2) note(40,(uintptr_t)display,0,0,0,0,0,0,0);
    errno=saved;original(display);saved=errno;
    if (probe_role==2) note(41,(uintptr_t)display,0,0,0,0,0,0,0);
    errno=saved;
}
int wl_display_read_events(struct wl_display *display) {
    int incoming=errno;
    static int (*original)(struct wl_display *);
    if (!original) original=dlsym(RTLD_NEXT,"wl_display_read_events");
    if (!original) _exit(127);
    int saved=incoming;
    if (probe_role==1) note(50,(uintptr_t)display,0,0,0,0,0,0,0);
    errno=saved;int result=original(display);saved=errno;
    if (probe_role==1) note(51,(uintptr_t)display,(uint64_t)(int64_t)result,saved,0,0,0,0,0);
    errno=saved;return result;
}
int wl_display_dispatch_pending(struct wl_display *display) {
    int incoming=errno;
    static int (*original)(struct wl_display *);
    if (!original) original=dlsym(RTLD_NEXT,"wl_display_dispatch_pending");
    if (!original) _exit(128);
    int saved=incoming;
    if (probe_role==1) note(52,(uintptr_t)display,0,0,0,0,0,0,0);
    errno=saved;int result=original(display);saved=errno;
    if (probe_role==1) note(53,(uintptr_t)display,(uint64_t)(int64_t)result,saved,0,0,0,0,0);
    errno=saved;return result;
}
struct libinput;
struct libinput_event;
struct libinput_event_keyboard;
int libinput_dispatch(struct libinput *input) {
    int incoming=errno;
    static int (*original)(struct libinput *);
    if (!original) original=dlsym(RTLD_NEXT,"libinput_dispatch");
    if (!original) _exit(129);
    int saved=incoming;
    if (probe_role==2) note(31,(uintptr_t)input,0,0,0,0,0,0,0);
    errno=saved;int result=original(input);saved=errno;
    if (probe_role==2) note(32,(uintptr_t)input,(uint64_t)(int64_t)result,saved,0,0,0,0,0);
    errno=saved;return result;
}
struct libinput_event *libinput_get_event(struct libinput *input) {
    int incoming=errno;
    static struct libinput_event *(*original)(struct libinput *);
    static int (*type)(struct libinput_event *);
    static struct libinput_event_keyboard *(*keyboard_event)(struct libinput_event *);
    static uint64_t (*event_time)(struct libinput_event_keyboard *);
    static uint32_t (*event_key)(struct libinput_event_keyboard *);
    static int (*event_state)(struct libinput_event_keyboard *);
    if (!original) {
        original=dlsym(RTLD_NEXT,"libinput_get_event");
        type=dlsym(RTLD_NEXT,"libinput_event_get_type");
        keyboard_event=dlsym(RTLD_NEXT,"libinput_event_get_keyboard_event");
        event_time=dlsym(RTLD_NEXT,"libinput_event_keyboard_get_time_usec");
        event_key=dlsym(RTLD_NEXT,"libinput_event_keyboard_get_key");
        event_state=dlsym(RTLD_NEXT,"libinput_event_keyboard_get_key_state");
    }
    if (!original || !type || !keyboard_event || !event_time || !event_key || !event_state) _exit(130);
    errno=incoming;struct libinput_event *event=original(input);int saved=errno;
    if (event && probe_role==2 && type(event)==300) {
        struct libinput_event_keyboard *key=keyboard_event(event);
        note(30,(uintptr_t)event,300,event_time(key),event_key(key),event_state(key),0,0,0);
    }
    errno=saved;return event;
}
