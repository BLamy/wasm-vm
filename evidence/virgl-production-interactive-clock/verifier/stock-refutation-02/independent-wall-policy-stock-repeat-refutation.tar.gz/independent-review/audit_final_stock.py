from pathlib import Path
import json,hashlib,subprocess,sys,re,math,datetime,urllib.parse
repo=Path.cwd(); source=Path(sys.argv[1]).resolve(); out=Path(sys.argv[2]).resolve()
RUNTIME="97021186ba6b1274edc4d9f50b2005a1a034d77d"; HARNESS="4619a4d11007f3d6bc221e67048b074c8f4eafeb"
WASM="a653fe3a4828fb46e4ced12668174c71e8d817a5bf5611117f17da3008a6aa82"
def pin(f):
 b=f.read_bytes();return {"path":str(f.relative_to(repo)),"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
r=json.loads((source/"report.json").read_text());assert r["status"]=="passed",r.get("errors")
assert r["head"]==HARNESS and r["errors"]==[] and r["gpuTrace"] is False
assert r["sourceHashes"]["pkg/wasm_vm_wasm_bg.wasm"]==WASM
for name,digest in r["sourceHashes"].items():
 b=subprocess.check_output(["git","show",RUNTIME+":web/dist/"+name],cwd=repo)
 assert hashlib.sha256(b).hexdigest()==digest,name
for name,digest in r["harnessHashes"].items():
 b=subprocess.check_output(["git","show",HARNESS+":tools/virgl-production/"+name],cwd=repo)
 assert hashlib.sha256(b).hexdigest()==digest,name
assert len(r["phases"])==1
phase=r["phases"][0];assert phase["phase"]=="omarchy-initial" and phase["result"]["exit"]==0
query=urllib.parse.parse_qs(urllib.parse.urlparse(phase["url"]).query)
assert query["guest"]==["omarchy"] and query["gpu"]==["1"] and query["desktop"]==["1"]
assert not set(query).intersection({"testHooks","gpuTrace"})
assert any(x["pathname"]=="/guest-clock.js" and x["status"]==200 for x in r["requests"])
assert len([x for x in r["requests"] if x["pathname"]=="/app"])==1,"unexpected document restart"
s=json.loads((source/"public-desktop-final.json").read_text());assert s==r["publicDesktopFinal"]
assert s["workerErrors"]==[] and s["pageErrors"]==[]
assert not re.search(r"\*ERROR\*\s+response\s+0x[0-9a-f]+",s["serial"],re.I)
assert s["restored"] is False and s["ready"] is True and s["overlayHidden"] is True
assert len(s["workers"])==1
opts=s["workers"][0]["options"]
assert opts["virgl"] is True and opts["guestClock"]=="icount" and opts["icountDivider"]==64
assert opts["interactiveClock"]=="wall-on-keyboard" and opts["bootSnapshot"] is False
assert not opts.get("gpuTrace",False)
g=s["gpu"];c=g["counters"]
for key,value in {"qualified":True,"lost":False,"poisoned":False,"disposed":False,"lastFailure":None}.items():assert g[key]==value,(key,g[key])
assert c["failed"]==c["cancelled"]==0 and c["completed"]>0 and c["draws"]>0
assert c["begun"]-c["completed"]==(1 if g["pending"] else 0)
i=json.loads((source/"public-desktop-input.json").read_text());assert i==r["publicDesktopInput"]
assert i["status"]=="passed" and i["uid"]=="1000"
assert i["initialClock"]["mode"]=="icount" and i["initialClock"]["clockDiv"]==64
assert i["interactivePolicy"]=="wall-on-keyboard"
assert i["typedText"]=="touch /tmp/gpukeyboard42touch"
assert i["markerAbsent"]["exit"]==0 and i["marker"]["exit"]==0 and i["marker"]["stdout"].strip()=="TRUSTED_TOUCH_42"
assert i["foot"]["pid"]==i["immediateFocus"]["pid"] and i["immediateFocus"]["class"]=="foot"
assert i["immediateFocus"]["visible"] is True and i["immediateFocus"]["acceptsInput"] is True
b=i["browserInput"];events=b["events"];frames=b["frames"]
assert b["focus"]=="ide-display-canvas" and b["capture"]=="on" and b["held"]==[]
assert b["clock"]["mode"]=="wall"
for k in ["pendingEvents","pendingFrames","droppedFrames","droppedEvents","rejectedEvents"]:assert b["stats"][k]==0,(k,b["stats"][k])
keys=["KeyT","KeyO","KeyU","KeyC","KeyH","Space","Slash","KeyT","KeyM","KeyP","Slash","KeyG","KeyP","KeyU","KeyK","KeyE","KeyY","KeyB","KeyO","KeyA","KeyR","KeyD","Digit4","Digit2","KeyT","KeyO","KeyU","KeyC","KeyH","Enter"]
evdev=[20,24,22,46,35,57,53,20,50,25,53,34,25,22,37,18,21,48,24,30,19,32,5,3,20,24,22,46,35,28]
expected=[(t,key) for key in keys for t in ["keydown","keyup"]]
assert [(e["type"],e["code"]) for e in events[-60:]]==expected
assert all(e["trusted"] is True and e["repeat"] is False and e["target"]=="ide-display-canvas" and e["focus"]=="ide-display-canvas" and not any(e.get(k,False) for k in ["shift","ctrl","alt","meta"]) for e in events)
prefix=events[:-60];assert len(prefix)%2==0 and all((prefix[n]["type"],prefix[n]["code"],prefix[n+1]["type"],prefix[n+1]["code"])==("keydown","Escape","keyup","Escape") for n in range(0,len(prefix),2))
code_numbers=dict(zip(keys,evdev));code_numbers["Escape"]=1
lock_numbers={"NumLock":69,"CapsLock":58,"ScrollLock":70}
logical_frames=[];repair_frames=[];at=0;event_at=0
while at<len(frames):
 f=frames[at]
 if event_at<len(events) and f["code"]==events[event_at]["code"]:
  e=events[event_at]
  assert (f["eventType"],f["evdev"],f["value"],f["sync"])==(1,code_numbers[e["code"]],1 if e["type"]=="keydown" else 0,0)
  logical_frames.append(f);event_at+=1;at+=1;continue
 assert f["code"] in lock_numbers and at+1<len(frames),f
 z=frames[at+1]
 assert z["code"]==f["code"] and f["evdev"]==z["evdev"]==lock_numbers[f["code"]]
 assert (f["eventType"],f["value"],f["sync"],z["eventType"],z["value"],z["sync"])==(1,1,0,1,0,0)
 repair_frames.extend([f,z]);at+=2
assert event_at==len(events) and len(repair_frames)==2*b["debug"]["lockRepairs"]
assert b["debug"]["held"]==[] and b["debug"]["pendingLockRepairs"]==[]
holds=[events[-60:][n+1]["time"]-events[-60:][n]["time"] for n in range(0,58,2)]
assert all(h>=40 for h in holds),holds
x,y=map(int,i["cursor"].split(","));initial=i["initialCursor"];target=i["target"]
assert abs(x-target["x"])<=4 and abs(y-target["y"])<=4 and math.hypot(x-initial["x"],y-initial["y"])>=16
probe=i["clockProbe"]
for key in ["beforePause","afterPause","resumed","progressed"]:
 clock=probe[key];assert clock["mode"]=="wall" and clock["timebaseHz"]==10000000 and isinstance(clock["mtime"],str) and re.fullmatch("[0-9]+",clock["mtime"])
after=int(probe["afterPause"]["mtime"]);resumed=int(probe["resumed"]["mtime"]);progress=int(probe["progressed"]["mtime"])
assert after==int(probe["beforePause"]["mtime"]) and after<=resumed<=progress
elapsed=probe["progressReceived"]-probe["resumeSent"];ticks=progress-after;maximum=math.ceil(elapsed*10000)+10000
assert 0<elapsed<probe["pauseMillis"] and 0<ticks<=maximum
bar=i["barContent"];assert bar["status"]=="passed" and bar["overlappingClients"]==[] and bar["layer"]["namespace"]=="omarchy-bar"
passed=[v for v in i["barProbes"] if v["status"]=="passed"];assert len(passed)==1
crop=source/(passed[0]["name"]+".rgba");png=source/(passed[0]["name"]+".png")
assert pin(crop)["sha256"]==bar["capture"]["rgbaSha256"] and pin(png)["sha256"]==bar["capture"]["pngSha256"]
assert not bar["overlappingClients"]
result={"status":"HELD numerical and original-ledger audit; exact images require separate visual inspection","checkedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"runtimeHead":RUNTIME,"harnessHead":HARNESS,"source":str(source),"files":[pin(source/"report.json"),pin(source/"public-desktop-final.json"),pin(source/"public-desktop-input.json"),pin(crop),pin(png)],"workerOptions":opts,"gpuCounters":c,"gpuPending":g["pending"],"rawSerialBytes":len(s["serial"].encode()),"trustedEvents":len(events),"escapePrefixEvents":len(prefix),"originalFrames":len(frames),"originalLockRepairFrames":repair_frames,"logicalFrames":len(logical_frames),"printableHoldMsRange":[min(holds),max(holds)],"markerAbsent":i["markerAbsent"],"marker":i["marker"],"initialCursor":initial,"target":target,"actualCursor":{"x":x,"y":y},"clockProbe":{"pauseMillis":probe["pauseMillis"],"elapsedMillis":elapsed,"actualTicks":str(ticks),"maximumTicks":str(maximum)},"bar":bar,"inputStats":b["stats"],"limits":["Final active snapshot is not zero-owner shutdown proof.","No live deployment, parent/recovery or throughput verdict."]}
out.write_text(json.dumps(result,indent=2)+"\n");print(json.dumps({"audit":pin(out),"marker":i["marker"],"gpu":c,"ticks":ticks,"bound":maximum,"barForeground":bar["content"]["foregroundPixels"]},indent=2))
