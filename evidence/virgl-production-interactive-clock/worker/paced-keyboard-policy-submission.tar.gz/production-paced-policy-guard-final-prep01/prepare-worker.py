from pathlib import Path
repo=Path.cwd()
s=(repo/'target/evidence/production-paced-policy-worker01/actual-worker.mjs').read_text()
s=s.replace('const repo='+repr(str(repo))+';',"const repo=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');")
s=s.replace("from '"+(repo/'tools/virgl-production/critic-fast-boots-final.mjs').as_uri()+"';","from './critic-fast-boots-final.mjs';")
s=s.replace("const output=path.resolve(process.argv[2]),mode=process.argv[3]??'qualify';","assert.equal(process.argv.length,3);\nconst output=path.resolve(process.argv[2]);")
s=s.replace("  try {\n    const name=new URL(req.url,'http://localhost').pathname;","  try {\n    res.setHeader('Cross-Origin-Opener-Policy','same-origin');\n    res.setHeader('Cross-Origin-Embedder-Policy','require-corp');\n    const name=new URL(req.url,'http://localhost').pathname;",1)
a=s.index("  if(mode==='qualify') {");b=s.index("  } else {\n",a)
s=s[:a]+s[b+len('  } else {\n'):]
needle='\n  }\n} finally {';assert s.count(needle)==1;s=s.replace(needle,'\n} finally {',1)
needle='      const paused=await c.isPaused(), before=await read(), retiredBefore=(await c.jitStats()).guestRetired;'
assert s.count(needle)==1
s=s.replace(needle,needle+'''
      const numericRows=[];
      const malformed=[[1,30.5,1],[1.5,30,1],[1,30,1.5],[65537,30,1],
        [1,65566,1],[1,30,0x100000001],[1,30,0x80000000],[1,30,-0x80000001],
        ['1',30,1],[1,'30',1],[1,30,'1'],[NaN,30,1],[1,Infinity,1],[1,30,null]];
      for(const frame of malformed) {
        const inputBefore=await c.inputDeviceStats();
        const accepted=await c.sendKeyboardEvent(...frame);await c.syncKeyboard();
        const inputAfter=await c.inputDeviceStats(),clock=await read();
        if(accepted!==false||JSON.stringify(inputAfter)!==JSON.stringify(inputBefore)||
          clock.mode!=='icount'||clock.mtime!==before.mtime)throw Error('Malformed native ABI frame reached staging/selection');
        numericRows.push({frame:frame.map(value=>Number.isNaN(value)?'NaN':value===Infinity?'Infinity':value),accepted,inputBefore,inputAfter,clock});
      }
      for(const value of [-0x80000000,-1,0x7fffffff]) {
        const inputBefore=await c.inputDeviceStats(),accepted=await c.sendKeyboardEvent(4,4,value);
        await c.syncKeyboard();const inputAfter=await c.inputDeviceStats(),clock=await read();
        if(accepted!==true||inputAfter.pendingEvents!==inputBefore.pendingEvents+2||
          inputAfter.pendingFrames!==inputBefore.pendingFrames+1||clock.mode!=='icount'||clock.mtime!==before.mtime)
          throw Error('Signed original MSC_SCAN forwarding changed');
        numericRows.push({frame:[4,4,value],accepted,inputBefore,inputAfter,clock});
      }
''',1)
s=s.replace('return {paused,before,retiredBefore,selected,','return {numericRows,paused,before,retiredBefore,selected,',1)
(repo/'tools/virgl-production/interactive-clock-worker.mjs').write_text(s)
for old,new in [('paced-policy-critic.test.mjs','e6-t11d72-paced-policy-critic.test.mjs'),('keyboard-abi-critic.test.mjs','e6-t11d72-keyboard-abi-critic.test.mjs')]:
 (repo/'web/tests'/new).write_bytes((repo/'target/evidence/critic-paced-keyboard-policy72'/old).read_bytes())
