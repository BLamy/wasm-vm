from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile,time
repo=Path.cwd();out=Path(__file__).resolve().parent;entries={};sha=lambda b:hashlib.sha256(b).hexdigest()
def add(p,name):
 assert p.is_file(),p
 b=p.read_bytes();assert len(b)<200*1024*1024,(p,len(b));assert name not in entries,name;entries[name]=b
def tree(p,name):
 for f in sorted(p.rglob('*')):
  if f.is_file():add(f,name+'/'+str(f.relative_to(p)))
def tops(p,name):
 for f in sorted(p.iterdir()):
  if f.is_file():add(f,name+'/'+f.name)
base=repo/'target/evidence'
for d in ['production-paced-policy-guard-frozen01','production-paced-policy-guard-cold01','production-paced-policy-guard-cold01/boundary','production-paced-policy-valid-frame-carry01','production-paced-policy-private-window04']:
 p=base/d/'report.json';s=json.loads(p.read_text());assert s['status']=='passed',p
p=base/'production-paced-policy-cold-stock02/browser/report.json';assert json.loads(p.read_text())['status']=='passed'
assert json.loads((base/'production-paced-policy-cold-stock02/report.json').read_text())['status']=='failed'
for d in ['production-paced-policy-guard-frozen01/default','production-paced-policy-guard-cold01/boundary/default']:
 s=json.loads((base/d/'report.json').read_text());assert s['passed']==127 and s['failed']==0 and s['errors']==[]
for d in ['production-paced-policy-frozen01','production-paced-policy-guard-frozen01','production-paced-policy-valid-frame-carry01','production-paced-policy-worker01','production-paced-policy-private-window04','production-paced-policy-private-isolated03','production-paced-policy-private-diagnostic02','production-private-isolation-control01','production-paced-policy-cold-stock02','production-paced-policy-guard-final-prep01','production-paced-policy-guard-cold-launch01']:
 tree(base/d,d)
p=base/'production-paced-policy-guard-cold01';tops(p,'cold-guard');tree(p/'boundary','cold-guard/boundary')
p=base/'production-paced-policy-cold-final01';tops(p,'cold-original-failed');tree(p/'interactive-clock','cold-original-failed/acceptance')
for d in ['production-paced-policy-negative01','production-paced-policy-guard-negative01']:
 p=base/d;tops(p,d)
 if d.endswith('guard-negative01'):
  for rel in ['web/loader.js','web/guest-clock.js']:add(p/'source'/rel,d+'/fault-source/'+rel)
 else:
  for name in ['handoff','rebase']:tree(p/name,d+'/'+name)
for d in ['production-paced-policy-worker-guard-self01']:tree(base/d,'self-validation/'+d)
for pattern in ['production-paced-policy-self0*.*','production-paced-policy-build01.*','production-paced-policy-numeric-self0*.*','production-paced-policy-numeric-build0*.*','production-paced-policy-worker-guard-self01.*']:
 for p in sorted(base.glob(pattern)):
  if p.is_file():add(p,'self-validation/'+p.name)
files=['Makefile','docs/timekeeping.md','web/loader.js','web/guest-clock.js','web/main.js','web/roadmap.js','web/linux-worker.js','web/linux-worker-protocol.js','web/linux-worker-host.js','web/tests/virgl-interactive-clock.test.mjs','web/tests/e6-t11d72-interactive-clock-critic.test.mjs','web/tests/e6-t11d72-paced-policy-critic.test.mjs','web/tests/e6-t11d72-keyboard-abi-critic.test.mjs','web/dist/loader.js','web/dist/guest-clock.js','web/dist/main.js','web/dist/roadmap.js','web/dist/sw.js','web/dist/pkg/wasm_vm_wasm.js','web/dist/pkg/wasm_vm_wasm_bg.wasm','web/artifacts-omarchy-virgl.json','tools/virgl-production/verify-interactive-clock.py','tools/virgl-production/interactive-clock-worker.mjs','tools/virgl-production/cold.py','tools/virgl-production/browser.mjs','tools/virgl-production/acceptance.mjs','tools/virgl-production/compare-handshake.py','tools/virgl-production/critic-fast-boots.mjs','tools/virgl-production/critic-fast-boots-input.mjs','tools/virgl-production/critic-fast-boots-final.mjs','tools/virgl-production/critic-fast-boots-final.test.mjs','tools/verify-virgl-default-demo.mjs','crates/core/src/lib.rs','crates/core/src/time.rs','crates/core/src/dev/virtio/input/keyboard.rs','crates/wasm/src/lib.rs','Cargo.lock','Cargo.toml','tasks/epic-6-transcendence/E6-T11d72-interactive-keyboard-clock.md']
for f in files:add(repo/f,'source/'+f)
for f in ['web/loader.js','web/dist/loader.js','tools/virgl-production/browser.mjs','tools/virgl-production/acceptance.mjs']:
 entries['original-e17/'+f]=subprocess.check_output(['git','show','e17f8caf:'+f])
add(repo/'target/virgl-production/image-12/manifest.json','image12/manifest.json')
add(Path(__file__),'producer/seal.py')
manifest={'schema':1,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'baseStockRuntime':'e17f8caf47712cbbc9ab863f2c161c56432118ad','wasmSha256':'d055c473b686ce543d8b87da68034e240ba0f66cf8aacbb482e03a405a64363f','scope':'D72 production paced-on-keyboard selection and exact numeric ABI; functional software/private/stock and final incremental pristine evidence. Prior original-cold,private deadlines and default-option wrapper remain failed; no300MIPS/deployment/contextloss claim.','files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(entries.items())]}
entries['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode();p=out/'paced-keyboard-policy-submission.tar.gz'
with p.open('wb') as target:
 with gzip.GzipFile(fileobj=target,mode='wb',mtime=0,filename='') as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for name,b in sorted(entries.items()):
    item=tarfile.TarInfo(name);item.size=len(b);item.mode=0o644;item.mtime=0;tar.addfile(item,io.BytesIO(b))
with tarfile.open(p,'r:gz') as tar:
 for member in tar:
  assert tar.extractfile(member).read()==entries[member.name],member.name
receipt={'path':str(p.relative_to(repo)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'members':len(entries),'identities':len(manifest['files']),'head':manifest['head'],'allMembersReopened':True,'uncompressedBytes':sum(map(len,entries.values()))}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
