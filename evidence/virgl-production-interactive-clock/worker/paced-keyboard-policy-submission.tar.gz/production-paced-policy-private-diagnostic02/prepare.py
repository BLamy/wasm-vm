from pathlib import Path
repo=Path.cwd();out=Path(__file__).resolve().parent
clone=repo/'target/evidence/production-paced-policy-cold-final01/clone'
s=(clone/'tools/virgl-production/browser.mjs').read_text()
s=s.replace("const repo=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');",'const repo='+repr(str(clone))+';')
for name in ['acceptance.mjs','recovery.mjs','numeric.mjs']:
 s=s.replace("import('./"+name+"')", "import('"+(clone/'tools/virgl-production'/name).as_uri()+"')")
old="}catch(error){process.exitCode=1;await fs.writeFile(path.join(output,'failure.json'),JSON.stringify({message:error.message,stack:error.stack,errors},null,2));console.error(error.stack);}"
assert s.count(old)==1
new='''}catch(error){
  process.exitCode=1;
  await fs.writeFile(path.join(output,'failure.json'),JSON.stringify({message:error.message,stack:error.stack,errors},null,2));
  console.error(error.stack);
  try {
    const failureState=await page.evaluate(async()=>({serial:__production.serial,errors:__production.errors,
      gpu:await __production.controller.gpuStats(),display:__production.presentation.snapshot(),
      scheduler:await __production.controller.schedulerStats(),clock:await __production.controller.guestClockState(),
      jit:await __production.controller.jitStats()}));
    await fs.writeFile(path.join(output,'failure-state.json'),JSON.stringify(failureState,null,2));
    await page.screenshot({path:path.join(output,'failure.png'),fullPage:true});
    // Diagnostic only AFTER the unchanged acceptance has already failed.
    // Never turn this into a passing acceptance result or retry the helper.
    const start=await page.evaluate(()=>__production.serial.length);
    const command="cat /tmp/production-hyprland.log; cat /tmp/production-monitors.txt; ps -eo pid,ppid,stat,time,comm; echo __POSTFAILURE_LOGS_COMPLETE\\n";
    await page.evaluate(text=>__production.controller.sendInput(new TextEncoder().encode(text)),command);
    await page.waitForFunction(start=>__production.serial.slice(start).includes('\\r\\n__POSTFAILURE_LOGS_COMPLETE\\r\\n'),start,{timeout:180000});
    await fs.writeFile(path.join(output,'postfailure-diagnostic.json'),JSON.stringify(await page.evaluate(start=>({serial:__production.serial.slice(start),scope:'after original failure; not acceptance'}),start),null,2));
  } catch(diagnosticError) {await fs.writeFile(path.join(output,'postfailure-diagnostic-error.json'),JSON.stringify({message:diagnosticError.message,stack:diagnosticError.stack},null,2));}
}'''
s=s.replace(old,new)
(out/'browser.mjs').write_text(s)
