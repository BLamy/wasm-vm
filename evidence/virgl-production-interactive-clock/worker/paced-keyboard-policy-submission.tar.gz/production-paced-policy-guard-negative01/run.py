from pathlib import Path
import hashlib,json,os,shutil,subprocess
repo=Path.cwd();out=Path(__file__).resolve().parent;fault=out/'source';fault.mkdir()
for rel in ['web/package.json','web/guest-clock.js','web/loader.js']:
 p=fault/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((repo/rel).read_bytes())
shutil.copytree(repo/'web/dist/pkg',fault/'web/dist/pkg')
p=fault/'web/loader.js';s=p.read_text();a=s.index('        // The Wasm u16/i32 ABI coerces');b=s.index('        try {',a);removed=s[a:b];assert len(removed.rstrip().splitlines())==5;p.write_text(s[:a]+s[b:])
env=dict(os.environ,CRITIC_D72_REPO_ROOT=str(fault))
command=['node','--test',str(repo/'web/tests/e6-t11d72-keyboard-abi-critic.test.mjs')]
with (out/'stdout').open('wb') as o,(out/'stderr').open('wb') as e:r=subprocess.run(command,env=env,stdout=o,stderr=e)
assert r.returncode==1
(out/'source.diff').write_bytes(subprocess.run(['diff','-u',str(repo/'web/loader.js'),str(p)],capture_output=True).stdout)
report={'status':'passed-negative-control','scope':'only five-line loader ABI guard removed in copied source; same actual compiledWasm; not pristine or Linuxproof','head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'command':command,'exitCode':r.returncode,'removed':removed,'sourceSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'stdoutSha256':hashlib.sha256((out/'stdout').read_bytes()).hexdigest()};(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status'])
