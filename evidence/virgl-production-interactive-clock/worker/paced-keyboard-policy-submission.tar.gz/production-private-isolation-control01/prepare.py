from pathlib import Path
repo=Path.cwd();out=Path(__file__).resolve().parent
for name,base in [('original',repo/'target/evidence/production-paced-policy-cold-final01/clone/tools/virgl-production/browser.mjs'),('corrected',repo/'tools/virgl-production/browser.mjs')]:
 s=base.read_text();s=s.replace("const repo=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');",'const repo='+repr(str(repo))+';')
 s=s.replace("virgl:true,gpuTrace:true,guestClock:","virgl:true,gpuTrace:true,startPaused:true,guestClock:")
 needle="  await page.goto('http://127.0.0.1:'+server.address().port+'/');"
 if name=='original':s=s.replace(needle,needle+"\n  await fs.writeFile(path.join(output,'environment.json'),JSON.stringify(await page.evaluate(()=>({crossOriginIsolated,secureContext:isSecureContext})),null,2));")
 a=s.index('    for(let i=0;i<1200;i++){');b=s.index('\n  }\n  await page.screenshot',a)
 s=s[:a]+"    const jit=await page.evaluate(()=>__production.controller.jitStats());\n    await fs.writeFile(path.join(output,'paused-jit.json'),JSON.stringify(jit,null,2));\n    await __unused;\n".replace('    await __unused;','    await page.evaluate(()=>__production.controller.stop());')+s[b:]
 (out/(name+'.mjs')).write_text(s)
