import hashlib,json,os,subprocess,time
from pathlib import Path
repo=Path.cwd();out=Path(__file__).resolve().parent
clone=repo/'target/evidence/production-paced-policy-cold-final01/clone'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()
assert head=='e17f8caf47712cbbc9ab863f2c161c56432118ad'
env={k:v for k,v in os.environ.items() if k not in ('RUSTFLAGS','RUST_LOG') and not k.startswith(('CARGO_','VIRGL_','CRITIC_'))}
env.update(CRITIC_FAST_BOOT_WEB_ROOT=str(clone/'web/dist'),CRITIC_FAST_BOOT_GPU='1',CRITIC_FAST_BOOT_GUESTS='omarchy',CRITIC_FAST_BOOT_PERSISTENCE='0')
report={'head':head,'status':'running','scope':'independent stock/default continuation from the same pristine clone; preceding compositor timeout remains a failure','started':time.time(),'commands':[]}
try:
 for name,cmd in [('public',['node','tools/virgl-production/critic-fast-boots.mjs',str(out/'browser')]),('default',['node','tools/verify-virgl-default-demo.mjs','--output',str(out/'default'),'--task','E6-T11d72'])]:
  with (out/(name+'.stdout')).open('wb') as o,(out/(name+'.stderr')).open('wb') as e:r=subprocess.run(cmd,cwd=clone,env=env,stdout=o,stderr=e,timeout=2400)
  report['commands'].append({'name':name,'command':cmd,'exitCode':r.returncode});(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');assert r.returncode==0,name+' failed'
 report['status']='passed'
except BaseException as e: report['status']='failed';report['failure']=str(e);raise
finally:
 report['finished']=time.time();report['files']=[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file() and p.name!='report.json'];(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
