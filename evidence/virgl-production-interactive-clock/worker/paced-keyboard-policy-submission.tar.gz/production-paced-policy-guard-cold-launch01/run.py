from pathlib import Path
import hashlib,json,os,subprocess,time
repo=Path.cwd();out=repo/'target/evidence/production-paced-policy-guard-cold01';out.mkdir(exist_ok=False)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip();assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
clone=out/'clone';env={k:v for k,v in os.environ.items() if k not in ('RUSTFLAGS','RUST_LOG') and not k.startswith(('CARGO_','VIRGL_','CRITIC_'))}
report={'status':'running','head':head,'scope':'Exact-head pristine incremental input ABI/worker/default only; earlier authenticated native/software/validstock/private boundaries explicitly carried','commands':[],'started':time.time()}
def run(name,command,cwd):
 print(name,flush=True)
 with (out/(name+'.stdout')).open('wb') as o,(out/(name+'.stderr')).open('wb') as e:r=subprocess.run(command,cwd=cwd,env=env,stdout=o,stderr=e,timeout=1800)
 report['commands'].append({'name':name,'command':command,'exitCode':r.returncode});(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');assert r.returncode==0,name+' failed'
try:
 run('clone',['git','clone','--no-local','--single-branch','--branch',branch,str(repo),str(clone)],repo)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==head
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=clone)
 assert not (clone/'.git/objects/info/alternates').exists()
 run('build',['make','web-dist'],clone)
 run('input-boundary',['python3','tools/virgl-production/verify-interactive-clock.py','--input-boundary-only','--output',str(out/'boundary')],clone)
 report['wasmSha256']=hashlib.sha256((clone/'web/dist/pkg/wasm_vm_wasm_bg.wasm').read_bytes()).hexdigest();assert report['wasmSha256']=='d055c473b686ce543d8b87da68034e240ba0f66cf8aacbb482e03a405a64363f'
 report['status']='passed'
except BaseException as error:report['status']='failed';report['failure']=str(error);raise
finally:
 report['finished']=time.time();report['files']=[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file() and clone not in p.parents and p.name!='report.json'];(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
