from pathlib import Path
import hashlib,json,subprocess
repo=Path.cwd();out=repo/'target/evidence/production-paced-policy-negative01'
report={'scope':'isolated actual JS lifecycle handoff/rebase controls; not stock Linux evidence','head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'rows':[]}
original=(repo/'web/guest-clock.js').read_text()
for name,old,new in [('handoff','        machine.setGuestClock(selectedMode);','        // negative control: selection removed'),('rebase','      if (mode !== "icount") machine.rebaseGuestClock();','      // negative control: explicit resume rebase removed')]:
    base=out/name;base.mkdir()
    for rel in ['web/guest-clock.js','web/loader.js','web/package.json','web/tests/virgl-interactive-clock.test.mjs','crates/core/src/dev/virtio/input/keyboard.rs']:
        p=base/rel;p.parent.mkdir(parents=True,exist_ok=True)
        content=(repo/rel).read_bytes()
        if rel=='web/guest-clock.js':
            assert original.count(old)==1
            content=original.replace(old,new).encode()
        p.write_bytes(content)
    with (base/'stdout').open('wb') as o,(base/'stderr').open('wb') as e:
        result=subprocess.run(['node','--test',str(base/'web/tests/virgl-interactive-clock.test.mjs')],stdout=o,stderr=e)
    assert result.returncode!=0
    diff=subprocess.run(['diff','-u',str(repo/'web/guest-clock.js'),str(base/'web/guest-clock.js')],capture_output=True).stdout
    (base/'source.diff').write_bytes(diff)
    report['rows'].append({'name':name,'exitCode':result.returncode,'singleReplacement':old,'sourceSha256':hashlib.sha256((base/'web/guest-clock.js').read_bytes()).hexdigest(),'stdoutSha256':hashlib.sha256((base/'stdout').read_bytes()).hexdigest()})
report['status']='passed-negative-controls'
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
