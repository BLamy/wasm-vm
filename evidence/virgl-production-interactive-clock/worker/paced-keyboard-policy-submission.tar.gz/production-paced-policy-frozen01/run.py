from pathlib import Path
import hashlib,json,os,subprocess,time
repo=Path.cwd();out=Path(__file__).resolve().parent
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
report={'head':head,'status':'running','scope':'exact frozen frontend boundary; full final native/browser/clone acceptance recorded separately','started':time.time(),'commands':[],'sources':{}}
for rel in ['web/guest-clock.js','web/main.js','web/loader.js','web/dist/guest-clock.js','web/dist/main.js','web/dist/pkg/wasm_vm_wasm_bg.wasm','tools/virgl-production/critic-fast-boots-input.mjs','tools/virgl-production/critic-fast-boots-final.mjs']:
    b=(repo/rel).read_bytes();report['sources'][rel]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
commands=[('policy',['python3','tools/check_task_policy.py']),('clock-protocol',['node','--test','web/tests/virgl-interactive-clock.test.mjs','web/tests/e6-t11d72-interactive-clock-critic.test.mjs','web/tests/e5-t26i-guest-clock.test.mjs','web/tests/e5-t26j-icount-divider.test.mjs','web/tests/e4-t32-worker-protocol.test.mjs','tools/virgl-production/critic-fast-boots-protocol.test.mjs','tools/virgl-production/critic-fast-boots-final.test.mjs']),('syntax',['node','--check','web/guest-clock.js']),('whitespace',['git','diff','--check','7e2739f2',head])]
try:
    for name,command in commands:
        with (out/(name+'.stdout')).open('wb') as o,(out/(name+'.stderr')).open('wb') as e:r=subprocess.run(command,stdout=o,stderr=e)
        report['commands'].append({'name':name,'command':command,'exitCode':r.returncode});assert r.returncode==0
    report['status']='passed'
finally:
    report['finished']=time.time();(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'head':head,'commands':len(report['commands'])}))
