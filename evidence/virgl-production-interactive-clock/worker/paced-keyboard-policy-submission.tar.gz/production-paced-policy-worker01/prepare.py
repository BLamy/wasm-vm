from pathlib import Path
repo=Path.cwd();out=repo/'target/evidence/production-paced-policy-worker01'
s=(repo/'tools/virgl-production/clock-browser-supplement.mjs').read_text()
s=s.replace("const repo=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');",'const repo='+repr(str(repo))+';')
s=s.replace("from 'node:url';", "from 'node:url';\nimport {assertInteractivePauseProbe} from '"+(repo/'tools/virgl-production/critic-fast-boots-final.mjs').as_uri()+"';")
s=s.replace("interactiveClock:'wall-on-keyboard'","interactiveClock:'paced-on-keyboard'")
s=s.replace('const paused=await c.isPaused(), before=await read();','const paused=await c.isPaused(), before=await read(), retiredBefore=(await c.jitStats()).guestRetired;')
s=s.replace('const selected=await read(),stillPaused=await c.isPaused();','const selected=await read(),stillPaused=await c.isPaused(), retiredSelected=(await c.jitStats()).guestRetired;')
s=s.replace('const beforePause=await read(),pauseStarted=performance.now();','const beforePause=await read(),retiredBeforePause=(await c.jitStats()).guestRetired,pauseStarted=performance.now();')
s=s.replace('const afterPause=await read(),pauseFinished=performance.now();','const afterPause=await read(),retiredAfterPause=(await c.jitStats()).guestRetired,pauseFinished=performance.now();')
s=s.replace('const resumed=await read();await sleep(250);','const resumed=await read(),retiredResumed=(await c.jitStats()).guestRetired;await sleep(250);')
s=s.replace('const progressed=await read(),progressReceived=performance.now();','const progressed=await read(),retiredProgressed=(await c.jitStats()).guestRetired,progressReceived=performance.now();')
s=s.replace('resumed,progressed,progressReceived});','resumed,progressed,progressReceived,retired:{beforePause:retiredBeforePause,afterPause:retiredAfterPause,resumed:retiredResumed,progressed:retiredProgressed}});')
s=s.replace('return {paused,before,selected,stillPaused,running,rows,','return {paused,before,retiredBefore,selected,retiredSelected,stillPaused,running,rows,')
s=s.replace("assert.equal(clock.selected.mode,'wall');", "assert.equal(clock.selected.mode,'paced-icount');assert.equal(clock.retiredSelected,clock.retiredBefore);")
s=s.replace("'original wall-mode guest actually ran'","'original paced-mode guest actually ran'")
a=s.index('    for(const row of clock.rows){');b=s.index('    assert.deepEqual(clock.errors',a)
s=s[:a]+'''    for(const row of clock.rows){
      row.pauseMillis=row.pauseFinished-row.pauseStarted;
      row.bound=assertInteractivePauseProbe(row);
    }
'''+s[b:]
(out/'actual-worker.mjs').write_text(s)
