from pathlib import Path
import hashlib,json,subprocess,urllib.parse
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-standard-uniform-offset-critic';UN=OUT/'unpacked';report=json.loads((OUT/'coverage-regions.json').read_text());added=report['addedLines'];sha=lambda raw:hashlib.sha256(raw).hexdigest();regions=report['llvmRegions'];branches=report['llvmBranches']
for label,name in [('independent-original-offsets','offsets-coverage.json'),('eight-direct-plain-limit-rejections','narrow-coverage.json')]:
 for function in json.loads((OUT/name).read_text())['data'][0]['functions']:
  for region in function['regions']:
   source=function['filenames'][region[5]].split('/wasm-vm/')[-1]
   if source not in added or not any(region[0]<=line<=region[2]for line in added[source]):continue
   short=region[:4]+region[5:];matches=[record for record in regions if record['source']==source and record['function']==function['name']and record['region']==short]
   if matches:record=matches[0]
   else:record=dict(source=source,function=function['name'],region=short,maxCount=0,observations=[]);regions.append(record)
   record['maxCount']=max(record['maxCount'],region[4]);record['observations'].append(dict(run=label,record=name,count=region[4]))
  for branch in function['branches']:
   source=function['filenames'][branch[6]].split('/wasm-vm/')[-1]
   if source not in added or not any(branch[0]<=line<=branch[2]for line in added[source]):continue
   short=branch[:4]+branch[6:];matches=[record for record in branches if record['source']==source and record['function']==function['name']and record['branch']==short]
   if matches:record=matches[0]
   else:record=dict(source=source,function=function['name'],branch=short,maxTrue=0,maxFalse=0,observations=[]);branches.append(record)
   record['maxTrue']=max(record['maxTrue'],branch[4]);record['maxFalse']=max(record['maxFalse'],branch[5]);record['observations'].append(dict(run=label,record=name,true=branch[4],false=branch[5]))
for branch in branches:assert branch['maxTrue']>0 and branch['maxFalse']>0,branch
scripts=[];bound_raw=[]
for folder in [UN/'hot/node-coverage',UN/'cold/node-coverage',OUT/'generator-coverage']:
 for file in sorted(folder.glob('coverage-*.json')):
  raw=file.read_bytes();bound_raw.append(dict(record=file.relative_to(OUT).as_posix(),sha256=sha(raw)))
  for script in json.loads(raw)['result']:
   url=script.get('url','')
   if not url.startswith('file:'):continue
   name=urllib.parse.unquote(urllib.parse.urlparse(url).path).split('/wasm-vm/')[-1]
   if name not in added:continue
   source=(ROOT/name).read_bytes();assert source==subprocess.check_output(['git','show','d3e0dc04431b64f7585565fdbf0a9c5065078152:'+name],cwd=ROOT);scripts.append(dict(record=file.relative_to(OUT).as_posix(),source=name,sha256=sha(source),coverage=script))
full=[];intervals=[]
for name in sorted({script['source']for script in scripts}):
 source=(ROOT/name).read_text();utf16=source.encode('utf-16-le');ranges=[]
 for script in scripts:
  if script['source']!=name:continue
  for function in script['coverage']['functions']:
   for part in function['ranges']:ranges.append(dict(record=script['record'],function=function['functionName'],isBlockCoverage=function['isBlockCoverage'],**part))
 full.append(dict(source=name,sha256=sha(source.encode()),ranges=ranges));ends=sorted({value for part in ranges for value in[part['startOffset'],part['endOffset']]})
 for start,end in zip(ends,ends[1:]):
  containing=[part for part in ranges if part['startOffset']<=start and part['endOffset']>=end]
  if not containing:continue
  per_record={}
  for part in containing:
   width=part['endOffset']-part['startOffset'];previous=per_record.get(part['record'])
   if previous is None or width<previous['width']:per_record[part['record']]=dict(width=width,count=part['count'])
   elif width==previous['width']:previous['count']=max(previous['count'],part['count'])
  prefix=utf16[:start*2].decode('utf-16-le');body=utf16[start*2:end*2].decode('utf-16-le');first=prefix.count('\n')+1;last=first+body.count('\n')
  if any(first<=line<=last for line in added[name]):intervals.append(dict(source=name,start=start,end=end,lineStart=first,lineEnd=last,maxCount=max(record['count']for record in per_record.values()),text=body,counters=per_record))
assert all(record['maxCount']>0 for record in intervals),[record for record in intervals if record['maxCount']==0]
for name in ['cases.json','cases.bin']:assert(OUT/'generator-matrix'/name).read_bytes()==(UN/'hot/native'/name).read_bytes()==(UN/'cold/native'/name).read_bytes()
hardware=[json.loads(line)for line in(OUT/'hardware-audit.jsonl').read_text().splitlines()];digests=json.loads((OUT/'generator-pixel-digests.json').read_text());by_name={frame['name']:frame for frame in digests['frames']}
for frame in hardware:
 if frame['record']=='hardware/report.json':assert frame['pixelSha256']==by_name[frame['name']]['pixelSha256']
classification=dict(status='passed',runtimeFile='renderer/virgl-shader/standard_guard.c',runtimeRegions=len(regions),runtimeBranches=len(branches),allChangedRuntimeRegionsCovered=all(record['maxCount']>0 or record['region'][-1]!=0 for record in regions),allChangedRuntimeBranchSidesCovered=True,rawProfileReexports=report['reexports'],independentSupplements=['offsets-coverage.json','narrow-coverage.json'],changedHarnessSourceRanges=full,changedHarnessNarrowIntervals=intervals,rawV8IdentityRecords=bound_raw,harnessWaivers=[dict(source='tools/virgl-standard-uniform/browser.mjs',reason='One changed count/assertion line is evidence plumbing: actual source-bound hot/cold wrapper reports contain253 frames397 compiles and success; all frames independently audited. The Node wrapper is not V8-instrumented; no product branch is waived.'),dict(source='tools/virgl-standard-uniform/pixels.mjs',reason='Two changed count/receipt lines are offline audit plumbing: actual hot/cold physical-audit reports contain253 independent frames/104844 pixels; independent Python reconstruction holds every original storage/pixel. No product branch is waived.'),dict(source='tools/virgl-standard-uniform/receipt.py',reason='Changed expected totals and result fields are deterministic receipt plumbing. Both sealed receipts authenticate508 cases397 compiles253 frames104844 pixels, backed by source-bound complete native/Wasm/GPU data. No runtime or admission behavior is waived.')],prior57RendererHunks='Carried via unchanged HELD P11 source/dependency/evidence identities except the two repaired guard hunks audited here.',authority='isolated-standard-uniform-shader');assert classification['allChangedRuntimeRegionsCovered'];(OUT/'coverage-classification.json').write_text(json.dumps(classification,indent=2)+'\n');(OUT/'coverage-regions.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':classification['status'],'regions':len(regions),'branches':len(branches),'changedHarnessRanges':len(intervals),'allRuntimeBranchSidesCovered':True,'sourceBoundFullReexports':len(report['reexports'])}))
