import assert from 'node:assert/strict';import fs from 'node:fs/promises';import path from 'node:path';import {pathToFileURL}from'node:url';import {createHash}from'node:crypto';
const root=process.cwd(),out=import.meta.dirname,built=path.join(root,'renderer/virgl-shader/build/wasm'),sha=bytes=>createHash('sha256').update(bytes).digest('hex'),sources={};
for(const name of ['virgl-shader.mjs','virgl-shader.wasm'])sources[name]=sha(await fs.readFile(path.join(built,name)));
const {default:createModule}=await import(pathToFileURL(path.join(built,'virgl-shader.mjs')).href),raw=await createModule();assert.equal(raw.HEAPU8.byteLength,16777216);
const rows=(await fs.readFile(path.join(out,'original-offsets.jsonl'),'utf8')).trim().split('\n').map(JSON.parse),results=[];
for(const [index,row]of rows.entries()){
 const bytes=Buffer.from(row.text),pointer=raw._malloc(bytes.length+1);assert.ok(pointer);try{raw.HEAPU8.set(bytes,pointer);raw.HEAPU8[pointer+bytes.length]=0;const result=JSON.parse(raw.UTF8ToString(raw._bridge_translate_standard_uniform(row.stage==='vertex'?0:1,pointer,bytes.length)));assert.deepEqual(result,row.result);assert.equal(result.ok,row.validSigned16);results.push({...row,index,result,exactNativeWasm:true});}finally{raw._free(pointer);}
}
for(const name of Object.keys(sources))assert.equal(sha(await fs.readFile(path.join(built,name))),sources[name]);
await fs.writeFile(path.join(out,'offsets-wasm-recheck.jsonl'),results.map(row=>JSON.stringify(row)).join('\n')+'\n');await fs.writeFile(path.join(out,'wasm-custody.json'),JSON.stringify({sources,cases:rows.length,fixedMemoryBytes:raw.HEAPU8.byteLength},null,2)+'\n');console.log('120 independently parsed original signed offset native/Wasm results agree.');
