from pathlib import Path
import hashlib,json,struct
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-standard-uniform-offset-critic';sha=lambda raw:hashlib.sha256(raw).hexdigest()
plans=json.loads((OUT/'novel-cases.json').read_text())['cases'];literal=json.loads((OUT/'novel-literal-predictions.json').read_text())['plans'];native=[json.loads(line)for line in(OUT/'novel-native.jsonl').read_text().splitlines()];assert len(plans)==len(literal)==len(native)==64
records=[];summaries=[]
def words(count,seed,stage,slot):
 factor=0x8da6b343 if stage=='vertex'else 0xd8163841
 return [(((index+1)*0x9e3779b9)&0xffffffff)^seed^(((slot+1)*factor)&0xffffffff)^(((index>>2)*0xcb1ab31f)&0xffffffff)for index in range(count*4)]
for folder,fault in [('novel-final',False),('sabotage-final',True)]:
 report=json.loads((OUT/folder/'report.json').read_text());acceptance=report['acceptance'];frames=acceptance['frames'];assert report['status']==('failed'if fault else'passed')and len(frames)==(1 if fault else 64);assert report['browserErrors']==dict(console=[],page=[],requests=[]);assert not report['browser']['launch']['headless'];assert 'Apple M4 Max'in acceptance['renderer']and'Metal'in acceptance['renderer'];assert report['browser']['gpu']['featureStatus'][report['browser']['webglFeature']]=='enabled'
 assert not any(any(bad in argument.lower()for bad in ['swiftshader','llvmpipe','softpipe','lavapipe','--disable-gpu'])for argument in report['browser']['actualCommandLine'])
 for item in report['sources']+report['servedFiles']:
  raw=(ROOT/item['path']).read_bytes();assert len(raw)==item['size']and sha(raw)==item['sha256'],item['path']
 assert sha((OUT/'novel-literal-predictions.json').read_bytes())==report['literalPredictionsSha256'];assert sha(Path(report['nativeExecutable']).read_bytes())==report['nativeExecutableSha256']
 coverage=(OUT/folder/report['browserCoverage']['path']).read_bytes();assert sha(coverage)==report['browserCoverage']['sha256'];served={item['path']:item['sha256']for item in report['servedFiles']}
 for row in json.loads(coverage)['scripts']:assert row['sha256']==served[row['source']]
 for index,frame in enumerate(frames):
  plan=plans[index];expectation=literal[index];assert all(frame[key]==value for key,value in plan.items());assert frame['pair']==native[index]['result'];assert frame['pair']['ok']and frame['cleaned'];assert frame['gpuComplete']['submitted']and frame['gpuComplete']['fenced']and frame['gpuComplete']['status']in[37146,37148];assert frame['draws']==[dict(name='drawArrays',mode=4,count=3)];assert frame['width']==frame['height']==2
  stage=plan['stage'];slot=plan['slot'];count=plan['count'];last=count-1;assert plan['last']==last and plan['base']+plan['offset']==last and plan['offset']in[-32768,32767]
  token=native[index]['originalTokens'][0 if stage=='vertex'else 1];assert token['constantDeclarations']==[dict(slot=slot,first=0,last=last,dimensional=plan['form']=='dimensional')];assert token['constantSources']==[dict(instruction=3 if stage=='vertex'else 2,slot=slot,index=plan['offset'],indirect=True,indirectDimension=False)]
  body=frame['pair'][stage];prefix='vs'if stage=='vertex'else'fs';assert prefix+'const'+str(slot)+'[addr0 + ('+str(plan['offset'])+')]'in body['glsl'];assert 'ARL ADDR[0].x, TEMP[0].xxxx'in(plan['vertexText']if stage=='vertex'else plan['fragmentText'])
  original=words(count,plan['seed'],stage,slot);assert len(frame['banks'])==1;bank=frame['banks'][0];assert bank['nativeOriginalWords']==original;buffered=slot!=0 or plan['form']=='dimensional'
  if not buffered:assert bank['inline']and bank['nativeActualWords']==original
  else:
   assert not bank['inline'];assert bank['size']==count*16 and bank['nativeSize']==count*16 and bank['nativeStart']==bank['start']and bank['nativeObjectMatches'];start=bank['alignment']*(7+slot+(stage=='fragment'));assert bank['start']==start and bank['binding']==3
   expected=bytearray((byte*17+plan['seed'])&255 for byte in range(start+count*16+bank['alignment']));expected[start:start+count*16]=struct.pack('<'+'I'*len(original),*original);assert bank['nativeStorage']==list(expected)
   assert bank['member']==dict(name=prefix+'const'+str(slot)+'[0]',type=36296,size=count,offset=0,stride=16,blockIndex=bank['blockIndex'])
  assert frame['attributes'][0]['type']==5126 and frame['attributes'][0]['original']==frame['attributes'][0]['actual']==[-1,-1,0,1,3,-1,0,1,-1,3,0,1]
  raw_words=original[last*4:last*4+4];expected=[(value>>plan['shift'])&255 for value in raw_words];assert expectation['rawWords']==raw_words and expectation['expectedBytes']==expected and frame['expectedWords']==expected
  if fault:expected[0]^=1
  mismatches=[dict(word=word,expected=expected[word%4],actual=actual)for word,actual in enumerate(frame['pixels'])if actual!=expected[word%4]][:8];assert bool(mismatches)==fault;assert frame['audit']==dict(held=not fault,checkedWords=16,mismatches=mismatches)
  records.append(dict(record=folder+'/report.json',frame=index,name=plan['name'],stage=stage,slot=slot,form=plan['form'],offset=plan['offset'],base=plan['base'],effectiveVector=last,tokenIndex=token['constantSources'][0]['index'],rawWords=raw_words,expectedBytes=expectation['expectedBytes'],gpuComplete=frame['gpuComplete'],completePixels=4,pixelSha256=sha(struct.pack('<16f',*frame['pixels'])),held=not fault,mismatches=mismatches,cleaned=True))
 if fault:assert 'critic original endpoint pixel assertion after completed native fence'in report['failure']['message']and frames[0]['sabotageAfterFence'];assert mismatches[0]['expected']!=mismatches[0]['actual']
 screenshot=report['failureScreenshot']if fault else report['screenshot'];assert sha((OUT/folder/screenshot['path']).read_bytes())==screenshot['sha256'];summaries.append(dict(record=folder+'/report.json',sha256=sha((OUT/folder/'report.json').read_bytes()),frames=len(frames),completePixels=len(frames)*4,nativeExecutableSha256=report['nativeExecutableSha256'],headed=True,renderer=acceptance['renderer'],screenshot=screenshot))
(OUT/'novel-hardware-audit.jsonl').write_text(''.join(json.dumps(record,separators=(',',':'))+'\n'for record in records));result=dict(status='passed',records=summaries,completeHealthyPixels=256,completeHealthyDraws=64,afterFenceSabotageRejected=True,workerFixtureImports=False,independentPythonRawWordOracle=True,guestExecution=False,productionAuthority=False);(OUT/'novel-hardware-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
