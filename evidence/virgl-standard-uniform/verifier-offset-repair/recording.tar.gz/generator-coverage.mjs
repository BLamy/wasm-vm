import assert from'node:assert/strict';import fs from'node:fs/promises';import path from'node:path';import{createHash}from'node:crypto';
import{hardwareFixtures}from'../../../tools/virgl-standard-uniform/hardware-fixtures.mjs';
const out=import.meta.dirname,records=[];let pixels=0;
for(const fixture of hardwareFixtures()){const expected=[];for(let y=0;y<fixture.height;++y)for(let x=0;x<fixture.width;++x)expected.push(...fixture.expected(x,y));pixels+=fixture.width*fixture.height;const raw=Buffer.from(new Float32Array(expected).buffer);records.push({name:fixture.name,pixels:fixture.width*fixture.height,pixelSha256:createHash('sha256').update(raw).digest('hex')});}
assert.equal(records.length,253);assert.equal(pixels,104844);await fs.writeFile(path.join(out,'generator-pixel-digests.json'),JSON.stringify({frames:records,pixels,rawFunctionCounters:true},null,2)+'\n');
