from pathlib import Path
import json,hashlib,gzip,struct,re
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-standard-uniform-verifier';UN=OUT/'unpacked';sha=lambda b:hashlib.sha256(b).hexdigest()
EDGE=[0,0x80000000,0xffffffff,0x7fc01234,0x7f800000,0xff800000,0x00800000,1,0x007fffff,0x3f800001,0xbf800001,0x7f7fffff,0xdeadbeef,0x12345678,0x80000001,0x7fa055aa]
def words(count,seed):
 value=seed&0xffffffff;result=[]
 for _ in range(count*4):
  value=(value^((value<<13)&0xffffffff))&0xffffffff;value^=value>>17;value=(value^((value<<5)&0xffffffff))&0xffffffff;result.append(value)
 take=min(16,len(result));result[:take]=EDGE[:take];result[-take:]=EDGE[:take];return result
def packed_words(count,seed):return struct.pack('<'+'I'*(count*4),*words(count,seed))
def f32(values):return struct.pack('<'+'f'*len(values),*values)
QUAD=f32([-1,-1,0,1,3,-1,0,1,-1,3,0,1]);records=[];nativerows=[];storage_count=0;pixels=0
for run in ['hot','cold']:
 receipt=json.loads((UN/run/'receipt.json').read_text()); sources=receipt['sources'];generated=receipt['generated']
 cases=json.loads((UN/run/'native/cases.json').read_text())['cases'];native=[json.loads(r) for r in (UN/run/'native/native.jsonl').read_text().splitlines()];sanitized=[json.loads(r) for r in (UN/run/'native/sanitize.jsonl').read_text().splitlines()];wasm=[json.loads(r) for r in (UN/run/'native/wasm.jsonl').read_text().splitlines()]
 assert len(cases)==len(native)==len(sanitized)==len(wasm)==338
 for index,(case,n,s,w) in enumerate(zip(cases,native,sanitized,wasm)):
  assert n==s and n['result']==w['result'];result=n['result'];assert result['ok']==case['okay']
  entries=[]
  if result['ok'] and case['kind']<7:
   bodies=[('vertex' if case['kind']==0 else 'fragment',case['a'],result)] if case['kind']<2 else [('vertex',case['a'],result['vertex']),('fragment',case['b'],result['fragment'])]
   for at,(stage,text,body) in enumerate(bodies):
    declarations=[];counts={};declared={}
    for m in re.finditer(r'^DCL CONST\[(\d+)(?:\.\.(\d+))?\](?:\[(\d+)(?:\.\.(\d+))?\])?$',text,re.M):
     dim=m[3] is not None;slot=int(m[1]) if dim else 0;first=int(m[3] if dim else m[1]);last=int(m[4] or m[3] or m[2] or m[1]);declarations.append(dict(slot=slot,first=first,last=last,dimensional=dim));counts[slot]=max(counts.get(slot,0),last+1);declared.setdefault(slot,set()).update(range(first,last+1))
    orig=n['originalTokens'][at];assert orig['constantDeclarations']==declarations
    refs=[]
    for ins,line in enumerate(re.findall(r'^\d+: (.*)$',text,re.M)):
     for m in re.finditer(r'CONST\[(\d+|ADDR\[0\]\.x(?:\s*[+-]\d+)?)\](?:\[(\d+|ADDR\[0\]\.x(?:\s*[+-]\d+)?)\])?',line):
      register=m[2] or m[1];slot=int(m[1]) if m[2] else 0;indirect=register.startswith('ADDR');off=re.search(r'[+-]\d+$',register);vector=int(off[0]) if off else 0 if indirect else int(register);refs.append(dict(instruction=ins,slot=slot,index=vector,indirect=indirect,indirectDimension=False))
      if not indirect:assert vector in declared[slot]
    assert orig['constantSources']==refs
    sel=case['kind']>=2 and bool(case['selectors']['bufferZeroMask']&(1 if stage=='vertex' else 2));prefix='vs' if stage=='vertex' else 'fs';blocks=[]
    for slot,count in sorted(counts.items()):
     assert slot<=12 and count<=(1024 if slot else 512)
     if not slot and not sel:continue
     block=dict(name='Virgl'+('VS' if stage=='vertex' else 'FS')+'Const'+str(slot),stage=stage,slot=slot,byteLength=count*16,encoding='raw-32bit-words',members=[dict(name=prefix+'const'+str(slot),type='uvec4[]',count=count,offset=0,arrayStride=16)])
     assert 'layout(std140) uniform '+block['name']+' { uvec4 '+block['members'][0]['name']+'['+str(count)+']; };' in body['glsl'];blocks.append(block)
    assert blocks==body['metadata']['guestUniformBlocks'];assert body['metadata']['profile']=='virgl-webgl2-standard-uniform-gles3-v1'
    assert body['metadata']['standardSemantics']['exactAuthority'] is False and body['metadata']['standardSemantics']['undefinedDomains']=='native-gles3'
    assert body['metadata']['uniforms']==([dict(name=prefix+'const0',type='uvec4[]',count=counts[0],encoding='raw-32bit-words')] if 0 in counts and not sel else [])
    for ref in refs:
     if ref['indirect']:
      expr=prefix+'const'+str(ref['slot'])+'[addr0'+(' + ('+str(ref['index'])+')' if ref['index'] else '')+']';assert expr in body['glsl']
    entries.append(dict(stage=stage,declarations=declarations,originalSources=refs,blocks=blocks))
  if not result['ok']:assert list(result)==['ok','error'] and result['error']['code']==case['code']
  nativerows.append(dict(run=run,index=index,name=case['name'],ok=result['ok'],responseSha256=sha(json.dumps(result,separators=(',',':')).encode()),original=entries))
 for folder in ['hardware','fault-block-word','fault-range-offset','fault-slot-zero-variant']:
  fault=None if folder=='hardware' else folder[6:];report=json.loads((UN/run/folder/'report.json').read_text());a=report['acceptance'];assert report['gitHead']==receipt['gitHead'];assert report['browserErrors']==dict(console=[],page=[],requests=[])
  assert report['status']==('failed' if fault else 'passed');assert not report['browser']['launch']['headless'];assert 'Apple M4 Max' in a['renderer'] and 'Metal' in a['renderer']
  assert not any(re.search(r'swiftshader|llvmpipe|lavapipe|softpipe|--disable-gpu',x,re.I) for x in report['browser']['actualCommandLine']);assert report['browser']['gpu']['featureStatus'][report['browser']['webglFeature']]=='enabled'
  served={r['path']:r['sha256'] for r in report['servedFiles']};assert served['renderer/virgl-shader/build/wasm/virgl-shader.wasm']==generated['renderer/virgl-shader/build/wasm/virgl-shader.wasm']
  for item in report['sources']+report['servedFiles']:
   name=item['path'];expected=generated.get(name,sources.get(name))
   if expected is None:
    # Native matrix inputs are generated evidence records on the source checkout.
    suffix=re.search(r'/native/(cases.json|native.jsonl)$',name);assert suffix,name;expected=sha((UN/run/'native'/suffix[1]).read_bytes())
   assert item['sha256']==expected,name
  coverage=json.loads((UN/run/folder/report['browserCoverage']['path']).read_text());assert sha((UN/run/folder/report['browserCoverage']['path']).read_bytes())==report['browserCoverage']['sha256']
  for script in coverage['scripts']:assert script['sha256']==served[script['source']]
  blobs={}
  for b in a['blobs']:
   zipped=(UN/run/folder/b['path']).read_bytes();raw=gzip.decompress(zipped);assert sha(zipped)==b['gzipSha256'] and sha(raw)==b['sha256'] and len(raw)==b['bytes'];assert b['key'] not in blobs;blobs[b['key']]=raw
  assert len(a['frames'])==(1 if fault else 125)
  if not fault:
   assert len(a['compiles'])==237
   for c in a['compiles']:
    original=native[c['index']]['result'];bodies=[original] if cases[c['index']]['kind']<2 else [original['vertex'],original['fragment']]
    for actual,body in zip(c['records'],bodies):assert actual['success'] and actual['glsl']==body['glsl'] and actual['metadata']==body['metadata']
  for frame in a['frames']:
   kind=frame['kind'];assert frame['cleaned'];assert frame['gpuComplete']['submitted'] and frame['gpuComplete']['fenced'] and frame['gpuComplete']['status'] in [37146,37148];assert len(frame['calls'])==1 and frame['calls'][0]['name']=='drawArrays'
   assert frame['pair']==native[frame['nativeIndex']]['result'];assert frame['vertexText']==cases[frame['nativeIndex']]['a'] and frame['fragmentText']==cases[frame['nativeIndex']]['b'];assert frame['actualSelectors']==cases[frame['nativeIndex']]['selectors']
   assert blobs[frame['systemStorage']]==bytes(640)+f32([1])+bytes(12);assert frame['systemBlocks'][0]['size']==656 and frame['systemBlocks'][0]['binding']==0 and frame['systemBlocks'][0]['member']['offset']==640
   bank_audits=[]
   for bank in frame['banks']:
    slot=bank['slot'];stage=bank['stage'];count=bank['count'];storage_count+=1
    if kind=='atlas':
     assert stage==frame['stage'] and slot==frame['slot'] and count==(1024 if slot else 512);seed=frame['seed'];expected=packed_words(count,seed)
     if frame['offset']==0:assert seed==(0x6e624eb7+slot*101+(0 if stage=='vertex' else 7919))&0xffffffff
     else:assert seed==0x34567891+slot*77
    elif kind=='all-banks':
     assert count==(1024 if slot else 512);expected=bytearray(packed_words(count,0x23456789+slot*31+(0 if stage=='vertex' else 88)));v=(slot+1)*(1 if stage=='vertex' else 2);expected[-16:]=f32([v+i for i in range(4)]);expected=bytes(expected)
    elif kind=='formats':
     if slot==12:expected=bytearray(packed_words(1024,0xc1234abc));expected[-16:]=f32([2]*4);expected=bytes(expected);assert count==1024
     else:expected=f32([.25,.5,.75,1] if stage=='vertex' else [1,2,3,4]);assert count==1
    else:assert kind=='unused' and stage=='vertex' and slot in [1,12];expected=packed_words(1024 if slot==1 else 1,0x6789abcd if slot==1 else 0x13579abc)
    assert blobs[bank['original']]==expected
    if bank['inline']:
     assert slot==0 and bank['type']==36296 and bank['size']==count and blobs[bank['actual']]==expected
    else:
     alignment=a['limits']['alignment'];start=alignment*(1+slot%3);assert bank['expectedOffset']==start;assert bank['actualOffset']==start+(alignment if fault=='range-offset' else 0)
     backing=bytearray((i*37+slot*19+23)&255 for i in range(start+len(expected)+alignment*2));backing[start:start+len(expected)]=expected
     if fault=='block-word':backing[start]^=1
     assert blobs[bank['actualStorage']]==backing and bank['nativeStorageBytes']==len(backing)
     assert bank['blockName']=='Virgl'+('VS' if stage=='vertex' else 'FS')+'Const'+str(slot)
     if bank['binding'] is not None:
      member=bank['member'];assert bank['size']==len(expected)==bank['nativeSize'];assert member==dict(name=('vs' if stage=='vertex' else 'fs')+'const'+str(slot)+'[0]',size=count,type=36296,offset=0,stride=16,blockIndex=bank['index']);assert bank['reflectedBinding']==bank['binding'] and bank['nativeStart']==bank['actualOffset'] and bank['nativeObjectMatches']
      assert (bank['vertex']==(stage=='vertex') and bank['fragment']==(stage=='fragment')) or kind=='unused' and not bank['vertex'] and not bank['fragment']
     else:assert kind=='unused' and bank.get('eliminatedDeclaration') or fault=='slot-zero-variant' and stage=='fragment' and slot==0 and bank.get('variantMissingBlock')
    bank_audits.append(dict(stage=stage,slot=slot,count=count,originalSha256=sha(expected),inline=bank['inline'],binding=bank.get('binding'),size=bank.get('size'),member=bank.get('member'),rangeStart=bank.get('actualOffset')))
   for attr in frame['attributes']:
    idx=attr['index'];expected=QUAD if idx==0 else struct.pack('<12i',*([-2,-1,2,-2]*3)) if idx==1 else struct.pack('<12I',*([3,4,5,6]*3)) if idx==2 else struct.pack('<3I',*(([(1020|(3<<10)|(1022<<20)|(2<<30))] if idx==3 else [(512|(511<<10)|(2<<30))])*3))
    assert blobs[attr['original']]==blobs[attr['actual']]==expected;assert attr['integer']==(idx in [1,2]);assert attr['normalized'] is False;assert attr['type']==[5126,5124,5125,33640,33640][idx]
   data=blobs[frame['pixels']];assert len(data)==frame['width']*frame['height']*16;mismatches=[];checked=0
   for y in range(frame['height']):
    for x in range(frame['width']):
     if kind=='atlas':
      vector=x+frame['base']+frame['offset'];bank=frame['banks'][0];original=blobs[bank['original']];expected=[(struct.unpack_from('<I',original,(vector*4+l)*4)[0]>>frame['shift'])&255 for l in range(4)]
     elif kind=='all-banks':expected=[sum((slot+1)*3+2*l for slot in range(13)) for l in range(4)]
     elif kind=='formats':
      signed=[-2,-1,2,-2];unsigned=[3,4,5,6];scaled=[-4,3,-2,-2];normalized=[-1,1,0,-1];expected=[signed[l]+unsigned[l]+scaled[l]+normalized[l]+[.25,.5,.75,1][l]+2+[1,2,3,4][l] for l in range(4)]
     else:expected=[.25,.5,.75,1]
     actual=list(struct.unpack_from('<4f',data,(y*frame['width']+x)*16));checked+=4
     for lane in range(4):
      if expected[lane]!=actual[lane] and len(mismatches)<8:mismatches.append(dict(x=x,y=y,lane=lane,expected=expected[lane],actual=actual[lane]))
   assert bool(mismatches)==bool(fault);assert frame['audit']==dict(held=not bool(fault),checkedWords=checked,mismatches=mismatches)
   if kind=='all-banks' and not fault:assert frame['activeBlocks']==25+bool(frame['expectedSelectors']['bufferZeroMask']&1)+bool(frame['expectedSelectors']['bufferZeroMask']&2)
   pixels+=frame['width']*frame['height'];records.append(dict(run=run,record=folder+'/report.json',name=frame['name'],kind=kind,frameIndex=a['frames'].index(frame),pixelSha256=sha(data),checkedPixels=checked//4,gpuComplete=frame['gpuComplete'],activeBlocks=frame['activeBlocks'],mismatches=mismatches,banks=bank_audits,held=not bool(fault)))
  if fault:assert 'independent original uniform pixels after completed GPU fence' in report['failure']['message']
(OUT/'native-audit.jsonl').write_text(''.join(json.dumps(r,separators=(',',':'))+'\n' for r in nativerows));(OUT/'hardware-audit.jsonl').write_text(''.join(json.dumps(r,separators=(',',':'))+'\n' for r in records))
result={'status':'passed','nativeCases':len(nativerows),'hardwareFrames':len(records),'completePixelsIncludingFaults':pixels,'originalStorageRecords':storage_count,'workerFixtureImports':False,'compilerOracleImports':False,'authority':'isolated-standard-uniform-shader'}
(OUT/'recording-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
