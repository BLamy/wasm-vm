#include "bridge.h"
#include "checked_tgsi_heap.h"
#include "tgsi/tgsi_text.h"
#include "tgsi/tgsi_parse.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void) {
 const int offsets[]={-32768,-32767,-1024,-1023,-512,-511,511,512,1023,1024,32767};
 for(int stage=0;stage<2;++stage)for(unsigned slot=0;slot<=12;slot+=slot?11:1)for(unsigned n=0;n<sizeof(offsets)/sizeof(offsets[0]);++n) {
  int off=offsets[n]; char text[2048];
  snprintf(text,sizeof(text),"%s\nDCL CONST[%u][0..%u]\nDCL ADDR[0]\nDCL OUT[0], %s\nIMM[0] FLT32 {%d.0,%d.0,%d.0,%d.0}\n0: ARL ADDR[0].x, IMM[0].xxxx\n1: MOV OUT[0], CONST[%u][ADDR[0].x %c%d]\n2: END\n",stage?"FRAG":"VERT",slot,slot?1023:511,stage?"COLOR":"POSITION",-off,-off,-off,-off,slot,off<0?'-':'+',off<0?-off:off);
  struct tgsi_token tokens[BRIDGE_MAX_TOKENS]={{0}};bridge_tgsi_scratch_begin_uniform();
  int ok=tgsi_text_translate(text,tokens,BRIDGE_MAX_TOKENS); if(!ok)return 2;
  struct tgsi_parse_context parser;if(tgsi_parse_init(&parser,tokens)!=TGSI_PARSE_OK)return 2;
  int got=0,index=0,dimension=0,indirect=0,instruction=0;
  while(!tgsi_parse_end_of_tokens(&parser)) {
   if(!tgsi_parse_token(&parser))return 2;
   if(parser.FullToken.Token.Type!=TGSI_TOKEN_TYPE_INSTRUCTION)continue;
   struct tgsi_full_instruction *i=&parser.FullToken.FullInstruction;
   for(unsigned src=0;src<i->Instruction.NumSrcRegs;++src)if(i->Src[src].Register.File==TGSI_FILE_CONSTANT) {
    ++got;index=i->Src[src].Register.Index;dimension=i->Src[src].Dimension.Index;indirect=i->Src[src].Register.Indirect;
   }
   ++instruction;
  }
  tgsi_parse_free(&parser);if(got!=1||index!=off||dimension!=(int)slot||!indirect)return 3;
  const char *response=bridge_translate_standard_uniform(stage,text,strlen(text));
  printf("{\"stage\":\"%s\",\"slot\":%u,\"offset\":%d,\"predictedBase\":%d,\"effectiveVector\":0,\"originalParse\":true,\"tokenSlot\":%d,\"tokenIndex\":%d,\"tokenIndirect\":true,\"text\":\"",stage?"fragment":"vertex",slot,off,-off,dimension,index);
  for(const char *c=text;*c;++c) {if(*c=='\n')printf("\\n");else if(*c=='\"'||*c=='\\')printf("\\%c",*c);else putchar(*c);}printf("\",\"result\":%s}\n",response);
 }
 return 0;
}
