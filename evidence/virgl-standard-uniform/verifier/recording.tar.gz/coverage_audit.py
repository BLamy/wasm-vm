from pathlib import Path
import subprocess,json,re,hashlib
ROOT=Path.cwd(); OUT=ROOT/'target/evidence/virgl-standard-uniform-verifier'; UN=OUT/'unpacked'
sha=lambda b:hashlib.sha256(b).hexdigest()
base='e118e4c2ddf83b2641fcca267025b1a6ef8fdad9'; diff=subprocess.check_output(['git','diff','--unified=0',base,'5dc84364','--','renderer'],text=True)
added={}; filename=None; line=0; hunks=[]
for row in diff.splitlines():
 if row.startswith('+++ b/'): filename=row[6:]
 elif row.startswith('@@'): line=int(re.search(r'\+(\d+)',row)[1]);hunks.append({'file':filename,'hunk':row})
 elif row.startswith('+') and filename: added.setdefault(filename,[]).append(line);line+=1
 elif row.startswith(' '):line+=1
profiles=[('coverage/matrix','standard-uniform-sanitize/standard-uniform-test'),('coverage/allocations','standard-uniform-allocation-sanitize/standard-uniform-allocation-test'),('compiler-retained/coverage/matrix','standard-sanitize/standard-test'),('compiler-retained/coverage/allocations','standard-allocation-sanitize/standard-allocation-test'),('coverage/packed-matrix','standard-packed-sanitize/standard-packed-test'),('coverage/packed-allocations','standard-packed-allocation-sanitize/standard-packed-allocation-test'),('coverage/integer-matrix','standard-integer-sanitize/standard-integer-test'),('coverage/integer-allocations','standard-integer-allocation-sanitize/standard-integer-allocation-test')]
raw_profiles={'coverage/packed-matrix':'coverage/packed-retained.profraw','coverage/packed-allocations':'coverage/packed-retained-allocations.profraw','coverage/integer-matrix':'coverage/integer-retained.profraw','coverage/integer-allocations':'coverage/integer-retained-allocations.profraw'}
regions={}; branches={}; reexports=[]
for run in ['hot','cold']:
 for profile,binary in profiles:
  raw=UN/run/(raw_profiles.get(profile,profile+'.profraw')); merged=OUT/(run+'-'+profile.replace('/','-')+'.profdata')
  subprocess.run(['xcrun','llvm-profdata','merge','-sparse',str(raw),'-o',str(merged)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  exported=subprocess.check_output(['xcrun','llvm-cov','export',str(UN/(run+'-generated')/'renderer/virgl-shader/build'/binary),'-instr-profile='+str(merged)])
  expected=(UN/run/(profile+'.json')).read_bytes();assert json.loads(exported)==json.loads(expected),(run,profile)
  reexports.append({'run':run,'profile':profile,'rawSha256':sha(raw.read_bytes()),'binarySha256':sha((UN/(run+'-generated')/'renderer/virgl-shader/build'/binary).read_bytes()),'completeExportEqual':True,'exportSha256':sha(expected)})
  data=json.loads(exported)
  for fn in data['data'][0]['functions']:
   for region in fn['regions']:
    source=fn['filenames'][region[5]].split('/wasm-vm/')[-1]
    if source not in added or not any(region[0]<=l<=region[2] for l in added[source]):continue
    key=(source,fn['name'],*region[:4],*region[5:]);item=regions.setdefault(key,{'source':source,'function':fn['name'],'region':region[:4]+region[5:],'maxCount':0,'observations':[]});item['maxCount']=max(item['maxCount'],region[4]);item['observations'].append({'run':run,'record':profile+'.json','count':region[4]})
   for branch in fn['branches']:
    source=fn['filenames'][branch[6]].split('/wasm-vm/')[-1]
    if source not in added or not any(branch[0]<=l<=branch[2] for l in added[source]):continue
    key=(source,fn['name'],*branch[:4],*branch[6:]);item=branches.setdefault(key,{'source':source,'function':fn['name'],'branch':branch[:4]+branch[6:],'maxTrue':0,'maxFalse':0,'observations':[]});item['maxTrue']=max(item['maxTrue'],branch[4]);item['maxFalse']=max(item['maxFalse'],branch[5]);item['observations'].append({'run':run,'record':profile+'.json','true':branch[4],'false':branch[5]})
v8={}; source_text={};
for run in ['hot','cold']:
 rows=[]
 for file in (UN/run).rglob('browser-coverage.json'):
  rows.extend((file.relative_to(UN).as_posix(),row['source'],row['sha256'],row['coverage']) for row in json.loads(file.read_text())['scripts'])
 for row in json.loads((UN/run/'node-coverage-runtime.json').read_text())['scripts']:rows.append((run+'/node-coverage-runtime.json',row['source'],row['sha256'],row['coverage']))
 for record,source,digest,script in rows:
  if source not in added:continue
  text=(ROOT/source).read_text();assert sha(text.encode())==digest;source_text[source]=text
  for fn in script['functions']:
   for r in fn['ranges']:
    key=(source,fn['functionName'],r['startOffset'],r['endOffset']);item=v8.setdefault(key,{'source':source,'function':fn['functionName'],'startOffset':r['startOffset'],'endOffset':r['endOffset'],'isBlockCoverage':fn['isBlockCoverage'],'maxCount':0,'observations':[]});item['maxCount']=max(item['maxCount'],r['count']);item['observations'].append({'record':record,'count':r['count']})
# Split at all range endpoints; narrowest containing range is the runtime count.
intervals=[]
for source,text in source_text.items():
 candidates=[r for r in v8.values() if r['source']==source];ends=sorted({v for r in candidates for v in [r['startOffset'],r['endOffset']]})
 for start,end in zip(ends,ends[1:]):
  covered=[r for r in candidates if r['startOffset']<=start and r['endOffset']>=end]
  if not covered:continue
  per_record={}
  for r in covered:
   for observation in r['observations']:
    rec=observation['record'];width=r['endOffset']-r['startOffset'];prev=per_record.get(rec)
    if prev is None or width<prev['width']:per_record[rec]={'width':width,'count':observation['count']}
    elif width==prev['width']:prev['count']=max(prev['count'],observation['count'])
  narrow=list(per_record.values())
  # UTF16 offsets; all changed sources use ASCII except comments.
  utf16=text.encode('utf-16-le');prefix=utf16[:start*2].decode('utf-16-le');body=utf16[start*2:end*2].decode('utf-16-le')
  first=prefix.count('\n')+1;last=first+body.count('\n')
  if any(first<=l<=last for l in added[source]):intervals.append({'source':source,'start':start,'end':end,'lineStart':first,'lineEnd':last,'maxCount':max(r['count'] for r in narrow),'text':body,'counters':narrow})
report={'schema':'fresh-uniform-full-region-audit-v1','addedLines':added,'hunks':hunks,'llvmRegions':list(regions.values()),'llvmBranches':list(branches.values()),'v8FullRanges':list(v8.values()),'v8NarrowIntervals':intervals,'reexports':reexports}
(OUT/'coverage-regions.json').write_text(json.dumps(report,indent=2)+'\n')
for family,rows in [('LLVM regions',regions.values()),('LLVM branches',branches.values()),('V8 intervals',intervals)]:
 print(family,len(list(rows)))
 for row in rows:
  if (row.get('maxCount',1)==0 and row.get('region',[0,0,0,0,0,0,0])[-1]==0) or 'maxTrue' in row and (not row['maxTrue'] or not row['maxFalse']):print(json.dumps({k:v for k,v in row.items() if k not in ['observations','counters']}))
print('Complete raw-profile reexports:',len(reexports))
