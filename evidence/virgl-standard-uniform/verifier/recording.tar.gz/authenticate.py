from pathlib import Path, PurePosixPath
import json,hashlib,tarfile,subprocess
ROOT=Path.cwd(); OUT=ROOT/'target/evidence/virgl-standard-uniform-verifier'; UNPACK=OUT/'unpacked'; UNPACK.mkdir(parents=True,exist_ok=True)
WORKER=ROOT/'evidence/virgl-standard-uniform/worker'; sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((WORKER/'manifest.json').read_bytes()); index_raw=(WORKER/'records.json').read_bytes(); index=json.loads(index_raw); archive=(WORKER/'recording.tar.gz').read_bytes()
assert sha(archive)==manifest['archiveSha256']=='25436c66b4a320aa7bd68d407d37cf8c675438047e1fb8f0160964504e601fe0'; assert len(archive)==manifest['archiveBytes']==81800987
assert sha(index_raw)==manifest['recordIndexSha256']=='8ea043b6586f2309d516e7d5f5ed6403ed413de7f8f6b4f16d317d031ff056b8'
source='01988ea2625edab1669efefec3b7daecd52d64df'; sealing='5535d247a43fd8a04183d8df4fc715a74b451055'
assert index['sourceHead']==manifest['sourceHead']==source; assert index['sealingHead']==manifest['sealingHead']==sealing
indexed={r['path']:r for r in index['records']}; assert len(indexed)==len(index['records'])==manifest['records']==10656
seen=set(); total=0
with tarfile.open(WORKER/'recording.tar.gz','r:gz') as tar:
 for m in tar:
  assert m.isfile() and m.name in indexed and m.name not in seen
  path=PurePosixPath(m.name); assert not path.is_absolute() and '..' not in path.parts
  raw=tar.extractfile(m).read(); r=indexed[m.name]; assert len(raw)==m.size==r['bytes']; assert sha(raw)==r['sha256']
  target=UNPACK/m.name; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(raw); total+=len(raw); seen.add(m.name)
assert seen==indexed.keys()
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT)
changed=git('diff','--name-only',source,sealing).decode().splitlines(); assert changed==['tools/virgl-standard-uniform/seal-test.py','tools/virgl-standard-uniform/seal.py']
confirmation=b'Frozen original uniform shaders, native hardware words/pixels, old ABIs and complete custody authenticated.\n'
receipts={}; filecounts={}; source_refs={}; carried={}; logrecords=[]
for prefix,key in [('hot','hotReceiptSha256'),('cold','coldReceiptSha256')]:
 raw=(UNPACK/prefix/'receipt.json').read_bytes(); assert sha(raw)==manifest[key]; receipt=json.loads(raw); receipts[prefix]=receipt
 assert receipt['status']=='passed' and receipt['gitHead']==source
 assert receipt['authority']=='isolated-standard-uniform-shader' and not receipt['guestExecution'] and not receipt['productionNegotiation'] and not receipt['productionDrawAuthority']
 for name,digest in receipt['files'].items(): assert sha((UNPACK/prefix/name).read_bytes())==digest,(prefix,name)
 for name,digest in receipt['sources'].items():
  if name in source_refs: assert source_refs[name]==digest
  source_refs[name]=digest
 for name,digest in receipt['generated'].items(): assert sha((UNPACK/(prefix+'-generated')/name).read_bytes())==digest,(prefix,name)
 log=(UNPACK/prefix/'acceptance.log').read_bytes(); final=(UNPACK/prefix/'acceptance.log.final').read_bytes()
 assert final==log+confirmation and sha(log)==receipt['files']['acceptance.log'] and b'STANDARD_UNIFORM_RECORDING_COMPLETE\n' in log
 logrecords.append({'run':prefix,'prefixSha256':sha(log),'prefixBytes':len(log),'finalSha256':sha(final),'finalBytes':len(final),'soleAppendBytes':len(confirmation)})
 filecounts[prefix]={'files':len(receipt['files']),'sources':len(receipt['sources']),'generated':len(receipt['generated'])}
 for name,digest in receipt['carriedVerifiedEvidence'].items():
  assert sha(git('show',source+':'+name))==digest==sha(git('show','e118e4c2ddf83b2641fcca267025b1a6ef8fdad9:'+name))
  carried[name]=digest
for name,digest in source_refs.items(): assert sha(git('show',source+':'+name))==digest, name
cold_raw=(UNPACK/'cold/report.json').read_bytes(); assert sha(cold_raw)==manifest['coldReportSha256']; cold=json.loads(cold_raw)
assert cold['status']=='passed' and cold['gitHead']==cold['cloneHead']==source and cold['exitCode']==0 and cold['statusBefore']==cold['statusAfter']==''
assert sha((UNPACK/'cold/cold.log').read_bytes())==cold['logSha256']; assert cold['receiptSha256']==manifest['coldReceiptSha256']; assert cold['command']==['make','verify-E6-T11d16']
for name in ['tools/virgl-standard-uniform/seal.py','tools/virgl-standard-uniform/seal-test.py']:
 assert (UNPACK/'sealing'/name).read_bytes()==git('show',sealing+':'+name)
assert (UNPACK/'sealing/seal-test.log').read_text()=='Exact receipt-prefix authentication and five tamper rejections passed.\n'
result={'status':'passed','sourceHead':source,'sealingHead':sealing,'archiveSha256':sha(archive),'recordIndexSha256':sha(index_raw),'records':len(seen),'uncompressedBytes':total,'counts':filecounts,'checkedUniqueSources':len(source_refs),'carriedVerifiedEvidence':carried,'soleLogAppends':logrecords,'cold':cold,'incrementalFiles':changed,'submissionChangesAfterSealing':git('diff','--name-only',sealing,'5dc84364').decode().splitlines()}
(OUT/'authentication.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['carriedVerifiedEvidence','cold']})); print('Cold',cold['status'],cold['cloneHead'],'scrubbed',cold['removedEnvironmentNames']); print('Authenticated carried files',len(carried))
