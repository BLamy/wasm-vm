from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,subprocess,gzip
ROOT=Path.cwd(); OUT=ROOT/'evidence/virgl-standard-uniform-bindings/verifier';seal=ROOT/'evidence/virgl-standard-uniform-bindings/worker'
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((seal/'manifest.json').read_bytes());indexraw=(seal/'records.json').read_bytes();index=json.loads(indexraw);archive=seal/'recording.tar.gz'
assert sha(archive.read_bytes())==manifest['archiveSha256']=='73a5bdfa08e5b7568b96017d471ac40cfbb8f5d087d52c1b2842cf6c2235d9d5'
assert sha(indexraw)==manifest['recordIndexSha256']=='93f1e05363dd0daced80f4a3229c4bc346410e38da3749288f03f4b20df3f7c4'
records={r['path']:r for r in index['records']};assert len(records)==len(index['records'])==6286==manifest['records'];unpack=OUT/'unpacked';unpack.mkdir(exist_ok=True)
seen=set();bytes_total=0
with tarfile.open(archive,'r:gz') as t:
 for m in t:
  p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts;assert m.name not in seen;seen.add(m.name)
  raw=t.extractfile(m).read();r=records[m.name];assert len(raw)==r['bytes'] and sha(raw)==r['sha256'];bytes_total+=len(raw)
  dest=unpack/m.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
assert seen==set(records)
head='47eb713cb5a456c8723cc32463fb04a4afea9905';base='3ec060c46a9743a62306ae409d0bf1a548d4a616';runtime='e771e262a37f9ee387f434fc752bd777187edcd8'
blob=lambda ref,p:subprocess.check_output(['git','show',ref+':'+p],cwd=ROOT)
closures={};carried={}
for prefix in ['hot','cold']:
 receipt=json.loads((unpack/prefix/'receipt.json').read_bytes());assert receipt['gitHead']==head;expected_execution=runtime if prefix=='hot' else head;assert receipt['executionHead']==expected_execution
 changes=subprocess.check_output(['git','diff','--name-only',receipt['executionHead'],head],cwd=ROOT,text=True).splitlines();assert changes==receipt['incrementalHarnessChanges'];assert set(changes)<={'tools/virgl-command/standard-uniform-binding-coverage.py','tools/virgl-command/standard-uniform-binding-receipt.py'}
 for p,d in receipt['sources'].items():assert sha(blob(head,p))==d,(prefix,p)
 for p,d in receipt['generated'].items():
  generated_prefix='hot-generated' if prefix=='hot' else 'cold-generated';assert sha((unpack/generated_prefix/p).read_bytes())==d
 for p,d in receipt['files'].items():assert sha((unpack/prefix/p).read_bytes())==d,(prefix,p)
 closures[prefix]={'sources':len(receipt['sources']),'generated':receipt['generated'],'files':len(receipt['files']),'runtimeHead':receipt['executionHead'],'parserChanges':changes}
 for p,d in receipt['carriedVerifiedEvidence'].items():assert blob(base,p)==blob(head,p) and sha(blob(head,p))==d;carried[p]=d
cold=json.loads((unpack/'cold/report.json').read_bytes());assert cold['gitHead']==cold['cloneHead']==head and cold['status']=='passed' and cold['statusBefore']==cold['statusAfter']=='' and cold['exitCode']==0
assert sha((unpack/'cold/cold.log').read_bytes())==cold['logSha256'];assert sha((unpack/'cold/receipt.json').read_bytes())==cold['receiptSha256']
assert not subprocess.check_output(['git','diff','--name-only',base,head,'--','renderer/virgl-shader','crates','web','tools/guest'],cwd=ROOT,text=True).strip()
for p in ['renderer/virgl-command/decoder.mjs','renderer/virgl-command/resources.mjs','renderer/virgl-command/state.mjs']:
 assert blob(runtime,p)==blob(head,p)==(ROOT/p).read_bytes()
# Authenticate every member of unchanged predecessor evidence, not merely its outer digest.
for label in ['worker-offset-repair','verifier-offset-repair']:
 path=ROOT/'evidence/virgl-standard-uniform'/label;man=json.loads((path/'manifest.json').read_bytes());ind=json.loads((path/'records.json').read_bytes());assert sha((path/'recording.tar.gz').read_bytes())==man['archiveSha256'];assert sha((path/'records.json').read_bytes())==man['recordIndexSha256'];rows={r['path']:r for r in ind['records']};check=set()
 with tarfile.open(path/'recording.tar.gz','r:gz') as t:
  for m in t:
   assert m.isfile() and m.name not in check;raw=t.extractfile(m).read();r=rows[m.name];assert len(raw)==r['bytes'] and sha(raw)==r['sha256'];check.add(m.name)
 assert check==set(rows);closures[label]={'archive':man['archiveSha256'],'index':man['recordIndexSha256'],'members':len(rows)}
result={'status':'passed','archive':manifest,'membersAuthenticated':len(seen),'uncompressedBytes':bytes_total,'closures':closures,'cold':cold,'carriedSources':len(carried)}
(OUT/'authentication.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
