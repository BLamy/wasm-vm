from pathlib import Path
import json,hashlib,tarfile,io,gzip,subprocess
ROOT=Path.cwd();OUT=ROOT/'evidence/virgl-standard-uniform-bindings/verifier';sha=lambda x:hashlib.sha256(x).hexdigest();members={}
selected=['citations.json','predictions.json','authentication.json','recording-audit.json','independent-run-audit.json','coverage-regions.json','coverage-waivers.json','supplement-custody.json','authenticate.py','audit_records.py','audit_coverage.py','audit_supplement.py','classify_coverage.py','novel-body.mjs','prepare_attack.py','promote.py','seal.py']
for name in selected:members['critic/'+name]=(OUT/name).read_bytes()
for name in ['matrix-2718281829','matrix-362436069','matrix-521288629','novel-3141592653','novel-733973753','novel-sabotage','promoted']:
 for p in (OUT/name).rglob('*'):
  if p.is_file():members['critic/'+p.relative_to(OUT).as_posix()]=p.read_bytes()
sourcepaths=set()
for name in ['matrix-2718281829','matrix-362436069','matrix-521288629','novel-3141592653','novel-733973753','promoted/gpu-3141592653','promoted/gpu-733973753']:
 report=json.loads((OUT/name/'report.json').read_text());assert report['status']=='passed'
 for row in report['sources']:
  p=row['path'];raw=(ROOT/p).read_bytes();assert sha(raw)==row['sha256'];sourcepaths.add(p)
for name in ['tools/verify-virgl-standard-uniform-bindings-adversarial.sh','tools/virgl-command/standard-uniform-binding-adversarial-audit.py','Makefile']:sourcepaths.add(name)
for p in sorted(sourcepaths):members['source/'+p]=(ROOT/p).read_bytes()
for p,d in json.loads((OUT/'predictions.json').read_text())['sourceHashes'].items():
 assert sha((ROOT/p).read_bytes())==d and (ROOT/p).read_bytes()==subprocess.check_output(['git','show','47eb713cb5a456c8723cc32463fb04a4afea9905:'+p])
for name in ['recording-audit.json','independent-run-audit.json','promoted/independent-audit.json']:assert json.loads((OUT/name).read_text())['status']=='passed'
assert json.loads((OUT/'coverage-regions.json').read_text())['status']=='held'
index=(json.dumps({'schema':'original-uniform-binding-critic-records-v1','task':'E6-T11d17','reviewedSubmission':'16316900','frozenRuntimeHead':'47eb713cb5a456c8723cc32463fb04a4afea9905','workerArchive':'73a5bdfa08e5b7568b96017d471ac40cfbb8f5d087d52c1b2842cf6c2235d9d5','records':[{'path':n,'bytes':len(raw),'sha256':sha(raw)} for n,raw in sorted(members.items())]},indent=2)+'\n').encode();(OUT/'records.json').write_bytes(index)
buf=io.BytesIO()
with gzip.GzipFile(fileobj=buf,mode='wb',mtime=0) as z:
 with tarfile.open(fileobj=z,mode='w') as t:
  for n,raw in sorted(members.items()):
   info=tarfile.TarInfo(n);info.size=len(raw);info.mtime=0;info.mode=0o644;t.addfile(info,io.BytesIO(raw))
archive=buf.getvalue();(OUT/'recording.tar.gz').write_bytes(archive)
seen=set()
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as t:
 for member in t:
  assert member.isfile() and member.name not in seen;seen.add(member.name);assert t.extractfile(member).read()==members[member.name]
assert seen==set(members)
manifest={'schema':'original-uniform-binding-critic-seal-v1','task':'E6-T11d17','verdict':'verified','reviewedSubmission':'16316900','runtimeCommit':'e771e262a37f9ee387f434fc752bd777187edcd8','frozenRuntimeHead':'47eb713cb5a456c8723cc32463fb04a4afea9905','workerArchive':'73a5bdfa08e5b7568b96017d471ac40cfbb8f5d087d52c1b2842cf6c2235d9d5','records':len(members),'archiveSha256':sha(archive),'archiveBytes':len(archive),'recordIndexSha256':sha(index),'predictionSha256':sha((OUT/'predictions.json').read_bytes()),'runtimeSourceHashes':json.loads((OUT/'predictions.json').read_text())['sourceHashes'],'sourceHashes':{p:sha((ROOT/p).read_bytes()) for p in sorted(sourcepaths)},'nativeProofs':{'sealedWorkerFramesAudited':313,'sealedWorkerPixelsAudited':80128,'independentFramesAudited':461,'independentPixelsAudited':118016,'promotedFramesAudited':5,'promotedPixelsAudited':1280},'unqualified':{'guestExecution':False,'productionNegotiation':False,'productionDrawAuthority':False,'deployment':False,'performance':False}}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k not in ['sourceHashes','runtimeSourceHashes']}))
