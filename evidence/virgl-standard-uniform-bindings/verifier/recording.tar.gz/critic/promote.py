from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'evidence/virgl-standard-uniform-bindings/verifier'
body=(OUT/'novel-body.mjs').read_text();(ROOT/'tools/virgl-command/standard-uniform-binding-adversarial-body.mjs').write_text('/** Test-only distinct native stage ranges and allocation-generation regression. */\n'+body)
source=(ROOT/'tools/verify-virgl-standard-uniform-bindings.mjs').read_text();source=source.replace('["--output", "--fault", "--smoke", "--node-only"]','["--output", "--fault", "--seed"]');source=source.replace('assert.ok(options.output); assert.ok(!options.fault || ["block-word", "range-offset", "slot-zero-variant"].includes(options.fault));\nfor (const flag of ["smoke", "node-only"]) assert.ok(!options[flag] || options[flag] === "true");', 'assert.ok(options.output); assert.ok(!options.fault || options.fault === "range-offset");\nconst seed = Number(options.seed); assert.ok(Number.isInteger(seed) && seed > 0 && seed <= 0xffffffff);')
source=source.replace(" 'tools/verify-virgl-standard-uniform-bindings.mjs',", " 'tools/verify-virgl-standard-uniform-bindings.mjs',\n 'tools/verify-virgl-standard-uniform-bindings-adversarial.mjs',\n 'tools/virgl-command/standard-uniform-binding-adversarial-body.mjs',")
marker='    report.fault=options.fault??null;'
injection='''    report.criticVariants = [];
    const harnessPath = 'renderer/virgl-command/tests/standard-uniform-buffer-bindings.mjs';
    const schedulerPath = 'renderer/virgl-command/tests/standard-instanced-draws.mjs';
    const body = sources.get('tools/virgl-command/standard-uniform-binding-adversarial-body.mjs').toString();
    const original = sources.get(harnessPath).toString();
    const generated = original.slice(0, original.indexOf('export async function runAcceptance')) + body.replaceAll('__SEED__', String(seed));
    const scheduler = sources.get(schedulerPath).toString().replace('steps % 3', '(steps * ' + (seed % 5 + 1) + ' + ' + (seed % 7) + ') % 7');
    for (const [name, text] of [[harnessPath, generated], [schedulerPath, scheduler]]) {
      const bytes = Buffer.from(text), file = path.join(output, 'served-' + path.basename(name));
      await fs.writeFile(file, bytes);
      report.criticVariants.push({ path: name, file, originalSha256: sha256(sources.get(name)), servedSha256: sha256(bytes) });
      sources.set(name, bytes);
    }
    report.seed = seed;
'''
assert source.count(marker)==1;source=source.replace(marker,injection+marker)
(ROOT/'tools/verify-virgl-standard-uniform-bindings-adversarial.mjs').write_text(source)
# Retain the independently implemented original-byte interpreter and full physical assertions.
audit=(OUT/'audit_records.py').read_text();audit=audit.replace("ROOT=Path.cwd();OUT=ROOT/'evidence/virgl-standard-uniform-bindings/verifier';U=OUT/'unpacked';H='47eb713cb5a456c8723cc32463fb04a4afea9905'", "ROOT=Path(__file__).resolve().parents[2]")
a=audit.index('pred=json.loads(');b=audit.index("summary={'schema':",a);audit=audit[:a]+"predqueues={}\n"+audit[b:]
a=audit.index("if __name__=='__main__':");audit=audit[:a]+'''if __name__=='__main__':
 import sys
 output=Path(sys.argv[1]).resolve()
 for directory in sorted(output.glob('gpu-*')):audit(directory,directory.name)
 audit(output/'sabotage-range', 'sabotage-range',fault=True)
 summary['status']='passed';(output/'independent-audit.json').write_text(json.dumps(summary,indent=2)+'\\n')
 print(json.dumps({k:v for k,v in summary.items() if k!='runs'}))
'''
(ROOT/'tools/virgl-command/standard-uniform-binding-adversarial-audit.py').write_text('#!/usr/bin/env python3\n"""Independent original-packet interpreter and actual native range/full-pixel oracle."""\n'+audit)
script='''#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
evidence=${VIRGL_UNIFORM_BINDINGS_ADVERSARIAL_DIR:-target/evidence/virgl-standard-uniform-bindings-adversarial}
mkdir -p "$evidence"
evidence=$(cd "$evidence" && pwd)
exec > >(tee "$evidence/acceptance.log") 2>&1
node --check tools/verify-virgl-standard-uniform-bindings-adversarial.mjs
node --check tools/virgl-command/standard-uniform-binding-adversarial-body.mjs
python3 -m py_compile tools/virgl-command/standard-uniform-binding-adversarial-audit.py
for seed in 3141592653 733973753; do
  node tools/verify-virgl-standard-uniform-bindings-adversarial.mjs --output "$evidence/gpu-$seed" --seed "$seed"
done
if node tools/verify-virgl-standard-uniform-bindings-adversarial.mjs --output "$evidence/sabotage-range" --seed 3141592653 --fault range-offset; then
  echo 'ERROR: distinct-stage original pixel oracle failed to catch native range sabotage' >&2
  exit 1
fi
python3 tools/virgl-command/standard-uniform-binding-adversarial-audit.py "$evidence"
'''
(ROOT/'tools/verify-virgl-standard-uniform-bindings-adversarial.sh').write_text(script)
make=ROOT/'Makefile';s=make.read_text();assert 'verify-E6-T11d17-adversarial:' not in s;s+='\n.PHONY: verify-E6-T11d17-adversarial\nverify-E6-T11d17-adversarial:\n\tbash tools/verify-virgl-standard-uniform-bindings-adversarial.sh\n';make.write_text(s)
print('Promoted only test-body, recorder, independent physical oracle and verify target; runtime untouched.')
