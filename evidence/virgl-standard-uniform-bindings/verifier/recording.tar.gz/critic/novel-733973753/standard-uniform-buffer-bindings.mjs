import {decodeSubmission,decodeStandardSubmission,decodeStandardUniformSubmission} from '../decoder.mjs';
import {createResourceStore,createStandardUniformResourceStore,computeTransferLayout,computeStandardUniformTransferLayout,createWebGL2TransferBackend} from '../resources.mjs';
import {createVirglStandardUniformAsyncRenderer,createVirglStandardAsyncRenderer} from '../state.mjs';
import {createVirglStandardUniformShaderBridge} from '../../virgl-shader/standard.mjs';
import {checks,packet,join,meta,add,transfer,clear,submit,dispose,hex,blob,traceGL} from './standard-instanced-draws.mjs';
import {specimen,setup,draw,bind} from '../../../tools/virgl-command/standard-uniform-binding-fixtures.mjs';

export function runWireAcceptance(){
 const c=checks(),records=[];
 for(const stage of [0,1,2,5,6])for(const slot of [0,1,12,13,14,15])for(const id of [0,777]){
  const raw=bind(stage,slot,16,id?32:0xffffffff,id),expected=stage<=5&&slot<15&&(!id||stage<=1&&slot<=12),result=decodeStandardUniformSubmission(raw);
  c.same(result.ok,expected,'original uniform stage/slot/null reset');c.same([decodeSubmission(raw).ok,decodeStandardSubmission(raw).ok],[false,false],'old wire facets remain isolated');
  if(expected&&!id)c.same(result.commands[0].fields,{stage,index:slot,offset:0,length:0,resourceHandle:0},'original null ignores incoming range');records.push({hex:hex(raw),expected,result});
 }
 for(const fields of [[0,1,0,0,7],[0,1,0xffffffff,1,7],[0,1,0xfffffff0,32,7]]){
  const raw=packet(27,0,fields),result=decodeStandardUniformSubmission(raw);c.same(result.ok,false,'nonempty u32 uniform range');records.push({hex:hex(raw),expected:false,result});
 }
 for(const raw of [packet(27,0,[0,1,0,16]),packet(27,0,[0,1,0,16,7,0]),packet(27,1,[0,1,0,16,7]),join(bind(0,1,0,16,7),packet(27,0,[]))]){
  const result=decodeStandardUniformSubmission(raw);c.same(result.ok,false,'complete original uniform framing');records.push({hex:hex(raw),expected:false,result});
 }
 c.same(decodeStandardUniformSubmission(bind(0,1,0,16,7),{uniform:true}).error.code,'invalid-provenance','guest labels cannot select facets');
 const backend={maxTextureSize:4096,allocate:m=>({bytes:new Uint8Array(m.byteLength)}),destroy:s=>{s.destroyed=true;},upload:(s,m,l,b)=>s.bytes.set(b,l.box.x),readback:(s,m,l)=>s.bytes.slice(l.box.x,l.box.x+l.tightBytes),dispose(){}};
 const layouts=[],ownership=[];const fields={resourceHandle:200,level:0,usage:0,stride:0,layerStride:0,box:{x:0,y:0,z:0,width:64,height:1,depth:1},dataOffset:0,direction:1};
 for(const binding of [16,32,64,80,96,524288]){
  const metadata=meta(200,0,64,binding,64),a=computeStandardUniformTransferLayout(metadata,fields,64),old=computeTransferLayout(metadata,fields,64);
  c.same(a.ok,[16,32,64,80].includes(binding),'selected resource wire role');c.same(old.ok,[16,32].includes(binding),'old resource layout shape');layouts.push({metadata,fields,backingBytes:64,selected:a,old});
 }
 for(const action of ['detach','unref-reuse','lease','context','revision','failed-revision','submitted-upload','dispose']){
  let failed=false;const owner=c.ok(createStandardUniformResourceStore({backend:{...backend,upload(...args){backend.upload(...args);if(failed)throw Error('partial original upload');}}}),'range owner'),{store,uniformAccess:access}=owner;
  c.ok(store.createContext(1),'range context');const original=c.ok(store.createResource(meta(200,0,64,64,64)),'range allocation').resource;c.ok(store.attachContext(1,200),'range membership');c.ok(store.attachBacking(200,[new Uint8Array(64)]),'range backing');
  const lease=c.ok(store.retainStorage(1,200,'uniform'),'range lease').lease,range=c.ok(access.capture(lease,16,48),'exact original allocation end');
  for(const[offset,length]of [[65,1],[63,2],[0,0],[-1,1],['0',16]])c.same(access.capture(lease,offset,length).ok,false,'range primitive/bounds rejects');
  if(action==='detach')c.ok(store.detachContext(1,200),'detach retains original binding');
  if(action==='unref-reuse'){c.ok(store.unref(200),'public unref original');const newer=c.ok(store.createResource(meta(200,0,64,80,64)),'reuse numeric name').resource;c.same(newer.generation!==original.generation,true,'numeric ID owns distinct storage');}
  if(action==='lease')c.ok(store.releaseStorage(lease),'external lease release');
  if(action==='context'){c.ok(store.destroyContext(1),'destroy range context');c.ok(store.createContext(1),'reuse context ID');}
  if(action==='submitted-upload')c.ok(access.submit(range.token),'range becomes allocation hold');
  if(['revision','failed-revision','submitted-upload'].includes(action)){
   failed=action==='failed-revision';const command=decodeStandardUniformSubmission(transfer(200,64)).commands[0],prepared=c.ok(store.prepareTransfer(1,command),'original upload ticket');c.same(store.executeTransfer(prepared.ticket).ok,!failed,'actual upload revision');
  }
  if(action==='dispose')c.ok(store.dispose(),'dispose with pending range');
  const stale=['lease','context','revision','failed-revision','dispose','submitted-upload'].includes(action);c.same(access.validate(range.token).ok,!stale,'pending range owns exact lease/context/revision');
  if(!stale)c.ok(access.submit(range.token),'submit exact retained range');c.same(access.submit(range.token).ok,false,'range cannot submit twice');
  c.ok(access.release(range.token),'release pending/submitted/revoked range once');c.same(access.release(range.token).ok,false,'released range rejects');
  const before=store.inspect();c.ok(store.dispose(),'range final store cleanup');for(const [key,value]of Object.entries(store.inspect().budgets))c.same(value,0,'zero range budget '+key);ownership.push({action,original,range:{generation:range.generation,offset:range.offset,length:range.byteLength},before,after:store.inspect()});
 }
 {const owner=c.ok(createStandardUniformResourceStore({backend,limits:{tickets:2}}),'bounded uniform ticket owner'),{store,uniformAccess:access}=owner;c.ok(store.createContext(1),'budget context');c.ok(store.createResource(meta(200,0,64,16,64)),'vertex creation hint');c.ok(store.attachContext(1,200),'budget member');c.ok(store.attachBacking(200,[new Uint8Array(64)]),'budget backing');const lease=c.ok(store.retainStorage(1,200,'uniform'),'vertex can serve uniform').lease,a=c.ok(access.capture(lease,0,16),'ticket1'),b=c.ok(access.capture(lease,16,16),'ticket2');c.same(access.capture(lease,32,16).error.code,'limit-exceeded','uniform ranges share ticket ceiling');c.same(store.prepareTransfer(1,decodeStandardUniformSubmission(transfer(200,64)).commands[0]).error.code,'limit-exceeded','range snapshots share transfers ceiling');c.ok(access.release(a.token),'return first token');c.ok(access.release(b.token),'return second token');c.ok(store.releaseStorage(lease),'return original lease');c.ok(store.dispose(),'bounded owner cleanup');}
 {const owner=c.ok(createStandardUniformResourceStore({backend}),'strict original range owner'),{store,uniformAccess:access}=owner;c.ok(store.createContext(1),'strict range context');c.ok(store.createResource(meta(200,0,64,80,64)),'original combined role');c.ok(store.attachContext(1,200),'strict range membership');const lease=c.ok(store.retainStorage(1,200,'uniform'),'strict range lease').lease,vertex=c.ok(store.retainStorage(1,200,'vertex'),'constant creation hint can serve vertex').lease;let invoked=0;const adversarial=new Proxy({valueOf(){invoked++;return 0;}},{get(){invoked++;throw Error('unexpected getter');}});for(const args of [[adversarial,0,16],[lease,adversarial,16],[lease,0,adversarial],[vertex,0,16]])c.same(access.capture(...args).ok,false,'primitive range and capability identities reject');c.same(invoked,0,'range inputs never invoke proxy/getter/coercion');for(const token of [adversarial,{},null]){c.same(access.validate(token).ok,false,'foreign pending range');c.same(access.submit(token).ok,false,'foreign submitted range');c.same(access.release(token).ok,false,'foreign released range');}c.ok(store.dispose(),'strict range cleanup');}
 const old=c.ok(createResourceStore({backend}),'old factory');c.same(Object.hasOwn(old,'uniformAccess'),false,'old public shape stays isolated');c.ok(old.store.dispose(),'old cleanup');
 let getters=0;const malformed=meta(200,0,64,64,64);Object.defineProperty(malformed,'width',{get(){getters++;return 64;}});const owner=c.ok(createStandardUniformResourceStore({backend}),'descriptor owner');c.same(owner.store.createResource(malformed).ok,false,'metadata accessors reject');c.same(getters,0,'metadata getter never runs');c.ok(owner.store.dispose(),'descriptor cleanup');
 c.same(createVirglStandardAsyncRenderer({uniformAccess:{}}).ok,false,'old state facet rejects new capability');
 return{status:'passed',records,layouts,ownership,predictions:c.rows};
}

function rig(gl,bridge,c,s,{delay=0,step=64,resourceLimits,stateLimits,cacheLimits,jobLimits,fault,hostFault,nativeFault}={}){
 const trace=traceGL(gl,c,delay),allocations=[],draws=[],requests=[],leases=[],faultEvents=[];let faultArmed=false,calls=0;
 const native=new Proxy(trace.gl,{get(target,name){
  const base=Reflect.get(target,name,target);if(typeof base!=='function')return base;
  if(name==='getParameter'&&hostFault)return parameter=>{const value=base(parameter);const pins={vertex:gl.MAX_VERTEX_UNIFORM_BLOCKS,fragment:gl.MAX_FRAGMENT_UNIFORM_BLOCKS,combined:gl.MAX_COMBINED_UNIFORM_BLOCKS,block:gl.MAX_UNIFORM_BLOCK_SIZE,binding:gl.MAX_UNIFORM_BUFFER_BINDINGS,alignment:gl.UNIFORM_BUFFER_OFFSET_ALIGNMENT};return parameter===pins[hostFault]?hostFault==='alignment'?0:hostFault==='block'?16383:hostFault==='vertex'?13:hostFault==='fragment'?12:26:value;};
  if(nativeFault&&name===nativeFault.method)return(...args)=>{
   if(faultArmed&&++calls===nativeFault.ordinal){faultEvents.push({method:name,ordinal:calls,mode:nativeFault.mode});
    if(nativeFault.mode==='null')return null;if(nativeFault.mode==='wait')return gl.WAIT_FAILED;
    if(nativeFault.mode==='error'){const result=base(...args);gl.enable(0);return result;}
   }return base(...args);
  };
  if(name==='bindBufferRange'&&fault==='range-offset')return(target,binding,buffer,offset,length)=>base(target,binding,buffer,binding===14?offset+s.alignment:offset,length);
  if(!['drawElements','drawArrays','drawElementsInstanced','drawArraysInstanced'].includes(name))return base;
  return(...args)=>{
   const program=gl.getParameter(gl.CURRENT_PROGRAM),blocks=[];
   for(let index=0;index<gl.getProgramParameter(program,gl.ACTIVE_UNIFORM_BLOCKS);index++){
    const name=gl.getActiveUniformBlockName(program,index),binding=gl.getActiveUniformBlockParameter(program,index,gl.UNIFORM_BLOCK_BINDING),buffer=gl.getIndexedParameter(gl.UNIFORM_BUFFER_BINDING,binding),allocation=allocations.find(a=>a.storage.buffer===buffer),members=[...gl.getActiveUniformBlockParameter(program,index,gl.UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES)].map(i=>{const m=gl.getActiveUniform(program,i);return{name:m.name,type:m.type,count:m.size,offset:gl.getActiveUniforms(program,[i],gl.UNIFORM_OFFSET)[0],stride:gl.getActiveUniforms(program,[i],gl.UNIFORM_ARRAY_STRIDE)[0],blockIndex:gl.getActiveUniforms(program,[i],gl.UNIFORM_BLOCK_INDEX)[0]};});
    let raw=null;if(buffer){gl.bindBuffer(gl.COPY_READ_BUFFER,buffer);raw=new Uint8Array(gl.getBufferParameter(gl.COPY_READ_BUFFER,gl.BUFFER_SIZE));gl.getBufferSubData(gl.COPY_READ_BUFFER,0,raw);gl.bindBuffer(gl.COPY_READ_BUFFER,null);}
    blocks.push({name,index,binding,bytes:gl.getActiveUniformBlockParameter(program,index,gl.UNIFORM_BLOCK_DATA_SIZE),vertex:gl.getActiveUniformBlockParameter(program,index,gl.UNIFORM_BLOCK_REFERENCED_BY_VERTEX_SHADER),fragment:gl.getActiveUniformBlockParameter(program,index,gl.UNIFORM_BLOCK_REFERENCED_BY_FRAGMENT_SHADER),start:gl.getIndexedParameter(gl.UNIFORM_BUFFER_START,binding),length:gl.getIndexedParameter(gl.UNIFORM_BUFFER_SIZE,binding),resourceId:allocation?.metadata.id??null,generation:allocation?.generation??null,members,raw});
   }
   const attributes=[];
   for(let i=0;i<gl.getProgramParameter(program,gl.ACTIVE_ATTRIBUTES);i++){
    const info=gl.getActiveAttrib(program,i),location=gl.getAttribLocation(program,info.name);if(location<0)continue;
    const buffer=gl.getVertexAttrib(location,gl.VERTEX_ATTRIB_ARRAY_BUFFER_BINDING),allocation=allocations.find(a=>a.storage.buffer===buffer);let raw=null;
    if(allocation){raw=new Uint8Array(allocation.metadata.byteLength);gl.bindBuffer(gl.COPY_READ_BUFFER,buffer);gl.getBufferSubData(gl.COPY_READ_BUFFER,0,raw);gl.bindBuffer(gl.COPY_READ_BUFFER,null);}
    attributes.push({name:info.name,shaderType:info.type,location,enabled:gl.getVertexAttrib(location,gl.VERTEX_ATTRIB_ARRAY_ENABLED),integer:gl.getVertexAttrib(location,gl.VERTEX_ATTRIB_ARRAY_INTEGER),type:gl.getVertexAttrib(location,gl.VERTEX_ATTRIB_ARRAY_TYPE),normalized:gl.getVertexAttrib(location,gl.VERTEX_ATTRIB_ARRAY_NORMALIZED),stride:gl.getVertexAttrib(location,gl.VERTEX_ATTRIB_ARRAY_STRIDE),offset:gl.getVertexAttribOffset(location,gl.VERTEX_ATTRIB_ARRAY_POINTER),genericValues:[...gl.getVertexAttrib(location,gl.CURRENT_VERTEX_ATTRIB)],resourceId:allocation?.metadata.id??null,generation:allocation?.generation??null,raw});
   }
   draws.push({label:r.currentLabel,name,args:[...args],blocks,attributes,shaders:gl.getAttachedShaders(program).map(shader=>({stage:gl.getShaderParameter(shader,gl.SHADER_TYPE),glsl:gl.getShaderSource(shader)}))});return base(...args);
  };
 }});
 const backend=c.ok(createWebGL2TransferBackend(native),'real uniform backend').backend,owner=c.ok(createStandardUniformResourceStore({backend:{...backend,allocate(metadata){const storage=backend.allocate(metadata);allocations.push({metadata,storage});return storage;},upload(storage,metadata,layout,bytes){if(fault==='block-word'&&metadata.id===200){bytes=bytes.slice();bytes[s.banks[0].offset+s.vector*16]^=1;}return backend.upload(storage,metadata,layout,bytes);}},...(resourceLimits?{limits:resourceLimits}:{})}),'uniform resource owner');
 const original=bridge,selected={...bridge,translatePairUniforms(request){const result=original.translatePairUniforms(request);requests.push({request:{...request},result:JSON.parse(JSON.stringify(result))});return result;}};
 const store={...owner.store,retainStorage(...args){const answer=owner.store.retainStorage(...args);if(answer.ok)leases.push({lease:answer.lease,role:args[2],id:args[1]});return answer;}};
 const built=createVirglStandardUniformAsyncRenderer({gl:native,shaderBridge:selected,resources:store,bindings:owner.bindings,asyncAccess:owner.asyncAccess,uniformAccess:owner.uniformAccess,
  jobLimits:{commandsPerStep:step,...jobLimits},...(stateLimits?{limits:stateLimits}:{}),...(cacheLimits?{cacheLimits}:{}),primitiveAssembly:'lists'});
 if(hostFault){c.same(built.error?.code,'unsupported-host','native uniform limit gate');c.ok(owner.store.dispose(),'host rejection resource cleanup');return{hostRejected:built};}
 const renderer=c.ok(built,'selected original uniform renderer').renderer;
 const r={gl,c,bridge:selected,...owner,store,renderer,trace,allocations,draws,requests,leases,created:[],faultEvents,armFault(){faultArmed=true;calls=0;},width:s.width,height:s.height,frame:0,history:[],exchanges:[],blobs:[],frames:[],currentLabel:''};r.add=(metadata,bytes)=>{const resource=add(r,metadata,bytes);r.created.push({metadata:{...metadata},generation:resource.generation,beforeSubmission:r.history.length});return resource;};
 for(const id of[1,2]){c.ok(store.createContext(id),'uniform resource context');c.ok(renderer.createContext(id),'uniform state context');}
 r.add(meta(1,2,67,2,s.width,s.height),new Uint8Array(s.width*s.height*4));return r;
}
async function frame(r,record,s){
 r.c.ok(record.result,'original uniform draw completion');r.c.same(record.result.gpuComplete,true,'actual uniform GPU fence');
 const gl=r.gl,fb=gl.createFramebuffer();gl.bindFramebuffer(gl.READ_FRAMEBUFFER,fb);gl.framebufferTexture2D(gl.READ_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,r.allocations[0].storage.texture,0);gl.readBuffer(gl.COLOR_ATTACHMENT0);gl.bindBuffer(gl.PIXEL_PACK_BUFFER,null);gl.pixelStorei(gl.PACK_ALIGNMENT,1);for(const name of ['PACK_ROW_LENGTH','PACK_SKIP_PIXELS','PACK_SKIP_ROWS'])gl.pixelStorei(gl[name],0);
 const raw=new Uint8Array(s.width*s.height*4);gl.readPixels(0,0,s.width,s.height,gl.RGBA,gl.UNSIGNED_BYTE,raw);gl.deleteFramebuffer(fb);
 const native=[];for(const draw of r.draws.filter(row=>row.label===record.label)){const blocks=[],attributes=[];for(const block of draw.blocks){const{raw,...info}=block;blocks.push({...info,storage:raw?await blob(r,raw):null});}for(const attribute of draw.attributes){const{raw,...info}=attribute;attributes.push({...info,storage:raw?await blob(r,raw):null});}native.push({...draw,blocks,attributes});}
 const expected=s.expected,misses=[];for(let at=0;at<raw.length;at++)if(raw[at]!==expected[at%4]){misses.push({at,expected:expected[at%4],actual:raw[at]});if(misses.length===16)break;}
 const row={label:record.label,width:s.width,height:s.height,expected,native,created:r.created.map(row=>({...row})),history:r.history.map(({hex,ctx,result,label})=>({hex,ctx,result,label})),inputs:r.exchanges.map(e=>({...e})),dump:record.dump,pixels:await blob(r,raw),audit:{held:misses.length===0,misses}};r.frames.push(row);
 r.c.same(misses,[],'independent original uniform pixels after completed fence');r.c.same(gl.getError(),gl.NO_ERROR,'uniform capture no GL error');return row;
}
export async function runAcceptance({fault}={}) {
 const c=checks(),report={schema:'d17-distinct-stage-range-critic-v1',status:'running',guestExecution:false,productionNegotiation:false,predictions:c.rows,frames:[],runs:[],ownership:[],blobs:[],seed:733973753};window.__standardUniformBindingEvidence=report;
 const gl=document.querySelector('#gpu').getContext('webgl2',{antialias:false,preserveDrawingBuffer:true,failIfMajorPerformanceCaveat:true}),debug=gl.getExtension('WEBGL_debug_renderer_info');report.gpu={renderer:gl.getParameter(debug.UNMASKED_RENDERER_WEBGL),version:gl.getParameter(gl.VERSION)};if(/swiftshader|llvmpipe|softpipe|lavapipe/i.test(report.gpu.renderer))throw Error('physical GPU required');
 const bridge=await createVirglStandardUniformShaderBridge(),alignment=gl.getParameter(gl.UNIFORM_BUFFER_OFFSET_ALIGNMENT),seed=733973753,shift=seed%4*8;
 const spec=chosen=>{
  const a=specimen({alignment,slots:[0],count:4,vector:3,shift,seed:chosen,formats:true,constant:true,indexed:true}),b=specimen({alignment,slots:[0],count:4,vector:3,shift,seed:chosen^0x69581abc}),bank=a.banks[0],second=Math.ceil((bank.offset+bank.length+alignment)/alignment)*alignment,combined=new Uint8Array(second+bank.length+2*alignment);combined.fill(0xa7);combined.set(new Uint8Array(bank.words.buffer),bank.offset);combined.set(new Uint8Array(b.banks[0].words.buffer),second);bank.data=combined;a.data.set(bank.id,combined);a.second=second;
  const bits=x=>new Uint32Array(new Float32Array([x]).buffer)[0],additions=[[-1,2,3,4],[0xffffffff,7,9,11],[1,-1,255,1].map(bits),[-1,Math.fround(-256/511),1,-1].map(bits)];
  const sums=Array.from({length:4},(_,lane)=>(bank.words[12+lane]+b.banks[0].words[12+lane])>>>0);for(const row of additions)for(let lane=0;lane<4;lane++)sums[lane]=(sums[lane]+row[lane])>>>0;a.expected=sums.map(n=>(n>>>shift)&255);return a;
 };
 const s=spec(seed),r=rig(gl,bridge,c,s,{delay:5+seed%7,step:1+seed%3,fault});r.frames=report.frames;r.blobs=report.blobs;r.currentLabel='distinct-stage-original-setup';c.ok((await submit(r,1,join(setup(r,s),bind(1,0,s.second,s.banks[0].length,200)),r.currentLabel)).result,'original two distinct stage ranges setup');
 let mutation=null,hold=null;r.currentLabel='distinct-stage-retained-'+seed;
 const rec=await submit(r,1,join(clear([0,0,0,0]),draw(s)),r.currentLabel,(_step,token)=>{
  const state=r.renderer.inspect();
  if(!mutation&&state.jobs.status==='waiting-attributes'){
   c.same(state.jobs.uniformPending,2,'two original stage ranges captured');const original=r.allocations.find(row=>row.metadata.id===200),replacement=spec(seed^0x13297bdc);c.ok(r.store.writeBacking(200,0,new Uint8Array(s.banks[0].data.length).fill(0x53)),'original backing dirt is isolated');c.ok(r.store.detachContext(1,200),'detach original stage allocation');c.ok(r.store.unref(200),'drop original numeric name');const next=r.add(meta(200,0,64,80,replacement.banks[0].data.length),replacement.banks[0].data);const ticket=c.ok(r.store.prepareTransfer(1,decodeStandardUniformSubmission(transfer(200,replacement.banks[0].data.length)).commands[0]),'replacement direct original transfer');c.ok(r.store.executeTransfer(ticket.ticket),'replacement upload cannot revise original allocation');mutation={originalGeneration:original.generation,replacementGeneration:next.generation,before:state,after:r.store.inspect()};c.same(next.generation!==original.generation,true,'replacement distinct original allocation');
  }
  if(!hold&&state.jobs.status==='finishing'){hold={state,access:r.uniformAccess.inspect(),resources:r.store.inspect()};c.same(state.jobs.uniformHolds,1,'distinct stage byte ranges deduplicate only allocation holds');c.same(state.jobs.uniformPending,0,'distinct snapshots retire at native submission');}
 });c.same(Boolean(mutation),true,'novel replacement happens after original range snapshots');c.same(Boolean(hold),true,'novel original allocation survives actual final fence');await frame(r,rec,s);
 const actual=report.frames.at(-1).native.at(-1).blocks.filter(row=>row.name!=='VirglBlock');c.same(actual.map(row=>[row.name,row.generation,row.start,row.length]),[['VirglVSConst0',mutation.originalGeneration,s.banks[0].offset,64],['VirglFSConst0',mutation.originalGeneration,s.second,64]],'native distinct stage ranges preserve original allocation');report.ownership.push({kind:'distinct-stage-replacement',mutation,hold});
 const replacement=spec(seed^0x13297bdc);r.currentLabel='distinct-stage-explicit-rebind-'+seed;let replacementHold;
 const rebound=await submit(r,1,join(transfer(200,replacement.banks[0].data.length),bind(0,0,replacement.banks[0].offset,64,200),bind(1,0,replacement.second,64,200),draw(replacement),bind(0,0,0xffffffff,0xffffffff,0),bind(1,0,0xffffffff,0xffffffff,0)),r.currentLabel,()=>{
  const state=r.renderer.inspect();if(!replacementHold&&state.jobs.status==='finishing'){c.same(state.jobs.uniformHolds,1,'replacement keeps one fence hold after both unbinds');c.ok(r.store.unref(200),'replacement last public reference removed before final fence');replacementHold={state,resources:r.store.inspect()};}
 });c.same(Boolean(replacementHold),true,'replacement hold reaches final fence');await frame(r,rebound,replacement);const native=report.frames.at(-1).native.at(-1).blocks.filter(row=>row.name!=='VirglBlock');c.same(native.map(row=>[row.generation,row.start]),[[mutation.replacementGeneration,replacement.banks[0].offset],[mutation.replacementGeneration,replacement.second]],'explicit rebinding alone adopts both new native ranges');report.ownership.push({kind:'distinct-stage-explicit-adoption',replacementHold});
 const run={history:r.history,requests:r.requests,events:r.trace.events,calls:r.trace.calls.map(({program,...row})=>row),inspection:r.renderer.inspect(),uniformAccess:r.uniformAccess.inspect()};report.runs.push(run);dispose(r);run.final={renderer:r.renderer.inspect(),resources:r.store.inspect(),uniformAccess:r.uniformAccess.inspect()};report.status='passed';return report;
}
