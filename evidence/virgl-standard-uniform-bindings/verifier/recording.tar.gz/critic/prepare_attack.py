from pathlib import Path
import json,hashlib,sys,re
ROOT=Path.cwd();OUT=ROOT/'evidence/virgl-standard-uniform-bindings/verifier';seed=int(sys.argv[1]);mode=sys.argv[2];run=OUT/(mode+'-'+str(seed));run.mkdir(exist_ok=True)
paths=['renderer/virgl-command/tests/standard-uniform-buffer-bindings.mjs','tools/virgl-command/standard-uniform-binding-fixtures.mjs','renderer/virgl-command/tests/standard-instanced-draws.mjs'];variants=[]
for p in paths:
 s=(ROOT/p).read_text();orig=s
 if p.endswith('standard-uniform-binding-fixtures.mjs'):s=s.replace('seed=0x6e624eb7','seed='+str(seed))
 elif p.endswith('standard-instanced-draws.mjs'):
  s=s.replace('steps % 3','(steps * '+str((seed%5)+1)+' + '+str(seed%7)+') % 7')
 elif mode=='matrix':
  s=re.sub(r'delay:(\d+)',lambda m:'delay:'+str((int(m[1])+seed%5)%9+1),s);s=re.sub(r'step:(\d+)',lambda m:'step:'+str((int(m[1])+seed%3)%5+1),s)
 else:
  body=(OUT/'novel-body.mjs').read_text().replace('__SEED__',str(seed));s=s[:s.index('export async function runAcceptance')]+body
 dest=run/Path(p).name;dest.write_text(s);variants.append({'path':p,'file':str(dest),'originalSha256':hashlib.sha256(orig.encode()).hexdigest(),'servedSha256':hashlib.sha256(s.encode()).hexdigest()})
source=(ROOT/'tools/verify-virgl-standard-uniform-bindings.mjs').read_text().replace('"./virgl-command/fixtures.mjs"',json.dumps((ROOT/'tools/virgl-command/fixtures.mjs').as_uri()))
marker='    report.fault=options.fault??null;';assert source.count(marker)==1
injection='    report.criticVariants='+json.dumps(variants)+';\n    for (const variant of report.criticVariants) { const bytes=await fs.readFile(variant.file);assert.equal(sha256(bytes),variant.servedSha256);sources.set(variant.path,bytes); }\n'
source=source.replace(marker,injection+marker);(run/'runner.mjs').write_text(source);(run/'plan.json').write_text(json.dumps({'seed':seed,'mode':mode,'variants':variants,'novelPrediction':'distinct original VS/FS byte ranges share one exact allocation; replacement upload while original indexed+generic read suspends must leave original ranges and pixels intact; explicit rebind adopts replacement; shared holds remain1 through fence and budgets retire0','sabotagePrediction':'wrong native FS byte start still completes native fence then fails original independent full pixel assertion'},indent=2)+'\n');print(run)
