from pathlib import Path
import subprocess,json,re,hashlib
ROOT=Path.cwd();OUT=ROOT/'evidence/virgl-standard-uniform-bindings/verifier';U=OUT/'unpacked';base='3ec060c46a9743a62306ae409d0bf1a548d4a616';head='16316900';names=['renderer/virgl-command/'+s+'.mjs' for s in ['decoder','resources','state']]
added={};name=None;line=0
for row in subprocess.check_output(['git','diff','--unified=0',base,head,'--',*names],text=True).splitlines():
 if row.startswith('+++ b/'):name=row[6:]
 elif row.startswith('@@'):line=int(re.search(r'\+(\d+)',row)[1])
 elif row.startswith('+') and name:added.setdefault(name,[]).append(line);line+=1
 elif row.startswith(' '):line+=1
sources={n:(ROOT/n).read_text() for n in names};digest={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in names};scripts={n:[] for n in names}
for file in U.rglob('browser-coverage.json'):
 if '/fault-' in file.as_posix():continue
 for row in json.loads(file.read_text()).get('scripts',[]):
  n=row['source']
  if n in scripts and row['sha256']==digest[n]:scripts[n].append({'record':file.relative_to(U).as_posix(),'coverage':row['coverage']})
for file in U.rglob('*.json'):
 if '/node-coverage/' not in file.as_posix() and file.name!='node-coverage.json':continue
 r=json.loads(file.read_text())
 for row in r.get('result',[]):
  n=next((n for n in names if row['url'].endswith('/'+n)),None)
  if n:scripts[n].append({'record':file.relative_to(U).as_posix(),'coverage':row})
report={'status':'running','fullRegions':True,'scripts':{n:[s['record'] for s in ss] for n,ss in scripts.items()},'added':added,'unexecutedFragments':[],'lineCoverage':[]}
for n,lines in added.items():
 text=sources[n];text16=text.encode('utf-16-le');rows=text.splitlines(keepends=True);starts=[];at=0
 for r in rows:starts.append(at);at+=len(r.encode('utf-16-le'))//2
 for ln in lines:
  a=starts[ln-1];b=a+len(rows[ln-1].rstrip('\n').encode('utf-16-le'))//2;bound={a,b};allranges=[]
  for script in scripts[n]:
   ranges=[r for f in script['coverage']['functions'] for r in f['ranges']];allranges.append((script['record'],ranges))
   for r in ranges:
    if a<r['startOffset']<b:bound.add(r['startOffset'])
    if a<r['endOffset']<b:bound.add(r['endOffset'])
  segments=[];points=sorted(bound)
  for i in range(len(points)-1):
   x,y=points[i:i+2];hits=[]
   for record,ranges in allranges:
    covering=[r for r in ranges if r['startOffset']<=x and y<=r['endOffset']]
    if covering:
     r=min(covering,key=lambda r:r['endOffset']-r['startOffset']);hits.append({'record':record,'count':r['count'],'region':[r['startOffset'],r['endOffset']]})
   count=max((h['count'] for h in hits),default=0);fragment=text16[x*2:y*2].decode('utf-16-le');segments.append({'start':x,'end':y,'maxCount':count,'text':fragment,'records':hits})
   if count==0 and fragment.strip():report['unexecutedFragments'].append({'source':n,'line':ln,'start':x,'end':y,'text':fragment,'records':hits})
  report['lineCoverage'].append({'source':n,'line':ln,'segments':segments})
report['status']='classified-needed';(OUT/'coverage-regions.json').write_text(json.dumps(report,indent=2)+'\n')
for r in report['unexecutedFragments']:print(json.dumps({k:v for k,v in r.items() if k!='records'}))
print(json.dumps({'addedRuntimeLines':sum(map(len,added.values())),'unexecutedFragments':len(report['unexecutedFragments']),'scripts':{n:len(r) for n,r in scripts.items()}}))
