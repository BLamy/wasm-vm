export async function runAcceptance(){
 const c=checks(),report={schema:'original-uniform-binding-supplement-v1',status:'running',guestExecution:false,productionNegotiation:false,predictions:c.rows,frames:[],runs:[],rejections:[],ownership:[],blobs:[]};window.__standardUniformBindingEvidence=report;
 const gl=document.querySelector('#gpu').getContext('webgl2',{antialias:false,preserveDrawingBuffer:true,failIfMajorPerformanceCaveat:true}),debug=gl.getExtension('WEBGL_debug_renderer_info');report.gpu={renderer:gl.getParameter(debug.UNMASKED_RENDERER_WEBGL),version:gl.getParameter(gl.VERSION)};if(/swiftshader|llvmpipe|softpipe|lavapipe/i.test(report.gpu.renderer))throw Error('physical GPU required');
 const bridge=await createVirglStandardUniformShaderBridge(),alignment=gl.getParameter(gl.UNIFORM_BUFFER_OFFSET_ALIGNMENT);
 const make=(s,opts={})=>{const r=rig(gl,bridge,c,s,{delay:4,step:1,...opts});r.frames=report.frames;r.blobs=report.blobs;return r;};
 const done=r=>{report.runs.push({events:r.trace.events,requests:r.requests,inspection:r.renderer.inspect(),history:r.history});dispose(r);report.ownership.push({final:{renderer:r.renderer.inspect(),resources:r.store.inspect(),access:r.uniformAccess.inspect()}});};
 {
  const s=specimen({alignment,slots:[1],count:4}),r=make(s,{stateLimits:{uniformBytes:17040}});r.currentLabel='eviction-active';await frame(r,await submit(r,1,join(setup(r,s),draw(s)),r.currentLabel),s);
  const unused=specimen({alignment,slots:[1],count:4,unused:true});r.currentLabel='eviction-unreferenced';const rec=await submit(r,1,join(packet(31,0,[0,1]),packet(1,4,[5,0,unused.vertex.length+1,8192,0,...Array(Math.ceil((unused.vertex.length+1)/4)).fill(0)])),r.currentLabel);
  c.same(rec.result.ok,false,'raw empty source prefix is explicitly rejected');
  const shaderPacket=(id,stage,text)=>{const raw=packet(1,4,[id,stage,text.length+1,8192,0,...Array(Math.ceil((text.length+1)/4)).fill(0)]);raw.set(new TextEncoder().encode(text),24);return raw;};
  r.currentLabel='eviction-zero-backing';await frame(r,await submit(r,1,join(packet(31,0,[0,1]),shaderPacket(5,0,unused.vertex),shaderPacket(6,1,unused.fragment),packet(31,0,[5,0]),packet(31,0,[6,1]),draw(unused)),r.currentLabel),unused);
  const state=r.renderer.inspect();c.same(state.budgets.uniformBytes,17040,'shared zero plus one system block fits exact budget');c.same(state.caches.program.evictions>=1,true,'native old program evicted to make zero storage room');report.ownership.push({kind:'shared-zero-eviction',state});done(r);
 }
 {
  const s=specimen({alignment,slots:[1],count:4}),r=make(s,{resourceLimits:{tickets:2}});r.currentLabel='scanout-ticket-input';await frame(r,await submit(r,1,join(setup(r,s),draw(s)),r.currentLabel),s);
  const bank=s.banks[0],lease=r.leases.find(row=>row.role==='uniform'&&row.id===bank.id).lease,a=c.ok(r.uniformAccess.capture(lease,bank.offset,bank.length),'scanout competing range A'),b=c.ok(r.uniformAccess.capture(lease,bank.offset,bank.length),'scanout competing range B'),target=r.allocations[0],scanout=c.ok(r.bindings.retainScanout(1,target.generation),'global ordered scanout lease');
  c.same(r.asyncAccess.beginScanoutRead(scanout.lease).error.code,'limit-exceeded','scanout and original uniform ranges share exact ticket ceiling');c.ok(r.uniformAccess.release(a.token),'release competing range A');const read=c.ok(r.asyncAccess.beginScanoutRead(scanout.lease),'scanout with one uniform range');let finished;
  for(let i=0;i<100;i++){await new Promise(resolve=>setTimeout(resolve,0));r.trace.nextTurn();const answer=c.ok(r.asyncAccess.poll(read.ticket),'actual scanout PBO poll');if(answer.status==='ready'){finished=answer;break;}}
  c.same(Boolean(finished),true,'actual scanout fence completes');const misses=[];for(let i=0;i<finished.bytes.length;i++)if(finished.bytes[i]!==s.expected[i%4])misses.push(i);c.same(misses,[],'scanout returns original rendered full pixels');report.ownership.push({kind:'uniform-scanout-ticket-budget',bytes:await blob(r,finished.bytes),access:r.uniformAccess.inspect(),async:r.asyncAccess.inspect()});c.ok(r.asyncAccess.release(read.ticket),'release scanout read');c.ok(r.uniformAccess.release(b.token),'release competing range B');c.ok(r.store.releaseStorage(scanout.lease),'release global scanout lease');done(r);
 }
 report.status='passed';return report;
}
