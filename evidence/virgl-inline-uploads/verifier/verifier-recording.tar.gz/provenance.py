from pathlib import Path
import hashlib,json,gzip,struct
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-inline-uploads-verifier';sha=lambda b:hashlib.sha256(b).hexdigest();H=json.loads((OUT/'recording/hot/hardware/report.json').read_bytes());observed=H['browserResult']['result']['original'];results=[];clients=[]
for name,cp,digest in [('kmscube','evidence/virgl-corpus/captures/kmscube','8a1fb71fdd3f4d4c3696104690e11af480e5f1b95634bd077a1fcef1636b7b8c'),('es2gears','evidence/virgl-workload-inventory/captures/es2gears','fb91301b9e14b098e0d8a590ddb7fa33ead15972195211741a5efcc3d58e9a3c')]:
 raw=(ROOT/f'evidence/virgl-workload-inventory/{name}-inventory.json').read_bytes();assert sha(raw)==digest;inv=json.loads(raw);cap=ROOT/cp;mr=(cap/'manifest.json').read_bytes();assert sha(mr)==inv['captureManifestSha256'];m=json.loads(mr);er=(cap/'events.jsonl').read_bytes();assert sha(er)==m['events']['sha256']==inv['eventsSha256'];events=[json.loads(x) for x in er.splitlines()];cache={}
 def blob(ref):
  key=ref['sha256']
  if key not in cache:
   p=cap/'blobs'/f'{key}.bin';b=p.read_bytes() if p.exists() else gzip.decompress(p.with_suffix('.bin.gz').read_bytes());assert sha(b)==key and len(b)==ref['bytes'];cache[key]=b
  return cache[key]
 counts={};packets=0
 for packet in inv['clientPackets']:
  c=packet['citation'];e=events[c['event']-1];assert e['seq']==c['event'] and e['type']=='submit_cmd' and e['ctxId']==c['contextId'];b=blob(next(x for x in e['blobs'] if x['role']=='command'));assert sha(b)==c['blobSha256'];part=b[c['byteOffset']:c['byteOffset']+c['byteLength']];assert sha(part)==c['packetSha256'];words=list(struct.unpack('<'+'I'*(len(part)//4),part));assert words==packet['words'];assert (words[0]>>16)+1==len(words);opcode=words[0]&255;counts[opcode]=counts.get(opcode,0)+1;packets+=1
 assert counts.get(9,0)==inv['clientInlineWriteCount']==0
 clients.append({'workload':name,'inventorySha256':digest,'manifestSha256':sha(mr),'eventsSha256':sha(er),'authenticatedClientPackets':packets,'originalInlinePackets':counts.get(9,0),'originalNormalTransfers':counts.get(43,0),'boundary':'client table completeness carried from unchanged independently verified G1; every listed packet rebound to original bytes'})
 for transfer in inv['clientTransfers']:
  c=transfer['citation'];e=events[c['event']-1];b=blob(next(x for x in e['blobs'] if x['role']=='command'));part=b[c['byteOffset']:c['byteOffset']+c['byteLength']];words=struct.unpack('<14I',part);assert words[0]==0x000d002b and words[2]==0 and words[4]==words[5]==words[12]==0 and words[13]==1
  resource=next(r for r in inv['resources'] if r['key']==transfer['resource']);create=events[resource['createEvent']-1];assert create['type']=='resource_create' and create['phase']=='enter' and create['resourceId']==words[1]
  snapshot=next(x for x in reversed(events[:c['event']-1]) if x['type']=='backing_snapshot' and x['resourceId']==words[1] and x['reason']=='submit');assert snapshot['seq']==transfer['backingAtSubmit']['event'];payload=blob(snapshot['blobs'][0]);assert sum(snapshot['iovLengths'])==len(payload)
  w,h=words[9],words[10];unit=4 if create['target']==2 else 1;stride=words[4] or create['width']*unit;offset=words[12];dense=b''.join(payload[offset+i*stride:offset+i*stride+w*unit] for i in range(h));physical=next(x for x in observed if x['workload']==name and x['metadata']['id']==words[1]);assert sha(dense)==physical['physicalSha256'] and sha(payload)==physical['backingSha256'];assert len(dense)==physical['bytes'] and physical['snapshotEvent']==snapshot['seq']
  for key,value in physical['metadata'].items():assert value==(create['resourceId'] if key=='id' else create[key])
  results.append({'workload':name,'resource':transfer['resource'],'eventFile':cp+'/events.jsonl','event':c['event'],'byteOffset':c['byteOffset'],'packetSha256':sha(part),'words':list(words),'snapshotEvent':snapshot['seq'],'iovLengths':snapshot['iovLengths'],'backingBytes':len(payload),'backingSha256':sha(payload),'independentDenseBytes':len(dense),'independentDenseSha256':sha(dense),'recordedPhysicalSha256':physical['physicalSha256']})
r={'status':'passed','workerHardwareReportSha256':sha((OUT/'recording/hot/hardware/report.json').read_bytes()),'clients':clients,'original':results,'syntheticInlineProvenance':'none claimed as original capture'};(OUT/'provenance.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':'passed','clients':clients,'original':[(x['resource'],x['event'],x['byteOffset'],x['snapshotEvent'],x['independentDenseSha256'])for x in results]},indent=2))
