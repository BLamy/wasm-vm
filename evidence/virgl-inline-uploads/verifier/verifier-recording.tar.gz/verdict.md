VERDICT: verified

Fresh critic reviewed AGENTS.md, the whole E6-T12g5 task and actual frozen
runtime/harness diff before evidence; predictions were written before opening
recordings. Runtime/harness source is 7c155f8ff630d4a83786cb2f4c982ddb26e3ab69,
base verified G4 feb78352200139079db61257acf1de1004456037; ecabcafb4862224866eda7451a32052881540cc1 is the sealed worker submission. All nine acceptance
predictions and four bounded-attack predictions HELD. No semantic refutation,
dead changed runtime code or sufficiency gap survived.

Citation notation: W is authenticated original worker archive member
hot/hardware/report.json, SHA256
6e1a9bc1c7f7c3d79cf9580439f4fd31be644cf1ec203726c664e0904257c740.
N is verifier novel-clean/report.json, SHA256
9d1011ce3f11a91fadc8a19e97be7e51434ab86d5605b4b05f959fb10b32f335.
JSON pointers and zero-based assertion indices are reproducible points; line
numbers refer to the preserved pretty-printed artifacts. The original archive
SHA256 is 04553ec60232a633120c7de041e13e297ce46134684712f6a6d39d75c76df157.

- P0 authenticity — HELD. All76 safe regular archive members match indexed
  bytes and digests, 84 source and40 input bindings match Git-frozen/current
  bytes, generated compiler matches source tables, and all23 hot/cold reports
  bind actual served runtime, V8 counters, fixture transport and screenshots.
  Independent authentication.json:2 onward and /reports record each binding.
  Frozen diff matches diff.patch SHA256
  4aed395c44048652695d6469cfd0f2ca700feec1359f4303e421ec3430c6208e.
  Only explicitly bound source-fault reports serve mutations.
- P1 wire — HELD. W:247 observes opcode9, RESOURCE_INLINE_WRITE, preserved
  usage0xffffffff and20 frozen data words beginning at word12. W:389 proves
  opaque END padding remains one command; W:1535 proves the malformed-field
  matrix issued zero host uploads. Decoder common words match pinned protocol
  header:521–532 and reference vrend_decode.c:434–460. Shared/detached inputs,
  bad object bytes, incomplete headers/data, whole-wire tails and row overflow
  reject; caller wire mutation cannot change the immutable decoder result.
- P2 physical layout — HELD. W:431 gives [offset0,rowBytes8,rowStride11,
  layerStride38,footprint30,tight24]; W:463 proves resource-width default20.
  W /browserResult/result/sync covers color67/2/233, Z16 and both buffer roles,
  whole and partial boxes, odd/default rows and untouched neighbors/backing.
  W:8037 proves no scatter into backing. An independent byte/float output
  model in observation-audit.json /physicalModel reproduces all18 recorded
  partial-upload digests exactly without using decoder/gather/conversion/
  inverse readback helpers. Fresh arbitrary packed 10-bit/Z16 sample checks
  also pass independently at N /result/matrices and /result/assertions.
- P3 ownership/lifetime — HELD. W:16829 and16841 observe upload-ready with
  owned payload and no guest DMA request before issue. W:17281 releases
  scratch; W:40175 records no stale/cancelled upload. W /result/jobs (under
  /browserResult) has12 actual-fence configurations, each3 A/B/A uploads and
  nonblocking delays0/1/3 with poll counts greater than the delay. Native dword
  mutation, direct async input replacement/double issue, backing reattachment,
  resource/member/context name reuse, cancellation/disposal all preserve owned
  data or reject before effects. N:129044/132408/182156 independently repeat
  yielding, delayed fences and stale-generation rejection with delays2/4/6.
- P4 fail-closed bounds — HELD. W:1529 records no accessor getter invocation;
  W:1809 quota rejection charges no scratch/ticket. W:2087 exercises dense
  allocation failure and rollback. W:41411 backend faults release scratch;
  recovery pixels pass. W:1731 admits the exact262144-byte wire, and W:43721
  physically matches the262096-byte buffer payload digest. One extra dword,
  too-short aligned footprint, overlapping rows/layers, overflow, bad roles,
  unsupported levels/layers, sparse/accessor/typed/shared/detached data and
  inconsistent opcode metadata reject. N:187640 and /result/attacks repeat
  the input/role/overflow matrix with fresh seeds and zero native issues.
- P5 original provenance — HELD. Independent provenance.json /clients rebinds
  all147 kmscube and8533 es2gears listed client packets to original blob bytes
  and verifies zero opcode9 packets. G1's unchanged client-table completeness
  is carried forward. Five original opcode43 packets decode independently:
  kmscube5@125 event140/byte0 with CPU snapshot139; kmscube4@114 event154/byte0
  with152; gears36/37/38 event5115 bytes0/56/112 with5112/5113/5114. Captured
  metadata, segmented CPU inputs, payload offset/strides and dense digests all
  match W /browserResult/result/original, including independent GPU digests.
  Both original event streams, inventory seals and packet hashes remain bound.
  Synthetic inline writes are explicitly separate; none is claimed captured.
- P6 physical source sensitivity — HELD. Worker offset+1 and rowBytes stride
  faults fail at raw RGBA texel0 and11 respectively with source/counter hashes.
  Independently served row reversal (not either worker mutation) fails the
  newly committed physical test at sabotage-row-reverse/report.json:216:
  expected[0,85,170,7], observed[255,170,0,50], before inverse conversion.
  Original resources SHA256 c2355819a1ae04125af8689bb0e23cbdfa73b10dc87710b0be72638397a66eae;
  reversed source d49bb7f1082f03d732df0ee1574f2bb9cb127dda304aca310f28ece3608800dd.
  Disabling the test's equality result in a separate served copy leaves a
  claimed pass but the independent observation audit detects1520 mismatches,
  first at /independentTestAudit/mismatches/0, assertion205/raw texel0.
  This is deliberate verifier sabotage, not a product refutation.
- P7 coverage sufficiency — HELD. Independent zero-context Git diff, lexical
  token and UTF-16 smallest-enclosing-range audit uses38 authenticated clean
  V8 runtime entries; excludes worker first-token map and all mutant counters.
  All significant executable token subspans on50 added runtime lines have
  positive counters. Seven added comment/structural lines are waived:
  resources.mjs:107,108,115,122,123,220,222. coverage-audit.json /lines provides
  per-token source digest, offsets, recording digest and count. No defensive
  behavior waiver, dead code or missing runtime proof was needed. Declarative
  docs/metadata are waived. Recorded logs exercise new Makefile, fixtures,
  browser acceptance, receipt and cold glue; generic environment/argument
  failure code adds no guest behavior claim.
- P8 cold/regressions — HELD, with unchanged G1–G4 conclusions carried forward.
  The final cold/report.json:4–21 records exact source head, exit0, empty
  porcelain before/after and relevant environment scrubbing; digest remains
  36c3a2078053a91075eb0529b41334f9eda9b3ab6d6dbf62de6178bb4a9b92c0.
  Hot/cold source/input tables match. All eight affected regression reports
  pass and all serialized HELD observations agree with their actual expected
  values. Retained unchanged flat proof in hot/regression/views/report.json
  /browserResult/result/flat includes44 draws,12 faults and zero final budgets.
  No portability finding warranted repeating the once-final pristine clone.
- N1 random odd strides — HELD. N has18 independently seeded format/role
  matrices, all terminal alignment counts0–3, arbitrary RGBA/BGRA/packed10-bit/
  Z16 data, edge/default/partial boxes, poisoned UNPACK state and canaries.
  All19594 assertions hold on Chrome154.0.8037.93, ANGLE Metal Apple M4 Max.
  Seeds are1838461447/418555341/3273552027 (0x6d94b207/0x18f2a5cd/0xc31e709b).
- N2 schedule/lifetime — HELD. N /result/jobs has12 A/B/A configurations at
  fresh delays2/4/6. N /result/attacks includes15 independently scheduled
  stale resource/member/context/cancel/dispose cases; all issue zero writes
  and release scratch/tickets/native names. Yielding never requests DMA.
- N3 malformed matrix — HELD. N /result/attacks has three independently seeded
  length/trailing/offset/stride/layer/overlap/role/input matrices, no getter
  effects, no charged rejected tickets and zero native uploads. Independently
  expected physical neighbors and all backing canary bytes remain unchanged.
- N4 independent source/test sabotage — HELD. Source-only reversal is detected
  by the new committed physical test; separate source+blind-assertion mutation
  is detected by the independent expected/observed record comparison despite
  every asserted HELD flag. Screenshots corroborate both recorded observations.

Commands: python3 target/evidence/virgl-inline-uploads-verifier/authenticate.py;
python3 target/evidence/virgl-inline-uploads-verifier/coverage-audit.py;
python3 target/evidence/virgl-inline-uploads-verifier/provenance.py;
node target/evidence/virgl-inline-uploads-verifier/run-novel.mjs clean;
node target/evidence/virgl-inline-uploads-verifier/run-novel.mjs row-reverse;
node target/evidence/virgl-inline-uploads-verifier/run-novel.mjs test-blind;
python3 target/evidence/virgl-inline-uploads-verifier/audit-recording.py.

SUITE: retain the new committed inline-uploads.mjs deterministic wire/ownership/
physical format and buffer checks, physical source-fault gate and make
verify-E6-T12g5. Preserve the independent driver, fresh seeds, counters,
observations and sabotage captures as verifier replay evidence; no duplicate
tracked test or runtime edit adds value. The narrow inline transfer boundary is
verified. Full-client shader closure is G6, depth raster state is H; no guest
CPU, full offload, MIPS, production negotiation or deployment claim is made.
Host rr is waived. Root owns preservation, queue, Git and stack; the critic did
not mutate Git, deploy, merge or rerun unrelated walls.
