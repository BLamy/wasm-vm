import hashlib,json,tarfile,subprocess
from pathlib import Path,PurePosixPath
ROOT=Path.cwd(); OUT=ROOT/'target/evidence/virgl-inline-uploads-verifier'; SRC=ROOT/'evidence/virgl-inline-uploads/worker'; FROZEN='7c155f8ff630d4a83786cb2f4c982ddb26e3ab69'
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(SRC/'manifest.json').read_bytes(); m=json.loads(raw); iraw=(SRC/'records.json').read_bytes(); idx=json.loads(iraw)
assert m['sourceHead']==FROZEN and m['base']=='feb78352200139079db61257acf1de1004456037'
assert m['records']==len(idx)==76
for key in ('archive','recordIndex'):
 r=m[key]; b=(SRC/r['path']).read_bytes(); assert len(b)==r['bytes'] and sha(b)==r['sha256']
expected={r['path']:r for r in idx};assert len(expected)==len(idx)
records={};target=OUT/'recording';target.mkdir(exist_ok=True)
with tarfile.open(SRC/m['archive']['path'],'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(idx)
 for x in members:
  p=PurePosixPath(x.name);assert x.isfile() and not p.is_absolute() and '..' not in p.parts and x.name in expected and x.name not in records
  b=tar.extractfile(x).read();r=expected[x.name];assert len(b)==r['bytes'] and sha(b)==r['sha256']
  dst=target/x.name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);records[x.name]=r
for path,digest in [('hot/receipt.json',m['hotReceiptSha256']),('cold/report.json',m['coldReportSha256']),('cold/acceptance/receipt.json',m['coldReceiptSha256'])]:assert records[path]['sha256']==digest
reports=[];bindings={};sources={};inputs={}
for p in sorted(target.rglob('report.json')):
 r=json.loads(p.read_bytes());rel=str(p.relative_to(target));report={'path':rel,'sha256':sha(p.read_bytes()),'status':r.get('status')}
 if rel=='cold/report.json':
  assert r['gitHead']==r['cloneHead']==FROZEN and r['status']=='passed' and r['exitCode']==0 and r['statusBefore']==r['statusAfter']==''
  assert r['receiptSha256']==m['coldReceiptSha256'] and sha((p.parent/'cold.log').read_bytes())==r['logSha256']
  report.update(r);reports.append(report);continue
 assert r['gitHead']==FROZEN
 isfault='sabotage-' in rel
 assert r['status']==('failed' if isfault else 'passed')
 for category,table in [('sources',sources),('inputs',inputs)]:
  for row in r[category]:
   path=row['path'];b=(ROOT/path).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],path
   if '/build/wasm/' not in path:
    frozen=subprocess.check_output(['git','show',FROZEN+':'+path]);assert b==frozen,path
   if path in table:assert table[path]==row
   table[path]=row;bindings[path]=row
 if 'browserResult' in r:
  assert r['browserErrors']=={'console':[],'page':[],'requests':[]}
  assert r['browserResult']['status']==('failed' if isfault else 'passed')
  assert r['browser']['headless']==False
  feature=r['browser']['gpu']['featureStatus'];assert feature.get('webgl2',feature.get('webgl'))=='enabled'
  assert not any(w in str(r['browser']['commandLine']).lower() for w in ['swiftshader','llvmpipe','lavapipe','--disable-gpu'])
  assert sha(Path(r['browser']['executable']).read_bytes())==r['browser']['sha256']
  for key in ('screenshot','failureScreenshot','browserCoverage'):
   if key in r:
    z=r[key];assert sha((p.parent/z['path']).read_bytes())==z['sha256']
  mutation=r.get('sabotage',{});served={s['path']:s for s in r['servedFiles']}
  for item in r['sources']:
   path=item['path']
   if '/'+path in served:
    assert served['/'+path]['sha256']==(mutation['servedSha256'] if mutation.get('path')==path else item['sha256'])
  if 'fixtureTransport' in r:assert served['/fixtures.json']['sha256']==r['fixtureTransport']['sha256']
  if isfault:
   fault=(p.parent/'fault-source.mjs').read_bytes();assert sha(fault)==mutation['servedSha256']
   original=(ROOT/mutation['path']).read_text();changed=original.replace(mutation['needle'],mutation['replacement'])
   assert original.count(mutation['needle'])==1 and changed.encode()==fault
   assert mutation['originalSha256']==sha(original.encode())
 assertions=r.get('native',r.get('node',{})).get('assertions',[])
 report.update({'task':r['task'],'nativeAssertions':len(assertions) if isinstance(assertions,list) else assertions,'browserStatus':r.get('browserResult',{}).get('status')});reports.append(report)
for hot,cold in [('hot/receipt.json','cold/acceptance/receipt.json'),('hot/hardware/report.json','cold/acceptance/hardware/report.json')]:
 a=json.loads((target/hot).read_bytes());b=json.loads((target/cold).read_bytes());assert a['sources']==b['sources'] and a['inputs']==b['inputs']
for p in target.rglob('*'):
 if p.is_file() and '/generated/' in str(p):
  suffix='renderer/virgl-shader/build/wasm/'+p.name
  if suffix in sources:assert sha(p.read_bytes())==sources[suffix]['sha256']
r={'status':'passed','workerManifestSha256':sha(raw),'recordIndexSha256':sha(iraw),'workerArchiveSha256':m['archive']['sha256'],'members':len(records),'frozenHead':FROZEN,'sources':list(sources.values()),'inputs':list(inputs.values()),'reports':reports,'memberNames':list(records)}
(OUT/'authentication.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':r['status'],'members':len(records),'sourceBindings':len(sources),'inputBindings':len(inputs),'reports':[(x['path'],x['status']) for x in reports],'memberNames':list(records)},indent=2))
