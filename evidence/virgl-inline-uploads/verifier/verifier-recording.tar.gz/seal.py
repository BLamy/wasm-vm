from pathlib import Path
import hashlib,json,io,tarfile,gzip
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-inline-uploads-verifier';sha=lambda b:hashlib.sha256(b).hexdigest()
excluded={'verifier-manifest.json','verifier-records.json','verifier-recording.tar.gz'}
files=sorted(p for p in OUT.rglob('*') if p.is_file() and p.parts[len(OUT.parts)]!='recording' and p.name not in excluded and '__pycache__' not in p.parts)
records=[{'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in files];idx=(json.dumps(records,indent=2)+'\n').encode();(OUT/'verifier-records.json').write_bytes(idx)
content=io.BytesIO()
with tarfile.open(fileobj=content,mode='w') as tar:
 for p,r in zip(files,records):
  raw=p.read_bytes();info=tarfile.TarInfo(r['path']);info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
archive=gzip.compress(content.getvalue(),mtime=0);(OUT/'verifier-recording.tar.gz').write_bytes(archive)
worker=ROOT/'evidence/virgl-inline-uploads/worker';manifest={'schema':'virgl-inline-verifier-seal-v1','task':'E6-T12g5','verdict':'verified','frozenRuntimeHead':'7c155f8ff630d4a83786cb2f4c982ddb26e3ab69','base':'feb78352200139079db61257acf1de1004456037','submission':'ecabcafb4862224866eda7451a32052881540cc1','records':len(records),'archive':{'path':'verifier-recording.tar.gz','bytes':len(archive),'sha256':sha(archive)},'recordIndex':{'path':'verifier-records.json','bytes':len(idx),'sha256':sha(idx)},'workerBinding':{name:sha((worker/name).read_bytes())for name in ['manifest.json','records.json','recording.tar.gz']},'excludedWorkerDuplicates':'recording/ extracted original archive members are excluded; original worker archive is bound above','predictionResultsSha256':sha((OUT/'prediction-results.json').read_bytes()),'verdictSha256':sha((OUT/'verdict.md').read_bytes()),'novelCleanSha256':sha((OUT/'novel-clean/report.json').read_bytes()),'hardwareAssertions':19594,'productionNegotiation':False,'guestExecution':False};(OUT/'verifier-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(OUT/'verifier-recording.tar.gz') as tar:
 members=tar.getmembers();assert len(members)==len(records)
 for m,r in zip(members,records):assert m.isfile() and m.name==r['path'] and sha(tar.extractfile(m).read())==r['sha256']
print(json.dumps(manifest,indent=2))
