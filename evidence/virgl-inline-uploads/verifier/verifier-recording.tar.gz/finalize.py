from pathlib import Path
import hashlib,json
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-inline-uploads-verifier';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def point(file,pointer=None,line=None):
 r={'path':file,'sha256':sha(OUT/file)}
 if pointer:r['point']=pointer
 if line:r['line']=line
 return r
W='recording/hot/hardware/report.json';N='novel-clean/report.json'
results=[
 ('P0','authenticate every archive/source/served artifact',[point('authentication.json','/reports'),point('recording/diff.patch')]),
 ('P1','word12 owned inline wire and opaque END admission',[point(W,'/native/assertions',247),point(W,None,389),point(W,None,1535)]),
 ('P2','physical formats/bytes/strides/untouched padding and neighbors',[point(W,'/browserResult/result/sync',431),point('observation-audit.json','/physicalModel'),point(N,'/result/matrices')]),
 ('P3','owned async yields/generations/fences and cleanup',[point(W,'/browserResult/result/jobs',16829),point(W,None,40175),point(N,'/result/jobs',129044)]),
 ('P4','fail-closed roles/arithmetic/inputs/quotas/fault rollback/max wire',[point(W,'/native/assertions',1529),point(W,None,2087),point(W,None,43721),point(N,'/result/attacks')]),
 ('P5','original packet and pre-submit CPU payload provenance',[point('provenance.json','/clients'),point('provenance.json','/original'),point(W,'/browserResult/result/original')]),
 ('P6','physical source and assertion sabotage sensitivity',[point('sabotage-row-reverse/report.json','/result/error',216),point('sabotage-test-blind/report.json','/independentTestAudit/mismatches/0')]),
 ('P7','all significant changed runtime token subspans executed',[point('coverage-audit.json','/classifications'),point('coverage-audit.json','/lines')]),
 ('P8','once-final exact cold and unchanged G1-G4 regression lineage',[point('recording/cold/report.json','/statusBefore',4),point('observation-audit.json','/flatSummary'),point('authentication.json','/reports')]),
 ('N1','independently seeded arbitrary odd-stride physical patterns',[point(N,'/result/matrices'),point(N,'/result/assertions')]),
 ('N2','fresh delays2/4/6 and pending generation reuse attacks',[point(N,'/result/jobs',132408),point(N,'/result/attacks',182156)]),
 ('N3','fresh overflow/overlap/input/role rejection matrix',[point(N,'/result/attacks'),point(N,None,187640)]),
 ('N4','independent source/test sabotage caught by physical observations',[point('sabotage-row-reverse/report.json','/result/error',216),point('sabotage-test-blind/report.json','/independentTestAudit')]),
]
r={'verdict':'verified','frozenRuntimeHead':'7c155f8ff630d4a83786cb2f4c982ddb26e3ab69','base':'feb78352200139079db61257acf1de1004456037','submissionHead':'ecabcafb4862224866eda7451a32052881540cc1','predictionFileSha256':sha(OUT/'predictions.md'),'verdictFileSha256':sha(OUT/'verdict.md'),'results':[{'prediction':id,'status':'HELD','claim':claim,'citations':citations,'demand':'none'}for id,claim,citations in results],'carryForward':['E6-T12g1','E6-T12g2','E6-T12g3','E6-T12g4'],'suite':'Retain committed inline tests and verify target; preserve independent replay evidence, no duplicate tracked test.'};(OUT/'prediction-results.json').write_text(json.dumps(r,indent=2)+'\n')
print('verdict',sha(OUT/'verdict.md'),'results',sha(OUT/'prediction-results.json'),'audit',sha(OUT/'observation-audit.json'))
