import json,re,subprocess,hashlib,bisect
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-inline-uploads-verifier';RECORD=OUT/'recording';HEAD='7c155f8ff630d4a83786cb2f4c982ddb26e3ab69';BASE='feb78352200139079db61257acf1de1004456037';sha=lambda b:hashlib.sha256(b).hexdigest()
files=['renderer/virgl-command/'+s+'.mjs' for s in ['decoder','resources','state']]; rows=[];coverage=[]
for p in sorted(RECORD.rglob('browser-coverage.json')):
 if 'sabotage-' in str(p):continue
 x=json.loads(p.read_bytes())
 for s in x.get('scripts',[x]):
  if s.get('source') in files:
   source=(ROOT/s['source']).read_bytes();assert s['sha256']==sha(source)
   coverage.append((s['source'],str(p.relative_to(OUT)),sha(p.read_bytes()),s['coverage']))
# A lexical scan, independent of worker first-token maps. All identifier, number,
# literal and nonstructural operator spans on added lines are split at every V8
# range boundary; each segment is checked against the narrowest covering range.
def tokens(text):
 i=0;n=len(text)
 while i<n:
  a=i;c=text[i]
  if c.isspace():i+=1;continue
  if text.startswith('//',i):j=text.find('\n',i);i=n if j<0 else j;continue
  if text.startswith('/*',i):j=text.find('*/',i+2);assert j>=0;i=j+2;continue
  if c in "'\"`":
   quote=c;i+=1
   while i<n:
    if text[i]=='\\':i+=2
    elif text[i]==quote:i+=1;break
    else:i+=1
   yield (a,i,text[a:i]);continue
  m=re.match(r'[A-Za-z_$][\w$]*|(?:0[xX][\da-fA-F]+|\d+(?:\.\d+)?)',text[i:])
  if m:i+=len(m[0]);yield(a,i,text[a:i]);continue
  m=re.match(r'(?:===|!==|>>>|=>|==|!=|<=|>=|&&|\|\||\?\?|\?\.|<<|>>|\+\+|--|\*\*|[+*/%<>=!&|^~?-])',text[i:])
  if m:i+=len(m[0]);yield(a,i,text[a:i]);continue
  i+=1
for file in files:
 raw=(ROOT/file).read_bytes();text=raw.decode();assert raw==subprocess.check_output(['git','show',HEAD+':'+file])
 starts=[0]+[m.end() for m in re.finditer('\n',text)];units=[0]
 for c in text:units.append(units[-1]+len(c.encode('utf-16-le'))//2)
 diff=subprocess.check_output(['git','diff','--unified=0',BASE,HEAD,'--',file],text=True)
 added=[];line=0
 for s in diff.splitlines():
  if s.startswith('@@'):line=int(re.search(r'\+(\d+)',s)[1])
  elif s.startswith('+') and not s.startswith('+++'):added.append(line);line+=1
  elif not s.startswith('-') and not s.startswith('\\'):line+=1
 records=[(path,digest,script) for f,path,digest,script in coverage if f==file]
 allRanges=[(r,path,digest,fn['functionName']) for path,digest,script in records for fn in script['functions'] for r in fn['ranges']]
 tokenrows={l:[] for l in added}
 for a,b,t in tokens(text):
  l=bisect.bisect_right(starts,a)
  if l not in tokenrows:continue
  aa,bb=units[a],units[b];proof=[]
  for path,digest,script in records:
   ranges=[(r,fn['functionName']) for fn in script['functions'] for r in fn['ranges']]
   breaks=sorted(set([aa,bb]+[o for r,_ in ranges for o in (r['startOffset'],r['endOffset']) if aa<o<bb]));selected=[];held=True
   for left,right in zip(breaks,breaks[1:]):
    candidates=[(r,name) for r,name in ranges if r['startOffset']<=left and r['endOffset']>=right]
    if not candidates:held=False;break
    r,name=min(candidates,key=lambda z:z[0]['endOffset']-z[0]['startOffset'])
    selected.append({'startOffset':r['startOffset'],'endOffset':r['endOffset'],'count':r['count'],'function':name})
    if r['count']<=0:held=False
   if held:proof.append({'record':path,'sha256':digest,'ranges':selected})
  tokenrows[l].append({'token':t,'startOffset':aa,'endOffset':bb,'held':bool(proof),'proof':proof[:1]})
 for l in added:
  ts=tokenrows[l];unhit=[t['token'] for t in ts if not t['held']];structural=not ts
  rows.append({'source':file,'sourceSha256':sha(raw),'line':l,'text':text.splitlines()[l-1],'classification':'waived-structural/comment' if structural else 'executed' if not unhit else 'needs-review','tokens':ts,'unhit':unhit})
r={'schema':1,'method':'all significant lexical tokens on added lines; every token subspan uses smallest enclosing clean V8 range, UTF-16 offsets; excludes worker map and sabotage counters','base':BASE,'frozenHead':HEAD,'records':len(coverage),'addedLines':len(rows),'classifications':{k:sum(x['classification']==k for x in rows) for k in sorted(set(x['classification'] for x in rows))},'lines':rows}
(OUT/'coverage-audit.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='lines'},indent=2))
for x in rows:
 if x['unhit']:print(x['source'],x['line'],x['unhit'],x['text'])
