from pathlib import Path
import hashlib,json,struct,subprocess
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-inline-uploads-verifier';REC=OUT/'recording';sha=lambda b:hashlib.sha256(b).hexdigest();HEAD='7c155f8ff630d4a83786cb2f4c982ddb26e3ab69';BASE='feb78352200139079db61257acf1de1004456037'
assert (REC/'diff.patch').read_bytes()==subprocess.check_output(['git','diff',BASE,HEAD])
report_rows=[]
for p in sorted(REC.rglob('report.json')):
 if 'sabotage-' in str(p) or p==REC/'cold/report.json':continue
 r=json.loads(p.read_bytes());failures=[]
 def walk(v,point=''):
  if isinstance(v,dict):
   if 'held' in v:
    assert v['held'] is True,(str(p),point)
    if 'observed' in v and 'expected' in v:assert v['observed']==v['expected'],(str(p),point,v)
   for k,x in v.items():walk(x,point+'/'+k)
  elif isinstance(v,list):
   for i,x in enumerate(v):walk(x,point+'/'+str(i))
 walk(r)
 if 'browserCoverage' in r:
  c=json.loads((p.parent/r['browserCoverage']['path']).read_bytes());scripts=c.get('scripts',[c]);source_table={s['path']:s for s in r['sources']}
  for s in scripts:assert s['sha256']==source_table[s['source']]['sha256'] and s['coverage']['url'].endswith('/'+s['source'])
 if r['task']=='E6-T12g5':assert r['native']==r['browserResult']['native']
 report_rows.append({'path':str(p.relative_to(OUT)),'sha256':sha(p.read_bytes()),'task':r['task'],'status':r['status']})
H=json.loads((REC/'hot/hardware/report.json').read_bytes());Z=H['browserResult']['result'];assert len(H['native']['assertions'])==202 and len(Z['assertions'])==3907
assert Z['guestExecution']==Z['productionNegotiation']==False
assert [(x['format'],x['delay'],x['uploads']) for x in Z['jobs']]==[(f,d,3) for d in [0,1,3] for f in [67,2,233,16]]
assert all(min(x['pollCounts'])>x['delay'] for x in Z['jobs'])
assert all(x['uploads']==0 for x in Z['failures'] if 'uploads' in x)
assert [x['metadata']['format'] for x in Z['sync']]==[67,2,233,16,64,64]
# Independent output model for synthetic source pattern; never calls decoder,
# layout/gather, backend conversion, inverse readback or fixture functions.
def pattern(m,w,h,seed):
 out=[]
 for i in range(w*h):
  if m['target']==0:out.append((i*31+seed*17+9)&255)
  elif m['format']==16:out.append(((i*7919+seed*1237)&65535)/65535)
  else:out.append([((i+seed)%4)*85,((i*3+seed+1)%4)*85,((i*2+seed+2)%4)*85,((i*37+seed*11+7)&255) if m['format']==67 else 255])
 return out
def byte_image(m,p):
 if m['target']==0:return bytes(p)
 if m['format']==16:return b''.join(struct.pack('<4f',x,0,0,1) for x in p)
 return bytes(x for pixel in p for x in pixel)
physical=[]
for x in Z['sync']:
 m=x['metadata'];image=pattern(m,m['width'],m['height'],0)
 for h in x['history']:
  l=h['layout'];b=l['box'];pixel=2 if m['format']==16 else 4 if m['target']==2 else 1;row=b['width']*pixel;stride=h['stride'] or m['width']*pixel;layer=h['layerStride'] or stride*m['height'];footprint=(b['height']-1)*stride+row
  assert [l['offset'],l['rowBytes'],l['rowStride'],l['layerStride'],l['footprintBytes'],l['tightBytes']]==[0,row,stride,layer,footprint,row*b['height']]
  update=pattern(m,b['width'],b['height'],h['seed'])
  for y in range(b['height']):
   for col in range(b['width']):image[(b['y']+y)*m['width']+b['x']+col]=update[y*b['width']+col]
  digest=sha(byte_image(m,image));same=digest==h['physicalSha256']
  # Float sample digests can differ one ULP due to native UN16 conversion;
  # tolerance assertions and independent novel sampling are authoritative there.
  if m['format']!=16:assert same,(m,h,digest)
  physical.append({'format':m['format'],'bind':m['bind'],'seed':h['seed'],'layout':l,'independentPhysicalSha256':digest,'recordedPhysicalSha256':h['physicalSha256'],'exactDigest':same})
views=json.loads((REC/'hot/regression/views/report.json').read_bytes())['browserResult']['result'];flat=views['flat']
N=json.loads((OUT/'novel-clean/report.json').read_bytes());assert N['status']==N['result']['status']=='passed';assert all(x['held'] and x['observed']==x['expected'] for x in N['result']['assertions']);assert len(N['result']['assertions'])==19594;assert len(N['result']['matrices'])==18 and len(N['result']['jobs'])==12
alignments=sorted({h['terminalAlignmentBytes'] for x in N['result']['matrices'] for h in x['history'] if 'terminalAlignmentBytes' in h});assert alignments==[0,1,2,3]
R=json.loads((OUT/'sabotage-row-reverse/report.json').read_bytes());T=json.loads((OUT/'sabotage-test-blind/report.json').read_bytes());assert R['status']==T['status']=='sabotage-detected';assert R['result']['status']=='failed' and T['result']['status']=='passed';assert T['independentTestAudit']['reportedHeld'] is True and len(T['independentTestAudit']['mismatches'])>0
r={'status':'passed','frozenDiffSha256':sha((REC/'diff.patch').read_bytes()),'cleanReports':report_rows,'hardwareAssertions':3907,'nativeAssertions':202,'physicalModel':physical,'flatSummary':{'status':flat['status'],'drawCount':len(flat['draws']),'faultCount':len(flat['faults']),'quotaCount':len(flat['quota']),'finalBudgets':flat['finalBudgets']},'novelAssertions':len(N['result']['assertions']),'novelMatrices':len(N['result']['matrices']),'novelJobs':len(N['result']['jobs']),'novelAlignmentCounts':alignments,'sourceSabotageError':R['result']['error'],'blindTestMismatchCount':len(T['independentTestAudit']['mismatches']),'blindTestFirstMismatch':T['independentTestAudit']['mismatches'][0]};(OUT/'observation-audit.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['cleanReports','physicalModel','flatSummary','sourceSabotageError']},indent=2));print('physical model exact digests',sum(x['exactDigest'] for x in physical),'/',len(physical));print('flat keys',list(flat))
