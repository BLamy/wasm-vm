#!/usr/bin/env python3
"""Concrete pixel, packet, role and failure points in authenticated recordings."""
from pathlib import Path
import hashlib
import json

OUT = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
summaries, citations = [], []
def point(prefix, member, needle):
    raw = (OUT / 'unpacked' / prefix / member).read_bytes()
    text = raw.decode()
    start = text.index(needle)
    return {'archiveMember': prefix + '/' + member, 'line': text.count('\n', 0, start) + 1, 'sha256': sha(raw), 'point': needle}
def report(prefix, member):
    return json.loads((OUT / 'unpacked' / prefix / member / 'report.json').read_bytes())
def walk(value):
    if isinstance(value, dict):
        if 'held' in value:
            assert value['held'] is True, value
        for child in value.values():
            walk(child)
    elif isinstance(value, list):
        for child in value:
            walk(child)

for prefix in ['hot', 'cold']:
    closure = json.loads((OUT / 'unpacked' / prefix / 'closure.json').read_bytes())
    colors = report(prefix, 'runtime/regression/colors')['browserResult']['result']
    depth = report(prefix, 'runtime/regression/depth')['browserResult']['result']
    views = report(prefix, 'runtime/regression/views')['browserResult']['result']
    inline = report(prefix, 'runtime/hardware')['browserResult']['result']
    for value in [colors, depth, views, inline]:
        assert value['status'] == 'passed'
        assert 'Metal Renderer: Apple M4 Max' in value['renderer']
        walk(value)
    assert [(r['citation']['event'], r['citation']['byteOffset']) for r in colors['originals']] == [(176, 4104), (5115, 5544), (140, 0)]
    assert depth['original']['citation']['event'] == 5115 and depth['original']['citation']['byteOffset'] == 5568
    expected = {
        2: ([[231,5,37,255],[23,177,91,255],[47,29,213,255],[17,254,1,255],[217,3,129,255],[199,113,7,255]], [8,8,8,0]),
        67: ([[37,5,231,12],[91,177,23,99],[213,29,47,0],[1,254,17,255],[129,3,217,201],[7,113,199,17]], [8,8,8,8]),
        233: ([[1,257,1022,3],[2,513,341,3],[1021,17,3,3],[1023,1023,0,3],[511,1,1023,3],[17,767,255,3]], [10,10,10,2]),
    }
    for result in colors['formats']:
        assert (result['physicalRgba'], result['componentBits']) == expected[result['format']]
    assert depth['encodings']['encodings'] == 65536 and depth['encodings']['maxSampleError'] < 3e-8
    assert depth['literal']['guestWords'] == [0,1,255,256,32768,65535]
    assert depth['literal']['attachment']['bits'] == 16 and depth['literal']['attachment']['stencilBits'] == 0
    assert views['original']['viewCitation'] == closure['view']['view']['citation']
    assert views['original']['samplerCitation'] == closure['view']['sampler']['citation']
    assert [(f['format'], len(f['cases'])) for f in views['formats']] == [(67,26),(2,26),(233,26)]
    assert views['filtering']['nearestCenter'] == [92,64,148,17]
    assert views['filtering']['linearCenter'] == [68,91,104,82]
    assert views['filtering']['flatCorners'] == [[36,200,8,255],[148,64,92,255]]
    assert all(r['error']['code'] in ['incompatible-resource','unsupported-resource','missing-resource'] for r in views['roles'])
    assert next(r for r in views['roles'] if r['label'] == 'depth cannot become a color view')['error']['code'] == 'unsupported-resource'
    assert [(r['workload'], r['metadata']['id'], r['citation'], r['snapshotEvent']) for r in inline['original']] == [(r['workload'], r['metadata']['id'], r['citation'], r['snapshotEvent']) for r in closure['uploads']]
    odd = [(r['metadata']['format'], [(entry['seed'], entry['stride'], entry['layerStride']) for entry in r['history']]) for r in inline['sync']]
    assert {row[0] for row in odd} == {2,16,64,67,233}
    assert {row['delay'] for row in inline['jobs']} == {0,1,3}
    for member, needle in [
        ('runtime/regression/colors/report.json', 'physical sampled RGBA 2 keeps channels/precision/alpha/origin'),
        ('runtime/regression/colors/report.json', 'draw 233 physical channels and destination alpha at 8,8'),
        ('runtime/regression/depth/report.json', 'all65536 independent normalized depth sampling'),
        ('runtime/regression/views/report.json', 'swizzle 2,1,0,3 physical RGBA 67 at 8,8'),
        ('runtime/regression/views/report.json', 'depth cannot become a color view'),
        ('runtime/hardware/report.json', 'partial inline 67/7 independent raw RGBA texel 11'),
    ]:
        citations.append(point(prefix, member, needle))
    fault_expectations = {
        'fault-channel-order': 'physical sampled RGBA 2 keeps channels/precision/alpha/origin',
        'fault-destination-alpha': 'draw 233 physical channels and destination alpha at 8,8',
        'fault-byte-order': 'all65536 independent normalized depth sampling',
        'fault-swizzle': 'swizzle 2,1,0,3 physical RGBA 67 at 8,8',
        'runtime/sabotage-inline-offset': 'whole inline 67/10 independent raw RGBA texel 0',
        'runtime/sabotage-stride': 'partial inline 67/7 independent raw RGBA texel 11',
    }
    faults = []
    for name, prediction in fault_expectations.items():
        bad = report(prefix, name)
        assert bad['status'] == bad['browserResult']['status'] == 'failed'
        assert prediction in bad['browserResult']['error']['message']
        assert bad['browserErrors'] == {'console': [], 'page': [], 'requests': []}
        faults.append({'fault': name, 'error': bad['browserResult']['error']['message'], 'citation': point(prefix, name + '/report.json', prediction)})
    summaries.append({'prefix': prefix, 'colorBits': [r['componentBits'] for r in colors['formats']],
                      'depthMaxSampleError': depth['encodings']['maxSampleError'], 'oddRows': odd,
                      'hardwareAssertionCounts': {name: len(value['assertions']) for name, value in [('colors',colors),('depth',depth),('views',views),('inline',inline)]},
                      'faults': faults})
result = {'status': 'passed', 'scope': 'isolated-client-format-view-closure', 'productionDrawAuthority': False,
          'summaries': summaries, 'citations': citations}
(OUT / 'record-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': 'passed', 'assertions': [s['hardwareAssertionCounts'] for s in summaries], 'citations': len(citations)}, indent=2))
