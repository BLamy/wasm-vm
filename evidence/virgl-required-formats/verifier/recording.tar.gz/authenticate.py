#!/usr/bin/env python3
"""Independent byte-custody audit of the frozen worker and carried leaf recordings."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
FROZEN = '5ad750b459d44b1f92dc3db9f5a49f043647b846'
BASE = '3f0db236825e4389c4cd78e82192f81dc9b5cf90'
EXPECTED_ARCHIVE = 'aaf797f2914f32519af9eed6ae55c32b2172b0d6ebaa89503eceedc0913c57db'
EXPECTED_INDEX = 'bdaf8a3ec2f48e7b7fed86993e9a5d206526e8e72be18b3be41e6644e49bedba'
LEAVES = {
    'virgl-workload-inventory': 'fd2b5faf08ab77133937fa8d09183a24f16bfe2f88913ca4f08d2fbacc14e7dc',
    'virgl-color-formats': 'ef5cd601c77585b597b85fda5f77e227694d6ddb1a3041dd50ae398b6920b273',
    'virgl-depth-formats': 'dbf7a0fbd12cc4e3711e4fc4745738d9cd3ac2ae4d9d60974f19077e148996eb',
    'virgl-texture-views': 'de6d0334fed7059bb9af7dfaa5bd52ed2531089091ef1ce74e65970bb0789830',
    'virgl-inline-uploads': '04553ec60232a633120c7de041e13e297ce46134684712f6a6d39d75c76df157',
    'virgl-gears-shaders': '9941036d869021078ce41f67e219b568c24a5b00294598dba4b6873c67b3af6e',
    'virgl-original-programs': 'a90cd34bf49f9dbe9dc8ebb54e2f0a95f544a1f72c78d28e436f1ba16beb5a12',
}

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def read_json(raw):
    return json.loads(raw)

cache = {}
def source(name, expected):
    if name not in cache:
        cache[name] = git('show', FROZEN + ':' + name)
    assert digest(cache[name]) == expected, ('frozen source mismatch', name)
    return cache[name]

def archive_audit(folder, expected_archive=None, expected_index=None, extract=False):
    manifest = read_json((folder / 'manifest.json').read_bytes())
    archive_name = manifest.get('archive', {}).get('path', 'recording.tar.gz')
    packed = (folder / archive_name).read_bytes()
    index_raw = (folder / 'records.json').read_bytes()
    index = read_json(index_raw)
    records = index['records'] if isinstance(index, dict) else index
    assert digest(packed) == (expected_archive or manifest['archiveSha256'])
    if expected_index:
        assert digest(index_raw) == expected_index
    asserted_index = manifest.get('recordIndexSha256', manifest.get('indexSha256'))
    if asserted_index:
        assert digest(index_raw) == asserted_index
    assert len(records) == manifest['records']
    assert len({r['path'] for r in records}) == len(records)
    data = {}
    with tarfile.open(folder / archive_name) as tar:
        members = tar.getmembers()
        assert len(members) == len(records)
        assert len({m.name for m in members}) == len(members)
        assert {m.name for m in members} == {r['path'] for r in records}
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        for item in records:
            raw = tar.extractfile(item['path']).read()
            assert len(raw) == item['bytes'] and digest(raw) == item['sha256'], item['path']
            data[item['path']] = raw
            if extract:
                dest = OUT / 'unpacked' / item['path']
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(raw)
    return manifest, data, {'records': len(records), 'archiveSha256': digest(packed), 'indexSha256': digest(index_raw)}

manifest, records, summary = archive_audit(ROOT / 'evidence/virgl-required-formats/worker', EXPECTED_ARCHIVE, EXPECTED_INDEX, True)
assert manifest['sourceHead'] == FROZEN and summary['records'] == 118
assert not manifest['guestExecution'] and not manifest['productionDrawAuthority']
assert not manifest['portableDomainCertified']
for label, name in [('hotReceiptSha256', 'hot/receipt.json'), ('coldReceiptSha256', 'cold/receipt.json'), ('coldReportSha256', 'cold/report.json')]:
    assert digest(records[name]) == manifest[label]

receipts = {}
browser = []
for prefix in ['hot', 'cold']:
    receipt = read_json(records[prefix + '/receipt.json'])
    receipts[prefix] = receipt
    assert receipt['gitHead'] == FROZEN and receipt['status'] == 'passed'
    assert not receipt['guestExecution'] and not receipt['productionNegotiation']
    for name, expected in receipt['sources'].items():
        source(name, expected)
    for name, expected in receipt['generated'].items():
        assert digest(records[prefix + '-generated/' + name]) == expected, name
    for name, expected in receipt['files'].items():
        assert digest(records[prefix + '/' + name]) == expected, name
    runtime = read_json(records[prefix + '/runtime/receipt.json'])
    assert runtime['status'] == 'passed' and runtime['gitHead'] == FROZEN
    for item in runtime['sources'] + runtime['inputs']:
        name = item['path']
        raw = records[prefix + '-generated/' + name] if '/build/' in name else source(name, item['sha256'])
        assert digest(raw) == item['sha256'] and len(raw) == item['bytes'], name
    for item in runtime['records']:
        raw = records[prefix + '/runtime/' + item['path']]
        assert digest(raw) == item['sha256'] and len(raw) == item['bytes'], item['path']
    for name in sorted(records):
        if not name.startswith(prefix + '/') or not name.endswith('/report.json') or name == 'cold/report.json':
            continue
        report = read_json(records[name])
        assert report['gitHead'] == FROZEN, name
        for item in report.get('sources', []) + report.get('inputs', []):
            raw = records[prefix + '-generated/' + item['path']] if '/build/' in item['path'] else source(item['path'], item['sha256'])
            assert len(raw) == item['bytes'] and digest(raw) == item['sha256'], item['path']
        if 'browser' not in report:
            assert report['status'] == 'passed'
            continue
        assert report['browserErrors'] == {'console': [], 'page': [], 'requests': []}, name
        hardware = report['browser']
        assert hardware['headless'] is False, name
        assert hardware['gpu']['featureStatus'].get('webgl2', hardware['gpu']['featureStatus'].get('webgl')) == 'enabled'
        assert not any(s in str(hardware['commandLine']).lower() for s in ['swiftshader', 'llvmpipe', 'softpipe', 'lavapipe', '--disable-gpu'])
        root = name.removesuffix('/report.json')
        screen = report.get('screenshot') or report.get('failureScreenshot')
        assert screen and digest(records[root + '/' + screen['path']]) == screen['sha256']
        coverage = report['browserCoverage']
        coverage_raw = records[root + '/' + coverage['path']]
        assert digest(coverage_raw) == coverage['sha256']
        table = {s['path']: s for s in report['sources']}
        mutation = report.get('sabotage') or {}
        served = {s['path']: s for s in report['servedFiles']}
        coverage_value = read_json(coverage_raw)
        for script in coverage_value.get('scripts', [coverage_value]):
            expected = mutation['servedSha256'] if script['source'] == mutation.get('path') else table[script['source']]['sha256']
            assert script['sha256'] == expected, script['source']
        for file, item in table.items():
            if '/' + file in served:
                expected = mutation['servedSha256'] if file == mutation.get('path') else item['sha256']
                assert served['/' + file]['sha256'] == expected, file
        assert served['/fixtures.json']['sha256'] == report['fixtureTransport']['sha256']
        failed = '/fault-' in name or '/sabotage-' in name
        assert report['status'] == report['browserResult']['status'] == ('failed' if failed else 'passed'), name
        if failed:
            assert mutation['originalSha256'] != mutation['servedSha256']
            assert digest(records[root + '/fault-source.mjs']) == mutation['servedSha256']
        browser.append({'record': name, 'task': report['task'], 'status': report['status'], 'hardware': hardware, 'sourceFault': mutation, 'error': report['browserResult'].get('error')})

cold = read_json(records['cold/report.json'])
assert cold['status'] == 'passed' and cold['gitHead'] == cold['cloneHead'] == FROZEN
assert cold['statusBefore'] == cold['statusAfter'] == '' and cold['exitCode'] == 0
assert cold['command'] == ['make', 'verify-E6-T12g']
assert cold['receiptSha256'] == digest(records['cold/receipt.json'])
assert cold['logSha256'] == digest(records['cold/cold.log'])
assert receipts['hot']['generated'] == receipts['cold']['generated'], 'nonidentical generated runtime'
dependency_diff = git('diff', '--name-only', BASE, FROZEN, '--', 'renderer/virgl-command', 'renderer/virgl-shader').decode().splitlines()
assert dependency_diff == ['renderer/virgl-command/tests/acceptance.mjs', 'renderer/virgl-command/tests/texture-views.mjs', 'renderer/virgl-shader/tests/original-programs-custody.mjs']
post_freeze = git('diff', '--name-only', FROZEN, '096d2c8a').decode().splitlines()
assert all(name.startswith('evidence/virgl-required-formats/worker/') or name in ['tasks/QUEUE.md', 'tasks/epic-6-transcendence/E6-T12g6-required-format-closure.md'] for name in post_freeze)

held = []
for leaf, expected in LEAVES.items():
    leaf_manifest, leaf_data, audit = archive_audit(ROOT / 'evidence' / leaf / 'worker', expected)
    if leaf == 'virgl-original-programs':
        original = read_json(leaf_data['hot/receipt.json'])
        assert original['pixels'] == 1612644 and original['powerSites'] == 29
        for name, expected_source in original['sources'].items():
            if name != 'Makefile' and not name.startswith('tasks/'):
                source(name, expected_source)
        audit['pixels'] = original['pixels']
        audit['powerSites'] = original['powerSites']
    audit['leaf'] = leaf
    audit['sourceHead'] = leaf_manifest.get('sourceHead', leaf_manifest.get('frozenSourceHead'))
    held.append(audit)
verifier_manifest, _, verifier_audit = archive_audit(ROOT / 'evidence/virgl-original-programs/verifier')
assert verifier_manifest['verdict'] == 'verified' and verifier_manifest['workerSourceHead'] == BASE

result = {'status': 'passed', 'task': 'E6-T12g6', 'workerSourceHead': FROZEN, 'worker': summary,
          'sourceFiles': len(cache), 'generatedRuntimeIdentical': True, 'browserReports': browser,
          'cold': cold, 'heldLeaves': held, 'originalProgramsVerifier': verifier_audit,
          'postFreezeChanges': post_freeze, 'unchangedRuntimeBoundaryTestOnlyDiff': dependency_diff}
(OUT / 'authentication.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': 'passed', 'members': summary['records'], 'sourceFiles': len(cache), 'browserReports': len(browser), 'heldLeaves': held}, indent=2))
