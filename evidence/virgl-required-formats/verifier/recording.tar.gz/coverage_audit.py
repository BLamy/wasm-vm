#!/usr/bin/env python3
"""Bind the changed straight-line test cases to precise execution counters."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def script_from_node(folder, source):
    url = (ROOT / source).as_uri()
    matches = []
    for file in (OUT / folder).glob('*.json'):
        for entry in json.loads(file.read_bytes())['result']:
            if entry['url'] == url:
                matches.append(entry)
    assert len(matches) == 1, (folder, source, len(matches))
    return matches[0]

def count_at(script, offset):
    ranges = [r for function in script['functions'] for r in function['ranges'] if r['startOffset'] <= offset < r['endOffset']]
    assert ranges, offset
    narrow = min(ranges, key=lambda r: r['endOffset'] - r['startOffset'])
    return narrow['count']

def points(source, script, needles):
    raw = (ROOT / source).read_bytes()
    frozen = subprocess.check_output(['git', 'show', '5ad750b4:' + source], cwd=ROOT)
    assert raw == frozen
    text = raw.decode()
    result = []
    for needle in needles:
        assert text.count(needle) == 1, needle
        start = text.index(needle)
        count = count_at(script, start)
        assert count > 0, needle
        result.append({'source': source, 'sha256': sha(raw), 'line': text.count('\n', 0, start) + 1, 'needle': needle, 'count': count})
    return result

acceptance = 'renderer/virgl-command/tests/acceptance.mjs'
rows = points(acceptance, script_from_node('node-coverage', acceptance), [
    'reject(setWord(shaderPacket, 3, 49154)',
    'accept(shader("x".repeat(16384), 1, 8192)',
    'const maxShader = accept(shader("x".repeat(49152)',
    'equal(maxShader.commands[0].fields.text.length, 49152',
    'reject(shader("x".repeat(49153))',
])
view = 'renderer/virgl-command/tests/texture-views.mjs'
current = json.loads((OUT / 'current-view-test/report.json').read_bytes())
assert current['status'] == current['browserResult']['status'] == 'passed'
assert current['browserErrors'] == {'console': [], 'page': [], 'requests': []}
coverage = json.loads((OUT / 'current-view-test/browser-coverage.json').read_bytes())
assert sha((OUT / 'current-view-test/browser-coverage.json').read_bytes()) == current['browserCoverage']['sha256']
test_script = next(s for s in coverage['scripts'] if s['source'] == view)
assert test_script['sha256'] == sha((ROOT / view).read_bytes())
rows.extend(points(view, test_script['coverage'], ["out.glsl=out.glsl.padEnd(262145,' ')"]))
checked = next(row for row in current['browserResult']['result']['checkedOutput'] if row['mode'] == 'length')
assert checked['error']['code'] == 'limit-exceeded'
obsolete = json.loads((OUT / 'obsolete-view-test/report.json').read_bytes())
assert obsolete['status'] == 'failed'
assert 'checked output boundary length rejects: expected false, got true' in obsolete['browserResult']['error']['message']
assert obsolete['browserErrors'] == {'console': [], 'page': [], 'requests': []}
closure_source = 'tools/virgl-required-formats/closure.mjs'
closure = script_from_node('closure-coverage', closure_source)
functions = [{'name': f['functionName'], 'count': f['ranges'][0]['count'], 'line': (ROOT / closure_source).read_text().count('\n', 0, f['ranges'][0]['startOffset']) + 1} for f in closure['functions']]
assert not any(f['count'] == 0 and f['name'] in ['bound', 'blob', 'equal'] for f in functions)
classifications = [
    {'hunk': 'Makefile verify-E6-T12g and shell driver', 'classification': 'executed', 'evidence': 'hot/acceptance.log and cold/acceptance.log bind the final command and all retained/fault gates.'},
    {'hunk': 'closure.mjs authenticated join and rejection matrix', 'classification': 'executed', 'evidence': 'hot/closure.json, cold/closure.json, inventory-audit.json and independent Node counters; all original keys/citations independently reproduced.'},
    {'hunk': 'closure.mjs metadata-only backend upload/readback methods and forbidden-allocation traps', 'classification': 'waived', 'reason': 'Trusted test stubs explicitly deny pixel authority. They are intentionally unreachable in metadata-only role admission; physical uploads/readbacks are separate recorded actual WebGL gates.'},
    {'hunk': 'receipt.py source, recording, physical fault, held-leaf and authority guards', 'classification': 'executed', 'evidence': 'Worker receipt, independent authentication plus exact replay and six tampered-input rejections in harness-sensitivity.json.'},
    {'hunk': 'cold.py pristine clone/setup/acceptance/receipt/log path', 'classification': 'executed', 'evidence': 'cold/report.json, cold/cold.log and authenticated clone still pristine; no portability/isolation failure, so not repeated.'},
    {'hunk': 'cold.py exception propagation and shell unexpected-pass messages', 'classification': 'waived', 'reason': 'Error-only proof plumbing reports unsuccessful commands and does not implement resource/format behavior. The recorded successful cold path and physical source fault failures bind the task claim.'},
    {'hunk': 'seal.py source/generated/member hashes and deterministic archive', 'classification': 'executed', 'evidence': 'Independent byte-identical re-seal plus six tampered-input rejections in harness-sensitivity.json.'},
    {'hunk': 'changed decoder input-limit test literals', 'classification': 'executed', 'evidence': 'Hashed hot/cold named Node cases; fresh four-seed replay and precise counters at every changed statement; shrink/one-byte expansion sabotage rejected.'},
    {'hunk': 'changed view output-limit fault literal', 'classification': 'executed', 'evidence': 'Hot/cold checkedOutput[length] errors plus fresh actual hardware test counter and obsolete-64KiB fault detection.'},
    {'hunk': 'README, task log/status, queue and serialized manifests/index', 'classification': 'waived', 'reason': 'Declarative claim/custody metadata is inspected directly and bound by authenticated hashes; no runtime control flow.'},
]
value = {'status': 'passed', 'testPoints': rows, 'currentCheckedOutputLength': checked,
         'obsoleteTestFailure': obsolete['browserResult']['error']['message'],
         'closureFunctionCounters': functions, 'hunkClassifications': classifications,
         'workerDecoderSummaryWaiver': 'The unchanged 16384 maximumCases field is historical reporting. Recorded named cases and exact source/control flow, independently covered here, establish the current 49152 bound.'}
(OUT / 'coverage-audit.json').write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps({'status': 'passed', 'testPoints': rows}, indent=2))
