import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {loadFixtures, repo, sha256} from '../../../tools/virgl-command/fixtures.mjs';

const out = path.dirname(fileURLToPath(import.meta.url));
const acceptancePath = path.join(repo, 'renderer/virgl-command/tests/acceptance.mjs');
const decoderPath = path.join(repo, 'renderer/virgl-command/decoder.mjs');
const acceptance = await fs.readFile(acceptancePath, 'utf8');
const decoder = await fs.readFile(decoderPath, 'utf8');
const fixtures = (await loadFixtures()).fixtures;
const seeds = [0x5311cafe, 0x86753091, 0xde42bc19, 0x106c3a5d];
const {runAcceptance} = await import(pathToFileURL(acceptancePath));
const good = runAcceptance(fixtures, {seeds, count: 4096});
assert.equal(good.status, 'passed');
const relevant = good.attacks.named.filter(row => ['historical 16KiB shader remains admitted', 'maximum shader text and token budgets', 'actual shader text above budget', 'shader declared text over budget'].includes(row.name));
assert.deepEqual(relevant.map(row => [row.name, row.outcome]), [
  ['shader declared text over budget', 'rejected'],
  ['historical 16KiB shader remains admitted', 'accepted'],
  ['maximum shader text and token budgets', 'accepted'],
  ['actual shader text above budget', 'rejected'],
]);
await fs.writeFile(path.join(out, 'decoder-independent-report.json'), JSON.stringify(good, null, 2) + '\n');
const attacks = [];
for (const [name, from, to] of [
  ['input-shrink-16KiB', 'shaderTextBytes: 49152', 'shaderTextBytes: 16384'],
  ['input-overread-one-byte', 'shaderTextBytes: 49152', 'shaderTextBytes: 49153'],
]) {
  assert.equal(decoder.split(from).length, 2);
  const changed = decoder.replace(from, to);
  const folder = path.join(out, 'sabotage', name);
  await fs.mkdir(folder, {recursive: true});
  await fs.writeFile(path.join(folder, 'decoder.mjs'), changed);
  const test = acceptance.replace('"../decoder.mjs"', '"./decoder.mjs"');
  await fs.writeFile(path.join(folder, 'acceptance.mjs'), test);
  const module = await import(pathToFileURL(path.join(folder, 'acceptance.mjs')));
  let failure;
  try {module.runAcceptance(fixtures, {seeds, count: 0});} catch (error) {failure = error.message;}
  assert.ok(failure, name + ' must not pass');
  assert.match(failure, /shader|maximum/);
  attacks.push({name, sourceSha256: sha256(Buffer.from(decoder)), mutationSha256: sha256(Buffer.from(changed)), failure, rejected: true});
}
const report = {status: 'passed', acceptanceSha256: sha256(Buffer.from(acceptance)), decoderSha256: sha256(Buffer.from(decoder)), seeds, mutations: good.attacks.mutations, relevant, attacks,
  summaryAuthority: 'Exact hashed test cases exercise 49152; pre-existing maximumCases.maximumShaderTextBytes=16384 is stale descriptive metadata and not used as an oracle.'};
await fs.writeFile(path.join(out, 'boundary-sensitivity.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report));
