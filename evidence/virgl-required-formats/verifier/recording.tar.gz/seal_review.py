#!/usr/bin/env python3
"""Seal independent verifier observations, execution counters and sabotage records."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
verdict = json.loads((OUT / 'verdict.json').read_bytes())
assert verdict['verdict'] == 'verified'
assert all(p['status'] == 'HELD' for p in verdict['predictions'])
for name in ['authentication', 'inventory-audit', 'record-audit', 'coverage-audit', 'harness-sensitivity', 'boundary-sensitivity', 'promoted-test-sensitivity', 'novel-format-role-attack']:
    assert json.loads((OUT / (name + '.json')).read_bytes())['status'] == 'passed', name
members = {}
excluded = {'manifest.json', 'records.json', 'recording.tar.gz'}
for file in sorted(OUT.iterdir()):
    if file.is_file() and file.name not in excluded:
        members[file.name] = file.read_bytes()
for directory in ['node-coverage', 'closure-coverage', 'current-view-test', 'obsolete-view-test', 'sabotage']:
    for file in sorted((OUT / directory).rglob('*')):
        if file.is_file():
            members[str(file.relative_to(OUT))] = file.read_bytes()
promoted = 'renderer/virgl-command/tests/required-format-roles.mjs'
members['promoted/required-format-roles.mjs'] = (ROOT / promoted).read_bytes()
records = {'schema': 'virgl-required-formats-verifier-records-v1', 'task': 'E6-T12g6',
           'workerSourceHead': verdict['workerSourceHead'],
           'records': [{'path': name, 'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(members.items())]}
index = (json.dumps(records, indent=2) + '\n').encode()
archive = io.BytesIO()
with gzip.GzipFile(fileobj=archive, mode='wb', mtime=0) as zipped:
    with tarfile.open(fileobj=zipped, mode='w') as tar:
        for name, raw in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mtime, info.mode = len(raw), 0, 0o644
            tar.addfile(info, io.BytesIO(raw))
packed = archive.getvalue()
(OUT / 'records.json').write_bytes(index)
(OUT / 'recording.tar.gz').write_bytes(packed)
manifest = {'schema': 'virgl-required-formats-verifier-seal-v1', 'task': 'E6-T12g6', 'verdict': 'verified',
            'workerSourceHead': verdict['workerSourceHead'], 'submissionHead': verdict['submissionHead'],
            'reviewBaseHead': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
            'workerArchiveSha256': verdict['workerArchiveSha256'], 'workerIndexSha256': verdict['workerIndexSha256'],
            'archiveSha256': sha(packed), 'archiveBytes': len(packed), 'recordIndexSha256': sha(index),
            'records': len(members), 'authority': 'isolated-client-format-view-closure',
            'productionDrawAuthority': False, 'guestExecution': False, 'portableDomainCertified': False,
            'coldProofCarriedUnchanged': True, 'promotedTests': {promoted: sha(members['promoted/required-format-roles.mjs'])}}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2))
