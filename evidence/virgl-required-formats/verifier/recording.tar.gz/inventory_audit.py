#!/usr/bin/env python3
"""Walk original wire bytes directly; do not use worker fixture or decoder helpers."""
from pathlib import Path
import gzip
import hashlib
import json
import struct

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
index = json.loads((ROOT / 'evidence/virgl-workload-inventory/index.json').read_bytes())
results = {}
fields = ['target', 'format', 'bind', 'width', 'height', 'depth', 'arraySize', 'lastLevel', 'nrSamples', 'flags']
types = {'SURFACE': 8, 'SAMPLER_VIEW': 6, 'SAMPLER_STATE': 7}
rows, objects, transfers = [], [], []
for workload, pin, capture in [
    ('kmscube', index['kmscubeInventory'], 'evidence/virgl-corpus/captures/kmscube'),
    ('es2gears', index['gearsInventory'], 'evidence/virgl-workload-inventory/captures/es2gears'),
]:
    inv_raw = (ROOT / 'evidence/virgl-workload-inventory' / pin['path']).read_bytes()
    assert sha(inv_raw) == pin['sha256']
    inv = json.loads(inv_raw)
    folder = ROOT / capture
    manifest_raw = (folder / 'manifest.json').read_bytes()
    assert sha(manifest_raw) == inv['captureManifestSha256']
    manifest = json.loads(manifest_raw)
    events_raw = (folder / 'events.jsonl').read_bytes()
    assert sha(events_raw) == manifest['events']['sha256']
    events = [json.loads(line) for line in events_raw.splitlines()]
    assert all(event['seq'] == i + 1 for i, event in enumerate(events))
    blobs = {}
    def blob(ref):
        if ref['sha256'] not in blobs:
            base = folder / 'blobs' / (ref['sha256'] + '.bin')
            raw = base.read_bytes() if base.exists() else gzip.decompress(base.with_suffix('.bin.gz').read_bytes())
            assert len(raw) == ref['bytes'] and sha(raw) == ref['sha256']
            blobs[ref['sha256']] = raw
        return blobs[ref['sha256']]
    def packet(citation):
        event = events[citation['event'] - 1]
        assert event['type'] == 'submit_cmd' and event['phase'] == 'enter' and event['ctxId'] == citation['contextId']
        ref = next(ref for ref in event['blobs'] if ref['role'] == 'command')
        assert ref['sha256'] == citation['blobSha256']
        raw = blob(ref)[citation['byteOffset']:citation['byteOffset'] + citation['byteLength']]
        assert len(raw) == citation['byteLength'] and sha(raw) == citation['packetSha256']
        words = struct.unpack('<' + str(len(raw) // 4) + 'I', raw)
        assert (words[0] >> 16) * 4 + 4 == len(raw)
        return raw, words
    for role in inv['clientResourceFormats']:
        for key in role['resources']:
            resource = next(r for r in inv['resources'] if r['key'] == key)
            event = events[resource['createEvent'] - 1]
            assert event['type'] == 'resource_create' and event['phase'] == 'enter' and event['resourceId'] == resource['resourceId']
            metadata = {'id': event['resourceId'], **{name: event[name] for name in fields}}
            assert all(event[name] == resource[name] for name in fields)
            assert [metadata[name] for name in ['depth', 'arraySize', 'lastLevel', 'nrSamples', 'flags']] == [1, 1, 0, 0, 0]
            assert metadata['target'] == (0 if metadata['format'] == 64 else 2)
            rows.append({'workload': workload, 'key': key, 'metadata': metadata, 'createEvent': resource['createEvent']})
    for obj in inv['clientObjects']:
        if obj['kind'] not in types:
            continue
        raw, words = packet(obj['citation'])
        assert (words[0] & 0xffff) == (1 | (types[obj['kind']] << 8))
        assert words[1] == obj['handle']
        recorded = obj['fields']
        if obj['kind'] == 'SURFACE':
            assert len(words) == 6 and words[3] in [2, 16, 67, 233] and words[4:] == (0, 0)
            assert [recorded['format'], recorded['level'], recorded['firstLayer'], recorded['lastLayer']] == [words[3], 0, 0, 0]
        elif obj['kind'] == 'SAMPLER_VIEW':
            assert len(words) == 7 and words[3] == 0x02000043 and words[4:6] == (0, 0) and words[6] == 0x688
            assert [recorded[name] for name in ['target', 'format', 'firstLayer', 'lastLayer', 'firstLevel', 'lastLevel', 'swizzle']] == [2, 67, 0, 0, 0, 0, [0, 1, 2, 3]]
        else:
            assert len(words) == 10
            bits = words[2]
            assert [bits & 7, (bits >> 3) & 7, (bits >> 9) & 1, (bits >> 11) & 3, (bits >> 13) & 1, (bits >> 15) & 1, (bits >> 20) & 31] == [2, 2, 1, 2, 1, 0, 0]
            assert words[3:5] == (0, 0) and words[6:] == (0, 0, 0, 0)
        objects.append({'workload': workload, 'kind': obj['kind'], 'resource': obj['resource'], 'citation': obj['citation']})
    assert inv['clientInlineWriteCount'] == 0
    for transfer in inv['clientTransfers']:
        raw, words = packet(transfer['citation'])
        assert (words[0] & 0xffff) == 43 and len(words) == 14
        assert words[2] == words[4] == words[5] == words[12] == 0 and words[13] == 1
        resource = next(r for r in inv['resources'] if r['key'] == transfer['resource'])
        assert words[1] == resource['resourceId']
        snapshots = [event for event in events[:transfer['citation']['event'] - 1] if event['type'] == 'backing_snapshot' and event['resourceId'] == words[1] and event['reason'] == 'submit']
        snapshot = snapshots[-1]
        backing = blob(snapshot['blobs'][0])
        assert sum(snapshot['iovLengths']) == len(backing)
        used = words[9] * words[10] * (4 if resource['target'] == 2 else 1)
        transfers.append({'workload': workload, 'id': words[1], 'citation': transfer['citation'], 'snapshotEvent': snapshot['seq'], 'usedBytes': used, 'backingSha256': sha(backing), 'denseSha256': sha(backing[:used])})
    results[workload] = {'resourceKeys': [r['key'] for r in rows if r['workload'] == workload], 'packets': sum(o['workload'] == workload for o in objects), 'transfers': sum(t['workload'] == workload for t in transfers), 'manifestSha256': sha(manifest_raw), 'eventsSha256': sha(events_raw)}

assert len(rows) == 38 and len(objects) == 536 and len(transfers) == 5
shaders = index['additionalClientShaders'] + index['additionalSupportingShaders']
assert len(shaders) == len(set(shaders)) == 6
for digest in shaders:
    assert sha((ROOT / 'evidence/virgl-workload-inventory/captures/es2gears/shaders' / (digest + '.tgsi')).read_bytes()) == digest
for prefix in ['hot', 'cold']:
    closure = json.loads((OUT / 'unpacked' / prefix / 'closure.json').read_bytes())
    assert [{'workload': r['workload'], 'key': r['key'], 'metadata': r['metadata'], 'createEvent': r['createEvent']} for r in closure['roles']] == rows
    assert [{key: r[key] for key in ['workload', 'kind', 'resource', 'citation']} for r in closure['originalPackets']] == objects
    assert [{'workload': t['workload'], 'id': t['metadata']['id'], **{key: t[key] for key in ['citation', 'snapshotEvent', 'usedBytes', 'backingSha256', 'denseSha256']}} for t in closure['uploads']] == transfers
    assert closure['shaderBodies'] == shaders
    assert {r['metadata']['format'] for r in closure['unavailable']} == {1, 20, 177}
    assert all(t['requiredMips'] == t['requiredCubeFaces'] == t['requiredArrayLayers'] == 0 for t in closure['topology'])
    assert all(a['held'] and a['actual'] == a['expected'] for a in closure['assertions'])
results.update(status='passed', resources=rows, packets=objects, transfers=transfers, shaderBodies=shaders)
(OUT / 'inventory-audit.json').write_text(json.dumps(results, indent=2) + '\n')
print('Independent wire audit held: 38 resource lifetimes, 536 packets, 5 CPU uploads, 6 literal bodies.')
