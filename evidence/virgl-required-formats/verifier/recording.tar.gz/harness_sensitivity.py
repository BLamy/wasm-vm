#!/usr/bin/env python3
"""Replay custody guards on copies; never rerun the frozen cold acceptance."""
from pathlib import Path
import contextlib
import hashlib
import importlib.util
import io
import json
import shutil
import subprocess
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
FROZEN = '5ad750b459d44b1f92dc3db9f5a49f043647b846'
sha = lambda data: hashlib.sha256(data).hexdigest()

def module(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / 'tools/virgl-required-formats' / (name + '.py'))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

def copied(folder):
    output = OUT / 'harness-replay' / folder
    if output.exists():
        shutil.rmtree(output)
    shutil.copytree(OUT / 'unpacked/hot', output)
    return output

def mutate_json(file, action):
    value = json.loads(file.read_bytes())
    action(value)
    file.write_text(json.dumps(value, indent=2) + '\n')

cold_report = json.loads((OUT / 'unpacked/cold/report.json').read_bytes())
clone = Path(cold_report['clone'])
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clone, text=True).strip() == FROZEN
assert subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=clone, text=True).strip() == ''
receipt = module('receipt')
receipt.ROOT = clone
good = copied('receipt-good')
with patch.object(sys, 'argv', ['receipt.py', str(good)]), contextlib.redirect_stdout(io.StringIO()):
    receipt.main()
assert json.loads((good / 'receipt.json').read_bytes()) == json.loads((OUT / 'unpacked/hot/receipt.json').read_bytes())
attacks = []
cases = [
    ('incomplete-original-packets', 'closure.json', lambda value: value['originalPackets'].pop()),
    ('forged-guest-authority', 'closure.json', lambda value: value.update(guestExecution=True)),
    ('unverified-supporting-format', 'closure.json', lambda value: value['unavailable'][0]['metadata'].update(format=68)),
    ('inventory-source-drift', 'closure.json', lambda value: value['inputs'][0].update(sha256='0' * 64)),
    ('fault-setup-only', 'fault-swizzle/report.json', lambda value: value['browserResult']['error'].update(message='deliberately unrelated setup failure')),
    ('fault-served-bytes', 'fault-channel-order/report.json', lambda value: value['sabotage'].update(servedSha256='0' * 64)),
]
for name, file, action in cases:
    directory = copied('receipt-' + name)
    mutate_json(directory / file, action)
    failure = None
    with patch.object(sys, 'argv', ['receipt.py', str(directory)]), contextlib.redirect_stdout(io.StringIO()):
        try:
            receipt.main()
        except Exception as error:
            failure = str(error)
    assert failure, name
    attacks.append({'guard': 'receipt', 'name': name, 'rejected': True, 'error': failure})

seal = module('seal')
real_check = subprocess.check_output
def frozen_git(command, **kwargs):
    if command == ['git', 'rev-parse', 'HEAD']:
        return FROZEN + '\n' if kwargs.get('text') else (FROZEN + '\n').encode()
    return real_check(command, **kwargs)

def seal_inputs(name):
    base = OUT / 'harness-replay' / name
    if base.exists():
        shutil.rmtree(base)
    shutil.copytree(OUT / 'unpacked/hot', base / 'hot')
    shutil.copytree(OUT / 'unpacked/cold', base / 'cold/acceptance')
    for file in ['report.json', 'cold.log']:
        shutil.copyfile(OUT / 'unpacked/cold' / file, base / 'cold' / file)
        (base / 'cold/acceptance' / file).unlink()
    return base

base = seal_inputs('seal-good')
with patch.object(sys, 'argv', ['seal.py', str(base / 'hot'), str(base / 'cold'), str(base / 'seal')]), patch.object(seal.subprocess, 'check_output', frozen_git), contextlib.redirect_stdout(io.StringIO()):
    seal.main()
worker = ROOT / 'evidence/virgl-required-formats/worker'
assert (base / 'seal/recording.tar.gz').read_bytes() == (worker / 'recording.tar.gz').read_bytes()
assert (base / 'seal/records.json').read_bytes() == (worker / 'records.json').read_bytes()
for name, file, action in [
    ('wrong-head', 'hot/receipt.json', lambda value: value.update(gitHead='c30e72f025ea77c3debd30ec247c5920b0c4f4f7')),
    ('dirty-cold', 'cold/report.json', lambda value: value.update(statusAfter=' M renderer/virgl-command/resources.mjs')),
    ('cold-receipt-drift', 'cold/report.json', lambda value: value.update(receiptSha256='0' * 64)),
    ('record-member-drift', 'hot/receipt.json', lambda value: value['files'].update({'closure.json': '0' * 64})),
    ('frozen-source-drift', 'hot/receipt.json', lambda value: value['sources'].update({'Makefile': '0' * 64})),
    ('generated-runtime-drift', 'hot/receipt.json', lambda value: value['generated'].update({'renderer/virgl-shader/build/wasm/virgl-shader.wasm': '0' * 64})),
]:
    base = seal_inputs('seal-' + name)
    mutate_json(base / file, action)
    failure = None
    with patch.object(sys, 'argv', ['seal.py', str(base / 'hot'), str(base / 'cold'), str(base / 'seal')]), patch.object(seal.subprocess, 'check_output', frozen_git), contextlib.redirect_stdout(io.StringIO()):
        try:
            seal.main()
        except Exception as error:
            failure = str(error)
    assert failure, name
    attacks.append({'guard': 'seal', 'name': name, 'rejected': True, 'error': failure})
result = {'status': 'passed', 'receiptReplayIdentical': True, 'sealReplayByteIdentical': True,
          'frozenColdCloneStillPristine': True, 'coldNotRepeated': True, 'attacks': attacks}
(OUT / 'harness-sensitivity.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
