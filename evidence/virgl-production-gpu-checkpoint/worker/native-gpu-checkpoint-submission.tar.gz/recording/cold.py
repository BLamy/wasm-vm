import hashlib,json,os,pathlib,subprocess,time
repo=pathlib.Path.cwd(); out=repo/'target/evidence/production-gpu-checkpoint-cold01'
out.mkdir(exist_ok=False,parents=True)
clone=out/'repo'; head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
r={'head':head,'status':'running','started':time.time()}
env={k:v for k,v in os.environ.items() if k not in ('RUSTFLAGS','RUSTDOCFLAGS','RUST_LOG') and not k.startswith(('CARGO_','VIRGL_','CRITIC_'))}
try:
 with (out/'clone.stdout').open('wb') as so,(out/'clone.stderr').open('wb') as se:
  subprocess.run(['git','clone','--no-local','--quiet',str(repo),str(clone)],stdout=so,stderr=se,check=True)
 subprocess.run(['git','checkout','--quiet',head],cwd=clone,check=True)
 assert not (clone/'.git/objects/info/alternates').exists()
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==head
 r['cloneMethod']='full-history --no-local; no alternates'
 env['VIRGL_GPU_CHECKPOINT_EVIDENCE_DIR']=str(out/'acceptance')
 with (out/'make.stdout').open('wb') as so,(out/'make.stderr').open('wb') as se:
  subprocess.run(['make','verify-E6-T11d74a'],cwd=clone,env=env,stdout=so,stderr=se,check=True,timeout=3600)
 assert json.loads((out/'acceptance/report.json').read_text())['status']=='passed'
 r['status']='passed'
except BaseException as error:
 r['status']='failed';r['failure']=str(error);raise
finally:
 r['finished']=time.time();(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
