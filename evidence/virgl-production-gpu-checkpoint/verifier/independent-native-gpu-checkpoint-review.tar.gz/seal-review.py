from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

base = Path(__file__).resolve().parent
repo = base.parents[2]
destination = repo / 'evidence/virgl-production-gpu-checkpoint/verifier'
destination.mkdir(parents=True, exist_ok=True)
archive_path = destination / 'independent-native-gpu-checkpoint-review.tar.gz'
files = []
for file in sorted(base.rglob('*')):
    relative = file.relative_to(base)
    if len(relative.parts) > 1 and relative.parts[0] == 'epoch-negative01' and relative.parts[1] in ['source', 'cargo']:
        continue
    if file.is_file():
        files.append((relative.as_posix(), file.read_bytes()))
identities = [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in files]
manifest = json.dumps({'files': identities}, indent=2).encode() + b'\n'
with archive_path.open('wb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, data in files + [('identities.json', manifest)]:
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                archive.addfile(info, io.BytesIO(data))
with tarfile.open(archive_path) as archive:
    assert len(archive.getmembers()) == len(identities) + 1
    for identity in identities:
        data = archive.extractfile(identity['path']).read()
        assert len(data) == identity['bytes'] and hashlib.sha256(data).hexdigest() == identity['sha256']
receipt = {'path': str(archive_path.relative_to(repo)), 'bytes': archive_path.stat().st_size,
           'sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(),
           'members': len(identities) + 1, 'identities': len(identities), 'reopened': True}
(destination / 'independent-native-gpu-checkpoint-review.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
