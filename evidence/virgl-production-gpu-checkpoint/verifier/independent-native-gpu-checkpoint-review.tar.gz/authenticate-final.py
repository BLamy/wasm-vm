#!/usr/bin/env python3
"""Independently reopen the two closed worker packages and pristine evidence."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import tarfile

repo = Path(__file__).resolve().parents[3]
base = Path(__file__).resolve().parent
runtime = "3505a7c480ec855bd1d64d7c0188dea8fc3ab4e8"
frozen = "268019aed7c5f61b0bcab660c6f82b32da828e59"
archives = [
    ("native-gpu-checkpoint-submission.tar.gz", "44bae635eecccc9c202df4e51777031d2ed1c53bb0817180c18336512210871a"),
    ("poison-reset-guard-supplement.tar.gz", "f89e1ad5e15ec31a90021bc896da06e458b629aa80d8cbb2d95fd9adc1d2afb1"),
]
result = {"runtime": runtime, "frozenAcceptance": frozen, "status": "HELD", "archives": []}
for name, expected_hash in archives:
    path = repo / "evidence/virgl-production-gpu-checkpoint/worker" / name
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected_hash
    with tarfile.open(path) as archive:
        members = {member.name: member for member in archive.getmembers()}
        assert len(members) == len(archive.getmembers())
        assert all(member.isfile() for member in members.values())
        identity_document = json.loads(archive.extractfile("identities.json").read())
        identities = identity_document["files"] if isinstance(identity_document, dict) else identity_document
        assert set(members) == {row["path"] for row in identities} | {"identities.json"}
        for row in identities:
            data = archive.extractfile(row["path"]).read()
            assert len(data) == row["bytes"]
            assert hashlib.sha256(data).hexdigest() == row["sha256"], row["path"]
        reports = []
        for member in members:
            if not member.endswith("report.json"):
                continue
            report = json.loads(archive.extractfile(member).read())
            reports.append({"path": member, "status": report.get("status"),
                            "head": report.get("head", report.get("gitHead")),
                            "commands": [(command.get("name"), command.get("exitCode"))
                                         for command in report.get("commands", []) if isinstance(command, dict)]})
        runtime_sources = []
        for member in members:
            if member.startswith("source/crates/core/src/"):
                relative = member[len("source/"):]
                data = archive.extractfile(member).read()
                assert data == subprocess.check_output(["git", "show", frozen + ":" + relative], cwd=repo)
                runtime_sources.append(relative)
        result["archives"].append({"path": str(path.relative_to(repo)), "bytes": len(raw),
                                   "sha256": expected_hash, "members": len(members),
                                   "identities": len(identities), "runtimeSourceMatches": runtime_sources,
                                   "reports": reports})

cold = repo / "target/evidence/production-gpu-checkpoint-cold01"
clone = cold / "repo"
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=clone, text=True).strip() == frozen
assert not subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=no"], cwd=clone)
assert not (clone / ".git/objects/info/alternates").exists()
outer = json.loads((cold / "report.json").read_text())
assert outer["head"] == frozen and outer["status"] == "passed"
acceptance = json.loads((cold / "acceptance/report.json").read_text())
assert acceptance["head"] == frozen and acceptance["status"] == "passed"
assert len(acceptance["commands"]) == 11
assert all(command["exitCode"] == 0 for command in acceptance["commands"])
for row in acceptance["files"]:
    raw = (cold / "acceptance" / row["path"]).read_bytes()
    assert len(raw) == row["bytes"] and hashlib.sha256(raw).hexdigest() == row["sha256"]
browser = json.loads((cold / "acceptance/default-browser/report.json").read_text())
assert browser["status"] == "passed" and browser["passed"] == 127 and browser["failed"] == 0
assert browser["proofExportAbsent"] and browser["errors"] == []
for row in browser["served"]:
    raw = subprocess.check_output(["git", "show", frozen + ":" + row["path"]], cwd=repo)
    assert len(raw) == row["bytes"] and hashlib.sha256(raw).hexdigest() == row["sha256"]
snapshot = browser["screenshot"]
raw = (cold / "acceptance/default-browser" / snapshot["path"]).read_bytes()
assert hashlib.sha256(raw).hexdigest() == snapshot["sha256"]
source_diff = subprocess.check_output(["git", "diff", "--name-only", runtime + ".." + frozen], cwd=repo, text=True).splitlines()
assert source_diff == ["tools/verify-virgl-default-demo.mjs"]
assert not subprocess.check_output(["git", "diff", frozen, "HEAD", "--", "crates/core/src", "crates/core/Cargo.toml", "Cargo.toml", "Cargo.lock", "web"], cwd=repo)
wire = (cold / "acceptance/original-wire.stdout").read_text()
result["cold"] = {"path": str(cold.relative_to(repo)), "head": frozen,
                  "outerReportSha256": hashlib.sha256((cold / "report.json").read_bytes()).hexdigest(),
                  "acceptanceReportSha256": hashlib.sha256((cold / "acceptance/report.json").read_bytes()).hexdigest(),
                  "commands": len(acceptance["commands"]), "authenticatedFiles": len(acceptance["files"]),
                  "noAlternates": True, "trackedClean": True,
                  "wireTestTotals": re.findall(r"test result: ok\. (\d+) passed", wire),
                  "workerRoundtripRows": len(re.findall(r"GPU_CHECKPOINT id=", wire)),
                  "semanticRefusals": len(re.findall(r"semantic=", wire)),
                  "default": {"passed": browser["passed"], "failed": browser["failed"],
                              "errors": browser["errors"], "proofExportAbsent": browser["proofExportAbsent"],
                              "servedSourcePins": len(browser["served"]), "wasmSha256": browser["servedWasmSha256"]}}
(base / "final-authentication.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"status": result["status"], "archives": [{k: a[k] for k in ["path", "members", "identities"]} for a in result["archives"]], "cold": result["cold"]}))
