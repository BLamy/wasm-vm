#!/usr/bin/env python3
"""One bounded native GPU-checkpoint negative control in an owned source copy."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

repo = Path(__file__).resolve().parents[3]
parser = argparse.ArgumentParser()
parser.add_argument("--commit", required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
commit = subprocess.check_output(["git", "rev-parse", args.commit], cwd=repo, text=True).strip()
output = args.output.resolve()
output.mkdir(parents=True, exist_ok=False)
checkout = output / "source"
checkout.mkdir()
checkpoint_path = "crates/core/src/dev/virtio/gpu/checkpoint.rs"
test_path = "crates/core/tests/production_gpu_checkpoint_critic.rs"
root_before = hashlib.sha256((repo / checkpoint_path).read_bytes()).hexdigest()
report = {"scope": "Isolated native GPU epoch-reservation negative control only",
          "started": datetime.datetime.now(datetime.timezone.utc).isoformat(), "commit": commit,
          "prediction": "Removing only the fresh-epoch increment makes the first original restore return epoch1, contradicting literal expected epoch2.",
          "commands": [], "status": "running"}

def save():
    (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")

def pin(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

env = {k: v for k, v in os.environ.items()
       if k not in ("RUSTFLAGS", "RUSTDOCFLAGS", "RUST_LOG")
       and not k.startswith(("CARGO_", "VIRGL_", "CRITIC_"))}
env["CARGO_TARGET_DIR"] = str(output / "cargo")
command = ["cargo", "test", "-p", "wasm-vm-core", "--features", "virgl-renderer",
           "--test", "production_gpu_checkpoint_critic",
           "repeated_restore_reserves_new_epoch_without_resetting_original_highwaters", "--", "--nocapture"]

def run(name):
    print(name, flush=True)
    start = time.monotonic()
    with (output / (name + ".stdout")).open("wb") as out, (output / (name + ".stderr")).open("wb") as err:
        result = subprocess.run(command, cwd=checkout, env=env, stdout=out, stderr=err, timeout=300)
    row = {"name": name, "command": command, "exitCode": result.returncode,
           "seconds": time.monotonic() - start,
           "stdout": pin(output / (name + ".stdout")), "stderr": pin(output / (name + ".stderr"))}
    report["commands"].append(row)
    save()
    return result.returncode

try:
    archive = output / "frozen-native-source.tar"
    with archive.open("wb") as target:
        subprocess.run(["git", "archive", "--format=tar", commit,
                        "Cargo.toml", "Cargo.lock", "rust-toolchain.toml", "crates", "guest/agent", "tools/fuzz"],
                       cwd=repo, stdout=target, check=True)
    report["archive"] = pin(archive)
    subprocess.run(["tar", "-xf", str(archive), "-C", str(checkout)], check=True)
    source_file = checkout / checkpoint_path
    original = source_file.read_text()
    original_bytes = original.encode()
    assert original_bytes == subprocess.check_output(["git", "show", commit + ":" + checkpoint_path], cwd=repo)
    test_bytes = (checkout / test_path).read_bytes()
    assert test_bytes == subprocess.check_output(["git", "show", commit + ":" + test_path], cwd=repo)
    report["healthySource"] = pin(source_file)
    report["test"] = pin(checkout / test_path)
    save()
    assert run("healthy") == 0
    before = ".checked_add(1)\n            .filter(|v| *v < u64::MAX)"
    after = ".checked_add(0)\n            .filter(|v| *v < u64::MAX)"
    assert original.count(before) == 1
    source_file.write_text(original.replace(before, after, 1))
    report["changedSource"] = pin(source_file)
    (output / "checkpoint.before.rs").write_bytes(original_bytes)
    (output / "checkpoint.after.rs").write_bytes(source_file.read_bytes())
    (output / "single-change.diff").write_text(
        "--- frozen/checkpoint.rs\n+++ isolated/checkpoint.rs\n@@ fresh transport epoch @@\n"
        "-" + before + "\n+" + after + "\n")
    assert run("epoch-increment-removed") == 101
    stdout = (output / "epoch-increment-removed.stdout").read_text()
    stderr = (output / "epoch-increment-removed.stderr").read_text()
    assert "repeated_restore_reserves_new_epoch_without_resetting_original_highwaters ... FAILED" in stdout
    assert "left: 1" in stderr and "right: 2" in stderr
    report["status"] = "held"
finally:
    report["rootSourceUnchanged"] = hashlib.sha256((repo / checkpoint_path).read_bytes()).hexdigest() == root_before
    report["finished"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps({k: report[k] for k in ["commit", "status", "rootSourceUnchanged"]}), flush=True)
