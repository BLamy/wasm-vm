"""Retain independent raw traces/counters and exact runtime/source-fault artifacts."""
from pathlib import Path
import gzip
import hashlib
import json
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OUT = ROOT / 'evidence/virgl-precise-word'
paths = {p.relative_to(HERE): p for p in HERE.iterdir() if p.is_file()}
for directory in ['gpu-ae95384f', 'gpu-6b31fdc9', 'gpu-novel', 'node-coverage',
                  'receipt-attacks', 'promoted-native-proof', 'promoted-native-fault-proof',
                  'final-promoted-native']:
    paths.update({p.relative_to(HERE): p for p in (HERE / directory).rglob('*') if p.is_file()})
for relative in [
    'source/renderer/virgl-shader/build/native/virgl-shader',
    'flag-fault/renderer/virgl-shader/build/native/virgl-shader',
    'flag-fault/renderer/virgl-shader/bridge.c',
    'repair-source/renderer/virgl-shader/build/allocation-attack',
    'latch-fault-source/renderer/virgl-shader/build/allocation-attack',
    'latch-fault-source/renderer/virgl-shader/bridge.c',
    'checkout/tools/virgl-precise-word/verifier-browser.mjs',
    'checkout/tools/virgl-precise-word/verifier-novel-browser.mjs',
    'repair-source/renderer/virgl-command/tests/precise-word-regressions.mjs',
    'repair-source/renderer/virgl-shader/native_tests/precise_upstream_allocations.c',
    'repair-source/renderer/virgl-shader/native_tests/precise_upstream_allocations.sh',
] + ['repair-source/renderer/virgl-shader/' + name for name in
     ['bridge.c', 'bridge.h', 'raw_bits.c', 'raw_bits.h', 'checked_upstream.c', 'checked_upstream.h']]:
    path = HERE / relative
    assert path.is_file(), relative
    paths[Path(relative)] = path


def digest(path):
    hasher = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            hasher.update(chunk)
    return hasher.hexdigest()


records = [dict(path=str(relative), bytes=path.stat().st_size, sha256=digest(path))
           for relative, path in sorted(paths.items())]
archive = OUT / 'verifier.tar.gz'
assert not archive.exists(), 'new independent archive only'
with archive.open('xb') as destination:
    with gzip.GzipFile(filename='', mode='wb', fileobj=destination, mtime=0, compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as handle:
            for record in records:
                path = paths[Path(record['path'])]
                info = handle.gettarinfo(str(path), arcname='./' + record['path'])
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                with path.open('rb') as data:
                    handle.addfile(info, data)
seen = set()
by_name = {record['path']: record for record in records}
with tarfile.open(archive) as handle:
    for member in handle:
        name = member.name.removeprefix('./')
        assert name in by_name and name not in seen and member.isfile()
        stream = handle.extractfile(member)
        hasher = hashlib.sha256()
        size = 0
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            hasher.update(chunk)
            size += len(chunk)
        assert size == by_name[name]['bytes'] and hasher.hexdigest() == by_name[name]['sha256'], name
        seen.add(name)
assert seen == set(by_name)
for record in records:
    path = paths[Path(record['path'])]
    assert path.stat().st_size == record['bytes'] and digest(path) == record['sha256'], record['path']
manifest = dict(schema='precise-independent-verifier-lossless-v1', task='E6-T12f4',
                sourceHead='09afcaa29bda5206b98fb14e019f41395d669fec', status='passed',
                archive=dict(path='verifier.tar.gz', bytes=archive.stat().st_size, sha256=digest(archive)),
                files=len(records), uncompressedBytes=sum(r['bytes'] for r in records), records=records,
                boundary='Independent prior/final verifier recordings, literal predictions, actual source faults, '
                         'raw GPU pixels, native traces, source-bound counters and promoted-test runs. Full '
                         'scratch checkouts are reconstructed from immutable Git heads; no historical worker '
                         'archives or irrelevant build directories are duplicated.')
(OUT / 'verifier-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(status='passed', files=len(records), archive=manifest['archive'],
                     uncompressedBytes=manifest['uncompressedBytes'])))
