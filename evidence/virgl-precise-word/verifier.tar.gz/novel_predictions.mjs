// Independent pre-draw predictions for per-lane aliases/negation and numeric
// bank use. This imports only the literal test input generator, not its oracle.
import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
import {bank,kernelVectors} from './checkout/tools/virgl-precise-word/oracle.mjs';
const here=path.dirname(new URL(import.meta.url).pathname),view=new DataView(new ArrayBuffer(4));
function value(w){view.setUint32(0,w,true);return view.getFloat32(0,true);}
function word(v){view.setFloat32(0,v,true);return view.getUint32(0,true);}
const negate=w=>(w^0x80000000)>>>0;
const maximum=(a,b)=>value(a)>value(b)?a:b;
export function predicted(kernel,vector){
 if(kernel.name==='MAX-novel-raw'){
  const a=vector.a,b=vector.b,d=a.slice();
  const x=maximum(negate(a[1]),negate(b[2])),y=maximum(negate(a[0]),negate(b[0]));
  d[0]=x;d[1]=y;d[2]=maximum(negate(y),b[2]);return d;
 }
 assert.equal(kernel.name,'MAX-novel-bank');
 const supplied=bank(kernel,vector),a=supplied.slice(0,4).map(w=>word(-value(w)+.25)),b=[word(.25),word(.75),word(.25),word(.75)],d=a.slice();
 const x=maximum(negate(a[1]),b[2]),y=maximum(negate(a[0]),b[0]);
 d[0]=x;d[1]=y;d[2]=maximum(negate(y),negate(b[1]));return d.map(w=>word(value(w)+1));
}
if(process.argv[1]===new URL(import.meta.url).pathname){
 const fixture=JSON.parse(fs.readFileSync(path.join(here,'novel-fixture.json'))),seed=0x98b31ecc;
 const predictions=fixture.kernels.map(kernel=>({kernel,draws:kernelVectors(kernel,seed).map(vector=>({vector,bank:bank(kernel,vector),words:predicted(kernel,vector)}))}));
 fs.writeFileSync(path.join(here,'novel-predictions.json'),JSON.stringify({schema:'precise-verifier-novel-predictions-v1',seed,predictions},null,2)+'\n');
 console.log('Recorded independent predictions before hardware execution');
}
