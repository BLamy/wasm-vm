import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
import {createVirglShaderBridge} from './checkout/renderer/virgl-shader/index.mjs';
import {parseConstantDomain} from './checkout/renderer/virgl-command/constant-domain.mjs';
const here=path.dirname(new URL(import.meta.url).pathname),root=path.join(here,'checkout'),hash=b=>createHash('sha256').update(b).digest('hex');
const fixture=JSON.parse(fs.readFileSync(path.join(root,'renderer/virgl-shader/tests/precise-word-cases.json'))),wasm=fs.readFileSync(path.join(root,'renderer/virgl-shader/build/wasm/virgl-shader.wasm'));
const bridge=await createVirglShaderBridge({wasmBinary:wasm});
const report={schema:'precise-verifier-metadata-attack-v1',status:'running',wasmSha256:hash(wasm),accepted:[],rejected:[],ownership:[],getterCalls:0};
for(const entry of fixture.cases.filter(e=>e.name.startsWith('profile-'))){
 const result=bridge.translate({stage:entry.stage,text:entry.text});assert.equal(result.ok,true,entry.name);
 const base=result.metadata;assert.equal(parseConstantDomain(base,entry.stage).ok,true);
 const names=['FSEQ','FSNE','MAX','MOV'];
 for(let mask=1;mask<16;mask++){
  const metadata=structuredClone(base);metadata.preciseWordContract.operations=names.filter((_,i)=>mask&(1<<i));
  const parsed=parseConstantDomain(metadata,entry.stage);assert.equal(parsed.ok,true,'valid exact operation subset');
  assert.deepEqual(parsed.precision.operations,metadata.preciseWordContract.operations);report.accepted.push({case:entry.name,mask});
 }
 const mutations=[
  ['missing precision',m=>delete m.preciseWordContract],
  ['symbol precision key',m=>m.preciseWordContract[Symbol('unexpected')]=1],
  ['operations undefined',m=>m.preciseWordContract.operations=undefined],
  ['null precision',m=>m.preciseWordContract=null],
  ['sparse inherited operation',m=>{const ops=[];ops.length=1;Object.setPrototypeOf(ops,{0:'MOV'});m.preciseWordContract.operations=ops;}],
  ['symbol operation',m=>m.preciseWordContract.operations=[Symbol('MOV')]],
  ['coercible operation object',m=>m.preciseWordContract.operations=[{toString(){throw new Error('must not coerce')}}]],
  ['numeric operation',m=>m.preciseWordContract.operations=[0]],
  ['array extra symbol',m=>m.preciseWordContract.operations[Symbol('extra')]='MOV'],
  ['operation accessor',m=>Object.defineProperty(m.preciseWordContract.operations,'0',{enumerable:true,get(){report.getterCalls++;throw new Error('must not invoke operation getter')}})],
  ['stage accessor',m=>Object.defineProperty(m.preciseWordContract,'stage',{enumerable:true,get(){report.getterCalls++;throw new Error('must not invoke precision getter')}})],
  ['record revoked proxy',m=>{const p=Proxy.revocable({},{});p.revoke();m.preciseWordContract=p.proxy;}],
  ['array revoked proxy',m=>{const p=Proxy.revocable([],{});p.revoke();m.preciseWordContract.operations=p.proxy;}],
  ['inherited kind',m=>{delete m.preciseWordContract.kind;Object.setPrototypeOf(m.preciseWordContract,{kind:'tgsi-precise-word-local-v1'});}]
 ];
 for(const key of ['constantDomains','constantAccesses','constantConstraints','constantRadialDomains'])if(Object.hasOwn(base,key))mutations.push(['erase '+key,m=>delete m[key]]);
 for(const [name,mutate]of mutations){
  const metadata=structuredClone(base);mutate(metadata);const parsed=parseConstantDomain(metadata,entry.stage);
  assert.equal(parsed.ok,false,entry.name+'/'+name);assert.equal(parsed.error.code,'shader-domain-error');
  report.rejected.push({case:entry.name,name,result:parsed});
 }
 const metadata=structuredClone(base),parsed=parseConstantDomain(metadata,entry.stage),before=JSON.stringify(parsed);
 metadata.preciseWordContract.kind='changed';metadata.preciseWordContract.stage='changed';metadata.preciseWordContract.operations.push('ADD');
 assert.equal(JSON.stringify(parsed),before);assert.equal(Object.isFrozen(parsed.precision),true);assert.equal(Object.isFrozen(parsed.precision.operations),true);
 report.ownership.push(entry.name);
}
assert.equal(report.getterCalls,0);report.status='passed';
fs.writeFileSync(path.join(here,'metadata-attack-report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,accepted:report.accepted.length,rejected:report.rejected.length,ownership:report.ownership.length,getterCalls:report.getterCalls}));
