"""Fresh final reviewer: interrogate raw recordings without rerunning runtime gates."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
HEAD = '09afcaa29bda5206b98fb14e019f41395d669fec'
OLD = 'b8743ae4f6417017fd3f15693ac11d6813ac5787'
WORKER = HERE.parent / 'virgl-precise-word-worker-09afcaa2'
sys.path.insert(0, str(ROOT / 'tools/virgl-precise-word'))
import native_receipt
import wasm_receipt
import receipt


def require(value, why):
    if not value:
        raise AssertionError(why)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def binding(path, base=ROOT):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path.relative_to(base)), bytes=len(raw), sha256=sha(raw))


def committed(relative, head=HEAD):
    return subprocess.check_output(['git', 'show', head + ':' + relative], cwd=ROOT)


def exact_source(relative, directory=ROOT, head=HEAD):
    require((directory / relative).read_bytes() == committed(relative, head),
            'source differs from exact head: ' + relative)


report = dict(schema='precise-final-independent-record-audit-v1', head=HEAD,
              status='running', checks=[])
previous = read(HERE / 'worker-record-replay.json')
require(previous['head'] == HEAD and previous['status'] == 'passed', 'prior exact-head replay')
for item in previous['records']:
    require(binding(ROOT / item['path']) == item, 'prior raw-record binding')

worker_receipt = read(WORKER / 'receipt.json')
require(worker_receipt['gitHead'] == HEAD and worker_receipt['status'] == 'passed', 'worker identity')
require(len({item['path'] for item in worker_receipt['records']}) == len(worker_receipt['records']),
        'unique worker receipt record inventory')
for item in worker_receipt['records']:
    require(binding(WORKER / item['path'], WORKER) == item, 'worker receipt raw-record binding')
require((ROOT / 'evidence/virgl-precise-word/worker-receipt.json').read_bytes()
        == (WORKER / 'receipt.json').read_bytes(), 'packaged receipt identical')
archive = ROOT / 'evidence/virgl-precise-word/worker.tar.gz'
archive_records = []
with tarfile.open(archive) as handle:
    names = set()
    for member in handle:
        require(member.isfile(), 'archive has regular files only')
        name = member.name.removeprefix('./')
        require(name not in names and not Path(name).is_absolute() and '..' not in Path(name).parts,
                'unique confined lossless archive path')
        names.add(name)
        raw = handle.extractfile(member).read()
        require(raw == (WORKER / name).read_bytes(), 'archived original raw evidence bytes')
        archive_records.append(dict(path=name, bytes=len(raw), sha256=sha(raw)))
require({'receipt.json', 'native/native.log', 'wasm/calls.jsonl', 'gpu/report.json'} <= names,
        'essential raw archive members')
report['workerArchive'] = dict(binding(archive), files=len(archive_records),
                              uncompressedBytes=sum(item['bytes'] for item in archive_records))
report['checks'].append('526 lossless archive files and every receipt/prior raw binding intact')

native = native_receipt.verify(WORKER / 'native', HEAD)
wasm = wasm_receipt.verify(WORKER / 'wasm', HEAD, native)
require(native['stats'] == previous['nativeStats'] and wasm == previous['wasm'],
        'independent transcript reconstruction matches prior HELD result')
require(sha((ROOT / 'evidence/virgl-precise-word/worker-native').read_bytes()) == native['binarySha256'],
        'archived actual instrumented worker binary')
semantic = read(WORKER / 'semantic/report.json')
require(semantic['status'] == 'passed', 'semantic audit completed')
for item in semantic['sources']:
    exact_source(item['path'])
    require(binding(ROOT / item['path']) == item, 'semantic primary source binding')
tokens = [json.loads(line) for line in (WORKER / 'semantic/tokens.jsonl').read_bytes().splitlines()]
expected_tokens = [dict(stage=stage, instructions=[dict(opcode=op, precise=i < 4)
                    for i, op in enumerate([1, 89, 92, 13, 1, 89, 92, 13, 98])])
                   for stage in ('vertex', 'fragment')]
require(tokens == expected_tokens == semantic['actual'], 'both-stage instruction-local flags')
require(sha((ROOT / 'evidence/virgl-precise-word/worker-token-audit').read_bytes())
        == semantic['binary']['sha256'], 'archived actual semantic binary')
report['nativeStats'] = native['stats']
report['wasm'] = wasm
report['checks'].append('native/Wasm full transcript, bounds, recovery, LLVM and semantic source re-audited')

reference = read(WORKER / 'reference.json')
fresh_reference = subprocess.check_output(['node', 'tools/virgl-precise-word/reference.mjs'], cwd=ROOT)
require(read(WORKER / 'reference.json') == json.loads(fresh_reference), 'fresh literal prediction')
report['physical'] = receipt.physical(WORKER / 'gpu', HEAD, native, reference)
fault_manifest = read(WORKER / 'faults/manifest.json')
report['sourceFaults'] = {}
for mode, fault in fault_manifest['modes'].items():
    raw = committed(fault['original']['path'])
    require(raw.decode().count(fault['before']) == 1, 'unique real compiler fault')
    require((WORKER / 'faults' / fault['fault']['path']).read_bytes()
            == raw.decode().replace(fault['before'], fault['after']).encode(), 'actual source sabotage')
    report['sourceFaults'][mode] = receipt.physical(WORKER / 'faults' / mode / 'gpu',
                                                 HEAD, native, reference, fault)
for label, task in [('equality', 'E6-T12f1'), ('selected', 'E6-T12f2'), ('radial', 'E6-T12f3')]:
    retained = receipt.browser(WORKER / ('retained-' + label), HEAD, task=task)
    require(retained['status'] == 'passed', 'retained independent hardware leaf')
report['checks'].append('3320 real words/all pixels and all three actual compiler faults independently re-read')

# Carry old successful semantics only across the unchanged precision boundary.
for relative in ['renderer/virgl-shader/raw_bits.c', 'renderer/virgl-shader/raw_bits.h',
                 'renderer/virgl-shader/bridge.h', 'renderer/virgl-shader/index.mjs',
                 'renderer/virgl-command/state.mjs', 'renderer/virgl-command/constant-domain.mjs']:
    require(committed(relative, OLD) == committed(relative), 'unchanged carried precision dependency')
old_bridge = committed('renderer/virgl-shader/bridge.c', OLD).decode()
new_bridge = committed('renderer/virgl-shader/bridge.c').decode()
normalized = new_bridge.replace('#include "checked_upstream.h"\n', '')
normalized = normalized.replace('   bridge_upstream_allocation_begin();\n', '')
normalized = normalized.replace(' || bridge_upstream_allocation_failed()', '')
require(normalized == old_bridge, 'only ordinary allocation boundary changed in bridge')
old_native = read(HERE.parent / 'virgl-precise-word-worker-b8743ae4/native/native-report.json')
for key in ['originals', 'cases', 'pairs']:
    require([(e['name'] if 'name' in e else e['path'], e['result']) for e in native[key]]
            == [(e['name'] if 'name' in e else e['path'], e['result']) for e in old_native[key]],
            'healthy complete paired compiler results retained after wrapper repair')
held_words = read(HERE / 'held-independent-word-report.json')
require(held_words['status'] == 'passed' and held_words['hostOracleChecks'] == 131136,
        'independent two-seed oracle audit')
for item in held_words['gpu']:
    require(sha((HERE / item['path']).read_bytes()) == item['sha256'], 'carried raw GPU binding')
    capture = read(HERE / item['path'])
    require(capture['status'] == 'passed' and capture['acceptance']['checkedWords'] == item['words'],
            'carried real seed capture complete')
novel = read(HERE / 'novel-hardware-report.json')
require(novel['status'] == 'passed' and (novel['rigs'], novel['words']) == (4, 288), 'novel alias GPU attack')
require(sha((HERE / 'novel-predictions.json').read_bytes()) == novel['predictionSha256']
        and sha((HERE / 'gpu-novel/report.json').read_bytes()) == novel['captureSha256'],
        'novel predictions and raw pixels immutable')
report['carriedWordChecks'] = dict(host=131136, seeds=held_words['seeds'],
                                 independentGPU=held_words['gpu'], novel=novel)
report['checks'].append('old successful word/alias checks carried across exact unchanged precision semantics')

allocation = read(HERE / 'allocation-attack-report.json')
require(allocation['head'] == HEAD and allocation['status'] == 'passed', 'independent allocation exact head')
require(binding(HERE / allocation['log']['path'], HERE) == allocation['log'], 'allocation raw log binding')
for item in allocation['sources']:
    require(sha((ROOT / item['path']).read_bytes()) == item['sha256'], 'allocation compiler source binding')
    exact_source(item['path'], HERE / 'repair-source')
require(sha((HERE / 'repair-source/renderer/virgl-shader/build/allocation-attack').read_bytes())
        == allocation['binarySha256'], 'actual independent allocator binary')
lines = [json.loads(line) for line in (HERE / allocation['log']['path']).read_bytes().splitlines()]
baselines = [line for line in lines if line['kind'] == 'baseline']
faults = [line for line in lines if line['kind'] == 'fault']
require(len(baselines) == 10 and len(faults) == 455 and lines[-1]['recoveries'] == 4550,
        'complete native texture/ordinary/mixed allocator schedule')
for baseline in baselines:
    selected = [line for line in faults if line['name'] == baseline['name']]
    require([line['failAt'] for line in selected] == list(range(1, baseline['allocations'] + 1)),
            'every actual allocator failed once')
for line in faults:
    require(type(line['bytes']) is int and line['bytes'] > 0 and line['attempted'] >= line['failAt']
            and line['allocator'] in ('malloc', 'realloc') and set(line['result']) == {'ok', 'error'}
            and line['result']['ok'] is False, 'every actual failure rejects atomically')
require(not (HERE / 'allocation-attack.err').read_bytes(), 'no sanitizer diagnostics')
latch = read(HERE / 'allocation-latch-fault-report.json')
require(latch['head'] == HEAD and latch['status'] == 'fault-detected'
        and latch['observed']['result']['ok'] is True and latch['observed']['failAt'] == 5,
        'actual latch deletion caught at previously ignored operand allocation')
require(sha((HERE / latch['log']['path']).read_bytes()) == latch['log']['sha256'], 'latch source-fault trace binding')
report['independentAllocation'] = dict(faults=455, recoveries=4550, witnesses=10, latch=latch)
report['checks'].append('independent allocator raw trace and real latch sabotage intact')

coverage = read(HERE / 'changed-c-coverage-09afcaa2.json')
require(coverage['head'] == HEAD and sha((ROOT / coverage['coverage']['path']).read_bytes())
        == coverage['coverage']['sha256'], 'measured changed-C counters')
exported = read(ROOT / coverage['coverage']['path'])['data'][0]
for file in coverage['files']:
    require(sha(committed(file['source'])) == file['sha256'], 'coverage exact source')
    original = next(v for v in exported['files'] if Path(v['filename']) == ROOT / file['source'])
    for record in file['records']:
        require(record['text'] == committed(file['source']).decode().splitlines()[record['line'] - 1],
                'changed-line source text')
        require(record['segments'] == [v for v in original['segments'] if v[0] == record['line']]
                and record['branches'] == [v for v in original['branches'] if v[0] == record['line']],
                'actual region counts from original LLVM export')
v8 = read(HERE / 'changed-v8-coverage.json')
require(v8['head'] == HEAD and v8['source']['sha256']
        == sha(committed(v8['source']['path'])), 'V8 exact consumer bytes')
for item in v8['coverage']:
    require(sha((HERE / item['path']).read_bytes()) == item['sha256'], 'V8 original counters digest')
require(all(line['minimum'] > 0 and not line['unexecutedColumns'] for line in v8['lines']),
        'every added consumer expression executed at most-specific range')
attacks = read(HERE / 'receipt-attack-report.json')
require(attacks['head'] == HEAD and attacks['status'] == 'passed'
        and len(attacks['attacks']) == 8 and all(a['status'] == 'rejected' for a in attacks['attacks']),
        'complete transcript-consistent proof attacks')
report['checks'].append('C source/changed-region counters and V8 evidence preserved; eight proof-reader attacks held')
report['status'] = 'passed'
report['readerSources'] = [binding(ROOT / ('tools/virgl-precise-word/' + name))
                         for name in ['native.py', 'native_receipt.py', 'wasm_receipt.py', 'receipt.py', 'shared.py']]
(HERE / 'final-review-record-audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(status=report['status'], nativeCalls=native['stats']['calls'],
                     wasmCalls=wasm['counts']['calls'], physical=report['physical'],
                     archiveFiles=report['workerArchive']['files'], checks=report['checks'])))
