#!/usr/bin/env python3
"""Verifier-authored public compiler admission attacks; no emitted-source oracle."""
from pathlib import Path
import hashlib,json,subprocess
HERE=Path(__file__).resolve().parent
BINARY=HERE/'source/renderer/virgl-shader/build/native/virgl-shader'
def digest(raw):return hashlib.sha256(raw).hexdigest()
def program(stage,body,constants=False):
 header=[('VERT' if stage=='vertex' else 'FRAG'),
  'DCL IN[0]' if stage=='vertex' else 'DCL IN[0], GENERIC[0], CONSTANT',
  'DCL IN[1]' if stage=='vertex' else 'DCL IN[1], GENERIC[1], CONSTANT',
  'DCL OUT[0], POSITION' if stage=='vertex' else 'DCL OUT[0], COLOR',
  'DCL TEMP[0..117]']
 if constants:header.append('DCL CONST[0..1]')
 return '\n'.join(header+body+['END'])+'\n'
cases=[]
def add(name,stage,body,ok,profile=17,constants=False):
 cases.append(dict(name=name+'-'+stage,stage=stage,text=program(stage,body,constants),ok=ok,profile=profile))
for stage in ('vertex','fragment'):
 for name,a,b,ok in [
  ('positive-zero-tie',0,0x80000000,True),('negative-zero-tie',0x80000000,0,True),
  ('left-nan-select-normal',0x7fc055aa,0x3f800000,True),
  ('right-nan-forbids-output',0x3f800000,0x7fc055aa,False),
  ('left-infinity-select-normal',0xff800000,0x3f800000,True),
  ('right-infinity-forbids-output',0x3f800000,0x7f800000,False),
  ('positive-subnormal-forbids-output',1,0,False),
  ('negative-subnormal-select-zero',0x80000001,0,True)]:
  add(name,stage,[f'IMM[0] UINT32 {{{a},{a},{a},{a}}}',f'IMM[1] UINT32 {{{b},{b},{b},{b}}}',
   'MAX_PRECISE TEMP[0], IMM[0], IMM[1]','MOV_PRECISE OUT[0], TEMP[0]'],ok)
 for side in ('left','right'):
  dst='TEMP[0]' if side=='left' else 'TEMP[1]'
  body=['IMM[0] FLT32 {0,0,0,0}','ADD TEMP[0], CONST[0], IMM[0]',
   'MOV TEMP[1], IN[0]',f'MAX_PRECISE {dst}, -TEMP[0].wzyx, TEMP[1].yxwz',
   f'ADD TEMP[2], {dst}, IMM[0]','MOV_PRECISE OUT[0], TEMP[2]']
  add('negated-'+side+'-alias-numeric-bank',stage,body,True,18,True)
  add('negated-'+side+'-alias-output-bank',stage,body[:-2]+[f'MOV_PRECISE OUT[0], {dst}'],True,18,True)
 add('bank-selection-does-not-grant-output',stage,['MOV TEMP[0], CONST[0]',
  'MAX_PRECISE TEMP[0], TEMP[0], IN[0]','MOV_PRECISE OUT[0], TEMP[0]'],False,17,True)
 add('undefined-selected-away-source',stage,['IMM[0] FLT32 {1,1,1,1}',
  'MOV TEMP[0], IMM[0]','MAX_PRECISE TEMP[0], TEMP[0], TEMP[1]',
  'MOV_PRECISE OUT[0], TEMP[0]'],False)
 add('undeclared-consumed-lane',stage,['IMM[0] FLT32 {0,0,0,0}',
  'MOV TEMP[0].xy, IN[0].xyxy','MAX_PRECISE TEMP[0].xy, -TEMP[0].zwxy, IMM[0]',
  'MOV_PRECISE OUT[0], IN[0]'],False)
 for n,ok in ((178,True),(179,False)):
  add('instruction-count-'+str(n+1),stage,['MOV_PRECISE TEMP[0], IN[0]']*n+['MOV_PRECISE OUT[0], TEMP[0]'],ok)
 for op in ('ADD_PRECISE','MUL_PRECISE','MAX_SAT_PRECISE','MOV_PRECISE_PRECISE'):
  add('unsupported-'+op,stage,[op+' TEMP[0], IN[0], IN[1]','MOV OUT[0], IN[0]'],False)
log=HERE/'native-attack.jsonl'
with log.open('w') as output:
 for index,case in enumerate(cases):
  run=subprocess.run([str(BINARY),case['stage']],input=case['text'].encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
  assert run.returncode==0 and not run.stderr,(case['name'],run.stderr)
  result=json.loads(run.stdout)
  record=dict(index=index,**case,inputSha256=digest(case['text'].encode()),result=result)
  output.write(json.dumps(record,separators=(',',':'))+'\n');output.flush()
  assert result['ok'] is case['ok'],(case['name'],result)
  if case['ok']:
   metadata=result['metadata'];assert metadata['profile']=='virgl-webgl2-raw-bits-v'+str(case['profile'])
   assert metadata['preciseWordContract']==dict(kind='tgsi-precise-word-local-v1',stage=case['stage'],operations=['MAX','MOV'] if 'MAX_PRECISE' in case['text'] else ['MOV'])
   if case['profile']==18:assert metadata['constantDomains']==[dict(kind='constant-bank-finite-f32-v1',stage=case['stage'],slot=0,name=('vs' if case['stage']=='vertex' else 'fs')+'const0',count=2)]
   assert result['glsl'].count('/* TGSI PRECISE word-local */')==case['text'].count('_PRECISE')
  else:assert set(result)=={'ok','error'} and len(run.stdout)<512
report=dict(schema='precise-verifier-native-attack-v1',status='passed',cases=len(cases),accepted=sum(e['ok'] for e in cases),
 binarySha256=digest(BINARY.read_bytes()),log=dict(path=log.name,sha256=digest(log.read_bytes()),bytes=log.stat().st_size))
(HERE/'native-attack-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
