from pathlib import Path
import json, struct, hashlib
here=Path(__file__).resolve().parent
def texture(stage,repeats=1):
    header=['VERT' if stage=='vertex' else 'FRAG', 'DCL IN[0]' if stage=='vertex' else 'DCL IN[0], GENERIC[0], PERSPECTIVE']
    if stage=='vertex': header+=['DCL IN[1]','DCL OUT[0], POSITION','DCL OUT[1], GENERIC[0]']
    else: header+=['DCL OUT[0], COLOR']
    header+=['DCL SAMP[0]','DCL SVIEW[0], 2D, FLOAT','DCL CONST[0]','DCL TEMP[0]']
    body=[f'TEX TEMP[0], IN[{1 if stage=="vertex" else 0}], SAMP[0], 2D']*repeats
    body+=['MUL OUT[1], TEMP[0], CONST[0]','MOV OUT[0], IN[0]'] if stage=='vertex' else ['MUL OUT[0], TEMP[0], CONST[0]']
    return '\n'.join(header+body+['END'])+'\n'
rawv='VERT\nDCL IN[0]\nDCL IN[1]\nDCL OUT[0], POSITION\nDCL OUT[1], GENERIC[0]\nMOV_PRECISE OUT[0], IN[0]\nMOV_PRECISE OUT[1], IN[1]\nEND\n'
rawf='FRAG\nDCL IN[0], GENERIC[0], PERSPECTIVE\nDCL OUT[0], COLOR\nMOV_PRECISE OUT[0], IN[0]\nEND\n'
def legacyv(n):
    return 'VERT\nDCL IN[0]\nDCL IN[1]\nDCL OUT[0], POSITION\nDCL OUT[1], GENERIC[0]\nDCL TEMP[0]\n' + 'MOV TEMP[0], IN[1]\n'*n + 'MOV OUT[0], IN[0]\nMOV OUT[1], TEMP[0]\nEND\n'
cases=[]
for stage in ('vertex','fragment'):
    for n in (1,7,176):
        text=legacyv(n) if stage=='vertex' else texture(stage,n);cases.append(dict(name=f'{"legacy-mov" if stage=="vertex" else "texture"}-{n}-{stage}',stage=stage,vertex=text if stage=='vertex' else '',fragment=text if stage=='fragment' else ''))
for n in (1,7):
    cases += [dict(name=f'legacy-mov-{n}-vertex-raw-fragment',stage='vertex',vertex=legacyv(n),fragment=rawf),
              dict(name=f'texture-{n}-raw-vertex-legacy-fragment',stage='fragment',vertex=rawv,fragment=texture('fragment',n))]
data=bytearray(struct.pack('<I',len(cases)))
for c in cases:
    name=c['name'].encode();data+=struct.pack('<I',len(name))+name+struct.pack('<I',int(c['stage']=='fragment'))
    for key in ('vertex','fragment'):
        text=c[key].encode();data+=struct.pack('<I',len(text))+text
(here/'allocation-fixtures.bin').write_bytes(data)
(here/'allocation-fixtures.json').write_text(json.dumps(cases,indent=2)+'\n')
print(json.dumps(dict(witnesses=len(cases),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())))
