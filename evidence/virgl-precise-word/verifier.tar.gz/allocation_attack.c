/* Verifier-authored bounded real upstream malloc/realloc failure attack.
 * Runtime source is the exact archived implementation head, never edited. */
#include "bridge.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned attempted, fail_at, hit, total_faults, recoveries;
static size_t failed_bytes;
static const char *failed_allocator;
void *precise_word_upstream_malloc(size_t bytes) {
   ++attempted;
   if (attempted == fail_at) { hit=attempted; failed_bytes=bytes; failed_allocator="malloc"; return NULL; }
   return malloc(bytes);
}
void *precise_word_upstream_realloc(void *pointer, size_t bytes) {
   ++attempted;
   if (attempted == fail_at) { hit=attempted; failed_bytes=bytes; failed_allocator="realloc"; return NULL; }
   return realloc(pointer, bytes);
}
struct witness { char *vertex, *fragment; unsigned stage; char name[80]; char *baseline; };
static struct witness witnesses[16];
static unsigned count;
static const char *current="init";
static void require(int value, const char *message) {
   if (!value) { fprintf(stderr,"FAIL %s failAt=%u attempted=%u hit=%u: %s\n", current, fail_at, attempted, hit, message); exit(1); }
}
static unsigned u32(void) {
   unsigned char b[4]; require(fread(b,1,4,stdin)==4,"complete input integer");
   return (unsigned)b[0]|(unsigned)b[1]<<8|(unsigned)b[2]<<16|(unsigned)b[3]<<24;
}
static char *input(void) {
   unsigned n=u32(); require(n<=BRIDGE_MAX_TEXT,"bounded input");
   if (!n) return NULL;
   char *s=malloc(n+1); require(s!=NULL,"owned fixture");
   require(fread(s,1,n,stdin)==n,"complete fixture"); s[n]=0; return s;
}
static const char *translate(struct witness *w) {
   const char *r = w->vertex && w->fragment ? bridge_translate_pair(w->vertex,strlen(w->vertex),w->fragment,strlen(w->fragment)) :
      bridge_translate((int)w->stage,w->vertex ? w->vertex : w->fragment,strlen(w->vertex ? w->vertex : w->fragment));
   const size_t cap = w->vertex && w->fragment ? BRIDGE_MAX_PAIR_RESULT : BRIDGE_MAX_RESULT;
   require(r!=NULL && strnlen(r,cap)<cap,"bounded complete serialized result");
   require(!strstr(r,"(null)"),"no published NULL operand");
   return r;
}
static void recover(void) {
   for (unsigned i=0;i<count;i++) {
      require(!strcmp(translate(&witnesses[i]),witnesses[i].baseline),"exact healthy recovery and reset latch");
      ++recoveries;
   }
}
int main(void) {
   count=u32(); require(count>0&&count<=16,"bounded witnesses");
   for(unsigned i=0;i<count;i++) {
      struct witness *w=&witnesses[i];
      unsigned n=u32();require(n>0&&n<sizeof(w->name),"bounded name"); require(fread(w->name,1,n,stdin)==n,"complete name");w->name[n]=0;
      w->stage=u32();require(w->stage<2,"stage");w->vertex=input();w->fragment=input();require(w->vertex||w->fragment,"some text");
      current=w->name; attempted=0;fail_at=0;
      const char *result=translate(w);
      if (strncmp(result,"{\"ok\":true,",11)) fprintf(stderr,"BASELINE %s\n", result);
      require(!strncmp(result,"{\"ok\":true,",11),"literal healthy acceptance");
      w->baseline=strdup(result);require(w->baseline!=NULL,"owned baseline");
      printf("{\"kind\":\"baseline\",\"name\":\"%s\",\"allocations\":%u,\"result\":%s}\n",w->name,attempted,w->baseline);
   }
   require(fgetc(stdin)==EOF,"complete bounded stream");
   for(unsigned i=0;i<count;i++) {
      struct witness *w=&witnesses[i];current=w->name;attempted=0;fail_at=0;
      require(!strcmp(translate(w),w->baseline),"stable calibration");
      unsigned sites=attempted;require(sites>4&&sites<1024,"bounded actual upstream sites");
      for(unsigned site=1;site<=sites;site++) {
         attempted=hit=0;failed_bytes=0;fail_at=site;
         const char *result=translate(w); fail_at=0;
         require(hit==site&&attempted>=site&&failed_bytes>0,"intended actual nonzero failure");
         /* This expectation is independent of the worker's fault harness. */
         printf("{\"kind\":\"fault\",\"name\":\"%s\",\"failAt\":%u,\"attempted\":%u,\"bytes\":%zu,\"allocator\":\"%s\",\"result\":%s}\n",w->name,site,attempted,failed_bytes,failed_allocator,result);
         fflush(stdout);
         require(!strncmp(result,"{\"ok\":false,",12),"every actual allocation failure rejects");
         require(!strstr(result,"\"glsl\":")&&!strstr(result,"\"vertex\":")&&!strstr(result,"\"fragment\":"),"no partial successful stage published");
         ++total_faults;recover();
      }
   }
   printf("{\"kind\":\"summary\",\"faults\":%u,\"recoveries\":%u,\"witnesses\":%u}\n",total_faults,recoveries,count);
   for(unsigned i=0;i<count;i++) {free(witnesses[i].vertex);free(witnesses[i].fragment);free(witnesses[i].baseline);}
   return 0;
}
