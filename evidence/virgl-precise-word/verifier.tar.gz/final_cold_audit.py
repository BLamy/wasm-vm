"""Final reviewer: lossless pristine evidence and exact healthy result comparisons."""
from pathlib import Path
import hashlib
import json
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
HEAD = '09afcaa29bda5206b98fb14e019f41395d669fec'
COLD = HERE.parent / 'virgl-precise-word-cold-09afcaa2'
WORKER = HERE.parent / 'virgl-precise-word-worker-09afcaa2'


def require(ok, reason):
    if not ok:
        raise AssertionError(reason)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def binding(path, base=ROOT):
    raw = path.read_bytes()
    return dict(path=str(path.relative_to(base)), bytes=len(raw), sha256=sha(raw))


r = read(COLD / 'report.json')
require(r['status'] == 'passed' and r['gitHead'] == HEAD == r['cloneHead'] == r['cloneHeadAfter']
        and r['exitCode'] == 0 and r['statusBefore'] == r['statusAfter'] == '', 'clean exact-source canonical cold exit')
require(r['command'] == ['make', 'verify-E6-T12f4'] and r['timeoutSeconds'] == 2400,
        'canonical exact acceptance command')
require(sha((ROOT / 'tools/virgl-precise-word/cold.py').read_bytes()) == r['harnessSha256'],
        'committed cold environment and clone logic')
require('RUST_LOG' in r['removedEnvironmentNames'], 'actual scrubbed recorded Rust override')
require(sha((COLD / 'cold.log').read_bytes()) == r['logSha256'], 'cold raw command log')
require(sha((COLD / 'acceptance/receipt.json').read_bytes()) == r['receiptSha256']
        == 'f579d9fd37c22a01484568861d5294928be097af034ca6ea4316b5d2daba14ca', 'cold raw receipt')
seen = set()
for record in r['acceptanceFiles']:
    require(record['path'] not in seen and binding(COLD / record['path'], COLD) == record,
            'every unique copied cold raw file intact')
    seen.add(record['path'])
require(len(seen) == 526, 'complete cold artifact inventory')
clone = Path(r['clone'])
require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clone).decode().strip() == HEAD,
        'retained real cold clone source head')
require(not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=clone),
        'retained real cold clone clean')
c = read(COLD / 'acceptance/receipt.json')
w = read(WORKER / 'receipt.json')
for key in ['schema', 'task', 'status', 'gitHead', 'guestExecution', 'currentGuest3dAdvertisement',
            'nativeStats', 'gpu', 'sabotage', 'retained', 'domain', 'migrationInventory']:
    require(c[key] == w[key], 'cold complete acceptance outcome: ' + key)
for record in c['records']:
    require(binding(COLD / 'acceptance' / record['path'], COLD / 'acceptance') == record,
            'cold receipt independently binds complete raw member')
native_c = read(COLD / 'acceptance/native/native-report.json')
native_w = read(WORKER / 'native/native-report.json')
checked = {}
for key in ['originals', 'cases', 'pairs'] + [prefix + suffix for prefix in
          ['raw', 'integer', 'float', 'numeric', 'component', 'dot', 'constant', 'structured',
           'indirect', 'loop', 'equality', 'selected', 'radial'] for suffix in ['Cases', 'Pairs']]:
    require(native_c[key] == native_w[key], 'cold full input identity/result parity: ' + key)
    checked[key] = len(native_c[key])
require((COLD / 'acceptance/native/native.log').read_bytes() == (WORKER / 'native/native.log').read_bytes(),
        'whole deterministic sanitizer transcript identical')
require((COLD / 'acceptance/wasm/calls.jsonl').read_bytes() == (WORKER / 'wasm/calls.jsonl').read_bytes(),
        'whole deterministic Wasm call/pressure transcript identical')
report = dict(schema='precise-final-independent-cold-audit-v1', head=HEAD, status='passed',
              coldReport=binding(COLD / 'report.json'), coldReceipt=binding(COLD / 'acceptance/receipt.json'),
              coldLog=binding(COLD / 'cold.log'), clone=dict(path=str(clone), sourceHead=HEAD,
              currentStatus='clean', recordedStatusBefore='', recordedStatusAfter=''),
              copiedRawFiles=len(seen), exactResultArrays=checked,
              nativeTranscriptSha256=sha((COLD / 'acceptance/native/native.log').read_bytes()),
              wasmTranscriptSha256=sha((COLD / 'acceptance/wasm/calls.jsonl').read_bytes()),
              nativeStats=c['nativeStats'], gpu=c['gpu'], retained=c['retained'],
              environmentScrub=ROOT.joinpath('tools/virgl-precise-word/cold.py').read_text().split('prefixes =', 1)[1].split('head =', 1)[0])
(HERE / 'final-review-cold-audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(status='passed', head=HEAD, files=len(seen), receiptSha256=r['receiptSha256'],
                     nativeCalls=c['nativeStats']['calls'], gpu=c['gpu'])))
