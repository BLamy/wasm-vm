from pathlib import Path
import json,hashlib,subprocess,re
here=Path(__file__).resolve().parent
root=here.parents[2]
target='renderer/virgl-command/constant-domain.mjs'
source=(here/'checkout'/target).read_text()
assert source.encode()==subprocess.check_output(['git','show',f'09afcaa29bda5206b98fb14e019f41395d669fec:{target}'],cwd=root)
scripts=[]
for node in (here/'node-coverage').glob('*.json'):
    for r in json.loads(node.read_text())['result']:
        if r['url'].endswith('/'+target): scripts.append((str(node.relative_to(here)),r))
for name in ['gpu-ae95384f','gpu-6b31fdc9','gpu-novel']:
    p=here/name/'browser-coverage.json'
    for r in json.loads(p.read_text())['scripts']:
        if r['source']==target:
            assert r['sha256']==hashlib.sha256(source.encode()).hexdigest()
            scripts.append((str(p.relative_to(here)),r['coverage']))
def at(script,offset):
    funcs=[f for f in script['functions'] if f['ranges'][0]['startOffset']<=offset<f['ranges'][0]['endOffset']]
    if not funcs:return 0
    f=min(funcs,key=lambda f:f['ranges'][0]['endOffset']-f['ranges'][0]['startOffset'])
    ranges=[r for r in f['ranges'] if r['startOffset']<=offset<r['endOffset']]
    return min(ranges,key=lambda r:r['endOffset']-r['startOffset'])['count']
rows=[];offset=0
changed=set([12,*range(16,26),66,*range(69,82),109,151])
for line_no,line in enumerate(source.splitlines(True),1):
    if line_no in changed:
        counts=[]
        for i,c in enumerate(line):
            if c.isspace():continue
            value=sum(at(s,offset+i) for _,s in scripts)
            counts.append((i,value))
        zero=[i for i,c in counts if c==0]
        rows.append(dict(line=line_no,text=line.rstrip(),minimum=min(c for _,c in counts),maximum=max(c for _,c in counts),unexecutedColumns=zero))
    offset+=len(line)
report=dict(schema='precise-verifier-v8-changed-lines-v1',status='measured',head='09afcaa29bda5206b98fb14e019f41395d669fec',source=dict(path=target,sha256=hashlib.sha256(source.encode()).hexdigest()),coverage=[dict(path=p,sha256=hashlib.sha256((here/p).read_bytes()).hexdigest()) for p,_ in scripts],lines=rows)
(here/'changed-v8-coverage.json').write_text(json.dumps(report,indent=2)+'\n')
for r in rows: print(r['line'],r['minimum'],r['maximum'],r['unexecutedColumns'])
