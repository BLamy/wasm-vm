# E6-T12f4 independent verifier predictions

Frozen source head: b8743ae4f6417017fd3f15693ac11d6813ac5787.
Verified parent boundary: 220c2640d8c75df4decae10a3aa12a7be150897f.
Written after task/diff orientation and before opening any F4 worker recording.

1. P1 semantic scope: the pinned TGSI parser will emit MOV/FSEQ/FSNE/MAX opcodes in order with the Precise bit set only for each marked instruction, in both stages. The bound stable TGSI definition will specify strict ordered x > y for MAX, ordered FSEQ and unordered FSNE. No automatic backward arithmetic precision claim is made.
2. P2 exact execution: at the bit observer, MAX(+0,-0) yields 0x80000000, MAX(-0,+0) yields zero, a NaN in source0 yields source1, and a NaN in source1 preserves that exact word. FSEQ(+0,-0) yields all ones; FSNE(NaN,NaN) yields all ones. MOV preserves all bits. Aliased/swizzled/computed/negated inputs match an independent rational binary32 oracle in both stages under independent seeds 0xae95384f and 0x6b31fdc9.
3. P3 retained flag: every accepted marked instruction contributes its emitted instruction-local marker and exactly the sorted operation contract. A compiler-source mutation dropping a retained flag or selecting the wrong MAX arm is refuted by the independent expectations and physical word observer, respectively.
4. P4 authority and obligations: an exact copy/selection cannot make an otherwise unauthorized raw word legal at a floating output, or make an undefined consumed lane defined. Profiles17..26 retain their simultaneous finite/indirect/count/radial obligations. Removing any mandatory obligation, changing its family, or supplying malformed precision data rejects without invoking getters or accepting caller-owned mutable state.
5. P5 compatibility: all unchanged historical results remain identical except the 20 specified accepted singles, two specified rejection-class changes and two specified radial pairs. All nineteen original source bodies retain their capture hashes and 12 accepted/7 rejected outcome. Production guest negotiation remains disabled.
6. P6 measured coverage: source-bound LLVM execution counters cover each changed runtime C hunk and V8 counters cover added consumer profile/precision behavior. Any unexecuted region is either a cited metadata/type/config/error waiver or an explicit proof gap. Existing F3 HELD results with unchanged source/dependency/evidence remain HELD.
7. P7 bounds and failure recovery: the new flag/opcode does not change instruction/IR/memory/stack limits. The sanitizer and fixed 16MiB Wasm runs retain complete results through real allocation failures, pressure, truncation and alias recovery; a 180th PRECISE instruction is rejected with a bounded structured error.
8. P8 evidence and isolation: worker/cold archives and every cited trace/capture digest bind the frozen source. Cold acceptance begins and ends with a clean exact-head checkout, scrubbed compiler/test environment and local hardware GPU. Compiler-source faults genuinely change the C implementation and fail due to observed words, with sources/artifacts bound.

Bounded novel attack: combine per-lane negated MAX with source/destination aliasing and distinct numeric/bank authority, followed by a numeric use and ordinary output. Expect exact pre-write selection with preserved obligations, and rejection if a selected arm lacks required authority. Add precision metadata descriptor/sparse/symbol/prototype attacks and instruction-cap neighbors without expanding the product boundary.

No verdict or status change until completed worker claim, packaged evidence and final cold proof are submitted.

## Allocation finding at the first frozen head

P7 FAILED at b8743ae4: worker wasm/calls.jsonl line24440, record index24439,
kind pressure, profile-26-fragment-mixed-pair reports ok:true while legacy vertex
GLSL contains four `(null)` expressions at offsets396,421,446,471. Full call-log
SHA256 df4b20b9f9bf4bdadd65959f355d0d20279fd6deec23f29ea14aaa44685f9450;
record result SHA256 14ae1b6e8515afac1bc08b5d4e91e82cca71b49827e892c4564016df58d4beeb.
Worker found this before submission and is repairing the allocation boundary.

P9 prediction before inspecting the forthcoming allocation fix: every failed
nonzero upstream operand-buffer allocation, even when pinned conversion returns
true, produces a complete bounded error and no successful partial shader/pair.
Both vertex-first and fragment-first legacy/raw pair arrangements preserve the
earliest error. Successful calls after heap release return the exact native
baseline rather than retaining a stale failure latch. Real allocator failures
and an actual latch-removal source fault must exercise this boundary; malloc,
calloc and realloc interception must be measured or specifically waived where
the admitted pinned conversion cannot invoke a site. Final evidence/cold proof
must bind the repaired head. Existing exact word predictions carry only for
unchanged instruction semantics and dependency boundaries.


## Repaired frozen boundary

New runtime/harness head: 09afcaa29bda5206b98fb14e019f41395d669fec.
P9a prediction before the independent texture run: every real nonzero upstream
malloc/realloc failed in ten otherwise accepted legacy texture witnesses returns
ok:false with no serialized stage/GLSL payload and no NULL operand. These include
one, seven and 176 repeated TEX operations in both stages, and both legacy/raw
pair arrangements. The ignored 128-byte bias/offset constructors must be safe
under ASan/UBSan, and each failed allocation must be followed by exact complete
recovery of all ten witnesses. Faulting only the final bridge latch condition in
an isolated source copy must fail this literal error expectation at a constructor
failure that upstream ignores. Counts and source-bound LLVM regions will identify
which constructor, lazy reserve, malloc, realloc and ready/error branches ran.

P9a input correction before fault-state inspection: TEX is explicitly restricted
by bridge.c:868 to the fragment stage. The initial vertex-TEX probe rejected
before any upstream allocation. Replace its three standalone and two pair
witnesses with otherwise equivalent admitted legacy vertex MOV sequences.
This preserves both-stage allocator/latch coverage and both mixed arrangements;
the ignored texture-specific constructors are tested only in admitted fragments.
No claim of vertex-TEX support or upstream vertex-TEX failure handling is made.
