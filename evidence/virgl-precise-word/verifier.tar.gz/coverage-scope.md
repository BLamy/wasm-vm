# Changed-hunk coverage scope

Implementation head: 09afcaa29bda5206b98fb14e019f41395d669fec.
Parent: 220c2640d8c75df4decae10a3aa12a7be150897f.

`changed-c-coverage-09afcaa2.json` retains actual LLVM segment/branch counters
for every added C line and complete regions for each new helper. Closing braces,
comments, include lines and string literal continuation lines are not independent
executable regions; a preceding counter is not presented as their hit count.
`changed-v8-coverage.json` resolves the most specific function/block range, so a
module-level positive count cannot conceal an unexecuted function. Every added
consumer expression has a positive count after the independent legacy-absence
probe. Counter source digests match the committed source, including the unchanged
consumer boundary carried from b8743ae4.

| Changed boundary | Actual coverage / classification |
| --- | --- |
| bridge.c:470-471 | MAX and MAX_PRECISE radial recognition comparisons execute in the source-bound native matrix; precise radial kernels also execute on hardware. |
| bridge.c:801-808 | MOV_PRECISE1124340, FSEQ_PRECISE27, FSNE_PRECISE37 and MAX_PRECISE112 parser arms execute; alternate ordinary opcodes also execute. |
| bridge.c:861-862,1114-1115,1129 | Candidate discovery and MAX numeric-negation admission execute on both true/false outcomes; independent negated/aliased hardware and admission probes corroborate the changed operand path. |
| bridge.c:1236,1240 | Begin635093; failed635081. Eight calls have converted:true and allocation_failed:true, independently rejecting the formerly successful partial conversion. Converted:false12 also executes. Diagnostic/output-cap alternatives in this condition are unchanged inherited checks, not new error behavior. |
| bridge.c:1307-1339,1355,1403 | precise_profile488410 and precise_contract488410 calls. All10 selected profile arms, all4 operation identities, both stages, and comma/non-comma paths execute. Static names/comment/punctuation are data/type waivers. |
| raw_bits.c:135-148 | precise_source404; source negation96/308, nonzero origin20/76. The sign-flip and numeric/output/bank authority preservation executes. |
| raw_bits.c:234-241,291 | MAX_PRECISE recording and retained feature flag execute, including known and unknown selections; constant-domain output authority rejects independently authored selected NaN/subnormal/undefined cases. |
| raw_bits.c:340-347,454,463-465,474,478,501-503,517-519,536-537 | precise_operand336; sign XOR80/256. Helper emission, instruction markers, raw pre-write snapshot/shadow and both operand arms execute. Both-stage physical words and the partial-destination aliased novel kernels substantiate the result, beyond strings emitted by the compiler. |
| checked_upstream.c:22-37 | Begin/reset/getter and both allocators execute. Native malloc12/realloc8 failures plus independent malloc414/realloc41 failures; healthy allocator outcomes execute. The bytes==0 null alternative is waived: every admitted pinned allocation site uses a positive fixed/growth size; so_info calloc at pinned vrend_shader.c:8158 cannot run with the owned zeroed info/key. No generic allocator contract is claimed. |
| checked_upstream.c:47-96 | Safe empty439 in independent run; constructor316883success/414failure, ready error1359, lazy reserve12659 with25failure, fmt990error, appendf394error. Worker native also hits each executable path. The independent TEX attack includes ignored128-byte constructors, which normal MOV calibration alone does not prove. |
| checked_upstream.c/.h macro/include/type branches | Compile-selected production malloc/realloc delegation is exercised by the recorded fixed-memory Wasm run; native test hooks call real allocation except the explicitly recorded failed site. Headers/macros/format attributes/static initialization are compile/data waivers. Unchanged pinned TU statements are outside the task diff. |
| raw_bits.h | Flag/opcode constants and static assertions are compile/type waivers, corroborated by measured unchanged raw_ir26480, raw_instruction112, profile7616, flow arena52644 / bound53248 / depth8. |
| constant-domain.mjs | `changed-v8-coverage.json` covers every added expression at lines12,16-25,66,69-81,109,151. All20 profile anchors, all15 valid operation subsets per profile, descriptor/sparse/symbol/proxy and mandatory-obligation rejection, frozen ownership, and both legacy omission paths execute. |
| C/JS test programs, fixtures, oracles and receipt scripts | These are proof programs/data, executed by canonical acceptance and independently checked against literal expectations. Native full stream19/4428/511,50 GPU kernels,334 worker metadata forgeries, and8 transcript-consistent verifier proof-reader attacks cover the claimed proof boundary. Reflection/error guards and fatal CLI/recording failures have no new product behavior; they are bounded proof-tool checks, not runtime code waived as tested. |
| build.sh, Makefile and acceptance/cold/browser adapters | Compiler/tool configuration, capture plumbing and entry recipes are exercised by the recorded acceptance and exact-head cold invocation. No target architecture, production export or public fault-injection API is introduced. Version rejection, capture cleanup and timeout/error reporting are infrastructure guards, waived outside the successful product run; their inclusion is not offered as runtime coverage. |
| Mesa definition, README, contract/queue/task metadata | Static reference/documentation/planning waivers. The pinned definition digest and actual token/parser audit bind the precise semantics; doc text cannot establish a runtime result. The production guest negotiation bit stays false and original captured bodies stay12/19. |

The unaffected F3 HELD results carry forward only where the source/dependency
boundary and evidence digest are unchanged. The b874 allocation refutation is
retained as an explicit FAILED predecessor; the repaired boundary is covered at
09af by canonical native/Wasm and independent real allocator failures. No verdict
or task status is set by this coverage note while cold/final claim is pending.
