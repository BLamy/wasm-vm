// Independent verifier word predictions use exactly representable binary32
// values in JS binary64, not the worker rational oracle or compiler sort keys.
import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
import {operation as workerOperation} from './checkout/tools/virgl-precise-word/oracle.mjs';
const here=path.dirname(new URL(import.meta.url).pathname),view=new DataView(new ArrayBuffer(4));
const hash=raw=>createHash('sha256').update(raw).digest('hex');
function float(w){view.setUint32(0,w,true);return view.getFloat32(0,true);}
function bits(f){view.setFloat32(0,f,true);return view.getUint32(0,true);}
export function ownOperation(op,a,b){
 if(op==='MOV')return a;
 const x=float(a),y=float(b);
 if(op==='MAX')return x>y?a:b;
 if(op==='FSEQ')return x===y?0xffffffff:0;
 if(op==='FSNE')return x!==y?0xffffffff:0;
 throw new Error('unknown exact word operation');
}
function wanted(rig,draw){
 if(rig.kernel.kind==='radial')return draw.bank.slice(20,24).map(w=>bits(float(w)+0));
 const split=rig.kernel.name.indexOf('-'),op=rig.kernel.name.slice(0,split),variant=rig.kernel.name.slice(split+1);
 let a=draw.vector.a.slice(),b=draw.vector.b.slice();
 if(variant==='computed'){a=a.map((w,i)=>(w+[17,29,31,43][i])>>>0);b=b.map(w=>(~w)>>>0);}
 else if(variant==='numeric'){a=[0x3f000000,0x3f800000,0x3f000000,0x3f800000];b=Array(4).fill(0x3f000000);}
 else if(variant==='swizzle'){a=a.reverse();b=[b[1],b[0],b[3],b[2]];}
 else if(variant==='literal'||variant==='literal-negative'){
  a=[0,0x80000000,0x7fc01234,0x3f800000];b=[0x80000000,0,0x3f800000,0xffc05678];
 }
 if(variant==='negative'||variant==='literal-negative'){a=a.map(w=>(w^0x80000000)>>>0);b=b.map(w=>(w^0x80000000)>>>0);}
 return a.map((w,i)=>ownOperation(op,w,b[i]));
}
const report={schema:'precise-verifier-independent-words-v1',status:'running',hostOracleChecks:0,seeds:[],gpu:[]};
for(const seed of [0xae95384f,0x6b31fdc9]){
 let state=seed;function next(){state^=state<<13;state^=state>>>17;state^=state<<5;return state>>>0;}
 const inputs=[[0,0x80000000],[0x80000000,0],[0x7fc01234,0x7fc01234],[0xff801111,0x3f800000],[0x3f800000,0x7f801111],[1,0],[0x80000001,0],[0x7f800000,0xff800000]];
 for(let i=0;i<16384;i++)inputs.push([next(),next()]);
 for(const [a,b]of inputs)for(const op of ['MOV','MAX','FSEQ','FSNE']){assert.equal(workerOperation(op,a,b),ownOperation(op,a,b),'worker rational oracle vs independent binary64 '+op);report.hostOracleChecks++;}
 report.seeds.push({seed,pairs:inputs.length});
}
for(const directory of process.argv.slice(2)){
 const filename=path.join(here,directory,'report.json'),raw=fs.readFileSync(filename),r=JSON.parse(raw);
 assert.equal(r.status,'passed');assert.equal(r.acceptance.status,'passed');assert.equal(r.browser.launch.headless,false);assert.equal(r.browser.gpu.featureStatus[r.browser.webglFeature],'enabled');
 assert.deepEqual(r.browserErrors,{console:[],page:[],requests:[]});
 const result={path:directory+'/report.json',sha256:hash(raw),seed:r.acceptance.seed,rigs:0,draws:0,words:0,pixels:0,hardware:r.acceptance.renderer.renderer,counts:{}};
 for(const rig of r.acceptance.rigs){
  assert.equal(rig.objects.live,0);const calls=rig.glEvents.filter(e=>e.call==='drawElements');assert.equal(calls.length,rig.draws.length);
  for(const draw of rig.draws){
   const words=wanted(rig,draw);assert.deepEqual(draw.oracle.words,words,'independent literal word prediction');assert.deepEqual(draw.words,words,'reconstructed physical word');
   assert.equal(hash(Buffer.from(draw.rgbaBytes)),draw.rgbaSha256);
   for(let y=0;y<64;y++)for(let x=0;x<64;x++){
    const pixel=draw.rgbaBytes.slice((y*64+x)*4,(y*64+x+1)*4),expected=y<2?words.map(w=>((w>>>Math.floor(x/2))&1)*255):[0,0,255,255];
    assert.deepEqual(pixel,expected,rig.input+'/'+draw.vector.name+'/'+x+','+y);result.pixels++;
   }
   result.draws++;result.words+=4;
  }
  result.rigs++;result.counts[rig.kernel.stage+'/'+rig.kernel.name]=rig.draws.length;
 }
 assert.equal(result.rigs,50);assert.equal(result.draws,r.acceptance.drawCount);assert.equal(result.words,r.acceptance.checkedWords);assert.equal(result.pixels,r.acceptance.checkedPixels);
 report.gpu.push(result);
}
report.status='passed';fs.writeFileSync(path.join(here,'independent-word-report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,hostOracleChecks:report.hostOracleChecks,gpu:report.gpu.map(({counts,...v})=>v)}));
