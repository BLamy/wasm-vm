import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';import {execFileSync} from 'node:child_process';
const here=path.dirname(new URL(import.meta.url).pathname),root=path.join(here,'checkout'),hash=b=>createHash('sha256').update(b).digest('hex');
const predictionRaw=fs.readFileSync(path.join(here,'novel-predictions.json')),predictions=JSON.parse(predictionRaw),raw=fs.readFileSync(path.join(here,'gpu-novel/report.json')),r=JSON.parse(raw),fixture=JSON.parse(fs.readFileSync(path.join(here,'novel-fixture.json'))),native=JSON.parse(fs.readFileSync(path.join(here,'novel-native.json')));
assert.equal(r.status,'passed');assert.equal(r.acceptance.seed,predictions.seed);assert.equal(r.acceptance.rigs.length,4);assert.deepEqual(r.browserErrors,{console:[],page:[],requests:[]});
assert.equal(r.browser.launch.headless,false);assert.equal(r.browser.gpu.featureStatus[r.browser.webglFeature],'enabled');
const report={schema:'precise-verifier-novel-hardware-v1',status:'running',predictionSha256:hash(predictionRaw),captureSha256:hash(raw),rigs:0,draws:0,words:0,pixels:0,runtimeSources:[]};
for(const relative of ['renderer/virgl-shader/bridge.c','renderer/virgl-shader/raw_bits.c','renderer/virgl-shader/raw_bits.h','renderer/virgl-shader/bridge.h','renderer/virgl-command/state.mjs','renderer/virgl-command/constant-domain.mjs']){
 const source=fs.readFileSync(path.join(root,relative)),frozen=execFileSync('git',['show','b8743ae4f6417017fd3f15693ac11d6813ac5787:'+relative],{cwd:root});
 assert.equal(hash(source),hash(frozen));report.runtimeSources.push({path:relative,sha256:hash(source)});
}
for(let i=0;i<4;i++){
 const rig=r.acceptance.rigs[i],expected=predictions.predictions[i],entry=fixture.cases[i];assert.deepEqual(rig.kernel,expected.kernel);assert.equal(rig.objects.live,0);
 for(const translation of rig.translations)if(translation.kind==='single'&&translation.request.stage===rig.kernel.stage){
  assert.equal(translation.request.text,entry.text);assert.deepEqual(translation.actual,native[i].result);assert.deepEqual(translation.result,native[i].result);
 }
 const sources=rig.translations.flatMap(t=>t.kind==='pair'?[t.result.vertex.glsl,t.result.fragment.glsl]:[t.result.glsl]);
 for(const event of rig.glEvents){
  if(event.call==='shaderSource')assert.ok(sources.includes(event.source));
  if(event.call==='compileShader'||event.call==='linkProgram')assert.equal(event.status,true);
  if(event.call==='uniform4uiv')assert.deepEqual(event.words,event.observed);
 }
 assert.equal(rig.draws.length,expected.draws.length);assert.equal(rig.glEvents.filter(e=>e.call==='drawElements').length,rig.draws.length);
 for(let j=0;j<rig.draws.length;j++){
  const draw=rig.draws[j],before=expected.draws[j];assert.deepEqual(draw.vector,before.vector);assert.deepEqual(draw.bank,before.bank);assert.deepEqual(draw.words,before.words);assert.deepEqual(draw.oracle.words,before.words);
  assert.equal(hash(Buffer.from(draw.rgbaBytes)),draw.rgbaSha256);
  for(let y=0;y<64;y++)for(let x=0;x<64;x++){
   const pixel=draw.rgbaBytes.slice((y*64+x)*4,(y*64+x+1)*4),wanted=y<2?before.words.map(w=>((w>>>Math.floor(x/2))&1)*255):[0,0,255,255];
   assert.deepEqual(pixel,wanted,rig.input+'/'+draw.vector.name+'/'+x+','+y);report.pixels++;
  }
  report.draws++;report.words+=4;
 }
 report.rigs++;
}
report.status='passed';fs.writeFileSync(path.join(here,'novel-hardware-report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
