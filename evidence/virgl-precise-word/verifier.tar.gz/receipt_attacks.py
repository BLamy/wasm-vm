"""Verifier-adapted report attacks keep transcript digests consistent before audit."""
from pathlib import Path
import json,sys,hashlib,shutil
here=Path(__file__).resolve().parent;root=here.parents[2]
sys.path.insert(0,str(root/'tools/virgl-precise-word'))
import native_receipt,wasm_receipt
head='09afcaa29bda5206b98fb14e019f41395d669fec';worker=here.parent/'virgl-precise-word-worker-09afcaa2'
native=json.loads((worker/'native/native-report.json').read_text())
results=[]
def native_test(name,mutate):
    dest=here/'receipt-attacks'/name;dest.mkdir(parents=True,exist_ok=True)
    for src in (worker/'native').iterdir():
        if src.is_file(): shutil.copyfile(src,dest/src.name)
    r=json.loads((dest/'native-report.json').read_text());mutate(r)
    # Keep the changed typed fields identical in the claimed report and raw log.
    lines=[]
    for line in (dest/'native.log').read_text().splitlines():
        if line.startswith('FAULT '):
            _,index,_=line.split(' ',2);line=f'FAULT {index} '+json.dumps(r['allocationFaults'][int(index)],separators=(',',':'))
        elif line.startswith('UPSTREAM '):
            _,index,_=line.split(' ',2);line=f'UPSTREAM {index} '+json.dumps(r['upstreamCalibrations'][int(index)],separators=(',',':'))
        lines.append(line)
    raw=('\n'.join(lines)+'\n').encode();(dest/'native.log').write_bytes(raw);r['logSha256']=hashlib.sha256(raw).hexdigest()
    (dest/'native-report.json').write_text(json.dumps(r,indent=2)+'\n')
    try: native_receipt.verify(dest,head)
    except ValueError as error: results.append(dict(name=name,status='rejected',reason=str(error)));return
    raise AssertionError('accepted forged report '+name)
def upstream(r): return next(f for f in r['allocationFaults'] if f.get('upstream') is True)
native_test('upstream-calibration-float',lambda r:r['upstreamCalibrations'][0].update(allocations=5.0))
native_test('upstream-failure-bool-bytes',lambda r:upstream(r).update(requestedBytes=True))
native_test('upstream-failure-bool-site',lambda r:upstream(r).update(failAt=True))
native_test('upstream-failure-numeric-tag',lambda r:upstream(r).update(upstream=1))
native_test('upstream-failure-unknown-allocator',lambda r:upstream(r).update(allocator='calloc'))
native_test('missing-wrapper-coverage',lambda r:r['coverage']['sources'].pop())
def wasm_test(name,mutate):
    dest=here/'receipt-attacks'/name;dest.mkdir(parents=True,exist_ok=True)
    # Copy both stages of the recording so its recorded native path remains exact.
    shutil.copytree(worker/'wasm',dest/'wasm',dirs_exist_ok=True)
    shutil.copytree(worker/'native',dest/'native',dirs_exist_ok=True)
    p=dest/'wasm/report.json';r=json.loads(p.read_text());mutate(r);p.write_text(json.dumps(r,indent=2)+'\n')
    try: wasm_receipt.verify(dest/'wasm',head,native)
    except ValueError as error: results.append(dict(name=name,status='rejected',reason=str(error)));return
    raise AssertionError('accepted forged report '+name)
wasm_test('pressure-capacity-bool',lambda r:r['allocationPressure']['targets'][0]['capacityBefore'].update(availableChunks=True))
wasm_test('pressure-requested-bytes-float',lambda r:r['allocationPressure']['targets'][0]['capacityBefore'].update(availableRequestedBytes=float(r['allocationPressure']['targets'][0]['capacityBefore']['availableRequestedBytes'])))
report=dict(schema='precise-verifier-recorded-data-schema-attacks-v1',head=head,status='passed',attacks=results)
(here/'receipt-attack-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
