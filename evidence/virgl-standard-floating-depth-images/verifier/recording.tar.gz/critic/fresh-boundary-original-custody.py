"""Hold every fresh boundary input and actual native upload against pre-run originals."""
import importlib.util
import json
from pathlib import Path
root=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
scratch=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fresh_inverse',root/'tools/virgl-floating-depth/critic.py')
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
prior=json.loads((scratch/'fresh-boundary-original-predictions.json').read_text())
results=[];inputs=0;native_uploads=0
for path in sorted((root/'target/evidence/virgl-standard-floating-depth-critic').glob('hardware-boundaries-*/report.json')):
 record=audit.Recording(path)
 for run in record.data['runs']:
  fmt=run['metadata']['format'];kind=run['kind']
  if fmt==64:continue
  wanted=next(row for row in prior['rows'] if row['scheduleSeed']==record.data['seed'] and row['format']==fmt and row['kind'] in (kind,kind+'-'+str(fmt)))
  planes=wanted['planes']
  audit.require((run['metadata']['width'],run['metadata']['height'],run['metadata']['lastLevel'])==(planes[0]['width'],planes[0]['height'],len(planes)-1),'complete pre-run original geometry')
  if 'input' in run:
   audit.require(record.blob(run['input']).hex()==planes[0]['inputHex'],'complete pre-run boundary input');inputs+=1
  if 'backing' in run:
   audit.require(record.blob(run['backing']).hex()==wanted['backingHex'],'complete pre-run segmented original backing');inputs+=1
  for saved in run.get('inputPlanes',run.get('planes',[])):
   if 'input' in saved:
    audit.require(record.blob(saved['input']).hex()==planes[saved['level']]['inputHex'],'every original boundary mip word');inputs+=1
  source=next((row for row in run['allocations'] if row['metadata']['format']==fmt and row['metadata']['id']==6),None)
  last_pbo={}
  for upload in run['uploads']:
   if upload.get('name')=='bufferSubData':
    last_pbo[upload['unpackBuffer']]=upload['bytes'];continue
   if not source or upload.get('texture')!=source['texture']:continue
   plane=planes[upload['args'][1]]
   point=last_pbo[upload['unpackBuffer']] if fmt==126 else upload['bytes']
   audit.require(record.blob(point).hex()==plane['inputHex'],'complete native uploaded original boundary fields')
   native_uploads+=1
  results.append(dict(path=path.name,report=path.parent.name,reportSha256=record.digest,kind=kind,format=fmt,inputSeed=wanted['inputSeed'],status='held'))
audit.require(len(results)==138,'all three complete original attack schedules')
(scratch/'fresh-boundary-original-custody.json').write_text(json.dumps(dict(schema='fresh-d39-pre-run-original-custody-v1',status='passed',cases=len(results),completeInputBlobs=inputs,completeNativeUploads=native_uploads,records=results),indent=2)+'\n')
print(json.dumps(dict(status='passed',cases=len(results),completeInputBlobs=inputs,completeNativeUploads=native_uploads)))
