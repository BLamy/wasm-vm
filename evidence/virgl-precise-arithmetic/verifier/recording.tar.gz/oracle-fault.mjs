// Precomputed predictions come from verifier audit.py's exact ratio quotient reference.
const response=await fetch('/target/evidence/virgl-precise-arithmetic-verifier/sabotage-vectors.json');
if(!response.ok)throw new Error('verifier prediction file');
const data=await response.json();
export const kernelVectors=()=>data.vectors;
export function bank(kernel,vector){return [vector.a,vector.b,vector.c].flatMap(words=>[...words.map(w=>(0x3f800000|(w>>>16))>>>0),...words.map(w=>(0x3f800000|(w&65535))>>>0)]);}
export const expected=(kernel,vector)=>structuredClone(data.expected[kernel.case][vector.name]);
export const proof=()=>({method:'verifier exact integer ratio quotient rounding',seed:data.seed,vectors:data.vectors.length});
