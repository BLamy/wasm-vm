from pathlib import Path
import subprocess,json,os,hashlib
root=Path.cwd();out=root/'target/evidence/virgl-precise-arithmetic-verifier/native-authority';binary=out/'cli'
assert binary.exists()
inputs=json.load(open(root/'target/evidence/virgl-precise-arithmetic-verifier/authority.json'))
records=[]
for i,entry in enumerate(e for e in inputs['cases'] if 'text' in e):
    raw=entry['text'].encode();input_file=out/(str(i)+'.tgsi');input_file.write_bytes(raw)
    env=dict(os.environ,LLVM_PROFILE_FILE=str(out/(str(i)+'.profraw')),ASAN_OPTIONS='abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
    run=subprocess.run([str(binary),entry['stage']],input=raw,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,check=True,timeout=10)
    result=json.loads(run.stdout);assert result==entry['result'],(entry['name'],result,entry['result'])
    (out/(str(i)+'.stdout')).write_bytes(run.stdout);(out/(str(i)+'.stderr')).write_bytes(run.stderr)
    records.append(dict(index=i,name=entry['name'],stage=entry['stage'],text=entry['text'],inputSha256=hashlib.sha256(raw).hexdigest(),exitCode=run.returncode,result=result,stdoutSha256=hashlib.sha256(run.stdout).hexdigest(),stderrSha256=hashlib.sha256(run.stderr).hexdigest(),profile=str(i)+'.profraw'))
profdata=subprocess.check_output(['xcrun','--find','llvm-profdata'],text=True).strip();cov=subprocess.check_output(['xcrun','--find','llvm-cov'],text=True).strip()
commands=[[profdata,'merge','-sparse',*[str(out/e['profile']) for e in records],'-o',str(out/'merged.profdata')],[cov,'export',str(binary),'-instr-profile='+str(out/'merged.profdata'),str(root/'renderer/virgl-shader/raw_bits.c'),str(root/'renderer/virgl-shader/bridge.c')],[cov,'show',str(binary),'-instr-profile='+str(out/'merged.profdata'),str(root/'renderer/virgl-shader/raw_bits.c'),str(root/'renderer/virgl-shader/bridge.c'),'-show-line-counts-or-regions','-show-branches=count']]
for command,name in zip(commands,['merge.log','coverage.json','coverage-show.txt']):
    run=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True,timeout=30);(out/name).write_bytes(run.stdout);(out/(name+'.stderr')).write_bytes(run.stderr)
sources=[]
source_paths=[Path(p) for p in json.load(open(out/'command.json')) if p.endswith('.c')]
source_paths+=list((root/'renderer/virgl-shader').glob('*.h'))+[root/'renderer/virgl-shader/UPSTREAM.json',root/'renderer/virgl-shader/verify_sources.py',root/'renderer/virgl-shader/build.sh',root/'target/evidence/virgl-precise-arithmetic-verifier/authority.mjs',Path(__file__).resolve()]
for p in source_paths:
    sources.append(dict(path=str(p.relative_to(root)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size))
exported=json.load(open(out/'coverage.json'))['data'][0];file=next(f for f in exported['files'] if f['filename'].endswith('/raw_bits.c'))
branches=[x for x in file['branches'] if x[0]==255]
assert len(branches)==2 and all(x[4]>0 and x[5]>0 for x in branches),branches
report={'status':'passed','head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'binarySha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'sanitizers':{'ASAN_OPTIONS':'abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1'},'sources':sources,'calls':records,'branchPoint':{'path':'renderer/virgl-shader/raw_bits.c','line':255,'branches':branches},'coverageCommands':commands,'tools':[dict(path=p,sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest(),version=subprocess.check_output([p,'--version'],text=True).strip()) for p in [profdata,cov]],'records':[dict(path=str(p.relative_to(out)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(out.iterdir()) if p.is_file() and p.name!='report.json']}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'calls':len(records),'branches':branches}))
