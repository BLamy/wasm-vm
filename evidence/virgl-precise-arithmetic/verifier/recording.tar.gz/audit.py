#!/usr/bin/env python3
"""Fresh integer-ratio quotient rounding; independent of both GLSL and neighbor search."""
import json,subprocess,struct,hashlib
from pathlib import Path
from fractions import Fraction
ROOT=Path.cwd(); OUT=ROOT/'target/evidence/virgl-precise-arithmetic-verifier'

def value(w):
    sign=w>>31;e=(w>>23)&255;f=w&0x7fffff
    if e==255:return ('nan' if f else 'inf',sign,None)
    # All finite binary32 numbers are exact integer multiples of 2^-149.
    n=(f if e==0 else (0x800000+f)<<(e-1))*(-1 if sign else 1)
    return ('finite',sign,Fraction(n,1<<149))

def rounded(v,z=0):
    if v==0:return z<<31
    sign=0x80000000 if v<0 else 0;n=abs(v.numerator);d=v.denominator
    e=n.bit_length()-d.bit_length()
    if (n<d<<e) if e>=0 else (n<<(-e)<d):e-=1
    unit=max(-149,e-23)
    q,r=divmod(n<<(-unit) if unit<0 else n,d<<unit if unit>=0 else d)
    if r*2>(d<<unit if unit>=0 else d) or (r*2==(d<<unit if unit>=0 else d) and q&1):q+=1
    if q==0:return sign
    if q.bit_length()>24:q>>=1;unit+=1
    final_e=q.bit_length()-1+unit
    if final_e>=128:return sign|0x7f800000
    if final_e< -126:
        assert unit==-149 and q<0x800000
        return sign|q
    assert q.bit_length()==24
    return sign|((final_e+127)<<23)|(q&0x7fffff)

def op(name,a,b):
    ka,sa,x=value(a);kb,sb,y=value(b)
    if 'nan' in (ka,kb):return 0x7fc00000
    if name=='ADD':
        if 'inf' in (ka,kb):return 0x7fc00000 if ka==kb and sa!=sb else a if ka=='inf' else b
        return rounded(x+y,int(x==y==0 and sa==sb==1))
    if 'inf' in (ka,kb):return 0x7fc00000 if (ka=='finite' and x==0) or (kb=='finite' and y==0) else ((sa^sb)<<31)|0x7f800000
    return rounded(x*y,sa^sb)

def expected(k,v):
    if k['op'] in ('ORIGINAL','RASTER'):
        words=v['color'] if k['op']=='ORIGINAL' else [0x3e800000,0x3f000000,*v['color'][2:]]
        color=[int(max(Fraction(0),min(Fraction(1),value(w)[2]))*255+Fraction(1,2)) for w in words]
        return {'words':None,'color':color}
    a=v['a'][:];b=v['b'][:]
    variant=k['variant']
    if variant=='swizzle':a=[a[3],a[2],a[1],a[0]];b=[b[1],b[0],b[3],b[2]]
    absolute=variant.startswith('absolute');negative=variant in ('negative','absolute-negative')
    def mod(w):return ((w&0x7fffffff) if absolute else w)^(0x80000000 if negative else 0)
    a=list(map(mod,a));b=list(map(mod,b))
    w=v['a'][:] if variant=='alias-left' else v['b'][:] if variant=='alias-right' else [0,0,0,0]
    for component in k['mask']:
        lane='xyzw'.index(component)
        w[lane]=op('ADD',op('MUL',a[lane],b[lane]),v['c'][lane]) if k['op']=='CHAIN' else op(k['op'],a[lane],b[lane])
    return {'words':w,'branch':v['c'][0]!=0 if variant=='branch' else None}

def audit_recording(directory):
    counts={'references':0,'pixelWords':0,'pixels':0,'stages':set()}
    for p in sorted(directory.glob('reference*.json')):
        r=json.loads(p.read_text())
        for c in r['proof']['cases']:
            for name in ('add','mul','chain'):
                want=[op('ADD',op('MUL',a,b),cc) if name=='chain' else op(name.upper(),a,b) for a,b,cc in zip(c['vector']['a'],c['vector']['b'],c['vector']['c'])]
                assert want==c[name],(p,c['vector']['name'],name,want,c[name]);counts['references']+=4
        for k in r['kernels']:
            for v in k['vectors']:assert expected(k['kernel'],v['vector'])==v['oracle'],(k['kernel'],v)
    for p in sorted(directory.glob('gpu*/report.json')):
        r=json.loads(p.read_text());assert r['status']=='passed'
        for rig in r['acceptance']['rigs']:
            k=rig['kernel'];counts['stages'].add(k['stage'])
            for draw in rig['draws']:
                want=expected(k,draw['vector']);raw=draw['rgbaBytes'];assert want==draw['oracle']
                for y in range(2):
                    for x in range(64):
                        pixel=want['color'] if want['words'] is None else [((w>>(x//2))&1)*255 for w in want['words']]
                        assert pixel==raw[(y*64+x)*4:(y*64+x+1)*4],(p,k,draw['vector'],x,y)
                counts['pixels']+=128;counts['pixelWords']+=4 if want['words'] is not None else 0
    counts['stages']=sorted(counts['stages']);return counts

if __name__=='__main__':
    counts=audit_recording(ROOT/'target/evidence/virgl-precise-arithmetic-worker-final')
    seed=0xd6316ac7
    code="import {vectors} from './tools/virgl-precise-arithmetic/oracle.mjs';process.stdout.write(JSON.stringify(vectors("+str(seed)+")))"
    vectors=json.loads(subprocess.check_output(['node','--input-type=module','-e',code],cwd=ROOT))
    new=[]
    def push(name,a,b,c=None):new.append(dict(name='verifier-'+name,a=a,b=b,c=c or [0x3f800000,0xbf800000,1,0x80000001]))
    limbs=[0,1,0x7fff,0xffff,0x10000,0x3fffff,0x7fffff]
    for i,x in enumerate(limbs):
        for j,y in enumerate(limbs):
            a=0x3f800000|x;b=0x3f800000|y
            push(f'limbs-{i}-{j}',[a,b,a|0x80000000,b|0x80000000],[b,a,b,a])
    for e in [1,2,17,63,126,127,128,253,254]:
        for f in [0,1,0x7ffffe,0x7fffff]:
            a=e<<23|f;upper=a+1
            push(f'cancel-{e}-{f}',[a,upper,a|0x80000000,upper|0x80000000],[upper|0x80000000,a|0x80000000,upper,a])
    for sub in [1,2,3,7,255,256,65535,65536,0x400000,0x7ffffe,0x7fffff,0x800000,0x800001]:
        for mul in [0x3effffff,0x3f000000,0x3f000001,0x3f7fffff,0x3f800001]:
            push(f'underflow-{sub}-{mul}',[sub,sub|0x80000000,mul,mul|0x80000000],[mul,mul,sub,sub|0x80000000])
    for gap in [0,1,2,3,23,24,25,26,30,31,32,33,127,200,253]:
        little=(254-gap)<<23|0x555555
        push(f'gap-{gap}',[0x7f555555,0xff555555,little,little|0x80000000],[little,little,0x7f555555,0x7f555555])
    vectors+=new
    assert len({v['name'] for v in vectors})==len(vectors)
    fixture=json.loads((ROOT/'renderer/virgl-shader/tests/precise-arithmetic-cases.json').read_text())
    fixture['kernels']=[k for k in fixture['kernels'] if k['op'] in ('ADD','MUL','CHAIN') and (k['variant']=='direct' or k['variant']=='absolute-negative' or k['mask'] in ('yz','x'))]
    data={'seed':seed,'vectors':vectors,'expected':{k['case']:{v['name']:expected(k,v) for v in vectors} for k in fixture['kernels']}}
    (OUT/'attack-fixture.json').write_text(json.dumps(fixture)+'\n');(OUT/'attack-vectors.json').write_text(json.dumps(data)+'\n')
    counts.update(status='passed',novelVectors=len(new),newSeed=seed,attackVectors=len(vectors),kernels=len(fixture['kernels']),method='integer-ratio quotient nearest-even; bit_length chooses quantum; no neighbor search, jam or limb algorithm')
    (OUT/'independent-oracle-audit.json').write_text(json.dumps(counts,indent=2)+'\n');print(json.dumps(counts))
