"""Replay all unmodified reader assertions in the exact clone; redirect only final output."""
from pathlib import Path
import json,subprocess,hashlib
import sys,os
root=Path.cwd();out=root/'target/evidence/virgl-precise-arithmetic-verifier'
cold=json.load(open(root/'evidence/virgl-precise-arithmetic/cold-report.json'));clone=Path(cold['clone']);evidence=clone/'target/evidence/virgl-precise-arithmetic-cold'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==cold['gitHead']
code='''from pathlib import Path
import sys
sys.path.insert(0,'tools/virgl-precise-arithmetic')
import receipt
output=Path(sys.argv[2]).resolve()
evidence=Path(sys.argv[1]).resolve()
original_write=Path.write_text
def redirected_write(self,data,*args,**kwargs):
    assert self.resolve()==evidence/'receipt.json',str(self)
    return original_write(output,data,*args,**kwargs)
Path.write_text=redirected_write
receipt.main()
'''
command=[sys.executable,'-c',code,str(evidence),str(out/'replayed-receipt.json')]
run=subprocess.run(command,cwd=clone,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
(out/'receipt-replay.stdout').write_bytes(run.stdout);(out/'receipt-replay.stderr').write_bytes(run.stderr)
assert run.returncode==0,run.stderr.decode()
assert (out/'replayed-receipt.json').read_bytes()==(root/'evidence/virgl-precise-arithmetic/worker-receipt.json').read_bytes()
report={'status':'passed','sourceHead':cold['gitHead'],'clone':str(clone),'command':command,'exitCode':run.returncode,'readerSha256':hashlib.sha256((clone/'tools/virgl-precise-arithmetic/receipt.py').read_bytes()).hexdigest(),'receiptSha256':hashlib.sha256((out/'replayed-receipt.json').read_bytes()).hexdigest(),'assertions':'Original reader functions and exact-head bindings unchanged; only final receipt write diverted to fresh verifier evidence.'}
(out/'receipt-replay-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'passed','receiptSha256':report['receiptSha256']}))
