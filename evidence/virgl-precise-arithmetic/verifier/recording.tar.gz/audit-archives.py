from pathlib import Path
import json,hashlib,tarfile
root=Path.cwd();base=root/'evidence/virgl-precise-arithmetic';out=root/'target/evidence/virgl-precise-arithmetic-verifier'
manifest=json.load(open(base/'manifest.json'));checked=[]
for label in ['worker','cold']:
    archive=base/(label+'.tar.gz');expect=next(x for x in manifest['archives'] if x['path']==archive.name)
    assert archive.stat().st_size==expect['bytes'] and hashlib.sha256(archive.read_bytes()).hexdigest()==expect['sha256']
    inventory={e['path']:e for e in json.load(open(base/(label+'-records.json')))};seen=set();bytes_checked=0
    with tarfile.open(archive,'r|gz') as tar:
        for member in tar:
            assert member.isfile() and member.name in inventory and member.name not in seen,member.name
            e=inventory[member.name];assert member.size==e['bytes'];stream=tar.extractfile(member);h=hashlib.sha256();count=0
            while chunk:=stream.read(1024*1024):h.update(chunk);count+=len(chunk)
            assert count==e['bytes'] and h.hexdigest()==e['sha256'],member.name
            seen.add(member.name);bytes_checked+=count
    assert seen==set(inventory)
    checked.append(dict(archive=archive.name,sha256=expect['sha256'],members=len(seen),uncompressedBytes=bytes_checked))
for category in ['receipts','artifacts','inventories']:
    for e in manifest[category]:
        p=base/e['path'];assert p.stat().st_size==e['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==e['sha256']
report={'status':'passed','sourceHead':manifest['gitHead'],'archives':checked,'sourceDigest':'All sealed receipt/artifact/inventory records also checked.'}
(out/'archive-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
