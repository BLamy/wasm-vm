#!/usr/bin/env python3
"""Whole facade responses and native private-owner failure/caller-state audit."""
import collections,hashlib,json,pathlib,re,struct
dest=pathlib.Path(__file__).resolve().parent;root=pathlib.Path('/tmp/wasmvm-dimensional-views-cold-1c7f8c9b/recording');sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(root/'facade/results.json').read_bytes();facade=json.loads(raw);fresh_raw=(dest/'fresh-facade/results.json').read_bytes();assert raw==fresh_raw
rows=facade['rows'];baseline=json.loads((root/'predecessor/baseline.json').read_bytes());assert len(rows)==794 and facade['traps']==0
checks=[];held={}
profile='virgl-webgl2-standard-dimensional-texture-gles3-v1'
types={'sampler2D','isampler2D','usampler2D','sampler2DShadow','sampler3D','isampler3D','usampler3D','samplerCube','isamplerCube','usamplerCube','sampler2DArray','isampler2DArray','usampler2DArray'}
def metadata(m,stage):
    assert m['profile']==profile and m['stage']==stage
    assert len(m['samplers'])<=16
    for s in m['samplers']:
        assert set(s)=={'index','name','type'} and s['type']in types and 0<=s['index']<16
        assert s['name']==('vssamp'if stage=='vertex'else'fssamp')+str(s['index'])
    assert m['standardSemantics']=={'kind':'native-gles3-highp-v1','precision':'native-highp','undefinedDomains':'native-gles3','preciseQualifier':'no-gpu-shader5','registerStorage':'uvec4','flatVaryingStorage':'uvec4','scalarResults':'tgsi-x-replicated','exactAuthority':False,'gpuExecutionBound':False}
def derived(vertex,fragment):
    inputs=sorted((e for e in fragment['inputs']if e['semantic']=='GENERIC'),key=lambda e:e['semanticIndex'])
    outputs={e['semanticIndex']:e for e in vertex['outputs']if e['semantic']=='GENERIC'}
    for e in inputs:
        o=outputs[e['semanticIndex']];assert not(e['componentMask']&~o['componentMask'])
        assert (o['type'],o['interpolation'])==(e['type'],e['interpolation'])
    return {'ok':True,'key':'standard-generic-interpolation-v1:'+';'.join('g'+str(e['semanticIndex'])+'/'+str(e['componentMask'])+'/'+e['interpolation']for e in inputs),'flat':any(e['interpolation']=='flat'for e in inputs),'coordinates':any(e['semantic']=='POSITION'for e in fragment['inputs']),'discard':False,'inputs':inputs}
for b in baseline['shaderRows']:
    label='stage/'+b['stage']+'/'+b['target']+'/'+b['type']+'/'+b['opcode'];r=next(x for x in rows if x['name']==label)
    assert r['input']==b['request'] and r['result']==b['response']
    md=r['result']['metadata'];assert md['profile']=='virgl-webgl2-standard-dimensional-texture-gles3-v1'
    prefix='vssamp' if b['stage']=='vertex' else 'fssamp';native={('3D','FLOAT'):'sampler3D',('CUBE','FLOAT'):'samplerCube',('2D_ARRAY','FLOAT'):'sampler2DArray'}
    typ=('i'if b['type']=='SINT'else'u'if b['type']=='UINT'else'')+native[b['target'],'FLOAT']
    assert md['samplers'][0]['type']==typ and md['samplers'][0]['name']==prefix+str(md['samplers'][0]['index'])
    held[label]={'request':r['input'],'responseSha256':sha(json.dumps(r['result'],sort_keys=True).encode())}
historic=[r for r in rows if r['name'].startswith('historical/')];assert len(historic)==76
for b in baseline['viewRows']+[r for r in baseline['positiveControls']if r.get('kind')=='historical-2D-view']:
    input=bytes.fromhex(b['hex']) if 'hex'in b else struct.pack('<'+'I'*len(b['words']),*b['words'])
    matching=[r for r in historic if r['name']=='historical/'+b['decoder']and bytes(r['input'])==input];assert len(matching)==1 and matching[0]['result']==b['response']
for i,row in enumerate(rows):
    name=row['name'];result=row['result']
    if name.startswith('stage/'):
        assert set(result)=={'ok','glsl','metadata'} and result['ok']is True and result['glsl'].startswith('#version 300 es')
        metadata(result['metadata'],row['input']['stage'])
    if name.startswith('metadata/'):
        assert result=={'ok':True,'domain':None,'metadata':row['input']}
        stage=next(x for x in rows if x['name']=='stage/'+name.removeprefix('metadata/'))
        assert result['metadata']==stage['result']['metadata'];metadata(result['metadata'],name.split('/')[1])
    if name.startswith('pair/'):
        assert set(result)=={'ok','vertex','fragment','interfaceKey'} and result['ok']is True
        for stage in ['vertex','fragment']:
            body=result[stage];assert set(body)=={'glsl','metadata'} and body['glsl'].startswith('#version 300 es')and len(body['glsl'])<=262144
            metadata(body['metadata'],stage)
        interface=next(x for x in rows if x['name']=='interface/'+name.removeprefix('pair/'))
        assert interface['input']=={'vertex':result['vertex']['metadata'],'fragment':result['fragment']['metadata']}
        assert interface['result']==derived(result['vertex']['metadata'],result['fragment']['metadata']) and result['interfaceKey']==interface['result']['key']
    if name.startswith('interface/'):
        assert result==derived(row['input']['vertex'],row['input']['fragment'])
    if name.startswith(('bad-','compiler-error','pair-error')):assert result['ok']is False and set(result)=={'ok','error'} and set(result['error'])>= {'code','message'}
    if name in ['compiler-error','pair-error']and isinstance(row['input']['code'],str):assert result=={'ok':False,'error':row['input']}
    if name.startswith('unexpected-fault/'):assert result=={'propagatedIdentity':True}
    if name.startswith('qualified-2D-format/'):
        assert result['ok']is True and result['profile']=='virgl-standard-dimensional-view-commands-v1'
        assert result['commands'][0]['fields']=={'handle':51,'resourceHandle':6,'format':row['input']['format'],'target':2,'firstLayer':0,'lastLayer':0,'firstLevel':0,'lastLevel':0,'swizzle':[0,1,2,3]}
    if name.startswith('selected-view/'):
        w=row['input']['words'];p=w[1:];target=p[2]>>24;layers=p[3];levels=p[4];swizzle=p[5]
        expected=dict(handle=p[0],resourceHandle=p[1],format=p[2]&0xffffff,target=target,firstLayer=layers&65535,lastLayer=layers>>16,firstLevel=levels&255,lastLevel=levels>>8,swizzle=[(swizzle>>(3*k))&7 for k in range(4)])
        assert result['commands'][0]['fields']==expected and result['profile']=='virgl-standard-dimensional-view-commands-v1'
    checks.append({'row':i,'name':name,'resultSha256':sha(json.dumps(result,sort_keys=True).encode()),'ok':result.get('ok')})
owners=[]
for directory in [root/'attacks',dest/'fresh-attacks-3141592653']:
    report=json.loads((directory/'report.json').read_bytes());groups=report['browserResult']['result']['ownerAttacks'];assert len(groups)==3
    for i,r in enumerate(groups):
        assert r['status']=='passed' and r['caller']['scissor']and r['caller']['box']==[1,2,3,4]
        target=r['name'].split('/')[1];wanted=36 if target=='3D'else 120 if target=='CUBE'else 60;original=292 if target=='3D'else 504 if target=='CUBE'else 420
        md=r['metadata'];assert md['byteLength']==md['gpuByteLength']==wanted and md['lastLevel']==1 and md['width']==md['height']==2
        assert md['depth']==(2 if target=='3D'else 1) and md['arraySize']==(1 if target=='3D'else 6 if target=='CUBE'else 3)
        assert r['before']['budgets']['gpuBytes']==original+wanted and r['after']['budgets']['gpuBytes']==original
        assert r['after']['budgets']['leases']==r['after']['budgets']['imageViews']==r['after']['budgets']['imageHolds']==0
        assert all(v==0 for v in r['cleaned']['budgets'].values()) and r['cleaned']['disposed']is True
        assert [v['error']['code']for v in r['refusals']]==['backend-error','out-of-bounds','out-of-bounds','out-of-bounds','backend-error','backend-error','backend-error']
        fbo={36008:None,36009:None};scissor=False;box=None;live=set();state_checks=[];status_faults=[];blits=0
        encode=lambda v:v.get('handle')if isinstance(v,dict)else v
        for event in r['calls']:
            name=event['name'];a=event['args'];seq=event['sequence']
            if name=='createFramebuffer'and 'actual'in event and event['actual']:live.add(encode(event['actual']))
            if name=='deleteFramebuffer':assert encode(a[0])in live;live.remove(encode(a[0]))
            if name=='bindFramebuffer':
                for t in [36008,36009]if a[0]==36160 else[a[0]]:fbo[t]=encode(a[1])
            if name=='enable'and a[0]==3089:scissor=True
            if name=='disable'and a[0]==3089:scissor=False
            if name=='scissor':box=a
            if name=='getParameter'and a[0]in [36010,36006]:
                expected=fbo[36008 if a[0]==36010 else 36009];assert encode(event['actual'])==expected
                if expected in [encode(r['caller']['read']),encode(r['caller']['draw'])]:state_checks.append(seq)
            if name=='getParameter'and a[0]==3088:
                observed=event['actual'];assert observed['type']=='Int32Array'
                assert list(struct.unpack('<4i',bytes(observed['bytes'])))==box
            if name=='isEnabled'and a[0]==3089:assert event['actual']==scissor
            if name=='checkFramebufferStatus'and event.get('injected')=='incomplete-native-status':status_faults.append(seq);assert event['actual']==36053
            if name=='blitFramebuffer':blits+=1;assert a[8:]==[16384,9728]
        assert not live and len(status_faults)==2 and len(state_checks)>=20 and blits>0
        owners.append({'record':str(directory/'report.json'),'reportSha256':sha((directory/'report.json').read_bytes()),'ownerIndex':i,'name':r['name'],'privateBytes':wanted,'originalBytes':original,'callerStateCheckCallSequences':state_checks,'actualStatusFaultSequences':status_faults,'blits':blits,'completeCleanup':True})
result={'schema':'E6-T11d58-fresh-boundary-contract-audit-v1','status':'passed','workerFacadeSha256':sha(raw),'freshFacadeSha256':sha(fresh_raw),'completeContracts':len(rows),'completeHeldCompilerBodies':len(held),'completeHeldDecoderResponses':len(historic),'completePairInterfaces':247,'accessorOrCoercionTraps':facade['traps'],'rowCitations':checks,'heldCompilerResponses':held,'ownerRecords':owners}
(dest/'boundary-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['rowCitations','heldCompilerResponses','ownerRecords']}))
