#!/usr/bin/env python3
"""Lossless reproducible critic evidence seal, with optional16MiB Git parts."""
import gzip,hashlib,json,pathlib,tarfile
dest=pathlib.Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
ignored={'manifest.json','records.json','recording.tar.gz','seal.log'}
files=sorted(p for p in dest.rglob('*')if p.is_file()and p.name not in ignored and not p.name.startswith('recording.tar.gz.part-')and '__pycache__'not in p.parts and p.name!='.DS_Store')
records=[{'path':p.relative_to(dest).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in files]
index=(json.dumps({'schema':'E6-T11d58-critic-body-index-v1','records':records},indent=2)+'\n').encode();(dest/'records.json').write_bytes(index)
archive=dest/'recording.tar.gz'
with archive.open('wb')as file,gzip.GzipFile(filename='',mode='wb',fileobj=file,mtime=0,compresslevel=9)as zipped,tarfile.open(fileobj=zipped,mode='w',format=tarfile.PAX_FORMAT)as tar:
 for p,row in zip(files,records):
    raw=p.read_bytes();assert len(raw)==row['bytes']and sha(raw)==row['sha256']
    info=tarfile.TarInfo(row['path']);info.size=len(raw);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
    import io
    tar.addfile(info,io.BytesIO(raw))
reopened=0
with tarfile.open(archive,'r|gz')as tar:
 for member in tar:
    row=records[reopened];raw=tar.extractfile(member).read();assert member.name==row['path']and len(raw)==row['bytes']and sha(raw)==row['sha256'];reopened+=1
assert reopened==len(records)
body=archive.read_bytes();parts=[]
if len(body)>100*1024*1024:
 for i,at in enumerate(range(0,len(body),16*1024*1024)):
    name='recording.tar.gz.part-'+str(i).zfill(4);raw=body[at:at+16*1024*1024];(dest/name).write_bytes(raw);parts.append({'path':name,'bytes':len(raw),'sha256':sha(raw)})
manifest={'schema':'E6-T11d58-fresh-critic-seal-v1','task':'E6-T11d58','verdict':'verified','head':'1c7f8c9b4e52e09e8f6e2201f92d7483ce7117a6','submission':'75f5815d0f290e92cdb77239b78facf93ca6fbbc','base':'deb7b3113f9adeb2e6e80449a6710dd3295093ea','archiveBytes':len(body),'archiveSha256':sha(body),'recordIndexSha256':sha(index),'members':len(records),'reopenedMembers':reopened,'uncompressedBytes':sum(r['bytes']for r in records),'parts':parts,'predictionsSha256':sha((dest/'predictions.json').read_bytes()),'verdictSha256':sha((dest/'verdict.json').read_bytes()),'workerManifestSha256':'366968fe114438560886832570b9c36b1ffe4e3d7526cf718fba6b6dc9a47b2c','workerArchiveSha256':'fb56c37995c361bece8bbe14f6ec5606580741affbb8c76a9469e6c6a231cdf5','deploymentManifestSha256':'9e91426d13b700e5b078510221e9236121f66d33b8af1450ce556feea43f84ec','deploymentArchiveSha256':'5054f169b23d2a8dcda3cd29d9bfc5708a7a05f43a54fc3af0057a0cc4a307c8','scope':'Explicitly selected original RGBA8 dimensional sampler-view consumer; no actual Linux guest/capset/API-completeness/production/MIPS authority','preservedRaw':str(dest),'preservedWorkerRaw':'/tmp/wasmvm-dimensional-views-cold-1c7f8c9b/recording'}
raw=(json.dumps(manifest,indent=2)+'\n').encode();(dest/'manifest.json').write_bytes(raw)
print(json.dumps({'manifestSha256':sha(raw),'indexSha256':sha(index),'archiveSha256':sha(body),'archiveBytes':len(body),'members':len(records),'parts':parts}))
