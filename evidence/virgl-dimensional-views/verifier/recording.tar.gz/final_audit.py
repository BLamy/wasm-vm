#!/usr/bin/env python3
"""Authenticate the fresh browser source closures and final immutable boundary."""
import hashlib,json,pathlib,subprocess
dest=pathlib.Path(__file__).resolve().parent;repo=dest.parents[2]
frozen='1c7f8c9b4e52e09e8f6e2201f92d7483ce7117a6';submission='75f5815d0f290e92cdb77239b78facf93ca6fbbc'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
assert git('rev-parse','HEAD').decode().strip()==submission
receipt=json.loads(pathlib.Path('/tmp/wasmvm-dimensional-views-cold-1c7f8c9b/recording/receipt.json').read_bytes())
submission_only={'tasks/epic-6-transcendence/E6-T11d58-dimensional-sampler-views.md','tasks/QUEUE.md','tools/virgl-dimensional-views/seal.py'}
for name,pin in receipt['sources'].items():
    old=git('show',frozen+':'+name);assert len(old)==pin['bytes'] and sha(old)==pin['sha256'],name
    raw=(repo/name).read_bytes();assert raw==git('show',(submission if name in submission_only else frozen)+':'+name),name
for name,pin in receipt['generated'].items():
    raw=(repo/name).read_bytes();assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256'],name
reports=[];source_count=0
alias='renderer/virgl-command/tests/native-dimensional-views.mjs';harness=(repo/alias).read_text()
assert sha(harness.encode())=='f6958d91ad90a7551dc08803dbcc69e8ccb4e0bcb51db2ffb816589c1f0d6526'
start=harness.index('  let fixtures=sharing?');end=harness.index('  try{\n    c.truth(fixtures.length>0',start)
novel=harness[:start]+'  const {novelCase}=await import("../../../tools/virgl-dimensional-views/critic-case.mjs");let fixtures=[novelCase()];\n'+harness[end:]
call="await originalPlane(rig,f,c,row,memory,'physically-wrong-layer');"
assert novel.count(call)==1
novel=novel.replace(call,"await originalPlane(rig,f,c,row,memory,'physically-wrong-layer',f.expectedPlane??expected(f));")
names=['fresh-attacks-3141592653','fresh-boundaries-2718281829','novel-corrected-3141592653-2718281829','novel-sabotage-corrected-3141592653']
for name in names:
    directory=dest/name;raw=(directory/'report.json').read_bytes();report=json.loads(raw)
    assert report['head']==submission and report['trackedChanges']=='' and report['task']=='E6-T11d58'
    assert report['browserErrors']=={'console':[],'page':[],'requests':[]}
    assert report['browser']['headless']is False
    features=report['browser']['gpu']['featureStatus'];assert features.get('webgl2',features.get('webgl'))=='enabled'
    assert 'Apple M4 Max' in report['browser']['gpu']['auxAttributes']['glRenderer']and 'Metal'in report['browser']['gpu']['auxAttributes']['glRenderer']
    assert not report['actualLinuxGuest']and not report['productionAuthority']
    assert report['status']==('failed'if 'sabotage'in name else 'passed')
    sources=[]
    for pin in report['sources']:
        file=pin['path'];body=(directory/'source'/file).read_bytes()
        assert len(body)==pin['bytes'] and sha(body)==pin['sha256'],(name,file)
        expected=novel.encode()if file==alias and 'novel'in name else (repo/file).read_bytes()
        assert body==expected,(name,file)
        sources.append({'source':file,'sha256':pin['sha256'],'bytes':pin['bytes'],'alias':file==alias and 'novel'in name});source_count+=1
    coverage=(directory/report['browserCoverage']['path']).read_bytes();assert sha(coverage)==report['browserCoverage']['sha256']
    screenshot=(directory/report['screenshot']['path']).read_bytes();assert sha(screenshot)==report['screenshot']['sha256']
    served={p['path']:p for p in report['servedFiles']}
    for pin in sources:
        key='/'+pin['source']
        if key in served:assert served[key]['sha256']==pin['sha256'] and served[key]['bytes']==pin['bytes']
    reports.append({'record':name+'/report.json','sha256':sha(raw),'status':report['status'],'sources':sources,'actualHeadedMetal':True})
assert not git('diff','--name-only',submission,'--','renderer','web','crates','Cargo.lock','Cargo.toml','AGENTS.md','Makefile')
result={'schema':'E6-T11d58-fresh-final-custody-v1','status':'passed','frozenHead':frozen,'submission':submission,'frozenSourcePins':len(receipt['sources']),'frozenSourcesUnchanged':len(receipt['sources'])-len(submission_only),'submissionOnlyExceptions':sorted(submission_only),'generatedUnchanged':len(receipt['generated']),'freshSources':source_count,'originalHarnessUnchanged':sha(harness.encode()),'novelAliasSha256':sha(novel.encode()),'reports':reports,'promotedSources':{name:sha((repo/name).read_bytes())for name in ['tools/virgl-dimensional-views/critic-case.mjs','tools/virgl-dimensional-views/critic-browser.mjs']}}
(dest/'final-custody.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k!='reports'}))
