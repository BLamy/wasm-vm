#!/usr/bin/env python3
"""Authenticate staged, frozen, HTTP and predecessor deployment bytes."""
import hashlib,io,json,pathlib,subprocess,tarfile
repo=pathlib.Path(__file__).resolve().parents[3];dest=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest();base='deb7b3113f9adeb2e6e80449a6710dd3295093ea';frozen='1c7f8c9b4e52e09e8f6e2201f92d7483ce7117a6'
def reopen(family,manifest_pin):
    d=repo/'evidence'/family;mraw=(d/'manifest.json').read_bytes();assert sha(mraw)==manifest_pin
    m=json.loads(mraw);iraw=(d/'records.json').read_bytes();idx=json.loads(iraw);pins=idx['records']if isinstance(idx,dict)else idx
    assert sha(iraw)==m['recordIndexSha256'] and sha((d/'recording.tar.gz').read_bytes())==m['archiveSha256']
    bodies={}
    with tarfile.open(d/'recording.tar.gz','r|gz') as tar:
        for member,pin in zip(tar,pins):
            assert member.name==pin['path'] and member.isfile();raw=tar.extractfile(member).read();assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256'];bodies[member.name]=raw
    assert len(bodies)==len(pins)
    return m,bodies
old_m,old=reopen('virgl-dimensional-shaders/deployment','f852585081506fe1e0c97417da06ea2cd3435d484e0d5d2f15cb81bf404fa650')
assert (repo/'evidence/virgl-dimensional-shaders/deployment/manifest.json').read_bytes()==subprocess.check_output(['git','show',base+':evidence/virgl-dimensional-shaders/deployment/manifest.json'],cwd=repo)
m,bodies=reopen('virgl-dimensional-views/deployment','9e91426d13b700e5b078510221e9236121f66d33b8af1450ce556feea43f84ec')
staging=json.loads(bodies['publication/staging-index.json']);prior=json.loads(old['publication/staging-index.json']);assert sha(old['publication/staging-index.json'])==staging['heldIndexSha256']
assert staging['head']==frozen and staging['heldDeployment']==prior['head']
index={p['path']:p for p in staging['records']};oldindex={p['path']:p for p in prior['records']};assert len(index)==304 and set(index)==set(oldindex)
changes=[];maxfile=0;total=0
for name,pin in index.items():
    raw=bodies['publication/web/dist/'+name];assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256'] and len(raw)<25*1024*1024
    if pin!=oldindex[name]:changes.append(name)
    total+=len(raw);maxfile=max(maxfile,len(raw))
assert changes==staging['codeChanges']==['roadmap.js','sw.js'] and total==staging['bytes']
archive=bodies['publication/frozen-web-dist.tar'];assert sha(archive)==staging['sourceArchiveSha256']
assert archive==subprocess.check_output(['git','archive',frozen,'web/dist'],cwd=repo)
frozen_bodies={}
with tarfile.open(fileobj=io.BytesIO(archive))as tar:
    for member in tar:
        if member.isfile():frozen_bodies[member.name.removeprefix('web/dist/')]=tar.extractfile(member).read()
manifests={p['path']:p for p in staging['carriedBootManifests']}
for name,raw in frozen_bodies.items():
    staged=bodies['publication/web/dist/'+name]
    if name in manifests:assert sha(raw)==manifests[name]['sourceSha256'] and sha(staged)==manifests[name]['stagedSha256'] and index[name]==oldindex[name]
    else:assert raw==staged
live=json.loads(bodies['live/report.json']);assert live['gitHead']==frozen and live['status']=='passed' and live['passed']==127 and live['failed']==0 and live['errors']==live['httpErrors']==[]
assert live['proofExportAbsent']is True and live['roadmapPip']=='cap-pip live' and live['graphicsRoadmapPip']=='cap-pip partial'
http=[]
for pin in live['served']:
    name=pin['path'];raw=bodies['live/bodies/'+(name.lstrip('/') or 'index.html')]
    assert len(raw)==pin['bytes']and sha(raw)==pin['sha256']
    target='app.html' if name=='/app' else name.lstrip('/') or 'index.html'
    assert raw==bodies['publication/web/dist/'+target],('HTTP-staging-drift',target)
    http.append({'path':name,'stagingPath':target,'sha256':pin['sha256'],'bytes':len(raw)})
wasm=bodies['publication/web/dist/pkg/wasm_vm_wasm_bg.wasm'];assert sha(wasm)==live['servedWasmSha256']
roadmap=bodies['publication/web/dist/roadmap.js'];assert b'E6-T11d58' in roadmap and b'production acceleration disabled' in roadmap and b'name: "Guest GPU offload", status: "partial"' in roadmap
assert b'WasmVirglSubmitProof'not in bodies['publication/web/dist/pkg/wasm_vm_wasm.js']
assert sha(bodies['live/browser.png'])==live['screenshot']['sha256']
cloud=json.loads(bodies['publication/cloudflare-success.json']);assert cloud['success'] is True
deployed=cloud['result'];assert deployed['id']=='e7b44bfe-632e-401f-a61a-df033112f26a' and deployed['environment']=='production' and deployed['latest_stage']['status']=='success' and deployed['deployment_trigger']['metadata']['commit_hash']==frozen
publish=json.loads(bodies['publication/publish.json']);assert publish['exitCode']==0 and publish['head']==frozen
assert sha(bodies['publication/publish.stdout'])==publish['stdoutSha256'] and sha(bodies['publication/publish.stderr'])==publish['stderrSha256']
local_dir=pathlib.Path('/tmp/wasmvm-dimensional-views-cold-1c7f8c9b/recording/default-demo');local=json.loads((local_dir/'report.json').read_bytes())
assert local['gitHead']==frozen and local['status']=='passed' and local['passed']==127 and local['failed']==0 and local['errors']==[] and local['proofExportAbsent']is True
assert local['graphicsRoadmapPip']=='cap-pip partial' and local['roadmapPip']=='cap-pip live' and sha((local_dir/'browser.png').read_bytes())==local['screenshot']['sha256']
result={'schema':'E6-T11d58-fresh-deployment-audit-v1','status':'passed','frozenHead':frozen,'deploymentMembersReopened':len(bodies),'heldDeploymentMembersReopened':len(old),'heldDeploymentManifestSha256':'f852585081506fe1e0c97417da06ea2cd3435d484e0d5d2f15cb81bf404fa650','stagingFiles':len(index),'stagingBytes':total,'maximumFileBytes':maxfile,'changedCodeBodies':changes,'sourceArchiveSha256':sha(archive),'completeHttpBodies':http,'wasmSha256':sha(wasm),'roadmapSha256':sha(roadmap),'liveScreenshotSha256':live['screenshot']['sha256'],'defaultScreenshotSha256':local['screenshot']['sha256'],'deploymentId':deployed['id'],'latestStage':deployed['latest_stage'],'localAndCanonical':{'passed':127,'failed':0,'errors':[],'proofExportAbsent':True,'graphicsRoadmapPip':'partial','productionGraphicsAuthority':False}}
(dest/'deployment-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='completeHttpBodies'}))
