#!/usr/bin/env python3
"""Preserve pre-inspection predictions and attach full falsifiable citations."""
import gzip,hashlib,json,pathlib
dest=pathlib.Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(dest/'predictions.json').read_bytes();assert sha(raw)=='a188b5bab782efdce59125f0a49343bf9e337af05b05a6f7958ccc0322a64978'
predictions=json.loads(raw);assert all(p['status']=='UNINSPECTED'for p in predictions['predictions'])
files=['authentication.json','recording-interrogation.json','recording-interrogation.jsonl','verifier-interrogation.json','verifier-interrogation.jsonl','boundary-audit.json','coverage-audit.json','deployment-audit.json','final-custody.json','novel-prediction.json','recording-corrections.json']
digests={name:sha((dest/name).read_bytes())for name in files}
refreshes=[]
for log,root in [('recording-interrogation.jsonl',pathlib.Path('/tmp/wasmvm-dimensional-views-cold-1c7f8c9b/recording')),('verifier-interrogation.jsonl',dest)]:
 for line,text in enumerate((dest/log).read_text().splitlines(),1):
    entry=json.loads(text)
    if not any(p['label']=='GPU-only-source-refresh'for p in entry['planes']):continue
    raw=gzip.decompress((root/entry['record']).read_bytes());assert sha(raw)==entry['bodySha256'];body=json.loads(raw)
    first=entry['planes'][0]['nativeDrawSequence'];later=[c for c in body['nativeCalls']if c['sequence']>first]
    assert body['gpuOnlyWrites']and not any(c['name'].startswith('texSubImage')for c in later)
    refreshes.append({'record':entry['record'],'bodySha256':entry['bodySha256'],'citation':log+':'+str(line),'afterBaselineDraw':first,'nativeCallsAfterBaseline':len(later),'newCpuTextureUploads':0,'originalGpuWrites':body['gpuOnlyWrites'],'completeRefreshedOutput':next(p['outputSha256']for p in entry['planes']if p['label']=='GPU-only-source-refresh')})
assert len(refreshes)==12
(dest/'gpu-refresh-audit.jsonl').write_text(''.join(json.dumps(r,sort_keys=True)+'\n'for r in refreshes))
digests['gpu-refresh-audit.jsonl']=sha((dest/'gpu-refresh-audit.jsonl').read_bytes())
observations=[
 'All2327 worker and512 deployment members, plus53318 dependency members, fully reopened. Frozen receipt has31 expected exits; three hardware heads exactly1c7f8c9b. Only sealer authentication guard changed from the stale single report to all three seed reports.',
 '794 complete facade rows,54 exact held compiler bodies,76 exact historical decoder responses,247 independent pair interfaces and all selected original view fields held. Recorded accessor/coercion count0; revoked proxies and extra/hole/typed/malformed records refuse.129 worker and43 fresh attack bodies refuse before native draw, then recover.',
 'Independent original-byte algebra held926 complete planes/58656 words, all RAM SG guards and padding.936 fractional written float lanes used abs1/255; maximum observed error0.00012254714965820312. All other lanes remained exact.',
 'Actual sampler3D/Cube/2DArray reflection and GL texture dimensions held. Sparse stage units remain slot and16+slot;18 worker sharing cases and two fresh same-allocation NPOT slot15 cases hold distinct mip/layer ranges and swizzles.',
 'Actual source/destination framebuffer attachments and native blits match original/local mip/layer extents. GPU-only refreshes contain no new CPU texture uploads. Six full native owner records preserve caller state, exact budgets and failure cleanup; full ranges retain source storage.',
 'Actual Wasm request/response/descriptor/avail/used/canonical/trace bodies, distinct real draw/PBO fences, native signal, owned synchronization retirement and RAM publication ordering held. Nine worker and three fresh generation/cancellation sequences held. Reset trace clearing is unchanged and explicitly cited.',
 'Worker baseline then completed wrong-layer plane1 word0 expected1065353216 observed0. Fresh two-schedule NPOT7-layer slot15 novel positives held. Fresh physically wrong source-layer run completed and test failed at plane1 word1 expected0 observed1065353216, exactly the pre-written prediction.',
 '913 finest V8 partitions audited:851 positive execution,61 HELD unchanged operands,one static waiver andzero new executable gaps. All61 historical counters arezero and are never counted as new execution. Exact old/new source offsets and governing raw counters retained.',
 'One final pristine scrubbed clone is authentic and still clean at frozen1c7f8c9b.589 frozen source pins,638 held dependency pins andsix generated bodies are exact. Fresh source closures retain unchanged runtime and original harness; only critic acceptance alias selects the promoted novel packet and forwards its same oracle to sabotage.',
 'All512 deployment and204 prior deployment bodies reopened.304 staged files match authenticated tree; only roadmap.js/sw.js code bodies change.194 live HTTP bodies match frozen staged bodies. Local/canonical127/0/errors0, no proof exports,partial pip andno production graphics authority.'
]
citations=[
 ['authentication.json:63','authentication.json:67','final-custody.json:1'],
 ['boundary-audit.json:6','recording-interrogation.jsonl:1','verifier-interrogation.jsonl:1'],
 ['recording-interrogation.json:7','recording-interrogation.json:23','recording-interrogation.jsonl:628'],
 ['recording-interrogation.jsonl:881','verifier-interrogation.jsonl:47','verifier-interrogation.jsonl:48'],
 ['recording-interrogation.jsonl:628','boundary-audit.json:5157','gpu-refresh-audit.jsonl:1'],
 ['recording-interrogation.jsonl:130','verifier-interrogation.jsonl:44','crates/core/src/dev/virtio/gpu/mod.rs:593'],
 ['recording-interrogation.jsonl:139','verifier-interrogation.jsonl:49','novel-prediction.json:1'],
 ['coverage-audit.json:252','coverage-audit.json:254','coverage-audit.json:257','held-citations.jsonl:1'],
 ['authentication.json:64','authentication.json:65','final-custody.json:1'],
 ['deployment-audit.json:5','deployment-audit.json:16','deployment-audit.json:1193']
]
coverage=json.loads((dest/'coverage-audit.json').read_bytes());held=[p for p in coverage['partitions']if p['classification']=='HELD'];assert len(held)==61
with (dest/'held-citations.jsonl').open('w')as out:
 for p in held:
    assert not any(c['count']for c in p['historicalCounters'])
    out.write(json.dumps({**p,'carriedByAuthenticatedDependencyBoundary':True,'newExecutedCoverage':False},sort_keys=True)+'\n')
digests['held-citations.jsonl']=sha((dest/'held-citations.jsonl').read_bytes())
result={'schema':'E6-T11d58-fresh-verdict-v1','verdict':'verified','scope':'Explicitly selected original RGBA8 dimensional sampler-view consumer only','actualLinuxGuest':False,'capsetAuthority':False,'productionAuthority':False,'mipsAuthority':False,'verifiedBase':predictions['base'],'frozenHead':predictions['frozenHead'],'submission':predictions['submission'],'predictionsWrittenBeforeEvidenceSha256':sha(raw),'predictions':[{**p,'status':'HELD','observation':o,'citations':c,'demand':'None within the selected task boundary.'}for p,o,c in zip(predictions['predictions'],observations,citations)],'FAILED':[],'NEEDS EVIDENCE':[],'auditDigests':digests,'suite':['tools/virgl-dimensional-views/critic-case.mjs','tools/virgl-dimensional-views/critic-browser.mjs'],'physicalSensitivity':{'record':'novel-sabotage-corrected-3141592653/run-0000.json.gz','bodySha256':'4570f90ba941d70000e43c157bd26c694dee7338bffe4619dfc0e0e0dc90b487','completedPlane':1,'word':1,'expected':0,'observed':1065353216,'requiredExit':1},'historicalZeroCounters':'All61 HELD historical operands remain unchanged exact-source dependencies; no positive/new execution authority.','workerSerializationNote':'Original151192332-byte archive is intact and above GitHub100MiB blob limit. Root will losslessly chunk only this unpublished artifact after leases release; that transport correction requires incremental authentication and does not alter this runtime verdict.'}
(dest/'verdict.json').write_text(json.dumps(result,indent=2)+'\n')
print('VERDICT: verified; ten HELD predictions; no FAILED/NEEDS EVIDENCE;'+str(len(held))+' historical zero operands retained as HELD.')
