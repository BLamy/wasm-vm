#!/usr/bin/env python3
"""Independent packet/RAM/native-call oracle; never imports worker pixel logic."""
import collections, gzip, hashlib, json, math, pathlib, re, struct, sys
dest=pathlib.Path(__file__).resolve().parent
root=pathlib.Path(sys.argv[1]).resolve() if len(sys.argv)>1 else pathlib.Path('/tmp/wasmvm-dimensional-views-cold-1c7f8c9b/recording')
selection=set(sys.argv[2].split(',')) if len(sys.argv)>2 else None
sha=lambda b:hashlib.sha256(b).hexdigest()
u32=lambda b,at=0:struct.unpack_from('<I',b,at)[0]
u16=lambda b,at=0:struct.unpack_from('<H',b,at)[0]
bits=lambda f:u32(struct.pack('<f',f))
fp=lambda w:struct.unpack('<f',struct.pack('<I',w))[0]
raw=lambda v:bytes.fromhex(v) if isinstance(v,str) else bytes(v)
handle=lambda v: v.get('handle') if isinstance(v,dict) else v
targets={'2D':2,'3D':3,'CUBE':4,'2D_ARRAY':7};native_targets={2:3553,3:32879,4:34067,7:35866};sampler_types={2:35678,3:35679,4:35680,7:36289}
def local(f,l):
    L=f['firstLevel']+l
    return max(1,f['width']//2**L),max(1,f['height']//2**L),max(1,f['depth']//2**L) if f['target']=='3D' else 6 if f['target']=='CUBE' else 1 if f['target']=='2D' else f['lastLayer']-f['firstLayer']+1
def wrapped(i,n,mode):
    if mode==2:return min(n-1,max(0,i))
    if mode==0:return i%n
    assert mode==4
    q=i%(2*n);return q if q<n else 2*n-1-q
def sample(f,c,L,uploads,overrides,fetch=False):
    w,h,n=local(f,L);u,v,z=c[:3];t=f['target'];layer=None
    if t=='CUBE':
        m=max(abs(i) for i in c[:3]);a=next(k for k in range(3) if abs(c[k])==m);layer=a*2+int(c[a]<0)
        sc,tc=((-c[2] if c[0]>0 else c[2]),-c[1]) if a==0 else (c[0],c[2] if c[1]>0 else -c[2]) if a==1 else (c[0] if c[2]>0 else -c[0],-c[1])
        u,v=(sc/m+1)/2,(tc/m+1)/2
    elif fetch:layer=z
    elif t!='3D':layer=min(n-1,max(0,math.floor(z+.5)))
    def at(x,y,z):
        sourceLayer=z+(f['firstLayer'] if t=='2D_ARRAY' else 0);original=f['firstLevel']+L
        if (f['source']['id'],original,sourceLayer) in overrides:return overrides[f['source']['id'],original,sourceLayer]
        p=uploads[f['source']['id'],original];assert 0<=x<p['width'] and 0<=y<p['height'] and 0<=sourceLayer<p['layers']
        start=((sourceLayer*p['height']+y)*p['width']+x)*4
        return [b/255 for b in p['body'][start:start+4]]
    if fetch:return at(c[0],c[1],layer)
    if not f.get('linear'):
        return at(wrapped(math.floor(u*w),w,f['wrap']),wrapped(math.floor(v*h),h,f['wrap']),layer if layer is not None else wrapped(math.floor(z*n),n,f['wrap']))
    axes=[u*w-.5,v*h-.5]+([z*n-.5] if layer is None else [])
    integer=[math.floor(x) for x in axes];fraction=[x-a for x,a in zip(axes,integer)];answer=[0.]*4
    for dz in range(2 if layer is None else 1):
        for dy in range(2):
            for dx in range(2):
                texel=at(wrapped(integer[0]+dx,w,2 if t=='CUBE' else f['wrap']),wrapped(integer[1]+dy,h,2 if t=='CUBE' else f['wrap']),layer if layer is not None else wrapped(integer[2]+dz,n,f['wrap']))
                weight=(fraction[0] if dx else 1-fraction[0])*(fraction[1] if dy else 1-fraction[1])*((fraction[2] if dz else 1-fraction[2]) if layer is None else 1)
                for k in range(4):answer[k]+=texel[k]*weight
    return answer
def words(f,x,y,uploads,overrides):
    if f.get('literalOracle'):
        result=[]
        for view,stage in [(f,'fragment'),(f['extraViews'][0]['fixture'],'vertex')]:
            text=f['fragmentText'] if stage=='fragment' else f['vertexText'];m=re.search(r'IMM\[0\] FLT32 \{([^}]+)\}',text);assert m
            c=list(map(float,m[1].split(',')));L=min(view['lastLevel']-view['firstLevel'],max(0,c[3]));value=sample(view,c,int(L),uploads,overrides)
            result.append([bits(0 if a==4 else 1 if a==5 else value[a]) for a in view['swizzle']])
        return [a^b for a,b in zip(*result)]
    op=f['opcode'];mask=f.get('mask','xyzw');sentinel=[0x12345678,0x80000001,0xdeadbeef,0xffffffff]
    if op=='TXQ':
        w,h,n=local(f,y);value=[w,h,0 if f['target'] in ['CUBE','2D'] else n,f['lastLevel']-f['firstLevel']+1]
    else:
        c=list(struct.unpack_from('<4I' if op=='TXF' else '<4f',raw(f['inputs'][1]),(y*f['grid']['width']+x)*16)) if not f.get('biasProbe') else [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]][f.get('face',0)]+[8] if f['target']=='CUBE' else [.5,.5,.875 if f['target']=='3D' else local(f,0)[2]-1,8]
        source=f.get('sourceExpression') or ''
        if source.endswith('wzyx'):c.reverse()
        if source.startswith('|'):c=[abs(v) for v in c]
        if source.startswith('-|'):c=[-abs(v) for v in c]
        if op=='TXP':c=[v/c[3] if i<3 else v for i,v in enumerate(c)]
        L=c[3] if op in ['TXL','TXF'] else f['lastLevel']-f['firstLevel'] if f.get('biasProbe') else 0
        if op=='TXD':
            dx=struct.unpack_from('<4f',raw(f['inputs'][2]),(y*f['grid']['width']+x)*16);dy=struct.unpack_from('<4f',raw(f['inputs'][3]),(y*f['grid']['width']+x)*16);w,h,n=local(f,0)
            if f['target']=='CUBE':rho=max(math.sqrt(sum(z*z for z in d[:3]))*w/2 for d in [dx,dy])
            else:rho=max(math.sqrt(sum((a*b)**2 for a,b in zip(d,[w,h,n] if f['target']=='3D' else [w,h]))) for d in [dx,dy])
            L=math.log2(rho)
        if op!='TXF':L=min(f['lastLevel']-f['firstLevel'],max(0,min(f['maxLod'],max(f['minLod'],L))))
        low=math.floor(L) if f.get('linear') else math.floor(L+.5);fraction=L-low if f.get('linear') else 0
        a=sample(f,c,low,uploads,overrides,op=='TXF');b=sample(f,c,low+1,uploads,overrides) if fraction else a
        values=[a[k]*(1-fraction)+b[k]*fraction for k in range(4)];value=[bits(0 if k==4 else 1 if k==5 else values[k])for k in f['swizzle']]
    return [value[k] if 'xyzw'[k] in mask else sentinel[k] for k in range(4)]
results=[];categories=collections.Counter();refusals=collections.Counter();completed_corruptions=[];totals=collections.Counter();maximum_error=0.
out=root.name+'-interrogation.jsonl'
with (dest/out).open('w') as log:
 for directory in sorted(root.iterdir()):
    if selection is not None and directory.name not in selection:continue
    if not directory.is_dir() or not (directory/'report.json').is_file():continue
    report=json.loads((directory/'report.json').read_bytes())
    if report.get('task')!='E6-T11d58' or 'runs' not in report:continue
    negative=report['status']=='failed';assert report['browserErrors']=={'console':[],'page':[],'requests':[]}
    for index,pin in enumerate(report['runs']):
        compressed=(directory/pin['path']).read_bytes();body=gzip.decompress(compressed);assert sha(body)==pin['sha256'] and sha(compressed)==pin['gzipSha256'] and len(body)==pin['bytes'];r=json.loads(body);f=r['fixture']
        assert r['cleaned']['liveObjects']==r['cleaned']['liveSyncs']==0
        uploads={}
        for p in r['sourcePlanes']:
            b=raw(p['input']);assert len(b)==p['width']*p['height']*p['layers']*4;p={**p,'body':b};uploads[p['resource'],p['level']]=p
            backing=bytearray([0x8d]*4096);stride=p['width']*4+7;layerStride=stride*p['height']+11
            for z in range(p['layers']):
                for y in range(p['height']):
                    start=((z*p['height']+y)*p['width'])*4;part=b[start:start+p['width']*4];backing[5+z*layerStride+y*stride:5+z*layerStride+y*stride+len(part)]=part
                    for x in range(p['width']):
                        for k in range(4):assert part[x*4+k]==255*((5*p['level']+3*z+7*x+11*y)//2**k%2)
            assert raw(p['backing'])==backing
            assert any(e['kind'] in ['input','layered-input'] and raw(e['bytes'])==b for e in r['exchanges'])
            totals['sourceBytes']+=len(b)
        for record_index,v in enumerate(r['records']):
            req=raw(v['request']);res=raw(v['response']);ring=v['ring'];assert v['usedIndex']==record_index+1
            assert sha(raw(v['transportCanonical']))==v['transportDigest'] and sha(raw(v['submitCanonical']))==v['submitDigest']
            assert res[4:24]==req[4:24] and len(res)==24
            assert u16(raw(ring['used']),2)==record_index+1 and u16(raw(ring['avail']),2)==record_index+1
            assert struct.unpack_from('<II',raw(ring['used']),4+record_index*8)==(record_index*2,24)
        assert r['commandTrace']['dropped']=='0000000000000000';traces=r['commandTrace']['records'];assert re.fullmatch('[0-9a-f]{64}',r['machineDigest'])
        # The unchanged device reset clears its command ring. The complete
        # pre-reset literal requests/responses/canonical digests remain above.
        assert (not traces) if 'cancelled' in r else len(traces)==len(r['records'])
        for trace,v in zip(traces,r['records']):assert (trace['commandType'],trace['responseType'],trace['usedIndex'])==(u32(raw(v['request'])),u32(raw(v['response'])),v['usedIndex'])
        if 'cancelled' in r:assert not r['cancelled']['host']['resources'] and not r['cancelled']['native']['resources'] and r['cancelled']['native']['epoch']=='0000000000000002'
        for refusal in r.get('refusals',[]):
            assert u32(raw(refusal['result']['response'])) in [0x1205,0x1201]
            assert refusal['host']['renderer']['work']['drawCalls']==0
            refusals[refusal['label']]+=1
        syncs={};lastturn={};signals=0
        for ev in r['physical']:
            if ev['name']=='fenceSync':assert ev['sync'] not in syncs;syncs[ev['sync']]={'turn':ev['turn'],'actual':False,'delivered':False}
            elif ev['name']=='clientWaitSync':
                s=syncs[ev['sync']];assert ev['turn']>s['turn'] and ev['turn']!=lastturn.get(ev['sync']);lastturn[ev['sync']]=ev['turn']
                assert ev['delivered'] not in [37146,37148] or ev['actual'] in [37146,37148]
                s['actual']|=ev['actual'] in [37146,37148];s['delivered']|=ev['delivered'] in [37146,37148]
            elif ev['name']=='getBufferSubData':assert syncs[ev['sync']]['actual'] and syncs[ev['sync']]['delivered'];signals+=1
            elif ev['name']=='deleteSync':assert ev['object'] in syncs;del syncs[ev['object']]
        assert not syncs
        assert not any(v['name']=='finish' for v in r['nativeCalls'])
        # Replay actual native binding/attachment state, including delivered sabotage.
        resource_targets={v['source']['id']:native_targets[targets[v['target']]] for v in [f]+f.get('extraTextures',[])}
        active=33984;bindings={};storage={};upload_handles={};fbo_bind={36008:None,36009:None};attachments={};blits=[];draws=[]
        for event in r['nativeCalls']:
            name=event['name'];a=event.get('delivered',event['arguments']);seq=event['sequence']
            if name=='activeTexture':active=a[0]
            elif name=='bindTexture':bindings[active,a[0]]=handle(a[1])
            elif name in ['texStorage2D','texStorage3D']:
                storage[bindings[active,a[0]]]={'target':a[0],'levels':a[1],'internal':a[2],'width':a[3],'height':a[4],'layers':a[5] if len(a)>5 else 6 if a[0]==34067 else 1,'sequence':seq}
            elif name in ['texSubImage2D','texSubImage3D'] and isinstance(a[-1],dict) and 'bytes' in a[-1]:
                target=34067 if 34069<=a[0]<=34074 else a[0];texture=bindings[active,target];pixels=raw(a[-1]['bytes'])
                candidates=[]
                for key,p in uploads.items():
                    if key[1]!=a[1] or resource_targets[key[0]]!=target:continue
                    part=p['body'] if name=='texSubImage3D' or target!=34067 else p['body'][(a[0]-34069)*p['width']*p['height']*4:(a[0]-34068)*p['width']*p['height']*4]
                    if pixels==part:candidates.append(key[0])
                assert candidates,(r['name'],'native-upload-not-original',seq)
                if texture in upload_handles:assert upload_handles[texture] in candidates
                else:upload_handles[texture]=candidates[0]
            elif name=='bindFramebuffer':
                for t in ([36008,36009] if a[0]==36160 else [a[0]]):fbo_bind[t]=handle(a[1])
            elif name=='framebufferTextureLayer':attachments[fbo_bind[a[0]]]=(handle(a[2]),a[3],a[4],seq)
            elif name=='framebufferTexture2D':
                for t in ([36008,36009] if a[0]==36160 else [a[0]]):attachments[fbo_bind[t]]=(handle(a[3]),a[4],a[2]-34069 if 34069<=a[2]<=34074 else 0,seq)
            elif name=='blitFramebuffer':
                source=attachments[fbo_bind[36008]];destination=attachments[fbo_bind[36009]]
                if storage.get(source[0],{}).get('target') in [32879,34067,35866]:
                    assert a[8:]==[16384,9728];assert a[:4]==a[4:8]
                    blits.append({'sequence':seq,'source':source,'destination':destination,'rect':a[:4]})
            elif re.fullmatch('draw(?:Arrays|Elements)(?:Instanced)?',name):draws.append(seq)
        assert len(draws)==len(r['drawStates'])
        plane_results=[];previous_draw=-1
        for pi,plane in enumerate(r['planes']):
            overrides={(f['source']['id'],v['level'],v['layer']):v['value'] for v in r.get('gpuOnlyWrites',[])} if plane['label']=='GPU-only-source-refresh' else {}
            wanted=[n for y in range(f['grid']['height']) for x in range(f['grid']['width']) for n in words(f,x,y,uploads,overrides)]
            assert raw(plane['expected'])==struct.pack('<'+'I'*len(wanted),*wanted),(r['name'],plane['label'],'original-byte prediction')
            observed=raw(plane['observed']);assert len(observed)==len(wanted)*4;differences=[];filtered_count=0
            for i,b in enumerate(wanted):
                a=u32(observed,i*4);lane=i%4;filtered=f.get('linear') and f['opcode']!='TXQ' and 'xyzw'[lane] in f.get('mask','xyzw') and f['swizzle'][lane]<4 and 0<fp(b)<1
                if filtered:
                    error=abs(fp(a)-fp(b));assert math.isfinite(fp(a)) and error<=1/255;maximum_error=max(maximum_error,error);filtered_count+=1
                elif a!=b:differences.append({'word':i,'expected':b,'observed':a})
            if differences:assert negative and 'wrong-layer' in plane['label'] and r['faults'];completed_corruptions.append({'record':directory.name+'/'+pin['path'],'bodySha256':pin['sha256'],'plane':pi,'firstDifference':differences[0],'faults':r['faults']})
            elif negative:assert plane['label']=='original-dimensional-baseline'
            full=raw(plane['wholeBacking']);occupied={}
            for y in range(f['grid']['height']):
                start=5+y*(f['grid']['width']*16+3);part=observed[y*f['grid']['width']*16:(y+1)*f['grid']['width']*16]
                occupied.update({start+j:b for j,b in enumerate(part)})
            assert full==bytes(occupied.get(i,0xc7) for i in range(4096))
            assert all(v['before']==v['after']=='a3'*8 for v in plane['guards'])
            assert any(e['kind']=='output' and raw(e['bytes'])==observed and e['usedIndex']==plane['read']['usedIndex']-1 for e in plane['exchanges'])
            assert plane['before']['pending']['completionReady'] is False and plane['before']['pending']['fenceId']=='ffffffffffffffff'
            state=plane['native'];seq=state['sequence'];assert seq in draws
            copied=[]
            for sampler in state['state']['samplers']:
                vertex=sampler['name'].startswith('vs');slot=int(sampler['name'][6:]);v=f['extraViews'][0]['fixture'] if vertex and f.get('extraViews') else f
                assert sampler['unit']==slot+(16 if vertex else 0)
                assert sampler['type']==sampler_types[targets[v['target']]] and sampler['originalTarget']==targets[v['target']]
                assert sampler['base']==0 and sampler['last']==v['lastLevel']-v['firstLevel']
                p=sampler['parameters'];assert [p[k] for k in ['TEXTURE_WRAP_S','TEXTURE_WRAP_T','TEXTURE_WRAP_R']]==[{0:10497,2:33071,4:33648}[v['wrap']]]*3
                assert p['TEXTURE_COMPARE_MODE']==0 and p['TEXTURE_MIN_LOD']==v['minLod'] and p['TEXTURE_MAX_LOD']==v['maxLod']
                assert p['TEXTURE_MIN_FILTER']==(9987 if v.get('linear') else 9984) and p['TEXTURE_MAG_FILTER']==(9729 if v.get('linear') else 9728)
                hnd=handle(sampler['texture']);s=storage[hnd];w,h,n=local(v,0)
                assert (s['target'],s['width'],s['height'],s['layers'],s['levels'])==(native_targets[targets[v['target']]],w,h,n,v['lastLevel']-v['firstLevel']+1)
                private=v['firstLevel']!=0 or v['lastLevel']!=2 or v['target']=='2D_ARRAY' and (v['firstLayer']!=0 or v['lastLayer']!=v['arraySize']-1)
                if private and v['target']!='2D':
                    latest=[b for b in blits if previous_draw<b['sequence']<seq and b['destination'][0]==hnd]
                    for l in range(v['lastLevel']-v['firstLevel']+1):
                        ew,eh,en=local(v,l)
                        for layer in range(en):
                            b=next((b for b in latest if b['destination'][1:3]==(l,layer)),None);assert b is not None
                            originalLayer=layer+(v['firstLayer'] if v['target']=='2D_ARRAY' else 0)
                            if not differences:assert b['source'][1:3]==(v['firstLevel']+l,originalLayer)
                            assert b['rect']==[0,0,ew,eh];copied.append(b['sequence'])
            # Distinct real native fences after the actual draw and output PBO.
            after=[v for v in r['nativeCalls'] if v['sequence']>seq];fence=next(v for v in after if v['name']=='fenceSync')
            read=next(v for v in after if v['name']=='readPixels');read_fence=next(v for v in after if v['sequence']>read['sequence'] and v['name']=='fenceSync')
            collection=next(v for v in after if v['name']=='getBufferSubData')
            assert handle(fence['result'])!=handle(read_fence['result']) and fence['sequence']<read['sequence']<read_fence['sequence']<collection['sequence']
            for selected in [fence,read_fence]:assert any(v['name']=='deleteSync' and handle(v['arguments'][0])==handle(selected['result']) and selected['sequence']<v['sequence']<collection['sequence']+(1 if selected is fence else 20) for v in after)
            previous_draw=seq;totals['planes']+=1;totals['words']+=len(wanted);totals['filteredWords']+=filtered_count
            plane_results.append({'plane':pi,'label':plane['label'],'nativeDrawSequence':seq,'drawFenceSequence':fence['sequence'],'readbackFenceSequence':read_fence['sequence'],'collectionSequence':collection['sequence'],'words':len(wanted),'filteredWords':filtered_count,'copySequences':copied,'differences':differences[:1],'outputSha256':sha(observed)})
        entry={'record':directory.name+'/'+pin['path'],'bodySha256':pin['sha256'],'name':r['name'],'seed':r['seed'],'commands':len(r['records']),'nativeCalls':len(r['nativeCalls']),'fences':r['cleaned']['fences'],'planes':plane_results,'status':r['status'],'refusals':[x['label']for x in r.get('refusals',[])]}
        log.write(json.dumps(entry,sort_keys=True)+'\n');results.append(entry);categories[directory.name]+=1;totals['runs']+=1;totals['nativeCalls']+=len(r['nativeCalls']);totals['commands']+=len(r['records'])
    print(directory.name+': independently interrogated '+str(categories[directory.name])+' original runs',flush=True)
summary={'schema':'E6-T11d58-fresh-original-body-interrogation-v1','status':'passed','root':str(root),'totals':dict(totals),'categories':dict(categories),'maximumFilteredAbsoluteError':maximum_error,'refusals':dict(refusals),'completedCorruptions':completed_corruptions,'citations':out,'citationSha256':sha((dest/out).read_bytes())}
(dest/(root.name+'-interrogation.json')).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
