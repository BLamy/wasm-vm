#!/usr/bin/env python3
"""Recompute finest governing counters and full changed-line coverage."""
import collections,hashlib,json,pathlib,re,struct,subprocess
repo=pathlib.Path(__file__).resolve().parents[3];dest=pathlib.Path(__file__).resolve().parent
root=pathlib.Path('/tmp/wasmvm-dimensional-views-cold-1c7f8c9b/recording');base='deb7b3113f9adeb2e6e80449a6710dd3295093ea';frozen='1c7f8c9b4e52e09e8f6e2201f92d7483ce7117a6'
sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=repo)
names=['renderer/virgl-command/'+n+'.mjs' for n in ['constant-domain','decoder','resources','state','control-bridge']]
body={n:git('show',frozen+':'+n) for n in names};old={n:git('show',base+':'+n) for n in names};u16={n:b.decode().encode('utf-16-le')for n,b in body.items()};old16={n:b.decode().encode('utf-16-le')for n,b in old.items()}
changed=collections.defaultdict(list);name=None;line=0
for row in git('diff','--unified=0',base,frozen,'--',*names).decode().splitlines():
    if row.startswith('+++ b/'):name=row[6:]
    elif row.startswith('@@'):line=int(re.search(r'\+(\d+)',row)[1])
    elif row.startswith('+') and not row.startswith('+++'):changed[name].append(line);line+=1
raw=json.loads((root/'coverage-audit.json').read_bytes());assert raw['changedLines']==dict(changed)
current={};previous={}
for record in raw['scripts']+raw['heldScripts']:
    path=root/record['record'];d=json.loads(path.read_bytes());is_old=record in raw['heldScripts'];expected=old[record['source']] if is_old else body[record['source']]
    assert sha(expected)==record['sha256']
    rows=d.get('scripts',[d] if 'source' in d and 'coverage' in d else None)
    if rows is not None:
        actual=next(x for x in rows if x['source']==record['source']);assert actual['coverage']==record['coverage'] and actual['sha256']==record['sha256']
        if 'sourceBody' in actual:assert actual['sourceBody'].encode()==expected
        if not is_old:
            report=json.loads((path.parent/'report.json').read_bytes());assert report['browserCoverage']['sha256']==sha(path.read_bytes())
    else:
        actual=next(x for x in d['result'] if x['url'].endswith('/'+record['source']));assert actual==record['coverage']
    (previous if is_old else current)[record['record'],record['source']]=record['coverage']
def finest(mapping,n,a,b):
    counters=[]
    for (path,name),script in mapping.items():
        if name!=n:continue
        candidates=[r for f in script['functions'] for r in f['ranges'] if r['startOffset']<=a and b<=r['endOffset']]
        if candidates:counters.append({'record':path,**min(candidates,key=lambda r:(r['endOffset']-r['startOffset'],r['count']))})
    return counters
checks=[]
for classification,parts in [('executed',raw['executed']),('HELD',raw['held']),('static-waiver',raw['waived'])]:
 for p in parts:
    n=p['source'];a=p['startOffset'];b=p['endOffset'];text=u16[n][a*2:b*2].decode('utf-16-le')
    assert text==p['text'] and sha(text.encode())==p['sha256']
    counters=finest(current,n,a,b);assert counters==p['counters'] and max((c['count']for c in counters),default=0)==p['maxCount']
    for (path,name),script in current.items():
        if name==n:
            for f in script['functions']:
                for r in f['ranges']:assert not (a<r['startOffset']<b or a<r['endOffset']<b),('coarse-partition',n,p['line'],path,r)
    if classification=='executed':assert p['maxCount']>0
    elif classification=='HELD':
        oa=p['oldStartOffset'];ob=p['oldEndOffset'];assert p['maxCount']==0 and u16[n][a*2:b*2]==old16[n][oa*2:ob*2]
        assert p['baseSourceSha256']==sha(old[n]);historic=finest(previous,n,oa,ob);assert historic==p['previousCounters'] and historic
    else:
        assert n.endswith('state.mjs') and text.strip()==': "texture"' and ': "texture"' in old[n].decode()
        assert 'images ? ["texture", "mip-texture"' in body[n].decode() and 'createVirglStandardDimensionalViewAsyncRenderer' in body[n].decode()
    checks.append({'source':n,'line':p['line'],'startOffset':a,'endOffset':b,'textSha256':p['sha256'],'classification':classification,'governingCounters':counters,**({'oldStartOffset':p['oldStartOffset'],'oldEndOffset':p['oldEndOffset'],'baseSourceSha256':p['baseSourceSha256'],'historicalCounters':p['previousCounters']} if classification=='HELD' else {}),'text':text})
for n,lines in changed.items():
    starts=[0]
    for line in body[n].decode().splitlines(keepends=True):starts.append(starts[-1]+len(line.encode('utf-16-le'))//2)
    for line in lines:
        parts=sorted((p for p in checks if p['source']==n and p['line']==line),key=lambda p:p['startOffset']);assert parts and parts[0]['startOffset']==starts[line-1] and parts[-1]['endOffset']==starts[line]
        assert all(a['endOffset']==b['startOffset'] for a,b in zip(parts,parts[1:])),('changed-line-gap',n,line)
assert not raw['needsEvidence']
result={'schema':'E6-T11d58-fresh-finest-counter-audit-v1','status':'passed','base':base,'frozenHead':frozen,'changedLines':dict(changed),'currentCoverageRecords':len(current),'historicalCoverageRecords':len(previous),'executed':sum(p['classification']=='executed'for p in checks),'held':sum(p['classification']=='HELD'for p in checks),'heldWithOnlyZeroHistoricalCounts':sum(p['classification']=='HELD' and not any(r['count']>0 for r in p['historicalCounters'])for p in checks),'staticWaivers':sum(p['classification']=='static-waiver'for p in checks),'newExecutableGaps':0,'partitions':checks}
(dest/'coverage-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['partitions','changedLines']}))
