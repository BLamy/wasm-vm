#!/usr/bin/env python3
"""Fresh critic: read every sealed member and bind to exact claimed heads."""
import hashlib, json, pathlib, subprocess, tarfile, time
repo = pathlib.Path(__file__).resolve().parents[3]
dest = pathlib.Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''): h.update(block)
    return h.hexdigest()
base = 'deb7b3113f9adeb2e6e80449a6710dd3295093ea'
frozen = '1c7f8c9b4e52e09e8f6e2201f92d7483ce7117a6'
families = {
 'virgl-dimensional-views/worker': ('366968fe114438560886832570b9c36b1ffe4e3d7526cf718fba6b6dc9a47b2c','398ef4c26c719a0995bd5fbc7d14039d5dcccdb13613de7a22c945572d9a32da','fb56c37995c361bece8bbe14f6ec5606580741affbb8c76a9469e6c6a231cdf5'),
 'virgl-dimensional-views/deployment': ('9e91426d13b700e5b078510221e9236121f66d33b8af1450ce556feea43f84ec','0fda4f27d53d65fd39285edf245344715da499e68f6c50439841462cba70654a','5054f169b23d2a8dcda3cd29d9bfc5708a7a05f43a54fc3af0057a0cc4a307c8'),
}
worker = json.loads((repo/'evidence/virgl-dimensional-views/worker/manifest.json').read_bytes())
for pin in worker['dependencySeals']:
    families[pin['family']] = (pin['manifestSha256'],pin['indexSha256'],pin['archiveSha256'])
results=[]
for family, pins in families.items():
    directory=repo/'evidence'/family
    raw_manifest=(directory/'manifest.json').read_bytes(); raw_index=(directory/'records.json').read_bytes()
    archive=directory/'recording.tar.gz'
    assert (sha(raw_manifest),sha(raw_index),digest(archive))==pins, family
    manifest=json.loads(raw_manifest);index=json.loads(raw_index);rows=index['records'] if isinstance(index,dict) else index
    assert manifest['recordIndexSha256']==pins[1] and manifest['archiveSha256']==pins[2]
    if family in ('virgl-dimensional-views/worker','virgl-dimensional-views/deployment'): assert manifest['head']==frozen
    else:
        ancestor='aa2190f01f15c1458f4f595de03747fcf5ac4cf4' if family.endswith('dimensional-sampler-view-gap') else base
        assert raw_manifest==subprocess.check_output(['git','show',ancestor+':evidence/'+family+'/manifest.json'],cwd=repo)
    counts=0;total=0;members=[]
    with tarfile.open(archive, 'r|gz') as tar:
        for member in tar:
            assert counts<len(rows) and member.name==rows[counts]['path'] and member.isfile(),(family,member.name)
            assert not pathlib.PurePosixPath(member.name).is_absolute() and '..' not in pathlib.PurePosixPath(member.name).parts
            raw=tar.extractfile(member).read(); pin=rows[counts]
            assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256'],(family,member.name)
            if family=='virgl-dimensional-views/worker' and member.name.startswith('cold/'):
                local=pathlib.Path('/tmp/wasmvm-dimensional-views-cold-1c7f8c9b')/member.name.removeprefix('cold/')
                assert local.is_file() and digest(local)==pin['sha256'],('raw-drift',local)
            if family=='virgl-dimensional-views/deployment':
                # Keep only lightweight replay metadata/scripts/screenshots here;
                # every binary and staged/HTTP body was still fully reopened.
                if member.name.endswith(('.json','.py','.mjs','.log','.stdout','.stderr','.png')):
                    target=dest/'deployment'/member.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
            members.append({'path':member.name,'bytes':len(raw),'sha256':pin['sha256']});counts+=1;total+=len(raw)
    assert counts==len(rows)
    result={'family':family,'manifestSha256':pins[0],'indexSha256':pins[1],'archiveSha256':pins[2],'reopenedMembers':counts,'uncompressedBytes':total}
    results.append(result);print(json.dumps(result),flush=True)
cold=pathlib.Path('/tmp/wasmvm-dimensional-views-cold-1c7f8c9b')
report=json.loads((cold/'report.json').read_bytes());recording=cold/'recording';receipt=json.loads((recording/'receipt.json').read_bytes())
assert report['head']==receipt['head']==frozen and report['command']==['make','verify-E6-T11d58']
assert report['cleanBefore']==report['cleanAfter']=='' and report['exitCode']==0
assert digest(recording/'receipt.json')==report['receiptSha256']
assert len(receipt['commands'])==31 and all(p['exitCode']==p['expected'] for p in receipt['commands'])
for p in receipt['commands']:
    assert digest(recording/(p['name']+'.stdout'))==p['stdoutSha256']
    assert digest(recording/(p['name']+'.stderr'))==p['stderrSha256']
for seed in [27449,84131,176129]:
    hardware=json.loads((recording/('hardware-'+str(seed))/'report.json').read_bytes())
    assert hardware['head']==frozen and hardware['trackedChanges']=='' and hardware['status']=='passed'
    assert hardware['seeds']==[seed] and hardware['browser']['headless'] is False
for name,pin in receipt['sources'].items():
    raw=(recording/'sources'/name).read_bytes()
    assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256']
    assert raw==subprocess.check_output(['git','show',frozen+':'+name],cwd=repo),('frozen-source',name)
auth=json.loads((recording/'predecessor/authentication.json').read_bytes())
for name,pin in auth['heldSourcePins'].items():
    raw=(repo/name).read_bytes();assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256'],('held-source',name)
for name,pin in auth['generated'].items():
    raw=(repo/name).read_bytes();assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256'],('generated',name)
assert not subprocess.check_output(['git','diff','--name-only',base,frozen,'--','renderer/virgl-shader','crates','Cargo.lock','Cargo.toml'],cwd=repo)
clone=pathlib.Path(report['clone']); assert clone.is_dir()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==frozen
assert subprocess.check_output(['git','status','--porcelain'],cwd=clone)==b''
sealer_delta=subprocess.check_output(['git','diff',frozen,'75f5815d0f290e92cdb77239b78facf93ca6fbbc','--','tools/virgl-dimensional-views/seal.py'],cwd=repo).decode()
assert sealer_delta.count('\n-assert ')==sealer_delta.count('\n+assert ')==1 and 'for seed in [27449,84131,176129]' in sealer_delta
result={'schema':'E6-T11d58-fresh-authentication-v1','status':'passed','frozenHead':frozen,'archives':results,'reopenedTotal':sum(r['reopenedMembers'] for r in results),'sourcePins':len(receipt['sources']),'heldSourcePins':len(auth['heldSourcePins']),'generatedBodies':len(auth['generated']),'receiptSha256':digest(recording/'receipt.json'),'recordedCommands':receipt['commands'],'pristineClone':str(clone),'sealerCorrection':'Only the authentication guard changes; all three positive hardware head checks verified independently.'}
(dest/'authentication.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','reopenedTotal','sourcePins','heldSourcePins','generatedBodies','receiptSha256']}))
