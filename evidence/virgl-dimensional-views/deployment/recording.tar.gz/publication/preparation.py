from pathlib import Path,PurePosixPath
import hashlib,io,json,shutil,subprocess,tarfile
repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');head='1c7f8c9b4e52e09e8f6e2201f92d7483ce7117a6'
out=Path('/tmp/wasmvm-dimensional-view-pages-1c7f8c9b');old=Path('/tmp/wasmvm-dimensional-shader-pages-ebd460b3')
sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=repo,text=True).strip()
assert sha((old/'staging-index.json').read_bytes())=='474738c0b03a2974247a260479f3cd959de3fe0f6e0a69e2c9dd48814893f619'
previous=json.loads((old/'staging-index.json').read_bytes());assert previous['fileCount']==304
for row in previous['records']:
 body=(old/'web/dist'/row['path']).read_bytes();assert len(body)==row['bytes'] and sha(body)==row['sha256']
assert not out.exists();out.mkdir();shutil.copytree(old/'web/dist',out/'web/dist')
raw=subprocess.check_output(['git','archive',head,'web/dist'],cwd=repo);(out/'frozen-web-dist.tar').write_bytes(raw)
source={}
with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
 for entry in archive:
  path=PurePosixPath(entry.name);assert path.parts[0]=='web' and '..' not in path.parts
  if not entry.isfile():continue
  assert path.parts[:2]==('web','dist') and len(path.parts)>2
  name='/'.join(path.parts[2:]);body=archive.extractfile(entry).read();source[name]=body;file=out/'web/dist'/name;file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(body)
for row in previous['carriedBootManifests']:
 name=row['path'];assert sha(source[name])==row['sourceSha256'];shutil.copyfile(old/'web/dist'/name,out/'web/dist'/name)
records=[]
for p in sorted((out/'web/dist').rglob('*')):
 if p.is_file():
  body=p.read_bytes();assert len(body)<25*1024*1024;records.append(dict(path=p.relative_to(out/'web/dist').as_posix(),bytes=len(body),sha256=sha(body)))
prior={r['path']:r for r in previous['records']};assert len(records)==304 and set(prior)=={r['path'] for r in records}
changes=[r['path'] for r in records if r!=prior[r['path']]];assert set(changes)=={'roadmap.js','sw.js'},changes
index=dict(head=head,sourceArchiveSha256=sha(raw),heldDeployment=previous['head'],heldIndexSha256=sha((old/'staging-index.json').read_bytes()),carriedBootManifests=previous['carriedBootManifests'],records=records,fileCount=len(records),bytes=sum(r['bytes'] for r in records),codeChanges=changes)
(out/'staging-index.json').write_text(json.dumps(index,indent=2)+'\n');shutil.copyfile(__file__,out/'preparation.py');print(json.dumps(dict(head=head,files=len(records),changes=changes,bytes=index['bytes'],indexSha256=sha((out/'staging-index.json').read_bytes()))))
