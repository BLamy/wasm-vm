from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, urllib.request

repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
head='1c7f8c9b4e52e09e8f6e2201f92d7483ce7117a6'
stage=Path('/tmp/wasmvm-dimensional-view-pages-1c7f8c9b')
sha=lambda b:hashlib.sha256(b).hexdigest()
index=json.loads((stage/'staging-index.json').read_bytes())
assert index['head']==head and sha((stage/'staging-index.json').read_bytes())=='37d8ea3dc255b5bad370e414d149722f5e3e020d44f1f16796ec867dc92f23ae'
for row in index['records']:
    b=(stage/'web/dist'/row['path']).read_bytes()
    assert len(b)==row['bytes'] and sha(b)==row['sha256'] and len(b)<25*1024*1024
assert json.loads(Path('/tmp/wasmvm-dimensional-views-cold-1c7f8c9b/report.json').read_bytes())['exitCode']==0
command=['npx','--yes','wrangler@4.149.0','pages','deploy',str(stage/'web/dist'),'--project-name','wasm-vm','--branch','main','--commit-hash',head,'--commit-dirty=true']
started=datetime.now(timezone.utc).isoformat()
r=subprocess.run(command,cwd=stage,env=os.environ.copy(),capture_output=True,timeout=300)
(stage/'publish.stdout').write_bytes(r.stdout);(stage/'publish.stderr').write_bytes(r.stderr)
(stage/'publish.json').write_text(json.dumps(dict(command=command,head=head,startedAt=started,finishedAt=datetime.now(timezone.utc).isoformat(),exitCode=r.returncode,stdoutSha256=sha(r.stdout),stderrSha256=sha(r.stderr)),indent=2)+'\n')
assert r.returncode==0,r.stderr[-2000:].decode(errors='replace')
urls=re.findall(r'https://[a-z0-9]+\.wasm-vm\.pages\.dev',r.stdout.decode())
assert urls
config=(Path.home()/'Library/Preferences/.wrangler/config/default.toml').read_text()
token=re.search(r'^oauth_token\s*=\s*"([^"]+)"',config,re.M).group(1)
account='cc8e2f38f1862286b90e834d8f267d1a'
def scrub(v):
    if isinstance(v,dict):return {k:({'omitted':'environment values','count':len(x)} if k=='env_vars' else scrub(x)) for k,x in v.items()}
    if isinstance(v,list):return [scrub(x) for x in v]
    return v
def api(suffix):
    request=urllib.request.Request('https://api.cloudflare.com/client/v4/accounts/'+account+'/pages/projects/wasm-vm/'+suffix,headers={'Authorization':'Bearer '+token})
    with urllib.request.urlopen(request,timeout=60) as response:
        status=response.status;body=response.read()
    value=json.loads(body);assert status==200 and value['success'] is True
    return value
listing=api('deployments?per_page=25')
selected=[v for v in listing['result'] if v['url']==urls[-1]]
assert len(selected)==1
value=api('deployments/'+selected[0]['id'])
deployment=value['result']
assert deployment['environment']=='production' and deployment['latest_stage']['status']=='success'
assert deployment['deployment_trigger']['metadata']['commit_hash']==head
(stage/'cloudflare-success.json').write_text(json.dumps(scrub(value),indent=2)+'\n')
print(json.dumps(dict(status='published',head=head,id=deployment['id'],url=deployment['url'],environment=deployment['environment'],stage=deployment['latest_stage'],stagingSha256=sha((stage/'staging-index.json').read_bytes()))))
