"""Lossless transport repair of ONLY the unpushed D58 worker commit."""
from pathlib import Path
import hashlib,io,json,os,shutil,subprocess,tarfile,tempfile

repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
worker='75f5815d0f290e92cdb77239b78facf93ca6fbbc'
frozen='1c7f8c9b4e52e09e8f6e2201f92d7483ce7117a6'
prefix='evidence/virgl-dimensional-views/worker/'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args,input=None,env=None):
    return subprocess.check_output(['git',*args],cwd=repo,input=input,env=env)
tip=git('rev-parse','HEAD').decode().strip()
branch=git('branch','--show-current').decode().strip()
assert branch=='codex/virgl-dimensional-sampler-views'
assert not git('status','--porcelain','--untracked-files=no').strip()
subprocess.run(['git','merge-base','--is-ancestor',worker,tip],cwd=repo,check=True)
assert git('rev-parse',worker+'^').decode().strip()==frozen
remote=subprocess.run(['git','ls-remote','--exit-code','origin','refs/heads/'+branch],cwd=repo,capture_output=True)
assert remote.returncode==2 and not remote.stdout,'D58 must still be unpublished'
output=Path('/tmp/wasmvm-d58-archive-transport-'+tip[:8]);assert not output.exists();output.mkdir()
archive=git('show',worker+':'+prefix+'recording.tar.gz')
original=git('show',worker+':'+prefix+'manifest.json')
manifest=json.loads(original)
assert sha(archive)==manifest['archiveSha256'] and len(archive)==manifest['archiveBytes']
(output/'recording.tar.gz').write_bytes(archive)
(output/'manifest.original.json').write_bytes(original)
records=json.loads(git('show',worker+':'+prefix+'records.json'))['records']
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
    assert tar.getnames()==[r['path'] for r in records]
    for row in records:
        body=tar.extractfile(row['path']).read();assert len(body)==row['bytes'] and sha(body)==row['sha256']
parts=[];bodies={};width=16*1024*1024
for ordinal,offset in enumerate(range(0,len(archive),width)):
    name='recording.tar.gz.part-'+str(ordinal).zfill(4);body=archive[offset:offset+width]
    bodies[name]=body;parts.append(dict(path=name,bytes=len(body),sha256=sha(body)))
assert b''.join(bodies[r['path']] for r in parts)==archive
manifest['archiveParts']=parts
manifest['originalManifestSha256']=sha(original)
bodies['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
bodies['manifest.original.json']=original
index=output/'git.index';env={**os.environ,'GIT_INDEX_FILE':str(index)}
git('read-tree',worker,env=env)
git('update-index','--force-remove',prefix+'recording.tar.gz',env=env)
for name,body in sorted(bodies.items()):
    blob=git('hash-object','-w','--stdin',input=body).decode().strip()
    git('update-index','--add','--cacheinfo','100644,'+blob+','+prefix+name,env=env)
tree=git('write-tree',env=env).decode().strip()
message=git('show','-s','--format=%B',worker).rstrip()+b'\n\nStore the identical verification archive in 16 MiB parts for GitHub transport.\n'
author=git('show','-s','--format=%an%x00%ae%x00%aI',worker).decode().strip().split('\0')
commitEnv={**os.environ,'GIT_AUTHOR_NAME':author[0],'GIT_AUTHOR_EMAIL':author[1],'GIT_AUTHOR_DATE':author[2]}
packedWorker=git('commit-tree',tree,'-p',frozen,input=message,env=commitEnv).decode().strip()
backup='refs/codex-backups/d58-before-archive-chunking-'+tip[:8]
git('update-ref',backup,tip,'0'*40)
subprocess.run(['git','rebase','--onto',packedWorker,worker],cwd=repo,check=True)
newTip=git('rev-parse','HEAD').decode().strip()
changed=git('diff','--name-only',tip,newTip).decode().splitlines()
expected={prefix+n for n in bodies}|{prefix+'recording.tar.gz'}
assert set(changed)==expected,changed
for row in parts:
    body=(repo/prefix/row['path']).read_bytes();assert len(body)==row['bytes'] and sha(body)==row['sha256']
assert sha(b''.join((repo/prefix/r['path']).read_bytes() for r in parts))==sha(archive)
assert not git('status','--porcelain','--untracked-files=no').strip()
objects=git('rev-list','--objects','HEAD','^deb7b3113f9adeb2e6e80449a6710dd3295093ea').decode().splitlines()
oids=[r.split(' ',1)[0] for r in objects]
sizes=git('cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)',input=('\n'.join(oids)+'\n').encode()).decode().splitlines()
assert all(int(r.split()[2])<=100*1024*1024 for r in sizes if r.split()[1]=='blob')
result=dict(schema='dimensional-view-lossless-git-transport-v1',oldWorker=worker,newWorker=packedWorker,oldTip=tip,newTip=newTip,frozen=frozen,backupRef=backup,originalArchiveSha256=sha(archive),originalManifestSha256=sha(original),manifestSha256=sha(bodies['manifest.json']),parts=parts,reopenedMembers=len(records),changedPaths=changed,sourceRuntimeUnchanged=True,allNewBlobsUnder100MiB=True,remoteBranchAbsentBefore=True,remoteMutation=False)
(output/'journal.json').write_text(json.dumps(result,indent=2)+'\n');shutil.copyfile(__file__,output/'packing.py')
print(json.dumps(result))
