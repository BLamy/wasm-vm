#!/usr/bin/env python3
"""Separate reproducible seal of lossless transport evidence and operation."""
import gzip,hashlib,io,json,pathlib,tarfile
dest=pathlib.Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
skip={'manifest.json','records.json','recording.tar.gz'}
files=sorted(p for p in dest.rglob('*')if p.is_file()and p.name not in skip and '__pycache__'not in p.parts)
rows=[{'path':p.relative_to(dest).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in files]
index=(json.dumps({'schema':'E6-T11d58-transport-critic-record-index-v1','records':rows},indent=2)+'\n').encode();(dest/'records.json').write_bytes(index)
archive=dest/'recording.tar.gz'
with archive.open('wb')as output,gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0,compresslevel=9)as zipped,tarfile.open(fileobj=zipped,mode='w',format=tarfile.PAX_FORMAT)as tar:
 for p,row in zip(files,rows):
    raw=p.read_bytes();assert sha(raw)==row['sha256']and len(raw)==row['bytes']
    info=tarfile.TarInfo(row['path']);info.size=len(raw);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(raw))
count=0
with tarfile.open(archive,'r|gz')as tar:
 for member in tar:
    raw=tar.extractfile(member).read();row=rows[count];assert member.name==row['path']and len(raw)==row['bytes']and sha(raw)==row['sha256'];count+=1
assert count==len(rows)
raw_archive=archive.read_bytes();assert len(raw_archive)<100*1024*1024
audit=json.loads((dest/'authentication.json').read_bytes());verdict=json.loads((dest/'verdict.json').read_bytes());assert audit['status']=='passed'and verdict['verdict']=='verified'
manifest={'schema':'E6-T11d58-incremental-transport-critic-seal-v1','task':'E6-T11d58','verdict':'verified','frozenHead':audit['frozenHead'],'oldTip':audit['oldTip'],'newTip':audit['newTip'],'oldWorker':audit['oldWorker'],'newWorker':audit['newWorker'],'members':count,'reopenedMembers':count,'archiveBytes':len(raw_archive),'archiveSha256':sha(raw_archive),'recordIndexSha256':sha(index),'predictionsSha256':sha((dest/'predictions.json').read_bytes()),'auditSha256':sha((dest/'authentication.json').read_bytes()),'verdictSha256':sha((dest/'verdict.json').read_bytes()),'logicalMembersReopened':2327,'originalArchiveSha256':audit['archiveSha256'],'originalManifestSha256':audit['originalManifestSha256'],'chunkedManifestSha256':audit['newManifestSha256'],'originalRecordIndexSha256':audit['recordIndexSha256'],'previousCriticSeal':audit['previousCriticSeal'],'carriedPredictions':10,'carriedHistoricalZeroOperands':61,'newRuntimeCoverage':False,'runtimeOrColdTestsRepeated':False,'operation':audit['operation'],'scope':'Unpublished lossless archive serialization only; selected original RGBA8 runtime verdict unchanged; no production/guest/capset/API-completeness/MIPS authority'}
raw=(json.dumps(manifest,indent=2)+'\n').encode();(dest/'manifest.json').write_bytes(raw)
print(json.dumps({'manifestSha256':sha(raw),'indexSha256':sha(index),'archiveSha256':sha(raw_archive),'archiveBytes':len(raw_archive),'members':count}))
