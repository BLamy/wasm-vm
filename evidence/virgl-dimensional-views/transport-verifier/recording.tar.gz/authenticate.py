#!/usr/bin/env python3
"""Fresh narrow archive authentication; never executes runtime or compilers."""
import hashlib,io,json,pathlib,subprocess,tarfile
dest=pathlib.Path(__file__).resolve().parent;repo=dest.parents[2]
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=repo)
old_tip='26d42890ec8fdb88869a67b6d107fa190d7865af';new_tip='e5dbc207ec68a1436e7ba5ad12f01548d44f9357'
old_worker='75f5815d0f290e92cdb77239b78facf93ca6fbbc';new_worker='febf596108a16c99870147a40d36f7e93e2c332f'
frozen='1c7f8c9b4e52e09e8f6e2201f92d7483ce7117a6';base='deb7b3113f9adeb2e6e80449a6710dd3295093ea'
prefix='evidence/virgl-dimensional-views/worker/';worker=repo/prefix
assert git('rev-parse','HEAD').decode().strip()==new_tip
assert git('rev-parse','refs/codex-backups/d58-before-archive-chunking-26d42890').decode().strip()==old_tip
assert git('rev-parse',new_worker+'^').decode().strip()==git('rev-parse',old_worker+'^').decode().strip()==frozen
assert git('rev-parse',new_tip+'^').decode().strip()==new_worker and git('rev-parse',old_tip+'^').decode().strip()==old_worker
assert git('show','-s','--format=%B',new_tip)==git('show','-s','--format=%B',old_tip)
expected={prefix+'manifest.json',prefix+'manifest.original.json',prefix+'recording.tar.gz'}|{prefix+'recording.tar.gz.part-'+str(i).zfill(4)for i in range(10)}
changed=git('diff','--name-only',old_tip,new_tip).decode().splitlines();assert set(changed)==expected
assert set(git('diff','--name-only',old_worker,new_worker).decode().splitlines())==expected
assert git('diff',old_worker,old_tip)==git('diff',new_worker,new_tip)
(dest/'serialization.diff').write_bytes(git('diff',old_tip,new_tip,'--',prefix+'manifest.json'))
(dest/'git-provenance.txt').write_bytes(git('log','--format=%H %P %s','-3'))
original=(worker/'manifest.original.json').read_bytes();raw_manifest=(worker/'manifest.json').read_bytes();raw_index=(worker/'records.json').read_bytes()
assert sha(original)=='366968fe114438560886832570b9c36b1ffe4e3d7526cf718fba6b6dc9a47b2c'
assert original==git('show',old_tip+':'+prefix+'manifest.json')
assert sha(raw_manifest)=='0d33df88ff4eab46b34d7c376fda9f4d69ae1120c6bba9e82a3fd468e8afd135'
assert raw_manifest==git('show',new_tip+':'+prefix+'manifest.json')
assert sha(raw_index)=='398ef4c26c719a0995bd5fbc7d14039d5dcccdb13613de7a22c945572d9a32da'
assert raw_index==git('show',old_tip+':'+prefix+'records.json')==git('show',new_tip+':'+prefix+'records.json')
manifest=json.loads(raw_manifest);previous=json.loads(original);parts=manifest.pop('archiveParts');old_sha=manifest.pop('originalManifestSha256')
assert old_sha==sha(original)and manifest==previous and len(parts)==10
assert previous['head']==frozen and previous['archiveBytes']==151192332
assert previous['archiveSha256']=='fb56c37995c361bece8bbe14f6ec5606580741affbb8c76a9469e6c6a231cdf5'
assert previous['recordIndexSha256']==sha(raw_index)
blobs=[];part_checks=[]
for ordinal,row in enumerate(parts):
    assert row['path']=='recording.tar.gz.part-'+str(ordinal).zfill(4)
    body=(worker/row['path']).read_bytes();assert len(body)==row['bytes']<=16*1024*1024 and sha(body)==row['sha256']
    assert body==git('show',new_tip+':'+prefix+row['path']);blobs.append(body)
    part_checks.append({**row,'gitBlob':git('rev-parse',new_tip+':'+prefix+row['path']).decode().strip(),'ordinal':ordinal})
archive=b''.join(blobs);assert len(archive)==previous['archiveBytes']and sha(archive)==previous['archiveSha256']
external=pathlib.Path('/tmp/wasmvm-d58-archive-transport-26d42890')
assert archive==(external/'recording.tar.gz').read_bytes()==git('show',old_tip+':'+prefix+'recording.tar.gz')
rows=json.loads(raw_index)['records'];assert len(rows)==2327
reopened=0;total=0
with tarfile.open(fileobj=io.BytesIO(archive),mode='r|gz')as tar,(dest/'logical-members.jsonl').open('w')as log:
 for member in tar:
    row=rows[reopened];assert member.isfile()and member.name==row['path']and member.size==row['bytes']
    assert not pathlib.PurePosixPath(member.name).is_absolute()and '..'not in pathlib.PurePosixPath(member.name).parts
    body=tar.extractfile(member).read();assert len(body)==row['bytes']and sha(body)==row['sha256']
    log.write(json.dumps({'ordinal':reopened,'path':member.name,'bytes':len(body),'sha256':sha(body)},sort_keys=True)+'\n');reopened+=1;total+=len(body)
assert reopened==len(rows)
for name in ['manifest.json','manifest.original.json','records.json']:(dest/name.replace('.json','.worker.json')).write_bytes((worker/name).read_bytes())
journal=(external/'journal.json').read_bytes();packing=(external/'packing.py').read_bytes();index=(external/'git.index').read_bytes()
(dest/'operation').mkdir(exist_ok=True)
for name in ['journal.json','packing.py','manifest.original.json','git.index']:(dest/'operation'/name).write_bytes((external/name).read_bytes())
j=json.loads(journal);assert {k:j[k]for k in ['oldWorker','newWorker','oldTip','newTip','frozen']}=={'oldWorker':old_worker,'newWorker':new_worker,'oldTip':old_tip,'newTip':new_tip,'frozen':frozen}
assert j['parts']==parts and j['originalArchiveSha256']==sha(archive)and j['originalManifestSha256']==sha(original)and j['manifestSha256']==sha(raw_manifest)
assert set(j['changedPaths'])==expected and j['reopenedMembers']==reopened and j['remoteMutation']is False
assert (external/'manifest.original.json').read_bytes()==original
# Independently reproduce the packing algorithm's byte slices, without running
# its history-mutating Git commands. Complete executed script is retained above.
for ordinal,row in enumerate(parts):assert blobs[ordinal]==archive[ordinal*16*1024*1024:(ordinal+1)*16*1024*1024]
objects=git('rev-list','--objects',new_tip,'^'+base).decode().splitlines();ids=[r.split(' ',1)[0]for r in objects]
sizes=subprocess.check_output(['git','cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)'],cwd=repo,input=('\n'.join(ids)+'\n').encode()).decode().splitlines()
blob_records=[]
for name,size in zip(objects,sizes):
    oid,kind,number=size.split();assert oid==name.split(' ',1)[0]
    if kind=='blob':
        assert int(number)<=100*1024*1024;blob_records.append({'oid':oid,'bytes':int(number),'path':name.split(' ',1)[1]if ' 'in name else None})
old_blob=git('rev-parse',old_tip+':'+prefix+'recording.tar.gz').decode().strip();assert old_blob not in ids
(dest/'reachable-blobs.jsonl').write_text(''.join(json.dumps(r,sort_keys=True)+'\n'for r in blob_records))
remote=subprocess.run(['git','ls-remote','--heads','origin','refs/heads/codex/virgl-dimensional-sampler-views'],cwd=repo,capture_output=True)
assert remote.returncode==0 and remote.stdout==b'';assert not remote.stderr
(dest/'remote-check.json').write_text(json.dumps({'command':['git','ls-remote','--heads','origin','refs/heads/codex/virgl-dimensional-sampler-views'],'exitCode':remote.returncode,'stdout':remote.stdout.decode(),'stderr':remote.stderr.decode(),'absent':True},indent=2)+'\n')
critic='evidence/virgl-dimensional-views/verifier/';critic_archive=(repo/critic/'recording.tar.gz').read_bytes()
critic_pins={'manifest.json':'bf8aaeb347ad4aead9304fbfc4759fe74f1e622328f0399fc13c3b412318d590','records.json':'c2b97a36f021cc572d94490e7a341bca0a209923399d3e0c2d070b3026386958','recording.tar.gz':'b5cbdaca9aa4885a0b06b94572eaa3a92688be1ba4b0a0c89def652fc956f787'}
for name,pin in critic_pins.items():assert sha((repo/critic/name).read_bytes())==pin and git('rev-parse',old_tip+':'+critic+name)==git('rev-parse',new_tip+':'+critic+name)
with tarfile.open(fileobj=io.BytesIO(critic_archive),mode='r:gz')as tar:
    verdict_raw=tar.extractfile('verdict.json').read();coverage_raw=tar.extractfile('coverage-audit.json').read();held_raw=tar.extractfile('held-citations.jsonl').read()
verdict=json.loads(verdict_raw);coverage=json.loads(coverage_raw);assert verdict['verdict']=='verified'and len(verdict['predictions'])==10 and all(p['status']=='HELD'for p in verdict['predictions'])
assert coverage['executed']==851 and coverage['held']==coverage['heldWithOnlyZeroHistoricalCounts']==61 and coverage['staticWaivers']==1 and coverage['newExecutableGaps']==0
assert sha(coverage_raw)==verdict['auditDigests']['coverage-audit.json']and sha(held_raw)==verdict['auditDigests']['held-citations.jsonl']
(dest/'carried-verdict.json').write_bytes(verdict_raw);(dest/'carried-held-citations.jsonl').write_bytes(held_raw)
proof={'schema':'E6-T11d58-incremental-lossless-transport-audit-v1','status':'passed','oldTip':old_tip,'newTip':new_tip,'oldWorker':old_worker,'newWorker':new_worker,'frozenHead':frozen,'changedPaths':changed,'runtimeOriginalHarnessTaskQueuePromotedTestsAndCriticSealUnchanged':True,'newManifestSha256':sha(raw_manifest),'originalManifestSha256':sha(original),'recordIndexSha256':sha(raw_index),'archiveSha256':sha(archive),'archiveBytes':len(archive),'parts':part_checks,'reopenedMembers':reopened,'uncompressedBytes':total,'logicalMemberCitationsSha256':sha((dest/'logical-members.jsonl').read_bytes()),'newReachableBlobs':len(blob_records),'maximumNewReachableBlobBytes':max(r['bytes']for r in blob_records),'originalOversizedBlobAbsentFromNewAncestry':old_blob,'reachableBlobCitationsSha256':sha((dest/'reachable-blobs.jsonl').read_bytes()),'remoteBranchAbsent':True,'carriedPredictions':[{ 'id':p['id'],'status':'HELD','authority':'unchanged code/dependency/evidence digests','observation':p['observation']}for p in verdict['predictions']],'carriedZeroHistoricalOperands':61,'newRuntimeCoverage':False,'previousCriticSeal':critic_pins,'operation':{'journalSha256':sha(journal),'executedPackingScriptSha256':sha(packing),'backupGitIndexSha256':sha(index),'preservedOriginalArchive':str(external/'recording.tar.gz'),'archiveSha256':sha(archive),'packingSlicesIndependentlyReproduced':True},'actualLinuxGuest':False,'productionAuthority':False,'mipsAuthority':False}
(dest/'authentication.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({k:v for k,v in proof.items()if k not in ['parts','carriedPredictions','previousCriticSeal','changedPaths']}))
