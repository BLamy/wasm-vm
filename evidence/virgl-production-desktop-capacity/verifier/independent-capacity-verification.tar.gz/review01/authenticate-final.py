from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

repo = Path.cwd()
base = repo / 'target/evidence/critic-production-desktop-capacity74d2'
final = repo / 'target/evidence/production-desktop-capacity-pristine01'
selected = final / 'desktop-capacity'
head = 'f0f36214f770551bd867f33b5177698107a5c00f'
archive = repo / 'evidence/virgl-production-desktop-capacity/worker/submission.tar.gz'
digest = lambda b: hashlib.sha256(b).hexdigest()
report = {'task': 'E6-T11d74d2', 'verdict': 'HELD', 'frozenHead': head,
          'workerSubmission': '4944b3f6', 'files': [], 'workerPhases': []}
raw = archive.read_bytes()
assert len(raw) == 9271104 and digest(raw) == '6c4a82aa2bb909fd29f56db4634bda5b12b6bac28ad87f18c5414de8948c54fc'
with tarfile.open(archive, 'r:gz') as stream:
    members = stream.getmembers()
    assert len(members) == 418 and all(m.isfile() for m in members)
    manifest = json.load(stream.extractfile('manifest.json'))
    assert manifest['head'] == head and manifest['status'] == 'passed'
    assert len(manifest['files']) == 417
    assert {m.name for m in members} == {'manifest.json', *(f['path'] for f in manifest['files'])}
    for item in manifest['files']:
        body = stream.extractfile(item['path']).read()
        assert len(body) == item['bytes'] and digest(body) == item['sha256'], item['path']
    report['workerSeal'] = {'path': str(archive.relative_to(repo)), 'bytes': len(raw), 'sha256': digest(raw),
                            'reopenedMembers': len(members), 'authenticatedIdentities': len(manifest['files'])}

for path in [final / 'report.json', selected / 'report.json']:
    data = json.loads(path.read_text())
    assert data['head'] == head and data['status'] == 'passed'
    assert all(c['exitCode'] == 0 for c in data['commands'])
    assert len(data['commands']) == (4 if path.parent == final else 16)
    for item in data['files']:
        body = (path.parent / item['path']).read_bytes()
        assert len(body) == item['bytes'] and digest(body) == item['sha256'], item['path']
    report['files'].append({'path': str(path.relative_to(repo)), 'sha256': digest(path.read_bytes()),
                            'passedCommands': len(data['commands']), 'authenticatedFiles': len(data['files'])})
clone = final / 'clone'
assert not (clone / '.git/objects/info/alternates').exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clone, text=True).strip() == head
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=clone)
report['clone'] = {'head': head, 'trackedClean': True, 'alternatesAbsent': True, 'cloneCommand': json.loads((final / 'report.json').read_text())['commands'][0]['command']}

for name in ['actual-worker', 'independent-physical']:
    directory = selected / name
    data = json.loads((directory / 'report.json').read_text())
    assert data['head'] == head and data['status'] == 'passed'
    for item in data['sources']:
        body = (directory / 'source' / item['path']).read_bytes()
        assert len(body) == item['bytes'] and digest(body) == item['sha256'], item['path']
        # Every frozen source is also present in the pristine checkout product.
        assert body == (clone / item['path']).read_bytes(), item['path']
    if name == 'actual-worker':
        assert data['errors'] == []
        worker = data
    else:
        assert data['errors'] == {'console': [], 'page': [], 'requests': []}
        assert all(row['status'] == 'passed' and row['liveNativeOwners'] == 0 for row in data['actual']['rows'])
        assert len(data['actual']['rows']) == 6
        assert sum(row['assertions'] for row in data['actual']['rows']) == 4837
        report['physical'] = {'rows': 6, 'assertions': 4837, 'allNativeOwnersRetired': True}

for label, color, restored, mode in [('cold', [0, 255, 0, 255], False, 'icount'),
                                    ('warm', [0, 255, 0, 255], True, 'icount'),
                                    ('warm-input', [255, 0, 0, 255], True, 'paced-icount'),
                                    ('repeat', [0, 0, 255, 255], True, 'paced-icount'),
                                    ('final', [0, 0, 255, 255], True, 'paced-icount')]:
    path = selected / 'actual-worker' / (label + '.json')
    state = json.loads(path.read_text())
    gpu = state['gpu']
    assert len(gpu['store']['resources']) == 512 and len(gpu['store']['contexts']) == 32
    assert gpu['renderer']['budgets']['contexts'] == 32 and gpu['renderer']['budgets']['subContexts'] == 64
    assert gpu['counters']['failed'] == 0 and gpu['pending'] is None and state['errors'] == []
    assert state['pixel'] == color and state['restored'] == restored and state['clock']['mode'] == mode
    report['workerPhases'].append({'label': label, 'sha256': digest(path.read_bytes()), 'resources': 512,
                                  'contexts': 32, 'subContexts': 64, 'pixel': color,
                                  'restored': restored, 'mode': mode, 'draws': gpu['renderer']['work']['draws']})
assert [s['draws'] for s in report['workerPhases'][:4]] == [2, 4, 6, 8]
for key, label in [('captureA', 'warm'), ('captureB', 'repeat')]:
    capture = worker[key]
    assert capture['before']['clock'] == capture['after']['clock']
    assert capture['before']['scheduler']['retiredInstructions'] == capture['after']['scheduler']['retiredInstructions']
    state = json.loads((selected / 'actual-worker' / (label + '.json')).read_text())
    event = state['events'][0]
    assert int(event['freshEpoch'], 16) == int(event['savedEpoch'], 16) + 1
    assert event['clockState'] == capture['before']['clock'] and event['sha256'] == capture['pin']['sha256']
    body = (selected / 'actual-worker' / (capture['pin']['path'].split('/')[-1] + '.wvgpair')).read_bytes()
    assert len(body) == capture['pin']['bytes'] and digest(body) == capture['pin']['sha256']
rows = [json.loads(line) for line in (selected / 'actual-worker/gpu.ndjson').read_text().splitlines()]
jobs = [(i + 1, row['event']) for i, row in enumerate(rows) if row.get('type') == 'control' and row.get('event', {}).get('type') == 'beginJob']
assert {len(job['resources']) for _, job in jobs} == {0, 512}
first512 = next((line, job) for line, job in jobs if len(job['resources']) == 512)
first512commands = next((line, job) for line, job in jobs if len(job['resources']) == 512 and job['header']['type'] == 0x207)
assert first512commands[1]['header']['flags'] == 1 and int(first512commands[1]['header']['fenceId'], 16) > 2**53
popup_line, popup = next((i + 1, row['event']) for i, row in enumerate(rows) if row.get('type') == 'control' and row.get('event', {}).get('type') == 'createResource' and row['event']['resource']['id'] == 104)
assert popup['metadata'] == {'id': 104, 'target': 2, 'format': 67, 'bind': 10, 'width': 24, 'height': 24, 'depth': 1, 'arraySize': 1, 'lastLevel': 0, 'nrSamples': 0, 'flags': 0}
assert sum(row.get('type') == 'control' and row.get('event', {}).get('type') == 'createResource' for row in rows[:popup_line]) == 65
report['originalWorkerTrace'] = {'sha256': digest((selected / 'actual-worker/gpu.ndjson').read_bytes()),
                                 'popupCreation65Line': popup_line, 'first512RosterLine': first512[0],
                                 'first512Header': first512[1]['header'], 'finalDigest': worker['finalDigest']}
report['originalWorkerTrace']['first512CommandLine'] = first512commands[0]
report['originalWorkerTrace']['first512CommandHeader'] = first512commands[1]['header']
native = selected / 'independent-native'
assert json.loads((native / 'report.json').read_text())['status'] == 'passed'
assert '6 passed; 0 failed; 0 ignored;' in (native / 'original-wire.stdout').read_text()
cases = [line for line in (native / 'original-wire.stderr').read_text().splitlines() if line.startswith('CRITIC_DESKTOP_CHECKPOINT')]
assert len(cases) == 12
report['nativeCheckpointCases'] = cases
default = json.loads((selected / 'default-browser/report.json').read_text())
assert default['status'] == 'passed' and default['passed'] == 127 and default['failed'] == 0 and default['errors'] == [] and default['proofExportAbsent']
assert default['servedWasmSha256'] == digest((clone / 'web/dist/pkg/wasm_vm_wasm_bg.wasm').read_bytes())
assert json.loads((selected / 'frame-continuity/report.json').read_text())['status'] == 'passed'
report['default'] = {'passed': 127, 'failed': 0, 'errors': [], 'ordinaryProofExportsAbsent': True, 'wasmSha256': default['servedWasmSha256']}
report['scope'] = 'Capacity component only; actual Omarchy bar/click/repeat, final warm factory, HTTPS publication and recovery remain74d/parent/e.'
(base / 'review01/final-authentication.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'verdict': report['verdict'], 'workerSeal': report['workerSeal'], 'clone': report['clone'],
                  'physical': report['physical'], 'workerPhases': report['workerPhases'], 'default': report['default']}, indent=2))
