from pathlib import Path
import json,hashlib,subprocess
R=Path.cwd(); E=R/'evidence/virgl-blend/verifier'; sha=lambda b:hashlib.sha256(b).hexdigest()
def read(name): return json.loads((E/name).read_text())
def write(name,d): (E/name).write_text(json.dumps(d,indent=2)+'\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='2b720fcac4da27b57397aa70ed3ba84a4d2c0b1e'
assert not subprocess.check_output(['git','diff','0ed130ff0b9a3efa1273ac485d87dad656efcef4','--','renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs','renderer/virgl-shader'])
for n in ['authentication.json','recording-audit.json','fresh-audit.json','carry-forward.json','final-audit.json','enum-audit.json']: assert read(n)['status']=='HELD'
assert read('coverage-audit.json')['counts']=={'executed':66,'waived':0,'needs-evidence':0}
write('guard-waivers.json',{
 'status':'HELD','task':'E6-T11d2','changedRuntimeLines':66,'unexecutedChangedRuntimeLines':0,
 'scope':'Narrow false error arms of valid-input checks; no acceptance behavior or changed runtime hunk is waived.',
 'guards':[
  {'source':'renderer/virgl-command/state.mjs','lines':[409,410,411], 'classification':'waived-false-arm',
   'reason':'Checked ordinary fragment compiler emits one fsout_c0 vec4 and no reserved host symbol. Terminal discard is excluded from folding. Invalid compiler text or metadata cannot originate from original-form TGSI at this unchanged checked compiler boundary; successful guard evaluation is recorded.',
   'authority':'Authenticated unchanged D1 compiler boundary in carry-forward.json; actual terminal-discard/reflection execution in fresh-audit.json.'},
  {'source':'renderer/virgl-command/state.mjs','lines':[412,413], 'classification':'waived-false-arm',
   'reason':'Checked compiler owns one main. Both ordinary and sampler-view-specialized compiler products execute this guard. Arbitrary host GLSL is outside the packet interface and the unchanged compiler boundary.',
   'authority':'carry-forward.json; novel sampled-view/blend A/B/A in fresh-audit.json.'},
  {'source':'renderer/virgl-command/state.mjs','lines':[679], 'classification':'waived-false-arm',
   'reason':'Synchronous trusted host work is nonreentrant; the asynchronous renderer serializes each owned job while busy and snapshots decoded bytes. A blend identity mutation between plan and restore would require violating that trusted adapter/busy contract. Actual equality executes with delays0/1/3 and true state-only restores.',
   'authority':'coverage-audit.json positive count; gpu-1779033703/report.json jobs and async assertions.'}
 ]})
p=read('predictions.json')
proof={'P1-authentication':'authentication.json','P2-wire':'enum-audit.json','P3-physical-matrix':'recording-audit.json','P4-fold':'recording-audit.json','P5-lifetime':'fresh-audit.json','P6-bounds':'fresh-audit.json','P7-schedules':'fresh-audit.json','P8-faults':'final-audit.json','P9-fresh-attacks':'fresh-audit.json','P10-coverage':'coverage-audit.json','P11-cold':'authentication.json'}
for x in p['predictions']:
 x['status']='HELD'; x['proof']=proof[x['id']]
p['verdict']='verified'; p['fixtureCorrection']='prediction-correction.json preserves an initial critic-only object-namespace collision and the corrected rerun; no runtime repair.'
write('predictions.json',p)
# Exact selected points are also available directly in full sealed reports.
def point(path,needle):
 raw=path.read_bytes(); text=raw.decode(); off=text.find(needle); assert off>=0,(path,needle)
 return {'path':path.relative_to(R).as_posix(),'line':text[:off].count('\n')+1,'sha256':sha(raw)}
anchors={}
for label,name in [('allocation','variant allocation rejects'),('components','host factor components rejects'),('size','variant output bound rejects'),('eviction','actual bounded variant program eviction'),('async','async-3 one real fence'),('terminal','mixed-constant-terminal-discard actual fold reflection'),('cleanup','terminal discard native deletion Program'),('reflection','critic reflection location rejects')]:
 anchors[label]=point(E/'gpu-1779033703/report.json',name)
anchors['wire']=point(E/'unpacked/hot/hardware/report.json','pinned enabled factor slot1 value6')
for label,name in [('mixed','rgb-0-7-8'),('min','rgb-3-7-8'),('restore','critic-owner-restore-1'),('lastColor','critic-last-color-update'),('reuse','critic-reused-ID-bind'),('subcontext','critic-subcontext-restore-42'),('composition','critic-view-fold-0')]:
 pth=E/('hot-hardware-audit.jsonl' if label in ['mixed','min'] else 'fresh-1779033703-audit.jsonl')
 rows=pth.read_text().splitlines(); i,row=next((i,json.loads(s)) for i,s in enumerate(rows,1) if json.loads(s)['name']==name)
 anchors[label]={'path':pth.relative_to(R).as_posix(),'line':i,'sha256':sha(pth.read_bytes()),'frame':row}
write('citations.json',anchors)
summary={'verdict':'verified','task':'E6-T11d2','sourceHead':p['sourceHead'],'submissionHead':p['submissionHead'],'verifiedParent':'3c6295a93d6b088c62a5c6f1cc434f226e090340','workerRecords':242,'recordedFramesPerOriginalRun':2302,'recordedPixelsPerOriginalRun':589312,'independentSeeds':[1779033703,3144134277,1013904242],'freshFrames':7410,'freshPixels':1896960,'promotedFrames':22,'promotedPredicates':633,'executedChangedRuntimeLines':66,'runtimeEvidenceGaps':0,'promotedTest':read('final-audit.json')['promoted']['path'],'promotedTestSha256':read('final-audit.json')['promoted']['sha256'],'fixtureCorrection':'prediction-correction.json','scope':read('carry-forward.json')['d2Scope']}
write('verdict.json',summary)
print(json.dumps(summary))
