from pathlib import Path
import io,json,hashlib,gzip,tarfile
R=Path.cwd(); E=R/'evidence/virgl-blend/verifier'; sha=lambda b:hashlib.sha256(b).hexdigest()
exclude={'recording.tar.gz','records.json','manifest.json'}
selected={p.name:p for p in E.iterdir() if p.is_file() and p.name not in exclude and p.suffix in {'.json','.jsonl','.py','.mjs'}}
for name in ['gpu-1779033703','gpu-3144134277','gpu-1013904242','gpu-initial-1779033703','promoted','sabotage-fold','sabotage-promoted','abi']:
 for p in (E/name).rglob('*'):
  if p.is_file() and not any(x.endswith('.dSYM') or x=='__pycache__' for x in p.parts):
   assert not p.is_symlink();selected[p.relative_to(E).as_posix()]=p
promoted=R/'renderer/virgl-command/tests/blend-boundaries.mjs'
selected['promoted-source/renderer/virgl-command/tests/blend-boundaries.mjs']=promoted
records=[]
with (E/'recording.tar.gz').open('wb') as fp:
 with gzip.GzipFile(fileobj=fp,mode='wb',filename='',mtime=0,compresslevel=6) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for name,p in sorted(selected.items()):
    raw=p.read_bytes();i=tarfile.TarInfo(name);i.size=len(raw);i.mode=0o644;i.mtime=0;tar.addfile(i,io.BytesIO(raw))
    records.append({'path':name,'bytes':len(raw),'sha256':sha(raw)})
index={'schema':1,'task':'E6-T11d2','role':'fresh-adversarial-verifier','sourceHead':'0ed130ff0b9a3efa1273ac485d87dad656efcef4','records':records}
(E/'records.json').write_text(json.dumps(index,indent=2)+'\n')
# Reopening the compressed seal is independent of the source enumeration above.
with tarfile.open(E/'recording.tar.gz','r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(records);assert len(set(x.name for x in members))==len(records)
 for member,row in zip(members,records):
  assert member.name==row['path'] and member.isfile() and member.size==row['bytes'];assert sha(tar.extractfile(member).read())==row['sha256']
verdict=json.loads((E/'verdict.json').read_text());manifest={'schema':1,'task':'E6-T11d2','verdict':'verified','sourceHead':index['sourceHead'],'submissionHead':verdict['submissionHead'],'verifiedParent':verdict['verifiedParent'],'records':len(records),'archive':'recording.tar.gz','archiveBytes':(E/'recording.tar.gz').stat().st_size,'archiveSha256':sha((E/'recording.tar.gz').read_bytes()),'recordIndex':'records.json','recordIndexSha256':sha((E/'records.json').read_bytes()),'workerArchiveSha256':'ee7ef868a4e8d98e8121c37116a8d3d06497b6cc88ef3c9c4581254f3a522b1f','workerIndexSha256':'1c6b9f26fae9591017986598f241272b084505d251e34460c5c315f322108d7c','promotedTest':verdict['promotedTest'],'promotedTestSha256':sha(promoted.read_bytes()),'executedChangedRuntimeLines':66,'freshPhysicalFrames':7410,'promotedFrames':22,'allMembersReopenedAndAuthenticated':True,'scope':verdict['scope']}
(E/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest))
