from pathlib import Path
import json,random,hashlib
R=Path.cwd();E=R/'evidence/virgl-blend/verifier';base=(R/'renderer/virgl-command/tests/blend-equations.mjs').read_text();wrapper=(R/'tools/verify-virgl-blend-equations.mjs').read_text()
wrapper=wrapper.replace("from './virgl-command/fixtures.mjs'","from '../../../tools/virgl-command/fixtures.mjs'")
wrapper=wrapper.replace("['--output','--node-only','--mutation']","['--output','--node-only','--mutation','--test-source']")
needle="  if(!options['node-only']){"
wrapper=wrapper.replace(needle,"  if(options['test-source']){const bytes=await fs.readFile(path.resolve(options['test-source']));report.verifierHarness={path:path.resolve(options['test-source']),originalSha256:sha256(sources.get('renderer/virgl-command/tests/blend-equations.mjs')),servedSha256:sha256(bytes)};sources.set('renderer/virgl-command/tests/blend-equations.mjs',bytes);await fs.writeFile(path.join(output,'harness.mjs'),bytes);}\n"+needle)
(E/'physical.mjs').write_text(wrapper)
extra=r'''
  // Fresh critic cases: no redundant color/bank/state updates during owner restoration.
  const o=rig(gl,bridge,c),ownerTests=new Map(),ownedHex=new Map();
  for(const ctx of [1,2])nativeRun(o,c,ctx,setup(),'critic owner setup '+ctx);
  for(const ctx of [1,2]){
    const test={name:'critic-owner-init-'+ctx,target:target(ctx===1?23:8,ctx===1?24:7,6,ctx===1?3:20,ctx===1?0:2,ctx===1?1:0,ctx===1?13:10),source:ctx===1?[.328125,.609375,.921875,.1875]:[.828125,.140625,.453125,.90625],color:ctx===1?[.171875,.734375,.390625,.5625]:[.875,.28125,.640625,.109375],destination:ctx===1?[89,149,47,37]:[213,51,177,219],format:67};
    const bytes=commands(test,77);nativeRun(o,c,ctx,bytes,test.name);verifyFrame(o,c,test,evidence,raw,bytes);ownerTests.set(ctx,test);ownedHex.set(ctx,hex(bytes));
  }
  for(const ctx of [1,2,1,2,1]){
    const test={...ownerTests.get(ctx),name:'critic-owner-restore-'+ctx,preparedPacketHex:ownedHex.get(ctx),stateOnly:true};poison(gl);
    const bytes=join(clear(test.destination.map(v=>v/255)),draw());nativeRun(o,c,ctx,bytes,test.name);verifyFrame(o,c,test,evidence,raw,bytes);
  }
  {const old=ownerTests.get(1),updated={...old,name:'critic-last-color-update',color:[.953125,.0625,.515625,.296875],stateOnly:true};
    const prepare=join(commands(old,79),packet(14,0,updated.color.map(word)));updated.preparedPacketHex=hex(prepare);poison(gl);
    const bytes=join(packet(14,0,[.75,.5,.25,.125].map(word)),packet(14,0,updated.color.map(word)),clear(updated.destination.map(v=>v/255)),draw());nativeRun(o,c,1,bytes,updated.name);verifyFrame(o,c,updated,evidence,raw,bytes);ownerTests.set(1,updated);ownedHex.set(1,updated.preparedPacketHex);
    // A new public object with the same ID cannot replace the retained destroyed binding.
    const other={...updated,name:'critic-reused-ID-bind',target:target(7,24,8,23,1,2,11)};
    const retained={...updated,name:'critic-reused-ID-unbound'};
    const pending=join(blend(77,other.target),clear(retained.destination.map(v=>v/255)),draw());nativeRun(o,c,1,pending,retained.name);verifyFrame(o,c,retained,evidence,raw,pending);
    other.preparedPacketHex=hex(join(blend(77,other.target),packet(14,0,other.color.map(word)),packet(12,0,[1,0,...other.source.map(word)]),clear(other.destination.map(v=>v/255)),draw()));other.stateOnly=true;
    const selected=join(packet(2,1,[77]),packet(3,1,[77]),clear(other.destination.map(v=>v/255)),draw());nativeRun(o,c,1,selected,other.name);verifyFrame(o,c,other,evidence,raw,selected);
  }
  // Distinct subcontext values survive only SET_SUB_CTX plus clear/draw.
  nativeRun(o,c,1,join(packet(29,0,[42]),packet(28,0,[42]),setup()),'critic subcontext setup');
  const subTest={name:'critic-subcontext-init',target:target(24,23,23,8,2,0,14),source:[.515625,.78125,.203125,.671875],color:[.046875,.90625,.359375,.8125],destination:[23,171,103,185],format:67};
  const subBytes=commands(subTest,77);nativeRun(o,c,1,subBytes,subTest.name);verifyFrame(o,c,subTest,evidence,raw,subBytes);
  for(const sub of [0,42,0,42]){
    const test={...(sub===42?subTest:{...ownerTests.get(1),target:target(7,24,8,23,1,2,11)}),name:'critic-subcontext-restore-'+sub,stateOnly:true,
      preparedPacketHex:sub===42?hex(subBytes):hex(join(blend(77,target(7,24,8,23,1,2,11)),packet(14,0,ownerTests.get(1).color.map(word)),packet(12,0,[1,0,...ownerTests.get(1).source.map(word)]),clear(ownerTests.get(1).destination.map(v=>v/255)),draw()))};
    const bytes=join(packet(28,0,[sub]),clear(test.destination.map(v=>v/255)),draw());poison(gl);nativeRun(o,c,1,bytes,test.name);verifyFrame(o,c,test,evidence,raw,bytes);
  }
  c.same(o.renderer.inspect().caches.program.evictions>0,true,'critic owner/subcontext evictions');dispose(o,c,'critic owners');
  // Real linked variant reflection fault paths; normal GPU/bank recovery is mandatory.
  for(const reflection of ['location','index','type','size']){
    const a=rig(gl,bridge,c);nativeRun(a,c,1,setup(),'critic reflection setup '+reflection);a.control.reflection=reflection;const before=a.calls.length;
    const failure=c.bad(a.renderer.executeSubmission(1,commands(fault)),'critic reflection '+reflection,'shader-reflection-error');c.same(a.calls.length,before,'critic reflection no draw '+reflection);a.control.reflection=null;
    const test={...fault,name:'critic-reflection-recovery-'+reflection};const bytes=join(packet(2,1,[0]),packet(3,1,[70]),commands(test,71));nativeRun(a,c,1,bytes,test.name);verifyFrame(a,c,test,evidence,raw,bytes);evidence.guards??=[];evidence.guards.push({reflection,failure,budgets:a.renderer.inspect().budgets});dispose(a,c,'critic reflection '+reflection);
  }
  // Bounded physical composition attack: sampled view wrapper followed by mixed blend wrapper.
  const tex=rig(gl,bridge,c),TEXTURE='FRAG\nDCL SAMP[0]\nDCL SVIEW[0], 2D, FLOAT\nDCL CONST[0]\nDCL OUT[0], COLOR\n0: TEX OUT[0], CONST[0], SAMP[0], 2D\n1: END\n';
  nativeRun(tex,c,1,setup(TEXTURE),'critic composition setup');c.ok(tex.store.createResource(meta(10,2,67,8,1,1)),'critic owned source texel');c.ok(tex.store.attachContext(1,10),'critic source texture attachment');
  c.ok(tex.store.attachBacking(10,[Uint8Array.from([0,0,255,255])]),'critic source texel backing');
  nativeRun(tex,c,1,packet(43,0,[10,0,0,0,0,0,0,0,1,1,1,0,1]),'critic source texture transfer');
  const baseTex=[0,0,1,1],bank=[.5,.5,0,0],sampler=packet(1,7,[92,2|(2<<3)|(2<<6)|(2<<11),0,0,0x447a0000,0,0,0,0]);nativeRun(tex,c,1,sampler,'critic sampled nearest sampler');
  for(const [i,swizzle]of [[2,1,0,3],[0,3,2,1],[2,1,0,3]].entries()){
    const view=packet(1,6,[100+i,10,0x02000043,0,0,swizzle.reduce((n,v,l)=>n|(v<<(3*l)),0)]),test={name:'critic-view-fold-'+i,target:target(i%2?24:7,i%2?23:8,6,20,i%3,(i+2)%5,i%2?13:15),source:swizzle.map(l=>baseTex[l]),sourceBank:bank,color:C,destination:D,format:67,textureBytes:[0,0,255,255],viewSwizzle:swizzle};
    const bytes=join(view,packet(10,0,[1,0,100+i]),packet(18,0,[1,0,92]),commands(test,77));poison(gl);nativeRun(tex,c,1,bytes,test.name);verifyFrame(tex,c,test,evidence,raw,bytes);
    const program=tex.lastDump.programs.find(p=>p.generation===tex.lastDump.draws[0].programGeneration);c.same(program.fragmentESSL300.includes('wv_view_0('),true,'critic composition actual sampled view wrapper');c.same(program.fragmentESSL300.includes('wv_unblended_main'),true,'critic composition actual blend wrapper');c.same(program.key.includes('sampler-view-v1'),true,'critic composition view key');
  }
  dispose(tex,c,'critic sampled view/fold composition');
'''
seeds=[0x6a09e667,0xbb67ae85,0x3c6ef372];plans=[]
for seed in seeds:
 rng=random.Random(seed);S=[rng.randrange(5,60)/64 for _ in range(4)];C=[rng.randrange(2,62)/64 for _ in range(4)];D=[rng.randrange(13,241) for _ in range(4)]
 s=base.replace('const S=[.25,.5,.75,.875], C=[.75,.125,.5,.625], D=[128,64,192,160];',f'const S={json.dumps(S)}, C={json.dumps(C)}, D={json.dumps(D)};')
 s=s.replace('rational(Math.round(v*8),8)','rational(Math.round(v*64),64)')
 s=s.replace('hostLimit=null,pad=false','hostLimit=null,pad=false')
 interception="""    if(control.reflection==='location'&&k==='getUniformLocation'&&args[1]==='wv_rgb_blend_factor')return null;
    if(control.reflection==='index'&&k==='getUniformIndices'&&args[1][0]==='wv_rgb_blend_factor')return [gl.INVALID_INDEX];
    if(['type','size'].includes(control.reflection)&&k==='getActiveUniforms'&&args[1][0]===t.getUniformIndices(args[0],['wv_rgb_blend_factor'])[0]&&args[2]===(control.reflection==='type'?gl.UNIFORM_TYPE:gl.UNIFORM_SIZE))return [control.reflection==='type'?gl.FLOAT:2];
"""
 s=s.replace("    if(k==='getParameter'",interception+"    if(k==='getParameter'",1)
 s=s.replace('packet(14,0,test.color.map(word))','packet(14,0,[.953125,.03125,.8125,.171875].map(word)),packet(14,0,test.color.map(word))')
 s=s.replace('packet(12,0,[1,0,...test.source.map(word)])','packet(12,0,[1,0,...(test.sourceBank??test.source).map(word)])')
 s=s.replace('test.discarded?[]:test.source.map(word)','test.discarded?[]:(test.sourceBank??test.source).map(word)')
 cases=[]
 for sf in [7,8,23,24]:
  for df in ([8,24] if sf in [7,23] else [7,23]):
   for fn in range(3):
    for mask in [1,2,4,8,11,14]:
     cases.append({'name':f'critic-mixed-{sf}-{df}-{fn}-{mask}','target':dict(rgbSourceFactor=sf,rgbDestinationFactor=df,alphaSourceFactor=rng.choice([6,7,8,23,24]),alphaDestinationFactor=rng.choice([3,7,8,20,23,24]),rgbFunction=fn,alphaFunction=(fn+mask)%5,mask=mask),'source':[rng.randrange(-16,97)/64 for _ in range(4)],'color':[rng.randrange(-24,89)/64 for _ in range(4)],'destination':[rng.randrange(9,247) for _ in range(4)],'format':67})
 for a,da in [(10,31),(58,223)]:
  cases.append({'name':f'critic-saturation-{a}-{da}','target':dict(rgbSourceFactor=6,rgbDestinationFactor=17,alphaSourceFactor=6,alphaDestinationFactor=17,rgbFunction=0,alphaFunction=0,mask=15),'source':[.234375,.6875,.953125,a/64],'color':C,'destination':[111,47,189,da],'format':67})
 s=s.replace('\nfunction shader(id,stage,text)', '\nBLEND_CASES.push(...'+json.dumps(cases)+');\n\nfunction shader(id,stage,text)')
 s=s.replace('  const all=join(...raw)',extra+'\n  const all=join(...raw)')
 s=s.replace('records:evidence.frames,jobs:evidence.jobs,pressure','records:evidence.frames,jobs:evidence.jobs,guards:evidence.guards,pressure')
 out=E/f'critic-{seed}.mjs';out.write_text(s);plans.append({'seed':seed,'source':S,'color':C,'destination':D,'additionalCases':cases,'harness':str(out.relative_to(R)),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'predictions':'All packet-derived normalized pixels within 1 unit; newest color wins; state-only owners restore; reused-but-unbound object cannot change retained state; four reflection failures issue no draw/recover with no native leaks; nonidentity sampler wrapper and blend wrapper both present and semantically compose.'})
(E/'fresh-plans.json').write_text(json.dumps({'schema':1,'baseSha256':hashlib.sha256(base.encode()).hexdigest(),'seeds':plans},indent=2)+'\n')
print('Prepared seeds',seeds,'with three independent full matrices,144 mixed mask/clamp cases each, and state/reflection/composition attacks')
