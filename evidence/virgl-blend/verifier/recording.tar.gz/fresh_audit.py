from pathlib import Path
import json,hashlib
from recording_audit import packet,expected,native,pixel_frame
R=Path.cwd();E=R/'evidence/virgl-blend/verifier';sha=lambda b:hashlib.sha256(b).hexdigest()
def need(ok,msg):
 if not ok:raise AssertionError(msg)
reports=[]
for seed in [1779033703,3144134277,1013904242]:
 directory=E/f'gpu-{seed}';p=directory/'report.json';text=p.read_text();j=json.loads(text);need(j['status']=='passed','fresh hardware '+str(seed));result=j['browserResult']['result'];raw=(directory/'blend-pixels.bin').read_bytes();need(sha(raw)==j['physicalPixels']['sha256'] and len(raw)==1024*2470,'raw stream binding');need(j['browserErrors']=={'console':[],'page':[],'requests':[]},'fresh browser errors');need(j['verifierHarness']['servedSha256']==sha((directory/'harness.mjs').read_bytes()),'critic harness served binding')
 # Independently bind every unmodified runtime and Wasm request; the critic module is the only harness override.
 served={x['path']:x['sha256'] for x in j['servedFiles']}
 for source in j['sources']:
  need(sha((R/source['path']).read_bytes())==source['sha256'],'fresh source drift')
  if '/'+source['path'] in served:
   wanted=j['verifierHarness']['servedSha256'] if source['path'].endswith('tests/blend-equations.mjs') else source['sha256'];need(served['/'+source['path']]==wanted,'fresh actual request custody')
 lines={}
 for no,line in enumerate(text.splitlines(),1):
  if line.strip().startswith('"name": '):lines.setdefault(json.loads(line.strip()[8:].rstrip(',')),no)
 rows=[];reportsha=sha(p.read_bytes())
 for index,row in enumerate(result['records']):
  parts=packet(row);pred=expected(row,parts);need(pred==row['expected'],'critic harness/oracle independence '+row['name']);observed=pixel_frame(raw[1024*index:1024*(index+1)],row['format']);err=max(abs(v-pred[l]) for pixel in observed for l,v in enumerate(pixel));need(err<=1,'fresh physical mismatch '+row['name']);native(row,parts)
  rows.append({'seed':seed,'record':index,'name':row['name'],'report':p.relative_to(R).as_posix(),'reportLine':lines[row['name']],'reportSha256':reportsha,'rawOffset':index*1024,'rawSha256':sha(raw),'expected':pred,'actualFirst':observed[0],'maximumUnitError':err,'held':True})
 need(len(result['guards'])==4 and {x['reflection'] for x in result['guards']}=={'location','index','type','size'},'all reflection guards');need(all(x['failure']['error']['code']=='shader-reflection-error' and x['failure']['draws']==[] and x['failure']['error']['opcode']==2 for x in result['guards']),'guard native-draw rejection provenance');need(all(x['held'] for x in result['assertions']),'false fresh predicate');need(result['quantizationBudget']==1,'fixed numerical budget')
 guardpred=[x for x in result['assertions'] if any(w in x['prediction'] for w in ['final accounting','native deletion','allocation releases','negative variant','final GL error'])];need(guardpred and all(x['held'] for x in guardpred),'cleanup predicates')
 for x in result['jobs']:need(x['gpuComplete'] and x['delay'] in [0,1,3] and x['fences']==2,'native varied schedule')
 audit=E/f'fresh-{seed}-audit.jsonl';audit.write_text(''.join(json.dumps(x)+'\n' for x in rows));reports.append({'seed':seed,'status':'HELD','frames':len(rows),'pixels':len(rows)*256,'assertions':len(result['assertions']),'sourceHead':j['gitHead'],'report':p.relative_to(R).as_posix(),'reportSha256':reportsha,'harnessSha256':j['verifierHarness']['servedSha256'],'rawSha256':sha(raw),'audit':audit.name,'auditSha256':sha(audit.read_bytes()),'maxUnitError':max(x['maximumUnitError'] for x in rows),'reflectedGuardFailures':result['guards'],'zeroBudgetDeletionPredicates':len(guardpred),'novelCompositionFrames':[x for x in rows if 'view-fold' in x['name']],'stateOnlyRestoreFrames':[x for x in rows if 'owner-restore' in x['name'] or 'subcontext-restore' in x['name']]})
(E/'fresh-audit.json').write_text(json.dumps({'schema':1,'task':'E6-T11d2','status':'HELD','reports':reports},indent=2)+'\n');print(json.dumps([{k:r[k] for k in ['seed','status','frames','pixels','assertions','maxUnitError','rawSha256']} for r in reports],indent=2))
