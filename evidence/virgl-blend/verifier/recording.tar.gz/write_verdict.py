from pathlib import Path
import hashlib,json
R=Path.cwd();E=R/'evidence/virgl-blend/verifier';sha=lambda b:hashlib.sha256(b).hexdigest()
M=json.loads((E/'manifest.json').read_text()); C=json.loads((E/'citations.json').read_text())
def cite(name):
 p=E/name; return f'`{p.relative_to(R)}:1` SHA256 `{sha(p.read_bytes())}`'
def point(name):
 x=C[name]; return f'`{x["path"]}:{x["line"]}` SHA256 `{x["sha256"]}`'
def frame(name):
 x=C[name]['frame']; return f'{point(name)} (original `{x.get("report",x.get("source"))}:{x["reportLine"]}`, raw offset {x["rawOffset"]}, raw SHA256 `{x["rawSha256"]}`)'
text=f'''\n### 2026-10-09 — fresh verifier — VERDICT: verified

VERDICT: verified

Reviewed frozen source `0ed130ff0b9a3efa1273ac485d87dad656efcef4` from
verified parent `3c6295a93d6b088c62a5c6f1cc434f226e090340`; submission
`2b720fcac4da27b57397aa70ed3ba84a4d2c0b1e`. Predictions preceded state
inspection; runtime remained unchanged. Detailed predictions: {cite('predictions.json')}.

- P1 authentication — HELD. Independently reopened all 242 worker members and checked
  sizes, archive/index digests, 780 hot/cold tracked-source bindings, 232 receipt files,
  actual served/coverage sources, exact fault substitutions, and generated hot/cold/current
  JS/Wasm equality. {cite('authentication.json')}.
- P2 wire/native enums — HELD. Pinned C compiled/executed freshly with native and
  ASan/UBSan clang; both match the sealed enum output. Equations 0..4 and 15 source
  factors agree. Destination SATURATE, unknown/dual-source, active zero, logic/independent
  and extra targets reject with provenance. {cite('enum-audit.json')}; {point('wire')}.
- P3 physical equations — HELD. Independent exact IEEE32/Fraction packet decoding
  checked full dumps and all 589,312 pixels in each 2,302-frame original hot/cold run,
  including all 2,100 RGB/alpha pair/equation cases, masks, clamps and X-alpha storage.
  Maximum permitted deviation is one stored component unit. {cite('recording-audit.json')}.
- P4 fold/native settings — HELD. Actual cache identities/reflection/uploads use owned
  clamped source coefficients, native RGB ONE, and untouched alpha. MIN/MAX and terminal
  discard avoid the variant. {frame('mixed')}; {frame('min')}; {point('terminal')}.
- P5 lifetime/restoration/eviction — HELD. Fresh state-only A/B/A and subcontext draws
  restore colors, banks and factors after host poisoning; latest-color and destroy/reused-ID
  binding produce distinct predicted pixels. {frame('restore')}; {frame('lastColor')};
  {frame('reuse')}; {frame('subcontext')}; bounded program/state eviction: {point('eviction')}.
- P6 bounds/cleanup — HELD. Actual native allocation, GLSL-output and host-component
  failures reject before drawing, ordinary/mixed recovery succeeds, and disposal deletes
  all native objects and reaches zero budgets. Fresh linked location/index/type/size faults
  also reject. {point('allocation')}; {point('size')}; {point('components')};
  {point('reflection')}; {point('cleanup')}; {cite('fresh-audit.json')}.
- P7 schedules — HELD. Independent seeded physical runs exercise owned bytes after
  caller mutation and delayed real fences 0/1/3, with bounded completion and correct uploads.
  {point('async')}; complete jobs/pixels in {cite('fresh-audit.json')}.
- P8 sabotage/oracle — HELD. All six original hot/cold faults fail their named equation,
  factor or fold pixel. Fresh actual fold sabotage deviates 25 units; promoted test detects
  91 units on its first frame: predicted `[108,149,164,41]`, observed `[123,149,255,41]`.
  Forging stored expectations to the corrupted actual value still fails the independent
  packet oracle. {cite('final-audit.json')}.
- P9 independent attacks/novel seam — HELD. Seeds 1779033703/3144134277/1013904242
  each pass 2,470 frames and 25,859 predicates with zero browser errors, using binary-exact
  sixty-fourth colors, all eight mixed classes, masks 1/2/4/8/11/14, distinct alpha equations,
  and both saturation minima. Novel physical nonidentity sampler-view/blend wrapper A/B/A
  composition preserves both semantics: {frame('composition')}; {cite('fresh-audit.json')}.
  The promoted actual WebGL probe rejects all eight forbidden native pairs with
  INVALID_OPERATION and unchanged factors: {cite('final-audit.json')}.
- P10 coverage/carry — HELD. Every added runtime line (10 decoder, 56 state) has an
  authenticated positive V8 witness; zero hunk gaps. {cite('coverage-audit.json')}.
  Narrow unreachable false arms of checked output/main and trusted draw-identity guards
  are classified individually, without waiving packet behavior: {cite('guard-waivers.json')}.
  The unchanged D1 checked compiler/private limits and older dependency HELD results carry
  forward after authenticating its 54-record seal and dependency equality; 44 affected
  retained hot/cold gates hold. {cite('carry-forward.json')}.
- P11 isolation — HELD. The single final frozen-head pristine clone was clean before/after,
  scrubbed overrides and served its own matching generated fixed-memory Wasm. Actual retained
  clone artifacts were rehashed; another clone/full compiler run is unnecessary.
  {cite('authentication.json')}.

Critic fixture correction (not a product refutation): the initial novel attack reused
public ID 92 for a sampler and view; the renderer correctly rejected it. The corrected
100/101/102 views pass with unchanged runtime. Initial evidence is preserved:
{cite('prediction-correction.json')}.

SUITE: promote `renderer/virgl-command/tests/blend-boundaries.mjs` SHA256
`9ccadf5102df2c93d9b58a2f88c7a7a16b2b02e4f663bc3ac87c79fb3f70d7c7`.
`node renderer/virgl-command/tests/blend-boundaries.mjs --output evidence/virgl-blend/verifier/promoted`
passes 22 frames / 633 predicates. Critic replay/audit commands and native enum commands
are sealed with the reports, raw pixels, actual harnesses, captures and coverage.

Critic seal: `evidence/virgl-blend/verifier/recording.tar.gz`, {M['records']} records,
{M['archiveBytes']:,} bytes; SHA256 `{M['archiveSha256']}`;
record-index SHA256 `{M['recordIndexSha256']}`. Reopened and rehashed every member.
No FAILED or NEEDS EVIDENCE acceptance result remains. Authority is confined to normalized
single-target blend; no production capset, guest boot, GPU portability or performance claim.
'''
task=R/'tasks/epic-6-transcendence/E6-T11d2-single-target-blend.md'
s=task.read_text();assert s.count('status: implemented')==1 and 'fresh verifier — VERDICT: verified' not in s
s=s.replace('status: implemented','status: verified',1);task.write_text(s+text)
print('Appended verifier verdict and set verified.')
