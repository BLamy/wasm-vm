"""Critic-owned packet-derived rational oracle; never imports worker receipt/test tables."""
from pathlib import Path
from fractions import Fraction as Q
import hashlib,json,struct
R=Path.cwd();E=R/'evidence/virgl-blend/verifier';U=E/'unpacked'
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(v,m):
 if not v: raise AssertionError(m)
def cap(v): return min(Q(1),max(Q(0),v))
def rnd(q): return (2*q.numerator+q.denominator)//(2*q.denominator)
def f32(w): return Q(struct.unpack('<f',struct.pack('<I',w))[0])
# Independent pinned Gallium ordinals, from the compiled/header oracle.
SOURCE=(1,2,3,4,5,6,7,8,17,18,19,20,21,23,24);DEST=tuple(x for x in SOURCE if x!=6)
GE=(0x8006,0x800a,0x800b,0x8007,0x8008)
GF=dict(zip(SOURCE,(1,0x300,0x302,0x304,0x306,0x308,0x8001,0x8003,0,0x301,0x303,0x305,0x307,0x8002,0x8004)))
def coef(f,i,s,d,c):
 if f==1:return Q(1)
 if f==17:return Q(0)
 if f==6:return Q(1) if i==3 else min(s[3],1-d[3])
 j={2:i,3:3,4:3,5:i,7:i,8:3,18:i,19:3,20:3,21:i,23:i,24:3}[f]
 vec={2:s,3:s,4:d,5:d,7:c,8:c,18:s,19:s,20:d,21:d,23:c,24:c}[f];v=vec[j]
 return 1-v if f>=18 else v

def packet(row):
 raw=bytes.fromhex(row.get('preparedPacketHex',row['packetHex'])); at=0; blend=color=bank=clear=draw=None; ids={}; deletion=[]
 while at<len(raw):
  h=struct.unpack_from('<I',raw,at)[0]; op=h&255;kind=(h>>8)&255;n=h>>16;end=at+4+4*n
  need(end<=len(raw),'packet truncation');w=struct.unpack_from('<'+'I'*n,raw,at+4)
  if op==1 and kind==1:need(n==11 and w[1:3]==(0,0) and w[4:]==(0,)*7,'blend excluded fields');blend=w[3];ids['created']=w[0]
  if op==2 and kind==1:ids['bound']=w[0]
  if op==3 and kind==1:deletion.append(w[0])
  if op==14:color=w
  if op==12:need(w[:2]==(1,0),'source bank stage');bank=w[2:]
  if op==7:need(w[0]==4,'clear color only');clear=w[1:5]
  if op==8:draw=w
  at=end
 need(at==len(raw) and None not in (blend,color,bank,clear,draw),'packet closure')
 need(draw==(0,4,5,0,1,0,0,0,0,0,0xffffffff,0),'draw closure')
 t={'rgbFunction':blend>>1&7,'rgbSourceFactor':blend>>4&31,'rgbDestinationFactor':blend>>9&31,'alphaFunction':blend>>14&7,'alphaSourceFactor':blend>>17&31,'alphaDestinationFactor':blend>>22&31,'mask':blend>>27&15}
 need(t==row['target'],'independent wire fields');need(bool(blend&1)==(row.get('enabled') is not False),'enable custody')
 need([float(f32(w)) for w in bank]==row.get('sourceBank',row['source']) and [float(f32(w)) for w in color]==row['color'],'row/binary color custody')
 if not row.get('stateOnly'):need(ids['created']==ids['bound'] and ids['created'] in deletion,'destruction-before-draw exercised')
 source=[cap(f32(w)) for w in bank]
 if 'textureBytes' in row:
  # Independent literal texture origin plus original-form view selectors.
  selectors=[];cursor=0;issued=bytes.fromhex(row['packetHex'])
  while cursor<len(issued):
   h=struct.unpack_from('<I',issued,cursor)[0];n=h>>16;words=struct.unpack_from('<'+'I'*n,issued,cursor+4)
   if h&255==1 and h>>8&255==6:selectors=[words[5]>>(3*i)&7 for i in range(4)]
   cursor+=4+4*n
  need(selectors==row['viewSwizzle'],'actual sampled view selectors');source=[Q(row['textureBytes'][x],255) for x in selectors];need([float(x) for x in source]==row['source'],'literal sampled/swizzled source')
 return raw,t,bool(blend&1),list(bank),source,[cap(f32(w)) for w in color],[cap(f32(w)) for w in clear]

def expected(row,parts):
 raw,t,on,bank,s,c,dc=parts; scale=(1023,1023,1023,3) if row['format']==233 else (255,)*4
 stored=[scale[i] if i==3 and row['format']!=67 else rnd(dc[i]*scale[i]) for i in range(4)];d=[Q(x,k) for x,k in zip(stored,scale)];out=[]
 for i in range(4):
  if row.get('discarded') or not t['mask']>>i&1 or i==3 and row['format']!=67:out.append(stored[i]);continue
  if not on:v=s[i]
  else:
   stage='alpha' if i==3 else 'rgb';q=t[stage+'Function']
   if q==3:v=min(s[i],d[i])
   elif q==4:v=max(s[i],d[i])
   else:
    l=s[i]*coef(t[stage+'SourceFactor'],i,s,d,c);r=d[i]*coef(t[stage+'DestinationFactor'],i,s,d,c)
    v={0:l+r,1:l-r,2:r-l}[q]
  out.append(rnd(cap(v)*scale[i]))
 return out

def native(row,p):
 raw,t,on,bank,s,c,clear=p;n=row['native']; rf=t['rgbFunction'] if on else 0;af=t['alphaFunction'] if on else 0
 sf=t['rgbSourceFactor'] if on else 1;df=t['rgbDestinationFactor'] if on else 17;sa=t['alphaSourceFactor'] if on else 1;da=t['alphaDestinationFactor'] if on else 17
 mixed=on and rf<3 and ((sf in (7,23) and df in (8,24)) or (sf in (8,24) and df in (7,23)))
 need(n['op']=='drawArrays' and n['args']==[5,0,4] and n['blend']==on,'actual native command/enable')
 need(n['equations']==[GE[rf],GE[af]],'actual independent equation selection')
 need(n['factors']==[1 if rf>=3 or mixed else GF[sf],0 if rf>=3 else GF[df],1 if sa==6 else GF[sa],GF[da]],'actual native factors')
 need(n['sourceWords']==([] if row.get('discarded') else bank),'actual word upload')
 need(n['color']==row['color'],'last supplied color')
 need(n['mask']==[bool(t['mask']>>i&1) and (i!=3 or row['format']==67) for i in range(4)],'actual color mask')
 d=row['dump'];need(d['complete'] and d['dropped']=={'submissions':0,'programs':0,'draws':0,'outcomes':0},'complete debug capture');need(len(d['draws'])==len(d['submissions'])==1 and d['submissions'][0]['hex']==row['packetHex'],'full original-form packet capture')
 draw=d['draws'][0];need(draw['bindings']['blendColor']==row['color'] and draw['bindings']['constants'][1]==bank,'owned draw snapshot colors/banks')
 need(d['outcomes'][0]['ok'] and d['outcomes'][0]['draws']==1,'actual successful draw outcome')
 sk=json.loads(draw['stateKey']);need(sk['blendColor']==row['color'] and sk['constants'][1]==bank,'state cache colors/banks')
 need(sk['blend']['renderTargets'][0]['rgbSourceFactor']==t['rgbSourceFactor'],'owned retained blend state')
 need(draw['bindings']['blend']['handle']==sk['blend']['handle'],'bound/dead public ID identity')
 program=next(x for x in d['programs'] if x['generation']==draw['programGeneration']);need(program['key']==draw['programKey']==sk['programKey'],'variant/state/draw identity')
 fold=mixed and not row.get('discarded');need((n['fold'] is not None)==fold,'variant necessity')
 if fold:
  v=[c[3]]*3 if sf in (8,24) else c[:3];v=[1-x for x in v] if sf in (23,24) else v
  need(n['fold']==[float(x) for x in v]+[1],'owned clamped inverse-aware uniform')
  need(program['key'].endswith('|blend-source-constant-v1:'+str(sf)),'variant key factor')
  need(program['reflection']['blend']=={'sourceFactor':sf,'uniform':'wv_rgb_blend_factor','type':'vec4','count':1},'actual vec4 reflection')
  need('fsout_c0.rgb=clamp(fsout_c0.rgb,0.0,1.0)*wv_rgb_blend_factor.rgb;' in program['fragmentESSL300'] and 'fsout_c0.a=' not in program['fragmentESSL300'],'RGB clamp-fold; alpha untouched')
 else:need('blend-source-constant' not in program['key'] and 'wv_rgb_blend_factor' not in program['fragmentESSL300'],'native/factor-free/discard lacks unnecessary variant')
 return mixed,draw['command']['contextId'],draw['command']['subContextId'],program['generation']

def pixel_frame(raw,fmt):
 if fmt==233:return [[w&1023,w>>10&1023,w>>20&1023,w>>30] for w in struct.unpack('<256I',raw)]
 return [list(raw[i:i+4]) for i in range(0,len(raw),4)]

def audit(prefix,name,mode=None):
 reportpath=U/prefix/name/'report.json';reporttext=reportpath.read_text();r=json.loads(reporttext); rows=r['partial']['frames'] if mode else r['browserResult']['result']['records'];pixinfo=r['faultPixels'] if mode else r['physicalPixels'];raw=(U/prefix/name/pixinfo['path']).read_bytes();need(sha(raw)==pixinfo['sha256'] and len(raw)==1024*len(rows),'raw extent/digest')
 records=[];failed=[];sat=set();mix=set(); masks=set(); contexts=set();factorfree=0; rh=sha(reportpath.read_bytes()); ph=sha(raw);lineMap={}
 for lineNo,line in enumerate(reporttext.splitlines(),1):
  if line.strip().startswith('"name": '):
   value=json.loads(line.strip()[8:].rstrip(','));lineMap.setdefault(value,lineNo)
 for i,row in enumerate(rows):
  parts=packet(row); exp=expected(row,parts);need(row['expected']==exp,'worker prediction not independent '+row['name']);observed=pixel_frame(raw[1024*i:1024*(i+1)],row['format']);diff=max(abs(p[l]-exp[l]) for p in observed for l in range(4));held=diff<=1
  if not held:failed.append(row['name'])
  if not mode:
   mixed,ctx,sub,gen=native(row,parts);contexts.add((ctx,sub));masks.add(row['target']['mask'])
   if mixed:mix.add((row['target']['rgbSourceFactor'],row['target']['rgbDestinationFactor']))
   if row['target']['rgbFunction']>=3:factorfree+=1
   if row['target']['rgbSourceFactor']==6:
    d=Q(row['destination'][3],255) if row['format']==67 else Q(1);sat.add('source' if parts[4][3]<=1-d else 'destination')
  line=lineMap[row['name']]
  records.append({'record':i,'name':row['name'],'source':str(reportpath.relative_to(R)),'reportLine':line,'reportSha256':rh,'rawSha256':ph,'rawOffset':1024*i,'expected':exp,'observedFirst':observed[0],'maximumUnitError':diff,'held':held})
 need(failed==([] if not mode else [{'equation':'rgb-0-1-1','factor':'rgb-0-1-4','fold':'rgb-0-7-8'}[mode]]),'physical oracle failure set '+str(failed))
 if not mode:
  need(len(rows)==2302,'full frames');base=[f'{st}-{fn}-{s}-{d}' for st in ['rgb','alpha'] for fn in range(5) for s in SOURCE for d in DEST];need([x['name'] for x in rows[:2100]]==base,'exhaustive independent matrices');need(sat=={'source','destination'},'both saturation branches');need(len(mix)==8,'all 8 mixed classes');need(contexts=={(1,0),(2,0),(1,42)},'actual context/subcontext execution');need(all(x['held'] for x in r['browserResult']['result']['assertions']),'failed assertion in recording')
 out=E/(prefix+'-'+name+'-audit.jsonl');out.write_text(''.join(json.dumps(x)+'\n' for x in records))
 return {'run':prefix,'name':name,'records':len(rows),'pixels':len(rows)*256,'failedFrames':failed,'status':'HELD','rationalOracle':'IEEE32 packet words; integer-normalized destination; independent Q factors/equations; no worker expected inputs','audit':out.name,'auditSha256':sha(out.read_bytes()),'rawSha256':sha(raw),'maximumUnitError':max(x['maximumUnitError'] for x in records),'saturationBranches':sorted(sat),'mixedPairs':sorted(mix),'masks':sorted(masks),'contexts':sorted(contexts),'factorFreeFrames':factorfree}

def main():
 reports=[]
 for prefix in ['hot','cold']:
  for name,mode in [('hardware',None),('fault-equation','equation'),('fault-factor','factor'),('fault-fold','fold')]:reports.append(audit(prefix,name,mode))
 (E/'recording-audit.json').write_text(json.dumps({'schema':1,'task':'E6-T11d2','status':'HELD','reports':reports},indent=2)+'\n');print(json.dumps(reports,indent=2))
if __name__=='__main__':main()
