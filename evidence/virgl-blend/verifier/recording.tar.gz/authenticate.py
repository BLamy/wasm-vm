from pathlib import Path, PurePosixPath
import hashlib, json, tarfile, subprocess
R=Path.cwd(); E=R/'evidence/virgl-blend/verifier'; W=R/'evidence/virgl-blend/worker'; H='0ed130ff0b9a3efa1273ac485d87dad656efcef4'
sha=lambda b:hashlib.sha256(b).hexdigest()
need=lambda ok,msg: None if ok else (_ for _ in ()).throw(AssertionError(msg))
manifest=json.loads((W/'manifest.json').read_bytes()); indexraw=(W/'records.json').read_bytes(); ix=json.loads(indexraw); ar=(W/'recording.tar.gz').read_bytes()
need(sha(ar)=='ee7ef868a4e8d98e8121c37116a8d3d06497b6cc88ef3c9c4581254f3a522b1f','archive claim');need(sha(indexraw)=='1c6b9f26fae9591017986598f241272b084505d251e34460c5c315f322108d7c','index claim')
need(manifest['sourceHead']==ix['sourceHead']==H and manifest['records']==len(ix['records'])==242,'frozen/head record count')
expected={r['path']:r for r in ix['records']};need(len(expected)==242,'unique index'); unpack=E/'unpacked';unpack.mkdir(exist_ok=True)
with tarfile.open(W/'recording.tar.gz','r:gz') as tf:
 ms=tf.getmembers();need(len(ms)==242 and {m.name for m in ms}==set(expected),'unique exact archive closure')
 for m in ms:
  need(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts,'unsafe tar path')
  raw=tf.extractfile(m).read(); row=expected[m.name];need(len(raw)==row['bytes'] and sha(raw)==row['sha256'],'sealed record drift '+m.name)
  p=unpack/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
source_rows=[];generated=[];file_checks=[];report_checks=[]
for prefix in ['hot','cold']:
 receipt=json.loads((unpack/prefix/'receipt.json').read_bytes())
 need(receipt['gitHead']==H and receipt['status']=='passed','receipt frozen status '+prefix)
 for name,digest in receipt['sources'].items():
  original=subprocess.check_output(['git','show',H+':'+name],cwd=R);current=(R/name).read_bytes()
  need(sha(original)==sha(current)==digest,'frozen source equivalence '+name)
  source_rows.append({'run':prefix,'source':name,'sha256':digest})
 for name,digest in receipt['files'].items():
  need(sha((unpack/prefix/name).read_bytes())==digest,'receipt file '+prefix+'/'+name);file_checks.append(prefix+'/'+name)
 for name,digest in receipt['generated'].items():
  need(sha((unpack/(prefix+'-generated')/name).read_bytes())==digest,'generated custody');generated.append({'run':prefix,'source':name,'sha256':digest,'currentEquivalent':sha((R/name).read_bytes())==digest})
 for name in ['hardware','fault-equation','fault-factor','fault-fold']:
  p=unpack/prefix/name/'report.json';report=json.loads(p.read_bytes());need(report['gitHead']==H,'browser head')
  mutation=report.get('mutation',{});served={s['path']:s for s in report['servedFiles']}
  need(report['browserErrors']=={'console':[],'page':[],'requests':[]},'browser errors');need(not report['browser']['headless'],'headed authority')
  for s in report['sources']:
   digest=sha((unpack/(prefix+'-generated')/s['path']).read_bytes()) if '/build/' in s['path'] else sha(subprocess.check_output(['git','show',H+':'+s['path']],cwd=R))
   need(s['sha256']==digest,'browser source binding '+s['path'])
   if '/'+s['path'] in served:
    sd=mutation['servedSha256'] if s['path']==mutation.get('path') else digest;need(served['/'+s['path']]['sha256']==sd,'served source binding')
  cov=json.loads((unpack/prefix/name/report['browserCoverage']['path']).read_bytes())
  for s in cov['scripts']:need(s['sha256']==served['/'+s['source']]['sha256'],'coverage served binding')
  if mutation:
   original=subprocess.check_output(['git','show',H+':'+mutation['path']],cwd=R);actual=(unpack/prefix/name/'mutation-source.mjs').read_bytes()
   need(sha(original)==mutation['originalSha256'] and original.count(mutation['needle'].encode())==1 and original.replace(mutation['needle'].encode(),mutation['replacement'].encode())==actual and sha(actual)==mutation['servedSha256'],'fault source custody')
  report_checks.append({'run':prefix,'report':name,'status':report['status'],'servedFiles':len(served),'gpu':report['browser']['gpu']['devices'],'sourceBindings':len(report['sources'])})
need(len(source_rows)==780,'390 sources each')
cold=json.loads((unpack/'cold/report.json').read_bytes());need(cold['gitHead']==cold['cloneHead']==H and cold['status']=='passed' and cold['statusBefore']==cold['statusAfter']=='','cold clone pristine')
need(cold['receiptSha256']==sha((unpack/'cold/receipt.json').read_bytes()),'cold receipt binding')
clone=Path(cold['clone']);clonehead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip();need(clonehead==H,'cold retained checkout')
for s in generated:
 if s['run']=='cold':need(sha((clone/s['source']).read_bytes())==s['sha256'],'retained cold generated binding')
need(subprocess.check_output(['git','diff','--name-only',H,'HEAD','--','renderer','tools'],cwd=R,text=True).strip()=='','submission runtime equivalence')
auth={'schema':1,'status':'HELD','sourceHead':H,'archiveSha256':sha(ar),'indexSha256':sha(indexraw),'records':242,'trackedSourceBindings':source_rows,'generatedBindings':generated,'receiptFiles':file_checks,'browserBindings':report_checks,'cold':cold,'retainedColdHead':clonehead,'unpacked':str(unpack),'submissionRuntimeEquivalent':True}
(E/'authentication.json').write_text(json.dumps(auth,indent=2)+'\n');print(json.dumps({k:auth[k] for k in ['status','sourceHead','archiveSha256','indexSha256','records','submissionRuntimeEquivalent']}));print('Tracked source bindings:',len(source_rows),'Receipt file bindings:',len(file_checks));print('Generated:',generated);print('Cold:',clone)
