from pathlib import Path
import hashlib,json,re,subprocess
R=Path.cwd();E=R/'evidence/virgl-blend/verifier';sha=lambda b:hashlib.sha256(b).hexdigest();P='3c6295a93d6b088c62a5c6f1cc434f226e090340';H='0ed130ff0b9a3efa1273ac485d87dad656efcef4'
# Every frozen added runtime line; narrow waiver only for syntax/comments, plus actual branch records.
files=['renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs'];evidence=list((E/'unpacked').glob('*/hardware/browser-coverage.json'))+list(E.glob('gpu-[0-9]*/browser-coverage.json'))
results=[];zero=[]
for name in files:
 raw=(R/name).read_bytes();text=raw.decode();lineparts=text.splitlines(keepends=True);lines={};off=0
 for i,s in enumerate(lineparts,1):lines[i]=(off,off+len(s.encode('utf-16-le'))//2,s);off=lines[i][1]
 diff=subprocess.check_output(['git','diff','--unified=0',P,H,'--',name],text=True);added=[];current=None
 for s in diff.splitlines():
  if s.startswith('@@'):current=int(re.search(r'\+(\d+)',s).group(1));continue
  if s.startswith('+++') or s.startswith('---'):continue
  if current is None:continue
  if s.startswith('+'):added.append(current);current+=1
  elif s.startswith('-'):pass
  else:current+=1
 cov=[]
 for p in evidence:
  j=json.loads(p.read_text());x=next((x for x in j['scripts'] if x['source']==name),None)
  if x and x['sha256']==sha(raw):cov.append((p.relative_to(R).as_posix(),x['coverage']['functions']))
 for i in added:
  start,end,line=lines[i];a=start+len(line)-len(line.lstrip());b=start+len(line.rstrip());body=line.strip();samples=[]
  for p,functions in cov:
   for f in functions:
    if not f['ranges'] or not (f['ranges'][0]['startOffset']<=a<f['ranges'][0]['endOffset']):continue
    ranges=[x for x in f['ranges'] if x['startOffset']<=a<x['endOffset']];x=min(ranges,key=lambda r:r['endOffset']-r['startOffset']);samples.append({'record':p,'function':f['functionName'],'count':x['count'],'range':[x['startOffset'],x['endOffset']]})
  syntax=body.startswith('//') or body in ('}', '};', '}', 'else {') or body.startswith('const BLEND_EQUATIONS') or body.startswith('const BLEND_FACTORS') or body.startswith('6: "SRC_ALPHA') or body.startswith('19: "ONE_MINUS')
  held=[s for s in samples if s['count']>0]
  if held:classification='executed';reason='Authenticated V8 block/function count at first runtime token.'
  elif syntax:classification='waived';reason='Declarative pinned table, comment, or brace has no standalone behavioral execution.'
  else:classification='needs-evidence';reason='No positive authenticated execution at the added runtime token.';zero.append([name,i,body,samples])
  results.append({'source':name,'line':i,'text':body,'classification':classification,'reason':reason,'witnesses':held[:5],'counts':samples if not held else None})
 branches=[]
 for p,functions in cov:
  for f in functions:
   for x in f['ranges']:
    if x['count']==0 and any(lines[i][0]<=x['startOffset']<lines[i][1] for i in added):branches.append({'record':p,'function':f['functionName'],'range':[x['startOffset'],x['endOffset']],'snippet':text.encode('utf-16-le')[2*x['startOffset']:2*x['endOffset']].decode('utf-16-le')})
 print(name,'added lines',len(added),'cold/hot/fresh coverage witnesses',len(cov),'zero ranges starting in added lines',len(branches));
 (E/(Path(name).stem+'-unhit-branches.json')).write_text(json.dumps(branches,indent=2)+'\n')
j={'schema':1,'task':'E6-T11d2','parent':P,'sourceHead':H,'evidence':[{ 'path':p.relative_to(R).as_posix(),'sha256':sha(p.read_bytes())} for p in evidence],'lines':results,'needsEvidence':zero,'counts':{k:sum(x['classification']==k for x in results) for k in ['executed','waived','needs-evidence']}}
(E/'coverage-audit.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j['counts']));print('Gaps:',zero)
