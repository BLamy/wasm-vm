from pathlib import Path
import ast,json
R=Path.cwd();E=R/'evidence/virgl-blend/verifier';base=(E/'critic-1779033703.mjs').read_text()
# Retain the independently exercised small owner/reflection/view composition suite.
start=base.index('  // Fresh critic cases:');end=base.index('  const all=join(...raw)',start);extra=base[start:end]
prefix=base[:base.index('export async function runBrowserBlendAcceptance()')]
a=prefix.index('export const BLEND_CASES=[];');b=prefix.index('function shader(id,stage,text)',a)
prefix=prefix[:a]+"const BLEND_CASES=[{name:'critic-mixed-base',target:target(7,8,3,19,0,2),source:S,color:C,destination:D,format:67}];\n\n"+prefix[b:]
body='''export async function runBrowserBlendBoundaries(){const c=checks(),wire=runBlendWireAcceptance(),evidence={frames:[],jobs:[]};window.__blendEvidence=evidence;
  const canvas=document.querySelector('#gpu'),gl=canvas.getContext('webgl2',{alpha:true,antialias:false,depth:false,stencil:false,preserveDrawingBuffer:true});c.same(Boolean(gl),true,'actual WebGL2');
  const debug=gl.getExtension('WEBGL_debug_renderer_info'),gpu={vendor:gl.getParameter(debug?.UNMASKED_VENDOR_WEBGL??gl.VENDOR),renderer:gl.getParameter(debug?.UNMASKED_RENDERER_WEBGL??gl.RENDERER)};
  c.same(/swiftshader|llvmpipe|softpipe|lavapipe/i.test(gpu.renderer),false,'physical hardware renderer');
  // This is the WebGL API prohibition the physical fragment fallback must avoid.
  for(const sf of [gl.CONSTANT_COLOR,gl.ONE_MINUS_CONSTANT_COLOR,gl.CONSTANT_ALPHA,gl.ONE_MINUS_CONSTANT_ALPHA])
    for(const df of ([gl.CONSTANT_COLOR,gl.ONE_MINUS_CONSTANT_COLOR].includes(sf)?[gl.CONSTANT_ALPHA,gl.ONE_MINUS_CONSTANT_ALPHA]:[gl.CONSTANT_COLOR,gl.ONE_MINUS_CONSTANT_COLOR])){
      gl.blendFuncSeparate(gl.ONE,gl.ZERO,gl.ONE,gl.ZERO);gl.blendFuncSeparate(sf,df,gl.ONE,gl.ZERO);
      c.same(gl.getError(),gl.INVALID_OPERATION,'native WebGL rejects mixed constants '+sf+'/'+df);
      c.same([gl.getParameter(gl.BLEND_SRC_RGB),gl.getParameter(gl.BLEND_DST_RGB)],[gl.ONE,gl.ZERO],'native rejection preserves earlier valid state');
    }
  const bridge=await createVirglShaderBridge(),raw=[],fault=BLEND_CASES[0];
'''
tail='''  const all=join(...raw),binary=[];for(let at=0;at<all.length;at+=16384)binary.push(String.fromCharCode(...all.subarray(at,at+16384)));
  for(const frame of evidence.frames)delete frame.pixels;
  return{status:'passed',guestExecution:false,productionNegotiation:false,gpu,wire,assertions:c.rows,records:evidence.frames,jobs:evidence.jobs,guards:evidence.guards,
    rawPixelsBase64:btoa(binary.join('')),rawBytes:all.length,quantizationBudget:1,frames:evidence.frames.length};
}
'''
# The same headed browser capture driver is embedded so this promotion has a standalone acceptance command.
wrapper=(R/'tools/verify-virgl-blend-equations.mjs').read_text();driver=wrapper[wrapper.index('const options={}'):]
driver=driver.replace("'renderer/virgl-command/tests/blend-equations.mjs'","'renderer/virgl-command/tests/blend-boundaries.mjs'")
driver=driver.replace('runBrowserBlendAcceptance','runBrowserBlendBoundaries')
driver=driver.replace("  const {runBlendWireAcceptance}=await import(pathToFileURL(path.join(repo,'renderer/virgl-command/tests/blend-boundaries.mjs')));report.native=runBlendWireAcceptance();","  report.native=runBlendWireAcceptance();")
driver=driver.replace("'tools/verify-virgl-blend-equations.mjs',","'tools/verify-virgl-blend-equations.mjs',")
driver=driver.replace("import('/renderer/virgl-command/tests/blend-equations.mjs')","import('/renderer/virgl-command/tests/blend-boundaries.mjs')")
node='''\n// node renderer/virgl-command/tests/blend-boundaries.mjs --output target/evidence/virgl-blend-boundaries
async function runNodeBlendBoundaries(){
  const {default:assert}=await import('node:assert/strict'),{execFileSync}=await import('node:child_process');
  const {default:fs}=await import('node:fs/promises'),{createServer}=await import('node:http');
  const {default:os}=await import('node:os'),{default:path}=await import('node:path'),{pathToFileURL}=await import('node:url');
  const {repo,sha256}=await import('../../../tools/virgl-command/fixtures.mjs');
'''+driver+'\n}\nif(typeof process===\'object\'&&process.versions?.node){const {fileURLToPath}=await import(\'node:url\');if(process.argv[1]===fileURLToPath(import.meta.url))await runNodeBlendBoundaries();}\n'
out=R/'renderer/virgl-command/tests/blend-boundaries.mjs';out.write_text('// Fresh critic promotion: independently predicted owner restoration, native reflection rejection, and sampler-view/blend composition.\n'+prefix+body+extra+tail+node)
print(out)
