from pathlib import Path
import json,hashlib,copy,subprocess
from recording_audit import packet,expected,native,pixel_frame
R=Path.cwd();E=R/'evidence/virgl-blend/verifier';sha=lambda b:hashlib.sha256(b).hexdigest()
def need(ok,m):
 if not ok:raise AssertionError(m)
results={};faults=[]
for name,first in [('sabotage-fold','rgb-0-7-8'),('sabotage-promoted','critic-owner-init-1')]:
 directory=E/name;p=directory/'report.json';r=json.loads(p.read_text());need(r['status']==r['browserResult']['status']=='failed','sabotage status');need(r['browserErrors']=={'console':[],'page':[],'requests':[]},'unrelated sabotage errors');need(r['partial']['frames'][-1]['name']==first and first+' rational physical pixels' in r['failure']['message'],'precise source fault oracle')
 state=(R/'renderer/virgl-command/state.mjs').read_bytes();mut=(directory/'mutation-source.mjs').read_bytes();need(sha(state)==r['mutation']['originalSha256'] and sha(mut)==r['mutation']['servedSha256'] and state.count(r['mutation']['needle'].encode())==1 and state.replace(r['mutation']['needle'].encode(),r['mutation']['replacement'].encode())==mut,'actual single-boundary served mutation');need(next(x for x in r['servedFiles'] if x['path']=='/renderer/virgl-command/state.mjs')['sha256']==sha(mut),'source fault request custody')
 raw=(directory/'fault-pixels.bin').read_bytes();need(sha(raw)==r['faultPixels']['sha256'],'source fault raw');bad=[];last=None
 for i,row in enumerate(r['partial']['frames']):
  parts=packet(row);pred=expected(row,parts);need(row['expected']==pred,'independent source-fault prediction');actual=pixel_frame(raw[1024*i:1024*(i+1)],row['format']);err=max(abs(v-pred[l]) for pix in actual for l,v in enumerate(pix))
  if err>1:bad.append(row['name']);last={'name':row['name'],'frame':i,'rawOffset':i*1024,'predicted':pred,'actual':actual[0],'maximumUnitError':err}
 need(bad==[first],'source fault falsification exact set');faults.append({'status':'HELD','name':name,'report':p.relative_to(R).as_posix(),'reportSha256':sha(p.read_bytes()),'servedMutationSha256':sha(mut),'rawSha256':sha(raw),'firstFailure':last})
 # A forged expected oracle equal to the corrupted hardware must not pass the independent packet oracle.
 forged=copy.deepcopy(r['partial']['frames'][-1]);forged['expected']=last['actual'];denied=False
 try:need(forged['expected']==expected(forged,packet(forged)),'forged expected value rejected by packet oracle')
 except AssertionError:denied=True
 need(denied,'self-licking stored oracle escaped');faults[-1]['forgedStoredOracleRejected']=True
results['sensitivity']=faults
# Interrogate the promoted physical fixtures using the same independent packet model.
directory=E/'promoted';p=directory/'report.json';r=json.loads(p.read_text());s=r['browserResult']['result'];raw=(directory/'blend-pixels.bin').read_bytes();need(r['status']=='passed' and r['browserErrors']=={'console':[],'page':[],'requests':[]},'promoted hardware status');need(sha(raw)==r['physicalPixels']['sha256'],'promoted raw binding');rows=[]
for i,row in enumerate(s['records']):
 parts=packet(row);pred=expected(row,parts);need(row['expected']==pred,'promoted independent prediction');actual=pixel_frame(raw[1024*i:1024*(i+1)],row['format']);err=max(abs(v-pred[l]) for pix in actual for l,v in enumerate(pix));need(err<=1,'promoted physical oracle');native(row,parts);rows.append({'record':i,'name':row['name'],'expected':pred,'actual':actual[0],'maximumUnitError':err,'rawOffset':i*1024,'held':True})
need(len(rows)==22 and all(x['held'] for x in s['assertions']),'promoted suite predicates')
reject=[x for x in s['assertions'] if x['prediction'].startswith('native WebGL rejects mixed constants')];need(len(reject)==8 and all(x['observed']==0x502 and x['held'] for x in reject),'physical native WebGL prohibition')
results['promoted']={'status':'HELD','path':'renderer/virgl-command/tests/blend-boundaries.mjs','sha256':sha((R/'renderer/virgl-command/tests/blend-boundaries.mjs').read_bytes()),'report':p.relative_to(R).as_posix(),'reportSha256':sha(p.read_bytes()),'rawSha256':sha(raw),'frames':rows,'predicates':len(s['assertions']),'nativeForbiddenPairResults':reject}
# Bind the final active lane and source: only new test/evidence/log writes are allowed.
H='0ed130ff0b9a3efa1273ac485d87dad656efcef4';need(not subprocess.check_output(['git','diff','--name-only',H,'HEAD','--','renderer','tools'],text=True).strip(),'tracked source changed since worker freeze');need(not subprocess.check_output(['git','diff','--name-only','--','renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs'],text=True).strip(),'current runtime edits');diff=subprocess.check_output(['git','diff','3c6295a93d6b088c62a5c6f1cc434f226e090340',H,'--','renderer','tools'],text=True);need('#[ignore]' not in diff and 'debug_assert' not in diff,'disabled assertion in new code')
results['sourceBinding']={'status':'HELD','frozenSource':H,'verifiedParent':'3c6295a93d6b088c62a5c6f1cc434f226e090340','submissionHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'runtimeUnchanged':True,'ignoredTestsAdded':False}
results['primaryReferences']=[{'url':'https://registry.khronos.org/webgl/specs/latest/1.0/#6.13','fact':'WebGL restricts mixing CC and CA classes in RGB factors; the physical native probe also verifies all8 combinations.'},{'url':'https://raw.githubusercontent.com/KhronosGroup/OpenGL-Refpages/main/es3.0/glBlendEquationSeparate.xml','fact':'MIN/MAX depend on source/destination colors, without factors.'},{'url':'https://raw.githubusercontent.com/KhronosGroup/OpenGL-Refpages/main/es2.0/glBlendFuncSeparate.xml','fact':'SATURATE RGB uses the source/destination-alpha minimum; alpha coefficient is1.'}]
results['status']='HELD';(E/'final-audit.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({'status':'HELD','faults':faults,'promotedFrames':len(rows),'promotedPredicates':len(s['assertions']),'nativeRejectedPairs':len(reject),'promotedSha256':results['promoted']['sha256']},indent=2))
