from pathlib import Path
import hashlib,json,tarfile,subprocess
R=Path.cwd();E=R/'evidence/virgl-blend/verifier';P=R/'evidence/virgl-vertex-constant/verifier';H='0ed130ff0b9a3efa1273ac485d87dad656efcef4';BASE='3c6295a93d6b088c62a5c6f1cc434f226e090340';sha=lambda b:hashlib.sha256(b).hexdigest()
def need(ok,m):
 if not ok:raise AssertionError(m)
manifest=json.loads((P/'manifest.json').read_bytes());index=json.loads((P/'records.json').read_bytes());need(sha((P/'recording.tar.gz').read_bytes())=='36d18cbf16f9736618c4a435f494961f3476f92a52edd442ee9425b54bda4850','D1 critic archive');need(sha((P/'records.json').read_bytes())=='3e7f1f18f18b94f1067da6dc736860b3762d535d86d3743e1cd9b1ae7a084326','D1 index')
ix={x['path']:x for x in index['records']};need(len(ix)==54 and manifest['verdict']=='verified','D1 prior verdict')
with tarfile.open(P/'recording.tar.gz','r:gz') as tf:
 need({x.name for x in tf.getmembers()}==set(ix),'D1 exact seal closure')
 for x in tf.getmembers():
  b=tf.extractfile(x).read();need(sha(b)==ix[x.name]['sha256'] and len(b)==ix[x.name]['bytes'],'D1 critic sealed record drift')
unchanged=['renderer/virgl-shader','renderer/virgl-command/constant-domain.mjs','renderer/virgl-command/resources.mjs','renderer/virgl-command/cache.mjs','renderer/virgl-command/tests/vertex-constant-boundaries.mjs']
need(not subprocess.check_output(['git','diff','--name-only',BASE,H,'--',*unchanged],text=True).strip(),'D1 unchanged dependencies')
for s in manifest['promotedTests']:need(sha((R/s['path']).read_bytes())==s['sha256'],'D1 promoted tests drift')
reports=[]
for prefix in ['hot','cold']:
 U=E/'unpacked'/prefix;receipt=json.loads((U/'regression/receipt.json').read_text());need(receipt['status']=='passed' and receipt['gitHead']==H,'retained current gates')
 for name in receipt['files']:
  if not name.endswith('report.json'):continue
  p=U/'regression'/name;j=json.loads(p.read_text());need(j.get('gitHead',j.get('sourceHead',H))==H,'retained report head'); expected=('failed' if any(x in name for x in ['fault-','sabotage-']) else 'passed');need(j['status']==expected,'retained report status '+name)
  def walk(v):
   if isinstance(v,dict):
    if 'held' in v and not any(x in name for x in ['fault-','sabotage-']):need(v['held'],'retained failed predicate')
    for x in v.values():walk(x)
   elif isinstance(v,list):
    for x in v:walk(x)
  walk(j)
  if 'browserErrors' in j:need(j['browserErrors']=={'console':[],'page':[],'requests':[]},'retained browser errors')
  reports.append({'run':prefix,'path':name,'sha256':sha(p.read_bytes()),'status':j['status']})
 promoted=json.loads((U/'promoted-cache/report.json').read_text());need(promoted['status']=='passed' and promoted['sourceHead']==promoted['repositoryHead']==H,'current promoted cache source');need(all(s['seed'] for s in promoted['result']['schedules']) and len(promoted['result']['schedules'])==3,'three retained seeded schedules')
record={'schema':1,'task':'E6-T11d2','status':'HELD','priorTask':'E6-T11d1','priorVerifiedParent':BASE,'priorSourceHead':manifest['sourceHead'],'priorArchiveSha256':manifest['archiveSha256'],'priorRecordIndexSha256':manifest['recordIndexSha256'],'priorRecordsAuthenticated':54,'unchangedDependencies':unchanged,'carriedPredictions':['D1 P2 ordinary vertex128/private raw/fragment46 separation','D1 P5 scratch cancellation/fixed memory recovery','D1 P6 compiler output/text/token/IR/private profile bounds','D1 P7 unchanged resource/index/cache boundaries'], 'reason':'The checked compiler and these dependency boundaries are byte-identical to the verified parent; no D2 compiler/private authority change. Current scoped gate records authenticate changed renderer behavior, supplemented by independent D2 physical state/factor attacks.','retainedGateReports':reports,'d2Scope':'Normalized single-target blend only; no production capset/API, guest boot, throughput/FPS or portability across GPUs claim.'}
(E/'carry-forward.json').write_text(json.dumps(record,indent=2)+'\n');print('D1 54-record seal authenticated, unchanged dependency closure,',len(reports),'current retained reports checked')
