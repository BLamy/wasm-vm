VERDICT: verified

Fresh critic for E6-T12g4, 2026-10-04. The task and base-to-frozen diff were read
before evidence. Falsifiable predictions were saved in predictions.md before
opening the worker manifest or archive. Runtime/harness head is
7b4fbb11b3d386319b7050d7fc1e0442494d4f68, dependency/base is
96d6b83fcde1765fc5e931a95808629f78d37b60; submission 970ab070 adds the seal/log.
No runtime code was edited, no Git operation performed, and no semantic
refutation or sufficiency gap survived the scoped audit.

Paths below are relative to target/evidence/virgl-texture-views-verifier.
H = recording/hot/hardware/report.json, SHA256
fee9a6e152ae86de131c00b1f6f5cf46cb6aac44923a183817e1209aace10d40.
N = novel-clean/report.json, SHA256
6c64eb942da5efb9cb3f07811273d9525b48ba67cbf2a6ef81012522f7f78bd0.
F = sabotage-one-zero/report.json, SHA256
dc7801e9a5c449274bf2fa37afafd4b2c07a5ed9b5f68976333781693930a53b.

- P1 authentication — HELD. Every one of 63 safe regular archive members has
  its independently checked indexed size/digest. Archive SHA256
  de6d0334fed7059bb9af7dfaa5bd52ed2531089091ef1ce74e65970bb0789830;
  113 source/input table bindings match frozen Git objects or the sealed
  generated compiler. All 18 recorded hot/cold reports authenticate sources,
  served runtime/counters/fixtures/screenshots, hardware enablement, and zero
  console/page/request errors. Hot/cold source and input tables are identical.
  recording/cold/report.json:4–19 records exact cloneHead, exit0 and empty
  before/after status; SHA256 ed88346b27cf7b1f9312e8a5f675ff7a8d2322bf03b44f9d21fc596dd790de0a.
  The clone removes relevant configured environment (RUST_LOG); the script
  scrubs all CARGO_/RUST/VIRGL/compiler/Node/Python overrides. No portability
  failure justified a second clone. Original VIEW words independently decoded
  as [0x60601,5,5,0x02000043,0,0,0x688], event176 byte4400, SHA256
  f9cdf2022c82808a28b62d1a98f1711947f4edb920740dca387aaaaf9aabe36c;
  original SAMPLER event176 byte4444 SHA256
  321dcf863e76de17bf6d2019346c25b7b434715951cddea95da9bdb0164c345d.
  Original native linear calls are H:91783 onward. No demand.
- P2 admitted families/roles — HELD. H/native/assertions records 294 held
  Node/browser-identical guards: selectors0–5, exact formats2/67/233, target2,
  mip0/layer0; other target/format/level families explicitly reject. H/result/roles
  records six incompatible storage/role attacks with unchanged renderer/store
  charges. Independently repeated mixed-format reinterpretation and forbidden
  target/mip/layer/depth requests on seeded hardware resources in N/assertions.
  The untouched compiler's bridge.c:874 rejects vertex TEX. No cube/mip/layer,
  depth sampler or vertex-texture capability is advertised by this boundary.
  No demand.
- P3 physical pixels/filter/alpha — HELD. H/result/formats has 26 patterns on
  each of three native formats, all six selectors in each lane, four asymmetric
  physical texels per pattern, and GPU4188 with exactly two image allocations
  per tiny rig. H:95461 proves no per-view image; H:100541 proves packed native
  sample [0,85,170,255]. H/result/filtering records nearest [92,64,148,17],
  linear [68,91,104,82], clamp-edge out-of-range UVs, and combined flat+view
  provoking colors [36,200,8,255]/[148,64,92,255]. Expected swizzle bytes are
  literal independent native colors, before any inverse guest conversion.
  N physically repeats composed ZERO/ONE/alpha/filter calculations using
  independent xorshift channel data and scalar bilinear arithmetic on all formats.
  Native X alpha1 is the unchanged verified storage boundary. No demand.
- P4 cache/lifetime — HELD. H:95555 and H/result/multiple show exact A/B/A
  native reuse; slot0/7 both enter the key and changing only slot7 selects a
  different physical program. New format/selector suffixes include fixed
  target2/mip0/layer0/lower-left dependencies; standard RGBA identity retains
  the legacy key. N:7710 observes 15 distinct mixed-format/swizzle programs on
  one selector; N:1722 confirms filters reuse the same code; N:8172 confirms
  identical semantics on another image reuse the native program. N:8624 onward
  proves old view fields/leases survive destruction and unbound numeric-name
  replacement before correct new format selection. No demand.
- P5 variant ownership/rollback — HELD. H:107639 charges the fragment's exact
  GLSL bytes before compile. H/result/budgets records exact-fit/one-byte-short
  pressure (H:108825), program-count pressure, and all twelve native
  allocation/compile/link/reflection/error failures with charge/name rollback.
  The flat+view program charges both generated stages; H:117389 exercises
  fragment failure after allocating its flat vertex. Worker success disposal
  and N's all-native-name instrument verify zero final charges. N:9706 onward
  checks specific deletion plus gl.isProgram false for every old selector's
  15 cached programs after final binding release; N:9958 has final shaderBytes0.
  No demand.
- P6 checked output/reflection — HELD. H/result/checkedOutput records explicit
  lookup/main/length/sampler-name/type/index rejection, with no temporary names
  or charge. They are trusted-host output injections, not an invented guest
  GLSL authority. All-constant lanes legitimately allow native sampler
  elimination; H:105999/106035 and the following feedback assertion prove
  logical view/state and alias safety still apply. N's independent all-constant
  composition draws under both filters. No demand.
- P7 asynchronous boundary — HELD. H/result/jobs records real native fence
  polling with delays0/1/3, no blocking waits, no outstanding syncs at completion,
  independent A/B/A pixels and exact A program reuse. Changed state.mjs:522
  has a positive tight V8 counter and verifies sampling identity in each final
  draw plan. Active jobs prohibit state mutation through the trusted API;
  immutable sampler metadata and the checked key cannot become a stale
  specialization during the controlled waits. No demand.
- P8 changed-line sufficiency — HELD. Independently derived the zero-context
  base-to-head Git diff and UTF-16 source offsets; for every added code token,
  used its narrowest enclosing precise V8 range from authenticated clean H
  counters, never the worker's map or a mutant recording. Of 62 added runtime
  lines, 53 wholly execute, 2 execute with narrow defensive-branch waivers,
  and 7 are comments/structural closures. state.mjs:421 `: null` and :422
  `?? false` alone have count0; they require vertex samplers and are unreachable
  under unchanged bridge.c:874's fragment-only TEX admission. The statements
  and all admitted fragment paths have positive counters. coverage-audit.json
  enumerates every token/waiver, SHA256
  5c11102cf91c47a48ecea6211e0830d776c4276be87a9edfcd8ca8fcce12744a.
  The decoder guard and removal of the identity-only state guard are exercised
  by physical nonidentity matrix cases. Docs/task/README/inspect metadata are
  declarative or reporting waivers; make/fixture/hardware/receipt/cold glue runs
  in the authenticated acceptance logs. Generic argument-validation and
  cleanup-on-environment-failure glue adds no unproved guest behavior. No
  dead code or proof run is demanded.
- P9 prior HELD boundaries/retained regression — HELD, carried forward.
  Resource/color/depth and checked shader compiler/pair implementations are
  unchanged against verified G3; prior G1/G2/G3 seals and source dependency
  boundaries retain their verdicts. All seven affected regression gates pass
  in both exact-source transcripts. The unchanged runRendererPairs body uses
  independently checked physical pixels, shader byte ownership, lifecycle,
  twelve real/pair fault paths and two quota cases; H/result/flat contains
  44 draws/12 faults/2 quotas. Its five supplied source texts are source-bound,
  with original flat/missing/partial TGSI digests pinned; flat/mixed anchor
  translations are checked by the original implementation. Skipping only the
  standalone wrapper's stale unrelated 12/19 compiler-admission premise does
  not remove any affected renderer regression or weaken an assertion. No demand.
- P10 bounded novel hardware attack — HELD. N records 39 draws/1688 held
  assertions on Chrome154.0.8037.93 / hardware ANGLE Metal Apple M4 Max,
  independent seeds2485694867/2803642213/1833140897. Its own sampler arithmetic
  checks seven pixels per draw, interleaves formats on one selector, composes
  nearest/linear with ZERO/ONE lanes, checks reinterpret/unsupported guards,
  shader-independent storage identity, name destruction/replacement and every
  old program's actual collection. All native tracked names and charges are0
  at disposal; zero GL/console/page/request errors. No demand.
- P11 independent sensitivity — HELD. The clean control above holds. Serving
  only helper ONE as0.0 leaves base compile/link valid, then F:1958 records
  physical pixel8,8 lane2 expected255 observed0 on pattern[2,4,5,3]. Failure is
  before inverse conversion, with clean browser errors and final cleanup.
  Served runtime SHA256 changes from
  bf56e153037793201d1588c1e58571c2980b24b0f8e6cb94f16315582ff26d7e to
  850428f5f6eced44dbffa7a7ea76a52b7fe16d039f99aff337dc8af8962c4be8;
  served source, precise counters and screenshot are saved alongside F. The
  sealed worker lane-swap source fault independently fails its physical oracle.
  No tracked runtime code was mutated. No demand.

SUITE: retain the committed texture-views.mjs deterministic native/GPU/role/
quota/alias/slot/fault cases and make verify-E6-T12g4 as the recurring boundary.
Preserve novel seeds, its independently authored hardware driver, exact pixels,
and ONE-lane fault as verifier replay evidence. No new tracked implementation
or duplicate test harness is necessary. Scope remains isolated renderer views;
full original-client shader closure is G6 and depth raster execution is H.
No guest offload, production negotiation or throughput claim is inferred.

Commands:
python3 target/evidence/virgl-texture-views-verifier/authenticate.py
python3 target/evidence/virgl-texture-views-verifier/audit-recording.py
node target/evidence/virgl-texture-views-verifier/run-novel.mjs
node target/evidence/virgl-texture-views-verifier/run-novel.mjs one-zero

The second clean run strengthened the verifier harness's native-object identity
assertions and added independent format-family guards; it did not rerun an
unrelated gate. All browser/server resources close in finally. Host rr/ssh dev
is waived by policy. Queue regeneration, evidence preservation and Git commit
belong to the parent session.
