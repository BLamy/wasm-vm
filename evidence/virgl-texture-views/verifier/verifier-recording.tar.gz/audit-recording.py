#!/usr/bin/env python3
import hashlib, json, pathlib, re, subprocess
OUT=pathlib.Path(__file__).resolve().parent
ROOT=OUT.parents[2]
BASE='96d6b83fcde1765fc5e931a95808629f78d37b60'
HEAD='7b4fbb11b3d386319b7050d7fc1e0442494d4f68'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_bytes())
hot_file=OUT/'recording/hot/hardware/report.json'
hot=load(hot_file)
r=hot['browserResult']['result']
assert all(a['held'] and a['expected']==a['observed'] for a in r['assertions'])
assert all(a['held'] and a['expected']==a['observed'] for a in hot['native']['assertions'])
assert len(r['assertions'])==4870 and len(hot['native']['assertions'])==294
assert [x['format'] for x in r['formats']]==[67,2,233]
assert all(len(x['cases'])==26 and x['aliasGpuBytes']==4188 for x in r['formats'])
assert len(r['roles'])==6 and len(r['multiple']['programs'])==2
assert len(r['budgets']['pressure'])==2 and len(r['budgets']['failures'])==12
assert [x['mode'] for x in r['checkedOutput']]==['lookup','main','length','sampler-name','sampler-type','sampler-index']
assert [x['delay'] for x in r['jobs']]==[0,1,3]
assert r['flat']['status']=='passed' and len(r['flat']['draws'])==44 and len(r['flat']['faults'])==12 and len(r['flat']['quota'])==2
for job in r['jobs']:
    assert job['draws'][0]==job['draws'][2]!=job['draws'][1]
    assert all(e['actual'] in (37146,37148,37147) for e in job['events'])
    assert sum(e['delivered']==37147 for e in job['events'])>=job['delay']
coverage=load(OUT/'recording/hot/hardware/browser-coverage.json')
scripts={s['source']:s for s in coverage['scripts']}
diff=subprocess.check_output(['git','diff','--no-ext-diff','--unified=0',BASE,HEAD,'--','renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs'],cwd=ROOT,text=True)
added={}; file=None; line=None
for row in diff.splitlines():
    if row.startswith('+++ b/'): file=row[6:]; added.setdefault(file,[])
    elif row.startswith('@@'): line=int(re.search(r'\+(\d+)',row).group(1))
    elif row.startswith('+') and not row.startswith('+++'): added[file].append(line);line+=1
    elif row.startswith(' '): line+=1
def utf16(s):return len(s.encode('utf-16-le'))//2
maps=[]
for file,numbers in added.items():
    source=subprocess.check_output(['git','show',f'{HEAD}:{file}'],cwd=ROOT).decode()
    assert hashlib.sha256(source.encode()).hexdigest()==scripts[file]['sha256']
    lines=source.splitlines(keepends=True)
    ranges=[{**q,'function':f['functionName']} for f in scripts[file]['coverage']['functions'] for q in f['ranges']]
    starts=[0]
    for row in lines:starts.append(starts[-1]+utf16(row))
    for n in numbers:
        text=lines[n-1].strip()
        # Declarative closure/comment-only lines have no independent behavior.
        if not text or text.startswith('//') or re.fullmatch(r'[}\]);,]+',text):
            maps.append({'source':file,'line':n,'text':text,'classification':'waived','reason':'comment, whitespace or structural closure; defining/executing enclosing expression is covered'})
            continue
        points=[]
        for m in re.finditer(r'[A-Za-z_$][A-Za-z0-9_$]*|\d+',lines[n-1]):
            p=starts[n-1]+utf16(lines[n-1][:m.start()])
            enclosing=[q for q in ranges if q['startOffset']<=p<q['endOffset']]
            tight=min(enclosing,key=lambda q:q['endOffset']-q['startOffset'])
            points.append({'token':m.group(),'offset':p,'range':tight})
        assert points
        unexecuted=[p for p in points if not p['range']['count']]
        waivers=[]
        if file=='renderer/virgl-command/state.mjs' and n in (421,422):
            # These exact defensive branches require a vertex sampler, which the
            # unchanged checked compiler rejects before emitting metadata.
            expected='null' if n==421 else 'false'
            assert [p['token'] for p in unexecuted]==[expected]
            assert subprocess.check_output(['git','show',f'{BASE}:renderer/virgl-shader/bridge.c'],cwd=ROOT)==subprocess.check_output(['git','show',f'{HEAD}:renderer/virgl-shader/bridge.c'],cwd=ROOT)
            waivers=[{'token':p['token'],'offset':p['offset'],'reason':'unreachable defensive vertex-sampler fallback: checked TEX parser requires s->stage == 1 at unchanged renderer/virgl-shader/bridge.c:874; no admitted vertex TEX family and no claim of one','counter':p['range']} for p in unexecuted]
            unexecuted=[]
        count=min(p['range']['count'] for p in points if p['range']['count'])
        maps.append({'source':file,'line':n,'text':text,'classification':'needs-evidence' if unexecuted else 'executed-with-waiver' if waivers else 'executed','minimumExecutedTightRangeCount':count,'waivedTokens':waivers,'points':points})
report={'status':'passed' if all(m['classification']!='needs-evidence' for m in maps) else 'needs-evidence','base':BASE,'head':HEAD,'method':'derive added lines from zero-context Git diff; authenticate exact UTF-16 source; independently take narrowest enclosing precise V8 counter for each token; structural/comment closures waived','coveragePath':'recording/hot/hardware/browser-coverage.json','coverageSha256':digest(OUT/'recording/hot/hardware/browser-coverage.json'),'lines':maps}
(OUT/'coverage-audit.json').write_text(json.dumps(report,indent=2)+'\n')
citations=[]
raw=hot_file.read_text()
patterns=['all-constant','optimized-away','one byte short','flat-fragment-compile','actual native linear','slot7','released shaderBytes','reuses its exact native program','no GPU image','physical RGBA 233','linear center','fragment storage is charged','sampler state restored']
for pattern in patterns:
    matches=[a for a in r['assertions'] if pattern in a['prediction']]
    if not matches:continue
    a=matches[0];needle='"prediction": '+json.dumps(a['prediction'],ensure_ascii=False)
    offset=raw.find(needle)
    citations.append({'prediction':a['prediction'],'expected':a['expected'],'observed':a['observed'],'line':raw[:offset].count('\n')+1,'path':str(hot_file.relative_to(ROOT)),'sha256':digest(hot_file)})
claim={'status':'passed','recordPath':str(hot_file.relative_to(ROOT)),'recordSha256':digest(hot_file),'assertions':len(r['assertions']),'nativeAssertions':len(hot['native']['assertions']),'formats':[{k:x[k] for k in ('format','aliasGpuBytes')} for x in r['formats']],'roles':r['roles'],'failures':[{k:x[k] for k in ('mode','error')} for x in r['budgets']['failures']],'quotas':r['budgets']['pressure'],'guards':r['checkedOutput'],'jobs':[{'delay':x['delay'],'draws':x['draws'],'actualFences':len(x['events'])} for x in r['jobs']],'retainedPairs':{'draws':len(r['flat']['draws']),'faults':len(r['flat']['faults']),'quotas':len(r['flat']['quota'])},'citations':citations}
(OUT/'claim-audit.json').write_text(json.dumps(claim,indent=2)+'\n')
print(json.dumps({'claimStatus':claim['status'],'coverageStatus':report['status'],'addedLines':len(maps),'executedLines':sum(m['classification']=='executed' for m in maps),'executedWithNarrowWaiverLines':sum(m['classification']=='executed-with-waiver' for m in maps),'waivedLines':sum(m['classification']=='waived' for m in maps),'proofGaps':[{'source':m['source'],'line':m['line'],'text':m['text']} for m in maps if m['classification']=='needs-evidence'],'citations':citations},indent=2))
