import {decodeSubmission} from '/renderer/virgl-command/decoder.mjs';
import {createResourceStore,createWebGL2TransferBackend} from '/renderer/virgl-command/resources.mjs';
import {createVirglDrawRenderer} from '/renderer/virgl-command/state.mjs';
import {createVirglShaderBridge} from '/renderer/virgl-shader/index.mjs';

function packet(op,type,words){const b=new Uint8Array(4+words.length*4),v=new DataView(b.buffer);v.setUint32(0,op|(type<<8)|(words.length<<16),true);words.forEach((w,i)=>v.setUint32(4+i*4,w,true));return b;}
function shader(handle,text){const b=packet(1,4,[handle,1,text.length+1,256,0,...Array(Math.ceil((text.length+1)/4)).fill(0)]);b.set(new TextEncoder().encode(text),24);return b;}
const view=(h,id,format,s)=>packet(1,6,[h,id,0x02000000|format,0,0,s.reduce((n,v,i)=>n|(v<<(i*3)),0)]);
const bindView=h=>packet(10,0,[1,0,h]);
const bindShader=h=>packet(31,0,[h,1]);
const sampler=(h,linear)=>packet(1,7,[h,2|(2<<3)|(2<<6)|(2<<11)|(linear?1<<9|1<<13:0),0,0,0x447a0000,0,0,0,0]);
const bindSampler=h=>packet(18,0,[1,0,h]);
const destroy=(type,h)=>packet(3,type,[h]);
const byteSha=async bytes=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(b=>b.toString(16).padStart(2,'0')).join('');

// These scalar expected values originate from the independent data generator,
// never from the renderer's upload/readback conversion or its GLSL helpers.
function sample(input,x,y,linear){
  if(!linear)return input.rgba[(y>=16?2:0)+(x>=16?1:0)];
  const weights=p=>{const t=(p+.5)/16-.5;const lo=Math.floor(t);return [Math.max(0,Math.min(1,lo)),Math.max(0,Math.min(1,lo+1)),t-lo];};
  const [x0,x1,fx]=weights(x),[y0,y1,fy]=weights(y);
  return [0,1,2,3].map(l=>(input.rgba[y0*2+x0][l]*(1-fx)+input.rgba[y0*2+x1][l]*fx)*(1-fy)+(input.rgba[y1*2+x0][l]*(1-fx)+input.rgba[y1*2+x1][l]*fx)*fy);
}
function poison(gl){gl.enable(gl.BLEND);gl.blendFunc(gl.ZERO,gl.ZERO);gl.enable(gl.SCISSOR_TEST);gl.scissor(0,0,0,0);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.NEVER);gl.enable(gl.CULL_FACE);gl.cullFace(gl.FRONT_AND_BACK);gl.colorMask(false,false,false,false);gl.viewport(0,0,0,0);gl.activeTexture(gl.TEXTURE7);gl.bindSampler(0,null);gl.pixelStorei(gl.PACK_ROW_LENGTH,13);gl.pixelStorei(gl.PACK_ALIGNMENT,8);}

export async function runNovel(fixtures,inputs){
  const report={status:'running',assertions:[],draws:[],inputs,lifecycle:[],glEvents:[]};window.__viewNovel=report;
  const equal=(got,want,label)=>{const held=JSON.stringify(got)===JSON.stringify(want);report.assertions.push({prediction:label,expected:want,observed:got,held});if(!held)throw new Error(label+': expected '+JSON.stringify(want)+', got '+JSON.stringify(got));};
  const ok=(value,label)=>{equal(value?.ok,true,label+' '+(value?.error?.message??''));return value;};
  const gl=document.querySelector('#gpu').getContext('webgl2',{antialias:false,preserveDrawingBuffer:true,failIfMajorPerformanceCaveat:true});equal(Boolean(gl),true,'real native context');
  const debug=gl.getExtension('WEBGL_debug_renderer_info');report.renderer=gl.getParameter(debug.UNMASKED_RENDERER_WEBGL);equal(/swiftshader|llvmpipe|softpipe|lavapipe/i.test(report.renderer),false,'hardware renderer');
  const allocations=new Map(),identities=new WeakMap(),names=new Map(),ever=[];let serial=0;
  const id=obj=>obj?(identities.get(obj)??null):null;
  const types=['Shader','Program','Texture','Framebuffer','VertexArray','Sampler','Buffer','Renderbuffer'];
  const proxy=new Proxy(gl,{get(t,k){const f=Reflect.get(t,k,t);if(typeof f!=='function')return f;return(...args)=>{
    const value=f.apply(t,args);
    for(const type of types){if(k==='create'+type&&value){identities.set(value,++serial);names.set(value,type);ever.push({object:value,type,id:serial});}if(k==='delete'+type)names.delete(args[0]);}
    if(k==='shaderSource')report.glEvents.push({call:k,id:id(args[0]),stage:t.getShaderParameter(args[0],t.SHADER_TYPE),text:args[1]});
    if(k==='attachShader')report.glEvents.push({call:k,program:id(args[0]),shader:id(args[1])});
    if(k==='drawElements')report.glEvents.push({call:k,program:id(t.getParameter(t.CURRENT_PROGRAM))});
    if(k==='texStorage2D')report.glEvents.push({call:k,format:args[2],width:args[3],height:args[4]});
    if(k==='deleteShader'||k==='deleteProgram')report.glEvents.push({call:k,id:id(args[0])});
    return value;
  };}});
  const bridge=await createVirglShaderBridge();
  const native=ok(createWebGL2TransferBackend(proxy),'backend').backend;
  const backend={...native,allocate(meta){const storage=native.allocate(meta);allocations.set(meta.id,storage);return storage;}};
  const {store,bindings}=ok(createResourceStore({backend}),'resource store');
  const renderer=ok(createVirglDrawRenderer({gl:proxy,resources:store,bindings,shaderBridge:bridge}),'renderer').renderer;
  const run=(bytes,label)=>ok(renderer.executeSubmission(2,bytes),label);
  const snapshot=()=>ok(renderer.inspect(),'inspect');
  const sub=()=>{const s=snapshot();return s.contexts[0].subContexts.find(q=>q.id===s.contexts[0].currentSubContext);};
  const currentProgram=()=>{const s=sub(),generation=s.bindings.fragmentShader.generation;return s.programs.find(p=>p.fragmentGeneration===generation&&p.samplingViews[0]?.swizzle.join(',')===current.swizzle.join(',')&&p.samplingViews[0]?.format===current.format);};
  let draw,current;
  try{
    for(const a of fixtures.initialization){
      if(a.type==='context_create'){ok(store.createContext(2),'resource context');ok(renderer.createContext(2),'renderer context');}
      else if(a.type==='resource_create')ok(store.createResource(a.metadata),'baseline storage');
      else if(a.type==='ctx_attach_resource')ok(store.attachContext(2,a.resourceId),'baseline membership');
      else if(a.type==='resource_attach_iov')ok(store.attachBacking(a.resourceId,a.iovLengths.map(n=>new Uint8Array(n))),'baseline backing');
      else throw new Error('unknown captured initialization');
    }
    for(const b of fixtures.backing)for(const range of b.ranges)ok(store.writeBacking(b.resourceId,range.offset,Uint8Array.from(range.data)),'captured geometry input');
    const bytes=Uint8Array.from(fixtures.commands.submissions.find(s=>s.event===161).data);
    const decoded=ok(decodeSubmission(bytes),'captured setup packets');
    for(const cmd of decoded.commands){const raw=bytes.slice(cmd.byteOffset,cmd.byteOffset+cmd.byteLength);if(cmd.opcode===8)draw=raw;else run(raw,'captured prerequisite '+cmd.name);}
    equal(Boolean(draw),true,'original draw packet selected');
    run(shader(99,fixtures.commands.shaders.FRAG),'independent selector');run(bindShader(99),'same selector for all view formats');
    run(sampler(90,false),'nearest state');run(sampler(91,true),'linear state');run(bindSampler(90),'nearest binding');
    for(const input of inputs){
      ok(store.createResource({id:input.id,target:2,format:input.format,bind:8,width:2,height:2,depth:1,arraySize:1,lastLevel:0,nrSamples:0,flags:0}),'seeded texture storage');
      ok(store.attachContext(2,input.id),'seeded texture membership');ok(store.attachBacking(input.id,[Uint8Array.from(input.bytes)]),'independent seed backing');
      const command={opcode:43,fields:{resourceHandle:input.id,level:0,usage:0,stride:0,layerStride:0,box:{x:0,y:0,z:0,width:2,height:2,depth:1},dataOffset:0,direction:1}};
      const ticket=ok(store.prepareTransfer(2,command),'seed upload prepare').ticket;ok(store.executeTransfer(ticket),'seed actual upload');
    }
    for(const input of inputs){
      const wrongFormat=input.format===67?233:67,before=snapshot().budgets,storage=ok(store.inspect(),'reinterpret pre-state').budgets;
      const result=renderer.executeSubmission(2,view(222,input.id,wrongFormat,[2,4,5,3]));equal(result.ok,false,'independent incompatible format rejects');equal(result.error.code,'incompatible-resource','independent precise format rejection');equal(snapshot().budgets,before,'independent reinterpret no renderer charge');equal(ok(store.inspect(),'reinterpret post-state').budgets,storage,'independent reinterpret no lease charge');
    }
    for(const words of [[223,80,0x03000043,0,0,0x688],[223,80,0x02000043,1,0,0x688],[223,80,0x02000043,0,1,0x688],[223,80,0x02000010,0,0,0x688]]){
      const result=renderer.executeSubmission(2,packet(1,6,words));equal(result.ok,false,'independent unsupported target/mip/layer/depth request rejects');equal(result.error.code,'unsupported-feature','independent unsupported family code');
    }
    const pixels=()=>{const fb=proxy.createFramebuffer();try{
      proxy.bindFramebuffer(gl.READ_FRAMEBUFFER,fb);proxy.framebufferTexture2D(gl.READ_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,allocations.get(5).texture,0);proxy.readBuffer(gl.COLOR_ATTACHMENT0);equal(proxy.checkFramebufferStatus(gl.READ_FRAMEBUFFER),gl.FRAMEBUFFER_COMPLETE,'independent physical FBO');proxy.bindBuffer(gl.PIXEL_PACK_BUFFER,null);proxy.pixelStorei(gl.PACK_ALIGNMENT,1);for(const p of [gl.PACK_ROW_LENGTH,gl.PACK_SKIP_PIXELS,gl.PACK_SKIP_ROWS])proxy.pixelStorei(p,0);
      const out=new Uint8Array(4096);proxy.readPixels(0,0,32,32,gl.RGBA,gl.UNSIGNED_BYTE,out);return out;
    }finally{proxy.deleteFramebuffer(fb);}};
    const physical=async(input,s,linear,label)=>{
      poison(gl);run(draw,label);const out=pixels(),program=currentProgram();equal(Boolean(program),true,label+' selected key');const samples=[];
      for(const [x,y] of [[8,8],[24,8],[8,24],[24,24],[16,16],[1,30],[30,1]]){
        const native=sample(input,x,y,linear),want=s.map(v=>v===4?0:v===5?255:Math.round(native[v]));const got=[...out.slice((y*32+x)*4,(y*32+x+1)*4)];
        for(let lane=0;lane<4;lane++)equal(Math.abs(want[lane]-got[lane])<=(linear?1:0),true,label+' physical lane'+lane+' at'+x+','+y+' wanted'+want[lane]+' got'+got[lane]);
        samples.push({x,y,expected:want,observed:got});
      }
      const row={label,resource:input.id,format:input.format,swizzle:s,linear,nativeProgram:id(gl.getParameter(gl.CURRENT_PROGRAM)),program,pixelSha256:await byteSha(out),samples};report.draws.push(row);return row;
    };
    const patterns=[[2,4,5,3],[3,2,1,5],[5,4,5,4],[1,0,2,5],[0,1,2,3]];
    const viewRows=[];let h=100;
    for(const input of inputs)for(const s of patterns){const handle=h++;run(view(handle,input.id,input.format,s),'seeded composed view');viewRows.push({handle,input,swizzle:s,format:input.format});}
    const gpu=ok(store.inspect(),'seed baseline residency').budgets.gpuBytes,images=report.glEvents.filter(e=>e.call==='texStorage2D').length;
    const selectorGeneration=sub().bindings.fragmentShader.generation,bySemantics=new Map();
    // Interleave all formats under one selector instead of isolated format rigs.
    for(let pattern=0;pattern<patterns.length;pattern++)for(const format of [67,233,2]){
      const row=viewRows.find(v=>v.format===format&&v.swizzle===patterns[pattern]);current=row;run(bindView(row.handle),'mixed format selection');run(bindSampler(90),'mixed nearest');
      const a=await physical(row.input,row.swizzle,false,'mixed'+format+'/'+pattern+' nearest');const before=report.glEvents.filter(e=>e.call==='shaderSource').length;
      run(bindSampler(91),'mixed linear');const b=await physical(row.input,row.swizzle,true,'mixed'+format+'/'+pattern+' linear');equal(b.nativeProgram,a.nativeProgram,'filter changes preserve shader program');equal(report.glEvents.filter(e=>e.call==='shaderSource').length,before,'filter changes compile no variant');
      equal(sub().bindings.fragmentShader.generation,selectorGeneration,'format changes retain one immutable selector');bySemantics.set(format+'/'+pattern,a);
    }
    equal(new Set([...bySemantics.values()].map(v=>v.nativeProgram)).size,15,'distinct format/swizzle semantics cannot collide');
    equal(report.glEvents.filter(e=>e.call==='texStorage2D').length,images,'new aliases create no texture images');equal(ok(store.inspect(),'alias residency').budgets.gpuBytes,gpu,'alias views add no GPU storage');
    // An identical-semantic view on another physical image must reuse the code.
    const alt={...inputs[0],id:83,bytes:[...inputs[0].bytes].reverse(),rgba:[]};for(let i=0;i<4;i++)alt.rgba.push(alt.bytes.slice(i*4,i*4+4));
    ok(store.createResource({id:83,target:2,format:67,bind:8,width:2,height:2,depth:1,arraySize:1,lastLevel:0,nrSamples:0,flags:0}),'second RGBA texture');ok(store.attachContext(2,83),'second texture membership');ok(store.attachBacking(83,[Uint8Array.from(alt.bytes)]),'second independent backing');ok(store.executeTransfer(ok(store.prepareTransfer(2,{opcode:43,fields:{resourceHandle:83,level:0,usage:0,stride:0,layerStride:0,box:{x:0,y:0,z:0,width:2,height:2,depth:1},dataOffset:0,direction:1}}),'second upload prepare').ticket),'second actual upload');
    const a=viewRows.find(v=>v.format===67&&v.swizzle===patterns[0]);current=a;run(bindView(a.handle),'restore A');run(bindSampler(90),'A nearest');const beforeA=await physical(a.input,a.swizzle,false,'A baseline');
    run(view(150,83,67,a.swizzle),'same-semantics other texture');current={format:67,swizzle:a.swizzle};run(bindView(150),'other texture same key');const alias=await physical(alt,a.swizzle,false,'same code other storage');equal(alias.nativeProgram,beforeA.nativeProgram,'storage identity is not a shader dependency');
    current=a;run(bindView(a.handle),'A restored');const restored=await physical(a.input,a.swizzle,false,'A/B/A independent storage');equal(restored.nativeProgram,beforeA.nativeProgram,'A/B/A exact native program');
    const state=snapshot();run(destroy(6,a.handle),'destroy bound public view');equal(snapshot().budgets,state.budgets,'bound destroyed view retains lease');await physical(a.input,a.swizzle,false,'destroyed bound view still draws');
    const replacement=viewRows.find(v=>v.format===233&&v.swizzle===patterns[1]);run(view(a.handle,replacement.input.id,233,replacement.swizzle),'reuse numeric view with different format');await physical(a.input,a.swizzle,false,'unbound replacement cannot change old lease');current=replacement;run(bindView(a.handle),'bind reused-format view');const replaced=await physical(replacement.input,replacement.swizzle,false,'new generation view pixels');equal(replaced.nativeProgram,bySemantics.get('233/1').nativeProgram,'canonical new view reuses correct existing program');
    report.lifecycle.push({kind:'view-name-reuse',before:state,after:snapshot()});
    const fsBefore=snapshot(),oldGeneration=sub().bindings.fragmentShader.generation,oldPrograms=sub().programs.filter(p=>p.fragmentGeneration===oldGeneration),oldNative=gl.getParameter(gl.CURRENT_PROGRAM);
    const oldNativeIds=new Set([...bySemantics.values()].map(p=>p.nativeProgram)),oldNativeObjects=ever.filter(item=>item.type==='Program'&&oldNativeIds.has(item.id));equal(oldNativeObjects.length,oldPrograms.length,'independent draw identities cover old variant programs');
    run(destroy(4,99),'destroy bound fragment selector');equal(snapshot().budgets,fsBefore.budgets,'bound unnamed shader owns its variants');await physical(replacement.input,replacement.swizzle,false,'unnamed shader pixels');
    run(shader(99,fixtures.commands.shaders.FRAG),'recreate numeric fragment selector');await physical(replacement.input,replacement.swizzle,false,'unbound replacement shader pixels');equal(gl.getParameter(gl.CURRENT_PROGRAM)===oldNative,true,'new public name leaves old bound native program');
    run(bindShader(99),'replace bound fragment generation');const newer=await physical(replacement.input,replacement.swizzle,false,'new fragment generation pixels');equal(newer.nativeProgram!==id(oldNative),true,'new shader generation gets new owned program');equal(sub().programs.some(p=>p.fragmentGeneration===oldGeneration),false,'last old selector release collects every old variant');
    for(const item of oldNativeObjects){equal(report.glEvents.some(e=>e.call==='deleteProgram'&&e.id===item.id),true,'specific old program delete call recorded '+item.id);equal(gl.isProgram(item.object),false,'every old program actually collected '+item.id);}
    equal(gl.isProgram(oldNative),false,'old native program actually destroyed');report.lifecycle.push({kind:'fragment-name-reuse',before:fsBefore,after:snapshot(),oldPrograms:oldPrograms.length});
    equal(gl.getError(),gl.NO_ERROR,'all attack draws leave no GL errors');report.status='passed';
  }catch(error){report.status='failed';report.failure={message:error.message,stack:error.stack};}
  finally{
    ok(renderer.dispose(),'final renderer dispose');ok(store.dispose(),'final storage dispose');
    for(const owner of [renderer,store])for(const [key,value] of Object.entries(ok(owner.inspect(),'final inspection').budgets))equal(value,0,'final zero '+key);
    equal(names.size,0,'all native names deleted');for(const item of ever)equal(gl['is'+item.type](item.object),false,'native '+item.type+item.id+' actually collected');equal(gl.getError(),gl.NO_ERROR,'final hardware GL error');
  }
  document.querySelector('#status').textContent=report.status==='passed'?'Passed: independent mixed formats, composed filtering, name lifetimes':report.failure.message;
  document.querySelector('#report').textContent=JSON.stringify({status:report.status,draws:report.draws.length,assertions:report.assertions.length,seeds:inputs.map(v=>v.seed),renderer:report.renderer,failure:report.failure},null,2);
  return report;
}
