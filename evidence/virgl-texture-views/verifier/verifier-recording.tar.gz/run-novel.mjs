import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {createServer} from 'node:http';
import {execFileSync} from 'node:child_process';
const out=path.dirname(fileURLToPath(import.meta.url)),root=path.resolve(out,'../../..');
const {loadViewFixtures}=await import(pathToFileURL(path.join(root,'tools/virgl-command/view-fixtures.mjs')));
const sha=raw=>createHash('sha256').update(raw).digest('hex');
const fault=process.argv[2]==='one-zero',mode=fault?'sabotage-one-zero':'novel-clean';
const output=path.join(out,mode);await fs.mkdir(output,{recursive:true});
const inputs=[{id:80,format:67,seed:0x9428b193},{id:81,format:2,seed:0xa71c2f65},{id:82,format:233,seed:0x6d4382a1}].map(input=>{
  let state=input.seed;const rng=()=>{state^=state<<13;state^=state>>>17;state^=state<<5;return state>>>0;};
  const bytes=[],rgba=[];
  for(let i=0;i<4;i++){
    if(input.format===67){const p=Array.from({length:4},()=>rng()&255);bytes.push(...p);rgba.push(p);}
    else if(input.format===2){const p=Array.from({length:4},()=>rng()&255);bytes.push(p[2],p[1],p[0],p[3]);rgba.push([p[0],p[1],p[2],255]);}
    else{const p=Array.from({length:3},()=>rng()&1023);const word=(p[0]<<20)|(p[1]<<10)|p[2]|((rng()&3)<<30);bytes.push(word&255,(word>>>8)&255,(word>>>16)&255,(word>>>24)&255);rgba.push([...p.map(v=>v*255/1023),255]);}
  }
  return{...input,bytes,rgba};
});
const {fixtures, sources:boundInputs}=await loadViewFixtures();
const fixtureBytes=Buffer.from(JSON.stringify(fixtures.tiny));
await fs.writeFile(path.join(output,'inputs.json'),JSON.stringify({generator:'xorshift32 / independent channel pack and normalization',inputs,originalInputs:boundInputs,fixtureTransport:{bytes:fixtureBytes.length,sha256:sha(fixtureBytes)}},null,2)+'\n');
const report={task:'E6-T12g4',status:'running',mode,gitHead:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),frozenSourceHead:'7b4fbb11b3d386319b7050d7fc1e0442494d4f68',originalInputs:boundInputs,sources:[],servedFiles:[],errors:{console:[],page:[],requests:[]}};
let browser,server;
try{
  const html=Buffer.from('<!doctype html><meta charset="utf-8"><title>Independent immutable view attack</title><style>body{font:16px system-ui;background:#141923;color:#eef3ff;margin:32px}pre{white-space:pre-wrap}</style><h1>Independent texture view attack</h1><p id="status">Checking hardware…</p><canvas id="gpu" width="32" height="32"></canvas><pre id="report"></pre>');
  const runtimePaths=['renderer/virgl-command/resources.mjs','renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs','renderer/virgl-command/constant-domain.mjs','renderer/virgl-shader/index.mjs','renderer/virgl-shader/build/wasm/virgl-shader.mjs','renderer/virgl-shader/build/wasm/virgl-shader.wasm'];
  const endpoints=new Map([['/',{bytes:html,type:'text/html'}],['/fixtures.json',{bytes:fixtureBytes,type:'application/json'}],['/novel-hardware.mjs',{bytes:await fs.readFile(path.join(out,'novel-hardware.mjs')),type:'text/javascript'}]]);
  for(const file of runtimePaths){let bytes=await fs.readFile(path.join(root,file));report.sources.push({path:file,bytes:bytes.length,sha256:sha(bytes)});
    if(file==='renderer/virgl-command/state.mjs'&&fault){const needle='const lanes = ["v.r", "v.g", "v.b", "v.a", "0.0", "1.0"];',replacement='const lanes = ["v.r", "v.g", "v.b", "v.a", "0.0", "0.0"];';const original=bytes.toString();assert.equal(original.split(needle).length,2);bytes=Buffer.from(original.replace(needle,replacement));report.sabotage={path:file,needle,replacement,originalSha256:sha(Buffer.from(original)),servedSha256:sha(bytes)};await fs.writeFile(path.join(output,'fault-source.mjs'),bytes);}
    endpoints.set('/'+file,{bytes,type:file.endsWith('.wasm')?'application/wasm':'text/javascript'});
  }
  const served=new Map();server=createServer((req,res)=>{const name=new URL(req.url,'http://localhost').pathname;if(name==='/favicon.ico'){res.writeHead(204).end();return;}const item=endpoints.get(name);if(!item){res.writeHead(404).end('not found');return;}served.set(name,{path:name,bytes:item.bytes.length,sha256:sha(item.bytes)});res.writeHead(200,{'Content-Type':item.type,'Cache-Control':'no-store','Cross-Origin-Opener-Policy':'same-origin','Cross-Origin-Embedder-Policy':'require-corp'}).end(item.bytes);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const {chromium}=await import(pathToFileURL(path.join(root,'web/node_modules/playwright/index.mjs')));
  browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:false,args:['--enable-gpu']});
  const session=await browser.newBrowserCDPSession(),system=await session.send('SystemInfo.getInfo'),commandLine=await session.send('Browser.getBrowserCommandLine');report.browser={version:browser.version(),headless:false,gpu:system.gpu,commandLine:commandLine.arguments};assert.equal(system.gpu.featureStatus.webgl2??system.gpu.featureStatus.webgl,'enabled');
  const context=await browser.newContext({viewport:{width:1100,height:900}}),page=await context.newPage();page.on('console',v=>{if(v.type()==='error')report.errors.console.push(v.text());});page.on('pageerror',e=>report.errors.page.push(e.message));page.on('requestfailed',r=>report.errors.requests.push(r.url()));
  await page.goto('http://127.0.0.1:'+server.address().port,{waitUntil:'load'});
  const cdp=await context.newCDPSession(page);await cdp.send('Profiler.enable');await cdp.send('Profiler.startPreciseCoverage',{callCount:true,detailed:true});
  report.result=await page.evaluate(async data=>{try{const {runNovel}=await import('/novel-hardware.mjs');return await runNovel(await(await fetch('/fixtures.json')).json(),data);}catch(e){return{status:'failed',failure:{message:e.message,stack:e.stack},partial:window.__viewNovel};}},inputs);
  const coverage=await cdp.send('Profiler.takePreciseCoverage');await fs.writeFile(path.join(output,'browser-coverage.json'),JSON.stringify(coverage,null,2)+'\n');report.coverageSha256=sha(await fs.readFile(path.join(output,'browser-coverage.json')));await cdp.send('Profiler.stopPreciseCoverage');await page.screenshot({path:path.join(output,'browser.png'),fullPage:true});report.screenshotSha256=sha(await fs.readFile(path.join(output,'browser.png')));report.servedFiles=[...served.values()];
  assert.deepEqual(report.errors,{console:[],page:[],requests:[]});
  if(fault){assert.equal(report.result.status,'failed');assert.match(report.result.failure.message,/physical lane/);assert.match(report.result.failure.message,/wanted255 got0/);report.status='fault-rejected';}
  else {assert.equal(report.result.status,'passed',report.result.failure?.message);assert.ok(report.result.assertions.every(a=>a.held));report.status='passed';}
}catch(e){report.status='failed';report.failure={message:e.message,stack:e.stack};process.exitCode=1;}
finally{await fs.writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n');await browser?.close();if(server)await new Promise(resolve=>server.close(resolve));}
console.log(JSON.stringify({mode,status:report.status,draws:report.result?.draws?.length,assertions:report.result?.assertions?.length,failure:report.result?.failure??report.failure,reportSha256:sha(await fs.readFile(path.join(output,'report.json')))},null,2));
