#!/usr/bin/env python3
import hashlib, json, pathlib, subprocess, tarfile

ROOT = pathlib.Path(__file__).resolve().parents[3]
OUT = pathlib.Path(__file__).resolve().parent
WORKER = ROOT / 'evidence/virgl-texture-views/worker'
FROZEN = '7b4fbb11b3d386319b7050d7fc1e0442494d4f68'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(file): return json.loads(file.read_bytes())
manifest = read(WORKER / 'manifest.json')
assert manifest['sourceHead'] == FROZEN
for key in ('archive', 'recordIndex'):
    raw = (WORKER / manifest[key]['path']).read_bytes()
    assert len(raw) == manifest[key]['bytes'] and sha(raw) == manifest[key]['sha256']
assert manifest['archive']['sha256'] == 'de6d0334fed7059bb9af7dfaa5bd52ed2531089091ef1ce74e65970bb0789830'
records = read(WORKER / 'records.json')
indexed = {r['path']: r for r in records}
assert len(indexed) == len(records) == manifest['records'] == 63
raws = {}
with tarfile.open(WORKER / 'recording.tar.gz', 'r:gz') as tar:
    for member in tar.getmembers():
        p = pathlib.PurePosixPath(member.name)
        assert member.isfile() and not p.is_absolute() and '..' not in p.parts
        assert member.name in indexed and member.name not in raws
        raw = tar.extractfile(member).read()
        r = indexed[member.name]
        assert len(raw) == r['bytes'] and sha(raw) == r['sha256'], member.name
        raws[member.name] = raw
        out = OUT / 'recording' / member.name
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(raw)
assert set(raws) == set(indexed)
get = lambda name: json.loads(raws[name])
hot = get('hot/receipt.json')
cold = get('cold/acceptance/receipt.json')
cold_report = get('cold/report.json')
for name, key in [('hot/receipt.json', 'receiptSha256'), ('cold/acceptance/receipt.json', 'coldReceiptSha256'), ('cold/report.json', 'coldReportSha256')]:
    assert sha(raws[name]) == manifest[key]
assert hot['sources'] == cold['sources'] and hot['inputs'] == cold['inputs']
assert all(r['gitHead'] == FROZEN and r['status'] == 'passed' for r in (hot, cold, cold_report))
assert cold_report['cloneHead'] == FROZEN and cold_report['exitCode'] == 0
assert cold_report['statusBefore'] == cold_report['statusAfter'] == ''
source_checks = []
for item in hot['sources'] + hot['inputs']:
    file = item['path']
    if file == 'renderer/virgl-shader/build/wasm/virgl-shader.mjs': raw = raws['build/virgl-shader.mjs']
    elif file == 'renderer/virgl-shader/build/wasm/virgl-shader.wasm': raw = raws['build/virgl-shader.wasm']
    else: raw = subprocess.check_output(['git', 'show', f'{FROZEN}:{file}'], cwd=ROOT)
    assert len(raw) == item['bytes'] and sha(raw) == item['sha256'], file
    current = (ROOT / file).read_bytes()
    assert sha(current) == item['sha256'], 'current source drift: ' + file
    source_checks.append(item)
reports = []
for prefix in ('hot', 'cold/acceptance'):
    receipt = get(prefix + '/receipt.json')
    for record in receipt['records']:
        name = prefix + '/' + record['path']
        assert sha(raws[name]) == record['sha256'] and len(raws[name]) == record['bytes'], name
    for name, raw in raws.items():
        if not name.startswith(prefix + '/') or not name.endswith('/report.json'): continue
        r = json.loads(raw)
        assert r['gitHead'] == FROZEN, name
        if 'browserResult' not in r:
            assert r['status'] == 'passed' and r.get('native',r.get('node'))['status'] == 'passed', name
            reports.append({'path':name,'sha256':sha(raw),'status':r['status']})
            continue
        fault = '/sabotage-' in name
        assert r['status'] == r['browserResult']['status'] == ('failed' if fault else 'passed'), name
        assert r['browser']['headless'] is False and r['browser']['gpu']['featureStatus'].get('webgl2',r['browser']['gpu']['featureStatus'].get('webgl')) == 'enabled', name
        assert r['browserErrors'] == {'console':[], 'page':[], 'requests':[]}, name
        assert not any('swiftshader' in arg.lower() or '--disable-gpu' in arg for arg in r['browser']['commandLine']), name
        sources = {s['path']:s for s in r['sources']}
        served = {s['path']:s for s in r['servedFiles']}
        sabotage = r.get('sabotage',{})
        for s in r['sources']:
            assert s['sha256'] == next(x['sha256'] for x in hot['sources'] if x['path'] == s['path']), name + ':' + s['path']
            if '/'+s['path'] in served:
                expected = sabotage['servedSha256'] if s['path'] == sabotage.get('path') else s['sha256']
                assert served['/'+s['path']]['sha256'] == expected
        assert served['/fixtures.json']['sha256'] == r['fixtureTransport']['sha256']
        cv = get(str(pathlib.PurePosixPath(name).parent / r['browserCoverage']['path']))
        for s in cv.get('scripts',[cv] if 'source' in cv else []):
            expected = sabotage['servedSha256'] if s['source'] == sabotage.get('path') else sources[s['source']]['sha256']
            assert s['sha256'] == expected
        native = r.get('native',r.get('node'))
        if native is not None:
            assert native['status'] == 'passed'
            if 'native' in r['browserResult']: assert native == r['browserResult']['native']
        reports.append({'path':name,'sha256':sha(raw),'status':r['status'],'gpu':r['browser']['gpu']['devices'],'sourceFault':sabotage})
audit = {'status':'passed','sourceHead':FROZEN,'manifestSha256':sha((WORKER/'manifest.json').read_bytes()),'archiveSha256':manifest['archive']['sha256'],'indexSha256':manifest['recordIndex']['sha256'],'members':len(raws),'hotColdSameSources':True,'hotColdSameInputs':True,'cold':cold_report,'sourceChecks':source_checks,'reports':reports}
(OUT / 'authentication.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({'status':audit['status'],'members':len(raws),'boundSourceAndInputFiles':len(source_checks),'recordedReports':len(reports),'coldHead':cold_report['cloneHead'],'coldPristine':True},indent=2))
