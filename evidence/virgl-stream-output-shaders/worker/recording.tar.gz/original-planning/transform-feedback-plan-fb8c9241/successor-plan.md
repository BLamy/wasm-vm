# Transform feedback successor plan

Read-only preparation during D64 independent verification. This is not activated work.

## D65: original stream-output compiler layout

One host-selected standard compiler facet over the original four strides and up to128
original two-word output entries. Bounds: register0..31, start0..3, count1..4, start+count<=4,
buffer0..3, stream0, declared components, disjoint destination ranges inside the original
uint16 stride, up to64 selected components per buffer. Typed C validation consumes original
packed words; JS only validates own-data request custody. Native output values are uint/uvecN
from the original output register, before host position adjustment. Initialize only the new
facet's output registers to zero for unwritten captured lanes. Distinct profile and explicit
host-selected capture-buffer variant; historical facets preserve response bytes and admission.
No decoder, resource, capset, guest or draw authority follows from this isolated facet.

Each native capture program links only its selected buffer outputs with a minimal fragment
shader so unrelated raster varyings do not exhaust the native vertex-output ceiling. No JS
source rewriting. Native interleaved capture stays <=64 components; layout metadata carries
original destinations and strides separately for the consumer. Physically check every captured
word, including signed zero, NaN encodings, true masks, POSITION before Y adjustment, component
ranges, four buffers and64-component boundary. Native/Wasm metadata and strings must agree.

## D66: original targets and native capture

Explicit decoder/store/renderer selector inherits qualified D64 behavior and D65 compiler.
Original VirGL bind STREAM_OUTPUT is2048 (1<<11), not128. Admit it in all ordinary buffer-role
combinations; object10 owns original resource generation, offset and size. Opcode25 retains
original target slots/append mask. Preserve target cursor/count ownership across detach,
delete/name reuse, subcontexts, pending fences and reset. Rasterizer discard is original bit3.

Capture original assembled primitive vertex order independently of raster-provoking/stencil
lowering. Use GPU transform feedback into charged, job-owned packed storage. Scatter captured
words via GPU copyBufferSubData into original destinations, preserving stride gaps and inactive
buffers. Unbind indexed transform feedback before other-data copies and later vertex/index/
uniform roles. For multiple buffers, bounded auxiliary capture passes do not alter visible
raster, stencil, guest query counts or cursor counts. Verify original complete output/DMA bytes,
overflow at complete primitive boundaries, append/reset, original count-override semantics against
pinned virglrenderer, role reuse and asynchronous cancellation/lifetime.

## Source findings requiring exact confirmation

Mesa26.2.2 virgl_screen.c313..315 advertises64 components for both separate and interleaved
stream output. virgl_streamout.c75..95 currently ignores offset array and sends append mask0.
virgl_encode.c1005..1006 serializes count_from_stream_output->buffer_size as word12. The
pinned renderer ca50e008 decoder passes this value as cso, and vrend_renderer.c6094..6095
uses nonzero cso directly as the nonindexed vertex count with start0. It is not a target
handle and must not be looked up as one. Indexed draws do not use cso. The archive matches
all67 vendored source pins and both full renderer/decoder mirrors byte for byte. Its SHA256
is e7c512469a207444103ead88a8992a7077173e21771623845d4567f8128b5dc1. Original
source layout max outputs128, buffer count4, destination and stride in dwords; output stream0.

## Remaining production acceptance

After TF verification, typed capsets must qualify the real host limits and every positive bit,
including a real query contract if required for GLES3 qualification. Wire the same qualified
bridge into production Machine worker before device negotiation, connect retained scanout to
the visible presenter, and prove actual Mesa/Hyprland/kmscube guest operation and recovery.
Experimental compiler or proof VM execution cannot stand in for those final guest runs.
