import {createHash} from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {decodeStandardDimensionalDepthSurfaceSubmission} from '../../../renderer/virgl-command/decoder.mjs';
import {computeStandardDimensionalDepthTransferLayout} from '../../../renderer/virgl-command/resources.mjs';
const root=path.dirname(new URL(import.meta.url).pathname),repo=process.cwd(),sha=b=>createHash('sha256').update(b).digest('hex');
const packet=(op,type,words)=>{const b=Buffer.alloc(4+words.length*4);b.writeUInt32LE((words.length<<16)|(type<<8)|op);words.forEach((v,i)=>b.writeUInt32LE(v>>>0,4+i*4));return new Uint8Array(b);};
const text='VERT\nDCL IN[0]\nDCL OUT[0], POSITION\n0: MOV OUT[0], IN[0]\n1: END\n',raw=Buffer.from(text+'\0'),padded=Buffer.alloc(Math.ceil(raw.length/4)*4);raw.copy(padded);
const words=Array.from({length:padded.length/4},(_,i)=>padded.readUInt32LE(i*4));
const input=[
 ['original-vertex-stream-output',packet(1,4,[40,0,raw.length,64,1,4,0,0,0,4<<10,0,...words])],
 ['original-stream-target',packet(1,10,[44,200,12,128])],
 ['original-stream-target-binding',packet(25,0,[0,44])],
 ['original-rasterizer-discard',packet(1,2,[45,2|(1<<29)|8,0x3f800000,0,65535,0x3f800000,0,0,0])],
 ['original-count-from-stream-output',packet(8,0,[0,3,0,0,1,0,0,0,0,0,0xffffffff,44])],
];
const results=input.map(([name,bytes])=>({name,wireHex:Buffer.from(bytes).toString('hex'),wireSha256:sha(bytes),result:decodeStandardDimensionalDepthSurfaceSubmission(bytes)}));
const metadata={id:200,target:0,format:64,bind:2048,width:512,height:1,depth:1,arraySize:1,lastLevel:0,nrSamples:0,flags:0};
const request=packet(43,0,[200,0,0,0,0,0,0,0,512,1,1,0,1]),fields=decodeStandardDimensionalDepthSurfaceSubmission(request).commands[0].fields;
results.push({name:'original-stream-output-buffer-role',metadata,wireHex:Buffer.from(request).toString('hex'),wireSha256:sha(request),result:computeStandardDimensionalDepthTransferLayout(metadata,fields,512)});
if(results.some(r=>r.result.ok!==false))throw Error('Unexpected readiness admission.');
const sources={};
for(const name of ['renderer/virgl-command/decoder.mjs','renderer/virgl-command/resources.mjs','renderer/virgl-shader/vendor/src/virgl_protocol.h','renderer/virgl-shader/vendor/src/gallium/include/pipe/p_defines.h','renderer/virgl-shader/vendor/src/gallium/include/pipe/p_state.h','crates/core/src/dev/virtio/gpu/control3d.rs','tools/virgl-floating-depth/primary/virgl_screen.c','tools/virgl-floating-depth/primary/st_extensions.c','tools/virgl-floating-depth/primary.json']){
 const body=await fs.readFile(path.join(repo,name)),file=path.join(root,'sources',name);await fs.mkdir(path.dirname(file),{recursive:true});await fs.writeFile(file,body);sources[name]={bytes:body.length,sha256:sha(body)};
}
const report={schema:'original-stream-output-negative-readiness-v1',head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),actualGPU:false,actualGuestQueue:false,productionAuthority:false,sourcePins:sources,results};
await fs.writeFile(path.join(root,'report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(results.map(r=>({name:r.name,ok:r.result.ok,error:r.result.error}))));
