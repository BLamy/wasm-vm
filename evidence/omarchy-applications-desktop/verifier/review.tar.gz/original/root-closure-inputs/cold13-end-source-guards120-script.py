from pathlib import Path
import datetime,hashlib,json,subprocess

root=Path(__file__).resolve().parents[3]
base=root/'target/evidence/omarchy-applications-pristine01'
run=base/'run13-image18-native-note-a7'
clone=base/'clone-native-note97'
report=json.loads((run/'report.json').read_bytes())
assert report['status']=='failed'
assert report['head']=='17f680a90f6082ca6b39dbf4dae002436c96d5ca'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()=='81fa138e12a898de5586b1cdd0c663484150f5e6'
assert subprocess.check_output(['git','status','--short','--untracked-files=no'],cwd=clone,text=True)==''
records=[]
def check(path,expected,kind):
    body=path.read_bytes();observed=hashlib.sha256(body).hexdigest()
    assert observed==expected,(str(path),expected,observed)
    records.append(dict(path=str(path.relative_to(root)),bytes=len(body),sha256=observed,kind=kind))
web=Path(report['webRoot'])
for name,sha in report['sourceHashes'].items():
    check(web/name,sha,'original web source unchanged')
    check(run/'executed-source'/name,sha,'original captured source unchanged')
for record in report['localRuntimeSources']:
    check(web/record['path'],record['sha256'],'actual served source still exact')
    check(run/record['bodyPath'],record['sha256'],'retained served bytes exact')
for name,sha in report['harnessHashes'].items():
    check(run/'executed-harness'/name,sha,'original executed harness retained')
    if name!='omarchy-applications.mjs':
        source=clone/name if name.startswith('renderer/') else clone/'tools/virgl-production'/name
        check(source,sha,'unchanged resident harness')
check(clone/'tools/virgl-production/omarchy-applications.mjs','d629062803c8d8762caf3016e59573274f11fda3c970cfbd50ebe1bcb673431b','explicit admitted missing-only helper81fa')
check(run/'control-applications-cold13-writer-open16-source.mjs','d629062803c8d8762caf3016e59573274f11fda3c970cfbd50ebe1bcb673431b','actual executed continuation source')
check(Path(report['candidate']['directory'])/'manifest.json',report['candidate']['manifestSha256'],'original candidate manifest unchanged')
check(Path(report['applicationImageInventory']['path']),report['applicationImageInventory']['sha256'],'accepted native inventory unchanged')
check(run/'input-runtime-elf.json',report['applicationImageInventory']['sha256'],'recorded native inventory exact')
check(run/'omarchy-initial-native-applications.json','894df61ff71aee51dddfb735e211844798b7d990f5db22d80900edfa3d2fc28a','original failed application report retained')
check(run/'report.json','ae0e4c6839a12d841e5e30dbe5c0a5b3f8c46d89b9e8fab91e8fc6cf6be3a596','original parent retained before ordinary closure')
result=dict(createdUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='passed',scope='Read-only original source, captured served bodies, accepted inventory and image manifest end guards after the missing-only continuation and before owned normal release. Original parent/application remain FAILED. Only the admitted helper81fa differs from original17f; no runtime/browser/backend/clock/image change. Ordinary parent finally will append the closed GPU digest without relabelling its result.',records=records)
path=base/'cold13-end-source-guards120.json'
with path.open('x') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(path=str(path.relative_to(root)),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),records=len(records))))
