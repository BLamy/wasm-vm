from pathlib import Path
import json,hashlib,subprocess,datetime,stat,os
root=Path(__file__).resolve().parents[3]
assert root.name=='wasm-vm'
base=root/'target/evidence/omarchy-applications-pristine01'
run=base/'run13-image18-native-note-a7'
clone=base/'clone-native-note97'
helper=clone/'tools/virgl-production/omarchy-applications.mjs'
assert hashlib.sha256(helper.read_bytes()).hexdigest()=='d629062803c8d8762caf3016e59573274f11fda3c970cfbd50ebe1bcb673431b'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()=='81fa138e12a898de5586b1cdd0c663484150f5e6'
report_path=run/'omarchy-initial-native-applications.json'
report_bytes=report_path.read_bytes();report=json.loads(report_bytes)
submission=report['browserSubmission']
assert submission['message']=='omarchy chromium riscv 42' and submission['clickTrusted'] is True
assert len(submission['inputTrusted'])>=25 and all(x is True for x in submission['inputTrusted'])
assert [r['label'] for r in report['noteControls']]==['before-input','before-save']
assert any(e.get('kind')=='screenshot' and e.get('label')=='chromium-submitted' for e in report['phases'])
assert report['firstSave']=={'sha256':'719cb212524f8393c9cf9fc7b227787f272671114e8a8526f669ac29ddef45af','bytes':8716,'text':'Omarchy riscv document 42'}
assert report['writer']['window']['pid']==8471
assert report['status']=='failed' and 'Actual guest application window did not close' in report['error']
assert report.get('secondSave') is None
component_path=run/'control-applications-cold13-writer-open16.json'
component_bytes=component_path.read_bytes();component=json.loads(component_bytes)
assert component['secondSave']=={'sha256':'7c9ce9319d72fee61f8952da3e3ac495e5ba28136a1257ddc17972e9f70f9b5d','bytes':9177,'text':'Omarchy riscv document 42 Reopened and saved'}
assert component['status']=='passed'
assert component['nodeNpm']=={'stdout':'riscv64\n12.2.0\n\n','exit':0}
assert component['wallpaperTransitions']['result']['status']=='passed'
assert component['publicDesktopInput']['status']=='passed'
assert all(x['trusted'] is True for x in component['trusted'])
assert len(component['trusted'])==382
shell=json.loads((run/'control-response-cold13-default-apps17.json').read_bytes())
assert shell['result']['status']=='passed' and not shell.get('error')
final=json.loads((run/'control-response-cold13-final-state18.json').read_bytes())
assert not final.get('error') and final['result']['gpu']['pending'] is None
release=json.loads((run/'control-response-cold13-normal-release19.json').read_bytes())
assert release['result']=={'release':True}
closed=json.loads((base/'native-note97-source/exit.json').read_bytes())
assert closed['exit']==1 and closed['nodePid']==10296
parent=json.loads((run/'report.json').read_bytes())
assert parent['status']=='failed' and parent['gpuRecording']['bytes']==1703462764
assert parent['gpuRecording']['sha256']=='6de847e7675af2382d2cb7d0a511967bc4b1102f974bbfc06608f5b5464c40db'
try:os.kill(10296,0)
except ProcessLookupError:pass
else:raise AssertionError('owned native capture must be closed')
out=base/'cold13-final-components-closed-frozen01';out.mkdir()
records=[]
def digest(path,limit=None):
 h=hashlib.sha256();total=0
 with path.open('rb') as f:
  while limit is None or total<limit:
   b=f.read(1048576 if limit is None else min(1048576,limit-total))
   if not b:break
   total+=len(b);h.update(b)
 if limit is not None:assert total==limit
 return total,h.hexdigest()
def record(src,dst):
 size,sha=digest(dst);records.append({'source':str(src.relative_to(root)),'path':str(dst.relative_to(out)),'bytes':size,'sha256':sha})
def copy_regular(src,dst,append=False):
 assert stat.S_ISREG(src.lstat().st_mode) and not src.is_symlink()
 dst.parent.mkdir(parents=True,exist_ok=True)
 subprocess.run(['cp','-c',str(src),str(dst)],check=True)
 if append:
  with dst.open('r+b') as f:
   f.seek(0,2);length=f.tell()
   if length:
    f.seek(max(0,length-1048576));tail=f.read();at=tail.rfind(b'\n');assert at>=0
    f.truncate(length-len(tail)+at+1)
  size,sha=digest(dst);assert digest(src,size)==(size,sha)
 else:
  assert digest(src)==digest(dst),str(src)
 record(src,dst)
paths=sorted(p for p in run.rglob('*') if p.is_file() and p!=report_path and p!=component_path and p.name!='gpu.ndjson')
for src in paths:copy_regular(src,out/'payloads'/src.relative_to(run),src.suffix=='.ndjson')
frozen_report=out/'payloads'/report_path.name;frozen_report.write_bytes(report_bytes);record(report_path,frozen_report)
frozen_component=out/'payloads'/component_path.name;frozen_component.write_bytes(component_bytes);record(component_path,frozen_component)
copy_regular(run/'gpu.ndjson',out/'gpu-prefix.ndjson',True)
for src in sorted((base/'native-note97-source').iterdir()):
 if src.is_file():copy_regular(src,out/'launch-source'/src.name,src.suffix=='.log')
copy_regular(helper,out/'executed-source/omarchy-applications.mjs')
copy_regular(clone/'tools/virgl-production/critic-fast-boots.mjs',out/'executed-source/critic-fast-boots.mjs')
for name in ['cold13-end-source-guards120-script.py','cold13-end-source-guards120.json','control-request-cold13-default-apps17-staged.json','control-request-cold13-final-state18-staged.json','control-request-cold13-normal-release19-staged.json']:
 copy_regular(base/name,out/'root-closure-inputs'/name)
copy_regular(Path(__file__),out/'freeze-script.py')
receipt={'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Frozen normal-closed same-live cold13 incremental component16 PASSED under admitted helper81fa/d629, separate normal Apps17 PASSED, actual later worker snapshot18,248 original source end guards120 and ordinary release19. Original17f/32f cold application staysFAILED and final parent staysFAILED/exit1 with added closedGPU digest. New Node/npm, canonical sampled-grid wallpaper return, stock42/bar/workspace/pointer/pause/clock, flushed382true events and final qualified worker/scanout are submitted for separate verification. Carry original cold Chromium/SVG, first/resaved Writer and prior exact-boundary HELD results. This is not a literal one-shot make pass, new cold VM, factory pair, external browsing, deployment or complete recovery claim. No runtime/image/backend/clock change.','sourceHead':'81fa138e12a898de5586b1cdd0c663484150f5e6','originalColdHead':'17f680a90f6082ca6b39dbf4dae002436c96d5ca','componentStatusAtCopy':component['status'],'componentLastRecordedPhaseTime':component['phases'][-1].get('time'),'records':records,'originalReportStatusAtCopy':report['status'],'lastRecordedPhaseTime':report['phases'][-1].get('time'),'scriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'status':'frozen; all nonappend copies exact; append streams authenticated complete-line prefixes'}
index=out/'custody.json';index.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'path':str(index.relative_to(root)),'bytes':index.stat().st_size,'sha256':hashlib.sha256(index.read_bytes()).hexdigest(),'records':len(records)}))
