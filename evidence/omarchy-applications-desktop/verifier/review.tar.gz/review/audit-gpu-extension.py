from pathlib import Path
import collections,gzip,hashlib,json
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');O=Path(__file__).resolve().parent;B=ROOT/'target/evidence/omarchy-applications-pristine01/cold13-final-components-closed-frozen01'
oldBytes=1432914618;oldHash='677df46c04591332a0b275a88632d64e241f67ede7621a03be0130333245629a';oldRows=43902
h=hashlib.sha256();left=oldBytes
with (B/'gpu-prefix.ndjson').open('rb') as f:
 while left:
  b=f.read(min(8*1024*1024,left));assert b;h.update(b);left-=len(b)
 assert h.hexdigest()==oldHash
 at=oldBytes;newh=hashlib.sha256();types=collections.Counter();events=collections.Counter();statuses=collections.Counter();epochs=set();bad=[];special=[]
 with (O/'gpu-suffix.ndjson.gz').open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as gz:
  for n,line in enumerate(f,oldRows+1):
   assert line.endswith(b'\n');offset=at;at+=len(line);newh.update(line);gz.write(line);v=json.loads(line);types[v.get('type')]+=1;e=v.get('event',{});r=v.get('result',{});events[e.get('type')]+=1
   if e.get('epoch'):epochs.add(e['epoch'])
   if isinstance(r,dict):
    if r.get('ok') is False:bad.append({'row':n,'offset':offset,'event':e,'result':r})
    if r.get('status'):statuses[r['status']]+=1
   if v.get('type')=='qualified' or any(x in str(e.get('type','')).lower() for x in ['reset','restore','import','lost','dispose']):special.append({'row':n,'offset':offset,'event':e,'type':v.get('type')})
 assert at==1703462764 and epochs=={'0000000000000002'} and not bad and not special
r={'status':'HELD final closed same-live component GPU trace extends exact previously frozen resave bytes','prior':{'bytes':oldBytes,'sha256':oldHash,'rows':oldRows,'carriedSeal':'413d108b1862a3f2a3e682bb94c9ddbddf8a6974459cd3c90fef623d5ec3b2f2'},'suffix':{'bytes':at-oldBytes,'sha256':newh.hexdigest(),'rows':n-oldRows,'firstRow':oldRows+1,'types':dict(types),'events':{str(k):v for k,v in events.items()},'statuses':dict(statuses),'epochs':sorted(epochs),'explicitOkFalse':bad,'resetImportRestoreQualification':special},'fullOriginal':{'bytes':at,'rows':n,'sha256':'6de847e7675af2382d2cb7d0a511967bc4b1102f974bbfc06608f5b5464c40db'},'limits':'Normal-closed complete stream, original parent remainsFAILED/exit1 while explicit component16 and separate Apps17 have their own outcomes. Later factory/warm/recovery/publication remain unclaimed; actual worker/lifecycle audit is separate.'}
(O/'gpu-extension-audit.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
