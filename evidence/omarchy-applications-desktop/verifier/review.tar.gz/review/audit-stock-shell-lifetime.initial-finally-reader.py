from pathlib import Path
import base64,collections,hashlib,json,math,re,stat
from png_reader import png_rgba
R=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');O=Path(__file__).resolve().parent;B=R/'target/evidence/omarchy-applications-pristine01/cold13-final-components-closed-frozen01';P=B/'payloads';OLD=R/'target/evidence/omarchy-applications-pristine01/resumed-writer16-resaved-prefix-frozen01';sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda n:json.loads((P/n).read_bytes())
a=load('control-applications-cold13-writer-open16.json');i=a['publicDesktopInput'];f=a['publicDesktopFinal'];assert a['status']==i['status']=='passed' and a['pageErrors']==f['pageErrors']==f['workerErrors']==[]
assert i==load('control-applications-cold13-writer-open16-public-desktop-input.json') and i['uid']=='1000' and i['options']['initialClockMode']=='paced-icount' and i['interactivePolicy']=='paced-on-keyboard' and i['initialClock']['mode']=='paced-icount'
assert i['typedText']=='touch /tmp/gpukeyboard42touch' and i['markerAbsent']['exit']==0 and i['marker']=={'stdout':'TRUSTED_TOUCH_42\n\n','exit':0} and i['immediateFocus']['pid']==i['foot']['pid']==704
stages={x['stage']:x['time'] for x in i['stages']};assert stages['marker-1']-stages['typed']==3541 and stages['marker-1']-stages['typed']<120000
bi=i['browserInput'];assert bi['focus']=='ide-display-canvas' and bi['capture']=='on' and bi['held']==[] and bi['debug']['held']==[]
for key in ['pendingEvents','pendingFrames','droppedFrames','droppedEvents','rejectedEvents']:assert bi['stats'][key]==i['inputAfter'][key]==0
assert len(bi['events'])==60 and all(x['trusted'] is True for x in bi['events']) and all(x['time']<=y['time'] for x,y in zip(bi['events'],bi['events'][1:]));down=[x for x in bi['events'] if x['type']=='keydown'];up=[x for x in bi['events'] if x['type']=='keyup'];assert len(down)==len(up)==30
assert ''.join(x['key'] for x in down[:-1])==i['typedText'] and down[-1]['key']=='Enter' and [x['code'] for x in down]==[x['code'] for x in up]
assert bi['frames'][-2:]==[{'eventType':1,'code':'Enter','evdev':28,'value':1,'sync':0},{'eventType':1,'code':'Enter','evdev':28,'value':0,'sync':0}]
# Exact actual bar capture: every original PNG pixel equals its RGBA record.
bar=i['barContent'];assert bar['status']=='passed' and bar['overlappingClients']==[] and bar['layer']['namespace']=='omarchy-bar' and bar['layer']['alpha']==1 and bar['layer']['pid']==728 and bar['layer']['h']==26
stem='control-applications-cold13-writer-open16-public-desktop-input-bar-content-000';pixels=(P/(stem+'.rgba')).read_bytes();width,height,png=png_rgba((P/(stem+'.png')).read_bytes());assert (width,height)==(1280,26) and png==pixels and sha(pixels)==bar['capture']['rgbaSha256']
# Independent Python implementation of foreground metric, over original decoded pixels.
hist=collections.Counter(tuple(pixels[(y*width+x)*4:(y*width+x)*4+3]) for y in range(2,height-2) for x in range(2,width-2) if pixels[(y*width+x)*4+3]);bg,bgcount=hist.most_common(1)[0];fg=[]
for y in range(2,height-2):
 for x in range(2,width-2):
  q=pixels[(y*width+x)*4:(y*width+x)*4+4];d=[abs(q[c]-bg[c]) for c in range(3)]
  if q[3] and max(d)>=32 and sum(d)>=64:fg.append((x,y))
assert len(fg)==bar['content']['foregroundPixels']==808 and len({y for x,y in fg})==12 and sorted({min(7,x*8//width) for x,y in fg})==[0,3,4,7] and max(x for x,y in fg)-min(x for x,y in fg)+1==1249
ba=i['barActions'];assert ba==load('control-applications-cold13-writer-open16-public-desktop-input-bar-actions.json') and ba['status']=='passed' and ba['before']['workspace']['id']==ba['after']['workspace']['id']==1
assert [x['expected'] for x in ba['actions']]==[2,1] and all(x['observed']['id']==x['expected'] and 0<=x['x']<1280 and 0<=x['y']<26 for x in ba['actions']) and len(ba['moves'])==6
cont=ba['continuity'];assert cont['overflow'] is False and len(cont['samples'])==2102 and len(cont['events'])==54 and all(x['trusted'] is True for x in cont['events'])
assert all(len(x['alpha'])==9 and all(0<=y<=255 for y in x['alpha']) and not x['blank'] and not all(y==0 for y in x['alpha']) for x in cont['samples']);assert all(x['time']<=y['time'] for x,y in zip(cont['samples'],cont['samples'][1:]))
assert len(cont['samples'])>=30 and ba['after']['gpu']['counters']['completed']>ba['before']['gpu']['counters']['completed'] and ba['after']['gpu']['counters']['failed']==0
x,y=map(int,i['cursor'].replace(' ','').split(','));assert abs(x-i['target']['x'])<=4 and abs(y-i['target']['y'])<=4 and math.hypot(x-i['initialCursor']['x'],y-i['initialCursor']['y'])>=16
# Recompute pause/clock bound instead of trusting helper's printed result.
c=i['clockProbe'];cl=[c[k] for k in ['beforePause','afterPause','resumed','progressed']];assert all(v['mode']=='paced-icount' and v['clockDiv']==64 and v['timebaseHz']==10000000 for v in cl)
assert cl[0]['mtime']==cl[1]['mtime'] and c['retired']['beforePause']==c['retired']['afterPause'];assert int(cl[3]['mtime'])>=int(cl[2]['mtime'])>=int(cl[1]['mtime']) and c['retired']['progressed']>=c['retired']['resumed']>=c['retired']['afterPause']
elapsed=c['progressReceived']-c['resumeSent'];ticks=int(cl[3]['mtime'])-int(cl[1]['mtime']);retirement=(c['retired']['progressed']-c['retired']['afterPause']+63)//64;maximum=math.ceil(elapsed*10000)+retirement+10000;assert 0<elapsed<c['pauseMillis'] and 0<ticks<=maximum
assert c['bound']==dict(actualTicks=str(ticks),maximumTicks=str(maximum),retirementTicks=str(retirement),elapsedMillis=elapsed)
def gpu(g):
 assert g['qualified'] and not any(g[k] for k in ['lost','poisoned','disposed']) and g['epoch']=='0000000000000002' and g['lastFailure'] is None and g['counters']['failed']==g['counters']['cancelled']==0 and g['counters']['draws']>0 and g['counters']['completed']>0 and g['counters']['begun']-g['counters']['completed']==(1 if g['pending'] else 0)
def final(v):
 assert v['workerErrors']==[] and not re.search(r'\*ERROR\*\s+response\s+0x[0-9a-f]+',v['serial'],re.I);gpu(v['gpu']);assert len(v['workers'])==1 and v['wireTotals']['send:boot']==v['wireTotals']['receive:ready']==1
 boot=v['workers'][0]['options'];assert boot['bootSnapshot']==False and boot['persist']==False and boot['virgl'] and boot['guestClock']=='icount' and boot['interactiveClock']=='paced-on-keyboard' and boot['ramMib']==1024
 assert collections.Counter(x['detail']['state'] for x in v['events'] if x['type']=='wvm:guest-state')=={'fetching':1,'instantiating':1,'booting':1}
 d=v['display'];assert d['backend']==d['defaultBackend']=='canvas2d' and d['errors']==[] and all(d[k]==0 for k in ['droppedFrames','contextLosses','contextRestores','fallbacks'])
final(f);assert f['gpu']['counters']['begun']==f['gpu']['counters']['completed']==12413 and f['gpu']['counters']['draws']==47294 and f['gpu']['pending'] is None
# Actual unmodified normal Apps/Escape, separate from original failed parent.
s=load('control-shell-cold13-default-apps17.json');rs=load('control-response-cold13-default-apps17.json');request=(P/'control-request-cold13-default-apps17.json').read_bytes();assert len(request)==59 and sha(request)=='7491a767c7b6f8cc9e02e4a5917967a5ab6ad976aebdc251e481a700d9a77c2e';assert json.loads(request)==rs['request']=={'id':'cold13-default-apps17','kind':'shell-ipc'} and rs['result']==s
assert s['status']=='passed' and len(s['phases'])==8 and s['openMs']==41679 and s['openMs']<=180000 and s['configErrors']==[''] and len(s['trusted'])==8 and all(x['trusted'] is True for x in s['trusted'])
q=s['config'];body=base64.b64decode(q['base64'],validate=True);assert len(body)==q['bytes']==1161 and sha(body)==q['sha256']=='73c5b469059b9aa8159cf6712a62a5d067216414fbe94d2ffb35ea3fdfa2341d' and q['uid']==1000 and q['mode']=='0o644' and q['nlink']==1 and q['isRegular']
def menu(stdout):return [v for m in json.loads(stdout).values() for group in m.get('levels',{}).values() for v in group if v.get('namespace')=='omarchy-menu' and v.get('alpha',0)>0]
assert all(x['result']['exit']==0 for x in s['phases']) and not menu(s['phases'][2]['result']['stdout']) and menu(s['phases'][6]['result']['stdout'])==[s['menu']] and not menu(s['phases'][7]['result']['stdout']) and s['phases'][7]['time']-s['phases'][6]['time']<120000
assert all('TIMEOUT=' not in x['command'] and not re.search(r'\b(start|reload|restart|ping)\b',x['command']) for x in s['phases']);gpu(s['beforeGpu']);gpu(s['afterGpu']);assert s['afterGpu']['counters']['draws']>s['beforeGpu']['counters']['draws']
# Explicit final real worker snapshot, normal release, closed originalreport/finally-only differences.
r16=load('control-response-cold13-writer-open16.json');assert r16['result']==a and r16['source']['sha256']=='d629062803c8d8762caf3016e59573274f11fda3c970cfbd50ebe1bcb673431b'
r18=load('control-response-cold13-final-state18.json');v=r18['result'];final(v);assert 'pageErrors' not in v and not v['restored'] and v['ready'] and not v['paused'] and v['overlayHidden'] and v['bootState']['lastBootError'] is None
assert v['workers']==f['workers'] and v['events']==f['events'] and v['gpu']['pending'] is None and v['gpu']['counters']['begun']==v['gpu']['counters']['completed']==12814 and v['gpu']['counters']['draws']==48293
assert v['wireTotals']['send:call']==v['wireTotals']['receive:result']==37667 and v['wireTotals']['send:input']==1365 and v['wireTotals']['send:boot']==1
r19=load('control-response-cold13-normal-release19.json');assert r19['request']=={'id':'cold13-normal-release19','kind':'release'} and r19['result']=={'release':True}
controls=[r16,rs,r18,r19];assert all(v['started']<=v['finished'] for v in controls) and all(x['finished']<y['started'] for x,y in zip(controls,controls[1:]));assert r16['started']==1792144492049
outer=load('report.json');old=json.loads((OLD/'payloads/report.json').read_bytes());assert outer['status']==old['status']=='failed' and outer['errors']==old['errors'];changed=[k for k in set(outer)|set(old) if outer.get(k)!=old.get(k)];assert set(changed)=={'gpuRecording','pageLifecycle'}
assert outer['pageLifecycle'][:-1]==old['pageLifecycle'] and outer['pageLifecycle'][-1]['type']=='page.close';assert collections.Counter(x['type'] for x in outer['pageLifecycle'])=={'Page.frameStartedNavigating':1,'Network.documentRequest':1,'page.framenavigated':1,'Page.frameNavigated':1,'page.close':1}
assert outer['pageLifecycle'][-1]['time']>=r19['finished'] and outer['gpuRecording']=={'path':'gpu.ndjson','bytes':1703462764,'sha256':'6de847e7675af2382d2cb7d0a511967bc4b1102f974bbfc06608f5b5464c40db'}
assert sha((P/'omarchy-initial-native-applications.json').read_bytes())=='894df61ff71aee51dddfb735e211844798b7d990f5db22d80900edfa3d2fc28a'
exit=json.loads((B/'launch-source/exit.json').read_bytes());assert exit['exit']==1 and exit['logSha256']==sha((B/'launch-source/launch.log').read_bytes()) and exit['logBytes']==(B/'launch-source/launch.log').stat().st_size and exit['nodePid']==10296
# All248 endguard input bodies independently rehash; one current parent is expected to gain finallyclosure only.
guards=json.loads((B/'root-closure-inputs/cold13-end-source-guards120.json').read_bytes());assert guards['status']=='passed' and len(guards['records'])==248;seen=set();actual=[]
for x in guards['records']:
 path=Path(x['path']);assert not path.is_absolute() and '..' not in path.parts and str(path) not in seen;seen.add(str(path));file=R/path;assert file.is_file() and not file.is_symlink();data=file.read_bytes()
 if x['kind']=='original parent retained before ordinary closure':assert x['sha256']==sha((OLD/'payloads/report.json').read_bytes()) and data==(P/'report.json').read_bytes();classification='only admitted normal finally fields added, independently compared'
 else:assert len(data)==x['bytes'] and sha(data)==x['sha256'],x;classification='actual original source body rehashed exact'
 actual.append(dict(path=str(path),kind=x['kind'],expectedBytes=x['bytes'],expectedSha256=x['sha256'],currentBytes=len(data),currentSha256=sha(data),classification=classification))
(O/'end-source-guards-independent.json').write_text(json.dumps(dict(status='all248 original/current bodies authenticated; only historical parent finally difference explicitly admitted',records=actual),indent=2)+'\n')
result=dict(status='HELD current stock input/defaultApps/actual final snapshots and normal closed lifetime',stock=dict(footPid=704,marker=i['marker'],markerAfterTypedMs=3541,trustedKeyEvents=60,allTrusted=True,noHeldOrDropped=True,barForeground=808,barSpan=1249,workspaceActions=[x['observed']['id'] for x in ba['actions']],pointerSamples=2102,trustedPointerEvents=54,allNinePointSamplesNonblank=True,cursor=i['cursor'],pause=c),defaultApps=dict(requestSha256=sha(request),status=s['status'],openMs=s['openMs'],normalCloseObserved=True,configSha256=q['sha256'],events=s['trusted']),componentFinal=dict(pageErrors=f['pageErrors'],workerErrors=f['workerErrors'],workers=len(f['workers']),counters=f['gpu']['counters'],pending=f['gpu']['pending'],wireTotals=f['wireTotals']),laterSnapshot18=dict(pageErrorsFieldPresent=False,workerErrors=v['workerErrors'],workers=len(v['workers']),counters=v['gpu']['counters'],pending=v['gpu']['pending'],wireTotals=v['wireTotals'],restored=v['restored']),normalClosure=dict(originalParentStatus=outer['status'],changedFinallyOnly=changed,pageLifecycle=outer['pageLifecycle'],exit=exit,controls=[dict(id=x['request']['id'],started=x['started'],finished=x['finished']) for x in controls]),endSourceGuards=248,limits='Nine-point alpha/rAF and forty-by-twentyfour wallpaper grids are sampled proofs, not every fullframe pixel/alltime. Actual component publicDesktopFinal contains pageErrors[], but later snapshot18 has no such field. Original coldFAILED/exit1 retained; no newfactory/warmrecovery/deploy/full-compatible147apps claim.')
(O/'stock-shell-lifetime-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k in ['status','endSourceGuards','defaultApps','componentFinal','laterSnapshot18']},indent=2))
