import struct,zlib
def png_rgba(data):
 assert data[:8]==b'\x89PNG\r\n\x1a\n';pos=8;packed=[];ihdr=None
 while pos<len(data):
  n=struct.unpack('>I',data[pos:pos+4])[0];kind=data[pos+4:pos+8];chunk=data[pos+8:pos+8+n];crc=struct.unpack('>I',data[pos+8+n:pos+12+n])[0];assert zlib.crc32(kind+chunk)&0xffffffff==crc;pos+=12+n
  if kind==b'IHDR':ihdr=struct.unpack('>IIBBBBB',chunk)
  elif kind==b'IDAT':packed.append(chunk)
  elif kind==b'IEND':break
 w,h,depth,color,compression,filter_method,interlace=ihdr;assert depth==8 and color in [2,6] and compression==filter_method==interlace==0
 bpp=3 if color==2 else 4;stride=w*bpp;raw=zlib.decompress(b''.join(packed));assert len(raw)==h*(stride+1);last=bytearray(stride);rgba=bytearray()
 for y in range(h):
  off=y*(stride+1);ft=raw[off];row=bytearray(raw[off+1:off+1+stride]);assert ft in range(5)
  for x in range(stride):
   left=row[x-bpp] if x>=bpp else 0;up=last[x];ul=last[x-bpp] if x>=bpp else 0
   if ft==1:pred=left
   elif ft==2:pred=up
   elif ft==3:pred=(left+up)//2
   elif ft==4:
    p=left+up-ul;pa,pb,pc=abs(p-left),abs(p-up),abs(p-ul);pred=left if pa<=pb and pa<=pc else up if pb<=pc else ul
   else:pred=0
   row[x]=(row[x]+pred)&255
  if bpp==4:rgba.extend(row)
  else:
   for x in range(0,stride,3):rgba.extend(row[x:x+3]);rgba.append(255)
  last=row
 return w,h,bytes(rgba)

