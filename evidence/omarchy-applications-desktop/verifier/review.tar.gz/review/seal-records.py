from pathlib import Path
import gzip,hashlib,io,json,sys,tarfile
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
planPath=Path(sys.argv[1]);plan=json.loads(planPath.read_text());OUT=ROOT/plan['output'];OUT.mkdir(exist_ok=True)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
inputs={name:ROOT/relative for name,relative in plan['inputs'].items()}
inputs['review/seal-records.py']=Path(__file__).resolve();inputs['review/seal-plan.json']=planPath.resolve()
records=[dict(path=name,source=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=digest(p)) for name,p in sorted(inputs.items())]
external=[]
for x in plan.get('external',[]):
 p=ROOT/x['source'];assert p.stat().st_size==x['bytes'] and digest(p)==x['sha256'];external.append(x)
index=json.dumps(dict(scope=plan['scope'],files=records,externalOriginalsNotDuplicated=external),indent=2).encode()+b'\n'
archive=OUT/plan['archive']
with archive.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tar:
 for row in records:
  p=inputs[row['path']];i=tarfile.TarInfo(row['path']);i.size=row['bytes'];i.mode=0o644;i.mtime=0;i.uid=i.gid=0;i.uname=i.gname=''
  with p.open('rb') as f:tar.addfile(i,f)
 i=tarfile.TarInfo('records.json');i.size=len(index);i.mode=0o644;i.mtime=0;i.uid=i.gid=0;i.uname=i.gname='';tar.addfile(i,io.BytesIO(index))
expected={x['path']:x for x in records};seen=set()
with tarfile.open(archive,'r|gz') as tar:
 for member in tar:
  f=tar.extractfile(member)
  if member.name=='records.json':assert f.read()==index;seen.add(member.name);continue
  row=expected[member.name];h=hashlib.sha256();n=0
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b);n+=len(b)
  assert n==row['bytes'] and h.hexdigest()==row['sha256'];seen.add(member.name)
assert seen==set(expected)|{'records.json'}
(OUT/'records.json').write_bytes(index)
receipt=dict(status='sealed; every member reopened/rehashed',archive=str(archive.relative_to(ROOT)),bytes=archive.stat().st_size,sha256=digest(archive),members=len(seen),indexSha256=hashlib.sha256(index).hexdigest(),scope=plan['scope'],externalOriginalsNotDuplicated=external)
(OUT/'authentication.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='externalOriginalsNotDuplicated'},indent=2))
