from pathlib import Path
import collections,gzip,hashlib,json,re,subprocess
R=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');O=Path(__file__).resolve().parent;T=O.parent;sha=lambda b:hashlib.sha256(b).hexdigest()
base='d4e721d6';head=subprocess.check_output(['git','rev-parse','4654002c'],cwd=R,text=True).strip();diff=subprocess.check_output(['git','diff','--unified=0',base,head],cwd=R);(O/'worker-diff.patch').write_bytes(diff)
assert subprocess.check_output(['git','diff','235d538b',head,'--','renderer','crates','web/renderer','web/dist/renderer','web/dist/pkg'],cwd=R)==b''
assert subprocess.check_output(['git','diff','b68dfb1a',head,'--','crates'],cwd=R)==b''
proofs={
 'dense':'Dense RAM v1 codec native/wasm full-byte192/928MiB, old-encoder sensitivity, clean standalone reproduction and actual current native cold13 Chromium paired checkpoint76b7…/full291175664B ELF reconstruction. Core code unchanged since b68; physical Wasm7d6 exact current.',
 'shader-copy-storage':'Padding5776d3b6, storage d5b60db6 and fresh copy235 custodyc5dcb27a retain original full jobs, hardware bytes/mips/alpha, ownership, malformed guards and meaningful sabotage. All current renderer source and shipping copies byte-unchanged since235; actual current cold13/native-apps consumes these exact served bodies with zero refusals.',
 'image':'Accepted B dependency d4e; source92 launcher088bdf1b, image18/software04 overlay7b343e19, earlier swap0b3a1aae and QML source-size provenance held. Actual cold13 native startup773/FIFOs before first chord, real swap/pageout/refault and original art/current sameimage snapshot prove new boundary; normal cfg/runtime/ELFs carried unchanged. Docker11 configuration gates and both authenticated preparation fullhashes carry; no software04 app-UI or full catalogue installation claim.',
 'application-harness':'Current native cold13 Chromium3328/fullELF/Mesa/SVG prefix073d4e5a plus independent pixelcritic actual13c46f8f7c, firstWriter644b4b39, preservedfailed d35fdae3 and helper-only guard0698935e/adoption671bodies, resumedWriter413d108b and current closed465record audit cover canonical/changed wrapper paths. Historical explicitly guarded continuation/diagnostic branches retain their prior scopes/negatives. Unobserved alternative/defensive paths are not claimed as native executed; see source115 coverage. Tooling only, never fake guest state or weaken runtime predicate.',
 'default':'Exact existing a7 build log0b2c7b42/default127/0report7d802986 + narrow task-labelled roadmap assertions held in seal f8893959. Its successful historical source identity is retained, not relabelled as new make invocation; shared67 served bodies byteequal current. Whole current app acceptance is expanded actual clean launch plus explicit missing-only harness adoption, not literal one-shot make.',
 'generated':'Canonical a7 build and actual current capturedserved/source endguard240unique/248roles prove exact deployable JS/Wasm7d6/buildidentity a7. Roadmap candidate entry remainsin-progress because warm releaseD uncompleted; metadata/generatedtaskhistory is declarative. Production publication is the explicitly separate gatedD boundary; no deployed-current-appimage claim.',
 'policy':'Task/queue/dependency/planning metadata only. C1 captures a genuine later color-scratch checkpoint limitation and remains pending; D publication depends on it. No C1/runtime/recovery/factory/deploy gate is fabricated.',
 'documentation':'Declarative source contract/recipe/provenance descriptions; inspected for accurate scope. Not runtime execution evidence.'}
files={};current=None
for line in diff.decode(errors='replace').splitlines():
 if line.startswith('diff --git '):
  current=line.split(' b/',1)[1];files[current]={'hunks':[]}
 elif line.startswith('@@ '):files[current]['hunks'].append(line)
assert len(files)==57
for path,row in files.items():
 if path.startswith('crates/') or path=='tools/verify/omarchy-snapshot-dense.mjs':group='dense'
 elif path.startswith('renderer/virgl-command/') and not path.endswith('.md'):group='shader-copy-storage'
 elif path.startswith('web/'):group='generated'
 elif path.startswith('tools/image/') and not path.endswith('.md'):group='image'
 elif path=='tools/verify-virgl-default-demo.mjs':group='default'
 elif path.startswith('tools/virgl-production/'):group='application-harness' if not any(x in path for x in ['omarchy-resource-copy','omarchy-shader-padding','omarchy-storage-leases']) else 'shader-copy-storage'
 elif path.startswith('tasks/'):group='policy'
 elif path.endswith('.md'):group='documentation'
 elif path=='Makefile':group='application-harness'
 else:raise AssertionError(path)
 blob=subprocess.check_output(['git','show',head+':'+path],cwd=R);row.update(group=group,classification='waived declarative metadata' if group in ['policy','documentation'] else 'held exact carried or current boundary; refusal/contingency qualification explicit',workerBytes=len(blob),workerSha256=sha(blob),evidence=proofs[group])
ledger={'status':'all57 changed worker paths and every textual hunk accounted for; production behavior has held runtime/component/current native evidence, declarative metadata waived with reason','baseline':subprocess.check_output(['git','rev-parse',base],cwd=R,text=True).strip(),'workerHead':head,'diffSha256':sha(diff),'files':files,'hunkCount':sum(len(x['hunks']) for x in files.values()),'groups':dict(collections.Counter(x['group'] for x in files.values())),'portability':'Actual original17f clean own-object-store/npm sparse checkout excluding only historical evidence; helper-only81fa adopted explicitly in the SAME still-live standalone clone with own gates and671 original-body equality. Current worker465 adds only tasklog/queue. No new semantic source changes require replay of carried native/wasm/physical gauntlets. Exact final relative claims/limitations retained.','unexecutedScope':'No blanket universal modal/legacy-continuation/future recovery/publication claim. Native first attempt observed overlap path and actual successful remaining criteria held. Defensive/error paths have pure guard adversarial/sabotage where material; other metadata/tooling contingency paths explicitly waived from accepted observed-flow claim, never asserted hit.'}
(O/'whole-c-hunk-coverage.json').write_text(json.dumps(ledger,indent=2)+'\n')
# Authenticate unchanged previously sealed bytes, not rerun their gates.
critical={'sparse-component01/sealed/scoped-review.tar.gz':'7a6354517521507134dc3869d55804ed2279290989de9ac1ab78eaeeb59d4170','storage-token-increment01/sealed/scoped-review.tar.gz':'d5b60db61b4ed1f75e6272f8995b327bcedbc016b0381c985eee28af2f7ce2d5'}
for path,expected in critical.items():assert sha((T/path).read_bytes())==expected,path
carried=[]
for file in sorted(T.glob('*/sealed/*.tar.gz')):
 if file.parent.parent==O:continue
 value=sha(file.read_bytes());receipt=file.parent/'authentication.json';expected=None
 if receipt.exists():
  d=json.loads(receipt.read_bytes());v=d.get('archive');expected=(v.get('sha256') if isinstance(v,dict) else d.get('sha256'))
 if expected:assert value==expected,file
 carried.append(dict(path=str(file.relative_to(R)),bytes=file.stat().st_size,sha256=value,existingReceiptDigestMatched=bool(expected),role='Carry only the original scoped verdict; archive may preserve a negative or partial result, never infer overall success from archive existence'))
peers=[]
for rel,expected in [('target/evidence/critic-omarchy-shader-padding01/sealed/scoped-review.tar.gz','5776d3b6a1f79d45b4e035ae06e2d9cf373391cdc23d4e64fc2715f9bb137fdf'),('target/evidence/critic-omarchy-native-copy01/custody.json','c5dcb27af0df6012365929d74457d1531cf32befa586269a019e0c4eb2be0861'),('target/evidence/critic-omarchy-native-note-controls01/new-helper97/actual13/verdict.md','c46f8f7c0f4f2a20d755137ef23fc33fd635d9a809f716633c5bbf10cad81a01')]:
 f=R/rel;assert sha(f.read_bytes())==expected;peers.append(dict(path=rel,bytes=f.stat().st_size,sha256=expected))
(O/'carried-proof-identities.json').write_text(json.dumps(dict(status='unchanged sealed scope identities authenticated; results carry with their scope/qualifications, not reexecuted',ownSeals=carried,peerSeals=peers),indent=2)+'\n');print(json.dumps({'workerHead':head,'changedPaths':len(files),'textHunks':ledger['hunkCount'],'groups':ledger['groups'],'carriedOwnSeals':len(carried),'peerIdentities':len(peers)},indent=2))
