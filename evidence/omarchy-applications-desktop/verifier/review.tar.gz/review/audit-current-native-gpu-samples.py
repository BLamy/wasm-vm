from pathlib import Path
import hashlib,json
R=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');O=Path(__file__).resolve().parent;P=R/'target/evidence/omarchy-applications-pristine01/cold13-final-components-closed-frozen01/payloads';a=json.loads((P/'control-applications-cold13-writer-open16.json').read_bytes());v=json.loads((P/'control-response-cold13-final-state18.json').read_bytes())['result'];s=json.loads((P/'control-shell-cold13-default-apps17.json').read_bytes());samples=[]
for f in sorted(P.glob('control-applications-cold13-writer-open16-*-gpu.json')):
 g=json.loads(f.read_bytes());samples.append((f.name,g))
samples.extend([('component publicDesktopFinal',a['publicDesktopFinal']['gpu']),('later snapshot18',v['gpu']),('defaultApps17 before',s['beforeGpu']),('defaultApps17 after',s['afterGpu'])]);out=[]
for name,g in samples:
 assert g['qualified'] and g['epoch']=='0000000000000002' and not any(g[k] for k in ['lost','poisoned','disposed']) and g['lastFailure'] is None and g['counters']['failed']==g['counters']['cancelled']==0
 assert g['guestCommands']['dropped']==0 and g['scanout']['failed']==0
 records=g['guestCommands']['records']
 for i,r in enumerate(records):assert r['sequence']==i and 0x1100<=r['response']<0x1200,(name,i,r)
 assert g['counters']['begun']-g['counters']['completed']==(1 if g['pending'] else 0)
 out.append(dict(name=name,epoch=g['epoch'],nativeCommands=len(records),nativeDropped=0,nativeRefusals=0,hostFailures=0,scanoutFailures=0,counters=g['counters'],pending=g['pending']))
(O/'current-native-gpu-samples-audit.json').write_text(json.dumps(dict(status='HELD all12 original actual component screenshot samples and4 actual final/menu samples have contiguous native success receipts and qualifiedsameepoch zerohost/native/scanoutfailure',samples=out),indent=2)+'\n');print(json.dumps({'samples':len(out),'actualLaterNativeCommands':out[-3]['nativeCommands'],'nativeRefusals':0,'hostFailures':0},indent=2))
