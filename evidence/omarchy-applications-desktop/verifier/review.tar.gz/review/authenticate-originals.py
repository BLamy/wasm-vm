from pathlib import Path
import hashlib,json,stat
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=Path(__file__).resolve().parent
BASE=ROOT/'target/evidence/omarchy-applications-pristine01/cold13-final-components-closed-frozen01';OLD=ROOT/'target/evidence/omarchy-applications-pristine01/resumed-writer16-resaved-prefix-frozen01'
c=json.loads((BASE/'custody.json').read_bytes());prior=json.loads((OLD/'custody.json').read_bytes());old={x['path']:x for x in prior['records']};seen=set();unchanged=[];changed=[];new=[]
for r in c['records']:
 name=Path(r['path']);assert not name.is_absolute() and '..' not in name.parts and r['path'] not in seen;seen.add(r['path']);p=BASE/name
 assert stat.S_ISREG(p.lstat().st_mode) and not p.is_symlink()
 for parent in p.parents:
  if parent==BASE:break
  assert not parent.is_symlink()
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b);n+=len(b)
 assert n==r['bytes'] and h.hexdigest()==r['sha256'],r['path']
 if r['path'] not in old:new.append(r)
 elif (r['bytes'],r['sha256'])==(old[r['path']]['bytes'],old[r['path']]['sha256']):unchanged.append(r)
 else:changed.append({'before':old[r['path']],'after':r})
assert len(seen)==465 and not (set(old)-seen)
a={'status':'all465 safe regular unique immutable payloads authenticated','records':c['records'],'previousCustodySha256':hashlib.sha256((OLD/'custody.json').read_bytes()).hexdigest(),'unchanged':unchanged,'changed':changed,'new':new}
(OUT/'custody-delta-authentication.json').write_text(json.dumps(a,indent=2)+'\n')
print(json.dumps({'payloads':len(seen),'unchanged':len(unchanged),'changed':[x['after']['path'] for x in changed],'new':[x['path'] for x in new]},indent=2))
