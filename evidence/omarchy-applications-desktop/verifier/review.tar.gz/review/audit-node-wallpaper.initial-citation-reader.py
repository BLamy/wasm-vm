from pathlib import Path
import hashlib,json,re,collections
from png_reader import png_rgba
R=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');O=Path(__file__).resolve().parent;B=R/'target/evidence/omarchy-applications-pristine01/cold13-final-components-closed-frozen01';P=B/'payloads';OLD=R/'target/evidence/omarchy-applications-pristine01/resumed-writer16-resaved-prefix-frozen01/payloads';sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(P/'control-applications-cold13-writer-open16.json').read_bytes();a=json.loads(raw);prior=json.loads((OLD/'control-applications-cold13-writer-open16.json').read_bytes());ph=a['phases'];assert a['status']=='passed' and len(ph)==177 and ph[:139]==prior['phases']
for k,v in prior.items():
 if k not in ['status','phases']:assert a[k]==v,k
assert a['nodeNpm']==ph[158]['result']=={'stdout':'riscv64\n12.2.0\n\n','exit':0};assert all(ph[i]['result']['exit']==1 for i in range(131,158));assert ph[128]['result']['exit']==0 and ph[128]['command']=='test ! -e /tmp/omarchyapps/node && test ! -e /tmp/omarchyapps/npm'
assert a['terminal']['pid']==16943 and ph[127]['result']['exit']==0 and json.loads(ph[127]['result']['stdout'])['pid']==16943 and ph[129]['text']=='node -p process.arch > /tmp/omarchyapps/node; npm --version > /tmp/omarchyapps/npm' and ph[130]['key']=='Enter'
n=a['nodeExecutable'];assert n['executable']=='/usr/bin/node' and n['executableSha256']=='939240cfbb7dc3742dbfb16f07b5142a2f0b3cae7c7fe2dd4f637f79d5eb3c12'
assert n['before']['exit']==n['after']['exit']==n['nativeHash']['exit']==0 and n['before']==n['after'];s=json.loads(n['before']['stdout']);assert s=={'dev':65024,'ino':3047,'size':57877136,'mode':493,'uid':0,'gid':0,'mtimeNs':'1792088927000000000','ctimeNs':'1792090966000000000'}
assert n['nativeHash']['stdout'].strip()==n['executableSha256']+'  /usr/bin/node';inv=json.loads((P/'input-runtime-elf.json').read_bytes());entry=[x for x in inv if x['path']=='usr/bin/node'];assert len(entry)==1 and entry[0]['machine']==243 and entry[0]['sha256']==n['executableSha256']
ledger=(P/'application-identity-commands.ndjson').read_bytes();oldledger=(OLD/'application-identity-commands.ndjson').read_bytes();assert ledger.startswith(oldledger);rows=[json.loads(x) for x in ledger.splitlines()];assert len(rows)==24 and rows[22]['command']=="sha256sum -- '/usr/bin/node'" and rows[22]['result']==n['nativeHash'];assert rows[21]['result']==n['before'] and rows[23]['result']==n['after']
assert a['afterGpu']==ph[159]['gpu'];assert ph[159]['label']=='node-npm' and a['afterGpu']['counters']['draws']>a['writerGpu']['counters']['draws'] and a['afterGpu']['counters']['completed']>a['writerGpu']['counters']['completed']
# Literal independent trusted event ledger; app-only ledger is flushed before stock input.
t=a['trusted'];assert len(t)==382 and all(x['trusted'] is True for x in t) and all(t[i]['time']<=t[i+1]['time'] for i in range(len(t)-1))
assert collections.Counter(x['type'] for x in t)=={'keydown':187,'keyup':187,'pointerdown':4,'pointerup':4}
# Original native assets/empty workspace, real nonquiet IPC then actual canvas pixel sample chain.
assert json.loads(ph[160]['result']['stdout'])['id']==1 and all(x['workspace']['id']!=5 for x in json.loads(ph[161]['result']['stdout'])) and ph[162]['key']=='Meta+5'
assert json.loads(ph[163]['result']['stdout'])['id']==5 and json.loads(ph[163]['result']['stdout'])['windows']==0
w=a['wallpaperTransitions'];assert w['assets']==json.loads(ph[164]['result']['stdout']);assets=w['assets'];assert assets[0]['path'].endswith('/backgrounds/0-winding-road.webp') and assets[0]['sha256']=='b149c3e1c8ce383812e7bc3170c2cf8b160ca583d72d59173cd42efdb79ced2b' and assets[1]['sha256']=='c9b96c106d2758113986a8ddb621f3867edf65e09a89dad51abb9fc5f3447146'
for i,asset in [(167,assets[1]),(171,assets[0])]:
 assert ph[i]['result']['exit']==0 and ph[i]['command']=="OMARCHY_PATH=/usr/share/omarchy XDG_RUNTIME_DIR=/run/user/1000 OMARCHY_SHELL_IPC_TIMEOUT=120s omarchy-shell background set '"+asset['path']+"'"
samples=w['samples'];assert len(samples)==141;assert [x['time'] for x in samples]==sorted(x['time'] for x in samples)
summary=[];lastgpu=a['afterGpu']
for label,field,index in [('original','before',166),('alternate','changed',170),('restored','restored',175)]:
 group=[x for x in samples if x['label']==label];assert len(group)=={'original':8,'alternate':35,'restored':98}[label]
 stored=(P/('control-applications-cold13-writer-open16-wallpaper-'+label+'.rgba')).read_bytes();width,height,pixels=png_rgba((P/('control-applications-cold13-writer-open16-wallpaper-'+label+'.png')).read_bytes());assert (width,height)==(1280,800) and len(stored)==3840
 # Recompute from independent actual captured PNG using the documented40x24 grid, avoiding bar/cursor.
 body=bytes(v for y in range(24) for x in range(40) for v in pixels[(int(800*(.15+.7*y/23))*1280+int(1280*(.1+.8*x/39)))*4:(int(800*(.15+.7*y/23))*1280+int(1280*(.1+.8*x/39)))*4+4])
 assert stored==body,(label,'actual PNG disagrees with retained sampled grid');digest=sha(stored);colors=len({stored[i:i+3] for i in range(0,len(stored),4)})
 assert colors>=16 and all(x['hash']==digest and x['colors']==colors for x in group[-8:]) and w['result'][field]['hash']==digest and ph[index]['gpu']==w['result'][field]['gpu']
 ticks=int(group[-1]['clock']['mtime'])-int(group[0]['clock']['mtime']);assert ticks>=20000000 and group[-1]['time']-group[0]['time']<300000
 for x in group:
  assert x['clock']['mode']=='paced-icount' and x['clock']['clockDiv']==64 and x['clock']['timebaseHz']==10000000
  d=x['presentation'];assert d['backend']==d['defaultBackend']=='canvas2d' and d['width']==1280 and d['height']==800 and d['errors']==[] and d['droppedFrames']==d['fallbacks']==d['contextLosses']==d['contextRestores']==0
 g=w['result'][field]['gpu'];assert g['qualified'] and g['epoch']=='0000000000000002' and g['counters']['failed']==0 and not any(g[k] for k in ['lost','disposed','poisoned']) and g['counters']['draws']>lastgpu['counters']['draws'] and g['counters']['completed']>lastgpu['counters']['completed'];lastgpu=g
 assert group[-1]['time']<=ph[index]['time'];summary.append(dict(label=label,samples=len(group),finalSha256=digest,colors=colors,stableTrailingSamples=8,observedGuestTicks=ticks,observedHostMs=group[-1]['time']-group[0]['time'],screenshotPhase=index,independentPngGridEqual=True,counters=g['counters']))
assert summary[0]['finalSha256']==summary[2]['finalSha256']!=summary[1]['finalSha256'] and ph[176]['key']=='Meta+1'
assert a['pageErrors']==[]
result=dict(status='HELD actual native Node/npm and canonical sampled-grid wallpaper/trusted ledger suffix',componentSha256=sha(raw),prior139PhasesUnchanged=True,nativeNode=dict(footPid=16943,outputPhase=158,output=a['nodeNpm'],fileIdentity=n,inventoryMachine=243,nativeHashCommandLine=23,limits='Actual native executable path is fully hashed before/after stable stat; ephemeral Node PID/process maps were not recorded. Actual trusted terminal command plus native riscv64/version output supplies execution, not a host Node process.'),nodeOutputDelayMs=ph[158]['time']-ph[130]['time'],nodePendingReads=27,wallpaper=summary,appTrusted=dict(events=382,types=dict(collections.Counter(x['type'] for x in t)),allTrusted=True),limits='Grid sample intermediate rows retain hash/colors/clock/presentation, not all intermediate3840-byte bodies. All3 retained raw grids independently equal original actual PNG sample coordinates; final8 consecutive hash records perstage retained. No all-frame-pixels/all-time claim; no untouched original failure promotion.')
(O/'node-wallpaper-audit.json').write_text(json.dumps(result,indent=2)+'\n')
starts=[i for i,l in enumerate(raw.decode().splitlines(),1) if re.match(r'^      "kind": ',l)];assert len(starts)==len(ph);points=[127,128,129,130,131,157,158,159,160,161,162,163,164,166,167,170,171,175,176];(O/'component-json-citations.json').write_text(json.dumps(dict(source=str((P/'control-applications-cold13-writer-open16.json').relative_to(R)),sha256=sha(raw),citations=[dict(phase=i,line=starts[i],kind=ph[i]['kind'],time=ph[i]['time']) for i in points]),indent=2)+'\n');print(json.dumps({'status':result['status'],'nodeDelayMs':result['nodeOutputDelayMs'],'wallpaper':[{k:v for k,v in x.items() if k!='counters'} for x in summary],'appTrusted':result['appTrusted']},indent=2))
