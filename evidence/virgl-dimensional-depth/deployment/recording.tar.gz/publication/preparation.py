from pathlib import Path,PurePosixPath
import hashlib,io,json,shutil,subprocess,tarfile
repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');head='ca9481ebe67cb0678939996d5f796552c6a1bf3b'
out=Path('/tmp/wasmvm-dimensional-depth-pages-ca9481eb');old=Path('/tmp/wasmvm-dimensional-view-pages-1c7f8c9b')
sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
assert subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines()==['tools/virgl-dimensional-depth/seal.py']
assert sha((old/'staging-index.json').read_bytes())=='37d8ea3dc255b5bad370e414d149722f5e3e020d44f1f16796ec867dc92f23ae'
previous=json.loads((old/'staging-index.json').read_bytes());assert previous['fileCount']==304
for row in previous['records']:
 body=(old/'web/dist'/row['path']).read_bytes();assert len(body)==row['bytes'] and sha(body)==row['sha256']
assert not out.exists();out.mkdir();shutil.copytree(old/'web/dist',out/'web/dist')
raw=subprocess.check_output(['git','archive',head,'web/dist'],cwd=repo);(out/'frozen-web-dist.tar').write_bytes(raw)
source={}
with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
 for entry in archive:
  path=PurePosixPath(entry.name);assert path.parts[0]=='web' and '..' not in path.parts
  if not entry.isfile():continue
  assert path.parts[:2]==('web','dist') and len(path.parts)>2
  name='/'.join(path.parts[2:]);body=archive.extractfile(entry).read();source[name]=body;file=out/'web/dist'/name;file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(body)
for row in previous['carriedBootManifests']:
 name=row['path'];assert sha(source[name])==row['sourceSha256'];shutil.copyfile(old/'web/dist'/name,out/'web/dist'/name)
records=[]
for p in sorted((out/'web/dist').rglob('*')):
 if p.is_file():
  body=p.read_bytes();assert len(body)<25*1024*1024;records.append(dict(path=p.relative_to(out/'web/dist').as_posix(),bytes=len(body),sha256=sha(body)))
prior={r['path']:r for r in previous['records']};assert len(records)==304 and set(prior)=={r['path'] for r in records}
changes=[r['path'] for r in records if r!=prior[r['path']]];assert set(changes)=={'roadmap.js','sw.js','pkg/wasm_vm_wasm_bg.wasm'},changes
index=dict(head=head,sourceArchiveSha256=sha(raw),heldDeployment=previous['head'],heldIndexSha256=sha((old/'staging-index.json').read_bytes()),carriedBootManifests=previous['carriedBootManifests'],records=records,fileCount=len(records),bytes=sum(r['bytes'] for r in records),codeChanges=changes)
(out/'staging-index.json').write_text(json.dumps(index,indent=2)+'\n');shutil.copyfile(__file__,out/'preparation.py');print(json.dumps(dict(head=head,files=len(records),changes=changes,bytes=index['bytes'],indexSha256=sha((out/'staging-index.json').read_bytes()))))
