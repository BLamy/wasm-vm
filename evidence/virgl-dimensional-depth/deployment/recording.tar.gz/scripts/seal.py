from pathlib import Path
import gzip,hashlib,io,json,tarfile

repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
stage=Path('/tmp/wasmvm-dimensional-depth-pages-ca9481eb')
live=Path('/tmp/wasmvm-dimensional-depth-live-ca9481eb')
head='ca9481ebe67cb0678939996d5f796552c6a1bf3b'
sha=lambda b:hashlib.sha256(b).hexdigest()
index=json.loads((stage/'staging-index.json').read_bytes())
report=json.loads((live/'report.json').read_bytes())
deployment=json.loads((stage/'cloudflare-success.json').read_bytes())['result']
assert report['gitHead']==index['head']==head and report['status']=='passed'
assert report['passed']==127 and report['failed']==0 and report['errors']==[]
assert deployment['deployment_trigger']['metadata']['commit_hash']==head and deployment['latest_stage']['status']=='success'
assert 'partial' in report['graphicsRoadmapPip'] and report['proofExportAbsent'] is True
for row in index['records']:
    body=(stage/'web/dist'/row['path']).read_bytes();assert sha(body)==row['sha256'] and len(body)==row['bytes']
for row in report['served']:
    body=(live/'bodies'/row['path'].lstrip('/')).read_bytes();assert sha(body)==row['sha256'] and len(body)==row['bytes']
files={'publication/'+p.relative_to(stage).as_posix():p for p in stage.rglob('*') if p.is_file()}
files.update({'live/'+p.relative_to(live).as_posix():p for p in live.rglob('*') if p.is_file()})
files.update({'scripts/publish.py':Path('/tmp/wasmvm-publish-dimensional-depth-pages.py'),'scripts/live.mjs':Path('/tmp/wasmvm-dimensional-depth-live.mjs'),'scripts/seal.py':Path(__file__)})
files.update({'packaging/worker-failure.json':Path('/tmp/wasmvm-d59-seal-failed-ca9481eb/failure.json'),'packaging/early-deployment-seal.stderr':Path('/tmp/wasmvm-d59-deployment-seal-early-failed.log')})
rows=[dict(path=n,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for n,p in sorted(files.items())]
out=repo/'evidence/virgl-dimensional-depth/deployment';assert not out.exists();out.mkdir(parents=True)
raw=(json.dumps(dict(schema='dimensional-depth-deployment-index-v1',head=head,records=rows),indent=2)+'\n').encode();(out/'records.json').write_bytes(raw)
archive=out/'recording.tar.gz'
with archive.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
    for row in rows:
        body=files[row['path']].read_bytes();info=tarfile.TarInfo(row['path']);info.size,info.mode,info.mtime=len(body),0o644,0;tar.addfile(info,io.BytesIO(body))
with tarfile.open(archive,'r:gz') as tar:
    assert tar.getnames()==[r['path'] for r in rows]
    for row in rows:
        body=tar.extractfile(row['path']).read();assert len(body)==row['bytes'] and sha(body)==row['sha256']
manifest=dict(schema='dimensional-depth-deployment-seal-v1',task='E6-T11d59',head=head,records=len(rows),reopenedMembers=len(rows),recordIndexSha256=sha(raw),archiveSha256=sha(archive.read_bytes()),archiveBytes=archive.stat().st_size,deploymentId=deployment['id'],url=deployment['url'],canonical='https://wasm-vm.pages.dev',passed=127,failed=0,productionGraphicsAuthority=False)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest));print('manifestSha256',sha((out/'manifest.json').read_bytes()))
