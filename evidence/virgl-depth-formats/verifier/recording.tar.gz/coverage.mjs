import fs from 'node:fs/promises';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const out=path.resolve('target/evidence/virgl-depth-formats-verifier'),head='61db520384877672b63a23cd0539946c55297431',base='9d93635d7aee08adb3cb1b17516cb4e5da87c9b0',hash=b=>createHash('sha256').update(b).digest('hex');
const runtime=['renderer/virgl-command/resources.mjs','renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs'];
const roots=['hot/hardware','hot/supplement','hot/regression/resources','hot/regression/state','hot/regression/draw','hot/regression/async','hot/regression/colors'];
const measurements=[];
for(const name of roots){const file=path.join(out,'authenticated',name,'browser-coverage.json'),raw=await fs.readFile(file),doc=JSON.parse(raw);for(const s of doc.scripts??[doc])measurements.push({record:name+'/browser-coverage.json',recordSha256:hash(raw),...s});}
const audit=[];
for(const file of runtime){
 const bytes=execFileSync('git',['show',head+':'+file]),src=bytes.toString(),lines=src.split('\n'),offsets=[];let offset=0;for(const l of lines){offsets.push(offset);offset+=l.length+1;}
 const diff=execFileSync('git',['diff','--unified=0',base,head,'--',file],{encoding:'utf8'}),added=[];let n=0;
 for(const l of diff.split('\n')){const h=l.match(/^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@/);if(h){n=+h[1];continue;}if(l.startsWith('+++')||l.startsWith('---')||l.startsWith('diff ')||l.startsWith('index '))continue;if(l.startsWith('+')){added.push(n++);}else if(l.startsWith(' '))n++;}
 const runs=measurements.filter(s=>s.source===file&&s.sha256===hash(bytes));
 for(const line of added){
   const text=lines[line-1],start=offsets[line-1],end=start+text.length,trim=text.trim(),points=[],tokenHits=new Set();
   const waived=!trim||/^(?:\/\/|\/\*|\*|[{}();,]+$)/.test(trim);
   if(!waived){for(const run of runs){
     const ranges=run.coverage.functions.flatMap((f,fi)=>f.ranges.map((r,ri)=>({...r,fi,ri,name:f.functionName})));
     const tokens=[];for(let p=start;p<end;p++)if(!/\s/.test(src[p]))tokens.push(p);
     const counts=tokens.map(p=>{const candidates=ranges.filter(r=>r.startOffset<=p&&p<r.endOffset).sort((a,b)=>(a.endOffset-a.startOffset)-(b.endOffset-b.startOffset));return candidates[0]??null;});
     const covered=counts.filter(r=>r?.count>0),zero=counts.filter(r=>r?.count===0); counts.forEach((r,i)=>{if(r?.count>0)tokenHits.add(tokens[i]);});
     if(covered.length){const witness=covered.reduce((a,b)=>b.endOffset-b.startOffset<a.endOffset-a.startOffset?b:a);points.push({record:run.record,recordSha256:run.recordSha256,range:witness,positiveTokens:covered.length,zeroTokens:zero.length,totalTokens:tokens.length});}
   }}
   const classification=waived?'waived':points.length?'executed':'needs-evidence';
   const unhit=[];if(!waived)for(let p=start;p<end;p++)if(!/\s/.test(src[p])&&!tokenHits.has(p))unhit.push(p-start);
   audit.push({source:file,sourceSha256:hash(bytes),line,text,unhitColumns:unhit,classification,reason:waived?'Comment, delimiter or blank line; no executable behavior.':points.length?'Smallest enclosing V8 range has positive counter at changed tokens.':'No non-mutant sealed recording hit changed executable tokens.',points});
 }
}
const result={head,base,method:'UTF16 source offsets; for each changed non-whitespace token choose the smallest enclosing function/block V8 interval, restricted to matching sealed source digest. Counter points listed; comments/delimiters waived.',summary:{lines:audit.length,executed:audit.filter(x=>x.classification==='executed').length,waived:audit.filter(x=>x.classification==='waived').length,needsEvidence:audit.filter(x=>x.classification==='needs-evidence').length},lines:audit};
await fs.writeFile(path.join(out,'coverage.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result.summary));
for(const x of audit)if(x.classification==='needs-evidence')console.log(x.source+':'+x.line+' '+x.text);
for(const x of audit)if(x.points.length&&x.points.every(p=>p.zeroTokens>0))console.log('Mixed deepest counts '+x.source+':'+x.line+' '+x.text);
for(const x of audit)if(x.unhitColumns.length)console.log('Unhit columns '+x.source+':'+x.line+' '+x.unhitColumns.join(',')+' chars='+x.unhitColumns.map(i=>x.text[i]).join(''));
