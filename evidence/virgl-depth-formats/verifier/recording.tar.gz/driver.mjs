import fs from 'node:fs/promises';
import {createServer} from 'node:http';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const root=process.cwd(),out=path.resolve('target/evidence/virgl-depth-formats-verifier'),head='61db520384877672b63a23cd0539946c55297431',hash=b=>createHash('sha256').update(b).digest('hex');
const files=['renderer/virgl-command/resources.mjs','renderer/virgl-command/state.mjs','renderer/virgl-command/decoder.mjs','renderer/virgl-command/constant-domain.mjs','renderer/virgl-shader/index.mjs'];
const sources=new Map();for(const file of files){const bytes=execFileSync('git',['show',head+':'+file]);assert.deepEqual(await fs.readFile(file),bytes);sources.set('/'+file,bytes);}
const attack=await fs.readFile(path.join(out,'attack.mjs')),driver=await fs.readFile(path.join(out,'driver.mjs'));let current,browser,server;const results=[];
try{
 server=createServer((q,r)=>{const file=new URL(q.url,'http://localhost').pathname;const bytes=file==='/attack.mjs'?attack:file==='/renderer/virgl-command/resources.mjs'?current.bytes:sources.get(file);
  if(file==='/favicon.ico'){r.writeHead(204).end();return;}if(file==='/'){r.writeHead(200,{'Content-Type':'text/html','Cache-Control':'no-store'}).end('<!doctype html><title>Independent Z16 critic</title><h1>Independent Z16 storage attacks</h1><canvas id="gpu" width="96" height="96"></canvas><pre id="result"></pre>');return;}
  if(!bytes){r.writeHead(404).end();return;}current.served.set(file,{path:file,bytes:bytes.length,sha256:hash(bytes)});r.writeHead(200,{'Content-Type':'text/javascript','Cache-Control':'no-store'}).end(bytes);
 });await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const {chromium}=await import(pathToFileURL(path.join(root,'web/node_modules/playwright/index.mjs'))),chrome='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';browser=await chromium.launch({executablePath:chrome,headless:false,args:['--enable-gpu']});
 const bs=await browser.newBrowserCDPSession(),system=await bs.send('SystemInfo.getInfo'),command=await bs.send('Browser.getBrowserCommandLine');assert.equal(system.gpu.featureStatus.webgl2??system.gpu.featureStatus.webgl,'enabled');assert.ok(!command.arguments.some(s=>/swiftshader|llvmpipe|softpipe|lavapipe|--disable-gpu(?:$|=)/i.test(s)));
 for(const mode of ['clean','byte-order','packing']){
  const folder=path.join(out,'independent-'+mode);await fs.mkdir(folder,{recursive:true});const original=sources.get('/renderer/virgl-command/resources.mjs');let text=original.toString(),mutation=null;
  if(mode!=='clean'){
   const [needle,replacement]=mode==='byte-order'?['guest.getUint16(i * 2, true)','guest.getUint16(i * 2, false)']:['float(d>>8)','float(d>>7)'];assert.equal(text.split(needle).length,2);text=text.replace(needle,replacement);mutation={path:'renderer/virgl-command/resources.mjs',needle,replacement,originalSha256:hash(original),mutantSha256:hash(Buffer.from(text))};await fs.writeFile(path.join(folder,'mutant-resources.mjs'),text);
  }
  current={bytes:Buffer.from(text),served:new Map()};const report={schema:1,task:'E6-T12g3',sourceHead:head,mode,status:'running',driverSha256:hash(driver),attackSha256:hash(attack),sources:[...sources].map(([path,bytes])=>({path:path.slice(1),bytes:bytes.length,sha256:hash(bytes)})),mutation,browser:{executable:chrome,executableSha256:hash(await fs.readFile(chrome)),version:browser.version(),headless:false,gpu:system.gpu,commandLine:command.arguments},browserErrors:{console:[],page:[],requests:[]}};
  const context=await browser.newContext({viewport:{width:1100,height:900}}),page=await context.newPage();page.on('console',m=>{if(m.type()==='error')report.browserErrors.console.push(m.text());});page.on('pageerror',e=>report.browserErrors.page.push(e.message));page.on('requestfailed',r=>report.browserErrors.requests.push(r.url()));
  try{
   await page.goto(`http://127.0.0.1:${server.address().port}/`,{waitUntil:'load'});const cdp=await context.newCDPSession(page);await cdp.send('Profiler.enable');await cdp.send('Profiler.startPreciseCoverage',{callCount:true,detailed:true});
   report.result=await page.evaluate(async mode=>{const result=await(await import('/attack.mjs')).runAttack(mode);document.querySelector('#result').textContent=JSON.stringify({mode,status:result.status,renderer:result.renderer,assertions:result.assertions.length,error:result.error,seeds:result.details.filter(d=>d.seed).map(d=>({seed:d.seed,delays:d.delays,completionOrder:d.completionOrder}))},null,2);return result;},mode);
   const coverage=await cdp.send('Profiler.takePreciseCoverage');const scripts=coverage.result.filter(s=>files.some(f=>s.url.endsWith('/'+f))).map(s=>({source:files.find(f=>s.url.endsWith('/'+f)),sha256:hash(s.url.endsWith('/renderer/virgl-command/resources.mjs')?current.bytes:sources.get('/'+files.find(f=>s.url.endsWith('/'+f)))),coverage:s}));
   await fs.writeFile(path.join(folder,'browser-coverage.json'),JSON.stringify({scripts},null,2)+'\n');report.coverageSha256=hash(await fs.readFile(path.join(folder,'browser-coverage.json')));await page.screenshot({path:path.join(folder,'browser.png'),fullPage:true});report.screenshotSha256=hash(await fs.readFile(path.join(folder,'browser.png')));report.servedFiles=[...current.served.values()];assert.deepEqual(report.browserErrors,{console:[],page:[],requests:[]});
   if(mode==='clean')assert.equal(report.result.status,'passed',JSON.stringify(report.result.error));else{assert.equal(report.result.status,'failed');assert.equal(report.result.error.observation.kind,mode==='byte-order'?'normalized-GPU':'packing-GPU');assert.equal(report.result.error.observation.held,false);assert.notEqual(mutation.originalSha256,mutation.mutantSha256);}
   report.status='passed';
  }catch(error){report.status='failed';report.failure={message:error.message,stack:error.stack};process.exitCode=1;}
  finally{await fs.writeFile(path.join(folder,'report.json'),JSON.stringify(report,null,2)+'\n');await context.close();}
  results.push({mode,status:report.status,assertions:report.result?.assertions.length,error:report.result?.error?.observation,reportSha256:hash(await fs.readFile(path.join(folder,'report.json')))});console.log(JSON.stringify(results.at(-1)));
 }
}finally{await browser?.close();if(server)await new Promise(resolve=>server.close(resolve));await fs.writeFile(path.join(out,'independent-summary.json'),JSON.stringify({sourceHead:head,results},null,2)+'\n');}
