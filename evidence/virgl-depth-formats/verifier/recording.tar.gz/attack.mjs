import {createResourceStore,createWebGL2TransferBackend} from '/renderer/virgl-command/resources.mjs';
import {createVirglStateRenderer} from '/renderer/virgl-command/state.mjs';

export async function runAttack(mode){
 const rows=[],details=[],cleanup=[];
 function equal(observed,expected,prediction,kind='assertion'){
  const held=JSON.stringify(observed)===JSON.stringify(expected),row={prediction,expected,observed,held,kind};rows.push(row);
  if(!held){const e=new Error(prediction);e.observation={index:rows.length-1,...row};throw e;}
 }
 function ok(r,label){equal(r?.ok,true,label+' '+(r?.error?.code??''));return r;}
 function bad(r,label,code){equal(r.ok,false,label);if(code)equal(r.error.code,code,label+' code');return r;}
 const gl=document.querySelector('#gpu').getContext('webgl2',{antialias:false,preserveDrawingBuffer:true});equal(Boolean(gl),true,'real WebGL2');
 const ext=gl.getExtension('WEBGL_debug_renderer_info'),renderer=gl.getParameter(ext.UNMASKED_RENDERER_WEBGL);equal(/swiftshader|llvmpipe|softpipe|lavapipe/i.test(renderer),false,'hardware renderer');
 const box=(w,h,x=0,y=0)=>({x,y,z:0,width:w,height:h,depth:1});
 const meta=(id,w,h,format=16)=>({id,target:2,format,bind:format===16?1:10,width:w,height:h,depth:1,arraySize:1,lastLevel:0,nrSamples:0,flags:0});
 const wordsToBytes=values=>Uint8Array.from(values.flatMap(n=>[n%256,Math.floor(n/256)]));
 const command=(id,b,stride=0,dataOffset=0,direction=1)=>({opcode:43,fields:{resourceHandle:id,level:0,usage:0,stride,layerStride:0,box:b,dataOffset,direction}});
 function upload(r,cmd){ok(r.store.executeTransfer(ok(r.store.prepareTransfer(1,cmd),'upload prepare').ticket),'real GPU upload');}
 function packet(op,type,values){const a=new Uint8Array(4+values.length*4),v=new DataView(a.buffer);v.setUint32(0,op|type<<8|values.length<<16,true);values.forEach((n,i)=>v.setUint32((i+1)*4,n,true));return a;}
 function rig(limits){
  const allocations=new Map(),names=new Map(),calls=[],packed=[],delays=new Map();let store,nextDelay=0;
  const kinds=['Texture','Buffer','Program','Shader','VertexArray','Framebuffer','Sync'];for(const k of kinds)names.set(k,new Set());
  const traced=new Proxy(gl,{get(t,k){const v=Reflect.get(t,k,t);if(typeof v!=='function')return v;return(...a)=>{
    const budgets=store?.inspect().budgets;
    if(['createTexture','createBuffer','texStorage2D','texSubImage2D','bufferData','readPixels'].includes(k))calls.push({op:k,budgets,args:a.map(x=>typeof x==='number'?x:typeof x)});
    if(k==='clientWaitSync'&&(delays.get(a[0])??0)>0){delays.set(a[0],delays.get(a[0])-1);return t.TIMEOUT_EXPIRED;}
    const answer=v.apply(t,a);
    if(k==='readPixels'&&a[4]===t.RGBA&&a[5]===t.UNSIGNED_BYTE&&ArrayBuffer.isView(a[6]))packed.push([...a[6]]);
    for(const kind of kinds){if(k==='create'+kind&&answer)names.get(kind).add(answer);if(k==='delete'+kind)names.get(kind).delete(a[0]);}
    if(k==='fenceSync'&&answer){names.get('Sync').add(answer);delays.set(answer,nextDelay);nextDelay=0;}
    return answer;
  };}});
  const native=ok(createWebGL2TransferBackend(traced),'native backend').backend;
  const backend={...native,allocate(m){const s=native.allocate(m);allocations.set(m.id,s);return s;}};
  const r=ok(createResourceStore({backend,...(limits?{limits}:{})}),'store');store=r.store;
  const result={...r,allocations,names,calls,packed,delay(n){nextDelay=n;},close(){ok(store.dispose(),'store disposed');for(const[k,v]of Object.entries(store.inspect().budgets))equal(v,0,'released '+k);for(const[k,n]of names)equal(n.size,0,'no native '+k+' leak');equal(gl.getError(),gl.NO_ERROR,'zero GL errors');}};
  cleanup.push(result);ok(store.createContext(1),'resource context');return result;
 }
 function reset(){
  for(const c of [gl.BLEND,gl.DEPTH_TEST,gl.STENCIL_TEST,gl.SCISSOR_TEST,gl.CULL_FACE,gl.DITHER,gl.RASTERIZER_DISCARD,gl.SAMPLE_ALPHA_TO_COVERAGE,gl.SAMPLE_COVERAGE])gl.disable(c);
  gl.colorMask(true,true,true,true);gl.depthMask(true);gl.depthRange(0,1);gl.activeTexture(gl.TEXTURE0);gl.bindSampler(0,null);gl.bindBuffer(gl.PIXEL_PACK_BUFFER,null);gl.bindBuffer(gl.PIXEL_UNPACK_BUFFER,null);
  for(const p of [gl.PACK_ROW_LENGTH,gl.PACK_SKIP_PIXELS,gl.PACK_SKIP_ROWS])gl.pixelStorei(p,0);gl.pixelStorei(gl.PACK_ALIGNMENT,1);
 }
 function sample(texture,w,h,values,label){
  equal(Boolean(gl.getExtension('EXT_color_buffer_float')),true,'separate float oracle');
  const output=gl.createTexture(),fbo=gl.createFramebuffer(),vao=gl.createVertexArray(),program=gl.createProgram(),shaders=[];
  try{
   for(const[type,text]of [[gl.VERTEX_SHADER,'#version 300 es\nvoid main(){vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2));gl_Position=vec4(p*2.0-1.0,0,1);}'],[gl.FRAGMENT_SHADER,'#version 300 es\nprecision highp float;uniform highp sampler2D src;out vec4 color;void main(){color=vec4(texelFetch(src,ivec2(gl_FragCoord.xy),0).r,0,0,1);}']]){
    const s=gl.createShader(type);shaders.push(s);gl.shaderSource(s,text);gl.compileShader(s);equal(gl.getShaderParameter(s,gl.COMPILE_STATUS),true,'oracle shader compile');gl.attachShader(program,s);
   }
   gl.linkProgram(program);equal(gl.getProgramParameter(program,gl.LINK_STATUS),true,'oracle program link');reset();gl.bindTexture(gl.TEXTURE_2D,output);gl.texStorage2D(gl.TEXTURE_2D,1,gl.RGBA32F,w,h);gl.bindFramebuffer(gl.FRAMEBUFFER,fbo);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,output,0);gl.drawBuffers([gl.COLOR_ATTACHMENT0]);gl.readBuffer(gl.COLOR_ATTACHMENT0);equal(gl.checkFramebufferStatus(gl.FRAMEBUFFER),gl.FRAMEBUFFER_COMPLETE,'independent float FBO');
   gl.bindVertexArray(vao);gl.useProgram(program);gl.bindTexture(gl.TEXTURE_2D,texture);gl.uniform1i(gl.getUniformLocation(program,'src'),0);gl.viewport(0,0,w,h);gl.drawArrays(gl.TRIANGLES,0,3);
   const data=new Float32Array(w*h*4);gl.readPixels(0,0,w,h,gl.RGBA,gl.FLOAT,data);
   let mismatch=null,maxError=0;for(let i=0;i<values.length;i++){const observed=data[4*i],expected=values[i]/65535,error=Math.abs(observed-expected);maxError=Math.max(maxError,error);if(mismatch===null&&(!Number.isFinite(observed)||error>1/(65535*128)||data[4*i+3]!==1))mismatch={pixel:i,word:values[i],expected,observed};}
   details.push({label,values,observed:Array.from(data),maxError});equal(mismatch,null,label+' independently normalized GPU sample','normalized-GPU');equal(gl.getError(),gl.NO_ERROR,'float sample GL errors');
  }finally{gl.useProgram(null);for(const s of shaders)gl.deleteShader(s);gl.deleteProgram(program);gl.deleteVertexArray(vao);gl.deleteFramebuffer(fbo);gl.deleteTexture(output);}
 }
 function add(r,m,data){const created=ok(r.store.createResource(m),'metadata create').resource;ok(r.store.attachContext(1,m.id),'resource membership');if(data)ok(r.store.attachBacking(m.id,[data.subarray(0,9),data.subarray(9,13),data.subarray(13)]),'owned unaligned split backing');return created;}
 async function awaitRead(r,ticket,label){for(let i=0;i<300;i++){const p=ok(r.asyncAccess.poll(ticket),'scheduled actual fence');if(p.status==='ready')return p.bytes;await new Promise(resolve=>setTimeout(resolve,1));}throw new Error('fence timeout '+label);}
 const unpack=(bytes)=>Array.from({length:bytes.length/2},(_,i)=>bytes[2*i]+256*bytes[2*i+1]);
 try{
  // Independent GPU samples are checked before literal physical packing pixels.
  {
   const values=[0,1,255,256,32768,65535,4660,43981],r=rig(),input=wordsToBytes(values);add(r,meta(1,4,2),input);upload(r,command(1,box(4,2)));sample(r.allocations.get(1).texture,4,2,values,'literal source');
   const lease=ok(r.store.retainStorage(1,1,'depth-surface'),'literal depth lease').lease,read=ok(r.store.readStorage(lease),'literal native pack read').bytes;
   const gpuPacked=r.packed.at(-1),expected=values.flatMap(n=>[n%256,Math.floor(n/256),0,255]);details.push({label:'literal pack GPU readPixels before CPU compaction',gpuPacked,expected});equal(gpuPacked,expected,'independent literal GPU RGBA packing before CPU conversion','packing-GPU');equal(unpack(read),values,'literal guest inverse');ok(r.store.releaseStorage(lease),'literal lease release');r.close();cleanup.splice(cleanup.indexOf(r),1);
  }
  if(mode!=='clean')throw new Error('source fault escaped independent GPU oracles');
  const seeds=[0x1a2b3c4d,0x50e1d2c3,0x76f02468];
  for(const seed of seeds){
   let s=seed>>>0;const rand=()=>{s^=s<<13;s^=s>>>17;s^=s<<5;return s>>>0;};
   const shapes=[{id:1,w:7,h:5},{id:2,w:9,h:3}];for(const shape of shapes){shape.values=Array.from({length:shape.w*shape.h},()=>rand()&65535);shape.values[0]=0;shape.values[1]=65535;shape.values[2]=256;shape.stride=shape.w*2+3;shape.source=new Uint8Array(7+(shape.h-1)*shape.stride+shape.w*2+9).fill(0x91);for(let y=0;y<shape.h;y++)shape.source.set(wordsToBytes(shape.values.slice(y*shape.w,(y+1)*shape.w)),7+y*shape.stride);}
   const backingBytes=shapes.reduce((n,x)=>n+x.source.length,0),sourceGpu=shapes.reduce((n,x)=>n+2*x.w*x.h,0),pixels=35+27+9,limits={gpuBytes:sourceGpu+8*pixels,cpuBytes:backingBytes+4*pixels,scratchBytes:4*pixels};
   const r=rig(limits),leases=[],state=ok(createVirglStateRenderer({gl,resources:r.store,bindings:r.bindings,shaderBridge:{translate(){throw new Error('no guest shaders in storage verifier');}}}),'alias state renderer').renderer;
   try{
    ok(state.createContext(1),'alias renderer context');
    for(const sh of shapes){sh.created=add(r,meta(sh.id,sh.w,sh.h),sh.source);sh.source.fill(99);upload(r,command(sh.id,box(sh.w,sh.h),sh.stride,7));sample(r.allocations.get(sh.id).texture,sh.w,sh.h,sh.values,'seed '+seed+' source '+sh.id);leases.push(ok(r.store.retainStorage(1,sh.id,'depth-surface'),'seed depth lease').lease);}
    for(const format of [17,18,19,20,21,22,23,24,25,26,27,28,29,30]){const before=r.store.inspect().budgets,n=r.calls.length;bad(r.store.createResource(meta(3,1,1,format)),'forbidden packed/float/stencil depth '+format,'unsupported-resource');equal(r.store.inspect().budgets,before,'forbidden metadata state unchanged');equal(r.calls.length,n,'forbidden metadata allocates no native name');}
    for(const[format,resourceId]of [[67,1],[233,2]]){const before=state.inspect(),budget=r.store.inspect().budgets;bad(state.executeSubmission(1,packet(1,8,[20+resourceId,resourceId,format,0,0])),'color surface alias over depth','unsupported-resource');equal(state.inspect(),before,'alias state not published');equal(r.store.inspect().budgets,budget,'alias lease rollback');}
    ok(state.executeSubmission(1,packet(1,8,[11,1,16,0,0])),'real depth surface object');const before=state.inspect();bad(state.executeSubmission(1,packet(5,0,[1,0,11])),'depth object in color attachment','incompatible-resource');equal(state.inspect(),before,'framebuffer alias state rollback');
    const requests=[{id:1,lease:leases[0],b:box(7,5),values:[...shapes[0].values]},{id:2,lease:leases[1],b:box(9,3),values:[...shapes[1].values]},{id:1,lease:leases[0],b:box(3,3,1,1),values:Array.from({length:3},(_,y)=>shapes[0].values.slice((y+1)*7+1,(y+1)*7+4)).flat()}];
    const delays=[];for(const q of requests){const delay=2+rand()%5;r.delay(delay);q.ticket=ok(r.asyncAccess.beginStorageRead(q.lease,q.b),'concurrent region PBO').ticket;delays.push(delay);}
    equal([r.store.inspect().budgets.gpuBytes,r.store.inspect().budgets.cpuBytes,r.store.inspect().budgets.scratchBytes],[limits.gpuBytes,limits.cpuBytes,limits.scratchBytes],'aggregate pending quota exact');
    const beforeQuota=r.store.inspect().budgets,beforeCalls=r.calls.length;bad(r.asyncAccess.beginStorageRead(leases[1],box(1,1,8,2)),'fourth read over aggregate bound','limit-exceeded');equal(r.store.inspect().budgets,beforeQuota,'aggregate quota rollback');equal(r.calls.length,beforeCalls,'aggregate failure precedes native allocation');
    const firstOrder=requests.map((_,i)=>i).sort(()=>rand()%3-1);for(const index of firstOrder)equal(ok(r.asyncAccess.poll(requests[index].ticket),'first withheld poll').status,'pending','seed scheduling withholds real fence bytes');
    const order=[...requests.keys()].sort(()=>rand()%3-1);for(const i of order){const q=requests[i],read=await awaitRead(r,q.ticket,'seeded region');equal(unpack(read),q.values,'interleaved source/region isolation '+seed+'/'+i);equal(read.buffer.byteLength,q.values.length*4,'owned compact scratch for concurrent region');ok(r.asyncAccess.release(q.ticket),'concurrent PBO release');}
    equal([r.store.inspect().budgets.gpuBytes,r.store.inspect().budgets.scratchBytes],[sourceGpu,0],'all concurrent charges released');
    const a=shapes[0],patch=Array.from({length:6},()=>rand()&65535),patchBytes=new Uint8Array(23).fill(0x4e);patchBytes.set(wordsToBytes(patch.slice(0,3)),0);patchBytes.set(wordsToBytes(patch.slice(3)),17);ok(r.store.writeBacking(1,7,patchBytes),'write only guest input patch');upload(r,command(1,box(3,2,2,1),17,7));for(let y=0;y<2;y++)for(let x=0;x<3;x++)a.values[(y+1)*7+x+2]=patch[y*3+x];sample(r.allocations.get(1).texture,a.w,a.h,a.values,'seeded partial write neighbors');
    const cleared=new Uint8Array(a.source.length).fill(0xda);ok(r.store.writeBacking(1,0,cleared),'scatter guards initialize');const region=box(3,2,2,1),wanted=a.values.slice(9,12).concat(a.values.slice(16,19));ok(r.store.executeTransfer(ok(r.store.prepareTransfer(1,command(1,region,9,5,2)),'independent odd read scatter').ticket),'scatter from GPU');for(let y=0;y<2;y++)cleared.set(wordsToBytes(wanted.slice(y*3,y*3+3)),5+y*9);equal([...ok(r.store.readBacking(1,0,cleared.length),'scatter guard inspection').bytes],[...cleared],'random partial read leaves every guard byte');
    const oldTexture=r.allocations.get(2).texture,oldGen=shapes[1].created.generation;r.delay(4+rand()%5);const oldRead=ok(r.asyncAccess.beginStorageRead(leases[1],box(9,3)),'old depth pending PBO').ticket;ok(r.store.unref(2),'drop old public depth ID');const fresh=ok(r.store.createResource(meta(2,9,3,67)),'reuse ID as native RGBA').resource;ok(r.store.attachContext(1,2),'new RGBA membership');equal(fresh.generation>oldGen,true,'generation cannot alias pending depth');
    equal(unpack(await awaitRead(r,oldRead,'old-format delayed PBO')),shapes[1].values,'old depth PBO retains old native type after RGBA reuse');ok(r.asyncAccess.release(oldRead),'old depth PBO release');ok(r.store.releaseStorage(leases[1]),'old exact lease release');equal(gl.isTexture(oldTexture),false,'old native texture deleted once');leases[1]=null;
    const budget=r.store.inspect().budgets;bad(state.executeSubmission(1,packet(1,8,[22,2,16,0,0])),'depth surface alias over new color','unsupported-resource');equal(r.store.inspect().budgets,budget,'new incompatible alias does not retain');
    r.delay(5+rand()%5);const cancel=ok(r.asyncAccess.beginStorageRead(leases[0],box(7,5)),'cancel after independent schedule').ticket;ok(r.asyncAccess.release(cancel),'cancel pending actual PBO');equal(r.store.inspect().budgets.scratchBytes,0,'cancelled scratch released');
    details.push({seed,delays,firstOrder,completionOrder:order,limits,calls:r.calls});
   }finally{ok(state.dispose(),'alias renderer dispose');for(const lease of leases)if(lease)ok(r.store.releaseStorage(lease),'remaining seed lease release');r.close();cleanup.splice(cleanup.indexOf(r),1);}
  }
  // GPU writes the source without any CPU depth upload; pack/read must observe it.
  {
   const r=rig(),values=[11326,11326,11326,11326,11326,11326],m=meta(3,3,2);add(r,m,null);const texture=r.allocations.get(3).texture,fbo=gl.createFramebuffer();
   try{reset();gl.bindFramebuffer(gl.FRAMEBUFFER,fbo);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,texture,0);gl.drawBuffers([gl.NONE]);gl.readBuffer(gl.NONE);equal(gl.checkFramebufferStatus(gl.FRAMEBUFFER),gl.FRAMEBUFFER_COMPLETE,'GPU-only native depth FBO');equal(gl.getFramebufferAttachmentParameter(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE),16,'GPU-only source precision');gl.clearBufferfv(gl.DEPTH,0,new Float32Array([11326/65535]));equal(gl.getError(),gl.NO_ERROR,'GPU-only depth write errors');}finally{gl.deleteFramebuffer(fbo);}
   sample(texture,3,2,values,'GPU-only written depth');const lease=ok(r.store.retainStorage(1,3,'depth-surface'),'GPU-write lease').lease;equal(unpack(ok(r.store.readStorage(lease),'GPU-only sync pack').bytes),values,'GPU-only depth inverse has no upload mirror');const t=ok(r.asyncAccess.beginStorageRead(lease,box(3,2)),'GPU-only actual PBO').ticket;equal(unpack(await awaitRead(r,t,'GPU-only')),values,'GPU-only async read');ok(r.asyncAccess.release(t),'GPU-only release');equal(r.calls.some(c=>c.op==='texSubImage2D'),false,'no CPU depth upload in GPU-only oracle');ok(r.store.releaseStorage(lease),'GPU-only lease release');r.close();cleanup.splice(cleanup.indexOf(r),1);
  }
  return{status:'passed',mode,renderer,assertions:rows,details};
 }catch(error){return{status:'failed',mode,renderer,error:{message:error.message,stack:error.stack,observation:error.observation},assertions:rows,details};}
 finally{for(const r of cleanup){try{r.close();}catch(e){details.push({cleanupError:e.message});}}}
}
