import hashlib,json,subprocess,tarfile,io
from pathlib import Path
root=Path.cwd();out=root/'target/evidence/virgl-depth-formats-verifier';seal=root/'evidence/virgl-depth-formats/worker';head='61db520384877672b63a23cd0539946c55297431'
digest=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((seal/'manifest.json').read_bytes());indexRaw=(seal/'records.json').read_bytes();records=json.loads(indexRaw)
assert digest(indexRaw)==manifest['recordIndex']['sha256'] and len(indexRaw)==manifest['recordIndex']['bytes']
archive=(seal/'recording.tar.gz').read_bytes();assert digest(archive)==manifest['archive']['sha256']=='dbf7a0fbd12cc4e3711e4fc4745738d9cd3ac2ae4d9d60974f19077e148996eb'
assert len(archive)==manifest['archive']['bytes'] and manifest['sourceHead']==head
want={r['path']:r for r in records};assert len(want)==len(records)==manifest['records']==60
members={};unpacked=out/'authenticated';unpacked.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
    for m in tar.getmembers():
        assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
        assert m.name in want and m.name not in members,m.name
        raw=tar.extractfile(m).read();r=want[m.name];assert len(raw)==r['bytes'] and digest(raw)==r['sha256'],m.name
        members[m.name]=raw;p=unpacked/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
assert members.keys()==want.keys()
sourceAudit=[];reports={};frozenCache={};bindings={}
generated={'renderer/virgl-shader/build/wasm/virgl-shader.mjs':'build/virgl-shader.mjs','renderer/virgl-shader/build/wasm/virgl-shader.wasm':'build/virgl-shader.wasm'}
for path,raw in members.items():
    if not path.endswith('/report.json') or path=='cold/report.json':continue
    r=json.loads(raw);reports[path]=r;assert r.get('gitHead')==head,(path,r.get('gitHead'))
    for kind in ['sources','inputs']:
        for item in r.get(kind,[]):
            file=item['path']
            if file in generated:bound=members[generated[file]];origin=generated[file]
            else:
                if file not in frozenCache:frozenCache[file]=subprocess.check_output(['git','show',head+':'+file])
                bound=frozenCache[file];origin='git:'+head+':'+file
            assert digest(bound)==item['sha256'] and len(bound)==item['bytes'],(path,file)
            assert file not in bindings or bindings[file]==item,(path,file,'conflicting binding');bindings[file]=item
            sourceAudit.append({'report':path,'kind':kind,**item,'origin':origin})
    if 'source' in r:
        item=r['source'];file=item['path'];bound=subprocess.check_output(['git','show',head+':'+file]);assert len(bound)==item['bytes'] and digest(bound)==item['sha256'];sourceAudit.append({'report':path,'kind':'source',**item,'origin':'git:'+head+':'+file})
        assert digest(members[str(Path(path).parent/'driver.mjs')])==r['driverSha256']
        cvRaw=members[str(Path(path).parent/'browser-coverage.json')];assert digest(cvRaw)==r['coverageSha256'];cv=json.loads(cvRaw)
        assert all(x['sha256']==item['sha256'] and x['source']==file for x in cv['scripts'])
        assert digest(members[str(Path(path).parent/'browser.png')])==r['screenshotSha256']
    if 'browser' in r:
        b=r['browser'];assert b['headless'] is False
        gpu=b['gpu']['featureStatus'];assert gpu.get('webgl2',gpu.get('webgl'))=='enabled'
        cmd=b.get('commandLine',[]);assert not any(x for x in cmd if any(a in x.lower() for a in ['swiftshader','llvmpipe','softpipe','lavapipe','--disable-gpu']))
        assert r['browserErrors']=={'console':[],'page':[],'requests':[]},(path,'browser error')
    for key in ['screenshot','failureScreenshot','browserCoverage']:
        if key in r:
            item=r[key];file=str(Path(path).parent/item['path']);assert digest(members[file])==item['sha256'],file
    if 'browserCoverage' in r:
        cv=json.loads(members[str(Path(path).parent/r['browserCoverage']['path'])]);scripts=cv.get('scripts',[cv] if 'source' in cv else [])
        mutation=r.get('sabotage',{});served={a['path']:a for a in r.get('servedFiles',[])}
        for s in scripts:
            expected=mutation['servedSha256'] if s['source']==mutation.get('path') else bindings[s['source']]['sha256']
            assert s['sha256']==expected,(path,s['source'])
        for item in r.get('sources',[]):
            file=item['path'];wire='/'+file
            if wire in served:
                expected=mutation['servedSha256'] if file==mutation.get('path') else item['sha256']
                assert served[wire]['sha256']==expected,(path,wire)
        if 'fixtureTransport' in r:assert served['/fixtures.json']['sha256']==r['fixtureTransport']['sha256']
        if mutation:
            fault=members[str(Path(path).parent/'fault-source.mjs')];assert digest(fault)==mutation['servedSha256']
            assert mutation['originalSha256']==bindings[mutation['path']]['sha256']
hot=json.loads(members['hot/receipt.json']);cold=json.loads(members['cold/acceptance/receipt.json']);coldReport=json.loads(members['cold/report.json'])
for receipt in [hot,cold]:
    assert receipt['gitHead']==head and receipt['status']=='passed'
    for record in receipt['records']:
        prefix='hot/' if receipt is hot else 'cold/acceptance/'
        bound=members[prefix+record['path']];assert digest(bound)==record['sha256'] and len(bound)==record['bytes']
assert hot['sources']==cold['sources'] and hot['inputs']==cold['inputs']
assert coldReport['gitHead']==coldReport['cloneHead']==head and coldReport['statusBefore']==coldReport['statusAfter']=='' and coldReport['status']=='passed' and coldReport['exitCode']==0
assert digest(members['cold/cold.log'])==coldReport['logSha256'] and digest(members['cold/acceptance/receipt.json'])==coldReport['receiptSha256']
audit={'status':'passed','archiveSha256':digest(archive),'manifestSha256':digest((seal/'manifest.json').read_bytes()),'recordIndexSha256':digest(indexRaw),'memberCount':len(members),'sourceHead':head,'bindingCount':len(bindings),'sourceBindings':sourceAudit,'records':records,'cold':coldReport,'hotReceiptSha256':digest(members['hot/receipt.json']),'coldReceiptSha256':digest(members['cold/acceptance/receipt.json'])}
(out/'authentication.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({k:v for k,v in audit.items() if k not in ['sourceBindings','records']},indent=2))
print('Reports: '+', '.join(reports))
actualDiff=subprocess.check_output(['git','diff',manifest['base'],head]);assert actualDiff==members['hot/audit/source.diff']
print('Frozen source diff and supplemental source/driver/coverage/screenshot bindings all match.')
