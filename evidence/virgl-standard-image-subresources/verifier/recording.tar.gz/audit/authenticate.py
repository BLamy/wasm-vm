from pathlib import Path,PurePosixPath
import hashlib,gzip,json,subprocess,tarfile
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
TMP=Path(__file__).resolve().parent
BASE='c0488902039a5fb5f9efc8c62101798668b2ce4a'
HEAD='89306b560bb71552a9a6800065ec54273cff0dc8'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
def seal(name,directory,out):
 m=json.loads((directory/'manifest.json').read_bytes()); ib=(directory/'records.json').read_bytes(); ab=(directory/'recording.tar.gz').read_bytes(); idx=json.loads(ib)
 assert sha(ab)==m['archiveSha256'];assert sha(ib)==m['recordIndexSha256'];assert len(ab)==m['archiveBytes']
 members={r['path']:r for r in idx['records']}; assert len(members)==len(idx['records'])==m['records']
 seen=set();total=0;out.mkdir(parents=True,exist_ok=True)
 with tarfile.open(fileobj=__import__('io').BytesIO(ab),mode='r:gz')as tar:
  for item in tar:
   p=PurePosixPath(item.name);assert item.isfile()and not p.is_absolute()and '..'not in p.parts;assert item.name in members and item.name not in seen
   row=members[item.name];raw=tar.extractfile(item).read();assert len(raw)==row['bytes']==item.size;assert sha(raw)==row['sha256'];dest=out/item.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);seen.add(item.name);total+=len(raw)
 assert seen==set(members)
 return {'name':name,'records':len(seen),'uncompressedBytes':total,'archiveSha256':sha(ab),'recordIndexSha256':sha(ib),'manifestSha256':sha((directory/'manifest.json').read_bytes()),'manifest':m}
rows=[]
worker=ROOT/'evidence/virgl-standard-image-subresources/worker';m=json.loads((worker/'manifest.json').read_text());assert m['archiveSha256']=='6dcdde6ae41416f458cb4d5371df2ac0c83ae49e2bc0571a3efa52d2142f0a48';assert m['recordIndexSha256']=='3199b8a4c20646f8cf31bd9b1e3d0b36a45c88e0e6994902b6564fddd425aeaa';assert m['sourceHead']==HEAD
rows.append(seal('D21 worker',worker,TMP/'worker'))
source_cache={}
def original(head,path):
 k=(head,path)
 if k not in source_cache:source_cache[k]=git('show',head+':'+path)
 return source_cache[k]
receipts={};browserRows=[];blobCount=0;sourceCount=0
for prefix in ['hot','cold']:
 directory=TMP/'worker'/prefix;receiptBytes=(directory/'receipt.json').read_bytes();r=json.loads(receiptBytes);receipts[prefix]=r
 assert sha(receiptBytes)==m[prefix+'ReceiptSha256'];assert r['gitHead']==HEAD and r['status']=='passed';assert r['historicalEvidenceHead']==BASE
 for path,digest in r['files'].items():assert sha((directory/path).read_bytes())==digest
 for path,digest in r['sources'].items():assert sha(original(HEAD,path))==digest;sourceCount+=1
 for path,digest in r['generated'].items():assert sha((TMP/'worker'/(prefix+'-generated')/path).read_bytes())==digest
 for path,digest in r['carriedVerifiedEvidence'].items():assert sha(original(BASE,path))==digest==sha(original(HEAD,path))==sha((ROOT/path).read_bytes())
 for reportPath in sorted(directory.glob('hardware-*/report.json'))+sorted(directory.glob('fault-*/report.json')):
  q=json.loads(reportPath.read_text());assert q['gitHead']==HEAD;assert q['fixedMemory']['bytes']==16777216;assert all(v=='function'for k,v in q['fixedMemory'].items()if k!='bytes')
  assert q['browser']['headless']==False and q['browserErrors']=={'console':[],'page':[],'requests':[]}
  assert not any(any(x in a.lower()for x in ['swiftshader','llvmpipe','softpipe','lavapipe'])or a.startswith('--disable-gpu')for a in q['browser']['commandLine'])
  result=q.get('partial')or q['browserResult']['result'];assert 'M4' in result['gpu']and'Metal'in result['gpu'];assert result['guestExecution']==False and result['productionNegotiation']==False
  served={row['path']:row for row in q['servedFiles']};sources={row['path']:row for row in q['sources']}
  for path,row in sources.items():
   sourceBytes=(TMP/'worker'/(prefix+'-generated')/path).read_bytes() if '/build/'in path else original(HEAD,path)
   assert len(sourceBytes)==row['bytes']and sha(sourceBytes)==row['sha256']
   if '/'+path in served:assert served['/'+path]['sha256']==row['sha256']and served['/'+path]['bytes']==row['bytes']
  cv=json.loads((reportPath.parent/q['browserCoverage']['path']).read_text());assert sha((reportPath.parent/q['browserCoverage']['path']).read_bytes())==q['browserCoverage']['sha256']
  for row in cv['scripts']:assert row['sha256']==sources[row['source']]['sha256']==served['/'+row['source']]['sha256'];assert row['coverage']['url'].endswith('/'+row['source'])
  for b in result['blobs']:
   packed=(reportPath.parent/b['path']).read_bytes();assert sha(packed)==b['gzipSha256'];raw=gzip.decompress(packed);assert len(raw)==b['bytes']and sha(raw)==b['sha256'];blobCount+=1
  browserRows.append({'record':str(reportPath.relative_to(TMP/'worker')),'gpu':result['gpu'],'status':q['status'],'draws':sum(len(run.get('draws',[]))for run in result['runs']),'blobs':len(result['blobs']),'scripts':len(cv['scripts'])})
cr=(TMP/'worker/cold/report.json').read_bytes();cq=json.loads(cr);assert sha(cr)==m['coldReportSha256'];assert cq['status']=='passed'and cq['cloneHead']==cq['gitHead']==HEAD;assert cq['statusBefore']==cq['statusAfter']=='';assert cq['receiptSha256']==m['coldReceiptSha256'];assert sha((TMP/'worker/cold/cold.log').read_bytes())==cq['logSha256']
for suffix in ['worker','verifier']:
 p=ROOT/'evidence/virgl-standard-texture-storage'/suffix
 for name in ['manifest.json','records.json','recording.tar.gz']:assert (p/name).read_bytes()==original(BASE,str((p/name).relative_to(ROOT)))==original(HEAD,str((p/name).relative_to(ROOT)))
 rows.append(seal('D20 '+suffix,p,TMP/'inherited'/suffix))
m20=rows[-1]['manifest'];assert m20['verdict']=='verified';assert m20['workerArchiveSha256']==rows[-2]['archiveSha256'];assert m20['workerRecordIndexSha256']==rows[-2]['recordIndexSha256'];assert m20['workerManifestSha256']==rows[-2]['manifestSha256'];assert sha((TMP/'inherited/verifier'/m20['verdictMember']).read_bytes())==m20['verdictSha256']
# Authentication inside the verified dependency is recorded, not retried.
authPath=ROOT/'evidence/virgl-standard-texture-storage/verifier'/m20['sealAuthentication'];auth=authPath.read_bytes();assert sha(auth)==m20['sealAuthenticationSha256'];assert auth==original(BASE,str(authPath.relative_to(ROOT)))
out={'schema':'fresh-image-authentication-v1','status':'passed','beforeBrowserRerun':True,'seals':rows,'authenticatedSources':sourceCount,'authenticatedFullBlobs':blobCount,'browsers':browserRows,'cold':cq,'dependencyAuthentication':json.loads(auth)}
(TMP/'authentication.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'passed','seals':[(r['name'],r['records'])for r in rows],'sourceChecks':sourceCount,'fullBlobs':blobCount,'browsers':len(browserRows),'tmp':str(TMP)}))
