from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');TMP=Path(__file__).resolve().parent
FROZEN='89306b560bb71552a9a6800065ec54273cff0dc8';BASE='c0488902039a5fb5f9efc8c62101798668b2ce4a';PROMOTED=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda head,name:subprocess.check_output(['git','show',head+':'+name],cwd=ROOT)
final=ROOT/'target/evidence/virgl-standard-image-critic-final';receipt=json.loads((final/'receipt.json').read_text());assert receipt['gitHead']==PROMOTED and receipt['status']=='passed'
for name,digest in receipt['files'].items():assert sha((final/name).read_bytes())==digest, name
for name,digest in receipt['sources'].items():assert sha(git(PROMOTED,name))==sha((ROOT/name).read_bytes())==digest,name
for name in ['decoder','resources','state']:
 p='renderer/virgl-command/'+name+'.mjs';assert git(FROZEN,p)==git(PROMOTED,p)==git('7529bc0c3fe796b9309c682ffd6308f1945f686d',p)==(ROOT/p).read_bytes()
inverse=json.loads(git(FROZEN,'tools/virgl-command/standard-image-boundary.json'));inverses=[]
for name,rows in inverse['changes'].items():
 text=git(FROZEN,name).decode()
 for row in reversed(rows):assert text.count(row['after'])==1;text=text.replace(row['after'],row['before'],1)
 assert text.encode()==git(BASE,name);inverses.append(dict(source=name,migrations=len(rows),predecessorSha256=sha(text.encode()),unchangedHistoricalShape=True))
assert sum(r['migrations']for r in inverses)==48
assert not subprocess.check_output(['git','diff','--name-only',BASE,PROMOTED,'--','renderer/virgl-shader','crates','web','tools/guest'],cwd=ROOT).strip()
prechecks=['virgl-standard-image-critic-precheck','virgl-standard-image-critic-precheck2','virgl-standard-image-critic-precheck3','virgl-standard-image-critic-fault-precheck']
records=[];sourceChecks=blobChecks=scriptChecks=0
originalIndex=json.loads((ROOT/'evidence/virgl-standard-image-subresources/worker/records.json').read_text())
generated={r['path'].split('hot-generated/',1)[1]:r['sha256']for r in originalIndex['records']if r['path'].startswith('hot-generated/')}
for group,directory in [('fresh',final)]+[(n,ROOT/'target/evidence'/n)for n in prechecks]:
 reports=list(directory.glob('*/report.json'))if group=='fresh'else[directory/'report.json']
 for reportPath in sorted(reports):
  q=json.loads(reportPath.read_text());result=q.get('partial')or q['browserResult']['result'];sourceHead=q['gitHead'];assert sourceHead==PROMOTED if group=='fresh'else sourceHead=='e32e4a5604628a70d9b55bd46eb3d1e2beb190eb'
  assert q['browserErrors']==dict(console=[],page=[],requests=[])
  assert q['browser']['headless']==False and q['browser']['gpu']['featureStatus']['webgl2']=='enabled'
  assert 'M4' in result['gpu']and'Metal'in result['gpu'];assert not any(any(x in a.lower()for x in ['swiftshader','llvmpipe','softpipe','lavapipe'])or a.startswith('--disable-gpu')for a in q['browser']['commandLine'])
  assert q['browser']['sha256']==sha(Path(q['browser']['executable']).read_bytes())
  assert q['fixedMemory']['bytes']==16777216 and all(v=='function'for k,v in q['fixedMemory'].items()if k!='bytes')
  assert result['guestExecution']==False and result['productionNegotiation']==False
  sources={r['path']:r for r in q['sources']};served={r['path']:r for r in q['servedFiles']}
  for name,row in sources.items():
   if name in generated:raw=(ROOT/name).read_bytes();assert sha(raw)==generated[name]
   elif group!='fresh'and name=='tools/virgl-command/standard-image-adversarial.mjs':raw=(TMP/'precheck-source-snapshots'/(group+'.mjs')).read_bytes()
   elif group!='fresh'and name=='tools/verify-virgl-standard-image-subresources-adversarial.mjs':raw=(ROOT/name).read_bytes()
   else:raw=git(sourceHead,name)
   assert len(raw)==row['bytes']and sha(raw)==row['sha256'],(group,name)
   if '/'+name in served:assert served['/'+name]['sha256']==row['sha256'] and served['/'+name]['bytes']==row['bytes']
   sourceChecks+=1
  for key in ['browserCoverage','screenshot']:assert sha((reportPath.parent/q[key]['path']).read_bytes())==q[key]['sha256']
  cv=json.loads((reportPath.parent/q['browserCoverage']['path']).read_text())
  for row in cv['scripts']:
   assert row['sha256']==sources[row['source']]['sha256']==served['/'+row['source']]['sha256'];assert row['coverage']['url'].endswith('/'+row['source']);scriptChecks+=1
  assert len({b['key']for b in result['blobs']})==len(result['blobs'])
  for b in result['blobs']:
   packed=(reportPath.parent/b['path']).read_bytes();assert sha(packed)==b['gzipSha256'];raw=gzip.decompress(packed);assert len(raw)==b['bytes']and sha(raw)==b['sha256'];blobChecks+=1
  if group=='fresh':
   assert q['status']==('failed'if reportPath.parent.name.startswith('fault-')else'passed')
   assert all(x['held']for x in result['predictions'])if q['status']=='passed'else result['sabotage']['fenceCompleted']and not result['sabotage']['held']
  elif group in prechecks[:2]:assert q['status']=='failed'and 'is not a function'in q['failure']['message']
  records.append(dict(record=group+'/'+reportPath.relative_to(directory).as_posix(),status=q['status'],reportSha256=sha(reportPath.read_bytes()),gpu=result['gpu'],draws=sum(len(r['draws'])for r in result['runs']),blobs=len(result['blobs']),sourceHead=sourceHead))
# Independently invert every literal decoder admission row (historical checks are carried exact code).
wireRecords=0
for side in ['hot','cold']:
 raw=(TMP/'worker'/side/'wire/report.json').read_bytes();q=json.loads(raw);assert len(q['wire']['records'])==750
 for n,r in enumerate(q['wire']['records']):
  import struct
  words=struct.unpack('<'+'I'*(len(bytes.fromhex(r['hex']))//4),bytes.fromhex(r['hex']));assert words[0]&255==1
  if r['kind']=='view':
   first,last=words[5]&255,words[5]>>8;valid=first<=last<=14;assert (first,last)==(r['first'],r['last']);assert r['observed']['ok']==valid==r['valid']
   if valid:assert r['observed']['commands'][0]['fields']['firstLevel']==first and r['observed']['commands'][0]['fields']['lastLevel']==last
  elif r['kind']=='surface':assert r['observed']['ok']==(words[4]<=14 and(words[3]!=16 or words[4]==0))==r['valid']
  else:assert not r['observed']['ok']
  wireRecords+=1
# Carry all previously HELD predecessor predictions and their earlier authenticated chain.
old=json.loads((TMP/'inherited/verifier/audit/verdict.json').read_text());assert old['verdict']=='verified'and all(p['status']=='HELD'for p in old['predictions'])
identity=json.loads((TMP/'inherited/verifier/audit/identity-audit.json').read_text())
for name in subprocess.check_output(['git','ls-files','evidence/virgl-standard-texture-storage'],cwd=ROOT,text=True).splitlines():assert git(BASE,name)==git(PROMOTED,name)==(ROOT/name).read_bytes()
out=dict(schema='fresh-original-image-custody-v1',status='passed',promotedHead=PROMOTED,runtimeFrozen=FROZEN,sourceChecks=sourceChecks,fullBlobChecks=blobChecks,fullScriptChecks=scriptChecks,wireAdmissions=wireRecords,reports=records,productInverse=inverses,unchangedUnqualifiedBoundaries=True,inheritedHeldPredictions=[p['id']for p in old['predictions']],inheritedIdentityAuditSha256=sha((TMP/'inherited/verifier/audit/identity-audit.json').read_bytes()),originalColdProofCarriedOnce=True,receiptSha256=sha((final/'receipt.json').read_bytes()))
(TMP/'fresh-authentication.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k]for k in ['status','promotedHead','sourceChecks','fullBlobChecks','fullScriptChecks','wireAdmissions','inheritedHeldPredictions']}))
