from pathlib import Path
import hashlib,json,re,subprocess
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');TMP=Path(__file__).resolve().parent;BASE='c0488902039a5fb5f9efc8c62101798668b2ce4a';HEAD='89306b560bb71552a9a6800065ec54273cff0dc8'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT,text=True)
added={};name=None;line=0;hunks=[];hunk=None
for row in git('diff','--unified=0',BASE,HEAD).splitlines():
 if row.startswith('+++ b/'):name=row[6:]
 elif row.startswith('@@'):
  line=int(re.search(r'\+(\d+)',row)[1]);hunk={'source':name,'header':row,'addedLines':[]};hunks.append(hunk)
 elif row.startswith('+')and name:added.setdefault(name,[]).append(line);hunk['addedLines'].append(line);line+=1
 elif row.startswith(' '):line+=1
scripts=[]
for f in (TMP/'worker').glob('*/**/browser-coverage.json'):
 if '/fault-'in str(f):continue
 for row in json.loads(f.read_text()).get('scripts',[]):
  if row['source']in added:scripts.append({'record':str(f.relative_to(TMP/'worker')),**row})
for f in (TMP/'worker').glob('*/node-coverage/coverage-*.json'):
 for row in json.loads(f.read_text())['result']:
  if not row['url'].startswith('file:'):continue
  for name in added:
   if row['url'].endswith('/'+name):scripts.append({'record':str(f.relative_to(TMP/'worker')),'source':name,'sha256':sha(subprocess.check_output(['git','show',HEAD+':'+name],cwd=ROOT)),'coverage':row})
regions=[];fnRows=[]
for name in [n for n in added if n.endswith('.mjs')]:
 raw=subprocess.check_output(['git','show',HEAD+':'+name],cwd=ROOT);text=raw.decode();lines=text.splitlines(keepends=True);offsets=[];start=0
 for n,s in enumerate(lines,1):end=start+len(s.encode('utf-16-le'))//2;offsets.append((n,start,end));start=end
 intervals=[(a,b)for n,a,b in offsets if n in added[name]]
 observations=[s for s in scripts if s['source']==name];assert all(s['sha256']==sha(raw)for s in observations)
 unique={};fns={}
 for s in observations:
  for fn in s['coverage']['functions']:
   full=fn['ranges'][0];key=(fn['functionName'],full['startOffset'],full['endOffset'])
   if any(full['startOffset']<b and full['endOffset']>a for a,b in intervals):
    fns.setdefault(key,[]).append({'record':s['record'],'count':full['count'],'ranges':len(fn['ranges'])})
   for r in fn['ranges']:
    if any(r['startOffset']<b and r['endOffset']>a for a,b in intervals):unique.setdefault((r['startOffset'],r['endOffset']),[]).append({'record':s['record'],'count':r['count'],'functionName':fn['functionName']})
 for(n,a,b),obs in fns.items():fnRows.append({'source':name,'functionName':n,'start':a,'end':b,'maxCount':max(o['count']for o in obs),'observations':obs})
 for(a,b),obs in unique.items():
  for script in observations:
   candidates=[r for fn in script['coverage']['functions']for r in fn['ranges']if r['startOffset']<=a and r['endOffset']>=b]
   if candidates:
    inner=min(candidates,key=lambda r:r['endOffset']-r['startOffset']);obs.append({'record':script['record'],'count':inner['count'],'functionName':'effective innermost containing region','observedStart':inner['startOffset'],'observedEnd':inner['endOffset']})
  lo=next(n for n,x,y in offsets if x<=a<y);hi=next((n for n,x,y in offsets if x<=max(a,b-1)<y),len(lines));snippet=text.encode('utf-16-le')[a*2:b*2].decode('utf-16-le');regions.append({'source':name,'start':a,'end':b,'startLine':lo,'endLine':hi,'maxCount':max(o['count']for o in obs),'snippet':snippet[:1200],'observations':obs})
zero=[r for r in regions if not r['maxCount']];runtime=[r for r in regions if r['source']in ['renderer/virgl-command/decoder.mjs','renderer/virgl-command/resources.mjs','renderer/virgl-command/state.mjs']]
out={'schema':'fresh-image-nested-region-audit-v1','predecessor':BASE,'acceptanceHead':HEAD,'status':'UNCLASSIFIED','fullRegionAuthority':True,'scripts':len(scripts),'functions':fnRows,'regions':regions,'zeroRegions':zero,'hunks':hunks,'runtimeRegions':len(runtime),'runtimeZeroRegions':len([r for r in runtime if not r['maxCount']])}
(TMP/'coverage-regions.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'scripts':len(scripts),'functions':len(fnRows),'regions':len(regions),'zeros':len(zero),'runtimeRegions':len(runtime),'runtimeZeros':out['runtimeZeroRegions'],'hunks':len(hunks)}))
for r in zero:print(json.dumps({k:r[k]for k in ['source','start','end','startLine','endLine','snippet']}))
