from pathlib import Path
import hashlib,json,re,subprocess
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');TMP=Path(__file__).resolve().parent;BASE='c0488902039a5fb5f9efc8c62101798668b2ce4a';FROZEN='89306b560bb71552a9a6800065ec54273cff0dc8';PROMOTED=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
sha=lambda b:hashlib.sha256(b).hexdigest()
from functools import lru_cache
@lru_cache(None)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
scriptRecords=[]
for group,directory in [('worker',TMP/'worker'),('fresh',ROOT/'target/evidence/virgl-standard-image-critic-final')]:
 for f in directory.rglob('browser-coverage.json'):
  j=json.loads(f.read_text());rows=j.get('scripts',[j]if'source'in j else[])
  for row in rows:scriptRecords.append(dict(record=group+'/'+str(f.relative_to(directory)),recordSha256=sha(f.read_bytes()),**row))
 for f in directory.rglob('coverage-*.json'):
  if f.parent.name!='node-coverage':continue
  for row in json.loads(f.read_text())['result']:
   if not row['url'].startswith('file:'):continue
   names=git('ls-files','renderer/virgl-command','tools').decode().splitlines()
   for name in names:
    if row['url'].endswith('/'+name):
     head=FROZEN if group=='worker'else PROMOTED
     raw=git('show',head+':'+name);scriptRecords.append(dict(record=group+'/'+str(f.relative_to(directory)),recordSha256=sha(f.read_bytes()),source=name,sha256=sha(raw),coverage=row));break

def changed(base,head):
 added={};name=None;line=0;hunks=[];hunk=None
 for row in git('diff','--unified=0',base,head).decode().splitlines():
  if row.startswith('+++ b/'):name=row[6:]
  elif row.startswith('@@'):
   line=int(re.search(r'\+(\d+)',row)[1]);hunk={'source':name,'header':row,'addedLines':[]};hunks.append(hunk)
  elif row.startswith('+')and name:added.setdefault(name,[]).append(line);hunk['addedLines'].append(line);line+=1
  elif row.startswith(' '):line+=1
 return added,hunks

def audit(base,head,label):
 added,hunks=changed(base,head);regions=[];functions=[];noScripts=[]
 for name in [n for n in added if n.endswith('.mjs')]:
  raw=git('show',head+':'+name);text=raw.decode();lines=text.splitlines(keepends=True);offsets=[];start=0
  for n,s in enumerate(lines,1):end=start+len(s.encode('utf-16-le'))//2;offsets.append((n,start,end));start=end
  intervals=[(a,b)for n,a,b in offsets if n in added[name]]
  observations=[s for s in scriptRecords if s['source']==name and s['sha256']==sha(raw)]
  if not observations:noScripts.append(name)
  unique={};fns={}
  for s in observations:
   for fn in s['coverage']['functions']:
    full=fn['ranges'][0];key=(fn['functionName'],full['startOffset'],full['endOffset'])
    if any(full['startOffset']<b and full['endOffset']>a for a,b in intervals):fns.setdefault(key,[]).append(dict(record=s['record'],recordSha256=s['recordSha256'],count=full['count'],ranges=len(fn['ranges'])))
    for r in fn['ranges']:
     if any(r['startOffset']<b and r['endOffset']>a for a,b in intervals):unique.setdefault((r['startOffset'],r['endOffset']),[]).append(dict(record=s['record'],recordSha256=s['recordSha256'],count=r['count'],functionName=fn['functionName']))
  for(n,a,b),obs in fns.items():functions.append(dict(source=name,sourceSha256=sha(raw),functionName=n,start=a,end=b,maxCount=max(o['count']for o in obs),observations=obs))
  for(a,b),obs in unique.items():
   for s in observations:
    candidates=[r for fn in s['coverage']['functions']for r in fn['ranges']if r['startOffset']<=a and r['endOffset']>=b]
    if candidates:
     inner=min(candidates,key=lambda r:r['endOffset']-r['startOffset']);obs.append(dict(record=s['record'],recordSha256=s['recordSha256'],count=inner['count'],functionName='effective innermost containing region',observedStart=inner['startOffset'],observedEnd=inner['endOffset']))
   lo=next(n for n,x,y in offsets if x<=a<y);hi=next((n for n,x,y in offsets if x<=max(a,b-1)<y),len(lines));snippet=text.encode('utf-16-le')[a*2:b*2].decode('utf-16-le');regions.append(dict(source=name,sourceSha256=sha(raw),start=a,end=b,startLine=lo,endLine=hi,maxCount=max(o['count']for o in obs),snippet=snippet,observations=obs))
 out=dict(schema='fresh-image-full-nested-coverage-v1',base=base,head=head,fullRegionAuthority=True,regions=regions,functions=functions,hunks=hunks,noMatchingScripts=noScripts,scripts=len([r for r in scriptRecords if r['source']in added and r['sha256']==sha(git('show',head+':'+r['source']))]))
 (TMP/('coverage-'+label+'.json')).write_text(json.dumps(out,indent=2)+'\n');zeros=[r for r in regions if not r['maxCount']];print(label,len(regions),'regions',len(functions),'functions',len(zeros),'zeros',len(hunks),'hunks')
 for r in zeros:print(json.dumps({k:r[k]for k in ['source','start','end','startLine','endLine','snippet']}))
 return out
original=audit(BASE,FROZEN,'final-original');promotion=audit(FROZEN,PROMOTED,'final-promotion')
