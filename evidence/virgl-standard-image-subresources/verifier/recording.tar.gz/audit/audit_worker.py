from pathlib import Path
import copy,gzip,hashlib,json,math,re,struct
TMP=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
points=[];totals={'draws':0,'fullOutputPixels':0,'nativeTexels':0,'originalTransfers':0,'physicalFences':0,'changedPlanes':0,'faults':0}
def check(ok,why,where):
 if not ok:raise AssertionError(why+' @ '+str(where))
def packets(s):
 b=bytes.fromhex(s);out=[];at=0
 while at<len(b):
  h=struct.unpack_from('<I',b,at)[0];n=h>>16;end=at+4*(n+1);check(end<=len(b),'original packet truncation',at);out.append((h&255,h>>8&255,list(struct.unpack_from('<'+'I'*n,b,at+4))));at=end
 return out
f32=lambda w:struct.unpack('<f',struct.pack('<I',w))[0]
def source(m,seed):
 planes=[];position=5
 for level in range(m['lastLevel']+1):
  w=max(1,m['width']//2**level);h=max(1,m['height']//2**level);raw=bytearray();fmt=m['format']
  for y in range(h):
   for x in range(w):
    r=(seed+17*x+31*y+53*level)&0xffffffff;g=(seed+71*x+11*y+97*level)&0xffffffff;b=(seed+41*x+83*y+19*level)&0xffffffff;a=(seed+23*x+61*y+37*level)&0xffffffff
    raw.extend(struct.pack('<I',(b%1024)+(g%1024)*1024+(r%1024)*1048576+(a%4)*1073741824)if fmt==233 else bytes([b%256,g%256,r%256,a%256]if fmt==2 else[r%256,g%256,b%256,a%256]))
  planes.append({'level':level,'width':w,'height':h,'byteLength':w*h*4,'offset':position,'stride':w*4+3,'input':bytes(raw)});position+=(h-1)*(w*4+3)+w*4+5
 backing=bytearray([0x17]*position)
 for p in planes:
  for y in range(p['height']):backing[p['offset']+y*p['stride']:p['offset']+y*p['stride']+p['width']*4]=p['input'][y*p['width']*4:(y+1)*p['width']*4]
 return planes,bytes(backing)
def native(fmt,raw):
 if fmt==233:
  out=[]
  for(w,)in struct.iter_unpack('<I',raw):out.append((w>>20&1023)+((w>>10&1023)<<10)+((w&1023)<<20)+(3<<30))
  return struct.pack('<'+'I'*len(out),*out)
 if fmt==2:return b''.join(bytes([raw[i+2],raw[i+1],raw[i],255])for i in range(0,len(raw),4))
 return bytes(raw)
def sampler(w):
 b=w[1];return {'s':b&7,'t':b>>3&7,'r':b>>6&7,'min':b>>9&1,'mip':b>>11&3,'mag':b>>13&1,'compare':b>>15&1,'compareFunction':b>>16&7,'bias':f32(w[2]),'minLod':f32(w[3]),'maxLod':f32(w[4])}
def params(p):
 wrap={0:10497,2:33071,4:33648};mins=[[9984,9986,9728],[9985,9987,9729]]
 return dict(TEXTURE_WRAP_S=wrap[p['s']],TEXTURE_WRAP_T=wrap[p['t']],TEXTURE_WRAP_R=wrap[p['r']],TEXTURE_MIN_FILTER=mins[p['min']][p['mip']],TEXTURE_MAG_FILTER=9728+p['mag'],TEXTURE_COMPARE_MODE=0,TEXTURE_COMPARE_FUNC=512+p['compareFunction'],TEXTURE_MIN_LOD=p['minLod'],TEXTURE_MAX_LOD=p['maxLod'])
def texel(fmt,p,x,y):
 x=max(0,min(p['width']-1,x));y=max(0,min(p['height']-1,y));at=4*(y*p['width']+x);raw=p['input']
 if fmt==233:
  w=struct.unpack_from('<I',raw,at)[0];return[(w>>20&1023)*255/1023,(w>>10&1023)*255/1023,(w&1023)*255/1023,255]
 return [raw[at+2],raw[at+1],raw[at],255]if fmt==2 else list(raw[at:at+4])
def sample(fmt,planes,view,p,vertex=False):
 lod=0 if vertex else -math.inf;lod=max(p['minLod'],min(p['maxLod'],lod));mag=lod<=0;linear=p['mag']if mag else p['min'];first,last=view['range'];maxlocal=last-first
 def local(k):
  plane=planes[first+k];u=plane['width']*.25;v=plane['height']*.25
  if not linear:return texel(fmt,plane,math.floor(u),math.floor(v))
  u-=.5;v-=.5;x=math.floor(u);y=math.floor(v);fx=u-x;fy=v-y;n=[texel(fmt,plane,x,y),texel(fmt,plane,x+1,y),texel(fmt,plane,x,y+1),texel(fmt,plane,x+1,y+1)]
  return[(1-fx)*(1-fy)*n[0][k]+fx*(1-fy)*n[1][k]+(1-fx)*fy*n[2][k]+fx*fy*n[3][k]for k in range(4)]
 if mag or p['mip']==2:c=local(0)
 elif p['mip']==0:c=local(min(maxlocal,max(0,math.floor(lod+.5))))
 else:
  lod=max(0,min(maxlocal,lod));k=math.floor(lod);a=local(k);b=local(min(maxlocal,k+1));c=[x*(1-(lod-k))+y*(lod-k)for x,y in zip(a,b)]
 return[0 if k==4 else 255 if k==5 else c[k]for k in view['swizzle']]
def output(fmt,planes,vs,fs,p,width,height):
 a=sample(fmt,planes,vs,p,True);b=sample(fmt,planes,fs,p,False);rgba=bytes(max(0,min(255,math.floor((x+y)/2+.5)))for x,y in zip(a,b));return rgba*(width*height)
def decode_shader(w):return struct.pack('<'+'I'*(len(w)-5),*w[5:])[:w[2]-1].decode()
def state_events(run,m,initial):
 planes=copy.deepcopy(initial);contexts={};events={};nativeGeneration={r['metadata']['id']:r['generation']for r in run['created']if r['beforeSubmission']==0}
 def sub():return {'objects':{},'views':[[None],[None]],'samplers':[[None],[None]],'shaders':[None,None],'surface':None}
 for hi,record in enumerate(run['history']):
  ctx=contexts.setdefault(record['ctx'],{'current':0,'subs':{0:sub()}});allp=packets(record['hex']);count=record.get('appliedBeforeDispose',record['result'].get('appliedCommands',len(allp)))
  for op,kind,w in allp[:count]:
   s=ctx['subs'][ctx['current']]
   if op==1:
    o={'kind':kind,'handle':w[0]}
    if kind==6:o.update(resource=w[1],format=w[2]&0xffffff,range=[w[4]&255,w[4]>>8],swizzle=[w[5]>>(3*k)&7 for k in range(4)],resourceGeneration=nativeGeneration.get(w[1]))
    elif kind==7:o['params']=sampler(w)
    elif kind==8:o.update(resource=w[1],format=w[2],level=w[3])
    elif kind==4:o['text']=decode_shader(w)
    s['objects'][w[0]]=o
   elif op==3:s['objects'].pop(w[0],None)
   elif op in[10,18]:
    slots=s['views'if op==10 else'samplers'][w[0]]
    for k,h in enumerate(w[2:]):
     while len(slots)<=w[1]+k:slots.append(None)
     slots[w[1]+k]=s['objects'].get(h)if h else None
   elif op==31:s['shaders'][w[1]]=s['objects'].get(w[0])
   elif op==5:s['surface']=s['objects'][w[2]]if len(w)>2 and w[2]else None
   elif op==29:ctx['subs'][w[0]]=sub();ctx['current']=w[0]
   elif op==28:ctx['current']=w[0]
   elif op==30:ctx['subs'].pop(w[0],None);ctx['current']=0 if ctx['current']==w[0]else ctx['current']
   elif op==43 and w[0]==6 and w[12]==1:planes[w[1]]['input']=initial[w[1]]['input'];totals['originalTransfers']+=1
   elif op==7 and w[0]&4 and s['surface']and s['surface']['resource']==6:
    sf=s['surface'];p=planes[sf['level']];channels=[max(0,min(3 if m['format']==233 and k==3 else 1023 if m['format']==233 else 255,math.floor(f32(w[k+1])*(3 if m['format']==233 and k==3 else 1023 if m['format']==233 else 255)+.5)))for k in range(4)]
    pixel=struct.pack('<I',(channels[0]<<20)+(channels[1]<<10)+channels[2]+(3<<30))if m['format']==233 else bytes([channels[2],channels[1],channels[0],255]if m['format']==2 else channels)
    p['input']=pixel*(p['width']*p['height']);events[record['label']]={'kind':'clear','surface':sf,'planes':copy.deepcopy(planes),'record':hi};totals['changedPlanes']+=1
   elif op==8:
    vs=s['views'][0][0];fs=s['views'][1][0];p=s['samplers'][0][0]['params'];check(p==s['samplers'][1][0]['params'],'both original stage samplers equal',record['label'])
    texts=[s['shaders'][k]['text']for k in range(2)];check('IMM[0] FLT32 {0,0,0,0}'in texts[0]and texts[0].count('TEX OUT[2], IMM[2], SAMP[0], 2D')==1,'literal vertex lookup body',record['label']);check('IMM[1] FLT32 {0.25,0.25,0,0}'in texts[0]and'IMM[2] FLT32 {0.25,0.25,0,0}'in texts[0],'literal coordinates',record['label']);check('ADD TEMP[0], TEMP[0], IN[1]'in texts[1]and'MUL OUT[0], TEMP[0], IMM[0]'in texts[1]and'IMM[0] FLT32 {0.5,0.5,0.5,0.5}'in texts[1],'original average shader body',record['label'])
    events[record['label']]={'kind':'draw','surface':s['surface'],'vs':vs,'fs':fs,'params':p,'planes':copy.deepcopy(planes),'texts':texts,'record':hi}
    if s['surface']['resource']==6 and m['format']==67:
     target=planes[s['surface']['level']];target['input']=output(m['format'],planes,vs,fs,p,target['width'],target['height'])
 return events
for prefix in['hot','cold']:
 home=TMP/'worker'/prefix
 for directory in sorted(home.glob('hardware-*'))+sorted(home.glob('fault-*')):
  if not(directory/'report.json').exists():continue
  q=json.loads((directory/'report.json').read_text());r=q.get('partial')or q['browserResult']['result'];fault=directory.name.startswith('fault-');blobs={b['key']:b for b in r['blobs']};blobCache={}
  def blob(ref):
   key=ref if isinstance(ref,str)else ref['key']
   if key not in blobCache:blobCache[key]=gzip.decompress((directory/blobs[key]['path']).read_bytes())
   b=blobCache[key];check(sha(b)==blobs[key]['sha256'],'complete blob hash',key)
   if isinstance(ref,dict):check(len(b)==ref['bytes']and sha(b)==ref['sha256'],'bound blob reference',key)
   return b
  def compare(actual,expected,tolerance=0):return[{'at':i,'actual':a,'predicted':b}for i,(a,b)in enumerate(zip(actual,expected))if abs(a-b)>tolerance]+([{'lengths':[len(actual),len(expected)]}]if len(actual)!=len(expected)else[])
  for ri,run in enumerate(r['runs']):
   where=f'{prefix}/{directory.name}/report.json#/browserResult/result/runs/{ri}';m=run['metadata'];planes,backing=source(m,run['originalSeed']);check(blob(run['backing'])==backing,'original seed backing with row padding',where)
   for p,expected in zip(run['planes'],planes):check(blob(p['input'])==expected['input'],'original seed plane',where+f'/planes/{p["level"]}')
   event=state_events(run,m,planes);sourceTexture=[o['id']for o in run['nativeObjects']if o['name']=='createTexture'][1];targetTexture=[o['id']for o in run['nativeObjects']if o['name']=='createTexture'][0]
   for hi,h in enumerate(run['history']):
    if h['result'].get('gpuComplete'):
     fs=[e for e in run['events']if e.get('label')==h['label']and e['name']=='fenceSync'];completed=[e for e in run['events']if e.get('label')==h['label']and e['name']=='clientWaitSync'and e.get('actual')in[37146,37148]and e.get('delivered')in[37146,37148]]
     check(bool(fs)and bool(completed),'claimed completed physical later-task fence',where+f'/history/{hi}');check(all(any(f['sync']==e['sync']and e['turn']>f['turn']for f in fs)for e in completed),'successful wait comes in later task on exact physical fence',where+f'/history/{hi}');totals['physicalFences']+=1
   for di,d in enumerate(run['draws']):
    point=where+f'/draws/{di}';e=event[d['label']];check(e['kind']=='draw','original native draw event',point);sf=e['surface'];check(d['native']['level']==sf['level'],'actual native selected surface level',point);check(d['native']['attachment']==(sourceTexture if sf['resource']==6 else targetTexture),'exact selected target native identity',point)
    hs=run['history'][e['record']];dp=(hs.get('dump')or{}).get('programs',[])or[p for h in run['history']for p in(h.get('dump')or{}).get('programs',[])];nativeBodies={s['stage']:s['glsl']for s in d['shaders']}
    if dp:check(any(p['vertexTGSI']==e['texts'][0]and p['fragmentTGSI']==e['texts'][1]and p['vertexESSL300']==nativeBodies[35633]and p['fragmentESSL300']==nativeBodies[35632]for p in dp),'complete original->translated->native shader identity',point)
    for si,s in enumerate(d['samplers']):
     v=e['vs'if s['unit']==16 else'fs'];check(s['name']==('vssamp0'if s['unit']==16 else'fssamp0'),'stage sampler name/unit',point);check(s['parameters']==params(e['params']),'all literal sampler native parameters',point);check(s['base']==0 and s['last']==v['range'][1]-v['range'][0],'native restored exact range base/max',point)
     first,last=v['range'];p=e['planes'][first];check(s['metadata']['width']==p['width']and s['metadata']['height']==p['height']and s['metadata']['lastLevel']==last-first,'selected local mip metadata',point);check(s['metadata']['byteLength']==sum(x['width']*x['height']*4 for x in e['planes'][first:last+1]),'exact complete native range charge',point)
     alias=first==0 and last==m['lastLevel'];check((s['texture']==sourceTexture)==alias,'restricted range private versus full original alias native identity',point)
     if not fault:check(not compare(blob(s['texels']),native(m['format'],p['input']),0 if m['format']==233 else 1),'full pre-draw selected native plane',point)
     if not alias:
      copies=[x for x in run['imageEvents']if x['name']=='blitFramebuffer'and x['label']==d['label']and x['draw']==s['texture']];check(bool(copies),'active range refreshed by actual native GPU copy',point)
      if not fault:
       check({x['drawLevel']for x in copies}==set(range(last-first+1)),'all private planes copied before active draw',point);check(all(x['read']==sourceTexture and x['readLevel']==first+x['drawLevel']and x['args'][0:4]==x['args'][4:8]and x['args'][-2:]==[16384,9728]for x in copies),'same-format unscaled literal source plane GPU blits',point)
    for a in d['attributes']:check(blob(a['bytes'])==struct.pack('<12f',-1,-1,0,1,3,-1,0,1,-1,3,0,1),'complete literal native vertex positions',point)
    totals['draws']+=1
   if directory.name=='hardware-matrix':
    for fi,f in enumerate(r['frames']):
     if f['run']!=ri:continue
     e=event[f['label']];check(f['wire']==run['history'][f['historyIndex']]['hex'],'frame immutable original wire',where);expected=output(m['format'],e['planes'],e['vs'],e['fs'],e['params'],8,8);check(not compare(blob(f['pixels']),expected,1),'full independently reconstructed matrix pixels',where+f'/frames/{fi}');totals['fullOutputPixels']+=64
     for b in f['bindings']:
      v=e['vs'if b['stage']==0 else'fs'];check(b['range']==v['range'],'binding follows original view words',where)
      for p in b['planes']:
       check(p['original']==v['range'][0]+p['local'],'full copied mip maps original range',where);check(blob(p['native'])==native(m['format'],e['planes'][p['original']]['input']),'every native plane exact independent original seed bytes',where);totals['nativeTexels']+=p['width']*p['height']
   for oi,o in enumerate(run.get('observations',[])):
    point=where+f'/observations/{oi}'
    if not o.get('native'):continue
    e=event.get(o.get('label'));fmt=o.get('format',m['format']);raw=blob(o['native']);expected=None
    if e and e['kind']=='draw':expected=output(m['format'],e['planes'],e['vs'],e['fs'],e['params'],o['width'],o['height']);check(blob(o['expected'])==expected,'stored expected output is independently reconstructed original input',point);totals['fullOutputPixels']+=o['width']*o['height']
    elif e and e['kind']=='clear':expected=native(fmt,e['planes'][o['level']]['input'])
    else:expected=native(fmt,planes[1]['input'])
    if o.get('expectedWords'):expected=struct.pack('<I',0xc0000000)if fmt==233 else bytes([0,0,0,255])
    misses=compare(raw,expected,0 if fmt==233 else 1)
    if fault and misses:totals['faults']+=1;check(r['sabotage']['fenceCompleted']==True and r['sabotage']['held']==False,'actual native fault oracle only after complete physical fence',point);points.append({'result':'FAILED AS PREDICTED','point':point,'reportSha256':sha((directory/'report.json').read_bytes()),'misses':misses[:8]})
    elif not fault:check(not misses,'complete independently reconstructed boundary native output',point)
    totals['nativeTexels']+=len(raw)//4
   for oi,o in enumerate(run.get('observations',[])):
    point=where+f'/observations/{oi}'
    if o.get('point'):
     j=o['point']['renderer']['jobs'];b=o['point']['resources']['budgets'];check(j['status']=='finishing'and j['imageHolds']==2 and j['imageSources']==1 and b['imageViews']==2 and b['imageHolds']==3,'retained images and target charged at pending native fence',point)
    if 'ceiling'in o:check(o['record']['result']['ok']==(o['ceiling']==636)and o['budgets']['gpuBytes']==(636 if o['ceiling']==636 else 604),'exact and one-byte-short private range charge',point)
   if not fault:
    for key in['resources','renderer']:check(all(n==0 for n in run['final'][key]['budgets'].values()),'all final owner budgets zero',where)
    check(all(x['deleted']==1 for x in run['nativeObjects']),'each actual native allocation deleted once',where)
   points.append({'result':'HELD','record':where,'sourceSeed':run['originalSeed'],'sourceFormat':m['format'],'sourceDimensions':[m['width'],m['height'],m['lastLevel']],'draws':len(run['draws']),'reportSha256':sha((directory/'report.json').read_bytes())})
out={'schema':'fresh-independent-original-image-audit-v1','status':'passed','implementationOrWorkerOracleImports':False,'predictionsBeforeEvidence':True,'totals':totals,'points':points}
(TMP/'worker-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':'passed','totals':totals,'points':len(points)}))
