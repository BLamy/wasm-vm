from pathlib import Path
import hashlib,json,subprocess
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');TMP=Path(__file__).resolve().parent;BASE='c0488902039a5fb5f9efc8c62101798668b2ce4a';PROMOTED=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();sha=lambda b:hashlib.sha256(b).hexdigest()
j=json.loads((TMP/'inherited/verifier/audit/identity-audit.json').read_text());rows=[]
for row in j['reports']:
 if 'inherited'not in row:continue
 path=row['inherited'];m=json.loads((ROOT/path/'manifest.json').read_text());assert sha((ROOT/path/'recording.tar.gz').read_bytes())==row['archiveSha256']==m['archiveSha256'];assert sha((ROOT/path/'records.json').read_bytes())==row['indexSha256']==m['recordIndexSha256']
 for name in ['manifest.json','records.json','recording.tar.gz']:
  p=path+name;assert subprocess.check_output(['git','rev-parse',BASE+':'+p],cwd=ROOT)==subprocess.check_output(['git','rev-parse',PROMOTED+':'+p],cwd=ROOT)
 rows.append(dict(**row,unchangedGitBlobIdentity=True,previousWholeMemberAuthenticationCarried=True))
assert len(rows)==10
out=dict(schema='unchanged-held-image-dependency-carry-v1',status='passed',predecessor=BASE,promotedHead=PROMOTED,D20WorkerAndCritic='Every whole member independently authenticated by this verifier; earlier whole member authentications carried only across these unchanged whole archive/index/Git identities',earlierSeals=rows,heldD20Predictions=[p['id']for p in json.loads((TMP/'inherited/verifier/audit/verdict.json').read_text())['predictions']])
(TMP/'inherited-carry.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status='passed',earlierUnchangedSeals=len(rows))))
