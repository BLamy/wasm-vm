/** Fresh original-wire retained generation proof; no implementation pixel oracle. */
import {createStandardImageResourceStore,createWebGL2TransferBackend} from '../../renderer/virgl-command/resources.mjs';
import {createVirglStandardImageAsyncRenderer} from '../../renderer/virgl-command/state.mjs';
import {createVirglStandardUniformShaderBridge} from '../../renderer/virgl-shader/standard.mjs';
import {rig,finish,submit,blob} from '../../renderer/virgl-command/tests/standard-image-rig.mjs';
import {checks,traceGL} from '../../renderer/virgl-command/tests/standard-instanced-draws.mjs';
import {nativeRead} from '../../renderer/virgl-command/tests/standard-texture-storage.mjs';
import {runAcceptance as boundaries} from '../../renderer/virgl-command/tests/standard-image-boundaries.mjs';
const hex=b=>Array.from(b,x=>x.toString(16).padStart(2,'0')).join('');
const packet=(op,kind,w)=>{const b=new Uint8Array(4*(w.length+1)),v=new DataView(b.buffer);v.setUint32(0,op|kind<<8|w.length<<16,true);w.forEach((x,i)=>v.setUint32(4*(i+1),x,true));return b;};
const join=(...xs)=>{const b=new Uint8Array(xs.reduce((n,x)=>n+x.length,0));let n=0;for(const x of xs){b.set(x,n);n+=x.length;}return b;};
const word=n=>new DataView(new Float32Array([n]).buffer).getUint32(0,true);
const meta=(id,target,format,bind,width,height=1,lastLevel=0)=>({id,target,format,bind,width,height,lastLevel,depth:1,arraySize:1,nrSamples:0,flags:0});
const view=(h,id,f,a,b,sw=[0,1,2,3])=>packet(1,6,[h,id,f|2<<24,0,a|b<<8,sw.reduce((n,k,i)=>n|k<<i*3,0)]);
const surface=(h,id,f,l)=>packet(1,8,[h,id,f,l,0]);
const bind=(stage,h,s=8)=>join(packet(10,0,[stage,0,h]),packet(18,0,[stage,0,s]));
const draw=()=>packet(8,0,[0,3,4,0,1,0,0,0,0,0,0xffffffff,0]);
const viewport=(w,h)=>packet(4,0,[0,...[w/2,h/2,.5,w/2,h/2,.5].map(word)]);
const sampler=()=>packet(1,7,[8,2|2<<3|2<<6|1<<9|1<<11|1<<13,0,word(.75),word(.75),0,0,0,0]);
const clear=values=>{const b=packet(7,0,[4,...values.map(word),0,0,0]);new DataView(b.buffer).setFloat64(24,1,true);return b;};
const shader=(h,stage,text)=>{const b=packet(1,4,[h,stage,text.length+1,8192,0,...Array(Math.ceil((text.length+1)/4)).fill(0)]);b.set(new TextEncoder().encode(text),24);return b;};
const transfer=(id,level,w,h,offset=0,stride=0)=>packet(43,0,[id,level,0,stride,stride?stride*h:0,0,0,0,w,h,1,offset,1]);
function specimen(){
 const vertex='VERT\nDCL IN[0]\nDCL OUT[0], POSITION\nDCL OUT[1], GENERIC[0]\nDCL OUT[2], GENERIC[1]\nDCL SAMP[0]\nDCL SVIEW[0], 2D, FLOAT\nIMM[0] FLT32 {0,0,0,0}\nIMM[1] FLT32 {0.625,0.375,0,0}\nIMM[2] FLT32 {0.375,0.625,0,0}\n0: MOV OUT[0], IN[0]\n1: MAD OUT[1], IN[0], IMM[0], IMM[1]\n2: TEX OUT[2], IMM[2], SAMP[0], 2D\n3: END\n';
 const fragment='FRAG\nDCL IN[0], GENERIC[0], PERSPECTIVE\nDCL SAMP[0]\nDCL SVIEW[0], 2D, FLOAT\nDCL IN[1], GENERIC[1], PERSPECTIVE\nDCL OUT[0], COLOR\nDCL TEMP[0]\nIMM[0] FLT32 {0.5,0.5,0.5,0.5}\n0: TEX TEMP[0], IN[0], SAMP[0], 2D\n1: ADD TEMP[0], TEMP[0], IN[1]\n2: MUL OUT[0], TEMP[0], IMM[0]\n3: END\n';
 return {vertex,fragment,width:8,height:8,positions:new Uint8Array(new Float32Array([-1,-1,0,1,3,-1,0,1,-1,3,0,1]).buffer)};
}
function source(w,h,f,seed){
 const metadata=meta(6,2,f,10,w,h,Math.floor(Math.log2(Math.max(w,h)))),planes=[];let offset=7;
 for(let level=0;level<=metadata.lastLevel;level++){
  const width=Math.max(1,Math.floor(w/2**level)),height=Math.max(1,Math.floor(h/2**level)),input=new Uint8Array(width*height*4),v=new DataView(input.buffer);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
   const a=[(seed+29*x+43*y+61*level)>>>0,(seed+47*x+17*y+89*level)>>>0,(seed+73*x+31*y+37*level)>>>0,(seed+19*x+53*y+23*level)>>>0],at=4*(y*width+x);
   if(f===233)v.setUint32(at,((a[0]%1024)<<20|(a[1]%1024)<<10|(a[2]%1024)|((a[3]%4)<<30))>>>0,true);else input.set(f===2?[a[2]&255,a[1]&255,a[0]&255,a[3]&255]:a.map(n=>n&255),at);
  }
  planes.push({level,width,height,input,offset,stride:width*4+5});offset+=(height-1)*(width*4+5)+width*4+7;
 }
 const backing=new Uint8Array(offset).fill(0xa9);for(const p of planes)for(let y=0;y<p.height;y++)backing.set(p.input.subarray(y*p.width*4,(y+1)*p.width*4),p.offset+y*p.stride);
 return {metadata,planes,backing};
}
const uploads=src=>join(...src.planes.map(p=>transfer(6,p.level,p.width,p.height,p.offset,p.stride)));
const setup=(s,src)=>join(transfer(3,0,s.positions.length,1),uploads(src),shader(1,0,s.vertex),shader(2,1,s.fragment),packet(1,5,[3,0,0,0,31]),packet(2,5,[3]),packet(6,0,[16,0,3]),surface(4,1,67,0),packet(5,0,[1,0,4]),viewport(8,8),packet(31,0,[1,0]),packet(31,0,[2,1]),clear([0,0,0,0]));
function rgba(f,p,x,y){x=Math.min(p.width-1,Math.max(0,x));y=Math.min(p.height-1,Math.max(0,y));const at=4*(y*p.width+x);if(f===233){const w=new DataView(p.input.buffer).getUint32(at,true);return[(w>>>20&1023)/1023,(w>>>10&1023)/1023,(w&1023)/1023,1];}return(f===2?[p.input[at+2],p.input[at+1],p.input[at],255]:[...p.input.subarray(at,at+4)]).map(n=>n/255);}
function sample(src,range,coord,sw=[0,1,2,3]){
 const at=l=>{const p=src.planes[range[0]+l],u=coord[0]*p.width-.5,v=coord[1]*p.height-.5,x=Math.floor(u),y=Math.floor(v),a=u-x,b=v-y,n=[rgba(src.metadata.format,p,x,y),rgba(src.metadata.format,p,x+1,y),rgba(src.metadata.format,p,x,y+1),rgba(src.metadata.format,p,x+1,y+1)];return [0,1,2,3].map(k=>(1-a)*(1-b)*n[0][k]+a*(1-b)*n[1][k]+(1-a)*b*n[2][k]+a*b*n[3][k]);};
 const a=at(0),b=at(Math.min(1,range[1]-range[0])),color=a.map((n,k)=>n*.25+b[k]*.75);return sw.map(k=>k===4?0:k===5?1:color[k]);
}
const color=(src,vs,fs,vSw=[0,1,2,3],fSw=[0,1,2,3])=>{const a=sample(src,vs,[.375,.625],vSw),b=sample(src,fs,[.625,.375],fSw);return a.map((n,k)=>(n+b[k])/2);};
function output(f,c,w,h,guest=false){
 const out=new Uint8Array(w*h*4),v=new DataView(out.buffer),channels=c.map((n,k)=>Math.round(Math.max(0,Math.min(1,n))*(f===233?(k===3?3:1023):255)));
 for(let i=0;i<w*h;i++)if(f===233)v.setUint32(i*4,(guest?channels[0]<<20|channels[1]<<10|channels[2]:channels[0]|channels[1]<<10|channels[2]<<20)|3<<30,true);else out.set(f===2?(guest?[channels[2],channels[1],channels[0],255]:[channels[0],channels[1],channels[2],255]):channels,i*4);return out;
}
const bytes=raw=>new Uint8Array(raw.buffer,raw.byteOffset,raw.byteLength).slice();
async function verifyPixels(report,r,row,record,texture,f,w,h,level,predicted){
 r.c.same(record.result.gpuComplete,true,'novel output read occurs only after completed physical fence');const raw=bytes(nativeRead(r.gl,texture,f,w,h,level)),misses=[];for(let i=0;i<raw.length;i++)if(Math.abs(raw[i]-predicted[i])>(f===233?0:1))misses.push({at:i,observed:raw[i],predicted:predicted[i]});
 const observation={label:record.label,wire:record.hex,format:f,width:w,height:h,level,texture:r.trace.id(texture),gpuComplete:record.result.gpuComplete,native:await blob(report,raw),predicted:await blob(report,predicted),misses:misses.slice(0,12),historyIndex:r.history.length-1,dump:record.dump};observation.selectedBindings=[];for(const stage of[0,1]){const unit=stage?0:16;r.gl.activeTexture(r.gl.TEXTURE0+unit);const texture=r.gl.getParameter(r.gl.TEXTURE_BINDING_2D),a=r.allocations.find(a=>a.storage.texture===texture),planes=[];for(let local=0;local<=a.metadata.lastLevel;local++){const width=Math.max(1,Math.floor(a.metadata.width/2**local)),height=Math.max(1,Math.floor(a.metadata.height/2**local));planes.push({local,width,height,native:await blob(report,bytes(nativeRead(r.gl,texture,a.metadata.format,width,height,local)))});}observation.selectedBindings.push({stage,unit,texture:r.trace.id(texture),metadata:a.metadata,base:r.gl.getTexParameter(r.gl.TEXTURE_2D,r.gl.TEXTURE_BASE_LEVEL),last:r.gl.getTexParameter(r.gl.TEXTURE_2D,r.gl.TEXTURE_MAX_LEVEL),planes});}r.gl.activeTexture(r.gl.TEXTURE0);row.observations.push(observation);report.sabotage={fenceCompleted:record.result.gpuComplete,held:misses.length===0,label:record.label,misses:misses.slice(0,12)};r.c.same(observation.misses,[],'independent retained generation original oracle after completed physical fence');return observation;
}
async function errorCleanup(gl,bridge,c,report){
 const trace=traceGL(gl,c,2),nativeEvents=[],nativeObjects=[];let armed=false;
 const observed=new Proxy(trace.gl,{get(t,name){const fn=Reflect.get(t,name,t);if(typeof fn!=='function')return fn;return(...args)=>{const answer=fn(...args);if(name==='getError')nativeEvents.push({name,actual:answer});if(/^create(Texture|Framebuffer|Buffer|Sampler|Shader|Program|VertexArray)$/.test(name)&&answer)nativeObjects.push({name,id:trace.id(answer),deleted:0,object:answer});if(/^delete(Texture|Framebuffer|Buffer|Sampler|Shader|Program|VertexArray)$/.test(name)&&args[0]){const n=nativeObjects.find(o=>o.object===args[0]);if(n)n.deleted++;}return answer;};}});
 const backend=c.ok(createWebGL2TransferBackend(observed),'cleanup actual backend').backend,owner=c.ok(createStandardImageResourceStore({backend}),'cleanup actual image owner');
 const originalCapture=owner.imageAccess.capture,captureEvents=[];const imageAccess={...owner.imageAccess,capture(...args){const result=originalCapture(...args);if(armed&&result.ok){gl.texParameteri(gl.TEXTURE_2D,0xffffffff,0);captureEvents.push({captured:true,first:args[1],last:args[2],injectedNativeCall:['texParameteri',gl.TEXTURE_2D,0xffffffff,0]});armed=false;}return result;}};
 const renderer=c.ok(createVirglStandardImageAsyncRenderer({gl:observed,shaderBridge:bridge,resources:owner.store,bindings:owner.bindings,asyncAccess:owner.asyncAccess,uniformAccess:owner.uniformAccess,imageAccess,jobLimits:{commandsPerStep:1}}),'cleanup native renderer').renderer;
 c.ok(owner.store.createContext(1),'cleanup resource context');c.ok(renderer.createContext(1),'cleanup renderer context');c.ok(owner.store.createResource(meta(6,2,67,10,8,4,3)),'cleanup original source');c.ok(owner.store.attachContextResource(1,6),'cleanup original membership');
 const r={gl,c,trace,renderer,...owner,frame:0,history:[],exchanges:[]};armed=true;const record=await submit(r,1,view(5,6,67,1,2),'native-error-after-original-capture');c.same(record.result.ok,false,'captured image native error rejects publication');c.same(record.result.error.code,'backend-error','captured image native error explicit');c.same(captureEvents.length,1,'actual native error follows successful owned capture');c.same(nativeEvents.filter(e=>e.actual===gl.INVALID_ENUM).length,1,'actual native invalid enum reaches renderer check');const point={renderer:renderer.inspect(),resources:owner.store.inspect(),images:owner.imageAccess.inspect()};c.same(point.images.views,0,'failed unpublished image token cleaned');c.same(point.images.allocations,0,'failed unpublished private allocation cleaned');c.same(point.resources.budgets.gpuBytes,172,'failed unpublished private GPU charge removed');c.same(point.resources.budgets.leases,0,'failed unpublished original lease removed');c.ok(renderer.dispose(),'cleanup renderer disposal');c.ok(owner.store.dispose(),'cleanup store disposal');c.same(nativeObjects.every(o=>o.deleted===1),true,'cleanup all actual native objects retired once');report.cleanup={record,point,captureEvents,nativeEvents,nativeObjects:nativeObjects.map(({object,...o})=>o),events:trace.events,final:{renderer:renderer.inspect(),resources:owner.store.inspect()}};
}
export async function runAcceptance({mode='novel',seed=0x6a09e667,fault}={}){
 if(mode==='boundaries')return boundaries({seed});
 const c=checks(),rawGl=document.querySelector('#gpu').getContext('webgl2',{antialias:false,preserveDrawingBuffer:true,failIfMajorPerformanceCaveat:true}),ext=rawGl.getExtension('WEBGL_debug_renderer_info'),bridge=await createVirglStandardUniformShaderBridge(),report={schema:'fresh-original-image-retention-v1',status:'running',gpu:rawGl.getParameter(ext.UNMASKED_RENDERER_WEBGL),seed,fault:fault??null,runs:[],frames:[],blobs:[],predictions:c.rows,guestExecution:false,productionNegotiation:false};window.__standardImageEvidence=report;c.same(/M4.*Metal|Metal.*M4/.test(report.gpu),true,'fresh actual M4 Metal required');
 let random=seed>>>0;const jitter=()=>{random^=random<<13;random^=random>>>17;random^=random<<5;return(random>>>0)%5;};const live=new Map();
 try{
 for(const format of fault?[67]:[2,67,233])for(const [w,h]of fault?[[8,4]]:[[8,4],[7,5]]){
  const originalSeed=random,s=specimen(),src=source(w,h,format,originalSeed);let armed=false,r,oldTexture;const sabotage=[];
  const gl=new Proxy(rawGl,{get(t,name){const fn=Reflect.get(t,name,t);if(typeof fn!=='function')return fn;return(...args)=>{let actual=args;if(armed&&fault&&name==='framebufferTexture2D'&&args[0]===rawGl.READ_FRAMEBUFFER&&args[3]===oldTexture&&args[4]>0&&r.trace.id(rawGl.getParameter(rawGl.READ_FRAMEBUFFER_BINDING))===2){actual=[...args];actual[4]=0;sabotage.push({label:r.currentLabel,name,source:r.trace.id(oldTexture),originalLevel:args[4],actualLevel:0});}return fn.apply(t,actual);};}});
  r=rig(gl,bridge,c,s,{delay:jitter,step:1});r.blobs=report.blobs;r.add(meta(3,0,64,0,s.positions.length),s.positions);const created=r.add(src.metadata,src.backing);oldTexture=r.allocations.find(a=>a.metadata.id===6).storage.texture;
  const row={kind:'novel',originalSeed,metadata:src.metadata,generation:created.generation,backing:await blob(report,src.backing),planes:[],observations:[],sabotage};for(const p of src.planes)row.planes.push({...p,input:await blob(report,p.input)});report.runs.push(row);live.set(r,row);r.currentLabel='novel-setup';c.ok((await submit(r,1,setup(s,src),'novel-setup')).result,'literal novel setup');
  const vs=[1,1],fs=[2,2],mixed=color(src,vs,fs);r.currentLabel='same-image-disjoint-level0';const sameWire=join(view(5,6,format,...vs),view(6,6,format,...fs),sampler(),bind(0,5),bind(1,6),surface(20,6,format,0),packet(5,0,[1,0,20]),viewport(w,h),draw()),same=await submit(r,1,sameWire,r.currentLabel);c.ok(same.result,'same original image disjoint plane draws');await verifyPixels(report,r,row,same,oldTexture,format,w,h,0,output(format,mixed,w,h));src.planes[0].input=output(format,mixed,w,h,true);
  r.currentLabel='copy-GPU-drawn-level0';const copied=await submit(r,1,join(view(7,6,format,0,0),bind(1,7),packet(5,0,[1,0,4]),viewport(8,8),draw()),r.currentLabel);c.ok(copied.result,'GPU-only drawn plane refresh');await verifyPixels(report,r,row,copied,r.allocations[0].storage.texture,67,8,8,0,output(67,color(src,vs,[0,0]),8,8));
  c.same(hex(c.ok(r.store.readBacking(6,0,src.backing.length),'read unchanged original backing after GPU-only draw').bytes),hex(src.backing),'GPU-only same-image draw leaves complete original backing unchanged');c.ok(r.store.unref(6),'retire original public ID with bound old views');const fresh=source(w,h,format,(originalSeed^0xf3b4a291)>>>0),replacement=r.add(fresh.metadata,fresh.backing);c.same(replacement.generation>created.generation,true,'same public ID has independent new generation');row.replacement={seed:(originalSeed^0xf3b4a291)>>>0,generation:replacement.generation,backing:await blob(report,fresh.backing)};
  r.currentLabel='upload-reused-public-generation';c.ok((await submit(r,1,uploads(fresh),r.currentLabel)).result,'new public generation uploads original literal poison');c.ok(r.renderer.resetCaches(),'reset caches across retained-generation reuse');for(const unit of[0,16]){gl.activeTexture(gl.TEXTURE0+unit);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_BASE_LEVEL,1);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAX_LEVEL,1);gl.bindTexture(gl.TEXTURE_2D,null);gl.bindSampler(unit,null);}gl.activeTexture(gl.TEXTURE0+9);
  armed=Boolean(fault);r.currentLabel='old-after-public-reuse';const retained=await submit(r,1,draw(),r.currentLabel);c.ok(retained.result,'old retained images draw across ID reuse/cache poison');await verifyPixels(report,r,row,retained,r.allocations[0].storage.texture,67,8,8,0,output(67,color(src,vs,[0,0]),8,8));
  armed=false;
  // Both old and new image generations execute in one owned job. Retired old
  // private images stay charged while public handles5/7 name new images.
  r.currentLabel='queued-old-new-generation';const wire=join(draw(),packet(3,6,[5]),packet(3,6,[7]),packet(3,6,[6]),packet(3,8,[20]),view(5,6,format,1,2,[2,1,0,3]),view(7,6,format,0,0,[0,4,2,5]),bind(0,5),bind(1,7),draw());let point;
  const queued=await submit(r,1,wire,r.currentLabel,async(step)=>{if(!point&&r.renderer.inspect().jobs.status==='finishing'){point={renderer:r.renderer.inspect(),resources:r.store.inspect(),images:r.imageAccess.inspect()};c.same(point.renderer.jobs.imageHolds,4,'old/new private generation holds coexist until final fence');c.same(point.renderer.jobs.imageSources,1,'exact target allocation holds across generation rebind');c.same(point.images.holds,5,'four images and one surface charged at pending final fence');}});c.ok(queued.result,'queued old/new original images complete');row.queuedPoint=point;c.same(Boolean(point),true,'queued generation lifetime reaches pending final fence');await verifyPixels(report,r,row,queued,r.allocations[0].storage.texture,67,8,8,0,output(67,color(fresh,[1,2],[0,0],[2,1,0,3],[0,4,2,5]),8,8));await finish(r,report,row);live.delete(r);
 }
 if(!fault){
  await errorCleanup(rawGl,bridge,c,report);
  const s=specimen(),src=source(8,4,67,seed^0xa55a5aa5),r=rig(rawGl,bridge,c,s,{delay:4,step:1});r.blobs=report.blobs;r.add(meta(3,0,64,0,s.positions.length),s.positions);r.add(src.metadata,src.backing);const row={kind:'dispose-source-holds',originalSeed:(seed^0xa55a5aa5)>>>0,metadata:src.metadata,backing:await blob(report,src.backing),planes:[],observations:[]};for(const p of src.planes)row.planes.push({...p,input:await blob(report,p.input)});report.runs.push(row);live.set(r,row);c.ok((await submit(r,1,setup(s,src),'dispose-source-setup')).result,'source-disposal setup');r.currentLabel='dispose-store-at-image-fence';let point;
  const disposed=await submit(r,1,join(view(5,6,67,1,1),view(6,6,67,2,2),sampler(),bind(0,5),bind(1,6),draw()),r.currentLabel,async()=>{if(!point&&r.renderer.inspect().jobs.status==='finishing'){point={before:{renderer:r.renderer.inspect(),resources:r.store.inspect(),images:r.imageAccess.inspect()}};c.same(point.before.resources.budgets.imageHolds,3,'disposing owner has actual source and view holds');c.ok(r.store.dispose(),'dispose original image owner with live source holds');point.after=r.store.inspect();c.same(Object.values(point.after.budgets).every(n=>n===0),true,'disposed owner drains all original/private native charges');c.ok(r.renderer.dispose(),'dispose renderer after owner revocation');return{disposed:true,appliedCommands:point.before.renderer.jobs.appliedCommands};}});row.observations.push({point,disposed});c.same(Boolean(point),true,'pending native image/source ownership disposal point');await finish(r,report,row);live.delete(r);
 }
 report.status='passed';return report;
 }catch(error){report.failure={message:error.message,stack:error.stack};throw error;}finally{for(const[r,row]of live)await finish(r,report,row);}
}
