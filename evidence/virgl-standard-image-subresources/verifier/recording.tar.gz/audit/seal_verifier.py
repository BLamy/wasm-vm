from pathlib import Path,PurePosixPath
import gzip,hashlib,io,json,subprocess,tarfile
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');TMP=Path(__file__).resolve().parent;OUTPUT=ROOT/'evidence/virgl-standard-image-subresources/verifier';FINAL=ROOT/'target/evidence/virgl-standard-image-critic-final';sha=lambda b:hashlib.sha256(b).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=ROOT).strip()
v=json.loads((TMP/'verdict.json').read_text());assert v['verdict']=='verified'and v['promotedTestHead']==head
receipt=json.loads((FINAL/'receipt.json').read_text());assert receipt['status']=='passed'and receipt['gitHead']==head
for name,digest in receipt['files'].items():assert sha((FINAL/name).read_bytes())==digest
members={}
def add(name,raw):
 p=PurePosixPath(name);assert not p.is_absolute()and'..'not in p.parts and name not in members;members[name]=raw
for prefix,directory in [('fresh',FINAL),('recording-before-citation',ROOT/'target/evidence/virgl-standard-image-critic-before-citation-correction'),('recording-before-native-allocation',ROOT/'target/evidence/virgl-standard-image-critic-before-native-allocation-check')]+[(n,ROOT/'target/evidence'/n)for n in ['virgl-standard-image-critic-precheck','virgl-standard-image-critic-precheck2','virgl-standard-image-critic-precheck3','virgl-standard-image-critic-fault-precheck']]:
 for f in sorted(directory.rglob('*')):
  if f.is_file():add(prefix+'/'+f.relative_to(directory).as_posix(),f.read_bytes())
for f in sorted(TMP.glob('*')):
 if f.is_file():add('audit/'+f.name,f.read_bytes())
for f in sorted((TMP/'precheck-source-snapshots').glob('*.mjs')):add('audit/precheck-source-snapshots/'+f.name,f.read_bytes())
for name in ['audit_worker.py','worker-audit.json']:
 raw=(TMP/'fresh-boundaries'/name).read_bytes();add('audit/fresh-boundaries/'+name,raw)
# Record all complete loaded script/compiler/proof bodies at their actual frozen Git heads.
versions={v['workerAcceptanceHead']:set(json.loads((TMP/'worker/hot/receipt.json').read_text())['sources'])}
for record in json.loads((TMP/'fresh-authentication.json').read_text())['reports']:
 path=record['record'];group,path=path.split('/',1)
 directories={'fresh':FINAL,'recording-before-citation':ROOT/'target/evidence/virgl-standard-image-critic-before-citation-correction','recording-before-native-allocation':ROOT/'target/evidence/virgl-standard-image-critic-before-native-allocation-check'}
 directory=directories.get(group,ROOT/'target/evidence'/group);q=json.loads((directory/path).read_text());versions.setdefault(q['gitHead'],set()).update(r['path']for r in q['sources'])
for version,names in versions.items():
 for name in sorted(names):
  if '/build/'in name or name.startswith('evidence/'):continue
  try:raw=subprocess.check_output(['git','show',version+':'+name],cwd=ROOT,stderr=subprocess.DEVNULL)
  except subprocess.CalledProcessError:continue # Untracked exploratory module bodies are separately exact-digest snapshotted above.
  add('sources/'+version+'/'+name,raw)
for name,digest in receipt['sources'].items():assert sha(subprocess.check_output(['git','show',head+':'+name],cwd=ROOT))==digest
for name in ['renderer/virgl-shader/build/wasm/virgl-shader.mjs','renderer/virgl-shader/build/wasm/virgl-shader.wasm']:add('generated/'+name,(ROOT/name).read_bytes())
for name in ['AGENTS.md','tools/virgl-command/standard-image-boundary.json']:
 add('sources/'+head+'/'+name,subprocess.check_output(['git','show',head+':'+name],cwd=ROOT))if 'sources/'+head+'/'+name not in members else None
wm=(ROOT/'evidence/virgl-standard-image-subresources/worker/manifest.json').read_bytes();wi=(ROOT/'evidence/virgl-standard-image-subresources/worker/records.json').read_bytes();w=json.loads(wm)
add('worker-reference.json',(json.dumps(dict(workerManifest=json.loads(wm),workerManifestSha256=sha(wm),workerIndexSha256=sha(wi),workerArchiveSha256=w['archiveSha256'],exactReviewedSubmission=v['reviewedSubmission'],wholeMemberAuthentication='audit/authentication.json',referenceMapping='worker:hot|cold/... and coverage worker/hot|cold/... refer to exact members of authenticated ../worker/recording.tar.gz; fresh/... refers to this archive; audit:... refers to audit/...'),indent=2)+'\n').encode())
OUTPUT.mkdir(parents=True,exist_ok=True)
index=(json.dumps(dict(schema='original-image-critic-records-v1',task='E6-T11d21',sourceHead=head,records=[dict(path=name,bytes=len(raw),sha256=sha(raw))for name,raw in sorted(members.items())]),indent=2)+'\n').encode();(OUTPUT/'records.json').write_bytes(index)
archive=io.BytesIO()
with gzip.GzipFile(fileobj=archive,mode='wb',mtime=0)as compressed:
 with tarfile.open(fileobj=compressed,mode='w')as tar:
  for name,raw in sorted(members.items()):
   info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(raw))
raw=archive.getvalue();(OUTPUT/'recording.tar.gz').write_bytes(raw)
m=dict(schema='original-image-subresource-critic-seal-v1',task='E6-T11d21',role='fresh-adversarial-verifier',verdict='verified',predecessor=v['predecessor'],reviewedSubmission=v['reviewedSubmission'],workerAcceptanceHead=v['workerAcceptanceHead'],runtimeHead=v['frozenRuntimeHead'],promotedTestHead=head,records=len(members),uncompressedRecordBytes=sum(len(b)for b in members.values()),archiveBytes=len(raw),archiveSha256=sha(raw),recordIndexSha256=sha(index),verdictMember='audit/verdict.json',verdictSha256=sha(members['audit/verdict.json']),predictionsSha256=v['predictionsBeforeNativeEvidenceSha256'],numericPredictionsSha256=v['numericPredictionsBeforeFinalNativeExecutionSha256'],promotedReceiptSha256=sha((FINAL/'receipt.json').read_bytes()),workerArchiveSha256=w['archiveSha256'],workerRecordIndexSha256=sha(wi),workerManifestSha256=sha(wm),originalWorkerRecords=20366,inheritedD20WorkerRecords=10704,inheritedD20CriticRecords=12993,earlierUnchangedHeldSeals=10,healthyIndependentSeeds=[1779033703,3144134277,1013904242],healthyFreshDraws=183,healthyFreshFullPixels=8673,healthyFreshNativeTexels=9063,healthyFreshMainPhysicalFences=399,actualNativeErrorFences=6,finalWrongMipControlFences=5,originalDiffHunks=69,originalNestedRegions=594,originalNestedFunctions=134,productNestedRegions=270,productExecutedRegions=262,productHistoricalCarryRegions=7,productDefensiveWaivedRegions=1,promotionNestedRegions=183,promotionNestedFunctions=76,promotionDiffHunks=11,unusedTestHelperDeleted=True,needsEvidence=0,productChanges=False,guestExecution=False,productionNegotiation=False,productionDrawAuthority=False,completeApiAuthority=False,capsetAuthority=False,performanceClaim=False,deploymentClaim=False,authority=v['scope'],promotedSuite=v['promotedSuite'],coldProof=v['coldProof'],referenceMapping='worker:hot|cold/... or coverage worker/hot|cold/... identify unchanged worker archive members. fresh/... identifies final exact-head native captures in this archive. audit:... identifies audit/...; original coverage records fresh/... use same member names.',preservedFailures=v['preservedCriticFailures'])
(OUTPUT/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(dict(records=len(members),archiveBytes=len(raw),archiveSha256=m['archiveSha256'],recordIndexSha256=m['recordIndexSha256'],promotedTestHead=head)))
