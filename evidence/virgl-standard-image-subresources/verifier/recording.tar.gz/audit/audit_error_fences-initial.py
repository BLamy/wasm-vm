from pathlib import Path
import hashlib,json
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');TMP=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
points=[]
for seed in [1779033703,3144134277,1013904242]:
 path=ROOT/'target/evidence/virgl-standard-image-critic-final'/('seed-'+str(seed))/'report.json';q=json.loads(path.read_text());cleanup=q['browserResult']['result']['cleanup'];events=cleanup['events']
 for key,record in [('allocation',cleanup['allocation']['record']),('capture',cleanup['record'])]:
  assert record['result']['gpuComplete']and not record['result']['ok']and not record['result']['draws']and record['result']['appliedCommands']==0
  issued=[e for e in events if e['name']=='fenceSync'and e['label']==record['label']]
  waits=[e for e in events if e['name']=='clientWaitSync'and e['label']==record['label']and e['actual']in [37146,37148]and e['delivered']in [37146,37148]]
  assert issued and waits and all(any(f['sync']==w['sync']and w['turn']>f['turn']for f in issued)for w in waits)
  point=cleanup['allocation']['point']if key=='allocation'else cleanup['point'];assert point['images']['views']==point['images']['allocations']==0 and point['resources']['budgets']['gpuBytes']==172 and point['resources']['budgets']['leases']==0
  points.append(dict(path='fresh/final/seed-'+str(seed)+'/report.json',sha256=sha(path.read_bytes()),point='/browserResult/result/cleanup/'+('allocation/record'if key=='allocation'else'record'),nativeError=1281 if key=='allocation'else1280,issued=issued,completed=waits,result='HELD'))
 assert all(o['deleted']==1 for o in cleanup['nativeObjects'])and all(n==0 for n in cleanup['final']['resources']['budgets'].values())
out=dict(schema='fresh-native-image-error-fence-audit-v1',status='passed',completedPhysicalFences=6,points=points,actualNativeAllocationArguments=[3553,0,32856,4,2],actualNativeParameterArguments=[3553,4294967295,0],noDrawOrPublication=True,nativeNullAllocationControls='Original createTexture/createFramebuffer null seams prove refusal paths, not a physical OOM event')
(TMP/'error-fence-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status='passed',nativeErrorJobs=len(points),completedPhysicalFences=6)))
