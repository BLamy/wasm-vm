import math,struct,re,gzip,json,hashlib
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=Path('/tmp/wasm-vm-d24-critic')
sha=lambda b:hashlib.sha256(b).hexdigest();bits=lambda f:struct.unpack('<I',struct.pack('<f',f))[0];floating=lambda w:struct.unpack('<f',struct.pack('<I',w&0xffffffff))[0];signed=lambda w:w-(1<<32) if w&(1<<31) else w
shrink=lambda n,l:max(1,n>>l)
class Original:
 def __init__(self,run,blobs,frame):
  self.r,self.b,self.frame=run,blobs,frame;self.texels=0
  self.planes={p['level']:(p['width'],p['height'],blobs[p['input']['key']]) for p in run['planes']}
  if 'backing' in run:
   backing=blobs[run['backing']['key']]
   for p in run['planes']:
    raw=blobs[p['input']['key']]
    for y in range(p['height']):assert backing[p['offset']+y*p['stride']:p['offset']+y*p['stride']+p['width']*4]==raw[y*p['width']*4:(y+1)*p['width']*4]
  if frame.get('sourceClear'):
   p=frame['sourceClear'];w,h,_=self.planes[p['level']];raw=bytes(math.floor(n*255+.5) for n in p['values'])*(w*h);self.planes[p['level']]=(w,h,raw)
  self.ranges={run['slot']:run['range']} if 'slot' in run else {3:[0,3]}
  for v in run.get('views',[]):self.ranges[v['slot']]=[v['first'],v['last']]
  self.swizzles={k:run.get('swizzle',[0,1,2,3]) for k in self.ranges}
  for v in run.get('views',[]):self.swizzles[v['slot']]=v['swizzle']
  if 'positions' in run:assert struct.unpack('<24f',blobs[run['positions']['key']])==(-1.,-1.,0.,1.,1.,-1.,0.,1.,-1.,1.,0.,1.,-1.,1.,0.,1.,1.,-1.,0.,1.,1.,1.,0.,1.)
 def texel(self,slot,lod,x,y):
  first,last=self.ranges[slot];w,h,raw=self.planes[first+lod];assert 0<=x<w and 0<=y<h
  out=[]
  for i,b in enumerate(raw[(y*w+x)*4:(y*w+x)*4+4]):
   if self.r.get('kind')=='snorm':n=max(-1,(b-256 if b>=128 else b)/127)
   else:n=b/255
   if self.r.get('kind')=='srgb' and i<3:n=n/12.92 if n<=.04045 else ((n+.055)/1.055)**2.4
   out.append(n)
  return out
 def sample(self,slot,lod,u,v):
  first,last=self.ranges[slot];w,h,_=self.planes[first+lod];clamp=lambda n,m:max(0,min(m-1,n))
  if not self.r['parameters']['min']:return self.texel(slot,lod,clamp(math.floor(u*w),w),clamp(math.floor(v*h),h))
  px,py=u*w-.5,v*h-.5;ix,iy=math.floor(px),math.floor(py);fx,fy=px-ix,py-iy;output=[0]*4
  for dx,dy,weight in [(0,0,(1-fx)*(1-fy)),(1,0,fx*(1-fy)),(0,1,(1-fx)*fy),(1,1,fx*fy)]:
   sampled=self.texel(slot,lod,clamp(ix+dx,w),clamp(iy+dy,h));output=[a+weight*b for a,b in zip(output,sampled)]
  return output
 def program(self,text,inputs,x,y,constants=None):
  registers={('IN',i):v for i,v in inputs.items()};immediates={};constants=constants or {}
  for m in re.finditer(r'^IMM\[(\d+)\] (FLT32|INT32|UINT32) \{([^}]+)\}',text,re.M):
   vals=[float(v) if m[2]=='FLT32' else int(v) for v in m[3].split(',')];immediates[int(m[1])]=[bits(v) if m[2]=='FLT32' else v&0xffffffff for v in vals]
  def source(term,integer=False):
   negative=term.startswith('-');term=term.lstrip('-');absolute=term.startswith('|');term=term.strip('|')
   m=re.fullmatch(r'(IN|OUT|TEMP|IMM|ADDR)\[(\d+)\](?:\.([xyzw]+))?',term)
   if m:
    vals=immediates[int(m[2])] if m[1]=='IMM' else registers[(m[1],int(m[2]))];sw=m[3] or 'xyzw';sw=sw*4 if len(sw)==1 else sw;result=[vals['xyzw'.index(k)] for k in sw]
   else:
    m=re.fullmatch(r'CONST(?:\[(\d+)\])?\[(\d+)\](?:\.([xyzw]+))?',term);assert m,term
    slot=int(m[1] or 0);index=int(m[2]);sw=m[3] or 'xyzw';sw=sw*4 if len(sw)==1 else sw;result=[constants[slot][index*4+'xyzw'.index(k)] for k in sw]
   if absolute:result=[bits(abs(floating(v))) for v in result]
   if negative:result=[(-signed(v))&0xffffffff if integer else bits(-floating(v)) for v in result]
   return result
  for _,op,operands in re.findall(r'^(\d+): (\w+)\s*([^\n]*)',text,re.M):
   if op=='END':continue
   terms=[s.strip() for s in operands.split(',')];dest=terms[0];m=re.fullmatch(r'(TEMP|OUT|ADDR)\[(\d+)\](?:\.([xyzw]+))?',dest);assert m,(op,dest);mask=m[3] or 'xyzw';key=(m[1],int(m[2]));old=registers.setdefault(key,[None]*4)
   if op in ['TXQ','TXF','TEX','TXL','TXD','TXB']:
    assert terms[-1]=='2D';slot=int(re.fullmatch(r'SAMP\[(\d+)\]',terms[-2])[1]);first,last=self.ranges[slot];levels=last-first+1;w,h,_=self.planes[first]
    vec=source(terms[1],op in ['TXQ','TXF'])
    if op=='TXQ':lod=signed(vec[0]);assert 0<=lod<levels;result=[shrink(w,lod),shrink(h,lod),None,levels]
    elif op=='TXF':ix,iy,_,lod=map(signed,vec);result=list(map(bits,self.texel(slot,lod,ix,iy)))
    else:
     u,v,_,lod=map(floating,vec)
     if op=='TEX':lod=0
     elif op=='TXD':dx=list(map(floating,source(terms[2])));dy=list(map(floating,source(terms[3])));lod=math.log2(max(math.hypot(dx[0]*w,dx[1]*h),math.hypot(dy[0]*w,dy[1]*h)))
     elif op=='TXB':lod=math.log2(max(w/8,h/8))+lod
     result=list(map(bits,self.sample(slot,max(0,min(levels-1,math.floor(lod+.5))),u,v)))
    if op!='TXQ':result=[bits(0) if k==4 else bits(1) if k==5 else result[k] for k in self.swizzles[slot]]
   elif op=='MOV':result=source(terms[1])
   elif op=='U2F':result=[bits(v) for v in source(terms[1])]
   elif op=='UADD':a,b=source(terms[1]),source(terms[2]);result=[(a+b)&0xffffffff for a,b in zip(a,b)]
   elif op=='USHR':a,b=source(terms[1]),source(terms[2]);result=[a>>(b&31) for a,b in zip(a,b)]
   elif op=='AND':a,b=source(terms[1]),source(terms[2]);result=[a&b for a,b in zip(a,b)]
   elif op in ['MUL','MAD']:
    a,b=list(map(floating,source(terms[1]))),list(map(floating,source(terms[2])));add=list(map(floating,source(terms[3]))) if op=='MAD' else [0]*4;result=[bits(a*b+c) for a,b,c in zip(a,b,add)]
   else:raise AssertionError('unhandled original operation '+op)
   for k in mask:old['xyzw'.index(k)]=result['xyzw'.index(k)]
  return {i:v for (kind,i),v in registers.items() if kind=='OUT'}
 def ordinary(self,x,y):
  coords=struct.unpack('<24f',self.b[self.r['coordinates']['key']]);bias=coords[3];vertex=self.program(self.r['vertex'],{0:list(map(bits,[-1,-1,0,1])),1:list(map(bits,[(x+.5)/8,(y+.5)/8,0,bias]))},x,y)
  incoming={0:vertex[1]} if 1 in vertex else {}
  output=self.program(self.r['fragment'],incoming,x,y)[0];return [max(0,min(255,math.floor(floating(w)*255+.5))) for w in output]

def blobs(base,result):
 out={}
 for row in result['blobs']:
  packed=(base/row['path']).read_bytes();assert sha(packed)==row['gzipSha256'];raw=gzip.decompress(packed);assert sha(raw)==row['sha256'] and len(raw)==row['bytes'];out[row['key']]=raw
 return out

def composition(run,frame,raw):
 data={r['id']:raw[r['bytes']['key']] for r in run['data']};constants={};native=next(d for d in run['draws'] if d['label']==frame['label'])
 for bank in run['banks']:
  full=data[bank['id']];constants[bank['slot']]=list(struct.unpack_from('<'+str(bank['count']*4)+'I',full,bank['offset']))
  assert constants[bank['slot']]==bank['words']
  for block in [b for b in native['blocks'] if b['name'] in ['VirglVSConst'+str(bank['slot']),'VirglFSConst'+str(bank['slot'])]]:assert raw[block['bytes']['key']]==full and block['start']==bank['offset'] and block['length']==bank['length']
 for r in run['rawBufferReads']:assert raw[r['bytes']['key']]==data[r['id']]
 assert {r['id'] for r in run['rawBufferReads']}==set(data)
 extra=data[4];a={0:list(struct.unpack_from('<4I',data[3])),1:list(struct.unpack_from('<4I',extra,0)),2:list(struct.unpack_from('<4I',extra,16))}
 for index,offset,normalized in [(3,32,False),(4,36,True)]:
  word=struct.unpack_from('<I',extra,offset)[0];v=[]
  for k in range(4):
   size=2 if k==3 else 10;n=(word>>(10*k))&((1<<size)-1);n=n-(1<<size) if n&(1<<(size-1)) else n;v.append(bits(max(-1,n/((1<<(size-1))-1)) if normalized else n))
  a[index]=v
 for attr in native['attributes']:
  if attr['bytes']:assert raw[attr['bytes']['key']] in data.values()
 model=Original(run,raw,frame);vs=model.program(run['vertex'],a,0,0,constants);fs=model.program(run['fragment'],{0:vs[1]},0,0,constants)[0];expected=bytes(max(0,min(255,math.floor(floating(w)*255+.5))) for w in fs)*256;actual=raw[frame['pixels']['key']];assert actual==expected
 assert native['queries']==[dict(name='fssamplevels3',type=5124,size=1,value=4)]
 return {'pixels':256,'texels':0,'held':True,'originalOpcodeInterpreter':True}

rows=[];faults=[];reports=[]
for role,directory in [('hot',ROOT/'target/evidence/virgl-standard-texture-operations-final-complete'),('cold',ROOT/'target/evidence/virgl-standard-texture-operations-cold-final/acceptance')]:
 for base in sorted(directory.glob('hardware-*'))+sorted(directory.glob('fault-*')):
  report=json.loads((base/'report.json').read_text());fault=base.name.startswith('fault-');result=report['partial'] if fault else report['browserResult']['result'];raw=blobs(base,result);before=len(rows)
  frames=list(result['frames'])
  for ri,run in enumerate(result['runs']):
   if 'retiredExpected' in run:
    draw=run['draws'][-1];p=next(p for p in run['retiredPlanes'] if p['texture']==draw['native']['attachment']);assert p['fencePoint']['actual'] in [37146,37148] and p['fencePoint']['delivered'] in [37146,37148]
    hi=next(i for i,r in enumerate(run['history']) if r['label']==draw['label']);frames.append(dict(run=ri,label=draw['label'],historyIndex=hi,pixels=p['pixels'],retired=True))
  for fi,f in enumerate(frames):
   r=result['runs'][f['run']]
   if r.get('kind')=='query-uniform-vertex-composition':point=composition(r,f,raw)
   else:
    model=Original(r,raw,f);actual=raw[f['pixels']['key']];assert len(actual)==256;mismatches=[];texels=0
    for b in f.get('bindings',[]):
     for p in b['planes']:
      original=raw[r['planes'][p['original']]['input']['key']];native=raw[p['native']['key']];assert len(original)==len(native)
      norm=lambda n:max(-1,(n-256 if n>=128 else n)/127)
      assert native==original or r['kind']=='snorm' and all(norm(a)==norm(b) for a,b in zip(original,native));texels+=p['width']*p['height']
    for y in range(8):
     for x in range(8):
      color=model.ordinary(x,y)
      for lane,n in enumerate(color):
       v=actual[(y*8+x)*4+lane]
       if abs(v-n)>2 and len(mismatches)<8:mismatches.append(dict(x=x,y=y,lane=lane,predicted=n,observed=v))
    point=dict(pixels=64,texels=texels,held=not mismatches,mismatches=mismatches,originalOpcodeInterpreter=True)
    native=next(d for d in r['draws'] if d['label']==f['label'])
    for q in native['queries']:
     slot=int(re.search(r'(\d+)$',q['name'])[1]);first,last=model.ranges[slot];assert q['type']==5124 and q['size']==1
     if not fault:assert q['value']==last-first+1
   hist=r['history'][f['historyIndex']];assert hist['result']['ok'] or f.get('retired') and hist['result']['error']['code']=='cancelled'
   events=[e for e in r['events'] if e.get('label')==f['label']];assert any(e['name']=='clientWaitSync' and e['actual'] in [37146,37148] and e['delivered'] in [37146,37148] for e in events)
   point.update(role=role,record=base.name,run=f['run'],frame=fi,label=f['label'],retired=f.get('retired',False))
   if fault:assert not point['held'];faults.append(point)
   else:assert point['held'],point;rows.append(point)
  reports.append(dict(role=role,record=base.name,sha256=sha((base/'report.json').read_bytes()),healthyFrames=len(rows)-before))
 assert sum(r['pixels'] for r in rows if r['role']==role)==143744 and sum(r['texels'] for r in rows if r['role']==role)==300488
assert len(faults)==6
summary=dict(status='passed',workerOracleImported=False,opcodeInterpreter=True,pixels=sum(r['pixels'] for r in rows),nativeTexels=sum(r['texels'] for r in rows),rows=rows,controls=faults,reports=reports)
(OUT/'worker-pixel-audit.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ['rows','controls','reports']}))
