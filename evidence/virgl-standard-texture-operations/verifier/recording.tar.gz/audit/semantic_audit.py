from pathlib import Path
import json,hashlib
R=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');O=Path('/tmp/wasm-vm-d24-critic');rows=[];controls=[]
for role,base in [('hot',R/'target/evidence/virgl-standard-texture-operations-final-complete'),('cold',R/'target/evidence/virgl-standard-texture-operations-cold-final/acceptance')]:
 wire=json.loads((base/'wire/report.json').read_text())['wire'];assert len(wire['records'])==34 and len(wire['predictions'])==49 and all(r['held'] for r in wire['predictions']);assert all(r.get('getters',0)==0 for r in wire['records']);assert all(r['result']['ok']==False for r in wire['records'])
 matrix=json.loads((base/'hardware-matrix/report.json').read_text())['browserResult']['result'];assert len(matrix['runs'])==970 and len(matrix['frames'])==1940
 assert {r['opcode'] for r in matrix['runs']}=={'TEX','TXL','TXF','TXD','TXB','TXQ'};assert {r['slot'] for r in matrix['runs']}=={0,3,15}
 for i,run in enumerate(matrix['runs']):
  assert run['cache'][1]['snapshot']['work']['programLinks']==run['cache'][0]['snapshot']['work']['programLinks']
  for pair in run['requests']:
   assert pair['request']['vertexText']==run['vertex'] and pair['request']['fragmentText']==run['fragment'];assert pair['result']['ok']
  if run['source']['lastLevel']==14:assert run['source']['width']==16384 and run['source']['height']==1 and all(q['value']==15 for d in run['draws'] for q in d['queries'])
  if run.get('queryLevelCounts'):assert {q['name']:q['value'] for q in run['draws'][-1]['queries']}=={'fssamplevels3':4,'fssamplevels15':3}
 for seed in ['0xa5471e03','0x13579bdf','0x9e3779b9']:
  path=base/('hardware-boundaries-'+seed)/'report.json';data=json.loads(path.read_text())['browserResult']['result'];assert data['seed']==int(seed,16) and len(data['frames'])==50
  faults=set();reuse=0;queued=0;gpu_clear=0
  for i,run in enumerate(data['runs']):
   if run.get('nativeFault'):
    faults.add(run['nativeFault']);assert run['faultEvents'] and not run['draws'];h=run['history'][-1];assert not h['result']['ok'] and h['result']['error']['code']==('backend-error' if run['nativeFault']=='query-write' else 'shader-reflection-error');rows.append(dict(role=role,seed=seed,run=i,kind='native-query-refusal',fault=run['nativeFault'],history=len(run['history'])-1,events=run['faultEvents']))
   for j,a in enumerate(run['actions']):
    if a.get('kind')=='unequal-source-ID-reuse':
     reuse+=1;s=a['inspection'];old=next(r for r in s['resources'] if r['id']==6 and not r['public']);new=next(r for r in s['resources'] if r['id']==6 and r['public']);assert (old['width'],old['height'],old['lastLevel'])==(17,9,3);assert (new['width'],new['height'],new['lastLevel'])==(11,7,1);assert new['generation']>old['generation']==run['sourceGeneration']
     resource_bytes=sum(r['width'] if r['target']==0 else sum(max(1,r['width']>>l)*max(1,r['height']>>l)*4 for l in range(r['lastLevel']+1)) for r in s['resources']);assert resource_bytes==sum(r['byteLength'] for r in s['resources']);assert s['budgets']['imageViews']==2 and s['budgets']['imageHolds']==0
     view_bytes=2*(8*4+4*2+2*1)*4;assert s['budgets']['gpuBytes']==resource_bytes+view_bytes==1932 and a['oldBudget']==1932-368
     for d in run['draws']:
      if 'reuse' in d['label'] or 'restored' in d['label']:
       for q in d['queries']:assert q['value']==3
     rows.append(dict(role=role,seed=seed,run=i,action=j,kind=a['kind'],nativeBytes=1932,oldOriginalBytes=780,newOriginalBytes=368,viewBytes=view_bytes,oldGeneration=old['generation'],newGeneration=new['generation']))
    elif a.get('kind')=='owned-final-fence-reuse':
     queued+=1;b,c=a['before'],a['after'];assert a['renderer']['jobs']['status']=='finishing' and b['budgets']['imageHolds']==2
     assert {r['id'] for r in b['resources'] if not r['public']}=={1,6};assert c['budgets']['gpuBytes']-b['budgets']['gpuBytes']==368+108
     assert b['budgets']['gpuBytes']==256+96+96+780+168==1396 and c['budgets']['gpuBytes']==1872
     old_src=next(r for r in c['resources'] if r['id']==6 and not r['public']);new_src=next(r for r in c['resources'] if r['id']==6 and r['public']);old_target=next(r for r in c['resources'] if r['id']==1 and not r['public']);new_target=next(r for r in c['resources'] if r['id']==1 and r['public']);assert old_src['generation']!=new_src['generation'] and old_target['generation']!=new_target['generation']
     rows.append(dict(role=role,seed=seed,run=i,action=j,kind=a['kind'],beforeBytes=1396,afterBytes=1872,sourceHold=old_src['generation'],outputHold=old_target['generation'],originalQueryLevels=3))
    elif a.get('kind')=='gpu-only-plane':
     gpu_clear+=1;assert a['level']==2 and a['values']==[.125,.375,.625,.875];refusal=run['actions'][-1];assert not refusal['result']['ok'] and refusal['result']['error']['code']=='framebuffer-feedback'
     rows.append(dict(role=role,seed=seed,run=i,action=j,kind=a['kind'],level=2,feedbackHistory=len(run['history'])-1))
  assert faults=={'query-type','query-size','query-location','query-budget','query-write'} and reuse==4 and queued==8 and gpu_clear==1
 for kind in ['upload-channel','query-levels','mip-state']:
  path=base/('fault-'+kind)/'report.json';r=json.loads(path.read_text());a=r['partial'];run=a['runs'][0];frame=a['frames'][0];h=run['history'][frame['historyIndex']];assert h['result']['ok'] and h['result']['gpuComplete'] and not a['sabotage']['held'];event=next((e for e in run['events'] if e.get('label')==frame['label'] and e['name']=='clientWaitSync' and e['actual'] in [37146,37148] and e['delivered'] in [37146,37148]));assert run['faultEvents'];controls.append(dict(role=role,kind=kind,record=str(path.relative_to(base)),reportSha256=hashlib.sha256(path.read_bytes()).hexdigest(),events=run['faultEvents'],completedFence=event,pixelMismatch=a['sabotage']['miss']))
r=dict(status='passed',metadataRecordsPerRun=34,metadataPredictionsPerRun=49,matrixCasesPerRun=970,matrixFramesPerRun=1940,rows=rows,controls=controls)
(O/'semantic-audit.json').write_text(json.dumps(r,indent=2)+'\n');print('Independent generation/budget/failure audit',len(rows),'points',len(controls),'native controls')
