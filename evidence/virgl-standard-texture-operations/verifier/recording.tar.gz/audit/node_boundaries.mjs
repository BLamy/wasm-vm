import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import { createVirglStandardTextureShaderBridge } from '/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm/renderer/virgl-shader/standard.mjs';
import { parseStandardTextureShaderMetadata, normalizeStandardTextureShaderResult, normalizeStandardTextureShaderPair, deriveStandardTextureShaderInterface, parseStandardUniformShaderMetadata } from '/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm/renderer/virgl-command/constant-domain.mjs';
import { specimen } from '/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm/renderer/virgl-command/tests/standard-texture-operations-adversarial.mjs';
const bridge=await createVirglStandardTextureShaderBridge(),s=specimen('fragment',0x73195cab,[1,5,0,2]),selectors={signedMask:0,unsignedMask:0,packedSignedMask:0,packedNormalizedMask:0,bufferZeroMask:0};
const pair=bridge.translatePairUniforms({vertexText:s.vertex,fragmentText:s.fragment,...selectors}),single=bridge.translate({stage:'fragment',text:s.fragment});assert.equal(pair.ok,true);assert.equal(single.ok,true);
const rows=[];
for(const mode of ['index-accessor','extra-field','inherited-query-name']){
 const original=structuredClone(pair);let getters=0;
 if(mode==='index-accessor')Object.defineProperty(original.fragment.metadata.textureQueries,'0',{get(){getters++;throw Error('getter executed');},enumerable:true});
 if(mode==='extra-field')original.fragment.metadata.textureQueries.extra=1;
 if(mode==='inherited-query-name'){const q=original.fragment.metadata.textureQueries[0],name=q.name;delete q.name;Object.setPrototypeOf(q,{get name(){getters++;return name}});}
 const result=normalizeStandardTextureShaderPair(original,selectors);assert.equal(result.ok,false);assert.equal(getters,0);rows.push({mode,result,getters,held:true});
}
const freeze=Object.freeze;
for(const [method,invoke] of [['parse',()=>parseStandardTextureShaderMetadata(single.metadata,'fragment')],['stage',()=>normalizeStandardTextureShaderResult(single,'fragment')],['pair',()=>normalizeStandardTextureShaderPair(pair,selectors)],['interface',()=>deriveStandardTextureShaderInterface(pair.vertex.metadata,pair.fragment.metadata,selectors)]]){
 const sentinel=new Error('real trusted host freeze failure '+method);let calls=0,observed;
 Object.freeze=value=>{if(value?.profile==='virgl-webgl2-standard-texture-gles3-v1'){calls++;throw sentinel;}return freeze(value);};
 try{invoke();}catch(error){observed=error;}finally{Object.freeze=freeze;}
 assert.equal(observed,sentinel);assert.equal(calls,1);rows.push({method,unexpectedHostError:observed.message,calls,held:true});
}
assert.equal(parseStandardUniformShaderMetadata(single.metadata,'fragment').ok,false);
await fs.writeFile('/tmp/wasm-vm-d24-critic/node-boundaries.json',JSON.stringify({status:'passed',original:{vertex:s.vertex,fragment:s.fragment,selectors,pair,single},predictions:rows},null,2)+'\n');console.log('Independent metadata ownership and four fatal-host fail-stop paths passed');
