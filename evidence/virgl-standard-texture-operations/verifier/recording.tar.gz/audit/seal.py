import hashlib,io,gzip,json,subprocess,tarfile
from pathlib import Path
R=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');O=Path('/tmp/wasm-vm-d24-critic');P=R/'target/evidence/virgl-standard-texture-operations-verifier/promoted';DEST=R/'evidence/virgl-standard-texture-operations/verifier';sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *args:subprocess.check_output(['git',*args],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert not git('diff','--name-only','HEAD').strip();frozen='765e9d967258e44def61b65e595bcfd92b192367';members={}
for file in sorted(O.rglob('*')):
 if file.is_file() and '__pycache__' not in file.parts:members['audit/'+file.relative_to(O).as_posix()]=file.read_bytes()
for file in sorted(P.rglob('*')):
 if file.is_file():members['promoted/'+file.relative_to(P).as_posix()]=file.read_bytes()
source_records={}
for file in sorted(P.glob('*/report.json')):
 capture=json.loads(file.read_text());assert capture['gitHead']==head
 for s in capture['sources']:
  data=(R/s['path']).read_bytes();assert sha(data)==s['sha256'] and len(data)==s['bytes']
  if '/build/' not in s['path']:assert data==git('show',head+':'+s['path'])
  key='source/'+s['path'];assert key not in members or members[key]==data;members[key]=data;source_records[s['path']]=sha(data)
 for s in capture['servedFiles']:
  if s['path']!='/':assert source_records[s['path'][1:]]==s['sha256']
 assert capture['browserErrors']==dict(console=[],page=[],requests=[])
for n in ['Makefile','tools/verify-virgl-standard-texture-operations-adversarial.sh','tools/virgl-command/standard-texture-operations-adversarial-pixels.py']:
 data=(R/n).read_bytes();assert data==git('show',head+':'+n);members['source/'+n]=data;source_records[n]=sha(data)
for n in ['renderer/virgl-command/state.mjs','renderer/virgl-command/resources.mjs','renderer/virgl-command/constant-domain.mjs']:
 assert (R/n).read_bytes()==git('show',frozen+':'+n)
boundary=dict(status='passed',sourceHead=head,frozenRuntimeHead=frozen,productionRuntimeUnchanged=True,sourceDigests=source_records,changesSinceFrozen=git('diff','--name-only',frozen,head).decode().splitlines(),coldCarried=True,workerArchiveSha256='f6be8a4330a501c058b539c0e0706ddf1e4d929dc518df7dd1cc49ab91326c81')
(O/'current-boundary.json').write_text(json.dumps(boundary,indent=2)+'\n');members['audit/current-boundary.json']=(O/'current-boundary.json').read_bytes()
predictions=json.loads((O/'predictions-before-evidence.json').read_text())
citations={'P1_custody':'audit/authentication.json#/archives,closures,captures','P2_own_contract':'audit/semantic-audit.json; audit/node-boundaries.json','P3_native_overloads':'audit/worker-pixel-audit.json#/rows','P4_original_queries':'audit/worker-pixel-audit.json#/rows; audit/semantic-audit.json','P5_native_planes':'audit/authentication.json#/captures; audit/worker-pixel-audit.json#/rows','P6_generations':'audit/semantic-audit.json#/rows; promoted/independent-pixels.json#/rows','P7_gpu_refresh':'audit/semantic-audit.json#/rows; audit/worker-pixel-audit.json#/rows','P8_cache':'audit/semantic-audit.json; promoted/independent-pixels.json#/rows','P9_composition':'audit/worker-pixel-audit.json#/rows; audit/audit_worker_pixels.py#composition','P10_native_errors':'audit/semantic-audit.json#/rows; audit/authentication.json#/captures','P11_controls':'audit/semantic-audit.json#/controls; audit/worker-pixel-audit.json#/controls','P12_nested_coverage':'audit/coverage-partition.json#/partitions; audit/harness-coverage.json','P13_cold_carry':'audit/authentication.json#/cold,inverse,archives; audit/current-boundary.json','P14_novel':'promoted/independent-pixels.json#/rows,controls; promoted/fault-query-levels/report.json#/partial/frames/0'}
for p in predictions['predictions']:p['result']='HELD';p['citation']=citations[p['id']]
predictions['verdict']='verified';(O/'predictions-verdict.json').write_text(json.dumps(predictions,indent=2)+'\n');members['audit/predictions-verdict.json']=(O/'predictions-verdict.json').read_bytes()
index=(json.dumps(dict(schema='d24-independent-verifier-records-v1',task='E6-T11d24',sourceHead=head,frozenRuntimeHead=frozen,records=[dict(path=n,bytes=len(b),sha256=sha(b)) for n,b in sorted(members.items())]),indent=2)+'\n').encode();DEST.mkdir(parents=True,exist_ok=True);(DEST/'records.json').write_bytes(index)
stream=io.BytesIO()
with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0) as gz:
 with tarfile.open(fileobj=gz,mode='w') as tar:
  for n,b in sorted(members.items()):
   info=tarfile.TarInfo(n);info.size=len(b);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(b))
archive=stream.getvalue();(DEST/'recording.tar.gz').write_bytes(archive)
manifest=dict(schema='d24-independent-verifier-seal-v1',task='E6-T11d24',sourceHead=head,frozenRuntimeHead=frozen,records=len(members),unpackedBytes=sum(map(len,members.values())),archiveBytes=len(archive),archiveSha256=sha(archive),recordIndexSha256=sha(index),workerArchiveSha256='f6be8a4330a501c058b539c0e0706ddf1e4d929dc518df7dd1cc49ab91326c81',guestExecution=False,productionNegotiation=False,authority='isolated-original-texture-operations',productionDrawAuthority=False)
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
seen=set();idx=json.loads(index);expected={x['path']:x for x in idx['records']}
with tarfile.open(DEST/'recording.tar.gz','r|gz') as tar:
 for m in tar:
  assert m.isfile() and m.name not in seen and m.name in expected;b=tar.extractfile(m).read();entry=expected[m.name];assert len(b)==entry['bytes'] and sha(b)==entry['sha256'];seen.add(m.name)
assert seen==set(members);assert sha((DEST/'recording.tar.gz').read_bytes())==manifest['archiveSha256'];print(json.dumps(manifest,indent=2))
