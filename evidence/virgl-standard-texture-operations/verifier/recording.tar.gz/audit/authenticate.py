#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,subprocess,sys,time
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
OUT=Path('/tmp/wasm-vm-d24-critic');FROZEN='765e9d967258e44def61b65e595bcfd92b192367';BASE='71853cd302a2a39cd8f5af001fd8ad1b791b7da6'
sha=lambda x:hashlib.sha256(x).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
read=lambda p:json.loads(p.read_text())
report={'schema':'d24-independent-custody-v1','status':'running','frozen':FROZEN,'currentHead':git('rev-parse','HEAD').decode().strip(),'archives':[],'closures':[],'captures':[]}
def seal(prefix,expected_archive=None,expected_index=None):
 d=ROOT/prefix;mf=read(d/'manifest.json');ir=(d/'records.json').read_bytes();idx=json.loads(ir);raw=(d/'recording.tar.gz').read_bytes()
 assert sha(raw)==mf['archiveSha256'] and len(raw)==mf.get('archiveBytes',len(raw));assert sha(ir)==mf['recordIndexSha256']
 if expected_archive:assert sha(raw)==expected_archive
 if expected_index:assert sha(ir)==expected_index
 entries={r['path']:r for r in idx['records']};assert len(entries)==len(idx['records']);seen=set();total=0
 with tarfile.open(d/'recording.tar.gz','r|gz') as tar:
  for m in tar:
   pp=PurePosixPath(m.name);assert not pp.is_absolute() and '..' not in pp.parts and m.isfile() and m.name in entries and m.name not in seen
   body=tar.extractfile(m).read();e=entries[m.name];assert len(body)==e['bytes'] and sha(body)==e['sha256'],m.name
   seen.add(m.name);total+=len(body)
 assert seen==set(entries) and len(seen)==mf['records'];r={'prefix':prefix,'members':len(seen),'unpackedBytes':total,'archiveSha256':sha(raw),'indexSha256':sha(ir),'manifestSha256':sha((d/'manifest.json').read_bytes())};report['archives'].append(r);print('Authenticated',prefix,len(seen),'members',flush=True);return mf,entries
worker,entries=seal('evidence/virgl-standard-texture-operations/worker','f6be8a4330a501c058b539c0e0706ddf1e4d929dc518df7dd1cc49ab91326c81','16aec9971cee75c0ac705ec38cced2d79f95d2c0e9d19f0413ab73146b155514')
assert worker['sourceHead']==FROZEN and worker['records']==102566
hot=ROOT/'target/evidence/virgl-standard-texture-operations-final-complete';cold=ROOT/'target/evidence/virgl-standard-texture-operations-cold-final'
for role,directory in [('hot',hot),('cold',cold/'acceptance')]:
 rc=read(directory/'receipt.json');assert rc['status']=='passed' and rc['gitHead']==FROZEN and rc['authority']=='isolated-original-texture-operations' and rc['productionDrawAuthority'] is False
 assert sha((directory/'receipt.json').read_bytes())==worker[role+'ReceiptSha256'];assert entries[role+'/receipt.json']['sha256']==sha((directory/'receipt.json').read_bytes())
 for n,digest in rc['files'].items():
  raw=(directory/n).read_bytes()
  if sha(raw)!=digest:
   suffix=b'Frozen original texture operations, retained image queries and full native evidence authenticated.\n';assert n=='acceptance.log' and raw.endswith(suffix) and sha(raw[:-len(suffix)])==digest
  assert entries[role+'/'+n]['sha256']==digest
 for n,digest in rc['sources'].items():
  original=git('show',FROZEN+':'+n);assert sha(original)==digest,(role,n)
  if n!='tasks/epic-6-transcendence/E6-T11d24-standard-texture-consumer.md':assert sha((ROOT/n).read_bytes())==digest,n
 binary_root=ROOT if role=='hot' else Path(read(cold/'report.json')['clone'])
 for n,digest in rc['generated'].items():assert sha((binary_root/n).read_bytes())==digest==entries[role+'-generated/'+n]['sha256']
 report['closures'].append(dict(role=role,receiptSha256=sha((directory/'receipt.json').read_bytes()),sourceFiles=len(rc['sources']),generated=rc['generated'],allRecordedFiles=len(rc['files'])))
 for base in sorted(directory.glob('hardware-*'))+sorted(directory.glob('fault-*')):
  capture=read(base/'report.json');bad=base.name.startswith('fault-');assert capture['gitHead']==FROZEN and capture['status']==('failed' if bad else 'passed')
  assert capture['browserErrors']=={'console':[],'page':[],'requests':[]} and capture['browser']['headless'] is False
  assert not any(any(w in a.lower() for w in ['swiftshader','llvmpipe','softpipe','lavapipe']) or a.startswith('--disable-gpu') for a in capture['browser']['commandLine'])
  result=capture['partial'] if bad else capture['browserResult']['result'];assert 'Metal' in result['gpu'] and 'M4' in result['gpu'];assert result['guestExecution'] is False and result['productionNegotiation'] is False
  served={e['path']:e for e in capture['servedFiles']};sources={e['path']:e for e in capture['sources']}
  for n,e in sources.items():assert sha(git('show',FROZEN+':'+n) if '/build/' not in n else (binary_root/n).read_bytes())==e['sha256']
  for n,e in served.items():
   if n!='/':assert n[1:] in sources and e['sha256']==sources[n[1:]]['sha256'] and e['bytes']==sources[n[1:]]['bytes']
  for k in ['screenshot','browserCoverage']:
   v=capture[k];assert sha((base/v['path']).read_bytes())==v['sha256']
  full=read(base/capture['browserCoverage']['path']);assert {'renderer/virgl-command/state.mjs','renderer/virgl-command/resources.mjs','renderer/virgl-command/constant-domain.mjs'}<={r['source'] for r in full['scripts']}
  for script in full['scripts']:assert script['sha256']==served['/'+script['source']]['sha256']
  blobseen=set();expanded=0
  for b in result['blobs']:
   assert b['key'] not in blobseen;blobseen.add(b['key']);packed=(base/b['path']).read_bytes();assert sha(packed)==b['gzipSha256'];plane=gzip.decompress(packed);assert len(plane)==b['bytes'] and sha(plane)==b['sha256'];expanded+=len(plane)
  terminal=0;draws=0;fences=0
  for run in result['runs']:
   assert all(v==0 for v in run['final']['renderer']['budgets'].values()) and all(v==0 for v in run['final']['resources']['budgets'].values())
   assert all(o['deleted']==1 for o in run['nativeObjects']);terminal+=len(run['nativeObjects']);draws+=len(run['draws'])
   syncs={};finished=set()
   for event in run['events']:
    if event['name']=='fenceSync':assert event['sync'] not in syncs;syncs[event['sync']]=event
    elif event['name']=='clientWaitSync':
     assert event['sync'] in syncs and event['turn']>syncs[event['sync']]['turn'];assert event['actual'] in [37146,37147,37148] and event['delivered'] in [37146,37147,37148]
     if event['delivered'] in [37146,37148]:assert event['actual'] in [37146,37148];finished.add(event['sync']);fences+=1
    elif event['name']=='deleteSync':assert event['sync'] in syncs;del syncs[event['sync']]
   assert not syncs
   for frame in [f for f in result['frames'] if result['runs'][f['run']] is run]:
    record=run['history'][frame['historyIndex']];assert record['label']==frame['label'] and record['result']['ok'] and record['result']['gpuComplete']
    events=[e for e in run['events'] if e.get('label')==frame['label']];assert any(e['name']=='clientWaitSync' and e['actual'] in [37146,37148] and e['delivered'] in [37146,37148] for e in events)
  if bad:assert result['sabotage']['fenceCompleted'] and not result['sabotage']['held'] and any(r['faultEvents'] for r in result['runs'])
  else:assert all(p['held'] for p in result['predictions'])
  report['captures'].append(dict(role=role,path=base.name,sha256=sha((base/'report.json').read_bytes()),runs=len(result['runs']),frames=len(result['frames']),blobs=len(blobseen),blobBytes=expanded,draws=draws,completedFencePolls=fences,retiredObjects=terminal,scripts=len(full['scripts'])))
cr=read(cold/'report.json');assert cr['status']=='passed' and cr['gitHead']==cr['cloneHead']==FROZEN and cr['statusBefore']==cr['statusAfter']=='' and cr['exitCode']==0
assert sha((cold/'report.json').read_bytes())==worker['coldReportSha256'] and sha((cold/'cold.log').read_bytes())==cr['logSha256'];clone=Path(cr['clone']);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==FROZEN;assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=clone,text=True)
report['cold']={**cr,'reportSha256':sha((cold/'report.json').read_bytes()),'carried':True}
for family in ['virgl-standard-byte-color-images','virgl-standard-texture']:
 for role in ['worker','verifier']:
  prefix='evidence/'+family+'/'+role;mf,idx=seal(prefix)
  for n in ['manifest.json','records.json','recording.tar.gz']:assert (ROOT/prefix/n).read_bytes()==git('show',BASE+':'+prefix+'/'+n)
inv=read(ROOT/'tools/virgl-command/standard-texture-operations-boundary.json');inverse=[]
for n,rs in inv['changes'].items():
 text=(ROOT/n).read_text()
 for r in reversed(rs):assert text.count(r['after'])==1;text=text.replace(r['after'],r['before'],1)
 original=git('show',BASE+':'+n);assert text.encode()==original;inverse.append(dict(source=n,migrations=len(rs),predecessorSHA256=sha(original),currentSHA256=sha((ROOT/n).read_bytes())))
assert set(inv['changes'])=={'renderer/virgl-command/constant-domain.mjs','renderer/virgl-command/resources.mjs','renderer/virgl-command/state.mjs'}
for n in ['renderer/virgl-command/cache.mjs','renderer/virgl-command/decoder.mjs','renderer/virgl-command/color-images.mjs']:assert (ROOT/n).read_bytes()==git('show',BASE+':'+n)
assert not git('diff','--name-only',BASE,FROZEN,'--','renderer/virgl-shader','crates','web','tools/guest').strip()
report['inverse']=inverse;report['status']='passed';(OUT/'authentication.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['captures','cold','inverse']},indent=2))
