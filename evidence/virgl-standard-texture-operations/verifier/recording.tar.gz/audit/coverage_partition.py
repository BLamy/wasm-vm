import json,hashlib,subprocess,re
from pathlib import Path
O=Path('/tmp/wasm-vm-d24-critic');R=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');a=json.loads((O/'nested-coverage.json').read_text());paths=a['changedAddedLines'];scripts=[]
for role,base in [('hot',R/'target/evidence/virgl-standard-texture-operations-final-complete'),('cold',R/'target/evidence/virgl-standard-texture-operations-cold-final/acceptance')]:
 for s in json.loads((base/'coverage-audit.json').read_text())['scripts']:
  if s['source'] in paths:scripts.append({**s,'role':role})
for base in sorted((R/'target/evidence/virgl-standard-texture-operations-verifier/promoted').glob('*')):
 if (base/'browser-coverage.json').exists():
  for s in json.loads((base/'browser-coverage.json').read_text())['scripts']:
   if s['source'] in paths:scripts.append({**s,'role':'fresh','record':base.name+'/browser-coverage.json'})
for file in sorted((O/'node-v8').glob('coverage-*.json')):
 for coverage in json.loads(file.read_text())['result']:
  prefix=R.as_uri()+'/'
  if coverage['url'].startswith(prefix):
   name=coverage['url'][len(prefix):]
   if name in paths:scripts.append(dict(source=name,sha256=hashlib.sha256((R/name).read_bytes()).hexdigest(),coverage=coverage,role='fresh-node',record='node-v8/'+file.name))
rows=[]
for name,lines in paths.items():
 text=(R/name).read_text();parts=text.splitlines(keepends=True);spans=[]
 for ln in lines:
  start=len(''.join(parts[:ln-1]).encode('utf-16-le'))//2;spans.append((start,start+len(parts[ln-1].encode('utf-16-le'))//2,ln))
 cuts={n for a,b,_ in spans for n in [a,b]};records=[]
 for s in scripts:
  if s['source']!=name:continue
  assert s['sha256']==hashlib.sha256((R/name).read_bytes()).hexdigest();ranges=[r for f in s['coverage']['functions'] for r in f['ranges']];records.append((s,ranges))
  for r in ranges:
   for n in [r['startOffset'],r['endOffset']]:
    if any(a<=n<=b for a,b,_ in spans):cuts.add(n)
 cuts=sorted(cuts)
 for lo,hi in zip(cuts,cuts[1:]):
  if not any(lo>=a and hi<=b for a,b,_ in spans):continue
  observations=[]
  for s,ranges in records:
   covers=[r for r in ranges if r['startOffset']<=lo and hi<=r['endOffset']]
   if covers:
    p=min(covers,key=lambda r:r['endOffset']-r['startOffset']);observations.append(dict(role=s['role'],record=s['record'],**p))
  snippet=text.encode('utf-16-le')[lo*2:hi*2].decode('utf-16-le');line=text[:lo].count('\n')+1
  rows.append(dict(source=name,line=line,startOffset=lo,endOffset=hi,text=snippet,observations=observations,maxEffectiveCount=max((r['count'] for r in observations),default=0)))
zeros=[r for r in rows if not r['maxEffectiveCount'] and r['text'].strip()]
result=dict(schema='d24-smallest-nested-interval-partition-v1',status='classification-pending',sourceHead='765e9d967258e44def61b65e595bcfd92b192367',scripts=len(scripts),partitions=rows,zero= zeros)
(O/'coverage-partition.json').write_text(json.dumps(result,indent=2)+'\n');print('partitions',len(rows),'nonblankzero',len(zeros))
for i,r in enumerate(zeros):print(i,r['source'],r['line'],r['startOffset'],r['endOffset'],repr(r['text']))
