from pathlib import Path
import json,re,subprocess,hashlib
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=Path('/tmp/wasm-vm-d24-critic');BASE='71853cd302a2a39cd8f5af001fd8ad1b791b7da6';FROZEN='765e9d967258e44def61b65e595bcfd92b192367'
changed={};name=None;line=0
raw=subprocess.check_output(['git','diff','--unified=0',BASE,FROZEN,'--','renderer/virgl-command/state.mjs','renderer/virgl-command/resources.mjs','renderer/virgl-command/constant-domain.mjs'],cwd=ROOT,text=True)
for row in raw.splitlines():
 if row.startswith('+++ b/'):name=row[6:]
 elif row.startswith('@@'):line=int(re.search(r'\+(\d+)',row)[1])
 elif row.startswith('+'):changed.setdefault(name,[]).append(line);line+=1
 elif row.startswith(' '):line+=1
scripts=[]
for role,base in [('hot',ROOT/'target/evidence/virgl-standard-texture-operations-final-complete'),('cold',ROOT/'target/evidence/virgl-standard-texture-operations-cold-final/acceptance')]:
 audit=json.loads((base/'coverage-audit.json').read_text())
 for script in audit['scripts']:
  if script['source'] in changed:scripts.append({**script,'role':role})
for base in sorted((ROOT/'target/evidence/virgl-standard-texture-operations-verifier/promoted').glob('*')):
 if not (base/'browser-coverage.json').exists():continue
 for script in json.loads((base/'browser-coverage.json').read_text())['scripts']:
  if script['source'] in changed:scripts.append({**script,'role':'fresh','record':base.name+'/browser-coverage.json'})
rows=[];zero=[]
for name,lines in changed.items():
 text=(ROOT/name).read_text();parts=text.splitlines(keepends=True);spans=[]
 for ln in lines:
  a=len(''.join(parts[:ln-1]).encode('utf-16-le'))//2;b=a+len(parts[ln-1].encode('utf-16-le'))//2;spans.append((a,b,ln))
 regions={}
 for script in scripts:
  if script['source']!=name:continue
  assert script['sha256']==hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
  for fn in script['coverage']['functions']:
   for r in fn['ranges']:
    a,b=r['startOffset'],r['endOffset']
    if not any(a<end and b>begin for begin,end,_ in spans):continue
    item=regions.setdefault((a,b),dict(source=name,function=fn['functionName'],startOffset=a,endOffset=b,observations=[]));item['observations'].append(dict(role=script['role'],record=script['record'],count=r['count']))
 for (a,b),r in sorted(regions.items()):
  # A positive enclosing function never overrides a narrower zero interval.
  r['maxDirectCount']=max(x['count'] for x in r['observations']);r['changedLines']=[ln for begin,end,ln in spans if a<end and b>begin];r['line']=text[:a].count('\n')+1;r['text']=text.encode('utf-16-le')[a*2:b*2].decode('utf-16-le');rows.append(r)
  if not r['maxDirectCount']:zero.append(r)
result=dict(schema='d24-independent-nested-coverage-v1',status='classification-pending',frozen=FROZEN,changedAddedLines=changed,scripts=len(scripts),regions=rows,zeroRegions=zero)
(OUT/'nested-coverage.json').write_text(json.dumps(result,indent=2)+'\n');print('regions',len(rows),'zero',len(zero),'scripts',len(scripts))
for i,z in enumerate(zero):print(i,z['source'],z['line'],z['startOffset'],z['endOffset'],repr(z['text'][:300]))
