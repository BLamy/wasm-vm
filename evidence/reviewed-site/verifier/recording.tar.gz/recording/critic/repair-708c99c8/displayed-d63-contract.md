## Deterministic acceptance

`make verify-E6-T11d63`

Record actual selected Wasm VirtIO queues and hardware WebGL2. Upload independent
original RGBA8 bytes through guarded padded SG; CLEAR and draw original points
into each valid single layer at all three NPOT mip levels for volume/cube/array,
roles2/10 (82 cases per schedule). Read every original mip/layer through actual
206 completion/DMA and independently assert both changed pixels and every
untouched byte. Run three varied deterministic schedules. Record actual native
attachment target/object/mip/layer, program and original fenced completion.

Exercise mixed dimensional/2D/null MRT slots, layer/mip rebind and program/cache
reuse, retained surfaces after public unref/name reuse, sampler private-range
refresh observing native GPU writes, real pending fence cancellation/reset and
exact owner/GPU-charge retirement. Preserve owned guest state and authenticated
unchanged private-copy caller scopes. No gl.finish or CPU rendering mirror.

Reject invalid mip or layer (including shrinking volume mips), multi-layer or
reversed ranges, non-RGBA8 dimensional/depth surfaces, missing render role,
2D nonzero layer, mismatched format and framebuffer feedback before native draw
or dimensional attachment publication. Physically redirect a valid native layer
or cube-face attachment and require the unchanged full-image oracle to fail
after actual GPU work, readback and queue DMA.

Authenticate unchanged D62/D58/D56 dependencies and complete evidence; carry
unchanged HELD regions. Run affected syntax/format/native/wasm gates once at the
frozen head, finest executable-region coverage and one final scrubbed pristine
clone. Preserve complete source/served inputs, wire, traces/digests, native calls,
planes and screenshots in a fully reopened seal for a fresh critic. Update the
partial demo marker and default-demo harness before freezing; build/commit dist,
deploy and prove built/live127/0 with zero browser errors.

