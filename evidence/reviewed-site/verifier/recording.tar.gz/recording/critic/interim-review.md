# Independent interim review — d55 product /679 recorder

Final task verdict is pending a corrected task-detail freeze and sealed worker submission. This record preserves the real refutation and distinguishes it from critic-harness errors.

## Real source/UI refutation

P3 **FAILED**: the new roadmap promises acceptance criteria (`web/roadmap.html`, intro), but selecting E6-T11d63 reveals no acceptance section. `tools/gen-tasks-json.py:185` only extracts the older Acceptance criteria heading; the frozen source task's Deterministic acceptance begins at `tasks/epic-6-transcendence/E6-T11d63-dimensional-color-surfaces.md:26`. Both Boundary and Deterministic acceptance are missing from that task's published object (empty goal/criteria), so its full contract cannot be inspected from the new drawer. Evidence: `08-roadmap-detail.png`, `08-roadmap-detail-dom.json`, and `browser-witness.json` step04's complete taskDetail. Root accepted this finding and is fixing the generator/detail. Demand: preserve and display the newer sections verbatim, retain old criteria support, rebuild tasks/dist, record the affected browser path. Preserve this failed witness.

## HELD independent checks

- `browser-witness.json` steps01–04: actual mesh/background/Devices, Home CTA→initialized unselected launcher, bare app→#ide, no duplicate mounts or iframe, task counts, Gantt→Kanban arrow key, real D63 evidence drawer, inert background, keyboard trap and Escape opener restore.
- `browser-continuation-witness.json` steps05–06: search+epic+status intersection, empty-state recovery, old initial #roadmap/#docs and later hash changes, preserved storage selection.
- `browser-reader-witness.json` step07: all six clean and.html Docs entries select the expected guide H1 and same revisioned reader module with Docstream1.8.0 and no iframe.
- `browser-reader-final-witness.json` steps08–09: Copy completion/portable Markdown, actual plain-text Blob viewer, exact inline architecture-demo source, View Code, text search,1995 archive links, unknown-page recovery, Back→Devices,390×844 reduced-motion home/roadmap/reader/menu/detail and no document overflow. Screenshots saved and viewed directly. All normal browser error lists in every owned-context run are empty. No guest boot or performance/GPU claim.
- `alternate-path-build.json`: exact detached d55 checkout, fresh pinned npm ci, build/check exit0;154 round trips,226 local links,181 original code blocks, original fragment shader. All48 tracked review/historical-receipt files are unchanged and Git status empty. Fresh metadata and validation reports go only to ignored target/docs-build. Generated path set remains330 files; only reader.js,reader.css,catalog.json,quickstart.md differ from the old cold receipt, matching the changed header/layout/link boundary.
- `baseline-preservation.json`: raw benchmark JSON and actual main/IDE/wasm/glue/isolation/xterm bytes match verified D63. Product/dist trees at d55 and679 are identical;679 changes only response-body recording custody. Hero source prefixes129315f0c4ab/c705c4904caa/aac7e0bf506c match prior independent HELD records.

## Critic harness corrections, not product findings

1. Native select AX names are “Epic All epics” and “Status All statuses”; exact Epic/Status labels timed out. Retested the actual observed controls by ID; intersection held. `continuation-accessibility.json` retains AX.
2. Reader nav title “The field guide” differs from actual publication H1 “A field guide to wasm-vm”. Expected H1 was corrected from the named published guide body, then every alias held.
3. Clipboard read occurred before asynchronous Copy completed and saw another session's public URL. Waiting for the real Copied state isolated the completed action.
4. Architecture Copy/View use Docstream1.8.0's documented resolveDemosToMarkdown path (`PageActions.js:14`), which intentionally embeds real demo files. The original assertion against raw Markdown was too strict. Revised prediction before the follow-up: all non-demo prose remains exact, actual architecture-demo.jsx bytes are embedded, and Copy/View bodies match. That held; `architecture-portable-clipboard.md` and `architecture-plain-view.md` retain actual bytes. No product code was edited by the critic.
5. One source-byte check used nonexistent wasm_vm_bg.wasm; corrected to the actual tracked wasm_vm_wasm_bg.wasm. Baseline preservation then held.

## Intermediate slop score

Composition1, empty language0, decorative simulation1, evidence distance2, craft1 = **5/25**, but **refuted** by the acceptance-contract promise despite the numeric threshold. The coherent editorial hierarchy, real layered model and honest current/historical/proposed scope survive; the missing source contract increases evidence distance. A final score will follow only after the repaired content/runtime boundary and sealed evidence are checked. No new unrelated requirements, task status, stack, deploy or implementation edits.
