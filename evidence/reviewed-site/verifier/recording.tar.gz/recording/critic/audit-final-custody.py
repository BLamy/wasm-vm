from pathlib import Path
from urllib.parse import urlparse
import hashlib,io,json,subprocess,tarfile
repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');out=repo/'target/evidence/reviewed-site-verifier-d55c051e';unpack=out/'worker-unpacked';recording=unpack/'recording'
head='c5f8ad16235a64c70e2732b0ddd7c4d4bc9c63a4';base='2aca65e9328aa1433fb516511ca554fdd96b422d';sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text())
manifest=read(repo/'evidence/reviewed-site/worker/manifest.json');stageDir=recording/'reviewed-site-release-c5f8ad16';stage=read(stageDir/'staging-index.json');stageMap={r['path']:r for r in stage['records']};stageFiles={r['path']:(stageDir/'web/dist'/r['path']).read_bytes() for r in stage['records']}
assert len(stageMap)==stage['fileCount']==638
for name,blob in stageFiles.items():assert len(blob)==stageMap[name]['bytes'] and sha(blob)==stageMap[name]['sha256'] and len(blob)<25*1024*1024,name
source=(unpack/'source/frozen-source.tar').read_bytes();sourcePaths=['web','design','Makefile','AGENTS.md','tools/build-docs.mjs','tools/build-docs-corpus.py','tools/gen-tasks-json.py','tools/check-docs.mjs','tools/check-docs-dist.py','tools/finalize-docs-dist.py','tools/build-web-dist.sh','tools/verify-reviewed-site.mjs','tools/verify-virgl-default-demo.mjs','tools/virgl-command/fixtures.mjs','tools/deploy-cloudflare.sh','tasks/epic-0-ignition/E0-T27-reviewed-docstream-site.md','tasks/epic-6-transcendence/E6-T11d64-dimensional-depth-surfaces.md','tasks/epic-6-transcendence/E6-T11d-truthful-guest-virgl-bringup.md','tasks/QUEUE.md'];fresh=subprocess.check_output(['git','archive',head,*sourcePaths],cwd=repo)
assert source==fresh and sha(source)==manifest['sourceArchiveSha256'], 'full frozen source archive'
frozenDist=(stageDir/'frozen-web-dist.tar').read_bytes();assert frozenDist==subprocess.check_output(['git','archive',head,'web/dist'],cwd=repo)
assert sha(frozenDist)==stage['sourceArchiveSha256']
production={}
with tarfile.open(fileobj=io.BytesIO(frozenDist)) as tar:
 for item in tar:
  if item.isfile():production[item.name.removeprefix('web/dist/')]=tar.extractfile(item).read()
assert len(production)==633
carried={r['path']:r for r in stage['carriedBootManifests']}
for name,blob in production.items():
 if name in carried:assert sha(blob)==carried[name]['sourceSha256'] and sha(stageFiles[name])==carried[name]['stagedSha256']
 else:assert stageFiles[name]==blob,name
held=read(stageDir/'held-staging-index.json');heldMap={r['path']:r for r in held['records']};assert len(heldMap)==304
previousSeal=repo/'evidence/virgl-dimensional-color-surfaces/deployment'
for name in ('manifest.json','records.json'):
 blob=(previousSeal/name).read_bytes();assert blob==subprocess.check_output(['git','show',base+':evidence/virgl-dimensional-color-surfaces/deployment/'+name],cwd=repo)
priorManifest=read(previousSeal/'manifest.json');priorIndex=read(previousSeal/'records.json');priorRows={r['path']:r for r in priorIndex['records']}
assert sha((previousSeal/'manifest.json').read_bytes())==stage['authority']['manifestSha256']=='22a01eafcf805b79094ee3b311b749f62e533ecbd8c5ff37d41ffba641f897ee'
assert sha((previousSeal/'records.json').read_bytes())==priorManifest['recordIndexSha256']==stage['authority']['indexSha256']
assert sha((stageDir/'held-staging-index.json').read_bytes())==priorRows['publication/staging-index.json']['sha256']
for name in carried:
 assert stageMap[name]['sha256']==heldMap[name]['sha256']==priorRows['publication/web/dist/'+name]['sha256'],name
extra=set(stageMap)-set(production);assert len(extra)==5
for name in extra:assert stageMap[name]==heldMap[name],name
assert set(heldMap)-set(stageMap)=={'docs-mount.js'} and not (stageDir/'web/dist/docs-mount.js').exists()
cold=read(recording/'reviewed-site-cold-c5f8ad16/report.json');own=read(out/'alternate-path-build.json');ownMap={r['path']:r for r in own['generatedRecords']}
assert cold['head']==head and cold['status']=='passed' and cold['initialStatus']==cold['finalStatus']==''
assert all(r['exitCode']==0 for r in cold['commands']) and cold['trackedDesignBodiesUnchanged']==57
assert cold['authoredTaskRecordsMatched']==682 and cold['modernBoundaries']==291 and cold['modernContracts']==196
assert len(cold['generatedFiles'])==330
for row in cold['generatedFiles']:assert row['sha256']==ownMap[row['path']]['sha256'],row['path']
for row in cold['productionFiles']:
 name=row['path'].removeprefix('web/dist/');blob=production[name];assert len(blob)==row['bytes'] and sha(blob)==row['sha256'],name
siteAudits=[]
allowedUnchanged={'ide.js','vendor/xterm/xterm.js','omarchy-startup-state.js','coi-serviceworker-register.js','cpu-isolation.js'}
for group in ('reviewed-site-final-c5f8ad16','reviewed-site-live-c5f8ad16'):
 expectedBodies=production if group.startswith('reviewed-site-final-') else stageFiles;expectedRows={name:{'bytes':len(blob),'sha256':sha(blob)} for name,blob in expectedBodies.items()};folder=recording/group/'site';report=read(folder/'report.json');assert report['head']==head and report['status']=='passed' and not report['errors'] and len(report['steps'])==8
 for row in report['requests']+report['originalRouteBodies']:
  blob=(folder/row['bodyPath']).read_bytes();name=row['path'];assert row['status']==200 and blob==expectedBodies[name] and sha(blob)==row['sha256'] and len(blob)==row['bytes'],(group,name)
 for row in report['originalRouteBodies']:assert row['path']=='tabs.js' and row['forwardedUnchanged']
 for item in report['interruptedResponseBodies']:
  name=urlparse(item['url']).path.lstrip('/');assert item['legacyTransition'] in ('workbench-roadmap-bookmark','workbench-docs-bookmark')
  assert 'Network.getResponseBody' in item['message'] and 'No resource with given identifier found' in item['message']
  if 'originalBodyPath' in item:
   assert name=='tabs.js';assert any(r['url']==item['url'] and r['bodyPath']==item['originalBodyPath'] and r['sha256']==item['sha256'] and r['forwardedUnchanged'] for r in report['originalRouteBodies']);assert (folder/item['originalBodyPath']).read_bytes()==expectedBodies[name]
  else:
   assert name in allowedUnchanged and item['baselineHead']==base
   blob=(folder/item['heldBodyPath']).read_bytes();assert blob==expectedBodies[name]==subprocess.check_output(['git','show',base+':web/dist/'+name],cwd=repo)
   assert any(r['path']==name and r['sha256']==item['sha256'] for r in report['requests'])
 for shot in report['screenshots']:assert sha((folder/shot['path']).read_bytes())==shot['sha256']
 if group.endswith('live-c5f8ad16'):
  assert all('favicon.ico' in x['location']['url'] for x in report['favicon404'])
 for critical in ['index.html','app.html','tabs.js','roadmap.html','roadmap.js','roadmap-page.js','roadmap.css','tasks.json','docs.html','docs-bundle/reader.js','docs-bundle/reader.css']:
  assert any(r['path']==critical for r in report['requests']) or any(r['path']==critical for r in report['originalRouteBodies']),critical
 demoDir=recording/group/'default-demo';demo=read(demoDir/'report.json');assert demo['gitHead']==head and demo['status']=='passed' and demo['passed']==127 and demo['failed']==0 and not demo['errors'] and demo['proofExportAbsent'] and demo['graphicsRoadmapPip']=='cap-pip partial' and demo['roadmapPip']=='cap-pip live'
 for row in demo['served']:
  name=row['path'].removeprefix('web/dist/').lstrip('/');name='app.html' if name=='app' else name
  assert name in expectedRows and row['bytes']==expectedRows[name]['bytes'] and row['sha256']==expectedRows[name]['sha256'],(group,name)
  if group.endswith('live-c5f8ad16'):assert (demoDir/'bodies'/row['path'].lstrip('/')).read_bytes()==expectedBodies[name]
 assert sha((demoDir/demo['screenshot']['path']).read_bytes())==demo['screenshot']['sha256']
 assert demo['servedWasmSha256']=='d45b575207e0035b5c518698e7b6793b2bf12da635531723fad70813a5956c36'
 siteAudits.append({'group':group,'uiGroups':8,'normalErrors':0,'actualFullSiteResponses':len(report['requests']),'originalRoutingFetchForwardRecords':len(report['originalRouteBodies']),'interruptedCdpBodiesAuthenticated':len(report['interruptedResponseBodies']),'defaultPassed':127,'defaultFailed':0,'defaultServedBodies':len(demo['served']),'partialGpuPreserved':True})
confirmation=read(stageDir/'cloudflare-cli-confirmation.json');publish=read(stageDir/'publish.json');assert confirmation['head']==head and confirmation['id']==manifest['deploymentId']=='92409cfe-36f8-4dd5-b967-64547d132e95' and confirmation['environment']=='Production' and confirmation['branch']=='main'
assert sha((stageDir/'deployment-list.stdout').read_bytes())==confirmation['listSha256'] and confirmation['id'] in (stageDir/'deployment-list.stdout').read_text()
assert sha((stageDir/'publish.json').read_bytes())==confirmation['publishReceiptSha256'] and publish['exitCode']==0 and publish['head']==head
assert sha((stageDir/'staging-index.json').read_bytes())==publish['stagingIndexSha256'] and sha((stageDir/'publish.stdout').read_bytes())==publish['stdoutSha256'] and sha((stageDir/'publish.stderr').read_bytes())==publish['stderrSha256']
result={'sourceHead':head,'submissionHead':'15ddb655c0d5ba787baea27c695dcab9a1fd9bcc','completeSourceArchiveBytes':len(source),'completeSourceArchiveSha256':sha(source),'completeScopedGitArchiveIdentityMatched':True,'sourcePaths':sourcePaths,'frozenProductionFiles':len(production),'stagedFiles':len(stageMap),'preservedAdditionalBootBodies':len(extra),'authenticatedCarriedBootManifests':len(carried),'retiredOnly':'docs-mount.js','defaultWasmSha256':stage['defaultWasmSha256'],'coldGenerated330MatchIndependentAlternatePath':True,'coldProduction633MatchFrozenGitBodies':True,'coldTrackedDesign57Unchanged':True,'actualRoutingAcquisition':'producer fetches original HTTP response, reads full bytes, asserts frozen identity then fulfills with the original response and same bytes; uninstrumented critic browser independently verifies those routes','siteAndDefaultAudits':siteAudits,'deployment':confirmation,'verdict':'HELD'}
(out/'final-custody-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
