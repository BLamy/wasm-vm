from pathlib import Path,PurePosixPath
import gzip,hashlib,io,json,os,tarfile,time
repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
seal=repo/'evidence/reviewed-site/worker';out=repo/'target/evidence/reviewed-site-verifier-d55c051e';dest=out/'worker-unpacked'
manifest=json.loads((seal/'manifest.json').read_text());index=json.loads((seal/'records.json').read_text());rows=index['records'];expected={r['path']:r for r in rows}
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha((seal/'manifest.json').read_bytes())=='135b91d9adb9fe373b12d53a423abdd266fd3e96ca95543e1378ba7f6e515f6a'
assert sha((seal/'records.json').read_bytes())==manifest['recordIndexSha256']=='284e17a274e3bf2f4eaa98fed1769e34c9bf1c99995ed54f963cdcf5eea267bc'
assert len(expected)==len(rows)==6073
combined=io.BytesIO();aggregate=hashlib.sha256();partChecks=[]
for part in manifest['archiveParts']:
 blob=(seal/part['path']).read_bytes();assert len(blob)==part['bytes'] and sha(blob)==part['sha256'];combined.write(blob);aggregate.update(blob);partChecks.append({'path':part['path'],'bytes':len(blob),'sha256':sha(blob)})
assert combined.tell()==manifest['archiveBytes']==203096077
assert aggregate.hexdigest()==manifest['archiveSha256']=='b22c3c167a4c105c4beaf3c0571c827f9f54c245cc0e0d231ba80b22e1e02b6b'
combined.seek(0);dest.mkdir(exist_ok=True);seen={};stored=links=0;logicalBytes=0
started=time.monotonic()
with gzip.GzipFile(fileobj=combined,mode='rb') as gz:
 with tarfile.open(fileobj=gz,mode='r|') as archive:
  for member in archive:
   name=member.name;parts=PurePosixPath(name).parts
   assert not PurePosixPath(name).is_absolute() and '..' not in parts
   assert name in expected and name not in seen,name
   row=expected[name];file=dest.joinpath(*parts);file.parent.mkdir(parents=True,exist_ok=True)
   if member.isfile():
    assert row['kind']=='file';blob=archive.extractfile(member).read();stored+=1
    assert len(blob)==member.size==row['bytes'] and sha(blob)==row['sha256'],name
    file.write_bytes(blob);seen[name]={'bytes':len(blob),'sha256':sha(blob)}
   elif member.islnk():
    assert row['kind']=='hardlink' and member.linkname==row['target'] and member.linkname in seen,name
    previous=seen[member.linkname];assert previous['bytes']==row['bytes'] and previous['sha256']==row['sha256'],name
    previousPath=dest.joinpath(*PurePosixPath(member.linkname).parts)
    if file.exists():file.unlink()
    os.link(previousPath,file);seen[name]=previous;links+=1
   else:raise AssertionError(('unrecognized member',name,member.type))
   logicalBytes+=row['bytes']
 tail=gz.read();assert not tail.strip(b'\0'),'nonzero trailing gzip payload'
assert set(seen)==set(expected)
assert stored==manifest['uniqueBodies']==905 and links==manifest['backwardLinks']==5168
result={'sourceHead':manifest['head'],'workerManifestSha256':sha((seal/'manifest.json').read_bytes()),'indexSha256':sha((seal/'records.json').read_bytes()),'archiveSha256':aggregate.hexdigest(),'archiveBytes':manifest['archiveBytes'],'parts':partChecks,'logicalMembersReopened':len(seen),'storedBodies':stored,'backwardLinks':links,'storedBytes':sum(r['bytes'] for r in rows if r['kind']=='file'),'logicalBytes':logicalBytes,'gzipEofChecked':True,'noUnindexedMembers':True,'noForwardOrExternalLinks':True,'trailingDecodedZeroPaddingBytes':len(tail),'seconds':round(time.monotonic()-started,3),'unpackedDirectory':str(dest)}
(out/'worker-seal-authentication.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='parts'},indent=2))
