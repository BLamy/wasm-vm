import ast,hashlib,json,pathlib,re,struct,subprocess
root=pathlib.Path(__file__).resolve().parent;repo=pathlib.Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');frozen='9de5721b5a9c5c0d70b94956305ba76a447a5024'
sha=lambda b:hashlib.sha256(b).hexdigest();binary=bytes.fromhex
literal={3:((5,3,7),(2,1,3),(1,1,1)),4:((5,5,6),(2,2,6),(1,1,6)),7:((5,3,7),(2,1,7),(1,1,7))};cost={3:448,4:720,7:504}
for t,d in literal.items():assert sum(w*h*z*4 for w,h,z in d)==cost[t]
def words(raw):
    b=binary(raw);assert len(b)%4==0;return struct.unpack('<'+'I'*(len(b)//4),b)
def pixels(seed,t,level,d):
    w,h,layers=d;out=bytearray()
    for z in range(layers):
        for y in range(h):
            for x in range(w):
                for c in range(4):out.append((seed+t*43+level*29+z*31+y*17+x*13+c*53)&255)
    return bytes(out)
def scatter(base,d,offset,pitch,layer,tight):
    out=bytearray(base);w,h,n=d;assert len(tight)==w*h*n*4
    for z in range(n):
        for y in range(h):
            at=offset+z*layer+y*pitch;src=(z*h+y)*w*4;out[at:at+w*4]=tight[src:src+w*4]
    return bytes(out)
def patched(base,d,box,data):
    out=bytearray(base);w,h,n=d;x,y,z=box['x'],box['y'],box['z'];bw,bh,bd=box['width'],box['height'],box['depth'];assert len(data)==bw*bh*bd*4
    for dz in range(bd):
        for dy in range(bh):
            at=(((z+dz)*h+y+dy)*w+x)*4;src=(dz*bh+dy)*bw*4;out[at:at+bw*4]=data[src:src+bw*4]
    return bytes(out)
def canonical(row):
    for domain in ['transport','submit']:assert sha(binary(row[domain+'Canonical']))==row[domain+'Digest']
def queue(row):
    canonical(row);w=words(row['request']);v=words(row['response']);assert len(v)==6 and v[4:6]==w[4:6]
    assert v[1]==w[1]&1 and v[2:4]==(w[2:4] if w[1]&1 else (0,0))
    ring=binary(row['ring']['used']);idx=struct.unpack_from('<H',ring,2)[0];assert idx>=row['usedIndex'];head,n=struct.unpack_from('<II',ring,4+((row['usedIndex']-1)%256)*8);assert n==24 and head==((row['usedIndex']-1)%128)*2
    return v[0]
records=[]
for recording in ['worker/cold/recording/hardware','fresh-hardware']:
    p=root/recording;raw=(p/'report.json').read_bytes();report=json.loads(raw);r=report['browserResult']['result'];assert report['status']==r['status']=='passed'
    assert report['browserErrors']=={'console':[],'page':[],'requests':[]};assert not report['productionAuthority'] and not report['actualLinuxGuest'] and not r['productionNegotiation']
    assert len(report['seeds'])==len(set(report['seeds']))==3 and 'Metal' in r['gpu'];assert report['browser']['gpu']['featureStatus'][report['browser']['webglFeature']]=='enabled'
    assert not any(re.search('swiftshader|llvmpipe|softpipe|lavapipe|--disable-gpu(?:$|=)',s,re.I) for s in report['browser']['commandLine'])
    assert sha(json.dumps(report['browserResult'],separators=(',',':'),ensure_ascii=False).encode())==report['browserResultSha256']
    planes=[];total=0;owners=[];cases={}
    assert {(run['seed'],run['metadata']['target']) for run in r['runs']}=={(seed,t) for seed in report['seeds'] for t in literal}
    for run in r['runs']:
        t=run['metadata']['target'];seed=run['seed'];d=literal[t];assert [tuple(v) for v in run['shape']['levels']]==list(d)
        m=run['metadata'];assert (m['format'],m['bind'],m['width'],m['height'],m['depth'],m['arraySize'],m['lastLevel'],m['nrSamples'],m['flags'])==(67,10,5,5 if t==4 else 3,7 if t==3 else 1,1 if t==3 else 6 if t==4 else 7,2,0,0)
        for state in run['states']:assert state['native']['gpuBytes']==state['native']['logicalBytes']==state['host']['store']['budgets']['gpuBytes']==cost[t]
        assert len(run['levels'])==3
        for level,o in enumerate(run['levels']):
            w,h,z=d[level];pred=pixels(seed,t,level,d[level]);assert binary(o['input'])==pred
            l=o['layout'];pitch=w*4+(7 if level%2==0 else 0);layer=pitch*h+(11 if level%2==0 else 0)
            assert (l['offset'],l['rowBytes'],l['rowStride'],l['layerStride'],l['tightBytes'])==(5,w*4,pitch,layer,len(pred))
            assert binary(o['source'])==scatter(bytes([0x8d])*4096,d[level],5,pitch,layer,pred)
            assert binary(o['fullBacking'])==scatter(bytes([0xc7])*4096,d[level],5,pitch,layer,pred)
            for upload,kind in [(o['upload'],'layered-input'),(o['readback'],'layered-output')]:
                assert queue(upload['record'])==0x1100;assert len(upload['exchanges'])==1;ex=upload['exchanges'][0];assert ex['kind']==kind and binary(ex['bytes'])==pred
                a=ex['args'];assert len(a)==12 and a[3]==6 and int(a[6],16)==5 and a[7:]==[w*4,pitch,h,layer,z]
                owner=upload['owner'];assert owner['resources'][0]['metadata']==m and owner['epoch']==a[0] and owner['sequence']==a[1]
                assert ex['usedIndex']==upload['record']['usedIndex']-1;owners.append(a[:6])
            up=words(o['upload']['record']['request']);assert up[0]==0x205 and up[6:12]==(0,0,0,w,h,z) and up[12:14]==(5,0) and up[14:18]==(6,level,pitch if level%2==0 else 0,layer if level%2==0 else 0)
            outer=words(o['readback']['record']['request']);inner=outer[8:];assert outer[0]==0x207 and inner[0]&255==43 and inner[0]>>16==13
            assert inner[1:6]==(6,level,0,pitch if level%2==0 else 0,layer if level%2==0 else 0) and inner[6:12]==(0,0,0,w,h,z) and inner[12:]==(5,2)
            assert all(g['prefix']==g['suffix']=='a3'*8 for g in o['guards']);planes.append({'seed':seed,'target':t,'level':level,'extent':d[level],'bytes':len(pred),'sha256':sha(pred)})
        part=run['partial'][0];box=part['box'];assert box=={'x':1,'y':1,'z':d[0][2]-2,'width':2,'height':2,'depth':2}
        pred=patched(patched(pixels(seed,t,0,d[0]),d[0],box,pixels(seed,t,19,(2,2,2))),d[0],box,pixels(seed,t,23,(2,2,2)))
        assert binary(part['expectedFullPlane'])==binary(part['full']['exchanges'][0]['bytes'])==pred
        assert not part['inlined']['exchanges'] and words(part['inlined']['record']['request'])[8]&255==9
        for member,flags in [('staged',1),('reverse',3)]:
            inner=words(part[member]['record']['request'])[8:];assert inner[0]&255==45 and inner[1:6]==(6,0,200,13,37) and inner[6:12]==(1,1,d[0][2]-2,2,2,2) and inner[-1]==flags
            assert binary(part[member]['exchanges'][0]['bytes'])==pixels(seed,t,23,(2,2,2)) and part[member]['exchanges'][0]['args'][3]==200
        lifecycle=run['lifecycle']['exchanges'];assert len(lifecycle)==3 and binary(lifecycle[0]['bytes'])==pred and binary(lifecycle[1]['bytes'])==binary(lifecycle[2]['bytes'])==pixels(seed,t,31,d[0])
        assert lifecycle[0]['args'][5]!=lifecycle[1]['args'][5] and run['snapshot']['liveSyncs']==0
        for attack in run['argumentAttacks']:assert attack['state']['lastExchange']=='0000000000000000'
        for row in run['records']:cases[row['case']]=cases.get(row['case'],0)+1;queue(row);total+=1
        assert any(e['type']=='reset' for e in run['events'])
        for ex in run['exchanges']:
            assert ex['kind'] in ['layered-input','layered-output'];assert len(ex['args'])==12 and int(ex['args'][2],16)>0
        for completion in run['completions']:
            assert len(completion['args'])==7 and completion['args'][4] is True
        assert re.fullmatch('[0-9a-f]{64}',run['machineDigest'])
    boundaries=r['boundaries'];assert len(boundaries['metadata'])==16 and len(boundaries['transfers'])==11
    for item in boundaries['metadata']:assert queue(item['record'])==0x1205
    for item in boundaries['transfers']:assert queue(item['record'])==0x1205
    for row in boundaries['records']:queue(row);total+=1
    assert [queue(row) for row in boundaries['historical']]==[0x1205]*3
    f=r['failure'];assert queue(f['record'])==0x1200 and f['before']==f['after'] and f['native']['poisoned'] and f['host']['poisoned'];assert f['completions'][-1]['args'][3:5]==[6,False]
    assert any(e['name']=='clientWaitSync' and e['delivered']==37149 for e in f['physical'])
    live=set();fences=[];collections=[];waits=[]
    for call in r['nativeCalls']:
        i=call['sequence'];name=call['name'];assert i>=0 and name!='finish'
        if (name.startswith('create') or name=='fenceSync') and call['result'] is not None:
            obj=call['result']['object'];assert obj not in live;live.add(obj)
        if name.startswith('delete') and call['before'][0] is not None:
            obj=call['before'][0]['object'];assert obj in live;live.remove(obj)
        if name=='fenceSync':fences.append(i)
        if name=='getBufferSubData':collections.append(i)
        if name=='clientWaitSync':waits.append(i)
    assert not live and len(fences)==120 and len(collections)==63
    records.append({'recording':recording,'reportSha256':sha(raw),'planes':planes,'queueRecords':total,'owners':owners,'nativeCalls':len(r['nativeCalls']),'physicalFences':fences,'physicalCollections':collections,'physicalWaits':waits,'terminalObjects':0,'cases':cases})
# All native full-state points and each complete dirty SG inverse, independent of worker audit.
native=[];state_count=0;trace_count=0;citations=[]
for filename in ['worker/cold/recording/native-submit.stderr','fresh-native-dimensional.stderr','promoted-native-final.stderr']:
    path=root/filename;state=0;dma=[];guest=0
    for line,raw in enumerate(path.read_text().splitlines(),1):
        if raw.startswith('SUBMIT3D_PORTABLE_RECORD '):canonical(json.loads(raw.split(' ',1)[1]));state+=1
        if raw.startswith('SUBMIT3D_GUEST_TRACE '):assert raw=='SUBMIT3D_GUEST_TRACE core 0: 0x0000000080200000 (0x0000006f)';guest+=1
        if raw.startswith('NATIVE_DIMENSIONAL_DMA_POINT '):
            r=json.loads(raw.split(' ',1)[1]);t=r['target'];level=r['level'];w,h,d=literal[t][level];assert tuple(r['extent'])==(w,h,d)
            source=bytes(((i*71)^r['seed']^(level*43))&255 for i in range(4096));assert binary(r['source'])==source
            expected=bytes(source[5+z*r['layerStride']+y*r['stride']+x] for z in range(d) for y in range(h) for x in range(w*4))
            assert binary(r['gathered'])==expected and binary(r['output'])==bytes(v^0x57 for v in expected)
            assert binary(r['fullBacking'])==scatter(source,(w,h,d),5,r['stride'],r['layerStride'],bytes(v^0x57 for v in expected))
            dma.append({'line':line,'target':t,'level':level,'seed':r['seed'],'outputSha256':sha(binary(r['output']))})
        if raw.startswith('NATIVE_DIMENSIONAL_CRITIC_EDGE '):
            match=re.fullmatch(r'NATIVE_DIMENSIONAL_CRITIC_EDGE target=(\d+) source=([0-9a-f]+) output=([0-9a-f]+) fullBacking=([0-9a-f]+) used=(\d+) cancelled=(\d+) machineDigest=([0-9a-f]{64})',raw);assert match
            t=int(match[1]);source=bytes((i*37+t)&255 for i in range(75));output=bytes((i*53+t*11)&255 for i in range(32));assert binary(match[2])==source and binary(match[3])==output and binary(match[4])==scatter(source,(2,2,2),23,13,31,output) and match[5:7]==('4','1')
            citations.append({'file':filename,'line':line,'sha256':sha(path.read_bytes()),'target':t,'machineDigest':match[7]})
        assert not ('panicked at' in raw or 'test result: FAILED' in raw)
    if 'promoted' not in filename:assert len(dma)==27
    native.append({'file':filename,'sha256':sha(path.read_bytes()),'canonicalPoints':state,'guestInstructions':guest,'dma':dma});state_count+=state;trace_count+=guest
# Direct physical sabotage defeats the unchanged full-byte independent pixel oracle.
faults=[]
for filename in ['worker/cold/recording/fault-cube-layer/report.json','fresh-fault-cube/report.json']:
    raw=(root/filename).read_bytes();r=json.loads(raw);assert r['status']==r['browserResult']['status']=='failed' and r['sabotage']['kind']=='cube-async-layer'
    p=r['browserResult']['point'];assert p['native']['resources'][0]['metadata']['target']==4
    output=binary(p['exchanges'][-1]['bytes']);expected=pixels(r['seeds'][0],4,0,literal[4][0]);assert len(output)==len(expected)==600 and output!=expected
    assert r['browserErrors']=={'console':[],'page':[],'requests':[]}
    faults.append({'file':filename,'sha256':sha(raw),'seed':r['seeds'][0],'expectedSha256':sha(expected),'observedSha256':sha(output),'bytes':600,'physicalCollections':[x['sequence'] for x in r['browserResult']['partial']['nativeCalls'] if x['name']=='getBufferSubData']})
unit=root/'worker/cold/recording/native-gpu.stderr';unitlines=unit.read_text().splitlines();assert any('result=Err(OutOfMemory) publishedSpans=0' in l for l in unitlines)
for line,s in enumerate(unitlines,1):
    if s.startswith('NATIVE_DIMENSIONAL_MIP_SPANS '):
        m=re.search(r'target=(\d+) level=(\d+) rows=Submit3dRows \{ offset: (\d+), row_bytes: (\d+), row_stride: (\d+), row_count: (\d+) \} layerStride=(\d+) layers=(\d+)',s);assert m
        t,level,offset,rb,pitch,h,layer,d=map(int,m.groups());assert literal[t][level]==(rb//4,h,d)
        entries=[tuple(map(int,x)) for x in re.findall(r'BackingEntry \{ addr: (\d+), length: (\d+) \}',s)];spans=ast.literal_eval(re.search(r'spans=(\[.*\]) bytes=',s)[1])
        predicted=[]
        for z in range(d):
            for y in range(h):
                for x in range(rb):
                    at=offset+z*layer+y*pitch
                    logical=at+x
                    for addr,n in entries:
                        if logical<n:predicted.append(addr+logical);break
                        logical-=n
                    else:raise AssertionError('logical byte absent')
        actual=[at+x for at,n in spans for x in range(n)];assert actual==predicted
        citations.append({'file':'worker/cold/recording/native-gpu.stderr','line':line,'sha256':sha(unit.read_bytes()),'target':t,'level':level,'spans':spans})
out={'status':'HELD','literalExtents':literal,'literalCosts':cost,'recordings':records,'native':native,'physicalSabotage':faults,'citations':citations,'canonicalPoints':state_count,'guestInstructions':trace_count}
(root/'interrogation.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':out['status'],'recordings':len(records),'mips':sum(len(x['planes']) for x in records),'workerCanonicalPoints':native[0]['canonicalPoints'],'novelCitations':len([x for x in citations if 'machineDigest' in x]),'faults':faults}))
