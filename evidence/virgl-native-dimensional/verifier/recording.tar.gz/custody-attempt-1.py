import hashlib,json,pathlib,subprocess
r=pathlib.Path('/tmp/wasmvm-native-dimensional-verifier-20261012');repo=pathlib.Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');clone=pathlib.Path('/var/folders/nr/cyvk1qc14jj5c081vj1xts000000gn/T/wasm-vm-native-dimensional-cold-360j2fhv/repo');sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda cwd,*a:subprocess.check_output(['git',*a],cwd=cwd)
auth=json.loads((r/'authentication.json').read_bytes());changed=[]
for name,pin in auth['sources'].items():
 b=(repo/name).read_bytes()
 if sha(b)!=pin['sha256']:changed.append(name)
assert changed==['crates/core/tests/virtio_gpu_submit3d/dimensional.rs'];assert git(clone,'rev-parse','HEAD').decode().strip()=='9de5721b5a9c5c0d70b94956305ba76a447a5024';assert not git(clone,'status','--porcelain')
protected=subprocess.check_output(['ps','-p','23192','-o','pid=,command='],text=True);assert 'playwright_chromiumdev_profile-60rjcU' in protected
runner=(repo/'tools/virgl-native-dimensional/browser.mjs').read_text();assert 'browser.close()' in runner and 'server.close(' in runner
receipts=[]
for name in ['fresh-hardware','fresh-fault-cube','fresh-live','restored-dimensional-tests','final-fmt-check','final-clippy']:
 p=json.loads((r/(name+'.json')).read_bytes());assert p['exitCode']==p['expected'];receipts.append(p)
(r/'custody-before-commit.json').write_text(json.dumps({'sourceLease':'exclusive verifier; parent read-only','role':'fresh critic never implementer','submission':git(repo,'rev-parse','HEAD').decode().strip(),'changedFrozenSources':changed,'productAndDistByteIdentical':True,'coldClone':str(clone),'coldCloneClean':True,'protectedChrome':protected.strip(),'ownedRunsCompleted':receipts,'ownedBrowserCleanup':'recorded runners complete and finally close browser/server; no persistent verifier job session','writes':'promoted tests, scoped evidence, verifier log/status and queue only','coldCleanupOwner':'parent after P6 authentication; clone preserved'},indent=2)+'\n')
