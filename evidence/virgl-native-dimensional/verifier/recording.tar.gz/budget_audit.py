import hashlib,json,pathlib,re,struct
root=pathlib.Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();file=root/'restored-dimensional-tests.stderr';body=file.read_bytes();points=[]
for line,text in enumerate(body.decode().splitlines(),1):
    if text.startswith('NATIVE_DIMENSIONAL_CRITIC_BUDGET '):
        assert text.startswith('NATIVE_DIMENSIONAL_CRITIC_BUDGET exactBytes=4194304 backingBytes=4194304 refusedBytes=4194305 ')
        match=re.search(r'source=([0-9a-f]+) gathered=([0-9a-f]+) output=([0-9a-f]+) fullBacking=([0-9a-f]+) machineDigest=([0-9a-f]{64})$',text);assert match
        source=bytes.fromhex(match[1]);gathered=bytes.fromhex(match[2]);output=bytes.fromhex(match[3]);full=bytes.fromhex(match[4]);assert len(source)==len(gathered)==len(output)==len(full)==4194304
        expected=bytes((i*37 ^ (i>>8)*11 ^ (i>>20) ^ 0x39)&255 for i in range(4194304));assert source==gathered==expected and output==full==bytes(x^0x6d for x in expected)
        points.append({'file':file.name,'line':line,'fileSha256':sha(body),'sourceBytes':len(source),'sourceSha256':sha(source),'outputSha256':sha(output),'machineDigest':match[5]})
    if text.startswith('SUBMIT3D_PORTABLE_RECORD '):
        r=json.loads(text.split(' ',1)[1])
        for family in ['transport','submit']:assert sha(bytes.fromhex(r[family+'Canonical']))==r[family+'Digest']
        if r['case']=='critic-exact-four-mib-layered-exchange':
            words=struct.unpack('<18I',bytes.fromhex(r['request']));assert words[0]==0x206 and words[6:12]==(0,0,0,1024,512,2) and words[12:14]==(0,0) and words[14:18]==(3,0,0,0)
            assert bytes.fromhex(r['response'])==bytes([0xa5])*24 and r['usedIndex']==9
    assert 'panicked at' not in text
assert len(points)==1
fault=(root/'native-oracle-layer-sabotage.stderr').read_text();assert 'panicked at crates/core/tests/virtio_gpu_submit3d/dimensional.rs:455:9' in fault and 'assertion `left == right` failed' in fault
assert json.loads((root/'native-oracle-layer-sabotage.json').read_bytes())['exitCode']==101
(root/'budget-audit.json').write_text(json.dumps({'status':'HELD','points':points,'nativeOracleSabotage':{'file':'native-oracle-layer-sabotage.stderr','sha256':sha((root/'native-oracle-layer-sabotage.stderr').read_bytes()),'line':next(i for i,t in enumerate(fault.splitlines(),1) if 'panicked at' in t),'expectedFailure':True,'sourceRestored':True}},indent=2)+'\n')
print(json.dumps({'status':'HELD','points':points,'physicalNativeRamOracleCaughtRotatedLayers':True}))
