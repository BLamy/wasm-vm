from pathlib import Path
import subprocess,hashlib,json
repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');root=Path(__file__).resolve().parent;file=repo/'crates/core/tests/virtio_gpu_submit3d/dimensional.rs'
original=file.read_bytes();text=original.decode();anchor='        q.machine\n            .submit3d_scatter_layered(&exchange, 31, 2, &output)\n            .unwrap();'
assert text.count(anchor)==1
mutant=text.replace(anchor,'        let wrong_layers = [output[16..].to_vec(), output[..16].to_vec()].concat();\n        q.machine\n            .submit3d_scatter_layered(&exchange, 31, 2, &wrong_layers)\n            .unwrap();')
(root/'promoted-native-mutant.rs').write_text(mutant)
try:
    file.write_text(mutant)
    subprocess.run(['python3',str(root/'run.py'),'native-oracle-layer-sabotage','101','cargo','test','--offline','-p','wasm-vm-core','--features','virgl-control-proof,gpu-trace,trace','--test','virtio_gpu_submit3d','dimensional_exact_sg_edge','--','--nocapture','--test-threads=1'],cwd=repo,check=True)
finally:
    file.write_bytes(original)
assert file.read_bytes()==original
out={'mutated':'promoted test supplies physically swapped layer bytes to unchanged native scatter; full expected byte oracle remains unchanged','productSourceEdits':False,'originalSha256':hashlib.sha256(original).hexdigest(),'mutantSha256':hashlib.sha256(mutant.encode()).hexdigest(),'restored':True}
(root/'native-oracle-sabotage.json').write_text(json.dumps(out,indent=2)+'\n')
