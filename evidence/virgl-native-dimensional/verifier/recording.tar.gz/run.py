import os,subprocess,json,time,hashlib,pathlib,sys
root=pathlib.Path(__file__).resolve().parent;repo=pathlib.Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
name=sys.argv[1];expected=int(sys.argv[2]);command=sys.argv[3:]
assert not (root/(name+'.json')).exists()
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','RUST','LLVM_PROFILE','VIRGL_','NODE_','npm_','NPM_','CHROME'))}
t=time.monotonic();r=subprocess.run(command,cwd=repo,env=env,capture_output=True,timeout=300)
(root/(name+'.stdout')).write_bytes(r.stdout);(root/(name+'.stderr')).write_bytes(r.stderr)
row={'name':name,'command':command,'expected':expected,'exitCode':r.returncode,'seconds':time.monotonic()-t,'stdoutSha256':hashlib.sha256(r.stdout).hexdigest(),'stderrSha256':hashlib.sha256(r.stderr).hexdigest(),'scrubbedPrefixes':['CARGO_','RUST','LLVM_PROFILE','VIRGL_','NODE_','npm_','NPM_','CHROME']}
(root/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row));print(r.stdout[-1000:].decode(errors='replace'));print(r.stderr[-1500:].decode(errors='replace'));assert r.returncode==expected
