import hashlib,json,pathlib,subprocess,tarfile
repo=pathlib.Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');root=pathlib.Path(__file__).resolve().parent
base='98187fdf222f393af27b2307667e10427027ad46';frozen='9de5721b5a9c5c0d70b94956305ba76a447a5024'
sha=lambda b:hashlib.sha256(b).hexdigest()
pins={'worker':('7c8fb3ab46b3659ce855e77a80afc161a14f808b491a6753caa6c53231b0d0e6','01cb810875ddfcd1b895df24e688e798c1fe4e9d66364da2be4ea0d6aaeef418','d2f66777cdba8f6375d5958e80ca9204854bbccf151a0c3325cb63e6f91eef4b'),'deployment':('450d049061ae93404145888a34333816e0b274005a0bbbcf6bee4d1764c18740','4f1761718f2197e77ffad96a3ee1467078dccfb9ced0dd6d21b31cec12532397','2edd60e5536a0ed4593e24bf8d079136406c720eb0a2c03abb6ed9178e2c24a6')}
auth=[];saved={}
def open_seal(directory,pin=None,extract=None,base_bound=False):
    mr=(directory/'manifest.json').read_bytes();ir=(directory/'records.json').read_bytes();ar=(directory/'recording.tar.gz').read_bytes();m=json.loads(mr);idx=json.loads(ir);rows=idx['records'] if isinstance(idx,dict) else idx
    actual=(sha(mr),sha(ir),sha(ar));assert actual[1]==m['recordIndexSha256'] and actual[2]==m['archiveSha256']
    if pin is not None:assert actual==tuple(pin),(directory,actual,pin)
    if base_bound:
        for name,raw in [('manifest.json',mr),('records.json',ir),('recording.tar.gz',ar)]:assert raw==subprocess.check_output(['git','show',base+':'+str(directory.relative_to(repo)/name)],cwd=repo)
    expected={v['path']:v for v in rows};assert len(expected)==len(rows)
    bodies={};links={}
    with tarfile.open(directory/'recording.tar.gz','r|gz') as stream:
        for member in stream:
            name=member.name;q=pathlib.PurePosixPath(name);assert not q.is_absolute() and '..' not in q.parts
            assert name in expected and name not in bodies and name not in links
            if member.isfile():bodies[name]=stream.extractfile(member).read()
            else:assert member.islnk();links[name]=member.linkname
    assert set(bodies)|set(links)==set(expected)
    def body(name,seen=()):
        if name in bodies:return bodies[name]
        assert name in links and name not in seen
        raw=body(links[name],seen+(name,));bodies[name]=raw;return raw
    for name,p in expected.items():
        raw=body(name);assert len(raw)==p['bytes'] and sha(raw)==p['sha256'],name
        if extract:
            dest=extract/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
    out={'directory':str(directory.relative_to(repo)),'manifestSha256':actual[0],'indexSha256':actual[1],'archiveSha256':actual[2],'members':len(rows),'decodedBytes':sum(v['bytes'] for v in rows),'archiveBytes':len(ar),'baseBound':base_bound}
    auth.append(out);print(json.dumps(out),flush=True);return m,bodies
for role,pin in pins.items():
    m,b=open_seal(repo/'evidence/virgl-native-dimensional'/role,pin,root/role);assert m['head']==frozen;saved[role]=b
worker_manifest=json.loads((repo/'evidence/virgl-native-dimensional/worker/manifest.json').read_bytes())
for dep in worker_manifest['dependencySeals']:
    d=repo/'evidence'/dep['family']/dep['role'];m,b=open_seal(d,[dep['manifestSha256'],dep['indexSha256'],dep['archiveSha256']],base_bound=True);assert len(b)==dep['reopenedBodies']
    if dep['family']=='virgl-dimensional-storage' and dep['role']=='worker':
        raw=b['cold/recording/receipt.json'];assert raw==saved['worker']['cold/recording/held-dimensional-receipt.json'];(root/'authenticated-d55-receipt.json').write_bytes(raw)
    if dep['family']=='virgl-dimensional-storage' and dep['role']=='verifier':
        for name,raw in b.items():
            if name.startswith('publication/'):
                dest=root/'d55-verifier'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
receipt=json.loads(saved['worker']['cold/recording/receipt.json']);assert receipt['head']==frozen and receipt['base']==base
source_pins={};batch=[]
for name,p in receipt['sources'].items():
    raw=saved['worker']['cold/recording/sources/'+name];assert len(raw)==p['bytes'] and sha(raw)==p['sha256'];assert raw==(repo/name).read_bytes(),name
    source_pins[name]=p;batch.append(frozen+':'+name)
proc=subprocess.run(['git','cat-file','--batch'],cwd=repo,input=('\n'.join(batch)+'\n').encode(),capture_output=True,check=True);raw=proc.stdout;at=0
for name,p in source_pins.items():
    end=raw.index(b'\n',at);header=raw[at:end].split();assert header[1]==b'blob';n=int(header[2]);body=raw[end+1:end+1+n];assert n==p['bytes'] and sha(body)==p['sha256'],name;at=end+n+2
assert at==len(raw)
for name,p in receipt['carriedSources'].items():assert sha((repo/name).read_bytes())==p['sha256']
cold=json.loads(saved['worker']['cold/report.json']);assert cold['head']==frozen and cold['cleanBefore']==cold['cleanAfter']=='' and cold['exitCode']==0
assert cold['receiptSha256']==sha(saved['worker']['cold/recording/receipt.json'])
clone=pathlib.Path(cold['clone']);assert clone.exists();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==frozen
assert not subprocess.check_output(['git','status','--porcelain'],cwd=clone,text=True)
assert (clone/'target/evidence/native-dimensional-cold/receipt.json').read_bytes()==saved['worker']['cold/recording/receipt.json']
assert all(v['exitCode']==v['expected'] for v in receipt['commands']) and len(receipt['commands'])==33
out={'status':'authenticated','seals':auth,'sources':source_pins,'carriedSources':receipt['carriedSources'],'cold':cold,'commands':receipt['commands'],'predictionsSha256':sha((root/'predictions.json').read_bytes()),'runtimeTrackedDiff':subprocess.check_output(['git','diff','--name-only',frozen,'HEAD'],cwd=repo,text=True).splitlines()}
(root/'authentication.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':out['status'],'sources':len(source_pins),'carried':len(receipt['carriedSources']),'coldCloneClean':True}),flush=True)
