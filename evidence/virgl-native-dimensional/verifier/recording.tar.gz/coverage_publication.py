import bisect,hashlib,json,pathlib,re,subprocess,tarfile
root=pathlib.Path(__file__).resolve().parent;repo=pathlib.Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');p=root/'worker/cold/recording';base='98187fdf222f393af27b2307667e10427027ad46';frozen='9de5721b5a9c5c0d70b94956305ba76a447a5024'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert (root/'coverage-reexport.stdout').read_bytes()==(p/'native-coverage.json').read_bytes()
# A warning about extraction mtime does not change the identical digest-bound export.
export=json.loads((root/'coverage-reexport.stdout').read_bytes());rawfiles={}
for block in export['data']:
    for f in block['files']:
        marker='/repo/'
        if marker in f['filename']:rawfiles[f['filename'].split(marker,1)[1]]=f
native=json.loads((p/'changed-coverage.json').read_bytes());coverage=[]
for row in native['runtimeLines']:
    name=row['path'];line=row['line'];source=(repo/name).read_text().splitlines()[line-1];assert source==row['text']
    seg=rawfiles[name]['segments'];points=[(s[0],s[1]) for s in seg]
    for op in row['operands']:
        i=bisect.bisect_right(points,(line,op['column']))-1;assert i>=0;actual=seg[i];assert actual==op['segment'];assert actual[3] and not actual[5] and actual[2]>0 and actual[2]==op['count']
    coverage.append({'file':name,'line':line,'operands':row['operands']})
assert not native['uncoveredOperands']
for waiver in native['waivers']:
    assert (repo/waiver['path']).read_text().splitlines()[waiver['line']-1]==waiver.get('text',(repo/waiver['path']).read_text().splitlines()[waiver['line']-1])
    if waiver.get('segment') is not None:assert not waiver['segment'][3] or waiver['reason'].startswith('static match')
    if 'witness' in waiver:assert any(s[2]>0 and s[3] for s in waiver['witness'])
# Every added native line is explicitly accounted for, without trusting aggregate coverage.
paths=list(dict.fromkeys(x['file'] for x in coverage));accounted={(r['path'],r['line']) for r in native['runtimeLines']+native['waivers']};changed={}
def added(paths):
    out=[];name=None;line=None
    diff=subprocess.check_output(['git','diff','--unified=0',base,frozen,'--',*paths],cwd=repo,text=True)
    for raw in diff.splitlines():
        if raw.startswith('+++ b/'):name=raw[6:]
        elif raw.startswith('@@'):line=int(re.search(r'\+(\d+)',raw)[1])
        elif raw.startswith('+') and name:out.append((name,line,raw[1:]));line+=1
        elif raw.startswith(' '):line+=1
    return out
for name,line,text in added(paths):assert (name,line) in accounted,(name,line,text)
# Reconstruct finest V8 partitions, carried regions and the one static null waiver.
v8=json.loads((p/'coverage-audit.json').read_bytes());d55=json.loads((root/'authenticated-d55-receipt.json').read_bytes());coverage_scripts=[]
for directory in ['hardware','historical-images']:
    raw=json.loads((p/directory/'browser-coverage.json').read_bytes())
    for script in raw.get('scripts',[raw]):coverage_scripts.append((directory,script))
for region in v8['carriedRegions']:
    name=region['source'];before=subprocess.check_output(['git','show',base+':'+name],cwd=repo);after=(repo/name).read_bytes();assert sha(before)==region['baseSourceSha256']==d55['sources'][name]['sha256']
    old=before.decode().encode('utf-16-le')[region['oldStartOffset']*2:region['oldEndOffset']*2].decode('utf-16-le');new=after.decode().encode('utf-16-le')[region['startOffset']*2:region['endOffset']*2].decode('utf-16-le');assert old==new and sha(new.encode())==region['sha256']
for part in v8['executed']+v8['held']+v8['waived']:
    name=part['source'];utf=(repo/name).read_text().encode('utf-16-le');raw=utf[part['startOffset']*2:part['endOffset']*2].decode('utf-16-le');assert raw==part['text'] and sha(raw.encode())==part['sha256'];observed=[]
    for directory,s in coverage_scripts:
        if s['source']!=name:continue
        assert sha((repo/name).read_bytes())==s['sha256']
        ranges=[r for f in s['coverage']['functions'] for r in f['ranges'] if r['startOffset']<=part['startOffset'] and part['endOffset']<=r['endOffset']]
        if ranges:
            size=min(r['endOffset']-r['startOffset'] for r in ranges);observed.append(min(r['count'] for r in ranges if r['endOffset']-r['startOffset']==size))
    assert max(observed,default=0)==part['maxCount']
    if part in v8['executed']:assert part['maxCount']>0
    elif part in v8['held']:assert any(r['source']==name and r['startOffset']<=part['startOffset'] and part['endOffset']<=r['endOffset'] for r in v8['carriedRegions'])
    else:assert raw==': null' and name.endswith('control-bridge.mjs')
assert not v8['needsEvidence']
v8lines={(x['source'],x['line']) for x in v8['executed']+v8['held']+v8['waived']}
for name,line,text in added(['renderer/virgl-command/state.mjs','renderer/virgl-command/control-bridge.mjs']):
    assert (name,line) in v8lines or not text.strip() or text.lstrip().startswith(('/', '*')) or re.fullmatch(r'[\s{}(),;]+',text),(name,line,text)
# Actual bindgen constructor and both wrappers cross the ABI; bodies match frozen source.
wasmjs=(root/'fresh-hardware/source/target/virgl-desktop-submit/pkg/wasm_vm_wasm.js').read_text()
for name in ['standardDimensional','gatherLayeredInput','scatterLayeredOutput']:assert name in wasmjs
wasmproof=[]
hardware=json.loads((root/'fresh-hardware/report.json').read_bytes())['browserResult']['result']
for run in hardware['runs']:
    assert run['metadata']['target'] in [3,4,7];assert any(x['kind']=='layered-input' for x in run['exchanges']) and any(x['kind']=='layered-output' for x in run['exchanges']) and len(run['argumentAttacks'])==12
    wasmproof.append({'seed':run['seed'],'target':run['metadata']['target'],'abiInputs':len([x for x in run['exchanges'] if x['kind']=='layered-input']),'abiOutputs':len([x for x in run['exchanges'] if x['kind']=='layered-output']),'reentrantCalls':'both methods attempted synchronously in each admitted backed beginJob; unchanged checker requires throw'})
# Full staged index is bound to frozen dist or byte-identical held D55 staging.
staging_raw=(root/'deployment/publication/staging-index.json').read_bytes();stage=json.loads(staging_raw);held_raw=(root/'d55-verifier/publication/staging-index.json').read_bytes();held=json.loads(held_raw)
assert sha(held_raw)==stage['heldIndexSha256'];heldfiles={x['path']:x for x in held['records']};files={x['path']:x for x in stage['records']};assert len(files)==stage['fileCount']==304 and sum(x['bytes'] for x in files.values())==stage['bytes']==66437533
assert set(files)==set(heldfiles);changes=[name for name,x in files.items() if x!=heldfiles[name]];assert sorted(changes)==['pkg/wasm_vm_wasm_bg.wasm','roadmap.js','sw.js']
carried={x['path']:x for x in stage['carriedBootManifests']}
for name,pin in files.items():
    source=repo/'web/dist'/name
    if name in carried:
        assert sha(source.read_bytes())==carried[name]['sourceSha256'];assert pin==heldfiles[name] and pin['sha256']==carried[name]['stagedSha256']
    elif source.exists():assert len(source.read_bytes())==pin['bytes'] and sha(source.read_bytes())==pin['sha256'],name
    else:assert pin==heldfiles[name],name
api=json.loads((root/'deployment/publication/publish-success.json').read_bytes());assert api['success'] and api['canonical_deployment']['id']=='9f22c455-fe79-48e1-a0c9-1062f684a74f' and api['canonical_deployment']['environment']=='production' and api['canonical_deployment']['latest_stage']['status']=='success' and api['canonical_deployment']['deployment_trigger']['metadata']['commit_hash']==frozen
live=[]
for directory in ['deployment/live','fresh-live']:
    raw=(root/directory/'report.json').read_bytes();r=json.loads(raw);assert r['status']=='passed' and r['passed']==127 and r['failed']==0 and not r['errors'] and r['proofExportAbsent'] and r['graphicsRoadmapPip']=='cap-pip partial'
    assert r['servedWasmSha256']==files['pkg/wasm_vm_wasm_bg.wasm']['sha256']
    for response in r['served']:
        name=response['path'].lstrip('/');p=root/directory/'bodies'/name;b=p.read_bytes();assert len(b)==response['bytes'] and sha(b)==response['sha256'];mapped='app.html' if name=='app' else name;assert files[mapped]['bytes']==response['bytes'] and files[mapped]['sha256']==response['sha256'],mapped
    live.append({'directory':directory,'reportSha256':sha(raw),'completeResponses':len(r['served']),'servedWasmSha256':r['servedWasmSha256'],'screenshotSha256':sha((root/directory/'browser.png').read_bytes()),'status':'127 passed, 0 failed, partial graphics, no proof exports, zero app errors'})
assert b'ENOENT' in (root/'deployment/publication/refused-local-preflight.log').read_bytes()
# Authenticate the original diagnostic gap archive as well as positive final seals.
d=repo/'evidence/virgl-production-readiness/native-dimensional-transport-gap';mr=(d/'manifest.json').read_bytes();ir=(d/'records.json').read_bytes();ar=(d/'recording.tar.gz').read_bytes();manifest=json.loads(mr);idx=json.loads(ir);rows=idx['records'] if isinstance(idx,dict) else idx
assert sha(ir)=='e220691cc54d72de64e3fbeb36f1a7267fa9f741d9c12174c85a804e37cc66af' and sha(ar)=='b35aa13f43cb33a88b3f4aeaa429545c7da06b34c06e9bf6a66ccf88320cb548'
expected={x['path']:x for x in rows};seen=set()
with tarfile.open(d/'recording.tar.gz','r|gz') as stream:
    for member in stream:
        assert member.isfile() and member.name in expected and member.name not in seen;raw=stream.extractfile(member).read();pin=expected[member.name];assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256'];seen.add(member.name)
assert len(seen)==len(rows)==99
gap={'manifestSha256':sha(mr),'indexSha256':sha(ir),'archiveSha256':sha(ar),'members':len(seen)}
out={'status':'HELD','nativeLines':len(coverage),'nativeOperands':sum(len(x['operands']) for x in coverage),'nativeRawReexportIdentical':True,'native':coverage,'nativeWaivers':native['waivers'],'v8Executed':len(v8['executed']),'v8Held':len(v8['held']),'v8StaticWaivers':v8['waived'],'carriedRegions':v8['carriedRegions'],'wasmAbi':wasmproof,'stagedIndexSha256':sha(staging_raw),'stagedChanges':changes,'heldBootManifests':list(carried),'live':live,'gap':gap,'coldReceipt':'d81c4f46a9d9d13eb61935330560ddba5e5c322ba7368419ed46f2d23d7edb6e'}
(root/'coverage-publication.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['native','nativeWaivers','carriedRegions','wasmAbi']}))
