import hashlib,json,pathlib,re
r=pathlib.Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();file=r/'restored-dimensional-tests.stderr';body=file.read_bytes();points=[];edges=[]
for line,text in enumerate(body.decode().splitlines(),1):
    assert 'panicked at' not in text
    if text.startswith('SUBMIT3D_PORTABLE_RECORD '):
        p=json.loads(text.split(' ',1)[1])
        for family in ('transport','submit'):assert sha(bytes.fromhex(p[family+'Canonical']))==p[family+'Digest']
        if p['case'].startswith('critic-'):
            assert bytes.fromhex(p['response'])==bytes([0xa5])*24
            assert p['usedIndex']==(9 if 'four-mib' in p['case'] else 4)
            points.append(dict(file=file.name,line=line,fileSha256=sha(body),case=p['case'],submitDigest=p['submitDigest'],transportDigest=p['transportDigest'],usedIndex=p['usedIndex'],response=p['response']))
    if text.startswith('NATIVE_DIMENSIONAL_CRITIC_EDGE '):
        m=re.fullmatch(r'NATIVE_DIMENSIONAL_CRITIC_EDGE target=(3|4|7) source=([0-9a-f]+) output=([0-9a-f]+) fullBacking=([0-9a-f]+) used=4 cancelled=1 machineDigest=([0-9a-f]{64})',text);assert m
        target=int(m[1]);source=bytes.fromhex(m[2]);output=bytes.fromhex(m[3]);actual=bytes.fromhex(m[4]);assert source==bytes((i*37+target)&255 for i in range(75));assert output==bytes((i*53+target*11)&255 for i in range(32))
        expected=bytearray(source)
        for i,(src,dst) in enumerate([(0,23),(8,36),(16,54),(24,67)]):expected[dst:dst+8]=output[src:src+8]
        assert actual==expected and len(actual)==75
        edges.append(dict(file=file.name,line=line,fileSha256=sha(body),target=target,bytes=75,sourceSha256=sha(source),outputSha256=sha(output),fullBackingSha256=sha(actual),machineDigest=m[5]))
assert [x['target'] for x in edges]==[3,4,7] and len(points)==7
(r/'final-native-citations.json').write_text(json.dumps(dict(status='HELD',canonical=points,exactSg=edges),indent=2)+'\n');print(json.dumps(dict(status='HELD',exactSg=edges,canonicalPoints=len(points))))
