import hashlib,json,re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
name='renderer/virgl-command/tests/standard-sampler-state.mjs';runs=[];ranges=[];variant=None
for root in sorted((OUT/'promoted-stable').glob('*/report.json')):
    q=json.loads(root.read_bytes());m,=q['mutations'];source=(root.parent/m['variantPath']).read_text()
    normalized=source.replace('seed='+str(q['seed'])+'>>>0','seed=__SEED__>>>0')
    expected=(ROOT/name).read_text().split('export async function runAcceptance')[0]+(ROOT/'tools/virgl-command/standard-sampler-adversarial-body.mjs').read_text()
    assert normalized==expected
    if variant is None:variant=source
    assert len(source)==len(variant)
    script,=[s for s in json.loads((root.parent/'browser-coverage.json').read_bytes())['scripts'] if s['source']==name]
    assert script['sha256']==hashlib.sha256(source.encode()).hexdigest()==m['servedSha256']
    rs=[r for fn in script['coverage']['functions'] for r in fn['ranges']];ranges.append((root.parent.relative_to(OUT).as_posix()+'/browser-coverage.json',rs));runs.append(dict(record=root.relative_to(OUT).as_posix(),seed=q['seed'],status=q['status'],fault=q.get('fault'),sourceSha256=script['sha256']))
start=variant.index('export async function runAcceptance');end=len(variant);bounds={start,end}
for _,rs in ranges:
    for r in rs:
        for key in ['startOffset','endOffset']:
            if start<r[key]<end:bounds.add(r[key])
segments=[]
for left,right in zip(sorted(bounds),sorted(bounds)[1:]):
    text=variant[left:right]
    if not re.sub(r'\s|//[^\n]*','',text):continue
    counters=[]
    for record,rs in ranges:
        enclosing=[r for r in rs if r['startOffset']<=left and right<=r['endOffset']]
        if enclosing:counters.append(dict(record=record,**min(enclosing,key=lambda r:r['endOffset']-r['startOffset'])))
    max_count=max((r['count'] for r in counters),default=0)
    assert max_count>0,(left,right,text)
    segments.append(dict(offsets=[left,right],line=variant[:left].count('\n')+1,text=text,counters=counters,maxCount=max_count))
summary=dict(status='passed',templateSource='tools/virgl-command/standard-sampler-adversarial-body.mjs',templateSha256=hashlib.sha256((ROOT/'tools/virgl-command/standard-sampler-adversarial-body.mjs').read_bytes()).hexdigest(),runs=runs,scope=[start,end],fullNestedRegions=True,unexecuted=0,segments=segments)
(OUT/'promotion-coverage.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Every nested region of the promoted novel body executes:',len(segments),'segments; unexecuted=0')
