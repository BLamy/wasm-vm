import hashlib,json
from pathlib import Path

OUT=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
roots=[OUT/'unpacked'/side/'hardware' for side in ['hot','cold']]
roots.extend(OUT/('matrix-'+str(seed)) for seed in [362436069,521288629,733973753])
roots.extend(OUT/'promoted-stable'/('gpu-'+str(seed)) for seed in [362436069,521288629,733973753])
summary=[]
for root in roots:
    raw=(root/'report.json').read_bytes();q=json.loads(raw);result=q['browserResult']['result'];points=[]
    for i,row in enumerate(result.get('rejections',[])):
        observed=row['result'];assert not observed['ok'] and observed['gpuComplete'] and not observed['draws']
        assert row['dump']['outcomes'][-1]['error']==observed['error']
        if row['label'].startswith('native-sampler-'):
            assert observed['appliedCommands']==0 and observed['error']['code']=='backend-error'
            matches=[(r,run) for r,run in enumerate(result['runs']) if run['faultEvents'] and run['history'][0]['label']==row['label']]
            assert len(matches)==1;r,run=matches[0]
            mode=row['label'].removeprefix('native-sampler-');assert run['faultEvents'][0]['mode']==mode
            if mode=='create':assert not run['nativeSamplers']
            else:assert len(run['nativeSamplers'])==1 and run['nativeSamplers'][0]['deleted']==1
            assert run['final']['renderer']['budgets']['samplers']==0
        else:assert observed['appliedCommands']==1 and observed['error']['code']=='incomplete-draw'
        points.append(dict(jsonPoint='/browserResult/result/rejections/'+str(i),label=row['label'],observed=observed))
    rounds=[]
    for i,row in enumerate(result.get('ownership',[])):
        if row['kind']=='parameter-only':
            _,run=next((r,run) for r,run in enumerate(result['runs']) if run['history'][0]['label']==row['record']['label'])
            assert not run['requests'] and not row['record']['result']['draws']
            assert row['record']['result']['ok'] and row['record']['result']['gpuComplete']
            assert len(run['nativeSamplers'])==1 and run['nativeSamplers'][0]['deleted']==1
            rounds.append(dict(jsonPoint='/browserResult/result/ownership/'+str(i),reversed=row['parameters']['minLod']>row['parameters']['maxLod'],parameters=row['parameters'],observed=row['observed']))
        else:
            renderer=row['point']['renderer'];assert renderer['jobs']['status']=='finishing' and renderer['jobs']['draws']==3
            assert renderer['jobs']['active']==1 and renderer['work']['completedSubmissions']<renderer['work']['submissions']
            assert renderer['budgets']['samplers']>0 and renderer['budgets']['leases']>0
            points.append(dict(jsonPoint='/browserResult/result/ownership/'+str(i),kind=row['kind'],jobs=renderer['jobs'],samplers=renderer['budgets']['samplers'],leases=renderer['budgets']['leases']))
    if result['schema']=='original-core-sampler-state-v1':assert len(rounds)==72 and sum(r['reversed'] for r in rounds)==40 and len(result['rejections'])==3
    else:assert not rounds and len(result['rejections'])==1
    for run in result['runs']:
        assert all(v==0 for owner in ['renderer','resources'] for v in run['final'][owner]['budgets'].values())
        assert run['final']['uniformAccess']['pending']==run['final']['uniformAccess']['submitted']==0
        assert all(s['deleted']==1 for s in run['nativeSamplers'])
    summary.append(dict(record=(root/'report.json').relative_to(OUT).as_posix(),sha256=sha(raw),statePoints=points,nativeParameterOnly=rounds,finalBudgetsZero=True,everySamplerDeletedOnce=True))
(OUT/'state-audit.json').write_text(json.dumps(dict(status='passed',runs=summary),indent=2)+'\n')
print('Allocation/parameter rejection, reversed parameter-only state, pending queued ownership and terminal retirement HELD across',len(summary),'recordings')
