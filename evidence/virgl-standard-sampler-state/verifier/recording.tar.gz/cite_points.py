import hashlib,json,re
from pathlib import Path

OUT=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
plan={
 'wire-audit.json':['/runs/0','/runs/1'],
 'recording-audit.json':['/runs/0/frames/0','/runs/1/frames/0','/runs/2/frames/0','/runs/3/frames/0','/runs/4/frames/0','/runs/5/frames/0'],
 'coverage-regions.json':['/runtimeUnexecuted','/waivers'],
 'promotion-coverage.json':['/unexecuted','/segments'],
 'authentication.json':['/receipts','/boundaries','/carry','/cold'],
 'fresh-custody.json':['/immutableFrozenSources','/runtimeDiffAfterFreeze','/incrementalCarry'],
 'wasm-replay.json':['/actualPairExportCalls','/translations/0'],
 'independent-matrix-audit.json':['/positivePixels','/nativeDraws'],
 'promoted-stable/adversarial-audit.json':['/positivePixels','/nativeDraws'],
 'state-audit.json':['/runs/0/statePoints','/runs/0/nativeParameterOnly/0','/runs/0/finalBudgetsZero'],
 'unpacked/hot/wire/report.json':['/wire/records','/wire/extra/0','/wire/predictions'],
 'unpacked/cold/report.json':['/cloneHead','/statusBefore','/statusAfter','/exitCode'],
 'unpacked/hot/hardware/report.json':['/browserResult/result/frames/0','/browserResult/result/frames/648','/browserResult/result/frames/831','/browserResult/result/rejections/0','/browserResult/result/rejections/1','/browserResult/result/rejections/2','/browserResult/result/ownership/0','/browserResult/result/ownership/72'],
 'unpacked/cold/hardware/report.json':['/browserResult/result/frames/0','/browserResult/result/runs/254/final'],
 'unpacked/hot/fault-wrap/report.json':['/partial/frames/0','/partial/runs/0/history/0/result'],
 'unpacked/hot/fault-filter/report.json':['/partial/frames/0','/partial/runs/0/history/0/result'],
 'unpacked/cold/fault-wrap/report.json':['/partial/frames/0','/partial/runs/0/history/0/result'],
 'unpacked/cold/fault-filter/report.json':['/partial/frames/0','/partial/runs/0/history/0/result'],
 'promoted-stable/gpu-362436069/report.json':['/browserResult/result/frames/5','/browserResult/result/ownership/0','/browserResult/result/runs/0/final'],
 'promoted-stable/gpu-521288629/report.json':['/browserResult/result/frames/5'],
 'promoted-stable/gpu-733973753/report.json':['/browserResult/result/frames/5'],
 'promoted-stable/sabotage-wrap/report.json':['/partial/frames/0','/partial/runs/0/history/0/result'],
 'promoted-stable/sabotage-filter/report.json':['/partial/frames/0','/partial/runs/0/history/0/result'],
 'promoted-final/gpu-521288629/report.json':['/partial/frames/5'],
 'novel-recheck-521288629/report.json':['/partial/frames/5'],
 'interpolation-diagnostic.json':['/result/rows/1/values','/result/rows/1/gpuComplete'],
 'prediction-correction.json':['/observedUpperRightY','/measuredCoordinateModelPixelMismatches','/revisedPredictionBeforeNewRuns'],
}
rows=[];decoder=json.JSONDecoder()
for name,points in plan.items():
    raw=(OUT/name).read_bytes();text=raw.decode();wanted=set(points);found={}
    def white(at):return re.compile(r'\s*').match(text,at).end()
    def walk(at,path):
        at=white(at)
        if path in wanted:found[path]=at
        if not any(p.startswith(path+'/') for p in wanted):return decoder.raw_decode(text,at)[1]
        token=text[at]
        if token=='{':
            at=white(at+1)
            while text[at]!='}':
                key,end=decoder.raw_decode(text,at);at=white(end);assert text[at]==':'
                at=white(walk(at+1,path+'/'+key.replace('~','~0').replace('/','~1')))
                if text[at]==',':at=white(at+1)
                else:assert text[at]=='}'
            return at+1
        if token=='[':
            at=white(at+1);i=0
            while text[at]!=']':
                at=white(walk(at,path+'/'+str(i)));i+=1
                if text[at]==',':at=white(at+1)
                else:assert text[at]==']'
            return at+1
        raise AssertionError((name,path,token))
    walk(0,'');assert wanted==set(found),(name,wanted-set(found))
    rows.extend(dict(record=name,jsonPoint=point,line=text[:at].count('\n')+1,sha256=sha(raw),custody='worker sealed archive via worker-reference.json' if name.startswith('unpacked/') else 'critic sealed archive') for point,at in found.items())
(OUT/'citations.json').write_text(json.dumps(dict(status='passed',points=rows),indent=2)+'\n')
print('Bound',len(rows),'concrete JSON points to exact file lines and record digests')
