import hashlib,json,subprocess,tarfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
WORKER=OUT.parent/'worker'
FROZEN='4e13347405adf4926dd866b9ff434a08420b4784'
BASE='bdad14aff93ba70c09d60ab308df4d2024dce4ba'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT)

manifest=json.loads((WORKER/'manifest.json').read_bytes())
index=json.loads((WORKER/'records.json').read_bytes())
assert sha((WORKER/'recording.tar.gz').read_bytes())==manifest['archiveSha256']=='aeffc0b3a43f7af0232248a1915961a62407002579f1bd69f52513b06c2e4f18'
assert sha((WORKER/'records.json').read_bytes())==manifest['recordIndexSha256']=='15792ac21e635cf3b3e8ab028ad4b79cec13e96703ab20520dd4bf9a46f92e8f'
rows={row['path']:row for row in index['records']}
assert len(rows)==len(index['records'])==manifest['records']==9750
with tarfile.open(WORKER/'recording.tar.gz') as tar:
    assert len(tar.getmembers())==len(rows)
    for member in tar.getmembers():
        assert member.isfile() and member.name in rows and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        raw=tar.extractfile(member).read();row=rows[member.name]
        assert len(raw)==member.size==row['bytes'] and sha(raw)==row['sha256'],member.name
        destination=OUT/'unpacked'/member.name
        destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(raw)

report={'task':'E6-T11d19','status':'passed','archiveSha256':manifest['archiveSha256'],'recordIndexSha256':manifest['recordIndexSha256'],'authenticatedRecords':len(rows),'frozen':FROZEN,'receipts':[],'boundaries':{},'carry':{},'generated':{}}
for prefix in ['hot','cold']:
    root=OUT/'unpacked'/prefix;r=json.loads((root/'receipt.json').read_bytes())
    assert r['status']=='passed' and r['gitHead']==FROZEN and not r['guestExecution'] and not r['productionNegotiation'] and not r['productionDrawAuthority']
    for name,digest in r['files'].items():assert sha((root/name).read_bytes())==digest,(prefix,name)
    for name,digest in r['sources'].items():assert sha(git('show',FROZEN+':'+name))==digest,(prefix,name)
    for name,digest in r['generated'].items():
        assert sha((OUT/'unpacked'/(prefix+'-generated')/name).read_bytes())==digest,(prefix,name)
        assert sha((ROOT/name).read_bytes())==digest,name
        report['generated'].setdefault(name,{})[prefix]=digest
    report['receipts'].append({'record':prefix+'/receipt.json','sha256':sha((root/'receipt.json').read_bytes()),'frozenSources':len(r['sources']),'generated':len(r['generated']),'frames':r['frames'],'nativeDraws':r['nativeDraws'],'pixels':r['pixels']})
    for label in ['hardware','fault-wrap','fault-filter']:
        q=json.loads((root/label/'report.json').read_bytes());served={row['path']:row for row in q['servedFiles']};sources={row['path']:row for row in q['sources']}
        assert q['gitHead']==FROZEN and not q['browser']['headless'] and q['browserErrors']=={'console':[],'page':[],'requests':[]}
        assert q['fixedMemory']==dict(bytes=16777216,stageExport='function',pairExport='function',typedPairExport='function',vertexFormatsExport='function',uniformExport='function',uniformPairExport='function')
        assert not any(any(w in arg.lower() for w in ['swiftshader','llvmpipe','softpipe','lavapipe']) or arg.startswith('--disable-gpu') for arg in q['browser']['commandLine'])
        result=q['partial'] if label!='hardware' else q['browserResult']['result'];assert 'M4' in result['gpu']['renderer'] and 'Metal' in result['gpu']['renderer']
        for name,row in served.items():
            if name=='/':continue
            assert row['sha256']==sources[name[1:]]['sha256'] and row['bytes']==sources[name[1:]]['bytes'],name
        assert '/renderer/virgl-shader/build/wasm/virgl-shader.wasm' in served
        for field in ['browserCoverage','screenshot']:assert sha((root/label/q[field]['path']).read_bytes())==q[field]['sha256']
        for row in json.loads((root/label/'browser-coverage.json').read_bytes())['scripts']:assert row['sha256']==served['/'+row['source']]['sha256']
    for name,digest in r['carriedUnchangedBoundaries'].items():
        before,after=git('show',BASE+':'+name),git('show',FROZEN+':'+name)
        def exclude(raw):
            if name.endswith('decoder.mjs'):return raw[:raw.index(b'function decodeSamplerState(')]+raw[raw.index(b'function decodeObject('):]
            if name.endswith('state.mjs'):
                start=raw.index(b'        if (type === 7) {');return raw[:start]+raw[raw.index(b'        check();',start):]
            return raw
        assert exclude(before)==exclude(after) and sha(exclude(after))==digest
        report['boundaries'][name]=digest
    for name,digest in r['carriedVerifiedEvidence'].items():
        assert sha(git('show',BASE+':'+name))==digest==sha((ROOT/name).read_bytes());report['carry'][name]=digest
    for label,task in [('retained-command-decoder','E6-T12a'),('retained-object-state','E6-T12c'),('retained-standard-state','E6-T11d5')]:
        q=json.loads((root/label/'report.json').read_bytes());assert q['status']=='passed' and q['gitHead']==FROZEN and q['task']==task

cold=json.loads((OUT/'unpacked/cold/report.json').read_bytes())
assert cold['status']=='passed' and cold['gitHead']==cold['cloneHead']==FROZEN and cold['statusBefore']==cold['statusAfter']=='' and cold['exitCode']==0
assert cold['receiptSha256']==sha((OUT/'unpacked/cold/receipt.json').read_bytes()) and cold['logSha256']==sha((OUT/'unpacked/cold/cold.log').read_bytes())
assert b'npm ci --no-audit --no-fund' in (OUT/'unpacked/cold/cold.log').read_bytes() or b'added ' in (OUT/'unpacked/cold/cold.log').read_bytes()
report['cold']=cold
for prefix in ['virgl-standard-buffer-roles/worker','virgl-standard-buffer-roles/verifier','virgl-standard-uniform/worker-offset-repair','virgl-standard-uniform/verifier-offset-repair','virgl-standard-uniform-bindings/worker','virgl-standard-uniform-bindings/verifier']:
    root=ROOT/'evidence'/prefix;m=json.loads((root/'manifest.json').read_bytes())
    assert sha((root/'recording.tar.gz').read_bytes())==m['archiveSha256'] and sha((root/'records.json').read_bytes())==m['recordIndexSha256']
report['authority']='isolated-original-core-sampler-state'
(OUT/'authentication.json').write_text(json.dumps(report,indent=2)+'\n')
(OUT/'worker-reference.json').write_text(json.dumps({'archive':'../worker/recording.tar.gz','archiveSha256':manifest['archiveSha256'],'recordIndex':'../worker/records.json','recordIndexSha256':manifest['recordIndexSha256'],'unpackedPrefix':'unpacked/'},indent=2)+'\n')
print('Authenticated all 9750 worker members, 437 frozen sources per receipt, generated/Wasm/served/V8/cold and inherited exact boundaries')
