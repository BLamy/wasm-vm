import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
FROZEN='4e13347405adf4926dd866b9ff434a08420b4784'
sha=lambda b:hashlib.sha256(b).hexdigest()
sources=['renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs','renderer/virgl-command/tests/standard-sampler-state.mjs','tools/virgl-command/standard-sampler-fixtures.mjs','tools/virgl-command/standard-sampler-oracle.mjs','tools/virgl-command/standard-sampler-pixels.mjs']
summary={'status':'passed','sources':[],'waivers':[]}
for prefix in ['hot','cold']:
    original=json.loads((OUT/'unpacked'/prefix/'coverage-audit.json').read_bytes());scripts=list(original['scripts'])
    for label in ['hardware','fault-wrap','fault-filter']:
        for row in json.loads((OUT/'unpacked'/prefix/label/'browser-coverage.json').read_bytes())['scripts']:scripts.append(dict(record=prefix+'/'+label+'/browser-coverage.json',**row))
    for row in json.loads((OUT/'smoke-positive/browser-coverage.json').read_bytes())['scripts']:scripts.append(dict(record='smoke-positive/browser-coverage.json',**row))
    for folder in [OUT/'unpacked'/prefix/'node-coverage',OUT/('covered-pixels-'+prefix)/'node-coverage']:
        for path in sorted(folder.glob('*.json')):
            for row in json.loads(path.read_bytes())['result']:
                matches=[name for name in sources if row['url'].endswith('/'+name)]
                if not matches:continue
                name,=matches
                frozen=subprocess.check_output(['git','show',FROZEN+':'+name],cwd=ROOT)
                assert (ROOT/name).read_bytes()==frozen
                scripts.append(dict(record=str(path.relative_to(OUT)),source=name,sha256=sha(frozen),coverage=row))
    for name in sources:
        source=subprocess.check_output(['git','show',FROZEN+':'+name],cwd=ROOT).decode();assert len(source.encode('utf-16-le'))//2==len(source)
        if name.endswith('/decoder.mjs'):start,end=source.index('function decodeSamplerState('),source.index('function decodeObject(')
        elif name.endswith('/state.mjs'):
            start=source.index('        if (type === 7) {');end=source.index('        check();',start)
        else:start,end=0,len(source)
        selected=[r for r in scripts if r['source']==name];assert selected and all(r['sha256']==sha(source.encode()) for r in selected)
        bounds={start,end};ranges=[]
        for r in selected:
            all_ranges=[z for fn in r['coverage']['functions'] for z in fn['ranges']];ranges.append((r,all_ranges))
            for z in all_ranges:
                for field in ['startOffset','endOffset']:
                    if start<z[field]<end:bounds.add(z[field])
        segments=[];zero=[];points=sorted(bounds)
        for left,right in zip(points,points[1:]):
            text=source[left:right]
            if not re.sub(r'\s|//[^\n]*','',text):continue
            counters=[]
            for r,all_ranges in ranges:
                enclosing=[z for z in all_ranges if z['startOffset']<=left and right<=z['endOffset']]
                if enclosing:
                    inner=min(enclosing,key=lambda z:z['endOffset']-z['startOffset']);counters.append(dict(record=r['record'],**inner))
            row=dict(line=source[:left].count('\n')+1,offsets=[left,right],text=text,counters=counters,maxCount=max((r['count'] for r in counters),default=0));segments.append(row)
            if row['maxCount']==0:zero.append(row)
        if name in sources[:2]:assert not zero,(prefix,name,zero)
        for row in zero:
            text=row['text'];reason=None
            if name.endswith('standard-sampler-state.mjs'):
                if text==':null':reason='Defensive capture diagnostic for absent native storage; qualified draws require owned complete texels and attributes, independently asserted by the critic audit.'
                elif "physical sampler GPU required" in text:reason='Host diagnostic for a software renderer; every admissible recording is independently authenticated as physical M4 Metal.'
            elif name.endswith('standard-sampler-oracle.mjs'):
                if text=='??[]':reason='Offline empty-hex fallback. Qualified draw histories have complete nonempty original packet bytes; this fallback does not alter product admission.'
                elif 'unqualified original address enum' in text:reason='Oracle diagnostic for an unsupported enum; all original enums are exhaustively admission-tested, and only literal0/2/4 reach physical sampling.'
                elif 'GLES3.0 equation3.18' in text:reason='Documented undefined reversed-LOD sampling diagnostic. Reversed bounds are independently proven by72 native parameter round-trips per run, never by a fabricated pixel prediction.'
                elif text=='return{held:null,misses,defined:false};':reason='Offline comparison for the same intentionally undefined reversed-LOD sampling model; the accepted evidence uses native parameter-only proof for reversed bounds.'
                elif "missing original coordinate immediate" in text or 'original coordinate shape outside oracle' in text:reason='Oracle diagnostics for source outside the task fixture grammar; complete original TGSI and actual native C/Wasm GLSL are independently bound for every qualified draw.'
                elif "original packet truncation" in text:reason='Offline parser diagnostic; malformed-tail atomic rejection is exercised by the production decoder and recorded wire predicate, not accepted physical packets.'
                elif text==':null' and row['line']==69:reason='Offline state-model clearing of a slot that referred to a deleted object. The accepted physical histories rebind before the next successful draw; product deleted-slot rejection is independently exercised by the recorded negative draws.'
                elif text=='ctx.current=0;' and row['line']==73:reason='Offline defensive reset after deleting a selected subcontext. Qualified positive histories switch selection before destruction; product subcontext selection/deletion semantics and dependencies are unchanged inherited boundaries, separately carried by exact source/evidence identity.'
            assert reason is not None,(prefix,name,row)
            summary['waivers'].append(dict(prefix=prefix,source=name,line=row['line'],offsets=row['offsets'],text=text,classification='waived',reason=reason))
        summary['sources'].append(dict(prefix=prefix,source=name,sha256=sha(source.encode()),scope=[start,end],fullNestedRegions=True,segments=segments,unexecuted=len(zero)))
summary['runtimeUnexecuted']=sum(r['unexecuted'] for r in summary['sources'] if r['source'] in sources[:2])
assert summary['runtimeUnexecuted']==0
(OUT/'coverage-regions.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Complete nested sampler runtime regions HELD; test-only diagnostics/defaults have individually cited text/scope waivers:',len(summary['waivers']))
