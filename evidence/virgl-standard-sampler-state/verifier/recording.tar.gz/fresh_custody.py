import gzip,hashlib,json,subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
FROZEN='4e13347405adf4926dd866b9ff434a08420b4784'
FIRST='3d81681fd22caf78639791a5b7f698cd44c13fc6'
PROMOTED='8b9a387a651640e707471d850468e9dd22b10dd7'
BASE='bdad14aff93ba70c09d60ab308df4d2024dce4ba'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==PROMOTED
assert git('diff',FROZEN,'HEAD','--','renderer')==b''
auth=json.loads((OUT/'authentication.json').read_bytes())
receipt=json.loads((OUT/'unpacked/hot/receipt.json').read_bytes())
assert auth['status']=='passed' and receipt['gitHead']==FROZEN
new=['Makefile','tools/verify-virgl-standard-sampler-state-adversarial.mjs',
     'tools/verify-virgl-standard-sampler-state-adversarial.sh',
     'tools/virgl-command/standard-sampler-adversarial-audit.py',
     'tools/virgl-command/standard-sampler-adversarial-body.mjs',
     'tools/virgl-command/standard_sampler_literal_model.py']
original={name:git('show',FROZEN+':'+name) for name in receipt['sources']}
assert all(sha(raw)==receipt['sources'][name] for name,raw in original.items())
for name,raw in original.items():
    if name not in ['Makefile','tasks/epic-6-transcendence/E6-T11d19-standard-sampler-state.md']:
        assert (ROOT/name).read_bytes()==raw,name
for name in new:assert (ROOT/name).read_bytes()==git('show',PROMOTED+':'+name),name
generated={name:(ROOT/name).read_bytes() for name in receipt['generated']}
assert all(sha(raw)==receipt['generated'][name] for name,raw in generated.items())
worker_browser=json.loads((OUT/'unpacked/hot/hardware/report.json').read_bytes())['browser']
browser_digest=sha(Path(worker_browser['executable']).read_bytes())
assert browser_digest==worker_browser['sha256']==json.loads((OUT/'unpacked/cold/hardware/report.json').read_bytes())['browser']['sha256']
versions={name:{ref:git('show',ref+':'+name) for ref in [FIRST,PROMOTED]} for name in new}
roots=[OUT/name for name in ['matrix-362436069','matrix-521288629','matrix-733973753',
       'wire-independent','novel-362436069','novel-recheck-521288629','smoke-positive']]
for name in ['promoted-final','promoted-stable']:
    roots.extend(p.parent for p in sorted((OUT/name).glob('*/report.json')))
records=[];snapshots={}
for root in roots:
    raw=(root/'report.json').read_bytes();q=json.loads(raw);side=root.relative_to(OUT).as_posix()
    assert q['task']=='E6-T11d19' and not q['guestExecution'] and not q['productionNegotiation']
    bindings={}
    for row in q['sources']:
        name=row['path']
        if name in original:source=original[name];boundary='frozen-runtime-and-worker-harness'
        elif name in generated:source=generated[name];boundary='byte-identical-hot-cold-generated'
        else:
            assert name in versions,name
            matches=[ref for ref,body in versions[name].items() if sha(body)==row['sha256']]
            assert matches,(side,name,row['sha256'])
            source=versions[name][matches[-1]];boundary='published-verifier-test-only';row={**row,'matchingPublishedRefs':matches}
        assert [len(source),sha(source)]==[row['bytes'],row['sha256']],(side,name)
        bindings[name]={**row,'boundary':boundary};snapshots.setdefault((boundary,name,sha(source)),source)
    mutations={m['path']:m for m in q.get('mutations',[])}
    assert len(mutations)==len(q.get('mutations',[]))
    if q.get('mode')=='novel':
        assert list(mutations)==['renderer/virgl-command/tests/standard-sampler-state.mjs']
        name=next(iter(mutations));m=mutations[name];source=original[name].decode()
        body_name='tools/virgl-command/standard-sampler-adversarial-body.mjs'
        body=next(raw for raw in versions[body_name].values() if sha(raw)==bindings[body_name]['sha256']).decode()
        variant=(source[:source.index('export async function runAcceptance')]+body.replace('__SEED__',str(q['seed']))).encode()
        assert (root/m['variantPath']).read_bytes()==variant
        assert [m['bytes'],m['servedSha256'],m['originalSha256']]==[len(variant),sha(variant),sha(original[name])]
    else:assert not mutations
    for row in q['servedFiles']:
        name=row['path'][1:]
        if not name:continue
        expected=mutations[name] if name in mutations else bindings[name]
        assert [row['bytes'],row['sha256']]==[expected['bytes'],expected.get('servedSha256',expected.get('sha256'))]
    if 'browser' in q:
        browser=q['browser'];assert browser['sha256']==browser_digest and browser['version']==worker_browser['version'];assert not browser['headless'] and browser['gpu']['featureStatus'].get('webgl2',browser['gpu']['featureStatus'].get('webgl'))=='enabled'
        assert not any(any(k in arg.lower() for k in ['swiftshader','llvmpipe','softpipe','lavapipe']) or arg.startswith('--disable-gpu') for arg in browser['commandLine'])
        assert q['browserErrors']=={'console':[],'page':[],'requests':[]}
        result=q.get('partial') or q['browserResult']['result'];assert 'M4' in result['gpu']['renderer'] and 'Metal' in result['gpu']['renderer']
        assert q['fixedMemory']==dict(bytes=16777216,stageExport='function',pairExport='function',typedPairExport='function',vertexFormatsExport='function',uniformExport='function',uniformPairExport='function')
        for field in ['browserCoverage','screenshot']:assert sha((root/q[field]['path']).read_bytes())==q[field]['sha256']
        coverage=json.loads((root/'browser-coverage.json').read_bytes())
        served={r['path'][1:]:r for r in q['servedFiles']}
        for row in coverage['scripts']:assert row['sha256']==served[row['source']]['sha256']
        for row in result['blobs']:
            packed=(root/row['path']).read_bytes();data=gzip.decompress(packed)
            assert sha(packed)==row['gzipSha256'] and sha(data)==row['sha256'] and len(data)==row['bytes']
        if side.startswith('promoted-stable/'):
            assert q['gitHead']==PROMOTED
            for name,row in bindings.items():assert sha((ROOT/name).read_bytes())==row['sha256']
            assert q['status']==('failed' if q.get('fault') else 'passed')
    else:assert q['status']=='passed' and q['wire']['status']=='passed'
    records.append(dict(record=side+'/report.json',sha256=sha(raw),head=q['gitHead'],mode=q.get('mode'),seed=q.get('seed'),status=q['status'],mutations=list(mutations.values()),bindings=list(bindings.values())))
for name in new:
    source=git('show',PROMOTED+':'+name);snapshots[('published-verifier-test-only',name,sha(source))]=source
snapshot_rows=[]
for (boundary,name,digest),raw in sorted(snapshots.items()):
    path=OUT/'source-snapshots'/digest/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
    snapshot_rows.append(dict(path=path.relative_to(OUT).as_posix(),original=name,boundary=boundary,sha256=digest,bytes=len(raw)))
offline=[]
for side in ['hot','cold']:
    root=OUT/('covered-pixels-'+side)
    assert (root/'physical-audit.json').read_bytes()==(OUT/'unpacked'/side/'physical-audit.json').read_bytes()
    offline.append(dict(record=str(root.relative_to(OUT))+'/physical-audit.json',sha256=sha((root/'physical-audit.json').read_bytes()),sameAsWorker=side+'/physical-audit.json',coverage=[str(p.relative_to(OUT)) for p in sorted((root/'node-coverage').glob('*.json'))]))
summary=dict(status='passed',frozenRuntimeAndHarness=FROZEN,promotedTestHead=PROMOTED,firstPromotedHead=FIRST,immutableFrozenSources=len(original),byteIdenticalGenerated=list(generated),runtimeDiffAfterFreeze=False,nativeBrowser=dict(version=worker_browser['version'],sha256=browser_digest,hotColdFreshCurrentExact=True),records=records,sourceSnapshots=snapshot_rows,coveredOfflineReplays=offline,incrementalCarry='Original runtime and harness bytes remain frozen. Earlier matrix recording heads predate test-only promotion/correction; their exact recorder versions are authenticated against later published test refs, their novel body is unserved in matrix mode, and every executed original runtime/harness source remains identical. Final corrected novel recordings execute the exact committed promoted test head.')
(OUT/'fresh-custody.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Fresh custody HELD:',len(records),'recordings;',len(snapshot_rows),'complete source snapshots; exact committed final test/runtime and covered offline replays')
