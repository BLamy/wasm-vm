import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import createModule from '../../../renderer/virgl-shader/build/wasm/virgl-shader.mjs';
const out=path.dirname(fileURLToPath(import.meta.url)),sha=b=>createHash('sha256').update(b).digest('hex'),records=[];
for(const prefix of ['hot','cold'])for(const name of ['hardware','fault-wrap','fault-filter'])records.push(path.join(out,'unpacked',prefix,name,'report.json'));
for(const name of ['matrix-362436069','matrix-521288629','matrix-733973753'])records.push(path.join(out,name,'report.json'));
for(const name of ['gpu-362436069','gpu-521288629','gpu-733973753','sabotage-wrap','sabotage-filter'])records.push(path.join(out,'promoted-stable',name,'report.json'));
const requests=new Map();
for(const name of records){const q=JSON.parse(await fs.readFile(name)),result=q.partial??q.browserResult.result;for(const [runIndex,run]of result.runs.entries())for(const [index,row]of run.requests.entries()){
 const key=JSON.stringify(row.request);if(requests.has(key))assert.deepEqual(requests.get(key).result,row.result);else requests.set(key,{...row,point:name+'#/'+(q.partial?'partial':'browserResult/result')+'/runs/'+runIndex+'/requests/'+index});
}}
const module=await createModule(),rows=[];assert.equal(module.HEAPU8.byteLength,16777216);
for(const [key,row]of requests){const q=row.request,pointers=[];let value;
 try{
  for(const text of [q.vertexText,q.fragmentText]){const pointer=module._malloc(text.length+1);assert.ok(pointer);pointers.push(pointer);for(let i=0;i<text.length;i++)module.HEAPU8[pointer+i]=text.charCodeAt(i);module.HEAPU8[pointer+text.length]=0;}
  const pointer=module._bridge_translate_standard_uniform_pair(pointers[0],q.vertexText.length,pointers[1],q.fragmentText.length,q.signedMask,q.unsignedMask,q.packedSignedMask,q.packedNormalizedMask,q.bufferZeroMask);value=JSON.parse(module.UTF8ToString(pointer));assert.deepEqual(value,row.result);
 }finally{for(const pointer of pointers.reverse())module._free(pointer);}
 rows.push({point:row.point,requestSha256:sha(key),vertexText:q.vertexText,fragmentText:q.fragmentText,result:value,vertexGLSLSha256:sha(value.vertex.glsl),fragmentGLSLSha256:sha(value.fragment.glsl)});
}
await fs.writeFile(path.join(out,'wasm-replay.json'),JSON.stringify({status:'passed',memoryBytes:module.HEAPU8.byteLength,actualPairExportCalls:rows.length,translations:rows},null,2)+'\n');console.log('Actual 16MiB C/Wasm replay passed:',rows.length,'complete original shader pairs');
