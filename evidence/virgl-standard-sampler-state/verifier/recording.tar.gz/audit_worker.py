import importlib.util,json,math,struct,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools/virgl-command'))
from standard_sampler_literal_model import packets,sampler,parameters
spec=importlib.util.spec_from_file_location('sampler_audit',ROOT/'tools/virgl-command/standard-sampler-adversarial-audit.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
wire=[];physical=[]
for prefix in ['hot','cold']:
    q=json.loads((OUT/'unpacked'/prefix/'wire/report.json').read_bytes());rows=q['wire']['records'];seen=set();admitted=old_admitted=0
    for ordinal,row in enumerate(rows):
        original=list(packets(row['hex']));assert len(original)==1;op,kind,w=original[0];assert [op,kind,w[0]]==[1,7,777]
        p=sampler(w);fields=(p['s'],p['t'],p['r'],p['min'],p['mip'],p['mag']);seen.add(fields)
        valid=all(n in [0,2,4] for n in fields[:3]) and fields[4]<3;old=fields[:2]==(2,2) and fields[2] in [0,2] and fields[4]==2
        assert row['valid']==row['standard']==row['uniform']==valid and row['legacy']==row['old']==old
        admitted+=valid;old_admitted+=old
    assert len(seen)==len(rows)==8192 and admitted==324 and old_admitted==8
    cases=set();negative_zero=0;reversed_bounds=0
    for ordinal,row in enumerate(q['wire']['extra']):
        _,_,w=list(packets(row['hex']))[0];p=sampler(w);f=row['standard']['commands'][0]['fields']
        assert row['standard']['ok'] is True and row['old']['ok'] is False
        assert [f['minLod'],f['maxLod'],f['compareFunction'],f['borderColor']]==[p['minLod'],p['maxLod'],p['compareFunction'],p['border']]
        assert all(math.isfinite(p[k]) for k in ['bias','minLod','maxLod'])
        cases.add((w[3],w[4],p['compareFunction']));negative_zero+=w[3]==0x80000000;reversed_bounds+=p['minLod']>p['maxLod']
    assert len(cases)==288 and negative_zero==48
    assert all(r['held'] for r in q['wire']['predictions'])
    wire.append(dict(record=prefix+'/wire/report.json',enums=8192,admitted=admitted,oldAdmitted=old_admitted,extras=288,negativeZeroOriginals=negative_zero,reversedOriginals=reversed_bounds,invalidAndAtomicPredictions=len(q['wire']['predictions'])))
    for name in ['hardware','fault-wrap','fault-filter']:physical.append(audit.audit(OUT/'unpacked'/prefix/name,prefix+'/'+name))
(OUT/'wire-audit.json').write_text(json.dumps(dict(status='passed',runs=wire),indent=2)+'\n')
(OUT/'recording-audit.json').write_text(json.dumps(dict(status='passed',runs=physical),indent=2)+'\n')
print('Literal original wire and all hot/cold native bytes/shaders/identities/pixels HELD')
