import gzip,hashlib,io,json,tarfile
from pathlib import Path

OUT=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
exclude={'manifest.json','records.json','recording.tar.gz','seal-verification.json'}
files=[p for p in OUT.iterdir() if p.is_file() and p.name not in exclude and p.suffix in ['.py','.mjs','.json','.log']]
for name in ['matrix-362436069','matrix-521288629','matrix-733973753','wire-independent',
             'novel-362436069','novel-recheck-521288629','smoke-positive','promoted-final',
             'promoted-stable','source-snapshots']:
    files.extend(p for p in (OUT/name).rglob('*') if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts)
for name in ['covered-pixels-hot','covered-pixels-cold']:
    files.extend([OUT/name/'physical-audit.json',OUT/name/'acceptance.log'])
    files.extend((OUT/name/'node-coverage').glob('*.json'))
files=sorted(set(files),key=lambda p:p.relative_to(OUT).as_posix())
assert all(p.is_file() and not p.is_symlink() for p in files)
rows=[]
with (OUT/'recording.tar.gz').open('wb') as handle:
    with gzip.GzipFile(fileobj=handle,mode='wb',mtime=0,filename='') as compressed:
        with tarfile.open(fileobj=compressed,mode='w',format=tarfile.USTAR_FORMAT) as tar:
            for path in files:
                raw=path.read_bytes();name=path.relative_to(OUT).as_posix();info=tarfile.TarInfo(name)
                info.size=len(raw);info.mode=0o644;info.mtime=0;info.uid=info.gid=0
                tar.addfile(info,io.BytesIO(raw));rows.append(dict(path=name,bytes=len(raw),sha256=sha(raw)))
index=dict(schema='original-core-sampler-critic-record-index-v1',task='E6-T11d19',frozenRuntimeAndWorkerHarness='4e13347405adf4926dd866b9ff434a08420b4784',promotedTestHead='8b9a387a651640e707471d850468e9dd22b10dd7',records=rows)
(OUT/'records.json').write_text(json.dumps(index,indent=2)+'\n')
manifest=dict(schema='original-core-sampler-critic-evidence-v1',task='E6-T11d19',role='fresh-adversarial-verifier',verdict='verified',frozenRuntimeAndWorkerHarness=index['frozenRuntimeAndWorkerHarness'],promotedTestHead=index['promotedTestHead'],records=len(rows),archiveBytes=(OUT/'recording.tar.gz').stat().st_size,archiveSha256=sha((OUT/'recording.tar.gz').read_bytes()),recordIndexSha256=sha((OUT/'records.json').read_bytes()),workerArchive='../worker/recording.tar.gz',workerArchiveSha256='aeffc0b3a43f7af0232248a1915961a62407002579f1bd69f52513b06c2e4f18',workerRecordIndexSha256='15792ac21e635cf3b3e8ab028ad4b79cec13e96703ab20520dd4bf9a46f92e8f',completeIndependentPositivePixels=267776,actualPositiveNativeDraws=4200,actualNativeSabotageDraws=6,actualWasmCompletePairReplays=7,authority='Only isolated original host-selected standard core sampler admission/native state; one-level2D remains; reversed LOD parameter-only; no guest/caps/API/production/scanout/deployment/performance authority.',unpackedWorkerCustody='References beginning unpacked/ map to corresponding members of the authenticated worker archive via worker-reference.json; unchanged inherited proof digests are recorded in authentication.json. Worker originals are not duplicated in this archive.')
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Sealed',len(rows),'critic records;',manifest['archiveBytes'],'bytes; archive',manifest['archiveSha256'],'index',manifest['recordIndexSha256'])
