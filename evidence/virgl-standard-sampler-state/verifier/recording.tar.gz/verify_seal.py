import hashlib,json,tarfile
from pathlib import Path

OUT=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
m=json.loads((OUT/'manifest.json').read_bytes());j=json.loads((OUT/'records.json').read_bytes());rows={r['path']:r for r in j['records']}
assert sha((OUT/'recording.tar.gz').read_bytes())==m['archiveSha256']
assert sha((OUT/'records.json').read_bytes())==m['recordIndexSha256']
assert len(rows)==len(j['records'])==m['records']
with tarfile.open(OUT/'recording.tar.gz') as tar:
    assert len(tar.getmembers())==len(rows)
    for member in tar.getmembers():
        assert member.isfile() and member.name in rows and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        raw=tar.extractfile(member).read();row=rows[member.name]
        assert member.size==row['bytes']==len(raw) and sha(raw)==row['sha256']==sha((OUT/member.name).read_bytes())
for ref in json.loads((OUT/'citations.json').read_bytes())['points']:
    assert sha((OUT/ref['record']).read_bytes())==ref['sha256']
    if not ref['record'].startswith('unpacked/'):assert rows[ref['record']]['sha256']==ref['sha256']
v=json.loads((OUT/'verdict.json').read_bytes());assert v['verdict']=='verified'
for ref in v['evidence']:assert rows[ref['record']]['sha256']==ref['sha256']
worker=OUT.parent/'worker'
assert sha((worker/'recording.tar.gz').read_bytes())==m['workerArchiveSha256'] and sha((worker/'records.json').read_bytes())==m['workerRecordIndexSha256']
result=dict(status='passed',authenticatedRecords=len(rows),archiveSha256=m['archiveSha256'],recordIndexSha256=m['recordIndexSha256'],workerArchiveSha256=m['workerArchiveSha256'])
(OUT/'seal-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('Every critic archive member, point citation, proof digest and external worker archive authenticates:',len(rows),'records')
