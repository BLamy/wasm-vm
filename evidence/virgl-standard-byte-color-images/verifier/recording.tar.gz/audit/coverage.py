import collections,hashlib,json,pathlib,re,subprocess
ROOT=pathlib.Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=pathlib.Path(__file__).parent;BASE='ac916b7fd0b194c088fe5d54800b24a80a4679ac'
sha=lambda b:hashlib.sha256(b).hexdigest();head='9c15f5b4750e1e100d6c952684d97b9d0ce227ac'
changed={};name=None;line=0
for row in subprocess.check_output(['git','diff','--unified=0',BASE,head,'--','*.mjs'],cwd=ROOT,text=True).splitlines():
 if row.startswith('+++ b/'):name=row[6:]
 elif row.startswith('@@'):line=int(re.search(r'\+(\d+)',row)[1])
 elif row.startswith('+') and name:changed.setdefault(name,[]).append(line);line+=1
 elif row.startswith(' '):line+=1
known=set(changed);scripts=collections.defaultdict(list)
for prefix in ['hot','cold']:
 home=OUT/'unpacked'/prefix
 for fn in home.rglob('*coverage*.json'):
  obj=json.loads(fn.read_text());records=obj.get('scripts',[])
  if 'result' in obj:records=[{'source':next((n for n in known if c['url'].endswith('/'+n)),None),'coverage':c} for c in obj['result']]
  if 'scripts' not in obj and isinstance(obj,dict) and 'coverage' in obj:records=[]
  for r in records:
   source=r.get('source')
   if source not in known:continue
   if r.get('sha256'):assert r['sha256']==sha((ROOT/source).read_bytes()),source
   cov=r['coverage'];ranges=[dict(rr,function=f['functionName']) for f in cov['functions'] for rr in f['ranges']]
   scripts[source].append({'record':fn.relative_to(OUT/'unpacked').as_posix(),'sha256':sha(fn.read_bytes()),'ranges':ranges})
for directory in [OUT/'oracle-v8', OUT/'worker-driver-v8', OUT/'worker-driver-control-v8', OUT/'worker-driver-smoke-v8']:
 for fn in directory.glob('*.json'):
  for cov in json.loads(fn.read_text()).get('result',[]):
   source=next((name for name in known if cov['url'].endswith('/'+name)),None)
   if source:
    scripts[source].append({'record':str(fn.relative_to(OUT)),'sha256':sha(fn.read_bytes()),'ranges':[dict(rr,function=f['functionName']) for f in cov['functions'] for rr in f['ranges']]})
for directory in [OUT/'fresh-boundaries-0x7f4a7c15', OUT/'fresh-smoke', OUT/'fresh-worker-control', ROOT/'target/evidence/virgl-standard-byte-color-verifier-final/novel-0x31415927',ROOT/'target/evidence/virgl-standard-byte-color-verifier-final/novel-0x27182818', ROOT/'target/evidence/virgl-standard-byte-color-verifier-final/fault-native-encoding']:
 for fn in directory.glob('*coverage*.json'):
  obj=json.loads(fn.read_text())
  for r in obj.get('scripts',[]):
   source=r.get('source')
   if source not in known:continue
   assert r['sha256']==sha((ROOT/source).read_bytes()),source
   scripts[source].append({'record':str(fn),'sha256':sha(fn.read_bytes()),'ranges':[dict(rr,function=f['functionName']) for f in r['coverage']['functions'] for rr in f['ranges']]})
regions=[]
for source,lines in changed.items():
 text=(ROOT/source).read_text();ll=text.splitlines(keepends=True);starts=[0]
 for s in ll:starts.append(starts[-1]+len(s.encode('utf-16-le'))//2)
 for line in lines:
  start,end=starts[line-1],starts[line];bounds={start,end}
  for s in scripts[source]:
   for r in s['ranges']:
    if start<r['startOffset']<end:bounds.add(r['startOffset'])
    if start<r['endOffset']<end:bounds.add(r['endOffset'])
  boundaries=sorted(bounds)
  for a,b in zip(boundaries,boundaries[1:]):
   observed=[]
   for s in scripts[source]:
    matching=[r for r in s['ranges'] if r['startOffset']<=a and b<=r['endOffset']]
    if matching:
     smallest=min(matching,key=lambda r:r['endOffset']-r['startOffset']);observed.append({'record':s['record'],'sha256':s['sha256'],**smallest})
   chara=len(text[:].encode('utf-16-le')[:a*2].decode('utf-16-le'));charb=len(text[:].encode('utf-16-le')[:b*2].decode('utf-16-le'))
   snippet=text[chara:charb];count=max((r['count'] for r in observed),default=0)
   regions.append({'source':source,'sourceSha256':sha(text.encode()),'line':line,'start':a,'end':b,'snippet':snippet,'maxNarrowestCount':count,'observed':observed,'class':'executed' if count else 'NEEDS CLASSIFICATION'})
summary=collections.Counter((r['source'],r['class']) for r in regions)
output={'task':'E6-T11d22','sourceHead':head,'rule':'Each complete added-line interval is partitioned at every nested V8 boundary; smallest containing range wins per recording, then union hot/cold healthy custody counts.','regions':regions,'scripts':{k:len(v) for k,v in scripts.items()},'counts':[{'source':s,'class':c,'regions':v} for (s,c),v in sorted(summary.items())]}
(OUT/'coverage-regions.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output['counts'],indent=2))
print('RUNTIME ZERO REGIONS')
for r in regions:
 if r['class']=='NEEDS CLASSIFICATION' and r['source'] in ['renderer/virgl-command/color-images.mjs','renderer/virgl-command/decoder.mjs','renderer/virgl-command/resources.mjs','renderer/virgl-command/state.mjs']:print(r['source'],r['line'],repr(r['snippet']),[(s['function'],s['count']) for s in r['observed'][:3]])
print('HARNESS ZERO REGIONS')
for r in regions:
 if r['class']=='NEEDS CLASSIFICATION' and r['source'].startswith('renderer/virgl-command/tests/standard-byte-color'):print(r['source'],r['line'],repr(r['snippet'][:220]))
