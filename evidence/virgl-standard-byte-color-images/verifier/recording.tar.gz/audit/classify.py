import collections,hashlib,json,pathlib,re,subprocess
R=pathlib.Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');O=pathlib.Path(__file__).parent;BASE='ac916b7fd0b194c088fe5d54800b24a80a4679ac';HEAD='9c15f5b4750e1e100d6c952684d97b9d0ce227ac';sha=lambda b:hashlib.sha256(b).hexdigest()
x=json.loads((O/'coverage-regions.json').read_text());inverse=json.loads((O/'dependency-inverse.json').read_text());deps=json.loads((O/'authentication.json').read_text())['dependencies']
old=lambda name:subprocess.check_output(['git','show',BASE+':'+name],cwd=R)
rigOld=old('renderer/virgl-command/tests/standard-image-rig.mjs');storageOld=old('renderer/virgl-command/tests/standard-texture-storage.mjs')
for row in x['regions']:
 s,l,v=row['source'],row['line'],row['snippet'];row['classificationPoint']=s+':'+str(l)+'@'+str(row['start'])+'-'+str(row['end'])
 if row['maxNarrowestCount']:
  row['class']='executed';row['reason']='Positive count in the narrowest nested region; exact recording SHA and interval are in observed.';continue
 if s.startswith('renderer/virgl-command/') and '/tests/' not in s:
  if s.endswith('resources.mjs') and l==942:
   row['class']='scoped descriptor/type waiver';row['reason']='The immutable admitted descriptor prefix [0,nativePixelBytes) contains only numeric original lanes and implicit one; no admitted prefix contains string zero. Missing R/RG green/blue zero is supplied by the native texture format outside the uploaded prefix. The zero sentinel is generic channel vocabulary and has no reachable upload under these 24 frozen descriptors. Every descriptor, native type and actual prefix was independently reconstructed and exercised.';row['proof']='independent-audit.json#/formats; renderer/virgl-command/color-images.mjs:4-27';continue
  assert v.strip() in old(s).decode(),(s,l,v)
  row['class']='exact D21 HELD carry';row['reason']='Historical profile/depth arm remains byte-identical after the authenticated 55-step inverse; the predecessor boundary and its worker+critic seals are unchanged. The selected color factory does not activate this old arm.';row['carry']={'predecessor':BASE,'sourceSha256':sha(old(s)),'evidence':deps};continue
 if s.startswith('tools/verify-virgl-') and not s.endswith('standard-byte-color-images.mjs'):
  row['class']='scoped transitive-dependency declaration waiver';row['reason']='Adding the pure imported descriptor to an explicit source/module array changes declarative source custody/serve closure; exact reversal proves every historical assertion/control unchanged.';row['proof']='dependency-inverse.json#/historicalSourceDeclarations'
  if s.endswith('command-decoder.mjs') and l==85:
   p=O/'unpacked/hot/retained-command-decoder/report.json';q=json.loads(p.read_text());served=next(z for z in q['servedFiles'] if z['path']=='/renderer/virgl-command/color-images.mjs');assert served['sha256']==sha((R/'renderer/virgl-command/color-images.mjs').read_bytes())
   row['class']='executed actual served endpoint';row['reason']='The affected historical decoder run requested and received this exact module; the report passes with empty errors.';row['proof']={'record':'hot/retained-command-decoder/report.json#/servedFiles/4','sha256':sha(p.read_bytes()),'moduleSha256':served['sha256']}
  continue
 if s.endswith('standard-byte-color-boundaries.mjs'):
  reasons={8:'Symmetric signed -128/-127 canonical endpoint equivalence; the captured hardware canonicalizes expected -128 to observed -127 through the first endpoint arm. Independent oracle independently enforces only these two equivalent endpoints.',11:'Fatal helper FBO diagnostic; all valid admitted physical helper FBOs complete, while real storage/upload/read error behavior is exercised separately.',12:'Adapter restoration of an already-enabled scissor flag; selected native state poisoning/restoration is independently exercised through renderer state. This test helper guard is outside the new renderer boundary.',18:'Optional test helper early return for a cancelled helper draw; the dedicated retained complete/cancel/dispose tests use submit directly and prove cancellation. No runtime branch is hidden.',24:'Denied-extension proxy fallback type shape: only EXT_render_snorm is requested by this qualification call; other properties are bound adapter types, not admitted behavior.'}
  row['class']='scoped test-adapter/type/diagnostic waiver';row['reason']=reasons[l];continue
 if s.endswith('standard-byte-color-images.mjs') and '/tests/' in s:
  row['class']='scoped test type waiver';row['reason']='Synthetic backend methods are empty shape placeholders used solely for admission/layout/allocation limits; byte transfer behavior is independently proved on the actual WebGL2 backend.' if l==12 else 'Symmetric -128/-127 equality fallback; hardware endpoint normalization is independently checked from original signed bytes, with no other equivalence accepted.';continue
 if s.endswith('standard-byte-color-rig.mjs'):
  compact=lambda z:re.sub(r'\s+','',z)
  if l in [6,7] and ('Uint32' in v or '2_10_10_10' in v):
   assert compact(v) in compact(storageOld.decode());row['class']='exact D21 helper carry';row['reason']='Unchanged packed233 native-read helper arm from the authenticated predecessor; packed families remain outside this new byte-format scope.';row['carry']={'source':'renderer/virgl-command/tests/standard-texture-storage.mjs','sha256':sha(storageOld),'predecessor':BASE}
  elif l in [16,51,52,53,54]:
   assert compact(v) in compact(rigOld.decode()),(l,v);row['class']='exact D21 helper carry';row['reason']='Byte-identical historical test scaffold from D21: its packed/native object/copy-level/surface-level fault mode or refused-begin adapter is not a new color claim. New byte-specific storage/upload/read faults and channel/encoding sabotage execute physically.';row['carry']={'source':'renderer/virgl-command/tests/standard-image-rig.mjs','sha256':sha(rigOld),'predecessor':BASE}
  else:
   row['class']='scoped diagnostic/type waiver';row['reason']='Fatal independent helper FBO diagnostic or optional null diagnostic field. Valid physical FBOs and complete lifetimes are independently checked; no admitted numerical/state behavior depends on this guard.'
  continue
 if s.endswith('tools/verify-virgl-standard-byte-color-images.mjs'):
  row['class']='scoped orchestration/diagnostic waiver'
  if 83<=l<=93:
   row['reason']='Playwright serializes this function into the browser; Node V8 does not execute the function body. Recorded browserResult binds the successfully executed callback, its complete native output, and the same callback caught native-control assertion after a completed fence. The function transports acceptance without supplying its numeric oracle.';row['proof']='hot/hardware-matrix/report.json#/browserResult; fresh-worker-control/report.json#/browserResult'
  elif l==96:row['reason']='Same marshalled-browser callback transport for retrieving preserved partial fault state; actual partial report and all blobs are authenticated.';row['proof']='fresh-worker-control/report.json#/partial'
  elif l==58:row['reason']='Unknown-source404 diagnostic; all required served sources are exact and request errors are empty.'
  elif l in [75,76,77]:row['reason']='Error-collection callback is a diagnostic; each healthy and expected native-control run records empty browser console/page/request errors.'
  elif l==94:row['reason']='Time-limit failure diagnostic; bounded physical captures complete below the limit.'
  elif l==124:row['reason']='Final cleanup rejection suppression; successful browser/server cleanup does not take the empty diagnostic catch.'
  else:row['reason']='Optional seed/transport type fallback; the gate always supplies explicit recorded seeds and replay binds each original seed.'
  continue
 if s.endswith('standard-byte-color-pixels.mjs'):
  reasons={15:'Symmetric signed endpoint equivalence diagnostic; original signed bytes are separately independently reconstructed.',23:'Record shape fallback only; each recorded submission includes exact applied command count.',35:'Optional null blend type; all exercised color writes bind explicit blend state.',41:'Redundant selected-subcontext deletion restoration guard; original run restores subcontext0 before deleting7 and independently verifies subsequent draw state.',43:'Default stride type fallback; literal original transfer words supply nonzero logical padded stride.',45:'Default stride type fallback; literal inline subrectangle words supply logical stride.',65:'String reference type alternative; all full capture references are structured, length/digest checked objects.',73:'Optional capture-array shape fallback; every sealed run includes allocations.',79:'Optional capture-array shape fallback; every sealed run includes uploads, including empty arrays.',82:'Default original upload stride type fallback; every capture supplies nonzero logical stride.',85:'Immutable uploaded-prefix zero sentinel; no admitted native prefix contains string zero, independently reconstructed from pinned format declarations.',88:'Optional capture-array shape fallback; every sealed run includes readbacks.',108:'Optional capture-array shape fallback; every recorded owned read has the owned array, including empty arrays.'}
  row['class']='scoped oracle shape/descriptor waiver';row['reason']=reasons[l];row['oracleAuthority']='Coverage only: correctness uses audit.py independently, never this worker helper.';continue
 raise AssertionError(('unclassified',s,l,v))
counts=collections.Counter(r['class'] for r in x['regions']);x['status']='HELD';x['classificationCounts']=dict(counts);x['dependencyInverseSha256']=sha((O/'dependency-inverse.json').read_bytes());(O/'coverage-classification.json').write_text(json.dumps(x,indent=2)+'\n')
# Non-JavaScript changed intervals are individually enumerated; source/line/digest
# remains explicit even when the proof is a declarative or evidence-only waiver.
files=[];source=None;hunks=[]
for line in subprocess.check_output(['git','diff','--unified=0',BASE,HEAD],cwd=R,text=True).splitlines():
 if line.startswith('+++ b/'):source=line[6:]
 elif line.startswith('@@') and source and not source.endswith('.mjs'):
  m=re.search(r'\+(\d+)(?:,(\d+))?',line);hunks.append((source,int(m[1]),int(m[2] or 1)))
for name,line,length in hunks:
 if name.startswith('evidence/virgl-standard-byte-color-images/worker/'):
  category='authenticated proof artifact';reason='All sealed records/member lengths/digests/native bodies and source closures independently authenticated.';proof='authentication.json'
 elif name.startswith('evidence/virgl-production-readiness/'):
  category='scoped declarative planning waiver';reason='Original negative layout/source planning declarations do not grant runtime authority; pinned source bytes and relevant original descriptors independently reconstructed.';proof='independent-audit.json#/formats'
 elif name.endswith('.md'):
  category='scoped documentation/status waiver';reason='Boundary, queue and worker claims are metadata; only independent verdict supplies authority.';proof='predictions.json'
 elif name.endswith('standard-byte-color-boundary.json'):
  category='executed inverse declaration';reason='Every one of55 migration strings reversed and yielded exact three predecessor runtime files.';proof='dependency-inverse.json'
 elif name=='Makefile' or name.endswith('.sh'):
  category='executed acceptance orchestration';reason='Frozen hot and pristine cold logs/receipts show this exact selected gate and all child commands. Shell failure diagnostics are guards, not runtime claims.';proof='hot/acceptance.log; cold/cold.log; authentication.json#/receipts'
 elif name.endswith('.py'):
  category='executed proof harness';reason='Recorded cold/receipt/coverage/seal artifacts identify this exact source, and their success outputs are independently authenticated/reconstructed. Invalid-input, drift, absent-artifact and archive-shape diagnostics are scoped error guards, not renderer claims.';proof='authentication.json; independent-audit.json; coverage-classification.json'
 else:raise AssertionError(name)
 files.append(dict(source=name,line=line,addedLines=length,sha256=sha((R/name).read_bytes()),classification=category,reason=reason,proof=proof))
(O/'coverage-non-js.json').write_text(json.dumps(dict(task='E6-T11d22',status='HELD',sourceHead=HEAD,regions=files),indent=2)+'\n');print(json.dumps(dict(status='HELD',jsRegions=len(x['regions']),counts=dict(counts),nonJsRegions=len(files))))
