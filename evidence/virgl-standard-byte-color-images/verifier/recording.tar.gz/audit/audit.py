"""Independent original-input byte/packet/normalized/color-space audit; no worker oracle imports."""
import collections,copy,gzip,hashlib,json,math,pathlib,re,struct,subprocess
ROOT=pathlib.Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest();ROUND=lambda x:math.floor(x+.5)
HEAD='30908255d0ab91434ff37505852fe6550977a227'
formats={};yaml=(ROOT/'renderer/virgl-shader/vendor/src/gallium/auxiliary/util/u_format.yaml').read_text();hw=(ROOT/'renderer/virgl-shader/vendor/src/virgl_hw.h').read_text()
blocks={m[1]:m[0] for m in re.finditer(r'^- name: (\w+)\n(?:(?!^- name:).)*',yaml,re.M|re.S)}
runtime=(ROOT/'renderer/virgl-command/color-images.mjs').read_text();original=json.loads(re.search(r'export const originalFormats = (\[.*?\]);', (ROOT/'tools/virgl-command/standard-byte-color-fixtures.mjs').read_text(),re.S)[1])
for row in original:
 block=blocks[row['name']];channel=re.search(r'^  channels: \[([^\]]+)\]',block,re.M)[1].split(', ');swizzle=re.search(r'^  swizzles: \[([^\]]+)\]',block,re.M)[1].split(', ')
 enum=int(re.search(r'VIRGL_FORMAT_'+row['name']+r'\s*=\s*(\d+)',hw)[1]);assert enum==row['format'] and row['channels']==channel and row['swizzles']==swizzle
 srgb='colorspace: SRGB' in block;snorm='SN8' in channel;assert row['srgb']==srgb and row['snorm']==snorm
 bpp=len(channel);native=4 if srgb or snorm and bpp==3 else 3 if bpp==4 and swizzle[3]=='1' else bpp
 name='SRGB8_ALPHA8' if srgb else ({1:'R8_SNORM',2:'RG8_SNORM',4:'RGBA8_SNORM'}[native] if snorm else {1:'R8',2:'RG8',3:'RGB8',4:'RGBA8'}[native])
 upload={1:'RED',2:'RG',3:'RGB',4:'RGBA'}[native];type_='BYTE' if snorm else 'UNSIGNED_BYTE';lanes=[v if v in ['0','1'] else 'XYZW'.index(v) for v in swizzle]
 literal=re.search(r'^  \['+str(enum)+r',.*\]',runtime,re.M)[0].strip().rstrip(',');runtimeRow=json.loads(literal)
 assert runtimeRow==[enum,row['name'],bpp,native,name,upload,type_,lanes,swizzle[3]=='1',snorm,srgb],(enum,runtimeRow)
 formats[enum]={'bpp':bpp,'native':native,'swizzle':swizzle,'snorm':snorm,'srgb':srgb,'internal':name,'upload':upload,'type':type_,'source':{'path':'renderer/virgl-shader/vendor/src/gallium/auxiliary/util/u_format.yaml','sha256':sha(yaml.encode()),'line':yaml[:yaml.index(block)].count('\n')+1}}
assert len(formats)==24

def decode_words(hex):
 raw=bytes.fromhex(hex);out=[];at=0
 while at<len(raw):
  h=struct.unpack_from('<I',raw,at)[0];n=h>>16;assert at+4*(n+1)<=len(raw);out.append((h&255,(h>>8)&255,list(struct.unpack_from('<'+'I'*n,raw,at+4)),at));at+=4*(n+1)
 assert at==len(raw);return out
f32=lambda x:struct.unpack('<f',struct.pack('<I',x))[0]
def mip_sizes(m):
 w,h=m['width'],m['height'];out=[]
 for level in range(m['lastLevel']+1):out.append((w,h));w,h=max(1,w//2),max(1,h//2)
 return out

def source(m,seed):
 p=formats[m['format']];pool=[128,129,160,192,255,0,1,31,63,96,126,127] if p['snorm'] else [2,19,127,231,253,0,61,173,251,11,233,255]
 rows=[];length=5
 for level,(w,h) in enumerate(mip_sizes(m)):
  data=bytes(pool[(x*3+y*5+k*7+level*2+(seed&0xffffffff)%12)%12] for y in range(h) for x in range(w) for k in range(p['bpp']))
  stride=w*p['bpp']+3;rows.append({'w':w,'h':h,'data':bytearray(data),'offset':length,'stride':stride});length+=(h-1)*stride+w*p['bpp']+5
 backing=bytearray([23]*length)
 for plane in rows:
  rb=plane['w']*p['bpp']
  for y in range(plane['h']):backing[plane['offset']+y*plane['stride']:plane['offset']+y*plane['stride']+rb]=plane['data'][y*rb:(y+1)*rb]
 return rows,backing

def rgba_bytes(p,data,canonical=True):
 out=[]
 for i in range(len(data)//p['bpp']):
  for v in p['swizzle']:
   value=0 if v=='0' else 127 if v=='1' and p['snorm'] else 255 if v=='1' else data[i*p['bpp']+'XYZW'.index(v)]
   out.append(129 if canonical and p['snorm'] and value==128 else value)
 return bytes(out)

def guest_bytes(p,data):
 rgba=rgba_bytes(p,data);out=[]
 for i in range(len(data)//p['bpp']):
  for k in range(p['bpp']):out.append(rgba[i*4+p['swizzle'].index('XYZW'[k])] if 'XYZW'[k] in p['swizzle'] else 255)
 return bytes(out)
linearize=lambda v:v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4
encode=lambda v:12.92*v if v<=.0031308 else 1.055*v**(1/2.4)-.055

def texel(p,plane,x,y):
 raw=rgba_bytes(p,plane['data'],False);at=(min(plane['h']-1,max(0,y))*plane['w']+min(plane['w']-1,max(0,x)))*4
 values=[max(-1,(v if v<128 else v-256)/127) if p['snorm'] else v/255 for v in raw[at:at+4]]
 return [linearize(v) if p['srgb'] and k<3 else v for k,v in enumerate(values)]

def sample(p,planes,view,par,coord):
 lod=min(par['maxLod'],max(par['minLod'],0));first,last=view['range'];maxlevel=last-first
 filt=par['mag'] if lod<=0 else par['min']
 def spatial(l):
  plane=planes[first+l];x=coord[0]*plane['w'];y=coord[1]*plane['h']
  if not filt:return texel(p,plane,math.floor(x),math.floor(y))
  xx,yy=x-.5,y-.5;a,b=math.floor(xx),math.floor(yy);dx,dy=xx-a,yy-b
  colors=[texel(p,plane,a,b),texel(p,plane,a+1,b),texel(p,plane,a,b+1),texel(p,plane,a+1,b+1)];weights=[(1-dx)*(1-dy),dx*(1-dy),(1-dx)*dy,dx*dy]
  return [sum(w*c[k] for w,c in zip(weights,colors)) for k in range(4)]
 if lod<=0 or par['mip']==2:result=spatial(0)
 elif par['mip']==0:result=spatial(min(maxlevel,max(0,math.floor(lod+.5))))
 else:
  clamped=min(maxlevel,max(0,lod));a=math.floor(clamped);f=clamped-a;l,r=spatial(a),spatial(min(maxlevel,a+1));result=[x*(1-f)+y*f for x,y in zip(l,r)]
 return [0 if sw==4 else 1 if sw==5 else result[sw] for sw in view['swizzle']]

def expected_frame(p,e):
 vs,fs=e['shaders'];imm=lambda text,n:[f32(struct.unpack('<I',struct.pack('<f',float(v)))[0]) for v in re.search(r'IMM\['+str(n)+r'\] FLT32 \{([^}]+)\}',text)[1].split(',')]
 scale,offset,coord=imm(vs,0),imm(vs,1),imm(vs,2);assert scale==[0,0,0,0] and offset==coord==[.25,.25,0,0]
 assert 'TEX OUT[2], IMM[2], SAMP[0], 2D' in vs
 assert 'TEX TEMP[0], IN[0], SAMP[0], 2D' in fs and 'ADD TEMP[0], TEMP[0], IN[1]' in fs
 assert ('MAD OUT[0], TEMP[0], IMM[0], IMM[0]' in fs)==p['snorm']
 assert imm(fs,0)==[.5]*4
 a=sample(p,e['planes'],e['vs'],e['p'],coord);b=sample(p,e['planes'],e['fs'],e['p'],offset)
 return bytes(max(0,min(255,ROUND(((x+y)/4+.5 if p['snorm'] else (x+y)/2)*255))) for x,y in zip(a,b))

def stored(p,linear):
 return bytes(0 if v=='0' else 255 if v=='1' else ROUND(min(1,max(0,encode(linear[k]) if p['srgb'] and k<3 else linear[k]))*255) for k,v in enumerate(p['swizzle']))

def sampler(w):
 z=w[1];return {'s':z&7,'t':(z>>3)&7,'r':(z>>6)&7,'min':(z>>9)&1,'mip':(z>>11)&3,'mag':(z>>13)&1,'minLod':f32(w[3]),'maxLod':f32(w[4]),'compareFunction':(z>>16)&7}

counts=collections.Counter();reports=[];citations=[];faults=[]
def compare(a,b,p=None,tol=0):return len(a)==len(b) and all(abs(x-y)<=tol or p and p['snorm'] and x in [128,129] and y in [128,129] for x,y in zip(a,b))
def check(condition,kind,point):
 counts[kind]+=1
 if not condition:raise AssertionError(kind+' '+point)

def replay(run,planes,backing,p,blob,point):
 contexts={};events=[];sub=lambda:{'obj':{},'view':[[None],[None]],'sampler':[[None],[None]],'shader':[None,None],'surface':None,'blend':None}
 for j,record in enumerate(run['history']):
  ctx=contexts.setdefault(record['ctx'],{'current':0,'subs':{0:sub()}});packets=decode_words(record['hex']);limit=record.get('appliedBeforeDispose',record.get('result',{}).get('appliedCommands',len(packets)))
  for op,kind,w,at in packets[:limit]:
   s=ctx['subs'][ctx['current']]
   if op==1:
    obj={'kind':kind}
    if kind==6:obj.update(resource=w[1],format=w[2]&0xffffff,target=w[2]>>24,range=[w[4]&255,w[4]>>8],swizzle=[(w[5]>>(3*k))&7 for k in range(4)])
    elif kind==7:obj.update(sampler(w))
    elif kind==8:obj.update(resource=w[1],format=w[2],level=w[3])
    elif kind==1:obj.update(word=w[3],mask=(w[3]>>27)&15)
    elif kind==4:
     raw=struct.pack('<'+'I'*len(w[5:]),*w[5:]);obj.update(text=raw[:w[2]-1].decode(),stage=w[1]);check(raw[w[2]-1]==0,'shader-terminated',point+'/history/'+str(j))
    s['obj'][w[0]]=obj
   elif op==3:s['obj'].pop(w[0],None)
   elif op==2 and kind==1:s['blend']=s['obj'][w[0]] if w[0] else None
   elif op in [10,18]:
    dest=s['view'] if op==10 else s['sampler'];stage,start=w[:2]
    for k,h in enumerate(w[2:]):
     while len(dest[stage])<=start+k:dest[stage].append(None)
     dest[stage][start+k]=s['obj'][h] if h else None
   elif op==31:s['shader'][w[1]]=s['obj'][w[0]]
   elif op==5:s['surface']=s['obj'][w[2]] if len(w)>2 and w[2] else None
   elif op==29:ctx['subs'][w[0]]=sub();ctx['current']=w[0]
   elif op==28:ctx['current']=w[0]
   elif op==30:ctx['subs'].pop(w[0]);ctx['current']=0 if ctx['current']==w[0] else ctx['current']
   elif op in [9,43] and w[0]==6 and (op==9 or w[12]==1):
    plane=planes[w[1]];stride=w[3] or plane['w']*p['bpp'];data=backing if op==43 else struct.pack('<'+'I'*len(w[11:]),*w[11:]);offset=w[11] if op==43 else 0
    for y in range(w[9]):
     dest=((w[6]+y)*plane['w']+w[5])*p['bpp'];src=offset+y*stride;plane['data'][dest:dest+w[8]*p['bpp']]=data[src:src+w[8]*p['bpp']]
   elif op==7 and w[0]&4 and s['surface']:events.append({'kind':'clear','index':j,'label':record['label'],'surface':copy.deepcopy(s['surface']),'linear':list(map(f32,w[1:5])),'blend':copy.deepcopy(s['blend'])})
   elif op==8:
    par=copy.deepcopy(s['sampler'][0][0]);check(par==s['sampler'][1][0],'dual-sampler-original-words',point+'/history/'+str(j))
    events.append({'kind':'draw','index':j,'label':record['label'],'vs':copy.deepcopy(s['view'][0][0]),'fs':copy.deepcopy(s['view'][1][0]),'p':par,'planes':copy.deepcopy(planes),'surface':copy.deepcopy(s['surface']),'blend':copy.deepcopy(s['blend']),'shaders':[s['shader'][0]['text'],s['shader'][1]['text']]})
  for change in run.get('changes',[]):
   if change['kind']=='gpu-only-clear' and change['afterHistory']==j:
    plane=planes[change['level']];check(blob(change['before'])==bytes(plane['data']),'gpu-mutation-original-before',point+'/changes')
    rgba=[(ROUND(max(-1,min(1,v))*127)&255) if p['snorm'] else ROUND((encode(v) if p['srgb'] and k<3 else v)*255) for k,v in enumerate(change['linear'])]
    pixel=bytes(rgba[p['swizzle'].index('XYZW'[k])] if 'XYZW'[k] in p['swizzle'] else 255 for k in range(p['bpp']));plane['data']=bytearray(pixel*plane['w']*plane['h'])
    check(blob(change['expected'])==bytes(plane['data']),'gpu-mutation-original-after',point+'/changes');check(compare(blob(change['native']),rgba_bytes(p,plane['data']),p),'gpu-mutation-native-after',point+'/changes');check(change['uploadsBefore']==len(run['uploads']),'gpu-only-no-upload',point+'/changes');counts['texels']+=plane['w']*plane['h']
 return events

for prefix in ['hot','cold']:
 home=OUT/'unpacked'/prefix
 wire=json.loads((home/'wire/report.json').read_text())['wire'];check(len(wire['records'])==192,'wire-corpus-count',prefix+'/wire')
 for j,row in enumerate(wire['records']):
  p=formats[row['format']];point=prefix+'/wire/report.json#/wire/records/'+str(j)
  if row['kind'] in ['view','surface']:
   op,kind,w,at=decode_words(row['hex'])[0];check(op==1 and kind==({'view':6,'surface':8}[row['kind']]) and w[1]==6,'literal-original-object',point);check(not row['original']['ok'] and row['selected']['ok']==(kind==6 or not p['snorm']),'explicit-selected-role',point)
  elif row['kind']=='layout':
   l=row['layout'];read=row['fields']['direction']==2;check(l['rowBytes']==3*p['bpp'] and l['tightBytes']==6*p['bpp'] and l['scratchBytes']==6*(4 if read else max(p['bpp'],p['native'])) and l['stagingBytes']==(24 if read else 0),'logical-native-layout',point)
  else:
   exact=row['boundary'].endswith('exact');key=next(iter(row['limits']));charge=42*(max(p['bpp'],p['native']) if key=='resourceBytes' else p['native']);check(row['limits'][key]==charge-(not exact) and row['result']['ok']==exact and row['allocations']==int(exact),'one-byte-allocation-boundary',point)
   if exact:check(row['result']['resource']['byteLength']==42*p['bpp'] and row['result']['resource']['gpuByteLength']==42*p['native'],'separate-metadata-charge',point)
 for directory in sorted(home.iterdir()):
  if not directory.is_dir() or not directory.name.startswith(('hardware-','fault-')):continue
  report=json.loads((directory/'report.json').read_text());data=report['browserResult'].get('result',report.get('partial'));fault=directory.name.startswith('fault-');point=prefix+'/'+directory.name+'/report.json';blobmap={b['key']:gzip.decompress((directory/b['path']).read_bytes()) for b in data['blobs']};blob=lambda ref:blobmap[ref['key']]
  reportcounts=counts.copy();localfaults=[]
  if 'extensionRefusal' in data:check(data['extensionRefusal']['ok'] is False and data['extensionRefusal']['error']['code']=='unsupported-host','actual-extension-qualification-refusal',point+'#/browserResult/result/extensionRefusal')
  for ri,run in enumerate(data['runs']):
   loc=point+'#/'+('partial' if fault else 'browserResult/result')+'/runs/'+str(ri);m=run['metadata'];p=formats[m['format']];planes,backing=source(m,run['originalSeed']);check(blob(run['backing'])==bytes(backing),'original-backing-regeneration',loc+'/backing')
   for plane in run['planes']:
    expected=planes[plane['level']];check(blob(plane['input'])==bytes(expected['data']) and plane['width']==expected['w'] and plane['height']==expected['h'] and plane['offset']==expected['offset'] and plane['stride']==expected['stride'],'original-plane-layout',loc+'/planes')
   originalPlanes=copy.deepcopy(planes);events=replay(run,planes,backing,p,blob,loc);drawEvents=[e for e in events if e['kind']=='draw']
   for change in run.get('changes',[]):
    if change['kind']=='format-refusal':check(change['result']['ok'] is False and change['result']['error']['code']=='incompatible-resource','explicit-original-format-refusal',loc+'/changes')
   def observe(raw,expected,kind,at,tol=0,signed=False):
    okay=compare(raw,expected,p if signed else None,tol);counts[kind]+=1
    if not okay:
     misses=[{'byte':i,'actual':x,'expected':y} for i,(x,y) in enumerate(zip(raw,expected)) if abs(x-y)>tol and not (signed and p['snorm'] and x in [128,129] and y in [128,129])][:8]
     if fault:localfaults.append({'point':at,'kind':kind,'misses':misses})
     else:raise AssertionError(kind+' '+at+' '+str(misses))
   for ai,a in enumerate(run['allocations']):
    meta=a['metadata']
    if meta['format']!=m['format'] or meta['target']!=2:continue
    count=sum(w*h for w,h in mip_sizes(meta));check(meta['byteLength']==count*p['bpp'] and meta['gpuByteLength']==count*p['native'] and meta['pixelBytes']==p['bpp'],'native-allocation-charges',loc+'/allocations/'+str(ai))
    e=next(e for e in run['imageEvents'] if e['name']=='texStorage2D' and e['texture']==a['texture']);name='RGBA8' if directory.name=='fault-srgb-storage' else p['internal'];check(e['args']==[3553,meta['lastLevel']+1,data['nativeEnums'][name],meta['width'],meta['height']],'actual-native-storage-selection',loc+'/allocations/'+str(ai))
   for ui,u in enumerate(run['uploads']):
    if run.get('kind')=='actual-native-error':continue
    t,l,x,y,w,h,fmt,ty=u['args'];check(t==3553 and fmt==data['nativeEnums'][p['upload']] and ty==data['nativeEnums'][p['type']] and u['type']==('Int8Array' if p['snorm'] else 'Uint8Array'),'typed-native-upload-selection',loc+'/uploads/'+str(ui))
    hist=next(hh for hh in run['history'] if hh['label']==u['label']);cmd=next(cmd for cmd in decode_words(hist['hex']) if cmd[0] in [9,43] and cmd[2][0]==6 and cmd[2][1]==l and cmd[2][5]==x and cmd[2][6]==y and cmd[2][8]==w and cmd[2][9]==h);op,kind,ww,offset=cmd;stride=ww[3] or originalPlanes[l]['w']*p['bpp'];src=backing if op==43 else struct.pack('<'+'I'*len(ww[11:]),*ww[11:]);start=ww[11] if op==43 else 0;dense=b''.join(src[start+j*stride:start+j*stride+w*p['bpp']] for j in range(h));rgba=rgba_bytes(p,dense,False);expected=b''.join(rgba[j*4:j*4+p['native']] for j in range(w*h));observe(blob(u['bytes']),expected,'actual-native-upload-bytes',loc+'/uploads/'+str(ui))
   for rdi,read in enumerate(run['readbacks']):
    if run.get('kind')=='actual-native-error':continue
    at=loc+'/readbacks/'+str(rdi)
    if read.get('name')!='getBufferSubData':
     check(read['args'][4:6]==[data['nativeEnums']['RGBA'],data['nativeEnums'][p['type']]],'typed-native-read-selection',at);check(read['type'] in ['PBO','Int8Array' if p['snorm'] else 'Uint8Array'],'typed-native-read-array',at)
    if read.get('bytes'):
     raw=blob(read['bytes']);candidate=[plane for plane in originalPlanes if plane['w']*plane['h']*4==len(raw)];check(len(candidate)==1,'full-native-read-plane-dimensions',at)
     dense=candidate[0]['data'] if run['uploads'] else bytes(len(candidate[0]['data']));observe(raw,rgba_bytes(p,dense),'independent-full-native-readback-bytes',at,signed=True)

   for fi,frame in enumerate(data['frames']):
    if frame['run']!=ri:continue
    at=point+'#/'+('partial' if fault else 'browserResult/result')+'/frames/'+str(fi);e=next(e for e in drawEvents if e['index']==frame['historyIndex']);check(frame['wire']==run['history'][e['index']]['hex'] and frame['vs']==e['vs']['range'] and frame['fs']==e['fs']['range'] and frame['vertexSwizzle']==e['vs']['swizzle'] and frame['fragmentSwizzle']==e['fs']['swizzle'],'original-draw-frame-binding',at)
    check(all(e['p'][k]==v for k,v in frame['p'].items()),'original-sampler-frame-binding',at);check(run['history'][e['index']]['result']['gpuComplete'],'owned-frame-gpu-completion',at)
    wanted=expected_frame(p,e);observe(blob(frame['pixels']),wanted*64,'independent-completed-frame-pixels',at,tol=1);counts['pixels']+=64
    for binding in frame['bindings']:
     view=e['fs'] if binding['stage'] else e['vs'];check(binding['range']==view['range'],'native-view-original-range',at+'/bindings')
     for plane in binding['planes']:
      original=e['planes'][plane['original']];check(plane['width']==original['w'] and plane['height']==original['h'],'native-plane-original-dimensions',at+'/bindings');observe(blob(plane['native']),rgba_bytes(p,original['data']),'independent-complete-native-plane',at+'/bindings',signed=True);counts['texels']+=original['w']*original['h']
   for di,d in enumerate(run['draws']):
    e=next(e for e in drawEvents if e['label']==d['label']);at=loc+'/draws/'+str(di);parameters=e['p'];check(d['args']==[4,0,3] and d['native']['level']==e['surface']['level'],'actual-native-original-draw',at)
    for sam in d['samplers']:
     vv=e['vs'] if sam['unit']==16 else e['fs'];plane=e['planes'][vv['range'][0]];np=sam['parameters'];check(sam['base']==0 and sam['last']==vv['range'][1]-vv['range'][0] and sam['metadata']['width']==plane['w'] and sam['metadata']['height']==plane['h'],'actual-native-draw-view',at)
     expectedMin=[[9984,9986,9728],[9985,9987,9729]][parameters['min']][parameters['mip']];check(np['TEXTURE_MIN_FILTER']==expectedMin and np['TEXTURE_MAG_FILTER']==9728+parameters['mag'] and np['TEXTURE_MIN_LOD']==parameters['minLod'] and np['TEXTURE_MAX_LOD']==parameters['maxLod'] and all(np[k]==33071 for k in ['TEXTURE_WRAP_S','TEXTURE_WRAP_T','TEXTURE_WRAP_R']),'native-sampler-independent-enums',at);observe(blob(sam['texels']),rgba_bytes(p,plane['data']),'independent-pre-draw-native-texels',at,signed=True);counts['texels']+=plane['w']*plane['h']
    implicit=e['surface']['format']==m['format'] and p['swizzle'][3]=='1';mask=e['blend']['mask'] if e['blend'] else 15;check(d['native']['mask']==[bool(mask&(1<<k)) and not(k==3 and implicit) for k in range(4)],'actual-native-original-color-mask',at)
    for sh in d['shaders']:check(sh['glsl'].startswith('#version 300 es\n') and 'texture(' in sh['glsl'],'complete-native-shader-body',at)
    for a in d['attributes']:
     original=next(x for x in run['exchanges'] if x['direction']=='upload' and x['resource']['id']==3);check(blob(a['bytes'])==blob(original['blob']) and a['stride']==16 and a['offset']==0,'actual-native-original-geometry',at)
    counts['draws']+=1
   for si,frame in enumerate(run.get('surfaceFrames',[])):
    at=loc+'/surfaceFrames/'+str(si);e=next(e for e in events if e['index']==frame['historyIndex'] and e['kind']==('clear' if frame['kind']=='clear' else 'draw'));clearEvent=next(e for e in events if e['kind']=='clear' and e['label']=='original-clear-color-surface');initial=stored(p,clearEvent['linear']);expected=initial
    if frame['kind']!='clear':
     color=sample(p,e['planes'],e['vs'],e['p'],[.25,.25]);check(e['vs']==e['fs'],'surface-dual-original-sample',at);expected=stored(p,color)
     if frame['kind']=='blend-mask':
      blend=e['blend']['word'];check(blend&1 and (blend>>4)&31==3 and (blend>>9)&31==19 and (blend>>27)&15==5,'original-blend-factor-mask-words',at);dest=[linearize(v/255) if p['srgb'] and k<3 else v/255 for k,v in enumerate(initial)];mixed=[v*color[3]+dest[k]*(1-color[3]) for k,v in enumerate(color)];pred=stored(p,mixed);expected=bytes(pred[k] if k in [0,2] else initial[k] for k in range(4))
    check(bytes(frame['expected'])==expected,'worker-surface-expected-independent',at);observe(blob(frame['pixels']),expected*16,'independent-encoded-masked-blended-surface',at,tol=1);counts['pixels']+=16
   for ti,tr in enumerate(run.get('transfers',[])):
    at=loc+'/transfers/'+str(ti);op,kind,w,offset=decode_words(tr['wire'])[0];plane=originalPlanes[w[1]];expect=guest_bytes(p,plane['data']);check(op==43 and w[12]==2 and tr['layout']['rowBytes']==plane['w']*p['bpp'] and tr['layout']['tightBytes']==len(expect) and tr['layout']['scratchBytes']==plane['w']*plane['h']*4==tr['layout']['stagingBytes'],'original-read-logical-physical-layout',at)
    for name in ['sync','staged']:observe(blob(tr[name]),expect,'independent-original-'+name+'-read',at,signed=True)
    check(tr['fenceCompleted'],'original-staged-complete',at);counts['transfers']+=1
    for owned in tr['owned']:
     op,kind,w,offset=decode_words(owned['wire'])[0];check(op==owned['opcode'] and w[0]==6 and w[1]==plane.get('level',tr['level']) and owned['exchange']['resource']['id']==(8 if op==45 else 6) and owned['exchange']['layout']['rowStride']==plane['stride'] and owned['exchange']['layout']['offset']==plane['offset'] and owned['fenceCompleted'],'owned-original43-45-logical-address',at);observe(blob(owned['exchange']['blob']),expect,'independent-owned-original-output',at,signed=True);counts['transfers']+=1
   for name,origin in [('finalBacking',backing),('finalStagingBacking',blob(run['stagingBacking']) if 'stagingBacking' in run else None)]:
    if name not in run:continue
    expected=bytearray(origin)
    for plane in originalPlanes:
     dense=guest_bytes(p,plane['data']);rb=plane['w']*p['bpp']
     for y in range(plane['h']):expected[plane['offset']+y*plane['stride']:plane['offset']+y*plane['stride']+rb]=dense[y*rb:(y+1)*rb]
    observe(blob(run[name]),expected,'independent-full-logical-backing-padding',loc+'/'+name,signed=True)
   if run.get('retiredExpected'):
    draw=run['draws'][-1];e=next(e for e in drawEvents if e['label']==draw['label']);retired=next(x for x in run['retiredPlanes'] if x['texture']==draw['native']['attachment']);check(retired['fencePoint']['actual'] in [37146,37148] and retired['fencePoint']['delivered'] in [37146,37148],'retired-target-real-consumed-fence',loc+'/retiredPlanes');observe(blob(retired['pixels']),expected_frame(p,e)*64,'independent-retained-old-generation-output',loc+'/retiredPlanes',tol=1);counts['pixels']+=64
   creation={e['sync']:e for e in run['events'] if e['name']=='fenceSync'};finished={}
   for j,e in enumerate(run['events']):
    if e['name']=='clientWaitSync' and e['delivered'] in [37146,37148]:
     check(e['actual'] in [37146,37148] and e['turn']>creation[e['sync']]['turn'],'real-later-task-fence',loc+'/events/'+str(j));finished[e['sync']]=e
   counts['physicalFences']+=len(finished)
   check(all(v==0 for v in run['final']['resources']['budgets'].values()) and all(v==0 for v in run['final']['renderer']['budgets'].values()) and all(o['deleted']==1 for o in run['nativeObjects']),'native-lifetime-terminal-cleanup',loc+'/final')
   if run.get('kind')=='physical-read-budget':
    actions=run['actions'];budget=run['budget'];prepare=actions[0];check(prepare['result']['ok']==(budget not in ['scratch-short','cpu-short']),'original-read-reservation-limit',loc+'/actions/0')
    if not prepare['result']['ok']:check(prepare['result']['error']['code']=='limit-exceeded','explicit-original-read-reservation-limit',loc+'/actions/0')
    if prepare['result']['ok']:
     check(prepare['inspection']['budgets']['scratchBytes']==140,'original-read-scratch-charge',loc+'/actions/0');begun=actions[1];check(begun['result']['ok']==(budget!='gpu-short'),'original-read-pbo-limit',loc+'/actions/1')
     if not begun['result']['ok']:check(begun['result']['error']['code']=='limit-exceeded','explicit-original-read-pbo-limit',loc+'/actions/1')
     if begun['result']['ok']:check(begun['inspection']['budgets']['gpuBytes']==run['limits']['gpuBytes'],'native-image-plus-physical-pbo-charge',loc+'/actions/1')
   elif run.get('kind')=='physical-private-view-budget':
    action=run['actions'][0];exact=run['budget']=='exact';check(action['result']['ok']==exact and action['inspection']['budgets']['gpuBytes']==256+42*p['native']+(7*p['native'] if exact else 0),'private-range-native-charge-limit',loc+'/actions/0')
    if not exact:check(action['result']['error']['code']=='limit-exceeded','explicit-private-range-limit',loc+'/actions/0')
   elif run.get('kind')=='actual-native-error':
    check(len(run['faultEvents'])==1,'actual-native-error-selected',loc+'/faultEvents');mode=run['nativeFault'];faultEvent=run['faultEvents'][0];rr=run['actions'][0]['result'];rr=rr.get('result',rr)
    check(rr['ok'] is False and rr['error']['code']=='backend-error','explicit-actual-native-error-code',loc+'/actions/0')
    check(faultEvent['mode']==mode and (faultEvent['name']=='texStorage2D' and faultEvent['original'][1]==3 and faultEvent['delivered'][1]==0 if mode=='storage' else faultEvent['name']=='texSubImage2D' and faultEvent['originalX']==0 and faultEvent['deliveredX']==-1 if mode=='upload' else faultEvent['name']=='readPixels' and faultEvent['originalFormat']==6408 and faultEvent['deliveredFormat']==36249),'actual-invalid-native-selection',loc+'/faultEvents/0')
   elif run.get('kind')=='queued-physical-color-lifetime':
    pointstate=run['actions'][0];check(pointstate['before']['budgets']['gpuBytes']==256+48+42*4+2*7*4==528 and pointstate['after']['budgets']['gpuBytes']==528+256+42*4==952 and pointstate['before']['budgets']['imageHolds']==3,'retained-reused-distinct-physical-generations',loc+'/actions/0');gens=[rr['generation'] for rr in pointstate['after']['resources'] if rr['id']==6];check(len(set(gens))==2 and pointstate['freshGeneration']==max(gens),'public-id-reuse-independent-generation',loc+'/actions/0')
  if fault:
   check(bool(localfaults) and data['sabotage']['fenceCompleted'] and not data['sabotage']['held'] and any(run['faultEvents'] for run in data['runs']),'native-control-after-physical-fence',point);faults.append({'record':point,'sha256':sha((directory/'report.json').read_bytes()),'mismatches':localfaults})
  else:check(report['status']=='passed','recorded-healthy-status',point)
  reports.append({'record':point,'sha256':sha((directory/'report.json').read_bytes()),'counts':dict(counts-reportcounts),'status':'HELD','runs':len(data['runs']),'frames':len(data['frames'])})
output={'task':'E6-T11d22','status':'HELD','implementation':'independent Python pinned-format/original-word/color-space reconstruction; no worker oracle imports','formats':formats,'counts':dict(counts),'reports':reports,'faults':faults}
(OUT/'independent-audit.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps({'status':'HELD','counts':dict(counts),'reports':len(reports),'faults':len(faults)},indent=2))
