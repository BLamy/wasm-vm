import collections,gzip,hashlib,json,pathlib,subprocess
R=pathlib.Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');O=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();PRODUCT='76bd5df85e9c59f202d1bd879cb8f2470612432a';rows=[];counts=collections.Counter();sources={}
directories=[O/'fresh-boundaries-0x7f4a7c15',O/'fresh-smoke',O/'fresh-worker-control',*[p for p in (R/'target/evidence/virgl-standard-byte-color-verifier-final').iterdir() if p.is_dir()]]
for home in directories:
 raw=(home/'report.json').read_bytes();report=json.loads(raw);head=report['gitHead'];headFiles=set(subprocess.check_output(['git','ls-tree','-r','--name-only',head],cwd=R,text=True).splitlines());byName={}
 for source in report['sources']:
  name=source['path'];body=subprocess.check_output(['git','show',head+':'+name],cwd=R) if name in headFiles else (R/name).read_bytes();assert len(body)==source['bytes'] and sha(body)==source['sha256'],(home,name);byName['/'+name]=body;sources[(head,name)]=dict(sha256=sha(body),bytes=len(body));counts['sourceBodies']+=1
 for source in report.get('verifierSources',[]):
  name=pathlib.Path(source['path']).relative_to(R).as_posix();body=subprocess.check_output(['git','show',head+':'+name],cwd=R);assert sha(body)==source['sha256'];assert 'bytes' not in source or len(body)==source['bytes'];sources[(head,name)]=dict(sha256=sha(body),bytes=len(body));byName['/critic.mjs']=body if name=='tools/virgl-command/standard-byte-color-adversarial.mjs' else byName.get('/critic.mjs')
 for source in report['servedFiles']:
  if source['path']=='/':continue
  body=byName[source['path']];assert sha(body)==source['sha256'] and len(body)==source['bytes'];counts['servedBodies']+=1
 for name in ['renderer/virgl-command/decoder.mjs','renderer/virgl-command/resources.mjs','renderer/virgl-command/state.mjs','renderer/virgl-command/color-images.mjs']:
  assert byName['/'+name]==subprocess.check_output(['git','show',PRODUCT+':'+name],cwd=R)
 assert report['browserErrors']==dict(console=[],page=[],requests=[]);assert not report['browser']['headless'];assert not any(any(bad in arg.lower() for bad in ['swiftshader','llvmpipe','softpipe','lavapipe','--disable-gpu']) for arg in report['browser']['commandLine']);assert report['fixedMemory']['bytes']==16777216
 assert report['browser']['sha256']==sha(pathlib.Path(report['browser']['executable']).read_bytes())
 for name in ['browserCoverage','screenshot']:
  ref=report[name];assert sha((home/ref['path']).read_bytes())==ref['sha256'];counts['authenticatedCoverageScreenshots']+=1
 result=report['browserResult'].get('result',report.get('partial'));assert 'M4' in result['gpu'] and 'Metal' in result['gpu'];bodies={}
 for blob in result['blobs']:
  body=(home/blob['path']).read_bytes();rawBody=gzip.decompress(body);assert sha(body)==blob['gzipSha256'] and sha(rawBody)==blob['sha256'] and len(rawBody)==blob['bytes'];assert blob['key'] not in bodies;bodies[blob['key']]=rawBody;counts['nativeBodies']+=1
 def walk(x):
  if isinstance(x,dict):
   if set(['key','sha256','bytes'])<=x.keys():assert len(bodies[x['key']])==x['bytes'] and sha(bodies[x['key']])==x['sha256'];counts['completeNativeReferences']+=1
   for v in x.values():walk(v)
  elif isinstance(x,list):
   for v in x:walk(v)
 walk(result)
 for s in json.loads((home/'browser-coverage.json').read_text())['scripts']:
  assert s['sha256']==sha(byName['/'+s['source']]);counts['fullCoverageScripts']+=1
 assert report['status']==('failed' if report.get('fault') else 'passed')
 rows.append(dict(path=str(home),reportSha256=sha(raw),sourceHead=head,status=report['status'],nativeBodies=len(bodies),physicalGpu=result['gpu']))
output=dict(task='E6-T11d22',status='HELD',unchangedProductHead=PRODUCT,counts=dict(counts),reports=rows,sources=[dict(head=h,path=n,**x) for (h,n),x in sorted(sources.items())]);(O/'fresh-authentication.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps(dict(status='HELD',reports=len(rows),counts=dict(counts))))
