import gzip,hashlib,io,json,pathlib,subprocess,tarfile
R=pathlib.Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');O=pathlib.Path(__file__).parent;D=R/'evidence/virgl-standard-byte-color-images/verifier';sha=lambda b:hashlib.sha256(b).hexdigest();HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();members={};maps=[]
assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).strip()
def put(name,raw):
 assert name not in members;members[name]=raw
scratchFiles=['predictions.json','novel-predictions.json','authentication.json','authenticate.py','audit.py','audit_fresh.py','independent-audit.json','independent-fresh-audit.json','audit-revisions.json','dependency-inverse.json','coverage.py','coverage_promoted.py','classify.py','coverage-regions.json','coverage-classification.json','coverage-non-js.json','promoted-coverage-regions.json','promoted-coverage-classification.json','fresh-authentication.json','authenticate_fresh.py','current-boundary.json','seal_verifier.py','baseline-status.txt','task-diff.patch']
for name in scratchFiles:put('audit/'+name,(O/name).read_bytes())
dirs=[('fresh/fresh-boundaries-0x7f4a7c15',O/'fresh-boundaries-0x7f4a7c15'),('fresh/fresh-smoke',O/'fresh-smoke'),('fresh/fresh-worker-control',O/'fresh-worker-control')]
for name in ['novel-0x31415927','novel-0x27182818','fault-native-encoding']:dirs.append(('promoted/'+name,R/'target/evidence/virgl-standard-byte-color-verifier-final'/name))
for name in ['oracle-v8','worker-driver-v8','worker-driver-control-v8','worker-driver-smoke-v8','promoted-node-v8']:dirs.append(('node/'+name,O/name))
for prefix,home in dirs:
 maps.append(dict(original=str(home),archive=prefix))
 for p in sorted(home.rglob('*')):
  if p.is_file():assert not p.is_symlink();put(prefix+'/'+p.relative_to(home).as_posix(),p.read_bytes())
put('promoted/independent-audit.json',(R/'target/evidence/virgl-standard-byte-color-verifier-final/independent-audit.json').read_bytes())
fresh=json.loads((O/'fresh-authentication.json').read_text())
for s in fresh['sources']:
 name=s['path'];key='source/'+s['sha256']+'/'+name
 if key in members:continue
 if name.startswith('renderer/virgl-shader/build/wasm/'):raw=(R/name).read_bytes()
 else:raw=subprocess.check_output(['git','show',s['head']+':'+name],cwd=R)
 assert sha(raw)==s['sha256'] and len(raw)==s['bytes'];put(key,raw)
for name in subprocess.check_output(['git','diff','--name-only','9c15f5b4750e1e100d6c952684d97b9d0ce227ac',HEAD],cwd=R,text=True).splitlines():
 raw=subprocess.check_output(['git','show',HEAD+':'+name],cwd=R);key='promoted-source/'+name
 put(key,raw)
worker=json.loads((R/'evidence/virgl-standard-byte-color-images/worker/manifest.json').read_text())
index=(json.dumps(dict(schema='independent-byte-color-verifier-records-v1',task='E6-T11d22',sourceHead=HEAD,records=[dict(path=n,bytes=len(b),sha256=sha(b)) for n,b in sorted(members.items())]),indent=2)+'\n').encode();D.mkdir(parents=True,exist_ok=True);(D/'records.json').write_bytes(index)
archive=io.BytesIO()
with gzip.GzipFile(fileobj=archive,mode='wb',mtime=0) as gz:
 with tarfile.open(fileobj=gz,mode='w') as tar:
  for name,raw in sorted(members.items()):
   info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(raw))
raw=archive.getvalue();(D/'recording.tar.gz').write_bytes(raw)
manifest=dict(schema='independent-byte-color-verifier-seal-v1',task='E6-T11d22',status='HELD',sourceHead=HEAD,workerSubmission='9c15f5b4750e1e100d6c952684d97b9d0ce227ac',frozenWorkerHead=worker['sourceHead'],unchangedProductHead='76bd5df85e9c59f202d1bd879cb8f2470612432a',predecessor='ac916b7fd0b194c088fe5d54800b24a80a4679ac',records=len(members),uncompressedBytes=sum(map(len,members.values())),archiveBytes=len(raw),archiveSha256=sha(raw),recordIndexSha256=sha(index),workerArchiveSha256=worker['archiveSha256'],workerIndexSha256=worker['recordIndexSha256'],pathMap=maps,dependencies=json.loads((O/'authentication.json').read_text())['dependencies'],coldCarry=json.loads((O/'current-boundary.json').read_text())['coldCarry'],guestExecution=False,productionNegotiation=False,productionDrawAuthority=False,scope='isolated explicitly host-selected original byte-color images only',suite=dict(command='make verify-E6-T11d22-adversarial',sourceHead=HEAD,status='passed',healthySeeds=['0x31415927','0x27182818'],nativeControl='fault-native-encoding: failed original oracle after actual consumed physical fence'))
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k not in ['pathMap','dependencies','coldCarry']}))
