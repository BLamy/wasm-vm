import functools,gzip,hashlib,json,pathlib,subprocess,tarfile
ROOT=pathlib.Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
OUT=pathlib.Path(__file__).parent
P=ROOT/'evidence/virgl-standard-byte-color-images/worker'
sha=lambda x:hashlib.sha256(x).hexdigest()
head='30908255d0ab91434ff37505852fe6550977a227'
base='ac916b7fd0b194c088fe5d54800b24a80a4679ac'
@functools.lru_cache(maxsize=None)
def source(rev,name): return subprocess.check_output(['git','show',rev+':'+name],cwd=ROOT)
m=json.loads((P/'manifest.json').read_bytes());index=json.loads((P/'records.json').read_bytes())
assert m['sourceHead']==head==index['sourceHead']
assert sha((P/'records.json').read_bytes())==m['recordIndexSha256']=='846ce5b67333ea0f3aac751d3c5aed448979ca2f17c2fd1cae569c73974166a7'
assert sha((P/'recording.tar.gz').read_bytes())==m['archiveSha256']=='06406c64da6f9117633df916eb307c466df9d73c3fcc13abec640f7efcb5ac4e'
assert len((P/'recording.tar.gz').read_bytes())==m['archiveBytes']
expected={row['path']:row for row in index['records']};assert len(expected)==len(index['records'])==m['records']==30256
unpacked=OUT/'unpacked';unpacked.mkdir(exist_ok=True)
observed=set();total=0
with tarfile.open(P/'recording.tar.gz','r:gz') as tar:
 for member in tar:
  name=member.name;p=pathlib.PurePosixPath(name)
  assert member.isfile() and not p.is_absolute() and '..' not in p.parts and name not in observed and name in expected
  raw=tar.extractfile(member).read();row=expected[name];assert len(raw)==row['bytes']==member.size and sha(raw)==row['sha256'],name
  target=unpacked/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);observed.add(name);total+=len(raw)
assert observed==set(expected)
for name,key in [('hot/receipt.json','hotReceiptSha256'),('cold/receipt.json','coldReceiptSha256'),('cold/report.json','coldReportSha256')]:assert sha((unpacked/name).read_bytes())==m[key]
summary={'archiveSha256':m['archiveSha256'],'recordIndexSha256':m['recordIndexSha256'],'sourceHead':head,'members':len(observed),'uncompressedBytes':total,'receipts':{},'reports':[],'dependencies':{}}
blob_total=0;raw_total=0
for prefix in ['hot','cold']:
 receipt=json.loads((unpacked/prefix/'receipt.json').read_bytes());assert receipt['gitHead']==head and receipt['status']=='passed' and receipt['historicalEvidenceHead']==base
 for name,digest in receipt['files'].items():assert sha((unpacked/prefix/name).read_bytes())==digest,(prefix,name)
 for name,digest in receipt['sources'].items():assert sha(source(head,name))==digest,(prefix,name)
 for name,digest in receipt['generated'].items():assert sha((unpacked/(prefix+'-generated')/name).read_bytes())==digest,(prefix,name)
 for name,digest in receipt['carriedVerifiedEvidence'].items():assert sha((ROOT/name).read_bytes())==digest==sha(source(base,name)),name
 for name,digest in receipt['carriedUnchangedBoundaries'].items():assert sha(source(base,name))==digest,name
 summary['receipts'][prefix]={'files':len(receipt['files']),'sources':len(receipt['sources']),'generated':receipt['generated'],'digest':sha((unpacked/prefix/'receipt.json').read_bytes())}
 for report_path in sorted((unpacked/prefix).glob('*/report.json')):
  report=json.loads(report_path.read_bytes());assert report['gitHead']==head,(prefix,report_path)
  entries=report.get('sources',[])
  served={x['path']:x for x in report.get('servedFiles',[])}
  for entry in entries:
   name=entry['path'];raw=(unpacked/(prefix+'-generated')/name).read_bytes() if '/build/' in name else source(head,name)
   assert sha(raw)==entry['sha256'],(report_path,name)
   if '/'+name in served:assert served['/'+name]['sha256']==entry['sha256'],name
  if report_path.parent.name.startswith(('hardware-','fault-')):
   assert report['browserErrors']=={'console':[],'page':[],'requests':[]},report_path
   assert report['fixedMemory']['bytes']==16777216 and not report['browser']['headless']
   assert all(not any(x in a.lower() for x in ['swiftshader','llvmpipe','softpipe','lavapipe','--disable-gpu']) for a in report['browser']['commandLine'])
   data=report['browserResult'].get('result',report.get('partial'));assert 'M4' in data['gpu'] and 'Metal' in data['gpu']
   blobs={x['key']:x for x in data['blobs']};assert len(blobs)==len(data['blobs'])
   refs=[]
   def scan(x,path='$'):
    if isinstance(x,dict):
     if 'key' in x and 'sha256' in x and x['key'].startswith('blob-'):refs.append((path,x))
     for k,v in x.items():scan(v,path+'/'+k)
    elif isinstance(x,list):
     for j,v in enumerate(x):scan(v,path+'/'+str(j))
   scan(data)
   for k,b in blobs.items():
    packed=(report_path.parent/b['path']).read_bytes();raw=gzip.decompress(packed)
    assert sha(packed)==b['gzipSha256'] and sha(raw)==b['sha256'] and len(raw)==b['bytes'],(report_path,k)
    blob_total+=1;raw_total+=len(raw)
   for loc,b in refs:
    real=blobs[b['key']];assert all(b[k]==real[k] for k in ['key','bytes','sha256','gzipSha256']),(report_path,loc)
  summary['reports'].append({'path':report_path.relative_to(unpacked).as_posix(),'status':report['status'],'sha256':sha(report_path.read_bytes()),'sources':len(entries),'served':len(served)})
  for key in ['browserCoverage','screenshot']:
   if key in report:assert sha((report_path.parent/report[key]['path']).read_bytes())==report[key]['sha256']
 cold=json.loads((unpacked/'cold/report.json').read_bytes());assert cold['status']=='passed' and cold['gitHead']==cold['cloneHead']==head and cold['statusBefore']==cold['statusAfter']=='' and cold['exitCode']==0
 assert sha((unpacked/'cold/receipt.json').read_bytes())==cold['receiptSha256'] and sha((unpacked/'cold/cold.log').read_bytes())==cold['logSha256']
for suffix in ['worker','verifier']:
 p=ROOT/'evidence/virgl-standard-image-subresources'/suffix
 dm=json.loads((p/'manifest.json').read_bytes());di=json.loads((p/'records.json').read_bytes())
 assert sha((p/'recording.tar.gz').read_bytes())==dm['archiveSha256'] and sha((p/'records.json').read_bytes())==dm['recordIndexSha256']
 de={r['path']:r for r in di['records']};seen=set();depsBytes=0
 with tarfile.open(p/'recording.tar.gz','r:gz') as tar:
  for member in tar:
   assert member.isfile() and member.name not in seen and member.name in de
   raw=tar.extractfile(member).read();r=de[member.name];assert len(raw)==r['bytes'] and sha(raw)==r['sha256'],member.name
   seen.add(member.name);depsBytes+=len(raw)
 assert seen==set(de)
 summary['dependencies'][suffix]={'members':len(seen),'bytes':depsBytes,'archiveSha256':dm['archiveSha256'],'recordIndexSha256':dm['recordIndexSha256']}
summary['nativeBlobs']=blob_total;summary['nativeBlobBytes']=raw_total;summary['status']='HELD'
(OUT/'authentication.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['reports']},indent=2))
