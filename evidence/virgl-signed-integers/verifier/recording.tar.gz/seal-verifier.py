import gzip,hashlib,io,json,pathlib,tarfile
ROOT=pathlib.Path.cwd(); OUT=ROOT/'target/evidence/virgl-signed-integers-verifier'; DEST=ROOT/'evidence/virgl-signed-integers/verifier'; sha=lambda b:hashlib.sha256(b).hexdigest()
files=['predictions.json','authenticate.py','authentication.json','interrogate.py','interrogation.json','coverage.py','coverage-audit.json','recomputed-coverage.json','recomputed.profdata','cold-recomputed-coverage.json','cold-recomputed.profdata','cold-coverage-authentication.json','signed-integer-regressions.mjs','guards.json','guards.bin','guard-sanitize.log','guard-sanitize.stderr','guard-sanitize.json','guard-sanitize.profraw','sabotage.patch','sabotage-build.log','sabotage-guards.json','sabotage-guards.log','sensitivity.json','scratch-build.log','gpu-independent.log','fourth-seed-authentication.json','cleanup.json','verdict.json','README.txt','seal-verifier.py']
files.extend('gpu-independent/'+p.name for p in sorted((OUT/'gpu-independent').iterdir()) if p.is_file())
member={name:(OUT/name).read_bytes() for name in files}
member['binaries/native']= (OUT/'source/renderer/virgl-shader/build/native/virgl-shader').read_bytes()
member['binaries/union-sabotage']=(OUT/'sabotage-source/renderer/virgl-shader/build/native/virgl-shader').read_bytes()
member['mutation/raw_bits.c']=(OUT/'sabotage-source/renderer/virgl-shader/raw_bits.c').read_bytes()
assert json.loads(member['guards.json'])['status']=='passed' and json.loads(member['guard-sanitize.json'])['status']=='passed'
assert json.loads(member['sabotage-guards.json'])['status']=='failed' and json.loads(member['verdict.json'])['verdict']=='verified'
assert sha(member['binaries/native'])==json.loads(member['guards.json'])['nativeBinary']['sha256']
assert sha(member['binaries/union-sabotage'])==json.loads(member['sensitivity.json'])['binarySha256']
assert sha(member['signed-integer-regressions.mjs'])==sha((ROOT/'renderer/virgl-shader/tests/signed-integer-regressions.mjs').read_bytes())
index=dict(schema='virgl-signed-integers-verifier-records-v1',task='E6-T12g6d',sourceHead='bc360945be9b9f20cc6cb2dc29475857b58f2382',records=[dict(path=name,bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(member.items())]); index_raw=(json.dumps(index,indent=2)+'\n').encode(); DEST.mkdir(parents=True,exist_ok=True);(DEST/'records.json').write_bytes(index_raw)
archive=io.BytesIO()
with gzip.GzipFile(fileobj=archive,mode='wb',mtime=0,filename='') as zipped:
 with tarfile.open(fileobj=zipped,mode='w') as tar:
  for name,raw in sorted(member.items()):
   info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.mode=0o755 if name.startswith('binaries/') else 0o644;tar.addfile(info,io.BytesIO(raw))
raw=archive.getvalue();(DEST/'recording.tar.gz').write_bytes(raw)
manifest=dict(schema='virgl-signed-integers-verifier-seal-v1',task='E6-T12g6d',verdict='verified',sourceHead=index['sourceHead'],base='0488546825fa63ee5740844c045ae7be0d43eeb9',workerArchiveSha256='ebba6b455cd12786a95b4531d6936e72906b9d5716a0f8234e9e5cffea95fb88',records=len(member),uncompressedMemberBytes=sum(map(len,member.values())),archive=dict(path='recording.tar.gz',bytes=len(raw),sha256=sha(raw)),recordIndex=dict(path='records.json',bytes=len(index_raw),sha256=sha(index_raw)),guard=dict(path='renderer/virgl-shader/tests/signed-integer-regressions.mjs',cases=108,sha256=sha(member['signed-integer-regressions.mjs']),reportSha256=sha(member['guards.json'])),ownedPhysicalSeed=967929221,ownedCheckedWords=30912,ownedCheckedPixels=9856,productionNegotiation=False,guestExecution=False)
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Immediate independent re-open and member/whole digest check.
with tarfile.open(DEST/'recording.tar.gz','r:gz') as tar:
 names=[]
 for item in tar.getmembers():
  data=tar.extractfile(item).read();assert data==member[item.name];names.append(item.name)
 assert len(names)==len(set(names))==len(member)
print(json.dumps(manifest,indent=2))
