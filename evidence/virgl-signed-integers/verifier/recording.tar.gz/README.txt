E6-T12g6d fresh critic recording, 2026-10-04

P1-P8 were written to predictions.json before opening evidence. Source runtime/harness:
bc360945be9b9f20cc6cb2dc29475857b58f2382, verified base 0488546825fa63ee5740844c045ae7be0d43eeb9.
Worker archive SHA-256 ebba6b455cd12786a95b4531d6936e72906b9d5716a0f8234e9e5cffea95fb88.

Authentication.py validates every indexed worker member, both full source/generated
sets, each child record, and exact/pristine cold proof. Interrogate.py interprets
literal TGSI (including banks, masks, simultaneous aliased reads, and control flow)
using signed int.from_bytes, not the worker oracle/expectedWords. It recomputes all
hot/cold feedback bytes/pixels, primary source restriction, exact old source/metadata,
consumer A/B/A wire packets and actual reflection, both source faults, and an owned
fourth physical seed. Coverage.py regenerates LLVM coverage from raw profiles and
binary and classifies all 25 source diff hunks. The cold export also matches exactly.

Owned commands (working directory is repository root, unless stated):
python3 target/evidence/virgl-signed-integers-verifier/authenticate.py
python3 target/evidence/virgl-signed-integers-verifier/interrogate.py
python3 target/evidence/virgl-signed-integers-verifier/coverage.py
bash renderer/virgl-shader/build.sh native  # in isolated source tree at frozen HEAD
node tools/virgl-signed-integers/browser.mjs --output ../gpu-independent --seed 967929221
node target/evidence/virgl-signed-integers-verifier/signed-integer-regressions.mjs --root target/evidence/virgl-signed-integers-verifier/source --native target/evidence/virgl-signed-integers-verifier/source/renderer/virgl-shader/build/native/virgl-shader --output target/evidence/virgl-signed-integers-verifier/guards.json
node --check renderer/virgl-shader/tests/signed-integer-regressions.mjs

The 108 independently predetermined guards were also packed as guards.bin and fed to
the authenticated worker ASan/UBSan binary with LLVM_PROFILE_FILE pointing into owned
scratch, UBSAN_OPTIONS=halt_on_error=1 and ASAN_OPTIONS=abort_on_error=1. It returned
all 108 identical results, STATUS passed, empty diagnostics (guard-sanitize.json).

Owned sabotage changes only RAW_IMAX's unknown facts from intersection to union,
builds a separate native binary, and runs the same promoted guard with --native-only.
It fails on native[0]: predicted rejection, observed admission. Concrete source A
can be +Inf and B 1; IMAX selects +Inf. One-sided bit23=1 and bit24=0 cannot establish
safe normality for both alternatives. Mutation source, binary, transcript and result
are sealed; authentic native/Wasm controls pass. No implementation was repaired.

Recurring command for root to integrate (create output directory first):
node renderer/virgl-shader/tests/signed-integer-regressions.mjs --native renderer/virgl-shader/build/native/virgl-shader --output target/evidence/virgl-signed-integers/independent-signed-guards.json

Prior G6b/G6c/resource/storage proofs carry HELD across unchanged boundaries. The
existing pristine cold proof was interrogated; another clone acceptance was not run.
The scratch source archive is only an isolated build/attack environment. The browser
closed, its unique process profile is absent and all GL/consumer budgets are zero.

Scope: isolated private signed32 compiler. Full owned words use source predictions;
pinned Mesa references use finite UCMP predicates and normal/zero IMAX selections,
with unchanged primary GLSL. Wire nonfinite rejection remains. No production imports,
caps/negotiation, guest boot, MIPS/FPS or accelerated desktop claim.
