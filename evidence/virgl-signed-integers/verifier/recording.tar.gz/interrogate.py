"""Critic-owned source interpreter and complete raw-byte audit. No worker oracle is imported."""
import collections,hashlib,json,pathlib,re,struct,subprocess
ROOT=pathlib.Path.cwd(); OUT=ROOT/'target/evidence/virgl-signed-integers-verifier'; REC=OUT/'authenticated-worker'
sha=lambda b:hashlib.sha256(b).hexdigest()
def check(c,m):
 if not c: raise AssertionError(m)
def i32(w): return int.from_bytes(int(w).to_bytes(4,'little'), 'little', signed=True)
def fword(x): return struct.unpack('<I',struct.pack('<f',x))[0]
def normal(w): return (w&0x7fffffff)==0 or 0<(w&0x7f800000)<0x7f800000
# Interpret source values and control flow; destination publication is after all reads.
def evaluate(text, banks=None, position=None):
 registers={'CONST':{},'TEMP':{},'OUT':{},'IMM':{},'IN':{0:position or [0,0,0,0]}}; effects=[]; active=True; stack=[]
 if banks is not None: registers['CONST']={i:banks[4*i:4*i+4] for i in range(len(banks)//4)}
 def read(token):
  m=re.fullmatch(r'(IMM|TEMP|OUT|IN|CONST)\[(\d+)\](?:\.([xyzw]{4}))?',token.strip());check(m is not None,'operand:'+token)
  file,index,sw=m.groups();words=registers[file][int(index)];return [words['xyzw'.index(c)] for c in sw or 'xyzw']
 for line in text.splitlines():
  if not line or line in ['VERT','FRAG','END'] or line.startswith(('DCL ','PROPERTY ')):continue
  m=re.fullmatch(r'IMM\[(\d+)\] UINT32 \{([^}]+)\}',line)
  if m: registers['IMM'][int(m[1])]=[int(x) for x in m[2].split(',')];continue
  if line.startswith('UIF '):
   decision=read(line[4:])[0]!=0 if active else False;stack.append((active,decision));active=active and decision;continue
  if line=='ELSE': parent,decision=stack[-1];active=parent and not decision;continue
  if line=='ENDIF': active=stack.pop()[0];continue
  if not active:continue
  op,args=line.split(' ',1); tokens=[x.strip() for x in args.split(',')];dst=re.fullmatch(r'(TEMP|OUT)\[(\d+)\](?:\.([xyzw]+))?',tokens[0]);check(dst is not None,'destination:'+tokens[0]);file,index,mask=dst.groups();index=int(index);mask=mask or 'xyzw';src=[read(t) for t in tokens[1:]]
  a=src[0];b=src[1] if len(src)>1 else None
  if op=='MOV': result=a[:]
  elif op=='ISLT':result=[0xffffffff if i32(x)<i32(y) else 0 for x,y in zip(a,b)]
  elif op=='IMAX':result=[x if i32(x)>=i32(y) else y for x,y in zip(a,b)]
  elif op=='AND':result=[x&y for x,y in zip(a,b)]
  elif op=='OR':result=[x|y for x,y in zip(a,b)]
  elif op=='USHR':result=[x>>(y%32) for x,y in zip(a,b)]
  elif op=='UCMP':result=[src[1][i] if x!=0 else src[2][i] for i,x in enumerate(a)]
  else:raise AssertionError('unmodeled opcode:'+op)
  before=registers[file].get(index,[None]*4);after=before[:]
  for c in mask:after['xyzw'.index(c)]=result['xyzw'.index(c)]
  registers[file][index]=after
  if op in ['ISLT','IMAX']:effects.append(dict(op=op,a=a,b=b,result=after[:],mask=mask))
 check(not stack,'balanced conditional');return registers['OUT'],effects,registers['IMM']
# Source-only predictions made before output inspection.
check(i32(0x80000000)==-2147483648 and i32(0x7fffffff)==2147483647 and i32(0xffffffff)==-1,'independent signed decoding')
primary_rows=json.loads((REC/'generated/signed-integers-primary.json').read_bytes());primary_by_text={x['text']:x['primary'] for x in primary_rows}
points=[];totals=[]
for label,base in [('hot',REC/'hot'),('cold',REC/'cold/acceptance')]:
 native=json.loads((base/'native/report.json').read_bytes());wasm=json.loads((base/'wasm/report.json').read_bytes());fixture=(base/'native/cases.bin').read_bytes(); at=4
 check(fixture[:4]==b'VSI1','fixture magic')
 def u32():
  global at
  n=int.from_bytes(fixture[at:at+4],'little');at+=4;return n
 check(u32()==432,'fixture count');check(len(native['cases'])==len(wasm['cases'])==len(wasm['pairs'])==432,'API cases')
 native_sources={}
 for c,w,p in zip(native['cases'],wasm['cases'],wasm['pairs']):
  st,ok,prim,n=u32(),u32(),u32(),u32();raw=fixture[at:at+n];at+=n
  check(raw.decode()==c['text'] and st==int(c['stage']=='fragment') and bool(ok)==c['ok'] and bool(prim)==c['primary'],'actual fixture binding')
  check(c['result']==w['result'] and p['result']['ok']==c['ok'],'native/Wasm single+pair equality')
  check(c['result']['ok']==c['ok'] and type(c['result']['ok']) is bool,'literal admission')
  check(sha(raw)==c['textSha256']==w['textSha256'],'literal source binding')
  if c['ok']:
   native_sources[c['text']]=c['result'];md=c['result']['metadata'];check('constantRasterDomains' not in md and c['consumerDomain']=={'ok':True,'domain':None},'no domain authority')
  else:
   check(not any(k in c['result'] for k in ['glsl','metadata']),'closed single rejection');check(not any(k in p['result'] for k in ['vertex','fragment','metadata']),'closed pair rejection')
  if c['primary']:
   check(c['primaryResult']==primary_by_text[c['text']],'actual pinned source fixture')
   for op in c['primaryResult']['signedInstructions']:check(op['sourceType']==op['destinationType']==3 and op['opcode'] in ['ISLT','IMAX'],'pinned signed32 types')
 check(at==len(fixture),'fixture complete');check(not (base/'native/native.stderr').read_bytes(),'empty sanitizer diagnostics')
 check(len(primary_rows)==392,'pinned witnesses')
 for name,count in [('independent-joins.json',402),('independent-hex-guards.json',49)]:
  guard=json.loads((base/name).read_bytes());check(guard['status']=='passed' and len(guard['native'])==len(guard['wasm'])==count,'prior guards')
  for n,w in zip(guard['native'],guard['wasm']):
   check(n['result']['ok']==n['ok'] and w['result']['ok']==w['ok'],'guard predicted admission')
   if n['result'].get('error',{}).get('code')=='invalid-input':check(w['result'].get('error',{}).get('code')=='invalid-input','prior invalid-input')
   else:check(n['result']==w['result'],'prior exact parity')
 retained=json.loads((base/'retained/report.json').read_bytes())
 for c in retained['originals']:
  raw=subprocess.check_output(['git','show','bc360945be9b9f20cc6cb2dc29475857b58f2382:'+c['path']]);check(sha(raw)==c['sha256'] and len(raw)==c['bytes'],'retained literal source');check(c['native']==c['wasm'],'retained exact native/Wasm');
  if not c['sha256'].startswith('92cb866a'):check(c['native']==c['old'],'retained exact old source/metadata')
 for c in retained['historical']:
  check(sha(c['text'].encode())==c['inputSha256'],'historical exact source')
 check(len(retained['originals'])==25 and sum(c['native']['ok'] for c in retained['originals'])==23 and len(retained['historical'])==112 and sum(c['native']['ok'] for c in retained['historical'])==5,'prior partitions')
 for seed in ([1369979863,2804203833,3781791491,967929221] if label=='hot' else [1369979863,2804203833,3781791491]):
  file=OUT/'gpu-independent/report.json' if seed==967929221 else base/f'gpu-{seed}/report.json';record=json.loads(file.read_bytes());a=record['acceptance'];check(record['status']==a['status']=='passed','physical outcome')
  check(record['browserErrors']=={'console':[],'page':[],'requests':[]},'browser errors');check(not record['trackedChanges'],'physical frozen input')
  browser=record['browser'];check(browser['launch']['headless'] is False and browser['gpu']['featureStatus'][browser['webglFeature']]=='enabled','hardware enabled');check(not re.search(r'swiftshader|llvmpipe|softpipe|software',a['renderer']['renderer'],re.I),'physical identity')
  check(a['objects']['live']==0 and a['guestExecution'] is False and a['productionNegotiation'] is False,'scope and disposed objects')
  event_sources=collections.Counter(e['source'] for e in a['events'] if e['call']=='shaderSource');expected_event_sources=collections.Counter();words=pixels=owned_words=owned_pixels=0;edge_pairs=set();joined=collections.Counter();kinds=collections.Counter()
  for vi,v in enumerate(a['vertices']):
   check(sha(v['text'].encode())==v['textSha256'],'physical text');check(v['pair']['ok'] is True,'physical compiler pair');check(v['reflection']==[{'name':name,'type':35666,'size':1} for name in ['gl_Position','vso_g0','vso_g1']],'actual feedback reflection')
   vert_source=v['primary']['glsl'] if v['backend']=='mesa' else v['pair']['vertex']['glsl'];expected_event_sources.update([vert_source,v['pair']['fragment']['glsl']]);check(event_sources[vert_source]>0,'actual served GL source')
   if v['backend']=='mesa':check(v['primary']==primary_by_text[v['text']],'unaltered pinned GLSL')
   if v['text'] in native_sources:check(v['pair']['vertex']=={k:x for k,x in native_sources[v['text']].items() if k!='ok'},'public compiled source binding')
   for xi,x in enumerate(v['vectors']):
    upload=x['bankUpload'];banks=None
    if upload:
     check(v['bank'] and upload['observedA']==x['input']['a'] and upload['observedB']==x['input']['b'],'actual reflected bank');banks=upload['words'];check(banks[:4]==upload['observedA'] and banks[180:184]==upload['observedB'] and banks[172]==x['condition'],'captured exact bank');check(set(upload['callerAfter'])=={0xdeadbeef},'caller storage independent');check(v['uniformReflection']['type']==36296 and v['uniformReflection']['count']>=46,'uvec4 bank reflection')
    out,effects,imms=evaluate(v['text'],banks,[fword(y) for y in x['position']]);check(len(effects)==1,'one chosen signed source');effect=effects[0]
    if not banks:check(imms[0]==x['input']['a'] and imms[1]==x['input']['b'],'literal input binding')
    expected=out[0]+out[1]+out[2];raw=bytes(x['bytes']);check(len(raw)==48 and sha(raw)==x['sha256'],'feedback raw digest');actual=list(struct.unpack('<12I',raw));check(actual==expected,'source-predicted physical byte equality')
    chosen=[((out[2][i]&511)<<23)|(out[1][i]&0x7fffff) for i in range(4)];check(chosen==x['selectedWords']==x['reconstructed'],'full raw bit reconstruction');check(x['attributeWords']==[fword(y) for y in x['position']],'actual position attributes')
    if v['backend']=='mesa':
     if v['op']=='ISLT':check(v['predicate'] is True and chosen==[0x3f800000 if y else 0 for y in effect['result']],'finite predicate reference')
     else:check(all(normal(w) for w in effect['result']),'safe IMAX reference domain')
     if v['variant'] in ['masked','alias']:check(all(normal(w) for w in x['input']['a']+x['input']['b']),'alias/mask primary domain')
    else:
     owned_words+=12
     if v['variant']=='direct' and not banks:edge_pairs.update((i32(x),i32(y)) for x,y in zip(effect['a'],effect['b']))
     if v['variant']=='join':joined[(v['op'],x['condition'])]+=1
    words+=12;kinds[(v['op'],v['backend'],v['variant'])]+=1
    if x['input']['name']=='edge-0-8' and v['backend']=='owned' and not banks and xi==0:points.append(dict(recording=label,seed=seed,report=str(file.relative_to(OUT)),reportSha256=sha(file.read_bytes()),point=f'acceptance.vertices[{vi}].vectors[{xi}]',opcode=effect['op'],signedA=list(map(i32,effect['a'])),signedB=list(map(i32,effect['b'])),signedResult=effect['result'],physicalRawSha256=x['sha256'],actual=actual))
  for fi,f in enumerate(a['fragments']):
   check(sha(f['text'].encode())==f['textSha256'],'fragment source');out,effects,imms=evaluate(f['text']);check(imms[0]==f['input']['a'] and imms[1]==f['input']['b'],'literal fragment binding');check(set(out[0])<=set([0,0x3f800000]),'exact zero/one output');expected=bytes([255 if w==0x3f800000 else 0 for w in out[0]])*16;raw=bytes(f['rgbaBytes']);check(raw==expected and len(raw)==64 and sha(raw)==f['sha256'],'all actual pixel bytes');
   frag_source=f['primary']['glsl'] if f['backend']=='mesa' else f['pair']['fragment']['glsl'];expected_event_sources.update([f['pair']['vertex']['glsl'],frag_source]);check(event_sources[frag_source]>0,'actual fragment source')
   if f['backend']=='mesa':
    check(f['primary']==primary_by_text[f['text']],'unchanged primary fragment');check(f['predicate'] is True if f['op']=='ISLT' else all(normal(w) for w in effects[0]['result']),'finite primary pixels')
   else:owned_pixels+=16
   pixels+=16
  check(owned_words==24192 and owned_pixels==9216,'unrestricted owned completeness')
  check(all(joined[(op,c)]==144 for op in ['ISLT','IMAX'] for c in [0,0xffffffff]),'both predecessor executions')
  endpoints=[0x80000000,0x80000001,0xffffffff,0xfffffffe,0xffff0000,0xff800000,0xff800001,0xffc12345,0,1,2,0xffff,0x3f000000,0x7f7fffff,0x7f800001,0x7fffffff]
  check(all((i32(x),i32(y)) in edge_pairs for x in endpoints for y in endpoints),'every endpoint pair')
  check(words==a['checkedWords'] and pixels==a['checkedPixels'],'counter recomputation after bytes')
  check(len(a['consumers'])==4,'both operations/schedules');consumer_checks=[]
  for ci,c in enumerate(a['consumers']):
   check(c['op'] in ['ISLT','IMAX'] and len(c['captures'])==6 and len(c['submissions'])==5,'consumer phases');expected_banks=[]
   for submission in c['submissions']:
    check(all(x==255 for x in submission['after']),'caller mutation');raw=bytes(submission['before']);offset=0;packets=[]
    while offset<len(raw):
     head=int.from_bytes(raw[offset:offset+4],'little');op=head&255;typ=(head>>8)&255;size=head>>16;payload=list(struct.unpack('<'+'I'*size,raw[offset+4:offset+4+size*4]));packets.append(dict(op=op,type=typ,words=payload));offset+=4+size*4
    check(offset==len(raw),'actual packet complete')
    if submission['label'].startswith('replace '):
     check([p['op'] for p in packets]==[12,12] and [p['words'][:2] for p in packets]==[[0,0],[1,0]],'two stage constant wire');check(packets[0]['words'][2:]==packets[1]['words'][2:],'same two stage owned wire');expected_banks.extend([packets[0]['words'][2:]]*2)
    if c['asynchronous']:
     if submission['result']['ok']:check(submission['begin']['ok'] and submission['states'][-1]['status']=='done' and len(submission['states'])>=1,'real async state progression')
    if submission['label']=='create/link actual signed shaders':
     check([p['op'] for p in packets]==[1,1,31,31,52],'real shader consumer setup')
   check(expected_banks[0]==expected_banks[1]==expected_banks[4]==expected_banks[5] and expected_banks[2]==expected_banks[3] and expected_banks[0]!=expected_banks[2],'wire A/B/A replacements')
   for x,wanted in zip(c['captures'],expected_banks):
    sub=x['snapshot']['contexts'][0]['subContexts'][0];check(sub['bindings']['constants']==[wanted,wanted],'owned consumer snapshots');
    for y in x['native']:check(y['words']==wanted[y['index']*4:y['index']*4+4],'actual reflected consumer bank')
    for obj in sub['objects']:
     md=obj['translation']['metadata'];check('constantRasterDomains' not in md and 'constantDomains' not in md,'consumer no numeric grant');check(md['profile']=='virgl-webgl2-raw-bits-v2' and md['uniforms'][0]['encoding']=='float32-bits' and md['uniforms'][0]['type']=='uvec4[]','unchanged metadata ABI')
    check(len(sub['programs'])==1 and len(sub['programs'][0]['reflection']['uniforms'])==2,'actual linked program metadata')
   check(c['rejection']['before']==c['rejection']['after']==c['captures'][-1]['snapshot'],'rejected immutable snapshot');check(c['rejection']['result']['ok'] is False and c['rejection']['result']['appliedCommands']==0,'atomic nonfinite rejection');check(all(w==0 for w in c['finalBudgets'].values()) and all(w==0 for w in c['finalResourceBudgets'].values()),'real zero budgets')
   expected_event_sources.update(c['captures'][0]['snapshot']['contexts'][0]['subContexts'][0]['objects'][i]['translation']['glsl'] for i in [0,1])
   consumer_checks.append(dict(op=c['op'],asyncMode=c['asynchronous'],phases=6,reflectedWords=6*16))
  if event_sources!=expected_event_sources:print('shader source count difference', [(sha(k.encode()),v,event_sources[k],expected_event_sources[k]) for k,v in (event_sources-expected_event_sources).items()],[(sha(k.encode()),v,event_sources[k],expected_event_sources[k]) for k,v in (expected_event_sources-event_sources).items()])
  check(event_sources==expected_event_sources,'every shader actually supplied to native GL, no rewriting/unaccounted shader')
  totals.append(dict(recording=label,seed=seed,feedbackWords=words,pixels=pixels,ownedWords=owned_words,ownedPixels=owned_pixels,joined={str(k):v for k,v in joined.items()},consumers=consumer_checks,reportSha256=sha(file.read_bytes())))
 for mode in ['signedness','winner']:
  path=base/f'fault-{mode}/report.json';record=json.loads(path.read_bytes());check(record['status']=='failed' and record['browserErrors']=={'console':[],'page':[],'requests':[]},'recorded source fault');a=record['acceptance'];v=next(v for v in a['vertices'] if v['mutation']);x=next(x for x in v['vectors'] if 'failure' in x);out,effects,imm=evaluate(v['text'],None,[fword(p) for p in x['position']]);pred=out[0]+out[1]+out[2];mut=v['mutation'];check(mut['original']==v['pair']['vertex']['glsl'],'owned original fault source');served=mut['original'].replace(mut['needle'],mut['replacement']) if mode=='signedness' else mut['original'].replace(mut['needle'],mut['replacement'],1);check(served==mut['served'] and served!=mut['original'],'precise owned fault mutation');check(any(e.get('source')==served for e in a['events'] if e['call']=='shaderSource'),'native GL consumes fault source');actual=list(struct.unpack('<12I',bytes(x['bytes'])));lane=next(i for i in range(12) if pred[i]!=actual[i]);check(lane==x['failure']['lane'] and pred[lane]==x['failure']['expected'] and actual[lane]==x['failure']['actual'],'independent source fault contradiction');check(a['objects']['live']==0,'fault disposal');points.append(dict(recording=label,mode=mode,point=f'acceptance.vertices[{a["vertices"].index(v)}].vectors[{v["vectors"].index(x)}]',reportSha256=sha(path.read_bytes()),lane=lane,predicted=pred[lane],actual=actual[lane],rawSha256=x['sha256']))
report=dict(task='E6-T12g6d',status='passed',predictions={p:'HELD' for p in ['P2','P3','P5','P6','P7']},method='independent TGSI interpreter, signed int.from_bytes, exact all feedback bytes/all RGBA bytes; never reads expectedWords as oracle',totals=totals,points=points)
(OUT/'interrogation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
