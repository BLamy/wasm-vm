import hashlib,json,pathlib,subprocess,tarfile
ROOT=pathlib.Path.cwd(); OUT=ROOT/'target/evidence/virgl-signed-integers-verifier'; WORKER=ROOT/'evidence/virgl-signed-integers/worker'
FROZEN='bc360945be9b9f20cc6cb2dc29475857b58f2382'
BASE='0488546825fa63ee5740844c045ae7be0d43eeb9'
sha=lambda b:hashlib.sha256(b).hexdigest()
def check(c,m):
 if not c: raise AssertionError(m)
manifest=json.loads((WORKER/'manifest.json').read_bytes()); index_raw=(WORKER/'records.json').read_bytes(); index=json.loads(index_raw); arc=(WORKER/'recording.tar.gz').read_bytes()
check(manifest['sourceHead']==index['sourceHead']==FROZEN and manifest['base']==BASE,'frozen source/base')
check(len(arc)==8055540 and sha(arc)=='ebba6b455cd12786a95b4531d6936e72906b9d5716a0f8234e9e5cffea95fb88','archive published digest')
check(sha(index_raw)=='bd2f737b4ae5b7ea03f87b4ce0c0c43c7e03cdf554beff461661142f81ab1741','index published digest')
check(manifest['archive']['sha256']==sha(arc) and manifest['recordIndex']['sha256']==sha(index_raw),'manifest digest')
records={x['path']:x for x in index['records']}; check(len(records)==65==manifest['records'],'unique complete index')
member={}
with tarfile.open(WORKER/'recording.tar.gz','r:gz') as tar:
 for item in tar.getmembers():
  path=pathlib.PurePosixPath(item.name)
  check(item.isfile() and not path.is_absolute() and '..' not in path.parts and item.name not in member,'safe unique regular member')
  raw=tar.extractfile(item).read(); row=records.get(item.name)
  check(row and len(raw)==row['bytes'] and sha(raw)==row['sha256'],'member:'+item.name)
  member[item.name]=raw
check(set(member)==set(records),'exact member set')
extract=OUT/'authenticated-worker'; extract.mkdir(exist_ok=True)
for name,raw in member.items():
 path=extract/name; path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(raw)
source_rows=[]; outputs=[]
for prefix,receipt_name in [('hot','hot/receipt.json'),('cold','cold/acceptance/receipt.json')]:
 receipt=json.loads(member[receipt_name]); base='hot/' if prefix=='hot' else 'cold/acceptance/'
 check(receipt['gitHead']==FROZEN and receipt['status']=='passed','receipt head')
 check(len({x['path'] for x in receipt['sources']})==len(receipt['sources'])==203,'source set')
 check(len({x['path'] for x in receipt['records']})==len(receipt['records'])==27,'record set')
 for x in receipt['records']:
  raw=member[base+x['path']]; check(len(raw)==x['bytes'] and sha(raw)==x['sha256'],'receipt artifact:'+base+x['path'])
 coldroot=pathlib.Path(json.loads(member['cold/report.json'])['clone'])
 for x in receipt['sources']:
  name=x['path']
  if name.startswith('renderer/virgl-shader/build/'):
   if prefix=='hot': raw=member['generated/'+name.removeprefix('renderer/virgl-shader/build/')]
   else: raw=(coldroot/name).read_bytes()
  else: raw=subprocess.check_output(['git','show',FROZEN+':'+name])
  check(sha(raw)==x['sha256'] and len(raw)==x['bytes'],'source/generated:'+prefix+':'+name)
  source_rows.append(dict(recording=prefix,**x))
 for x in receipt['records']:
  if x['path'].endswith('/report.json'):
   value=json.loads(member[base+x['path']]); check(value['gitHead']==FROZEN,'child head:'+base+x['path'])
 outputs.append(dict(recording=prefix,receiptSha256=sha(member[receipt_name]),sources=len(receipt['sources']),records=len(receipt['records'])))
cold=json.loads(member['cold/report.json']); check(cold['status']=='passed' and cold['cloneHead']==cold['gitHead']==FROZEN and cold['exitCode']==0 and cold['statusBefore']==cold['statusAfter']=='','cold exact/pristine')
check(sha(member['cold/cold.log'])==cold['logSha256'] and sha(member['cold/acceptance/receipt.json'])==cold['receiptSha256'],'cold child binding')
check(cold['removedEnvironmentNames']==sorted(cold['removedEnvironmentNames']),'scrub log names')
check(sha(member['hot/receipt.json'])==manifest['hotReceiptSha256'] and sha(member['cold/report.json'])==manifest['coldReportSha256'] and sha(member['cold/acceptance/receipt.json'])==manifest['coldReceiptSha256'],'manifest receipts')
report=dict(task='E6-T12g6d',prediction='P1',verdict='HELD',sourceHead=FROZEN,archiveSha256=sha(arc),recordIndexSha256=sha(index_raw),authenticatedMembers=65,authenticatedBytes=sum(len(x) for x in member.values()),receipts=outputs,cold=cold,sources=source_rows)
(OUT/'authentication.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['sources','cold']},indent=2)); print(json.dumps({'cold':cold,'members':list(member)},indent=2))
