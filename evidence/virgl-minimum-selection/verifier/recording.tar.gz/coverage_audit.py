#!/usr/bin/env python3
import hashlib, json, re, subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
UNPACK=OUT/'unpacked'
sha=lambda b:hashlib.sha256(b).hexdigest()
audits=[]
shown={}
for prefix,generated in [('hot','generated'),('cold/acceptance','cold-generated')]:
    binary=UNPACK/generated/'minimum-selection-sanitize/minimum-selection-test'
    profile=UNPACK/prefix/'native/native.profdata'
    export=json.loads(subprocess.check_output(['xcrun','llvm-cov','export',str(binary),'-instr-profile='+str(profile)]))
    for data in export['data']:
        data['files']=[f for f in data['files'] if any(f['filename'].endswith('/'+name) for name in ['bridge.c','raw_bits.c','native_tests/minimum_selection.c'])]
        data['functions']=[f for f in data['functions'] if any(any(n.endswith('/'+s) for s in ['bridge.c','raw_bits.c','native_tests/minimum_selection.c']) for n in f['filenames'])]
    original=json.loads((UNPACK/prefix/'native/coverage.json').read_bytes())
    assert export==original,prefix+' actual binary/profile export differs'
    (OUT/(prefix.split('/')[0]+'-coverage-export.json')).write_text(json.dumps(export,indent=2)+'\n')
    totals=[]
    for data in export['data']:
        for f in data['files']:
            text=subprocess.check_output(['xcrun','llvm-cov','show',str(binary),'-instr-profile='+str(profile),f['filename'],'-show-line-counts-or-regions'],text=True)
            name=Path(f['filename']).name
            (OUT/(prefix.split('/')[0]+'-coverage-'+name+'.txt')).write_text(text)
            lines={}
            for row in text.splitlines():
                match=re.match(r'^\s*(\d+)\|\s*([^|]*)\|(.*)$',row)
                if match:
                    count=match[2].strip()
                    lines[int(match[1])]={'displayCount':count,'source':match[3]}
            shown[(prefix,name)]=lines
            totals.append({'source':name,'summary':f['summary']})
    audits.append({'prefix':prefix,'binarySha256':sha(binary.read_bytes()),'profileSha256':sha(profile.read_bytes()),'recordedExportMatches':True,'files':totals})

paths=['renderer/virgl-shader/bridge.c','renderer/virgl-shader/raw_bits.c','renderer/virgl-shader/raw_bits.h','renderer/virgl-command/constant-domain.mjs']
patch=subprocess.check_output(['git','diff','--unified=0','79cae493','22be542a','--',*paths],cwd=ROOT,text=True)
(OUT/'runtime.diff').write_text(patch)
changes=[]
file=None; line=0; hunk=None
for row in patch.splitlines():
    if row.startswith('+++ b/'):file=row[6:]
    elif row.startswith('@@'):
        line=int(re.search(r'\+(\d+)',row)[1]);hunk=row
    elif row.startswith('+') and not row.startswith('+++'):
        code=row[1:]
        counts=[]
        if file.endswith('.c'):
            for prefix in ['hot','cold/acceptance']:
                counts.append(shown[(prefix,Path(file).name)].get(line,{}).get('displayCount',''))
        changes.append({'file':file,'line':line,'source':code,'hunk':hunk,'nativeCounts':counts})
        line+=1
    elif row.startswith(' ') and not row.startswith(' ---'):line+=1
for item in changes:
    source=item['source'].strip();file=item['file']
    if file.endswith('.h'):
        item.update(classification='waived',reason='Static opcode declarations/masks/assertion; executing both emitted MIN modes and compiling static assertions proves this data.')
    elif file.endswith('.c'):
        positive=any(x and x!='0' for x in item['nativeCounts'])
        if positive:item.update(classification='executed',reason='Positive actual recorded LLVM line count.')
        elif source=='}' or source=='{' or source.startswith('/*') or source.startswith('*') or not source:
            item.update(classification='waived',reason='Non-executable delimiter/comment; adjacent body execution proves the hunk.')
        elif source.startswith('static void minimum_contract'):
            item.update(classification='waived',reason='Function declaration; actual minimum_contract entry/body count proves execution.')
        else:item.update(classification='needs-evidence',reason='No positive changed-line count; inspect exact region before verdict.')
    else:
        item.update(classification='pending-js',reason='Needs exact served-source V8 coverage or independent consumer recording.')
result={'task':'E6-T12g6g1','nativeBinaryBindings':audits,'runtimeAddedLines':changes,
        'nativeNeedsEvidence':[i for i in changes if i['classification']=='needs-evidence']}
(OUT/'coverage-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'matchedNativeExports':len(audits),'changedRuntimeLines':len(changes),'nativeNeedsEvidence':result['nativeNeedsEvidence']},indent=2))
