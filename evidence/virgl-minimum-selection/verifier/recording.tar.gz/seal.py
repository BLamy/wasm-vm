#!/usr/bin/env python3
import gzip,hashlib,io,json,tarfile
from pathlib import Path

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
sha=lambda b:hashlib.sha256(b).hexdigest()
verdict=json.loads((OUT/'verdict.json').read_bytes());assert verdict['verdict']=='verified'
promoted=ROOT/verdict['promoted']['path'];assert sha(promoted.read_bytes())==verdict['promoted']['testSha256']
(OUT/'promoted').mkdir(exist_ok=True)
(OUT/'promoted'/promoted.name).write_bytes(promoted.read_bytes())
members={}
for p in sorted(OUT.iterdir()):
    if p.is_file() and p.name not in ['manifest.json','records.json','recording.tar.gz']:
        members[p.name]=p.read_bytes()
for folder in ['node-consumer-coverage','gpu-19088743','promoted']:
    for p in sorted((OUT/folder).rglob('*')):
        if p.is_file():members[str(p.relative_to(OUT))]=p.read_bytes()
for name in ['sabotage/renderer/virgl-shader/raw_bits.c','sabotage/renderer/virgl-shader/build/native/virgl-shader']:
    members[name]=(OUT/name).read_bytes()
assert sha(members['sabotage/renderer/virgl-shader/build/native/virgl-shader'])==json.loads(members['sabotage-regressions.json'])['nativeBinary']['sha256']
for finding in verdict['findings']:
    for citation in finding['citations']:assert sha(members[citation['path']])==citation['sha256']
index={'schema':'virgl-minimum-selection-verifier-records-v1','task':'E6-T12g6g1','sourceHead':verdict['sourceHead'],'records':[{'path':name,'bytes':len(raw),'sha256':sha(raw)} for name,raw in sorted(members.items())]}
index_raw=(json.dumps(index,indent=2)+'\n').encode();(OUT/'records.json').write_bytes(index_raw)
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0) as zipped:
    with tarfile.open(fileobj=zipped,mode='w') as tar:
        for name,raw in sorted(members.items()):
            info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
archive=buffer.getvalue();(OUT/'recording.tar.gz').write_bytes(archive)
worker=OUT.parent/'worker';wm=json.loads((worker/'manifest.json').read_bytes())
carry=json.loads(members['carry-forward.json'])
manifest={'schema':'virgl-minimum-selection-verifier-seal-v1','task':'E6-T12g6g1','verdict':'verified','sourceHead':verdict['sourceHead'],'runtimeHead':verdict['runtimeHead'],'workerSubmissionHead':verdict['workerSubmissionHead'],'base':verdict['base'],
    'records':len(members),'archive':{'path':'recording.tar.gz','bytes':len(archive),'sha256':sha(archive)},'recordIndex':{'path':'records.json','bytes':len(index_raw),'sha256':sha(index_raw)},
    'verdictRecord':{'path':'verdict.json','bytes':len(members['verdict.json']),'sha256':sha(members['verdict.json'])},'workerDependencies':{'manifestSha256':sha((worker/'manifest.json').read_bytes()),'archive':wm['archive'],'recordIndex':wm['recordIndex']},
    'priorHeldSeals':carry['priorSeals'],'promoted':verdict['promoted'],'held':11,'failed':0,'needsEvidence':0,'coverage':{'hunks':32,'addedRuntimeLines':69,'needsEvidence':0,'dead':0},'frozenWords':333504,'frozenPixels':34688,'fourthWords':55224,'fourthPixels':5440,'productionNegotiation':False,'guestExecution':False}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
seen=set();rows={r['path']:r for r in index['records']}
with tarfile.open(OUT/'recording.tar.gz','r:gz') as tar:
    for entry in tar.getmembers():
        assert entry.isfile() and entry.name not in seen and entry.name in rows
        raw=tar.extractfile(entry).read();row=rows[entry.name];assert len(raw)==row['bytes'] and sha(raw)==row['sha256'];seen.add(entry.name)
assert seen==set(rows)
print(json.dumps({'records':len(members),'archive':manifest['archive'],'index':manifest['recordIndex'],'verdict':manifest['verdictRecord'],'promoted':manifest['promoted']},indent=2))
