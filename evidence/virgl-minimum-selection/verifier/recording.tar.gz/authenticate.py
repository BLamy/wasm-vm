#!/usr/bin/env python3
import hashlib, json, subprocess, tarfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
WORKER = OUT.parent / 'worker'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
manifest = json.loads((WORKER / 'manifest.json').read_bytes())
index_raw = (WORKER / 'records.json').read_bytes()
archive = (WORKER / 'recording.tar.gz').read_bytes()
for name, raw in [('archive', archive), ('recordIndex', index_raw)]:
    assert len(raw) == manifest[name]['bytes'] and sha(raw) == manifest[name]['sha256'], name
assert sha(archive) == '4cde54d259703ba0c62f7f70f88820fdb53faa06621f5b7b0d5f372066ebc394'
assert sha(index_raw) == '97bb60698f66009bfa1bf0fe498797b9c2601967693c61f7f9017bf18e6456a7'
index = json.loads(index_raw)
entries = {x['path']: x for x in index['records']}
assert len(entries) == len(index['records']) == manifest['records'] == 82
assert manifest['sourceHead'] == index['sourceHead'] == '2be8709b05a9f6bcaf9f2a543a62d9eda37656ed'
unpacked = OUT / 'unpacked'
unpacked.mkdir(exist_ok=True)
members = []
with tarfile.open(WORKER / 'recording.tar.gz', 'r:gz') as tar:
    for member in tar.getmembers():
        assert member.isfile() and member.name in entries and member.name not in members
        part = PurePosixPath(member.name)
        assert not part.is_absolute() and '..' not in part.parts
        raw = tar.extractfile(member).read()
        row = entries[member.name]
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], member.name
        dest = unpacked / member.name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(raw)
        members.append(member.name)
assert set(members) == set(entries)
receipt_names = [('hot/receipt.json', 'hotReceiptSha256'), ('cold/report.json', 'coldReportSha256'), ('cold/acceptance/receipt.json', 'coldReceiptSha256')]
for path, key in receipt_names:
    assert sha((unpacked / path).read_bytes()) == manifest[key], key
head = git('rev-parse', 'HEAD').decode().strip()
assert head.startswith('22be542a')
changed_after = git('diff', '--name-only', manifest['sourceHead'], head).decode().splitlines()
assert all(x.startswith('evidence/') or x.startswith('tasks/') for x in changed_after), changed_after
runtime = ['renderer/virgl-shader/bridge.c', 'renderer/virgl-shader/raw_bits.c', 'renderer/virgl-shader/raw_bits.h', 'renderer/virgl-command/constant-domain.mjs']
frozen = '2412ecf2e4350cd21eadf10b3f022fdbd7e75e1d'
for path in runtime:
    assert git('show', frozen + ':' + path) == git('show', head + ':' + path) == (ROOT / path).read_bytes(), path
authenticated = []
for prefix, generated in [('hot', 'generated'), ('cold/acceptance', 'cold-generated')]:
    receipt = json.loads((unpacked / prefix / 'receipt.json').read_bytes())
    assert receipt['gitHead'] == manifest['sourceHead'] and receipt['status'] == 'passed'
    for row in receipt['records']:
        raw = (unpacked / prefix / row['path']).read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['path']
    for row in receipt['sources']:
        path = row['path']
        if path.startswith('renderer/virgl-shader/build/'):
            raw = (unpacked / generated / path.removeprefix('renderer/virgl-shader/build/')).read_bytes()
        else:
            raw = git('show', receipt['gitHead'] + ':' + path)
            assert raw == (ROOT / path).read_bytes(), path
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], path
    reports = []
    for p in sorted((unpacked / prefix).rglob('*.json')):
        value = json.loads(p.read_bytes())
        if not isinstance(value, dict) or 'gitHead' not in value:
            continue
        recorded = value['gitHead']
        subprocess.run(['git', 'merge-base', '--is-ancestor', recorded, receipt['gitHead']], cwd=ROOT, check=True)
        files = git('diff', '--name-only', recorded, receipt['gitHead']).decode().splitlines()
        allowed = receipt['incrementalHarnessRepairs']
        assert set(files) <= set(allowed), (p, files)
        for row in value.get('sources', []):
            path = row['path']
            if path.startswith('renderer/virgl-shader/build/'):
                raw = (unpacked / generated / path.removeprefix('renderer/virgl-shader/build/')).read_bytes()
            else:
                raw = git('show', recorded + ':' + path)
            assert sha(raw) == row['sha256'] and len(raw) == row.get('size', row.get('bytes')), (p, path)
        for row in value.get('servedFiles', []):
            path = row['path']
            if path.startswith('renderer/virgl-shader/build/'):
                raw = (unpacked / generated / path.removeprefix('renderer/virgl-shader/build/')).read_bytes()
            else:
                raw = git('show', recorded + ':' + path)
            assert sha(raw) == row['sha256'] and len(raw) == row['size'], (p, path)
        reports.append({'path': str(p.relative_to(unpacked)), 'head': recorded, 'incrementalChangedFiles': files})
    authenticated.append({'prefix': prefix, 'records': len(receipt['records']), 'sources': len(receipt['sources']), 'reports': reports})
cold = json.loads((unpacked / 'cold/report.json').read_bytes())
assert cold['status'] == 'passed' and cold['gitHead'] == cold['cloneHead'] == manifest['sourceHead']
assert cold['statusBefore'] == cold['statusAfter'] == '' and cold['exitCode'] == 0
assert cold['receiptSha256'] == manifest['coldReceiptSha256']
assert cold['logSha256'] == sha((unpacked / 'cold/cold.log').read_bytes())
result = {'task': 'E6-T12g6g1', 'status': 'passed', 'submission': head, 'recordingHead': manifest['sourceHead'], 'runtimeFreeze': frozen,
          'memberCount': len(members), 'archiveSha256': sha(archive), 'indexSha256': sha(index_raw), 'runtimeSourceHashes': {p: sha((ROOT/p).read_bytes()) for p in runtime},
          'authenticated': authenticated, 'cold': cold}
(OUT / 'authentication.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': 'passed', 'members': len(members), 'sources': [x['sources'] for x in authenticated], 'coldHead': cold['cloneHead']}))
