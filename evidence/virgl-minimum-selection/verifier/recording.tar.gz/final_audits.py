#!/usr/bin/env python3
import hashlib,json,subprocess
from pathlib import Path
from source_semantics import interpret,word

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];UNPACK=OUT/'unpacked'
sha=lambda b:hashlib.sha256(b).hexdigest()
faults=[]
for prefix in ['hot','cold/acceptance']:
    path=UNPACK/prefix/'fault-selection/report.json';raw=path.read_bytes();report=json.loads(raw);a=report['acceptance']
    assert report['status']==a['status']=='failed' and report['browserErrors']=={'console':[],'page':[],'requests':[]}
    vertices=[(i,v) for i,v in enumerate(a['vertices']) if v['mutation']];assert len(vertices)==1
    index,v=vertices[0];mutation=v['mutation'];assert mutation['original']==v['pair']['vertex']['glsl']
    assert mutation['served']==mutation['original'].replace(mutation['needle'],mutation['replacement'],1)
    assert mutation['original']!=mutation['served'] and mutation['served'] in [e['source'] for e in a['events'] if e['call']=='shaderSource']
    point=next((i,x) for i,x in enumerate(v['vectors']) if 'failure' in x);vi,x=point
    bank=[0]*184;bank[:4]=x['input']['a'];bank[180:184]=x['input']['b'];bank[172]=x['condition']
    state,ops=interpret(v['text'],{0:[word(x) for x in x['position']]},bank)
    selected=state['OUT',0]+state['OUT',1]+state['OUT',2]
    failure=x['failure'];lane=failure['lane'];assert failure['expected'] in selected[lane] and failure['actual'] not in selected[lane]
    assert x['observed'][lane]==failure['actual'] and sha(bytes(x['bytes']))==x['sha256']
    assert 'independent scalar word mismatch' in a['failure']['message'] and a['objects']['live']==0
    faults.append({'report':str(path.relative_to(OUT)),'reportSha256':sha(raw),'point':f'acceptance.vertices[{index}].vectors[{vi}].failure','source':v['text'],'predictedCarrierWords':[sorted(s) for s in selected],'observed':x['observed'],'failure':failure,'mutation':mutation,'allDisposed':True})
sabotage=json.loads((OUT/'sabotage-regressions.json').read_bytes());s=sabotage['failure']['counterexample']
assert sabotage['status']=='failed' and s['name']=='precise-selected-1-0-none-bit-0' and s['ok'] is True and s['result']['ok'] is False
assert s['expectedWord']==s['expectedBit']==0
source=json.loads((OUT/'sabotage-source.json').read_bytes())
assert sha((ROOT/'renderer/virgl-shader/raw_bits.c').read_bytes())==source['originalSha256']
sensitivity={'task':'E6-T12g6g1','status':'passed','physicalFaults':faults,'sabotage':{'testSha256':sabotage['testSha256'],'binary':sabotage['nativeBinary'],'point':'failure.counterexample','case':s,'reportSha256':sha((OUT/'sabotage-regressions.json').read_bytes()),'sourceSha256':source['mutantSha256']}}
(OUT/'sensitivity.json').write_text(json.dumps(sensitivity,indent=2)+'\n')

reports=list((UNPACK/'hot').glob('gpu-*/report.json'))+list((UNPACK/'cold/acceptance').glob('gpu-*/report.json'))+[UNPACK/'hot/fault-selection/report.json',UNPACK/'cold/acceptance/fault-selection/report.json',OUT/'gpu-19088743/report.json']
profiles=[];lifetimes=[]
for p in reports:
    r=json.loads(p.read_bytes());a=r['acceptance'];created={e['id'] for e in a['events'] if e['call'].startswith('create') or e['call']=='fenceSync'};deleted={e['id'] for e in a['events'] if e['call'].startswith('delete')}
    assert created<=deleted and len(created)==a['objects']['created'] and a['objects']['live']==0
    for record in a['consumers']+a['bankDraws']:
        assert all(v==0 for v in record['finalBudgets'].values()) and all(v==0 for v in record['finalResourceBudgets'].values())
    owned=[arg for arg in r['browser']['actualCommandLine'] if arg.startswith('--user-data-dir=')];profiles+=owned
    lifetimes.append({'report':str(p.relative_to(OUT)),'createdObjects':len(created),'deletedObjects':len(created&deleted),'live':0,'consumerBudgets':[c['finalBudgets'] for c in a['consumers']],'drawBudgets':[c['finalBudgets'] for c in a['bankDraws']]})
processes=subprocess.check_output(['ps','-axo','pid,args'],text=True)
matching=[line for line in processes.splitlines() if any(arg in line for arg in profiles)]
assert not matching,matching
cleanup={'task':'E6-T12g6g1','status':'passed','lifetimes':lifetimes,'ownedBrowserProfileArguments':profiles,'matchingOwnedProcesses':matching}
(OUT/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')

promoted=json.loads((OUT/'independent-regressions.json').read_bytes());assert promoted['status']=='passed' and promoted['cases']==len(promoted['native'])==len(promoted['wasm'])==4524
test=ROOT/'renderer/virgl-shader/tests/minimum-selection-regressions.mjs';assert sha(test.read_bytes())==promoted['testSha256']==sabotage['testSha256']
assert promoted['nativeBinary']['sha256']==sha((UNPACK/'generated/native/virgl-shader').read_bytes())
for prefix,generated in [('hot','generated'),('cold/acceptance','cold-generated')]:
    for name in ['native/virgl-shader','wasm/virgl-shader.wasm','wasm/virgl-shader.mjs','minimum-selection-primary.json']:
        if prefix=='hot':assert (ROOT/'renderer/virgl-shader/build'/name).read_bytes()==(UNPACK/generated/name).read_bytes(),name
frozen=['renderer/virgl-shader/bridge.c','renderer/virgl-shader/raw_bits.c','renderer/virgl-shader/raw_bits.h','renderer/virgl-command/constant-domain.mjs']
for p in frozen:assert (ROOT/p).read_bytes()==subprocess.check_output(['git','show','2412ecf2e4350cd21eadf10b3f022fdbd7e75e1d:'+p],cwd=ROOT)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
result={'task':'E6-T12g6g1','status':'passed','promoted':{'path':str(test.relative_to(ROOT)),'schema':promoted['schema'],'cases':promoted['cases'],'testSha256':promoted['testSha256'],'nativeBinary':promoted['nativeBinary'],'reportSha256':sha((OUT/'independent-regressions.json').read_bytes())},'runtimeUnmodified':True,'sealedHotBuildUnmodified':True,'coldClonesAddedByCritic':0,'commits':0,'productionNegotiation':False,'guestExecution':False}
(OUT/'final-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'passed','physicalSourceFaults':len(faults),'promotedCases':4524,'sabotage':'caught','closedRuns':len(lifetimes),'ownedProcesses':len(matching)}))
