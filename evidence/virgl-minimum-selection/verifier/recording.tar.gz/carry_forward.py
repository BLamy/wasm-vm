#!/usr/bin/env python3
import hashlib,json,subprocess,tarfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT)
parent='79cae493';head=git('rev-parse','HEAD').decode().strip()
dependencies=[]
for name in ['virgl-scalar-operations','virgl-signed-conversions','virgl-signed-integers','virgl-hex-literals','virgl-compiler-bounds']:
    path=ROOT/'evidence'/name/'verifier'
    manifest=json.loads((path/'manifest.json').read_bytes());index_row=manifest.get('recordIndex',manifest.get('index'));raw=(path/manifest['archive']['path']).read_bytes();idxraw=(path/index_row['path']).read_bytes()
    assert len(raw)==manifest['archive']['bytes'] and sha(raw)==manifest['archive']['sha256']
    assert len(idxraw)==index_row.get('bytes',len(idxraw)) and sha(idxraw)==index_row['sha256']
    index=json.loads(idxraw);entries={x['path']:x for x in index['records']};seen=set()
    with tarfile.open(path/manifest['archive']['path'],'r:gz') as tar:
        for member in tar.getmembers():
            assert member.isfile() and member.name not in seen and member.name in entries
            data=tar.extractfile(member).read();row=entries[member.name]
            assert len(data)==row['bytes'] and sha(data)==row['sha256'];seen.add(member.name)
    assert seen==set(entries)
    dependencies.append({'boundary':name,'manifestSha256':sha((path/'manifest.json').read_bytes()),'archiveSha256':sha(raw),'indexSha256':sha(idxraw),'members':len(seen),'verdict':manifest.get('verdict')})
unchanged=[]
scalar=ROOT/'evidence/virgl-scalar-operations/worker'
worker_manifest=json.loads((scalar/'manifest.json').read_bytes())
worker_index=json.loads((scalar/'records.json').read_bytes())
assert sha((scalar/'recording.tar.gz').read_bytes())==worker_manifest['archive']['sha256']
assert sha((scalar/'records.json').read_bytes())==worker_manifest['recordIndex']['sha256']
worker_rows={r['path']:r for r in worker_index['records']}
with tarfile.open(scalar/'recording.tar.gz','r:gz') as tar:
    data=tar.extractfile('hot/retained/report.json').read()
    assert len(data)==worker_rows['hot/retained/report.json']['bytes'] and sha(data)==worker_rows['hot/retained/report.json']['sha256']
    previous_retained=json.loads(data)
paths=git('ls-files','renderer/virgl-shader','renderer/virgl-command','tools/lib/virgl-browser-runner.mjs','tools/setup-virgl-emsdk.sh').decode().splitlines()
changed=set(git('diff','--name-only',parent,head).decode().splitlines())
for path in paths:
    if path in changed:continue
    old=git('show',parent+':'+path);current=(ROOT/path).read_bytes();assert old==current,path
    unchanged.append({'path':path,'sha256':sha(current)})
def function(text,name):
    import re
    m=re.search(r'^.*\b'+name+r'\([^;]*?\)\n\{',text,re.M);assert m,name
    start=m.start();at=m.end();level=1
    while level:
        if text[at]=='{':level+=1
        if text[at]=='}':level-=1
        at+=1
    return text[start:at]
helpers=[]
for path,names in [('renderer/virgl-shader/raw_bits.c',['ordered_float_mask','equal_float_mask','safe_raw_float','float_mode','output_legal','raw_join','selected','raw_consumed_mask','precise_source','raster_source']),('renderer/virgl-shader/bridge.c',['precise_profile','arithmetic_contract','raster_contract','conversion_contract','scalar_contract'])]:
    old=git('show',parent+':'+path).decode();now=(ROOT/path).read_text()
    for name in names:
        before=function(old,name);after=function(now,name);assert before==after,name
        helpers.append({'path':path,'function':name,'sha256':sha(before.encode())})
rows=[]
for prefix in ['hot','cold/acceptance']:
    base=OUT/'unpacked'/prefix
    retained=json.loads((base/'retained/report.json').read_bytes())
    assert len(retained['originals'])==25 and sum(c['native']['ok'] for c in retained['originals'])==23
    assert len(retained['historical'])==112 and sum(c['native']['ok'] for c in retained['historical'])==5
    assert retained['originals']==previous_retained['originals'] and retained['historical']==previous_retained['historical']
    for c in retained['originals']:assert c['native']==c['wasm']
    legacy=json.loads((base/'legacy.json').read_bytes());assert len(legacy['cases'])==84
    for c in legacy['cases']:
        assert c['old']['ok']==c['added']['ok']==c['ok']
        if c['ok']:
            md=dict(c['added']['metadata']);md['profile']=md.pop('minimumBaseProfile');md.pop('minimumWordContract');old=dict(c['old']['metadata'])
            if c['baseTransition']:assert c['name'] in ['pass-vertex','pass-fragment'];old['profile']='virgl-webgl2-raw-bits-v1'
            assert md==old,c['name']
    guards=[]
    for filename,count,test in [('independent-joins.json',402,'compiler-bounds-joins.mjs'),('independent-hex-guards.json',49,'hex-literal-regressions.mjs'),('independent-signed-guards.json',108,'signed-integer-regressions.mjs'),('independent-conversion-guards.json',1575,'signed-conversion-regressions.mjs'),('independent-scalar-guards.json',1427,'scalar-operation-regressions.mjs')]:
        guard=json.loads((base/filename).read_bytes());assert guard['status']=='passed' and guard['cases']==len(guard['native'])==len(guard['wasm'])==count
        for a,b in zip(guard['native'],guard['wasm']):
            if a['result'].get('error',{}).get('code')=='invalid-input':assert b['result'].get('error',{}).get('code')=='invalid-input'
            else:assert a['result']==b['result']
        old=git('show',parent+':renderer/virgl-shader/tests/'+test);assert old==(ROOT/'renderer/virgl-shader/tests'/test).read_bytes()
        if 'testSha256' in guard:assert sha(old)==guard['testSha256']
        guards.append({'path':filename,'cases':count,'reportSha256':sha((base/filename).read_bytes()),'unchangedTestSha256':sha(old)})
    rows.append({'prefix':prefix,'retainedOriginals':25,'retainedAdmissions':23,'historical':112,'historicalAdmissions':5,'legacyPrecision':84,'guards':guards})
result={'task':'E6-T12g6g1','status':'passed','parent':parent,'submission':head,'priorSeals':dependencies,'unchangedDependencies':unchanged,'unchangedHelpers':helpers,'currentRecordedGuards':rows,'changedPaths':sorted(changed),'carryPolicy':'Carry only immutable previous evidence and unchanged helpers/dependency bytes; changed dispatcher/parser paths have fresh MIN coverage and current legacy/guard results.'}
(OUT/'carry-forward.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'passed','priorSeals':len(dependencies),'unchangedFiles':len(unchanged),'unchangedHelpers':len(helpers),'legacyCases':84}))
