import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {parseConstantDomain,checkConversionBank,checkIndirectBank,checkRasterBank,checkRadialBank,checkLoopBank} from '../../../renderer/virgl-command/constant-domain.mjs';

const out=path.dirname(fileURLToPath(import.meta.url));
const native=JSON.parse(fs.readFileSync(path.join(out,'unpacked/hot/native/report.json')));
const report={task:'E6-T12g6g1',status:'running',metadata:[],ownership:[],banks:[],getterCalls:0};
const inert=value=>{if(value===null||typeof value!=='object')return value;const result=Array.isArray(value)?[]:{};
  for(const [k,d] of Object.entries(Object.getOwnPropertyDescriptors(value))) if(d.enumerable) result[k]=Object.hasOwn(d,'value')?inert(d.value):'[accessor]';return result;};
const fail=(md,stage,name)=>{const result=parseConstantDomain(md,stage);assert.equal(result.ok,false,name);assert.equal(result.error.code,'shader-domain-error');report.metadata.push({name,metadata:inert(md),predicted:false,result});};
const seen=new Set();
for(const c of native.cases.filter(c=>c.ok)){
  const md=c.result.metadata,key=JSON.stringify(md);if(seen.has(key))continue;seen.add(key);
  const ownedInput=structuredClone(md),parsed=parseConstantDomain(ownedInput,c.stage);assert.equal(parsed.ok,true);assert.ok(Object.isFrozen(parsed)&&Object.isFrozen(parsed.minimum)&&Object.isFrozen(parsed.minimum.operations));
  const before=JSON.stringify(parsed);ownedInput.minimumWordContract.operations.splice(0,2,'INVALID');ownedInput.minimumWordContract.ordinary='fabricated';ownedInput.minimumBaseProfile='invalid';
  for(const k of ['constantDomains','constantAccesses','constantConstraints','constantRadialDomains','constantRasterDomains','constantConversionDomains']) if(ownedInput[k]?.[0]) ownedInput[k][0].count=9999;
  assert.equal(JSON.stringify(parsed),before,'owned complete policy snapshot');report.ownership.push({name:c.name,before:JSON.parse(before),after:parsed,minimumFrozen:true});
  for(const field of ['kind','stage','operations','ordinary','precise','modifiers','output']){
    for(const value of [null,true,1,0,{},[],NaN,Infinity,'invalid']){
      const m=structuredClone(md);m.minimumWordContract[field]=value;fail(m,c.stage,c.name+'/'+field+'/'+JSON.stringify(value));
    }
    const m=structuredClone(md);delete m.minimumWordContract[field];fail(m,c.stage,c.name+'/missing '+field);
    const accessor=structuredClone(md);Object.defineProperty(accessor.minimumWordContract,field,{enumerable:true,get(){report.getterCalls++;throw Error('getter invoked');}});fail(accessor,c.stage,c.name+'/accessor '+field);
    const inherited=structuredClone(md);delete inherited.minimumWordContract[field];Object.setPrototypeOf(inherited.minimumWordContract,{get [field](){report.getterCalls++;return md.minimumWordContract[field];}});fail(inherited,c.stage,c.name+'/inherited '+field);
  }
  for(const operations of [[],['MIN','MIN','MIN'],['MIN_PRECISE','MIN'],['MIN',false],[, 'MIN'],Array(2),['MINIMUM']]){
    const m=structuredClone(md);m.minimumWordContract.operations=operations;fail(m,c.stage,c.name+'/hostile operation array '+report.metadata.length);
  }
  for(const style of ['symbol','hidden','index getter','inherited hole']){
    const m=structuredClone(md),a=m.minimumWordContract.operations;
    if(style==='symbol')a[Symbol('secret')]='MIN';
    if(style==='hidden')Object.defineProperty(a,'hidden',{value:'MIN'});
    if(style==='index getter')Object.defineProperty(a,'0',{enumerable:true,get(){report.getterCalls++;return 'MIN';}});
    if(style==='inherited hole'){delete a[0];const proto=Object.create(Array.prototype);Object.defineProperty(proto,'0',{get(){report.getterCalls++;return 'MIN';}});Object.setPrototypeOf(a,proto);}
    fail(m,c.stage,c.name+'/array '+style);
  }
  for(const field of ['minimumBaseProfile','minimumWordContract','profile']){
    const m=structuredClone(md);Object.defineProperty(m,field,{enumerable:true,get(){report.getterCalls++;return md[field];}});fail(m,c.stage,c.name+'/outer accessor '+field);
  }
  for(const base of ['virgl-webgl2-raw-bits-v32','virgl-webgl2-raw-bits-v33','virgl-webgl2-raw-bits-v0','virgl-webgl2-straight-line-v5',null,31]){
    const m=structuredClone(md);m.minimumBaseProfile=base;fail(m,c.stage,c.name+'/bad minimum base '+base);
  }
  for(const field of ['constantDomains','constantAccesses','constantConstraints','constantRadialDomains','constantRasterDomains','constantConversionDomains','preciseWordContract','rasterBaseProfile','arithmeticBaseProfile','preciseArithmeticContract','conversionBaseProfile','signedConversionContract','scalarBaseProfile','scalarWordContract']) if(Object.hasOwn(md,field)){
    const m=structuredClone(md);delete m[field];fail(m,c.stage,c.name+'/cannot erase inherited '+field);
  }
  const symbol=structuredClone(md);symbol.minimumWordContract[Symbol('hidden policy')]=0;fail(symbol,c.stage,c.name+'/unknown policy symbol');
  const downgrade=structuredClone(md);downgrade.profile=downgrade.minimumBaseProfile;fail(downgrade,c.stage,c.name+'/downgrade with stray minimum policy');
  fail(structuredClone(md),c.stage==='vertex'?'fragment':'vertex',c.name+'/wrong stage');
}
const revoked=Proxy.revocable({},{});revoked.revoke();const result=parseConstantDomain(revoked.proxy,'vertex');assert.equal(result.ok,false);report.metadata.push({name:'revoked proxy',predicted:false,result});
assert.equal(report.getterCalls,0,'all hostile getters remain unexecuted');

const choices=['MIN-copied-bank-output','MIN_PRECISE-copied-bank-output',...native.cases.filter(c=>c.base).map(c=>c.name)];
const values=[0,0x80000000,1,0x80000001,0x007fffff,0x807fffff,0x00800000,0x80800000,0x3fc00000,0xbfc00000,0x4effffff,0x4f000000,0xcf000000,0xcf000001,0x7f7fffff,0xff7fffff,0x7f800000,0xff800000,0x7fc12345,0xffffffff];
for(const name of choices){
  const c=native.cases.find(c=>c.name===name),p=parseConstantDomain(c.result.metadata,c.stage);assert.equal(p.ok,true);
  if(!p.domain&&!p.conversionDomain&&!p.rasterDomain)continue;
  const count=(p.domain??p.conversionDomain??p.rasterDomain).count,words=Array(Math.min(count,46)*4).fill(0);if(p.radialDomain)words[16]=0x3f800000;
  const check=w=>p.conversionDomain?checkConversionBank(w,p.conversionDomain,p):p.rasterDomain?checkRasterBank(w,p.rasterDomain,!!p.constraint,!!p.radialDomain):p.radialDomain?checkRadialBank(w,count,!!p.constraint):p.constraint?checkLoopBank(w,count):checkIndirectBank(w,count,!!p.domain);
  const accepted=check(words);assert.equal(accepted.ok,true);const before=accepted.words.slice();words.fill(0xdeadbeef);assert.deepEqual(accepted.words,before);assert.ok(Object.isFrozen(accepted.words));
  const components=[...(p.rasterDomain?.components??[]),...(p.conversionDomain?.components??[])];
  const indices=[0,1,2,3,180,181,182,183].filter(i=>i<before.length);
  for(const index of indices)for(const value of values){
    const w=before.slice();w[index]=value;
    const special=(value&0x7f800000)===0x7f800000;
    const raster=p.rasterDomain?.components.some(c=>c.register===Math.floor(index/4)&&(c.mask&(1<<(index%4))));
    const range=p.conversionDomain?.components.some(c=>c.register===Math.floor(index/4)&&(c.mask&(1<<(index%4))));
    const normalZero=(value&0x7fffffff)===0||((value&0x7f800000)!==0&&!special);
    const defined=(value&0x7fffffff)<0x4f000000||(value>=0x80000000&&(value&0x7fffffff)===0x4f000000);
    const predicted=(!p.domain||!special)&&(!raster||normalZero)&&(!range||defined);
    const actual=check(w);assert.equal(actual.ok,predicted,name+'/'+index+'/'+value);
    report.banks.push({name,index,value,predicted,result:actual});
  }
  for(const length of [0,4,before.length-4]){const actual=check(before.slice(0,length));assert.equal(actual.ok,false,name+' complete declared prefix');report.banks.push({name,length,predicted:false,result:actual});}
}
report.status='passed';report.policySourceSha256=createHash('sha256').update(fs.readFileSync('renderer/virgl-command/constant-domain.mjs')).digest('hex');
fs.writeFileSync(path.join(out,'consumer-attacks.json'),JSON.stringify(report,null,2)+'\n');console.log(`${report.metadata.length} metadata attacks, ${report.banks.length} bank checks and ${report.ownership.length} immutable snapshots; zero getter calls.`);
