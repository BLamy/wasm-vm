#!/usr/bin/env python3
import hashlib,json,os,subprocess
from pathlib import Path

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];UNPACK=OUT/'unpacked'
sha=lambda b:hashlib.sha256(b).hexdigest()
replays=[]
for prefix,generated in [('hot','generated'),('cold/acceptance','cold-generated')]:
    native=json.loads((UNPACK/prefix/'native/report.json').read_bytes())
    binary=UNPACK/generated/'minimum-selection-sanitize/minimum-selection-test';binary.chmod(0o755)
    fixture=(UNPACK/prefix/'native/cases.bin').read_bytes()
    env=dict(os.environ,LLVM_PROFILE_FILE=str(OUT/(prefix.split('/')[0]+'-replay.profraw')),UBSAN_OPTIONS='halt_on_error=1',ASAN_OPTIONS='abort_on_error=1')
    run=subprocess.run([str(binary)],input=fixture,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
    assert not run.stderr and run.stdout==(UNPACK/prefix/'native/native.log').read_bytes(),prefix
    (OUT/(prefix.split('/')[0]+'-native-replay.log')).write_bytes(run.stdout)
    cases=primary=0
    for line in run.stdout.decode().splitlines():
        if line=='STATUS passed':continue
        label,index,value=line.split(' ',2);index=int(index);value=json.loads(value)
        if label=='CASE':assert value==native['cases'][index]['result'];cases+=1
        else:assert label=='PRIMARY' and value==native['cases'][index]['primaryResult'];primary+=1
    assert cases==961 and primary==913
    replays.append({'prefix':prefix,'actualBinarySha256':sha(binary.read_bytes()),'fixtureSha256':sha(fixture),'stdoutSha256':sha(run.stdout),'cases':cases,'primaryWitnesses':primary,'stderrBytes':len(run.stderr),'exitCode':run.returncode})

sources={}
for p in list((UNPACK/'hot').glob('gpu-*/report.json'))+list((UNPACK/'cold/acceptance').glob('gpu-*/report.json'))+[OUT/'gpu-19088743/report.json']:
    report=json.loads(p.read_bytes());a=report['acceptance'];events=a['events'];shader_sources={e['source'] for e in events if e['call']=='shaderSource'}
    bindings=[]
    for vertex in a['vertices']:
        sources['vertex',vertex['text']]=vertex['pair']['vertex']
        assert vertex['pair']['fragment']['glsl'] in shader_sources
        glsl=vertex['primary']['glsl'] if vertex['backend']=='mesa' else vertex['pair']['vertex']['glsl']
        assert glsl in shader_sources,'actual vertex shaderSource must match unmodified claimed GLSL'
        bindings.append({'stage':'vertex','textSha256':vertex['textSha256'],'backend':vertex['backend'],'actualShaderSourceSha256':sha(glsl.encode())})
    for fragment in a['fragments']:
        sources['fragment',fragment['text']]=fragment['pair']['fragment']
        glsl=fragment['primary']['glsl'] if fragment['backend']=='mesa' else fragment['pair']['fragment']['glsl']
        assert glsl in shader_sources and fragment['pair']['vertex']['glsl'] in shader_sources
        bindings.append({'stage':'fragment','textSha256':fragment['textSha256'],'backend':fragment['backend'],'actualShaderSourceSha256':sha(glsl.encode())})
    for draw in a['bankDraws']:
        for stage in ['vertex','fragment']:
            text=draw['sources'][stage];sources[stage,text]=draw['pair'][stage]
            assert draw['pair'][stage]['glsl'] in shader_sources
    if p==OUT/'gpu-19088743/report.json':fourth_bindings=bindings

binary=UNPACK/'generated/native/virgl-shader';binary.chmod(0o755)
parity=[]
for (stage,text),expected in sorted(sources.items()):
    result=json.loads(subprocess.check_output([str(binary),stage],input=text.encode()))
    assert result=={'ok':True,**expected},(stage,text)
    parity.append({'stage':stage,'text':text,'textSha256':sha(text.encode()),'result':result})
fixture=UNPACK/'generated/minimum-selection-primary.json'
native=json.loads((UNPACK/'hot/native/report.json').read_bytes())
assert json.loads(fixture.read_bytes())==[{'name':c['name'],'stage':c['stage'],'text':c['text'],'primary':c['primaryResult']} for c in native['cases'] if c['primary']]
result={'task':'E6-T12g6g1','status':'passed','replays':replays,'physicalSourceCount':len(parity),'sources':parity,'fourthBindings':fourth_bindings,'primaryFixtureSha256':sha(fixture.read_bytes())}
(OUT/'native-source-parity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'passed','actualReplays':len(replays),'physicalSources':len(parity),'primaryWitnessesPerReplay':913}))
