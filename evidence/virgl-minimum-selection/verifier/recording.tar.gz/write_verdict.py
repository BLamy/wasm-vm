#!/usr/bin/env python3
import hashlib,json
from pathlib import Path

OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
predictions=json.loads((OUT/'predictions.json').read_bytes())
def cite(path,point):return {'path':path,'point':point,'sha256':sha((OUT/path).read_bytes())}
facts=[
('All 82 actual members, 230 hot/224 cold source rows, both actual binaries/profiles and frozen source heads authenticate.', [cite('authentication.json','memberCount,authenticated,cold,runtimeSourceHashes')]),
('Source binary32 interpretation preserves precise ordered-less selection, second-operand ties/zero/NaN payloads and all original selected bits.',[cite('source-semantics.json','runs[].vertices[].vectors[].sourceOperation,predictedCarrierWords,reconstructedWords'),cite('independent-regressions.json','native/wasm:precise-selected-*')]),
('Ordinary MIN retains finite numeric authority and documented zero-sign freedom; private killed versions/unsafe literals reject and untouched raw lanes remain exact.',[cite('independent-regressions.json','native/wasm:MIN-killed-source-*,selected-raster-authority-*,saved-numeric-version-*'),cite('source-semantics.json','runs[].vertices:masked,mask-*,alias')]),
('All masks, swizzles, aliases, both source negations and conditional source versions use captured original source values; adjacent plain/precise and legacy precision inventories stay local.',[cite('independent-regressions.json','native/wasm:killed-source-*,aliased-selected-output-*,adjacent-local-precision'),cite('source-semantics.json','runs[].vertices[].vectors[].sourceOperation')]),
('2,606 independent hostile metadata cases reject without getters; 24 snapshots remain owned/frozen; 738 bank/prefix checks retain complete older obligations.',[cite('consumer-attacks.json','metadata,ownership,banks,getterCalls')]),
('Five previous critic seals, 242 unchanged dependency files and 15 unchanged helpers authenticate; originals, historical admissions, 84 legacy cases and all old guards carry forward unchanged.',[cite('carry-forward.json','priorSeals,unchangedDependencies,unchangedHelpers,currentRecordedGuards')]),
('Both actual sanitizer binaries replay identical complete logs and real primary witnesses. 601 physical source programs match compiler results, actual shaderSource events bind unchanged GLSL, and independent TGSI reproduces every frozen word/pixel and guarded draw/wait.',[cite('native-source-parity.json','replays,sources,fourthBindings,primaryFixtureSha256'),cite('source-semantics.json','runs[].vertices,fragments,draws')]),
('All 32 runtime hunks/69 added lines execute or have explicit structural waivers. Both actual LLVM exports reproduce the worker counts; independent source-bound V8 coverage executes the new policy paths. No dead or unproven runtime hunk.',[cite('coverage-audit.json','nativeBinaryBindings,runtimeAddedLines,v8Profiles,needsEvidence,dead')]),
('Both actual physical helper reversals contradict independent source equations at captured lane 6. The independent real C knowledge-selector reversal is caught at precise-selected-1-0-none-bit-0; all nine runs dispose objects/budgets and no owned browser process remains.',[cite('sensitivity.json','physicalFaults[].point,failure; sabotage.case'),cite('cleanup.json','lifetimes,matchingOwnedProcesses')]),
('The single final pristine clone has clean status before/after, scrubbed environment, exit zero and an authenticated full receipt at exact final harness 2be8709b. Earlier failed hot logs are retained, and all incremental changes are the declared recording-only files.',[cite('authentication.json','cold,authenticated[].reports[].incrementalChangedFiles')]),
('Fourth headed Apple M4 Max seed 19088743 independently reproduces 55,224 words/5,440 pixels. The new 4,524-case native/Wasm test covers selected bits/lane/version/authority and kills an isolated selector sabotage.',[cite('fourth-seed-semantics.json','runs[0]'),cite('independent-regressions.json','cases,native,wasm,testSha256,nativeBinary'),cite('sensitivity.json','sabotage')])]
assert len(facts)==len(predictions['predictions'])==11
checks=json.loads((OUT/'final-checks.json').read_bytes());assert checks['status']=='passed'
findings=[{'id':p['id'],'prediction':p['prediction'],'status':'HELD','observed':fact[0],'citations':fact[1]} for p,fact in zip(predictions['predictions'],facts)]
verdict={'schema':'virgl-minimum-selection-verifier-verdict-v1','task':'E6-T12g6g1','verdict':'verified','workerSubmissionHead':predictions['submission'],
 'sourceHead':'2be8709b05a9f6bcaf9f2a543a62d9eda37656ed','runtimeHead':'2412ecf2e4350cd21eadf10b3f022fdbd7e75e1d','base':'79cae493',
 'predictionsBeforeSha256':sha((OUT/'predictions.json').read_bytes()),'held':11,'failed':0,'needsEvidence':0,'findings':findings,
 'promoted':checks['promoted'],'frozenWords':333504,'frozenPixels':34688,'fourthSeed':19088743,'fourthWords':55224,'fourthPixels':5440,
 'metadataAttacks':2606,'bankAttacks':738,'ownedSnapshots':24,'duplicateColdClone':False,'implementationEdits':False,'commitsMade':False,'productionNegotiation':False,'guestExecution':False}
(OUT/'verdict.json').write_text(json.dumps(verdict,indent=2)+'\n')
print(json.dumps({'verdict':'verified','held':11,'failed':0,'needsEvidence':0,'verdictSha256':sha((OUT/'verdict.json').read_bytes()),'promoted':checks['promoted']},indent=2))
