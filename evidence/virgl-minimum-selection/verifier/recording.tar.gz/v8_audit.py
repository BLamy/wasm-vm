#!/usr/bin/env python3
import hashlib,json
from pathlib import Path

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
policy='renderer/virgl-command/constant-domain.mjs';source=(ROOT/policy).read_text()
sha=lambda b:hashlib.sha256(b).hexdigest()
consumer=json.loads((OUT/'consumer-attacks.json').read_bytes())
assert sha(source.encode())==consumer['policySourceSha256']
profiles=[]
for path in sorted((OUT/'node-consumer-coverage').glob('*.json')):
    coverage=json.loads(path.read_bytes())
    for script in coverage['result']:
        if script['url'].endswith('/'+policy):
            profiles.append({'path':str(path.relative_to(OUT)),'sha256':sha(path.read_bytes()),'script':script})
assert profiles
audit=json.loads((OUT/'coverage-audit.json').read_bytes())
lines=source.splitlines(keepends=True);starts=[];offset=0
for line in lines:starts.append(offset);offset+=len(line)
for row in audit['runtimeAddedLines']:
    if row['file']!=policy:continue
    text=lines[row['line']-1];position=starts[row['line']-1]+len(text)-len(text.lstrip())
    hits=[]
    for profile in profiles:
        matches=[]
        for function in profile['script']['functions']:
            for region in function['ranges']:
                if region['startOffset']<=position<region['endOffset']:
                    matches.append((region['endOffset']-region['startOffset'],region['count'],function['functionName'],region))
        if matches:
            narrow=min(matches,key=lambda x:x[0]);hits.append({'count':narrow[1],'function':narrow[2],'region':narrow[3],'profile':profile['path']})
    row['v8Hits']=hits
    text=row['source'].strip()
    if not text or text in ['}','};'] or text.startswith('//'):
        row.update(classification='waived',reason='Non-executable delimiter/comment; exercised surrounding minimum policy body binds the hunk.')
    elif any(h['count']>0 for h in hits):row.update(classification='executed',reason='Exact frozen runtime source and narrow V8 region count in independent hostile metadata/ownership recording.')
    else:row.update(classification='needs-evidence',reason='No positive narrow V8 range for changed runtime source.')
audit['v8Profiles']=[{k:v for k,v in p.items() if k!='script'} for p in profiles]
audit['needsEvidence']=[r for r in audit['runtimeAddedLines'] if r['classification']=='needs-evidence']
audit['dead']=[]
audit['hunks']=len({(r['file'],r['hunk']) for r in audit['runtimeAddedLines']})
assert not audit['needsEvidence'],audit['needsEvidence']
(OUT/'coverage-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({'status':'passed','runtimeHunks':audit['hunks'],'changedRuntimeLines':len(audit['runtimeAddedLines']),'needsEvidence':0,'dead':0,'policyProfiles':len(profiles)}))
