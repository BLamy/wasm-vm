#!/usr/bin/env python3
"""Independent bounded canonical-HEAD generator challenge; never mutates primary refs."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess

repo = Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
output = repo/'target/evidence/critic-production-scanout-continuity74d1/generator-ref-challenge01'
output.mkdir(exist_ok=False)
fixture = output/'fixture'
fixture.mkdir()
source = (repo/'tools/gen-tasks-json.py').read_bytes()
sha = lambda b: hashlib.sha256(b).hexdigest()
report = {'task':'E6-T11d74d1', 'role':'independent verifier', 'scope':'canonical-HEAD task generator extra-ref invariance',
          'primaryHead': subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
          'generatorSha256':sha(source), 'startedAt':datetime.now(timezone.utc).isoformat(), 'commands':[], 'checks':[]}
(output/'predictions.json').write_text(json.dumps({'recordedBeforeRun':True,'predictions':[
    'Adding side-branch, remote-only and stash refs outside unchanged HEAD cannot change task output bytes.',
    'Legacy --all history must make the same extra-ref challenge differ, proving the fixture can detect the old defect.',
    'Advancing actual HEAD to the task commit must change real status/activity; returning to baseline HEAD restores bytes.']},indent=2)+'\n')
env = {k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
env.update(GIT_AUTHOR_NAME='Verifier Fixture',GIT_AUTHOR_EMAIL='verifier@example.invalid',
           GIT_COMMITTER_NAME='Verifier Fixture',GIT_COMMITTER_EMAIL='verifier@example.invalid')

def git(*args, date=None):
    e=dict(env)
    if date:e.update(GIT_AUTHOR_DATE=date,GIT_COMMITTER_DATE=date)
    p=subprocess.run(['git','-c','core.hooksPath=/dev/null',*args],cwd=fixture,env=e,check=True,capture_output=True,text=True)
    report['commands'].append({'command':['git',*args],'stdout':p.stdout.strip(),'stderr':p.stderr.strip()})
    return p.stdout.strip()

def generate(label, legacy=False):
    name='gen-legacy-probe.py' if legacy else 'gen-tasks-json.py'
    subprocess.run(['python3',str(fixture/'tools'/name)],cwd=fixture,env=env,check=True,capture_output=True)
    b=(fixture/'web/tasks.json').read_bytes(); (output/(label+'.json')).write_bytes(b)
    return b,json.loads(b)

try:
    (fixture/'tools').mkdir();(fixture/'web').mkdir();(fixture/'tasks/epic-6-fixture').mkdir(parents=True)
    (fixture/'tools/gen-tasks-json.py').write_bytes(source)
    (fixture/'web/.gitkeep').write_text('')
    task=fixture/'tasks/epic-6-fixture/E6-T11d74d1.md'
    baseline='---\nid: E6-T11d74d1\nepic: 6\ntitle: Canonical fixture\npriority: 1\nstatus: pending\ndepends_on: []\nestimate: S\n---\n## Boundary\nFixture task.\n## Verification log\n### 2026-10-01\nBaseline event.\n'
    task.write_text(baseline);(fixture/'tasks/QUEUE.md').write_text('**0 / 1 tasks verified**\n')
    git('init','--initial-branch=baseline');git('add','tools/gen-tasks-json.py','tasks','web/.gitkeep')
    git('commit','-m','E6-T11d74d1 canonical baseline',date='2026-10-01T12:00:00+00:00')
    base=git('rev-parse','HEAD');b0,j0=generate('baseline')
    git('checkout','-b','unmerged-side')
    task.write_text(baseline.replace('status: pending','status: verified').replace('Canonical fixture','Unmerged side fixture')+'\n### 2026-10-02\nSide-only event.\n')
    git('add',str(task.relative_to(fixture)));git('commit','-m','E6-T11d74d1 unmerged side event',date='2026-10-02T12:00:00+00:00')
    side=git('rev-parse','HEAD');git('update-ref','refs/remotes/origin/remote-only',side);git('update-ref','refs/stash',side);git('checkout','--detach',base)
    b1,j1=generate('with-extra-refs');assert b1==b0,'non-HEAD refs changed canonical output'
    report['checks'].append({'prediction':'extra-ref invariance','status':'HELD','baselineSha256':sha(b0),'withExtraRefsSha256':sha(b1),'head':base,'outsideHeadCommit':side,'refs':git('show-ref').splitlines()})
    needle=b'"log", "HEAD"';assert source.count(needle)==1,'unique legacy-history negative anchor'
    (fixture/'tools/gen-legacy-probe.py').write_bytes(source.replace(needle,b'"log", "--all"'))
    legacy,jlegacy=generate('legacy-negative',legacy=True);assert legacy!=b0,'legacy --all negative did not detect extra refs'
    assert any('unmerged side event' in label for event in jlegacy['tasks'][0]['activity'] for label in event['labels'])
    report['checks'].append({'prediction':'legacy negative detects old defect','status':'HELD','legacySha256':sha(legacy),'canonicalCommitCount':j0['tasks'][0]['commitCount'],'legacyCommitCount':jlegacy['tasks'][0]['commitCount']})
    git('checkout','--detach',side);bh,jh=generate('advanced-head');assert bh!=b0 and jh['tasks'][0]['status']=='verified'
    assert any('unmerged side event' in label for event in jh['tasks'][0]['activity'] for label in event['labels'])
    git('checkout','--detach',base);back,jback=generate('returned-head');assert back==b0
    report['checks'].append({'prediction':'real HEAD changes are published and reversible','status':'HELD','advancedHeadSha256':sha(bh),'advancedStatus':jh['tasks'][0]['status'],'advancedCommitCount':jh['tasks'][0]['commitCount'],'returnedHeadSha256':sha(back)})
    report['status']='passed'
except BaseException as e:
    report['status']='failed';report['failure']=repr(e);raise
finally:
    (output/'generator-executed.py').write_bytes(source)
    (output/'driver-executed.py').write_bytes(Path(__file__).read_bytes())
    report['finishedAt']=datetime.now(timezone.utc).isoformat();(output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k]for k in ['status','primaryHead','generatorSha256','checks']},indent=2))
