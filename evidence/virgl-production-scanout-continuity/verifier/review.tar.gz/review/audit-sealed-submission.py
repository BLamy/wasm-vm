#!/usr/bin/env python3
"""Independent final receipt/diff identity audit. Read-only to implementation and Git."""
from pathlib import Path, PurePosixPath
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import subprocess
import tarfile

repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
out=repo/'target/evidence/critic-production-scanout-continuity74d1'
candidate='afd26047a3751a55d4bee376ecf668769d06bca5'
capsule=repo/'evidence/virgl-production-scanout-continuity/worker/submission.tar.gz'
sha=lambda b:hashlib.sha256(b).hexdigest()
result={'task':'E6-T11d74d1','role':'independent verifier','candidateHead':candidate,
        'startedAt':datetime.now(timezone.utc).isoformat(),'checks':[]}

def demand(v,message):
    if not v:raise AssertionError(message)

def git(*args,cwd=repo):
    env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
    return subprocess.check_output(['git',*args],cwd=cwd,env=env,text=True,stderr=subprocess.PIPE).strip()

try:
    submission=json.loads((capsule.parent/'submission.json').read_text())
    compressed=capsule.read_bytes();demand(len(compressed)==submission['bytes'] and sha(compressed)==submission['sha256'],'capsule outer identity')
    bodies={}
    with tarfile.open(capsule) as tar:
        members=tar.getmembers();demand(len(members)==submission['members']==418,'capsule member count')
        for m in members:
            path=PurePosixPath(m.name);demand(m.isfile() and not path.is_absolute() and '..' not in path.parts,'unsafe/non-file tar member '+m.name)
            demand(m.name not in bodies,'duplicate tar member '+m.name);bodies[m.name]=tar.extractfile(m).read()
    manifest=json.loads(bodies['manifest.json']);demand(manifest['head']==submission['head']==candidate and manifest['status']=='passed','manifest candidate')
    demand(set(bodies)=={'manifest.json'}|{f['path']for f in manifest['files']},'manifest coverage')
    for f in manifest['files']:
        b=bodies[f['path']];demand(len(b)==f['bytes'] and sha(b)==f['sha256'],'manifest digest '+f['path'])
    result['checks'].append({'prediction':'P10 capsule authenticates every final member','status':'HELD','bytes':len(compressed),'sha256':sha(compressed),'members':len(members),'rehashedFileEntries':len(manifest['files'])})
    prefix='recording/scanout-continuity-repaired01/'
    read=lambda name:json.loads(bodies[prefix+name])
    continuation=json.loads(bodies['recording/repaired-report.json']);receipt=read('report.json')
    demand(continuation['head']==receipt['head']==candidate and continuation['status']==receipt['status']=='passed','final candidate receipts')
    demand(len(receipt['commands'])==15 and all(c['exitCode']==c['expectedExitCode']for c in receipt['commands']),'fifteen command exits')
    demand(all(c['exitCode']==0 for c in continuation['commands']),'continuation exits')
    for f in receipt['files']:
        b=bodies[prefix+f['path']];demand(len(b)==f['bytes'] and sha(b)==f['sha256'],'acceptance file '+f['path'])
    result['checks'].append({'prediction':'P10 complete selected acceptance','status':'HELD','commands':receipt['commands'],'continuation':continuation})
    clone=repo/'target/evidence/production-scanout-continuity-pristine02/clone'
    demand(git('rev-parse','HEAD',cwd=clone)==candidate,'clone exact head')
    demand(git('status','--porcelain',cwd=clone)=='','clone clean after full build and acceptance')
    demand(git('rev-parse','--is-shallow-repository',cwd=clone)=='false','shallow clone')
    demand(not(clone/'.git/objects/info/alternates').exists() and not(clone/'.git/shallow').exists(),'clone alternates/shallow file')
    demand(not list((clone/'.git/objects/pack').glob('*.promisor')),'partial-clone promisor pack')
    demand(git('fsck','--connectivity-only','--no-dangling',cwd=clone)=='','clone object connectivity')
    clone_command=json.loads(bodies['recording/report.json'])['commands'][0]['command']
    demand(clone_command[:4]==['git','clone','--no-local',str(repo)],'ordinary complete no-local clone command')
    result['checks'].append({'prediction':'P10 complete clean clone, no object borrowing','status':'HELD','clone':str(clone),'head':candidate,'cloneCommand':clone_command,'shallow':False,'alternates':False,'promisor':False,'connectivity':'clean'})
    actual=read('actual-worker/report.json');negative=read('original-clear-negative/report.json')
    demand(actual['head']==negative['head']==candidate and actual['status']=='passed' and negative['status']=='failed','worker/negative candidate')
    demand(actual['errors']==negative['errors']==[] and not actual['sabotage'] and negative['sabotage'],'worker/negative errors or sabotage label')
    expected={'green':(0,255,0,255),'queued-old-red':(0,255,0,255),'rebound-before-replacement':(0,255,0,255),'stale-callback-before-blue':(0,255,0,255),'fresh-blue':(0,0,255,255),'disabled':(0,0,0,0),'enabled-without-frame':(0,0,0,0),'fresh-red':(255,0,0,255),'rebound-before-context-loss':(255,0,0,255),'actual-worker-context-lost':(0,0,0,0)}
    phases={};observations=[]
    for p in actual['phases']:
        name='actual-worker/'+p['label']+'.json';b=bodies[prefix+name];demand(sha(b)==p['sha256'],'native phase digest '+p['label'])
        j=json.loads(b);phases[p['label']]=j;pixels=j['pixels'];counts=Counter(tuple(pixels[i:i+4])for i in range(0,len(pixels),4))
        demand(counts=={expected[p['label']]:4096},'native literal pixels '+p['label'])
        observations.append({'phase':p['label'],'sha256':p['sha256'],'rgba':expected[p['label']],'pixels':4096,'latest':j['ui']['latest'],'replayedFrames':j['ui']['replayedFrames']})
    demand(set(phases)==set(expected),'native ten phases')
    cancelled=phases['rebound-before-replacement']['gpu']['scanout']['retirements'][-1]
    fresh=phases['fresh-blue']['gpu']['scanout']['retirements'][-1]
    demand(cancelled['sequence']=='0000000000000006' and cancelled['bindingGeneration']=='0000000000000001' and cancelled['status']=='cancelled','exact old native receipt')
    demand(fresh['sequence']=='0000000000000008' and fresh['bindingGeneration']=='0000000000000003' and fresh['status']=='drawn','exact fresh native receipt')
    demand(phases['stale-callback-before-blue']['delayed']==1 and phases['stale-callback-before-blue']['ui']['latest'] is None,'stale callback consumed blue')
    lost=phases['actual-worker-context-lost'];demand(lost['ui']['latest'] is None and lost['ui']['replayedFrames']==0 and lost['gpu']['qualified'] is False,'loss recovery authority')
    demand(re.fullmatch('[0-9a-f]{64}',actual['finalDigest']) is not None,'native digest')
    hardware=actual['hardware'];demand((hardware['gpu']['featureStatus'].get('webgl2')or hardware['gpu']['featureStatus'].get('webgl'))=='enabled','hardware WebGL')
    demand(any('Metal' in d.get('deviceString','') and 'Apple' in d.get('deviceString','')for d in hardware['gpu']['devices']),'actual Apple Metal device')
    demand('--headless'in hardware['commandLine'] and not any(re.search(r'swiftshader|llvmpipe|softpipe|lavapipe|--disable-gpu(?:$|=)',a,re.I)for a in hardware['commandLine']),'physical headless command line')
    result['checks'].append({'prediction':'P1/P2/P4/P5/P6 native original-MMIO physical pixels and receipts','status':'HELD','observations':observations,'cancelled':cancelled,'fresh':fresh,'nativeStateDigest':actual['finalDigest'],'browser':hardware['version']})
    healthy={s['path']:s for s in actual['sources']};bad={s['path']:s for s in negative['sources']};demand(set(healthy)==set(bad),'negative source set')
    changed=[p for p in healthy if healthy[p]['sha256']!=bad[p]['sha256']];demand(changed==['web/renderer/virgl-command/production.mjs'],'negative one source delta')
    p=changed[0];goodbody=bodies[prefix+'actual-worker/source/'+p];badbody=bodies[prefix+'original-clear-negative/source/'+p]
    needle=b"send({type:preserveDisplay?'invalidate':'clear'})";demand(goodbody.count(needle)==1 and badbody==goodbody.replace(needle,b"send({type:'clear'})"),'negative exact unconditional clear delta')
    demand(negative['failure']['message'].startswith('no-blank: valid page flip retains displayed original green;'),'negative precise failed assertion')
    result['checks'].append({'prediction':'old clear falsifies the new between-bind assertion','status':'HELD','healthySha256':sha(goodbody),'negativeSha256':sha(badbody),'failure':negative['failure']['message'][:500]})
    sourcechecks=[]
    for p,s in healthy.items():
        b=bodies[prefix+'actual-worker/source/'+p];demand(sha(b)==s['sha256'],'worker source digest '+p)
        try:commitbody=subprocess.check_output(['git','show',candidate+':'+p],cwd=repo,stderr=subprocess.PIPE)
        except subprocess.CalledProcessError:commitbody=subprocess.check_output(['git','show',candidate+':web/dist/'+p[4:]],cwd=repo,stderr=subprocess.PIPE)
        demand(b==commitbody,'frozen source differs from candidate '+p);sourcechecks.append({'path':p,'sha256':sha(b)})
    own=read('independent-state-attacks/report.json');demand(own['head']==candidate and own['status']=='held-within-scope' and own['errors']==[] and len(own['results'])==8 and all(x['status']=='HELD'for x in own['results']),'independent eight groups')
    physical=read('independent-physical-pixels/report.json');demand(physical['head']==candidate and physical['status']=='passed' and physical['errors']==[] and physical['actual']['assertions']==47 and len(physical['actual']['rows'])==3 and all(x['status']=='passed'for x in physical['actual']['rows']),'independent physical47')
    result['checks'].append({'prediction':'P1-P9 source identity and changed-hunk coverage','status':'HELD','workerSourcesComparedToCandidate':len(sourcechecks),'sourceChecks':sourcechecks,'independentGroups':[{'name':x['name'],'status':x['status']}for x in own['results']],'physicalAssertions':47,'physicalRows':[x['name']for x in physical['actual']['rows']]})
    software=read('software-fast-boots/report.json');demand(software['head']==candidate and software['status']=='passed' and software['errors']==[],'software final receipt')
    demand([p['phase']for p in software['phases']]==['busybox-initial','busybox-repeat','alpine-initial','alpine-repeat','alpine-persistence','node-alpine-initial','node-alpine-repeat','node-alpine-persistence','omarchy-initial','omarchy-repeat'],'software ten phases')
    summaries=[]
    for p in software['phases']:
        if 'result'in p:
            demand(p['result']['exit']==0,'software command exit '+p['phase']);demand(re.search('FAST_.*_42_PASS',p['result']['stdout']) is not None,'software original command marker '+p['phase'])
            demand(p['commandTimeoutMs']==(300000 if p['guest']in ['node-alpine','omarchy'] else 120000),'finite software command deadline')
        else:
            demand(p['write']['exit']==p['read']['exit']==0,'software persistence exits '+p['phase'])
            marker='DURABLE_'+p['phase'].removesuffix('-persistence')+'_42_PASS'
            demand(marker in p['read']['stdout'],'software original persistence marker '+p['phase'])
        summaries.append({k:p.get(k)for k in ['phase','restoredMs','commandTimeoutMs','liveCommandMs','result','write','read']})
    default=read('default-browser/report.json');demand(default['gitHead']==candidate and default['status']=='passed' and default['passed']==127 and default['failed']==0 and default['proofExportAbsent'] and default['errors']==[],'ordinary default127')
    wasm=subprocess.check_output(['git','show',candidate+':web/dist/pkg/wasm_vm_wasm_bg.wasm'],cwd=repo)
    demand(default['servedWasmSha256']==sha(wasm),'ordinary served Wasm exact candidate')
    result['checks'].append({'prediction':'P10 actual software/default regressions keep original predicates','status':'HELD','software':summaries,'ordinaryPassed':127,'ordinaryFailed':0,'proofExportAbsent':True,'ordinaryWasmSha256':sha(wasm)})
    result['status']='passed'
except BaseException as error:
    result['status']='failed';result['failure']=repr(error);raise
finally:
    result['finishedAt']=datetime.now(timezone.utc).isoformat();(out/'sealed-submission-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'checks':[{'prediction':c['prediction'],'status':c['status']}for c in result['checks']],'failure':result.get('failure')},indent=2))
