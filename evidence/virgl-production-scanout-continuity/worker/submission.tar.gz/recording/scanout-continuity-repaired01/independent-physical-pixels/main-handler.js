let pendingGpuFrame = null, gpuFrameRequest = null;
function handleDisplayFrame(frame) {
  if ((frame?.type === 'clear' || frame?.type === 'invalidate') && pendingGpuFrame) {
    pendingGpuFrame.onRetired('cancelled'); pendingGpuFrame = null;
    if (gpuFrameRequest !== null) cancelAnimationFrame(gpuFrameRequest);
    gpuFrameRequest = null;
  }
  if (typeof frame?.onRetired === 'function') {
    if (!presentation) { frame.onRetired('failed'); return false; }
    if (pendingGpuFrame) pendingGpuFrame.onRetired('superseded');
    pendingGpuFrame = frame;
    if (gpuFrameRequest === null) {
      const request = requestAnimationFrame(() => {
        if (gpuFrameRequest !== request) return;
        gpuFrameRequest = null;
        const owned = pendingGpuFrame; pendingGpuFrame = null;
        if (!owned) return;
        try {
          const before = presentation.snapshot().drawnPresents;
          const accepted = presentation.presentNow(owned);
          displayViewport?.applyCanvasStyle();
          const after = presentation.snapshot();
          owned.onRetired(accepted && after.drawnPresents > before ? 'drawn' : 'failed',
            {backend:after.backend,resourceWidth:owned.resourceWidth,resourceHeight:owned.resourceHeight});
        } catch { owned.onRetired('failed'); }
      });
      gpuFrameRequest = request;
    }
    return true;
  }
  if (!presentation) return false;
  try {
    const reached = presentation.present(frame);
    displayViewport?.applyCanvasStyle();
    if (displayStatusEl) {
      const state = presentation.snapshot();
      displayStatusEl.textContent = `${state.backend || "none"} · ${state.width}×${state.height} · ${state.successfulPresents} presents`;
      if (state.sizeMismatch) displayStatusEl.textContent += " · waiting for guest mode set";
      displayStatusEl.dataset.state = reached ? "ready" : "degraded";
    }
    return reached;
  } catch (error) {
    if (displayStatusEl) {
      displayStatusEl.textContent = `display error: ${String(error?.message || error)}`;
      displayStatusEl.dataset.state = "error";
    }
    return false;
  }
}
