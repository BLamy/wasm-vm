---
id: E6-T11d72
epic: 6
title: Bound accelerated desktop idle time during keyboard interaction
priority: 525.027037
status: verified
depends_on: [E5-T26i, E6-T11d70, E6-T11d73]
estimate: S
risk: high
capstone: false
---

## Boundary

Define an explicit GPU-Omarchy `paced-on-keyboard` policy: boot in ICount64,
then select the verified native `paced-icount` clock before the first original
eligible EV_KEY make is staged. Keep normal retirement time and bound idle jumps
by elapsed monotonic host time. The numeric original interface does not attest
DOM trust; a lock reconciliation make can be first. Input may arrive during
boot. Eligibility follows the original keyboard's EV_KEY make and PC105 range.
Other guests and omitted policy retain their existing clocks and fast boots;
explicit `wall-on-keyboard` remains supported.

Validate exact options and monotonic source before fetch, and actual machine
APIs before execution. Read back the selected mode and unchanged decimal mtime,
divider and timebase before publishing the make. Commit the one-way selection
only after success; poison the lifecycle on failed selection. Preserve original
send/sync ordering and rebase explicit pauses in both host-paced modes. Reuse
D73's verified native implementation without changing repeat settings, typing
delay, snapshot formats or renderer capabilities. The historical wall-policy
stock failure below remains a failure; this new policy needs its own stock proof.

## Deterministic acceptance

`make verify-E6-T11d72` records exact policy/realm/API validation, actual loader
callback ordering, failure poisoning and pause/resume. Record the actual worker
policy and clock before/after original keyboard input: ICount before a make,
paced-icount afterward, unchanged mtime/divider/timebase, monotonic progress and
excluded pause time. Bound a resumed observation by measured host time plus
actual retired-instruction contribution, retaining exact clock-divider phase
slack. Carry D73 native/Wasm gates by unchanged source and evidence identity.

Unchanged 50 ms trusted stock Foot typing must create its absent-before marker,
with correct original transitions, visible package bar and displaced guest cursor.
Prove all software fast boots, real VirGL-only Mesa/cube/Hyprland/scanout, normal
default build and final pristine clone. Carry unchanged native71 and earlier
component holds by source/evidence identity. The same final full parent run may
serve71 and the parent after fresh verdicts; no duplicate full cold boot.

## Adversarial verification

Independently attack invalid options/realm/API shape, release-only/repeat/invalid
numeric frames, lock repair, repeated makes, stopped and paused controllers,
selection failure, mtime drift, stale reported mode and pause/quota resumes.
Remove only the handoff in an isolated copy; its clock/ordering test must fail.
Inspect actual original worker fields and clock state rather than trusting a
query string. Retain the old stock repeat and unexplained navigation recordings;
no automatic retry may turn those failures into success. Judge performance only
against an explicit measured budget; this task makes no300-MIPS claim.

## Verification log

### 2026-10-14 — worker — prerequisite from preserved stock negative

Native71's WFI guard holds, but its frozen stock GPU run still prints `tttouch`
for the unchanged50ms trusted command. A software-warm diagnostic with the same
helper succeeds. Their immutable original records are in71's worker negative
archive SHA-256 `a77ed05d56d25a88502a342a625abf2bb6a1b850d5307b9e4fc13c730ab4fec5`.
The private root compositor timestamp diagnostic succeeds and reports one first-T
make/break separated by1,559us in guest time, with no kernel repeat values. Its
observer changes scheduling, so it does not discharge stock acceptance. This task
owns an explicit production clock-policy decision, separate from71's native
deterministic WFI boundary. Both final actual stock and pristine evidence remain
required before a verdict.

### 2026-10-14 — verifier — stock interaction refutation

VERDICT: refuted

- **F3 / A2 stock typing — FAILED.** Predicted the unchanged 50 ms trusted command
  would create its absent-before `/tmp/gpukeyboard42touch` marker in the normal
  UID 1000 Foot session. In original pristine-clone
  `production-interactive-clock-cold-public-final02`, the actual policy was
  `wall-on-keyboard`, initial clock ICount (divider 64) (`mtime=862006079`), and final clock
  wall (`mtime=2173132800`). All 60 trusted DOM transitions match the literal text;
  the first T hold was 52.13 ms. All 62 original frames match those 60 transitions plus
  one balanced NumLock 69 repair; held/pending/dropped/rejected counts are zero.
  Nevertheless all 20 actual original serial marker commands exited 1 with empty
  stdout. The unmodified Foot PNG shows long repeated `t` runs followed by the
  intended command suffix and `command not found`. This refutes the product's stock-input
  acceptance. Determine the actual input or
  consumer timing cause and re-record unchanged stock typing.
- **Concrete points.** The independent seal's
  `browser/public-desktop-input.json:2994` records the requested text;
  `browser/original-serial.log:5469` (tag `mv8s0i1j182`) and
  `browser/original-serial.log:5582` (tag `mv8s2o6x201`) bracket the first and last
  failed marker checks. Full unfiltered serial SHA-256 is
  `51ba7ae2dbfdb4fd55664bc57a874fe6374fdc052aa69f4a5753b034a51554b9`.
  Exact failed PNG SHA-256 is
  `fe3cc565814329927c9cedbd65af7e8d094ec54a016e11417c00c88fe7dcf260`.
  The failed outer wrapper and original browser reports remain failed; its
  default command was never reached.
- **HELD components and source.** Carry the unchanged native D71, policy/realm/API
  validation, original callback ordering, malformed readback/failure poisoning,
  lock repair/idempotence, quota/resume, real paused-worker selection and measured
  pause results, and both isolated handoff/rebase negative controls. The frozen
  runtime is `97021186ba6b1274edc4d9f50b2005a1a034d77d`; corrected recording tools
  are `4619a4d11007f3d6bc221e67048b074c8f4eafeb` (five tools files only).
  Actual Wasm remains
  `a653fe3a4828fb46e4ced12668174c71e8d817a5bf5611117f17da3008a6aa82`.
  Root and original pristine prefixes authenticate all six selected D72 and 10 prior
  parent commands. Their public aborts remain explicit failed/interrupted
  reports. All 10 software warm phases, private actual Mesa/cube/Hyprland/Foot,
  original handshake, and the separately recorded default suite (127 passed, 0 failed) remain held.
- **HELD graphics / unproved cause.** Crop 022 is visibly readable (Wednesday 23:38,
  workspace glyphs/icons), with 790 foreground pixels across 12 rows and four columns;
  exact PNG SHA-256 is
  `3c07c15c87aef85158f7e7fb6bf826c38eb63f6769fb2918785a9173af928884`.
  Failure-state GPU is qualified/live/unpoisoned, 687 begun = 687 completed,
  failed/cancelled 0, 321 draws and no pending request. Full serial has no observed
  DRM response-error strings; workerErrors and recorded main-page timerGaps are
  empty. All 124 original keyboard/sync callbacks have matching response IDs
  within 23.23 ms, but this does not prove Linux/Wayland consumption timing.
  Native `wfi_fast_forward` already returns in wall mode (`crates/core/src/lib.rs:4203`).
  No exclusive renderer, native-clock, host, or guest-client cause is claimed.
- **COVERAGE — NEEDS EVIDENCE.** The marker assertion stops the stock final cursor
  check, five-second pause probe, successful post-input final-state oracle and final02
  default command. Do not substitute earlier/private or pre-failure state for
  these unexecuted paths. The two prior final01 pre-make heartbeat failures also
  remain genuine negatives; preserved powerd sleep/wake correlation does not
  establish exclusive causation or claim sleep/wake recovery fixed.
- **SUITE / custody.** Keep the promoted
  `web/tests/e6-t11d72-interactive-clock-critic.test.mjs` and strengthened final
  oracle/protocol tests. Independent archives below were reopened member-by-member:
  `verifier/components-01/clock-policy-unit-and-pause-controls.tar.gz`
  (306,487 B, 80 identities / 81 members,
  SHA `0fa7e848bf8ed256ffcf40d707abb1ab62957b257e4446e0116728a80cb90cec`),
  `verifier/before-make-negatives-01/stock-before-make-heartbeat-negatives.tar.gz`
  (487,651 B, 17 identities / 18 members,
  SHA `10745bfc21fee98e5e79b558e98bb1bd160c50880ce8580dd3f86b05fdb21e47`),
  and `verifier/stock-refutation-02/independent-wall-policy-stock-repeat-refutation.tar.gz`
  (464,612 B, 99 identities / 100 members,
  SHA `cc05a41cc85fc77f6a195b9c6086b7d7095fa04e7e82b8960ec6bf044cd24e26`).
  All paths are under `evidence/virgl-production-interactive-clock/`.
  The independent final02 audit also reopened the worker negative archive
  SHA `49e3d57af16f950460a5b266afee70e1a5a7d33c84327bfc14db8208ef7173c2`
  and matched all 83 members to the originals. No runtime code was edited by this
  verifier. Status stays `in-progress`; parent/recovery/deployment/300 MIPS are not
  verified by this entry.

Commands: authenticated existing closed producer reports / 82 file identities,
`git show` source/served dependency checks, independently parsed 20 original serial
marker blocks and 124 keyboard method ID/timing pairs, direct unmodified PNG
inspection, and deterministic archive reopen/hash checks. No browser or broad
suite was rerun by the verifier during the live recordings. The worker's exact
selected command prefix and final02 commands remain in their original reports.

### 2026-10-14 — worker — preserve stock wall-clock input refutation

The original pristine continuation at recorder head `4619a4d1` failed all20
marker reads after62 original frames (60 trusted DOM transitions plus NumLock
repair). The terminal visibly contains a long run of `t` followed by the intended
command suffix and `command not found`. Actual mode is wall; no keys remain held,
no events/frames were dropped or rejected, all124 original send/sync RPCs have
matching results (maximum23.230ms). RPC completion does not attest Linux or
Wayland consumption. Post-failure original state remains qualified, live and
unpoisoned,687 begun/completed,321 draws, zero failed/cancelled/pending jobs,
zero original DRM refusals, zero worker errors and no page timer gaps. The actual
bar content is crop022; its preceding blank crops are retained.

Worker negative archive
`evidence/virgl-production-interactive-clock/worker/stock-wall-clock-repeat-negative-02.tar.gz`
is417,826bytes, SHA-256
`49e3d57af16f950460a5b266afee70e1a5a7d33c84327bfc14db8208ef7173c2`,
83 members reopened and rehashed. Fresh refutation is recorded below/above in
the verifier log and commit `847eb56f`; unaffected component holds carry forward.
The skipped final02 default stage is not called passed; the separate original
root default127/0 record remains valid by unchanged source identity.

Self-validation now adds a passive, memory-buffered evdev timestamp observer to
a disposable image12 copy, retaining the stock uid1000/config/Foot/compositor.
Its service opens the keyboard then drops uid/gid1000, without grabbing input,
changing repeat settings, or changing production assets. Source, compiler,
image/chunk and original-driver diff pins are recorded in
`target/evidence/production-stock-repeat-investigation01`. It changes scheduling
and cannot discharge untouched-stock acceptance. No cause or runtime repair is
claimed until the original kernel/Wayland delivery is measured.

### 2026-10-15 — worker — concurrent input delay isolated; stock still refuted

Both disposable observed-image runs reproduced the unchanged trusted50ms Foot
command failure. The first passive evdev recording contains128 complete records,
62 balanced original key frames, no kernel repeats or dropped SYN, and a44.925ms
first-T hold. The second adds a buffer around the unchanged Foot listener/timer
APIs. Its128 evdev records again match all62 original frames; first-T is45.845ms.
Actual Foot PID695/UID1000 receives all62 matching source-time/key/state values,
but its first-T callbacks are28.5886399s apart. The down callback itself takes
47.21ms wall/2.1099ms thread CPU; the interval between callbacks contains
1.1762437s of that same thread's CPU. The original40Hz/250ms timerfd6 yields1126
expirations before release disarm, all consistent with elapsed guest time.
This establishes delayed userspace release consumption, without locating the
Hyprland-emission versus client-socket boundary or claiming exclusive cause.

The second probe's constructor SIGUSR2 handler was overwritten by Foot's normal
signal initialization. Its automatic post-helper signal requests the light
palette and produces an empty diagnostic file; that harness failure is preserved.
A separate read-only `/proc/695/mem` helper recovers1687 published rows, with two
identical raw prefixes, three equal used counters, overflow0 and exact library/
original-ELF identities. It does not stop/write/signal the process or fabricate
a successful C END. Executable relocation changes diagnostic02's process comm;
this scheduling difference further excludes it from untouched-stock acceptance.

The fresh critic independently authenticates, parses and seals both recordings:
`evidence/virgl-production-interactive-clock/verifier/diagnostics-01/first-helper-kernel-input-audit.tar.gz`
is536428bytes/94 reopened members, SHA-256
`8bf19ea577b2175b219bdf65264d211ceeecfce0369fb0e1472011d991aa60e7`;
`concurrent-input-callback-and-timer-diagnostic.tar.gz` in that directory is
1005960bytes/129 reopened members, SHA-256
`509ae5bd33b3fd98c4974c78cda147931935c35c753e1a77cb4560beaa38a4f6`.
The archive's raw callback rows61/64/1442 and first kernel-T pair are the concrete
points; the missing signal dump remains failed. The critic held459 conservative
timer bounds and matched62 original kernel/client pairs. A diagnostic Linux
host-ABI check proves forwarding/data/results/errors and child preload exclusion;
it is not emulated-guest acceptance.

No product runtime repair, new stock success, recovery verdict or deployment is
claimed. Wasm remains`a653fe3a4828fb46e4ced12668174c71e8d817a5bf5611117f17da3008a6aa82`,
clock-policy module`62a268c0766733860f422d80870790ca48a899fc37600420f66ef5fc802fd4a7`.
The first helper's stock refutation and prior component holds remain in force.
The next bounded diagnostic adds official Wayland server logging, libinput and
client read/dispatch timings, keeping original binary basenames and no signals.
Wrangler whoami now confirms the intended Cloudflare account; no deploy occurred.

### 2026-10-15 — worker — blocked on native paced-idle prerequisite

Exact repro at944ac6f8: the unchanged stock helper in concurrent diagnostic03
fails all20 marker reads after62 balanced original frames, as in the preserved
untouched-stock refutation. Independent raw pipeline timing now locates a long
compositor-serialization to observed-flush/client-read interval while native
repeat timers remain valid. Selecting wall time alone has not met acceptance.
OrderedS/high E6-T11d73 introduces an opt-in retire-derived clock with host-paced
idle jumps. D72 remains blocked until that primitive is independently verified,
then owns its explicit loader policy and unchanged final stock proof. This is
a proposed pacing repair, not a declaration that the observed failure is fixed.

### 2026-10-15 — worker — preserve independently audited pipeline negative

The fresh critic independently parsed diagnostic03's actual PID696 Foot and
PID592 Hyprland prefixes, matched all62 original events across four layers and
held all442 native timer bounds (zero exclusions/violations). First T20 kernel
hold is47.750ms, compositor serialization gap1.013250s, Foot callback gap
30.423785s. Exact compositor release row816 is followed by58 backend events and
58 corresponding key emissions before observed flush933,29.457760s later;
Foot read1543/dispatch1545/release1546 follow. All native call pairs are complete.
Repeat fd5 has334 reads/1195 expirations before release consumption; these are
consistent with actual elapsed time. Public flush attempts do not certify
per-client socket delivery and missing hooks cannot exclude internal writes.

Both stable raw prefixes have overflow0. The original image-build stdout pins
an earlier source hash8ec40ca9 while the frozen outer receipt pins9178f7a1;
this discrepancy is preserved. A fresh compile of the final frozen9178f7a1
source using the authenticated original source basename produces byte-identical
installed libraryd03b8ce3. The first differing-basename rebuild and its mismatch
are retained too; no comment-only source history is invented.

Independent archive
`evidence/virgl-production-interactive-clock/verifier/diagnostics-03/concurrent-pipeline-input-boundary-diagnostic.tar.gz`
is7,217,914bytes, SHA-256
`ba738841b0f54bb8b7b338ee4ce289d0cddd6c9b899b545ca8a48a32e61a62e3`;
all183 members/182 identities were reopened. It includes the full failed first
helper,20 original failed marker blocks, source/build receipts, raw buffers,
pre-data independent predictions/decoder, exact crops, final failed PNG and
separately marked post-helper metadata. The diagnostic closed exit1 after owned
release. No product verdict, runtime repair or deployment is claimed.

### 2026-10-15 — worker — resume after independently verified native prerequisite

D73 is verified at `7e2739f28b9c539be894ecd8f693cf743c35258e`. Its independent
archive SHA-256 is `496e53dbccffd922e1fd63287cf1b2038f62f3abd6c82ef360eadac35935a14f`.
The production policy layer continues the existing native stack above D73.
The new boundary uses paced-icount for idle ceilings while preserving busy guest
retirement timing; historical wall-policy stock negatives remain unmodified.
No stock success, parent completion or deployment is claimed by activation.

### 2026-10-15 — worker — preserve private compositor deadline negatives

Pristine runtime `e17f8caf` passed all six selected clock gates, all preceding
parent native/Wasm/protocol/qualification gates, all ten software warm phases,
real Mesa GLES initialization/index checks,768 exact pixels and1000 cube frames.
Its private compositor-ready marker did not arrive within the recording helper's
300000ms host wait. The outer report remains failed in
`target/evidence/production-paced-policy-cold-final01`.

A paired actual paused-worker control confirms that this older private harness
returned HTML before setting production COOP/COEP headers: original isolation
false/hasExecutor false versus corrected true/true, both0 retired. Commits
`d209f994`/`fba69588` fix recording headers and retain actual JIT/failure state;
all product sources, dependencies and ordinary Wasm remain unchanged. The
corrected private03 still times out at300000ms: actual ICount64,mtime260892015,
8332552364 retired,3450480653 via JIT,246920108 executed blocks,14042 GPU draws,
2613 begun/2612 completed/one pending and zero failed/cancelled. There is no final
healthy-state or exclusive timeout-cause claim. Diagnostic02 was intentionally
interrupted after a target-only catch-scope bug was found; it is not product proof.

The task and parent require functional compositor/scanout proof without a host
startup latency budget. A missing-path recording now allows900000ms for the
private compositor-ready marker, matching the existing cube observation budget.
Its internal180-second guest timeout, executable/configuration/image and every
semantic assertion stay identical. This is a longer bounded evidence window,
not a reinterpretation of either prior failure or a performance claim. Stock
50ms typing,20 marker attempts, keyboard repeat and production heartbeat budgets
remain unchanged. No successful stock input or deployment is claimed here.

### 2026-10-15 — worker — successful stock and missing private component; ABI fix

The unchanged image12 stock helper at frozen production `e17f8caf` passed its
50ms trusted command: absent-before marker created, actual UID1000 Foot focused,
bar crop021 contains722 contrasting foreground pixels, and the guest cursor
moved640,400→430,412. Actual mode switched ICount64→paced-icount. Five-second
pause holdsmtime1177933052 and retired48240469040 exactly; resumed observed
62497ticks are bounded by2986154ticks including actual retirement contribution.
The original post-input state is657begun=657completed,308draws,no pending job,
zero failed/cancelled,workerErrors[] and pageErrors[]. Original report
`production-paced-policy-cold-stock02/browser/report.json` is passed. Its outer
wrapper remains failed because the default helper rejected task72 before loading
any browser: it lacked task72 in its allowlist. That recording-harness option
support is corrected separately; no stock helper retry or claim of default success.

Private window04 completes the identical real Mesa768pixel/index83 checks,
1000cube frames, Hyprland GLES3.0 renderer/IPC/client mapping and scanout within
the documented longer bounded observation window. Actual JIT has291649836
executedblocks/3937142435retiredViaJit. It is a passed missing component, not a
reinterpretation of the earlier300000ms negatives; reports/sourcepins are under
`target/evidence/production-paced-policy-private-window04`.

Fresh actual-Wasm interrogation found that fractional numeric codes could be
coerced by the u16/u16/i32 native ABI into a valid make without clock selection.
The loader now refuses noninteger or out-of-domain fields before eligibility or
native staging, preserving exact signed32 MSC_SCAN values and original valid
integer forwarding. The worker's first uncommitted unsigned-value prototype
was corrected after the critic checked the actual i32 ABI; both self-validation
records are retained. The corrected selected77tests pass; actual ABI/worker and
final pristine scope are still required. All native/core/renderer/dependency and
ordinary Wasm bytes remain unchanged. No deployment is claimed by this entry.

The independent regression is promoted byte-for-byte into
`web/tests/e6-t11d72-keyboard-abi-critic.test.mjs` (five actual shipping-Wasm tests,
26 malformed frames across paced/wall/omitted policies and real signed MSC/KEY
positive controls). Removing only the guard fails that actual-Wasm test. The
separate seven-test policy/oracle fixture is also promoted unchanged. Actual
hardware-worker self-validation rejects14 malformed RPC frames without staging,
preserves signed MSC_SCAN min/-1/max, then selects actual paced-icount before a
valid make; all17rows and two pause intervals pass with zero errors.

Incremental final proof uses `verify-interactive-clock.py --input-boundary-only`
from both the frozen tree and a newly built pristine exact-head clone. It covers
all selected/promotion tests, the actual worker ABI/handoff/pause and the default
127-test demo. The successful original stock run's62integer frames must all
satisfy the new pure guard; its unchanged valid forwarding/selection body is
covered by the new actual-worker control. Fresh critic accepts that explicit
valid-path custody instead of another30-minute stock boot. Native73, the earlier
new-runtime native gates, software warm matrix and final private/handshake
components carry by their unchanged code/evidence boundaries. No failed wrapper
is relabelled passed, and no unexecuted browser path is claimed.

### 2026-10-15 — worker — final paced policy submission

Claim at frozen code `61eeb1b59902c9c52f0c4fdf3880a0081ebb2db2`: qualified
GPU Omarchy boots in ICount64 and selects the verified native paced-icount idle
policy before the first canonical original keyboard make, preserving exact time,
divider and timebase. Selection/readback failures poison before staging, repeated
makes do not reanchor, and explicit pause/resume excludes paused host time.
Malformed u16/u16/i32 ABI fields are rejected before both selection and native
staging; valid signed scan events and integer KEY forwarding remain intact.

Recorded commands and exact reports:

- `python3 tools/virgl-production/verify-interactive-clock.py --input-boundary-only --output target/evidence/production-paced-policy-guard-frozen01`:
  four commands0;89 clock/protocol/actual-Wasm tests; actual production worker's
  14 malformed and3 signed-MSC rows, original make handoff and two pause intervals;
  ordinary demo127passed/0failed,zeroerrors,no proof exports.
- `python3 target/evidence/production-paced-policy-guard-cold-launch01/run.py`:
  `git clone --no-local --single-branch`, no alternates, clean exact61eeb1b5,
  own `make web-dist`, then identical incremental acceptance. All3 outer and4
  inner commands0; same89tests/17workerrows/default127/0. The original selected
  six clock and eight preceding parent commands at e17 remain passed components
  of the explicitly failed original-cold report; unchanged native73 remains
  independently verified. No failed outer wrapper is called passed.
- Original `critic-fast-boots.mjs` stock GPU run from the pristine e17 clone:
  `production-paced-policy-cold-stock02/browser/report.json` passed with60trusted
  transitions/62original frames, absent-before marker then TRUSTED_TOUCH_42,
  readable actual package bar,cursor displacement,5-second pause,657/657GPUjobs,
  308draws,no pending/failed/cancelled job and zero worker/page errors. Its outer
  wrapper failed a pre-browser default-task option; the corrected default passes
  on both final root and final cold. The pure guard carry command is
  `node target/evidence/production-paced-policy-valid-frame-carry01/check.mjs`:
  all62 original frames accepted and only the new five-line guard differs in the
  loader. Actual new-worker and real-Wasm controls cover that changed boundary.
- Original four-image software matrix has all10initial/repeat/persistence phases
  passed in `production-paced-policy-cold-final01/interactive-clock/production/fast-boot-images`.
  Omarchy84.265s first restore includes198MB download; repeat6.027s. This is
  functional/warm-path proof, not a GPU warm snapshot or latency-budget claim.
- Private missing-path `production-paced-policy-private-window04` is closed0:
  original real Mesa/index83/textured768pixels,1000cube frames, Hyprland GLES3.0,
  actual mapped Foot and scanout. Final-state GPU snapshot contains31192draws;
  later full raw trace totals31516 DRAW packets in the original13-family
  `compare-handshake.py` report. These are different recorded points, not a
  drained-owner assertion. Actual JIT291649836blocks/3937142435retiredViaJit.
  Both earlier300000ms readiness failures, their actual pending states, and the
  interrupted target-only recording experiment are preserved and remain negative.
- Isolated single-hunk handoff/rebase/ABI-guard removals fail the relevant tests.
  Guard negative uses the actual ordinary Wasm and fails on the first fractional
  type; malformed code cannot masquerade as a valid make. Self-validation's
  unsigned-value prototype and all earlier stock wall-policy failures remain
  available separately and are not positive product proof.

Ordinary Wasm is unchanged `d055c473b686ce543d8b87da68034e240ba0f66cf8aacbb482e03a405a64363f`.
Source, guest/image identities, raw GPU/serial records, all original reports,
screenshots, controls and both final root/cold records are sealed in
`evidence/virgl-production-interactive-clock/worker/paced-keyboard-policy-submission.tar.gz`:
9,318,782bytes,SHA-256`01f6feaca7b0079b0a4dfa83fc4bdfeb757ca8b258af26c9bd8882273374a37d`,
416members/415identities; every member reopened and byte-compared. The fresh
verifier must still judge sufficiency/coverage. Host cursor publication remains
resource0 in the stock record; native cursor displacement is proven, not cursor
plane recovery. Parent71/D,context-loss recovery,deployment and300MIPS are not
verified by this worker submission.


### 2026-10-15 — verifier — paced policy and exact numeric ABI

VERDICT: verified

- **A1–A3 policy, ordering and failure boundaries — HELD.** The independent
  pre-data predictions in `critic-paced-keyboard-policy72/pre-data-predictions.json`
  are discharged by the actual extracted loader/main bodies and final selected
  tests. Accelerated ephemeral Omarchy alone defaults to paced-on-keyboard;
  exact realm/API admission precedes fetch/execution. A paused original NumLock
  make selects and reads back exact mode/decimal mtime/divider/timebase before
  staging. Repeated makes do not reanchor; stale/throwing/drifting readback and
  failed rebase stop before publication and poison the lifecycle. Release,
  repeat, omitted-policy, quota and explicit pause paths retain their stated
  behavior. The seven independent policy/oracle tests are promoted unchanged.
- **Numeric ABI novel attack — FAILED before repair; final A2 HELD.** With actual
  ordinary Wasm, original `sendKeyboardEvent(1,30.5,1)` plus SYN admitted two
  native events/one frame while clock remained ICount0/divider64: u16 coercion
  bypassed make eligibility. The independently rechecked literal is retained in
  `numeric-native-staging-result.json` (SHA-256
  `2bcf2ef68bb6c492bec7daba15a5cc648346f89e9e5d21386df802e501078564`).
  Final loader lines1207–1216 now reject nonrepresentable u16/u16/i32 inputs
  before clock selection or staging. Five promoted tests use the actual ordinary
  Wasm, covering26 malformed frames under paced/wall/omitted policies, exact
  signed MSC_SCAN min/-1/max and valid original KEY controls. The original
  unsigned-value prototype was corrected before freeze; signed native data is
  preserved. Removing only the guard in an isolated copy makes the actual-Wasm
  test fail on its first fractional type. Removing only the handoff separately
  fails paused-lock ordering. Original source bytes remain unchanged by either
  negative control.
- **A4–A5 real worker and pause — HELD.** Reopened final frozen61 hot and pristine
  worker recordings each contain14 rejected no-effect numeric rows,3 accepted
  signed MSC rows, then actual ICount→paced-icount at unchanged mtime0,
  retired0,timebase10M,divider64 while paused. Both49 served-body pins match
  frozen source objects. Recomputed hot pause bounds375000≤3292263 and
  210937≤3300750; cold445313≤3300475 and164062≤3120726. Exact paused retirement
  and clock are frozen; bounds include measured host time and ceil(actual
  retired delta/divider), including phase slack. Independent divider37 boundary
  and one-excess-tick refusal hold. Ten events/five frames in this component are
  staged, not claimed consumed by Linux. D73 native/JIT semantics carry by
  unchanged code/dependency and ordinary Wasm SHA-256
  `d055c473b686ce543d8b87da68034e240ba0f66cf8aacbb482e03a405a64363f`.
- **A6 stock interaction and valid-domain carry — HELD.** Original pristine e17
  stock `production-paced-policy-cold-stock02/browser/report.json` passes.
  All60 trusted balanced transitions match the literal command and62 original
  frames (including balanced NumLock repair); original nominal50ms helper is
  unchanged. First T hold is51.825ms; actual letter holds49.550–52.345ms are
  retained, without inventing a minimum50ms condition. Marker is absent before
  typing; original serial line5577/tag`mv8z4e7v189` reports
  `TRUSTED_TOUCH_42`/exit0 after four failed read-only observations. Final original
  PNG shows one correct touch command and new prompt. Bar crop021 is visibly
  readable with722 reported foreground pixels, exact PNG SHA-256
  `960996228cdf900b7f42e56ac0e67b5c557b563502ce59fc83b0924f3f44b4f5`;
  earlier blank crops remain preserved. Actual guest cursor640,400→430,412
  moves210px. Five-second pause freezesmtime1177933052/retired48240469040;
  resumed62497ticks≤2986154 bound. Final GPU657begun=657completed,308draws,
  no pending/failed/cancelled job, no held/pending/dropped/rejected input,
  worker/page errors[] and no observed original DRM response refusal.
  Every one of those62 original integer frames passes the new pure guard;
  removing exactly its five lines restores the original e17 loader. All other
  clock/main/worker/native/renderer/Wasm boundaries are identical. Final actual
  worker and actual-Wasm controls exercise this changed guard, so that explicit
  domain-equivalence proof carries the valid stock path without another long boot.
- **A6 software/private components — HELD.** All10 original four-image
  initial/repeat/persistence phases pass, including actual Node20.15.1 and
  coherent durable markers. Omarchy84.265s initial includes198MB download;
  repeat6.027s, not a universal latency claim. Private window04 closes actual
  Mesa768pixel/index83,1000cube frames and real Hyprland/Foot scanout;
  serial lines608/632 prove IPC and mapping, line650 contains the mapped title.
  Guest digest is
  `d27ddf4d5d4b6e6007ed6836750fbbaf31500d87a74f7747bd8431f83fe1faaa`.
  Actual JIT291649836blocks/3937142435retiredViaJit and the13-family original
  handshake hold. Private final31192draws/3269begun/3268completed has one
  pending ready request; later full trace31516DRAW packets is a different point,
  not a drained-owner assertion. The upright green-text Foot screenshot was
  directly inspected. This root/config component does not substitute for stock.
- **Exact-head cold custody and A7 — HELD.** Final input-boundary proof at
  `61eeb1b59902c9c52f0c4fdf3880a0081ebb2db2` passes four hot commands and
  three pristine outer/four inner commands:89 tests,17 actual worker rows and
  default127passed/0failed, errors[], no proof exports; graphics pip remains
  partial. Independently checked ordinary `clone --no-local`, scrubbed
  RUSTFLAGS/RUST_LOG/CARGO_/VIRGL_/CRITIC_ environment, own `make web-dist`,
  exact clean clone HEAD and no alternates. All report payload pins authenticate.
  Rehashed/reopened all416 worker archive members/415 identities and all39
  frozen source copies; later294a570f changes no product source. Worker archive
  SHA-256 is
  `01f6feaca7b0079b0a4dfa83fc4bdfeb757ca8b258af26c9bd8882273374a37d`.
- **COVERAGE / preserved failures.** The independent seal's
  `prediction-and-coverage.json` maps each runtime/harness hunk to executed
  proof; documentation/config/generated metadata is explicitly classified.
  Original full-cold/private300000ms wrappers remain failed; corrected isolation
  enables genuine JIT but did not alone resolve readiness. Private900000ms
  missing-path proof changes only the bounded observation window; this task
  states no host-startup budget. Original stock outer wrapper's pre-browser
  default-task allowlist failure remains failed; final default checks close only
  that missing path. Recording interruptions and earlier wall-policy repeated-t
  refutations remain negative. No whole failed wrapper is relabelled passed.
  No required D72 runtime hunk remains unexecuted or unclassified.
- **SUITE / limits.** Keep the seven policy/oracle and five actual-Wasm tests in
  the selected clock gate. Independent seal:
  `evidence/virgl-production-interactive-clock/verifier/paced-policy-final/independent-paced-keyboard-policy-review.tar.gz`,
  910543bytes, SHA-256
  `57c6a9e4851218571fd4b81990757a1b3fe21b406d97b5f9d640d5f63bcec8a9`,
  87members/86identities reopened. It retains pre-data predictions, controls,
  original coercion, failed reader-preparation attempts and final custody audits.
  Stock host cursor remains resource0; this verifies guest cursor displacement,
  not cursor-plane recovery. D71, parentD, E6e recovery, deployment and300MIPS
  remain outside this verdict and require their own transitions.

Commands: original recorded commands and exact outputs are in the independent
seal's `report.json`, `keyboard-abi-report.json`, `handoff-negative-report.json`
and `keyboard-abi-negative-report.json`. Final read-only authentication:
`python3 target/evidence/critic-paced-keyboard-policy72/audit-private-component.py`,
`python3 target/evidence/critic-paced-keyboard-policy72/audit-stock-and-carry.py`,
`python3 target/evidence/critic-paced-keyboard-policy72/audit-final-submission.py`.
Native73 verifier commit7e2739f2 and unchanged held boundaries are carried;
no unrelated native suite or successful stock boot was repeated for this review.
