import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');SCRATCH=Path('/tmp/wasmvm-d25-critic');OUTPUT=ROOT/'evidence/virgl-standard-float-images/verifier'
FROZEN='18ef4acfdebd30dd9edef9c3a1cca1e1fc4490dc';PROMOTED='953f5c5eee075e4dc6562626bae945db6a0513f0'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==PROMOTED
assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=ROOT,text=True).strip()
members={}
def add(name,raw):assert name not in members;members[name]=raw
def tree(prefix,path):
 for file in sorted(path.rglob('*')):
  if file.is_file():add(prefix+'/'+file.relative_to(path).as_posix(),file.read_bytes())
for file in sorted(SCRATCH.iterdir()):
 if file.is_file() and file.name not in ['novel-original-inputs.json','specgen.py']:
  add('audit/'+file.name,file.read_bytes())
# Preserve the pre-native original predictions and complete first proof-attempt bodies.
add('audit/novel-original-inputs-initial-preparation.json',(SCRATCH/'novel-original-inputs.json').read_bytes())
add('audit/initial-preparation-generator.py',(SCRATCH/'specgen.py').read_bytes())
for folder in ['node-v8','promoted-node-v8','promoted-node-v8-final','promoted-precheck']:
 tree('audit/'+folder,SCRATCH/folder)
tree('promoted',ROOT/'target/evidence/virgl-standard-float-images-verifier-final')
for name in ['renderer/virgl-command/resources.mjs','renderer/virgl-command/float-images.mjs','renderer/virgl-command/color-images.mjs','renderer/virgl-command/tests/standard-float-image-adversarial.mjs','tools/verify-virgl-standard-float-images-adversarial.mjs','tools/verify-virgl-standard-float-images-adversarial.sh','tools/virgl-command/standard-float-image-adversarial.py','Makefile']:
 add('source/promoted/'+name,subprocess.check_output(['git','show',PROMOTED+':'+name],cwd=ROOT))
for name in subprocess.check_output(['git','diff','--name-only','6ec464d9b9d1daecd01a0dd5ac58d31ac23910fe',FROZEN],cwd=ROOT,text=True).splitlines():
 add('source/worker-frozen/'+name,subprocess.check_output(['git','show',FROZEN+':'+name],cwd=ROOT))
add('source/worker-frozen/renderer/virgl-shader/vendor/src/virgl_hw.h',subprocess.check_output(['git','show',FROZEN+':renderer/virgl-shader/vendor/src/virgl_hw.h'],cwd=ROOT))
# Full worker/native originals stay in the separately authenticated committed seal.
for name in ['manifest.json','records.json']:
 add('worker-reference/'+name,(ROOT/'evidence/virgl-standard-float-images/worker'/name).read_bytes())
for name in ['renderer/virgl-shader/build/wasm/virgl-shader.mjs','renderer/virgl-shader/build/wasm/virgl-shader.wasm']:
 add('generated/'+name,(ROOT/name).read_bytes())
confirmation=dict(schema='independent-E6-T11d25-command-record-v1',finalPromotedCommand='VIRGL_FLOAT_IMAGE_ADVERSARIAL_DIR=target/evidence/virgl-standard-float-images-verifier-final NODE_V8_COVERAGE=/tmp/wasmvm-d25-critic/promoted-node-v8-final make verify-E6-T11d25-adversarial',status='passed',sourceHead=PROMOTED,nativeRuns=16,controlRuns=1,nodeOwnBudgetRecords=112,workerAudit='audit/worker-bit-audit.json',completeWorkerSeal='evidence/virgl-standard-float-images/worker',runtimeUnchanged=True,coldProofCarriedOnce=True)
add('audit/final-command.json',(json.dumps(confirmation,indent=2)+'\n').encode())
index=(json.dumps(dict(schema='independent-float-image-verifier-records-v1',task='E6-T11d25',sourceHead=PROMOTED,workerFrozenHead=FROZEN,records=[dict(path=name,bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(members.items())]),indent=2)+'\n').encode()
stream=io.BytesIO()
with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0) as gz:
 with tarfile.open(fileobj=gz,mode='w') as tar:
  for name,raw in sorted(members.items()):
   info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(raw))
archive=stream.getvalue();OUTPUT.mkdir(parents=True,exist_ok=True);(OUTPUT/'records.json').write_bytes(index);(OUTPUT/'recording.tar.gz').write_bytes(archive)
manifest=dict(schema='independent-float-image-verifier-seal-v1',task='E6-T11d25',verdict='verified',sourceHead=PROMOTED,workerFrozenHead=FROZEN,workerSubmission='132ece2a1f9e6ff71fc08bbd1a8aaa6ddd5a01e1',records=len(members),unpackedBytes=sum(map(len,members.values())),archiveBytes=len(archive),archiveSha256=sha(archive),recordIndexSha256=sha(index),workerArchiveSha256='560341ec9107b78c74be23176fc3d6a5bd988da08674e96f69855f2eec259eb9',workerIndexSha256='dc9200c84fc4cbb006390265b5510f2c54343c87d6f609ce202b2e3c2d03f4dd',coldReportSha256='69435d0be5916c036481cd50410839610446c7d423c01129d1f143b4457d1276',coldReceiptSha256='11450209d60ffaeab8f6de9f416ad0b7567321d6f0d51d265388bbf7eb467eb4',guestExecution=False,productionDrawAuthority=False,authority='isolated-original-float-image-storage-transfers-ranges')
(OUTPUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Reopen every complete sealed member; no summary-only acceptance.
rows={r['path']:r for r in json.loads(index)['records']};seen=set()
with tarfile.open(OUTPUT/'recording.tar.gz','r|gz') as tar:
 for entry in tar:
  assert entry.isfile() and entry.name not in seen;seen.add(entry.name);body=tar.extractfile(entry).read();row=rows[entry.name]
  assert len(body)==row['bytes'] and sha(body)==row['sha256']
assert seen==rows.keys() and sha((OUTPUT/'recording.tar.gz').read_bytes())==manifest['archiveSha256'] and sha((OUTPUT/'records.json').read_bytes())==manifest['recordIndexSha256']
print(json.dumps(manifest))
