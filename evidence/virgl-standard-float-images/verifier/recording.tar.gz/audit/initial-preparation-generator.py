import json,hashlib
from pathlib import Path
OUT=Path('/tmp/wasmvm-d25-critic')
FORMATS={**{91+i:(16,i+1) for i in range(4)},**{28+i:(32,i+1) for i in range(4)}}
def generate(seed,fmt,width,height,last):
 precision,c=FORMATS[fmt];size=precision//8;nc=4 if c==3 else c;state=seed^fmt;planes=[];offset=5
 def bits():
  nonlocal state
  state=(1664525*state+1013904223)&0xffffffff
  if precision==16:return (state&0x8000)|(((state>>23)%28+1)<<10)|(state&1023)
  return (state&0x80000000)|(((state>>23)%28+112)<<23)|(state&0x7fffff)
 def dense(w,h):return b''.join(bits().to_bytes(size,'little') for _ in range(w*h*c))
 for level in range(last+1):
  w=max(1,width//2**level);h=max(1,height//2**level);input=dense(w,h);stride=w*c*size+5
  planes.append(dict(level=level,width=w,height=h,offset=offset,stride=stride,input=input.hex()));offset+=(h-1)*stride+w*c*size+9
 patch=dict(level=1,box=dict(x=2,y=1,z=0,width=5,height=3,depth=1),offset=offset+3,stride=5*c*size+3,input=dense(5,3).hex());offset=patch['offset']+(3-1)*patch['stride']+5*c*size+17
 backing=bytearray([0x93]*offset)
 for plane in planes+[patch]:
  w=plane.get('width',5);h=plane.get('height',3);raw=bytes.fromhex(plane['input']);rb=w*c*size
  for y in range(h):backing[plane['offset']+y*plane['stride']:plane['offset']+y*plane['stride']+rb]=raw[y*rb:(y+1)*rb]
 mutation=dict(level=2,x=1,y=1,width=1,height=1,input=dense(1,1).hex())
 pixels=sum(p['width']*p['height'] for p in planes);viewpixels=sum(p['width']*p['height'] for p in planes[1:4]);physical=pixels*nc*size;viewphysical=viewpixels*nc*size
 return dict(seed=seed,format=fmt,precision=precision,components=c,nativeComponents=nc,size=size,metadata=dict(id=37,target=2,format=fmt,bind=10,width=width,height=height,depth=1,arraySize=1,lastLevel=last,nrSamples=0,flags=0),planes=planes,patch=patch,mutation=mutation,backing=backing.hex(),backingSha256=hashlib.sha256(backing).hexdigest(),predicted=dict(pixels=pixels,logicalBytes=pixels*c*size,physicalBytes=physical,viewPixels=viewpixels,viewLogicalBytes=viewpixels*c*size,viewPhysicalBytes=viewphysical,patchScratchBytes=15*nc*size,readScratchBytes=720,readStagingBytes=720,oldReadScratchBytes=448,oldReadStagingBytes=448,queuedOldGpuBytes=physical+viewphysical+448))
specs=[]
for seed in [0x6d3ac291,0xb71854e3]:
 for fmt in FORMATS:
  spec=generate(seed,fmt,19,11,4);spec['replacement']=generate(seed^0xf63ac749,fmt,7,3,2)
  # Replacement patch/mutation metadata is deliberately unused: only initial planes are uploaded.
  specs.append(spec)
(OUT/'novel-original-inputs.json').write_text(json.dumps(dict(schema='independent-floating-original-inputs-v1',specs=specs),indent=2)+'\n')
print(json.dumps(dict(specs=len(specs),predicted=specs[0]['predicted'],inputSha256=hashlib.sha256((OUT/'novel-original-inputs.json').read_bytes()).hexdigest())))
