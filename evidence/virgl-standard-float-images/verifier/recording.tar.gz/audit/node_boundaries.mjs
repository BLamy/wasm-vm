import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {createStandardFloatColorResourceStore,computeStandardFloatColorTransferLayout} from '/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm/renderer/virgl-command/resources.mjs';
const records=[];
for(const [format,precision,components] of [[91,16,1],[92,16,2],[93,16,3],[94,16,4],[28,32,1],[29,32,2],[30,32,3],[31,32,4]]) {
 const metadata={id:41,target:2,format,bind:10,width:7,height:5,depth:1,arraySize:1,lastLevel:2,nrSamples:0,flags:0};
 const box={x:2,y:1,z:0,width:3,height:2,depth:1},fields={resourceHandle:41,level:0,usage:0,stride:3*components*precision/8+3,layerStride:0,box,dataOffset:3,direction:2};
 const exact=computeStandardFloatColorTransferLayout(metadata,fields,1000);assert.equal(exact.ok,true);
 assert.equal(exact.layout.scratchBytes,96);assert.equal(exact.layout.stagingBytes,96);records.push({kind:'nonzero-layout',metadata,fields,result:exact});
 for(const [name,changed] of [['out-x',{...fields,box:{...box,x:7}}],['out-level',{...fields,level:3}],['out-row',{...fields,stride:1}],['out-layer',{...fields,layerStride:1}],['overflow-stride',{...fields,stride:0xffffffff}],['overflow-offset',{...fields,dataOffset:0xffffffff}]]){
  const result=computeStandardFloatColorTransferLayout(metadata,changed,1000);assert.equal(result.ok,false,name);records.push({kind:'refusal',name,format,result});
 }
 let getters=0;const hostile={...box};Object.defineProperty(hostile,'x',{enumerable:true,get(){getters++;return 2;}});
 assert.equal(computeStandardFloatColorTransferLayout(metadata,{...fields,box:hostile},1000).ok,false);assert.equal(getters,0);records.push({kind:'hostile-box',format,getters});
 for(const boundary of ['scratch','cpu','gpu'])for(const short of [false,true]){
  let staged=0,releases=0,allocations=0;
  const nativePixels=42*(components===3?4:components)*precision/8;
  const limits=boundary==='gpu'?{gpuBytes:nativePixels+96-Number(short)}:{[boundary==='scratch'?'scratchBytes':'cpuBytes']:96-Number(short)};
  const backend={maxTextureSize:64,colorProfile:'virgl-standard-byte-color-transfers-v1',floatProfile:'virgl-standard-float-color-transfers-v1',allocate(){allocations++;return{};},destroy(){},upload(){},readback(){},copyTextureRange(){},dispose(){},beginReadback(){staged++;return{};},releaseReadback(){releases++;},pollReadback(){return true;},collectReadback(){return new Uint8Array(3*2*components*precision/8);}};
  const owner=createStandardFloatColorResourceStore({backend,limits});assert.equal(owner.ok,true);const store=owner.store;
  assert.equal(store.createContext(1).ok,true);assert.equal(store.createResource(metadata).ok,true);assert.equal(store.attachContext(1,41).ok,true);
  const lease=store.retainStorage(1,41,'readback');assert.equal(lease.ok,true);
  const read=owner.asyncAccess.beginStorageRead(lease.lease,box);assert.equal(read.ok,!short);assert.equal(staged,Number(!short));
  if(short){assert.equal(read.error.code,'limit-exceeded');assert.equal(store.inspect().budgets.scratchBytes,0);assert.equal(owner.asyncAccess.inspect().stagingBytes,0);}
  else{assert.equal(store.inspect().budgets.gpuBytes,nativePixels+96);assert.equal(store.inspect().budgets.scratchBytes,96);assert.equal(owner.asyncAccess.inspect().stagingBytes,96);assert.equal(owner.asyncAccess.release(read.ticket).ok,true);assert.equal(releases,1);}
  assert.equal(store.releaseStorage(lease.lease).ok,true);assert.equal(store.dispose().ok,true);assert.ok(Object.values(store.inspect().budgets).every(x=>x===0));
  records.push({kind:'one-byte-limit',format,boundary,short,result:read.ok,allocations,staged,releases,limits});
 }
}
await fs.writeFile('/tmp/wasmvm-d25-critic/node-boundaries.json',JSON.stringify({schema:'independent-original-float-own-budget-boundaries-v1',status:'passed',records},null,2)+'\n');
console.log(JSON.stringify({status:'passed',records:records.length}));
