import gzip,hashlib,json,math,struct,re
from pathlib import Path
OUT=Path('/tmp/wasmvm-d25-critic');ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
FORMATS={**{91+i:(16,i+1) for i in range(4)},**{28+i:(32,i+1) for i in range(4)}}
ENUMS={91:33325,92:33327,93:34842,94:34842,28:33326,29:33328,30:34836,31:34836}
HALF=[0,32768,1,32769,1023,33791,1024,33792,15360,48128,13653,46421,15361,15362,31743,64511,1025,6142,27673,58389]
FLOAT=[0,2147483648,1,2147483649,8388607,2155872255,8388608,2155872256,1065353216,3212836864,1051372203,3198855851,1065353217,1065353218,2139095039,4286578687,8388609,0x177ffe01,0x4d431219,3826390339]
EXTRA16=[31744,64512,32256,65024,32003];EXTRA32=[2139095040,4286578688,2143289344,4290772992,2140148276]
sha=lambda b:hashlib.sha256(b).hexdigest()
def raw(d,entry):
 p=d/(entry.get('path') or entry['key']+'.bin.gz');b=gzip.decompress(p.read_bytes());assert len(b)==entry['bytes'] and sha(b)==entry['sha256'];return b
def words(b,size):return struct.unpack('<'+('H' if size==2 else 'I')*(len(b)//size),b)
def half32(h):
 s=(h&32768)<<16;e=(h>>10)&31;f=h&1023
 if e==31:return s|0x7f800000|(f<<13)
 if e:return s|((e+112)<<23)|(f<<13)
 if not f:return s
 n=f.bit_length()-1;return s|((n+103)<<23)|((f-(1<<n))<<(23-n))
def finite_bits(p,w):return ((w>>(10 if p==16 else 23))& (31 if p==16 else 255)) != (31 if p==16 else 255)
def matches(p,w,a):
 if not finite_bits(p,w):return True
 wanted=half32(w) if p==16 else w
 if wanted&0x7fffffff==0:return a&0x7fffffff==0
 if w& (0x7c00 if p==16 else 0x7f800000)==0:return a==wanted or a&0x7fffffff==0
 return a==wanted
def compare_native(fmt,source,native,label):
 p,c=FORMATS[fmt];given=words(source,p//8);actual=words(native,4);assert len(actual)==len(given)//c*4,label
 n=0
 for i,a in enumerate(actual):
  lane=i%4;pixel=i//4
  w=given[pixel*c+lane] if lane<c else (0x3c00 if p==16 else 0x3f800000) if lane==3 else 0
  assert matches(p,w,a),(label,i,hex(w),hex(a));n+=finite_bits(p,w)
 return n
def compare_public(fmt,source,public,label):
 p,c=FORMATS[fmt];a=words(public,p//8);want=words(source,p//8);assert len(a)==len(want),label;n=0
 for i,(w,z) in enumerate(zip(want,a)):
  if not finite_bits(p,w):continue
  signmask=32767 if p==16 else 0x7fffffff;expmask=0x7c00 if p==16 else 0x7f800000
  assert z==w or (w&signmask==0 and z&signmask==0) or (w&expmask==0 and z&signmask==0),(label,i,hex(w),hex(z));n+=1
 return n
def upload(fmt,source):
 p,c=FORMATS[fmt];size=p//8
 if c!=3:return source
 alpha=(0x3c00 if p==16 else 0x3f800000).to_bytes(size,'little')
 return b''.join(source[i:i+3*size]+alpha for i in range(0,len(source),3*size))
def generated(fmt,run,plane):
 p,c=FORMATS[fmt];pool=(EXTRA16 if p==16 else EXTRA32) if run.get('exceptional') else HALF if p==16 else FLOAT
 seed=run.get('seed')
 if seed is None:return None
 return b''.join(pool[(i*7+plane['level']*3+seed)%len(pool)].to_bytes(p//8,'little') for i in range(plane['width']*plane['height']*c))
def geometry(meta):
 p,c=FORMATS[meta['format']];size=p//8;pixels=[max(1,meta['width']//2**k)*max(1,meta['height']//2**k) for k in range(meta['lastLevel']+1)]
 return sum(pixels)*c*size,sum(pixels)*(4 if c==3 else c)*size
counts=dict(runs=0,nativeComponents=0,publicStoredComponents=0,uploadBytes=0,paddingBytes=0,allocations=0,layouts=0,fences=0,lifetimeSnapshots=0,halfPatterns=0,roundingPatterns=0)
rows=[];controls=[]
descriptors=json.loads((ROOT/'tools/virgl-command/standard-float-image-formats.json').read_text());table=(ROOT/descriptors['sourceFile']).read_bytes();assert sha(table)==descriptors['yamlSha256'];header=(ROOT/'renderer/virgl-shader/vendor/src/virgl_hw.h').read_bytes();assert sha(header)==descriptors['headerSha256']
for r in descriptors['records']:
 p,c=FORMATS[r['format']];assert r['precision']==p and r['components']==c and r['pixelBytes']==p//8*c and r['nativePixelBytes']==p//8*(4 if c==3 else c)
 lines=table.decode().splitlines(keepends=True);desc=''.join(lines[r['sourceLine']-1:r['sourceLine']-1+len(r['descriptor'].splitlines())]);assert desc==r['descriptor'] and sha(desc.encode())==r['descriptorSha256']
 assert int(re.search('VIRGL_FORMAT_'+r['name']+r'\s*=\s*(\d+)',header.decode())[1])==r['format']
for phase in ['hot','cold']:
 root=OUT/'worker'/phase
 half=json.loads((root/'half-representation.json').read_text())
 for r in half['records']:
  h=r['half'];f=r['floatWord'];back=r['roundtrip']
  if finite_bits(16,h) or h&1023==0:assert f==half32(h) and back==h
  else:assert f&0x7f800000==0x7f800000 and f&0x7fffff and back&0x7c00==0x7c00 and back&1023
  counts['halfPatterns']+=1
 def nearest_even_ratio(n,shift):
  if shift<=0:return n<<-shift
  q,rem=divmod(n,1<<shift);halfway=1<<(shift-1)
  return q+int(rem>halfway or rem==halfway and q&1)
 def round_half(w):
  sign=(w>>16)&0x8000;exp=(w>>23)&255;frac=w&0x7fffff
  if exp==255:return sign|0x7c00|(0x200 if frac else 0)
  if exp==0:return sign
  # Integer significand multiplied by 2^(exp-150). Subnormal unit is 2^-24.
  if exp<113:return sign|nearest_even_ratio((1<<23)|frac,126-exp)
  q=nearest_even_ratio((1<<23)|frac,13);e=exp-127
  if q==2048:q=1024;e+=1
  if e>15:return sign|0x7c00
  return sign|((e+15)<<10)|(q-1024)
 for r in half['rounding']:assert r['half']==round_half(r['inputWord']),(r,round_half(r['inputWord']));counts['roundingPatterns']+=1
 wire=json.loads((root/'wire/report.json').read_text())['wire'];assert len(wire['records'])==240
 for r in wire['records']:
  if r['kind']=='metadata':l,g=geometry(r['original']);assert r['result']['byteLength']==l and r['result']['gpuByteLength']==g
  elif r['kind']=='allocation-limit':assert r['result']['ok']==r['boundary'].endswith('exact') and r['allocations']==int(r['boundary'].endswith('exact'))
  elif r['kind'] in ['invalid','hostile','backend-profile']:assert not r['result']['ok']
  elif r['kind']=='layout':
   p,c=FORMATS[r['format']];layout=r['layout'];f=r['fields'];w=f['box']['width'];h=f['box']['height'];rb=w*c*p//8
   assert layout['rowBytes']==rb and layout['tightBytes']==rb*h and layout['scratchBytes']==w*h*(16 if f['direction']==2 else (4 if c==3 else c)*p//8)
   assert layout['stagingBytes']==(w*h*16 if f['direction']==2 else 0);counts['layouts']+=1
 for d in sorted(p.parent for p in root.glob('hardware*/report.json')):
  env=json.loads((d/'report.json').read_text());report=env['browserResult']['result'];assert env['status']=='passed' and 'Metal' in report['gpu'] and 'M4' in report['gpu']
  for ix,run in enumerate(report['runs']):
   fmt=run['metadata']['format'];p,c=FORMATS[fmt];size=p//8;original={k['level']:raw(d,k['input']) for k in run['planes']};backing=raw(d,run['backing']);counts['runs']+=1
   for plane in run['planes']:
    assert plane['width']==max(1,run['metadata']['width']//2**plane['level']) and plane['height']==max(1,run['metadata']['height']//2**plane['level'])
    gold=generated(fmt,run,plane)
    if gold is not None:assert gold==original[plane['level']],('original generator',d.name,ix,plane['level'])
    rb=plane['width']*c*size;recovered=b''.join(backing[plane['offset']+y*plane['stride']:plane['offset']+y*plane['stride']+rb] for y in range(plane['height']));assert recovered==original[plane['level']]
    if 'observed' in plane:counts['nativeComponents']+=compare_native(fmt,original[plane['level']],raw(d,plane['observed']['native']),(d.name,ix,'plane',plane['level']))
   for a in run['allocations']:
    m=a['metadata']
    if m['format'] not in FORMATS:continue
    logical,physical=geometry(m);assert m['byteLength']==logical and m['gpuByteLength']==physical
    ev=[e for e in run['nativeEvents'] if e['name']=='texStorage2D' and e['texture']==a['texture']];assert len(ev)==1
    assert ev[0]['args']==[3553,m['lastLevel']+1,ENUMS[fmt],m['width'],m['height']]
    counts['allocations']+=1
   replacements={z['level']:raw(d,z['input']) for z in run.get('replacement',{}).get('planes',[])}
   for u in run['uploads']:
    inputs=replacements if u['label'].startswith('bounded-float-unequal-replacement') else original
    b=raw(d,u['bytes']);assert b==upload(fmt,inputs[u['args'][1]])
    assert u['type']==('Uint16Array' if p==16 else 'Float32Array') and u['args'][7]==(5131 if p==16 else 5126)
    assert u['args'][6]==([6403,33319,6408,6408][c-1]);counts['uploadBytes']+=len(b)
   for t in run.get('transfers',[]):
    counts['publicStoredComponents']+=compare_public(fmt,original[t['level']],raw(d,t['sync']),'sync')
    for r in t['reads']:
     counts['publicStoredComponents']+=compare_public(fmt,original[t['level']],raw(d,r['nativeBytes']),'staged')
     f=r['fence'];assert f['actual'] in [37146,37148] and f['delivered']==f['actual'];layout=r['layout'];pix=layout['box']['width']*layout['box']['height'];assert layout['scratchBytes']==layout['stagingBytes']==pix*16;counts['layouts']+=1
   for v in run.get('views',[]):
    assert v['generation']==run['generation'] and v['metadata']['width']==max(1,run['metadata']['width']//2**v['firstLevel']) and v['metadata']['height']==max(1,run['metadata']['height']//2**v['firstLevel'])
    for z in v['planes']:assert z['original']==v['firstLevel']+z['local'];counts['nativeComponents']+=compare_native(fmt,original[z['original']],raw(d,z['native']),'private view')
   for z in run.get('observations',[]):
    assert z['fence']['actual'] in [37146,37148] and z['fence']['delivered']==z['fence']['actual']
    if z['kind']=='retained-old-read':assert z['generation']==run['generation'];counts['publicStoredComponents']+=compare_public(fmt,original[0],raw(d,z['native']),'retained-old')
    else:
     wanted=raw(d,z['clearInput']) if 'clearInput'in z else original[z['original']]
     if 'clearInput'in z:
      vv=[.125,-1.25,4,1];gold=struct.pack('<'+('e' if p==16 else 'f')*(c*z['width']*z['height']),*(vv[:c]*z['width']*z['height']));assert wanted==gold
     counts['nativeComponents']+=compare_native(fmt,wanted,raw(d,z['native']),'native refresh')
   if 'backingAfterRefresh'in run:assert raw(d,run['backingAfterRefresh'])==backing
   for s in run.get('snapshots',[]):
    b=s['state']['budgets'];resources=s['state']['resources'];physical=sum(geometry(m)[1] for m in resources);view=geometry(run['view']['metadata'])[1] if b['imageViews'] else 0
    staging=s['async']['stagingBytes'];assert b['gpuBytes']==physical+view+staging and b['scratchBytes']==staging and b['cpuBytes']==b['backingBytes']+staging
    if s['point']=='queued-old-read':assert staging==run['metadata']['width']*run['metadata']['height']*16
    counts['lifetimeSnapshots']+=1
   if run.get('kind')=='native-failure':assert not run['result']['ok'] and run['result']['error']['code']=='backend-error' and len(run['faultEvents'])==1 and run['afterFailure']['budgets']['scratchBytes']==0
   for end,fill in [('finalBacking',167),('finalStagingBacking',46)]:
    if end not in run:continue
    final=raw(d,run[end]);occupied=set();assert len(final)==len(backing)
    for z in run['planes']:
     rb=z['width']*c*size;dense=b''.join(final[z['offset']+y*z['stride']:z['offset']+y*z['stride']+rb] for y in range(z['height']));counts['publicStoredComponents']+=compare_public(fmt,original[z['level']],dense,end)
     for y in range(z['height']):occupied.update(range(z['offset']+y*z['stride'],z['offset']+y*z['stride']+rb))
    for at,b in enumerate(final):
     if at not in occupied:assert b==fill;counts['paddingBytes']+=1
   for event in run['events']:
    if event['name']=='clientWaitSync':assert event['actual'] in [37147,37146,37148] and event['delivered'] in [37147,37146,37148];counts['fences']+=int(event['delivered'] in [37146,37148])
   assert all(x==0 for x in run['final']['budgets'].values()) and all(o['deleted']==1 for o in run['nativeObjects'])
   rows.append(dict(record=str(d.relative_to(OUT/'worker')),run=ix,format=fmt,kind=run.get('kind','matrix'),status='held'))
 for d in sorted(p.parent for p in root.glob('fault-*/report.json')):
  env=json.loads((d/'report.json').read_text());r=env['partial'];s=r['sabotage'];run=r['runs'][0];z=s['observation'];level=z.get('original',z.get('level'));plane=next(q for q in run['planes'] if q['level']==level)
  assert s['fenceCompleted'] and s['fence']['actual'] in [37146,37148] and s['fence']['delivered']==s['fence']['actual']
  try:compare_native(run['metadata']['format'],raw(d,plane['input']),raw(d,z['native']),'wrong physical selection')
  except AssertionError as e:controls.append(dict(record=str(d.relative_to(OUT/'worker')),status='refuted',finding=str(e),fence=s['fence']))
  else:raise AssertionError('independent oracle did not detect actual wrong native selection')
result=dict(schema='independent-original-bit-float-audit-v1',status='passed',counts=counts,rows=rows,controls=controls)
(OUT/'worker-bit-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status='passed',counts=counts,controls=controls)))
