import hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=Path('/tmp/wasmvm-d25-critic');PROMOTED=ROOT/'target/evidence/virgl-standard-float-images-verifier-final'
sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *args:subprocess.check_output(['git','--no-optional-locks',*args],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');frozen='18ef4acfdebd30dd9edef9c3a1cca1e1fc4490dc';baseline='6ec464d9b9d1daecd01a0dd5ac58d31ac23910fe'
classifications=[]
coverage=json.loads((OUT/'nested-coverage.json').read_text())
for part in coverage['segments']:
 if part['maxCount']>0:part['classification']='executed'
 elif not part['text'].strip():part['classification']='waived-whitespace'
 else:
  assert (part['source'],part['line']) in [('renderer/virgl-command/resources.mjs',1245),('renderer/virgl-command/resources.mjs',1273)]
  original=subprocess.check_output(['git','show',baseline+':'+part['source']],cwd=ROOT).decode()
  assert part['text'] in original
  part['classification']='carried-immutable-historical-arm'
  part['reason']='Packed RGB10_A2 UInt32 read destination or Z16 UNSIGNED_BYTE staging read type is byte-identical to independently verified D22/D24. The preceding new FLOAT arm executes; no old semantic change is claimed.'
(OUT/'coverage-classification.json').write_text(json.dumps(coverage,indent=2)+'\n')
changes=git('diff','--name-only',baseline,frozen).splitlines()
inverse=json.loads((ROOT/'tools/virgl-command/standard-float-image-boundary.json').read_text())['changes']
for name in changes:
 if name in ['renderer/virgl-command/resources.mjs','renderer/virgl-command/float-images.mjs']:kind='executed-nested-runtime';reason='Every executable changed subregion has positive narrowest-region counters; two exact inherited arms carry authenticated D22/D24 HELD.'
 elif name in inverse:kind='waived-declarative-source-closure';reason='Each exact reversible HTTP snapshot/serving dependency declaration in this file reconstructs the predecessor including all assertions and controls. Relevant async/uniform/full-byte-color/texture-consumer gates execute with zero errors; immutable closures bind the new imported pure module. Other historical declarations grant no runtime authority.'
 elif name.startswith('tasks/') or name.endswith('README.md'):kind='waived-documentation';reason='Task/queue/documentation states a selected claim only and changes no runtime behavior.'
 elif name.endswith(('.yaml','.json')):kind='waived-pinned-data';reason='Original descriptors/enums, full YAML or boundary metadata are independently hashed/reconstructed. No executable runtime path resides here.'
 elif name=='Makefile':kind='executed-command-declaration';reason='The exact deterministic acceptance command appears in authenticated hot/cold acceptance logs and completed at frozen head.'
 else:kind='executed-proof-harness';reason='Relevant syntax checks and recorded final hot/cold invocations exercise this capture/oracle/authentication/coverage/cold/seal harness. Remaining source-drift/error/transport/type diagnostics are explicit proof scaffolding, not product semantic claims; their full source remains frozen and audited.'
 classifications.append(dict(path=name,classification=kind,reason=reason))
assert len(classifications)==50
(OUT/'changed-file-classification.json').write_text(json.dumps(dict(schema='independent-complete-float-diff-classification-v1',files=classifications),indent=2)+'\n')
current={}
for name in ['renderer/virgl-command/resources.mjs','renderer/virgl-command/float-images.mjs','renderer/virgl-command/color-images.mjs','renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs','renderer/virgl-command/cache.mjs']:
 raw=(ROOT/name).read_bytes();assert raw==subprocess.check_output(['git','show',frozen+':'+name],cwd=ROOT);current[name]=sha(raw)
assert not git('diff','--name-only',frozen,head,'--','renderer/virgl-shader','crates','web','tools/guest')
for name,digest in json.loads((OUT/'worker/hot/receipt.json').read_text())['generated'].items():assert sha((ROOT/name).read_bytes())==digest;current[name]=digest
captures=[];fence_audit=[]
for kind in ['healthy','control']:
 directory=PROMOTED/kind;p=directory/'report.json';report=json.loads(p.read_text());assert report['gitHead']==head
 for source in report['sources']:
  raw=(ROOT/source['path']).read_bytes();assert sha(raw)==source['sha256'] and len(raw)==source['bytes']
  assert raw==subprocess.check_output(['git','show',head+':'+source['path']],cwd=ROOT)
 for script in json.loads((directory/'coverage.json').read_text())['scripts']:assert script['sha256']==next(r['sha256'] for r in report['sources'] if r['path']==script['source'])
 assert report['browserErrors']==dict(console=[],page=[],requests=[]) and not report['browser']['headless']
 for run in report['result']['runs']:
  pending_buffer=None;buffer_sync={};complete=set();collected=0
  for event in run['events']:
   if event['name']=='readPixels' and event['buffer'] is not None:pending_buffer=event['buffer']
   elif event['name']=='fenceSync' and pending_buffer is not None:buffer_sync[pending_buffer]=event['sync'];pending_buffer=None
   elif event['name']=='clientWaitSync' and event['actual'] in [37146,37148]:complete.add(event['args'][0])
   elif event['name']=='getBufferSubData':assert buffer_sync[event['buffer']] in complete,(kind,run['format'],event['ordinal']);collected+=1
  fence_audit.append(dict(kind=kind,seed=run['seed'],format=run['format'],collected=collected,allAfterActualCompletedPhysicalFence=True))
 captures.append(dict(kind=kind,head=report['gitHead'],reportSha256=sha(p.read_bytes()),coverageSha256=sha((directory/'coverage.json').read_bytes()),screenshotSha256=sha((directory/'browser.png').read_bytes())))
(OUT/'current-boundary.json').write_text(json.dumps(dict(schema='independent-final-float-boundary-v1',sourceHead=head,workerFrozenHead=frozen,runtimeUnchanged=True,current=current,verifierChanges=git('diff','--name-only','132ece2a1f9e6ff71fc08bbd1a8aaa6ddd5a01e1',head).splitlines()),indent=2)+'\n')
(OUT/'fresh-authentication.json').write_text(json.dumps(dict(schema='independent-fresh-float-custody-v1',status='passed',captures=captures,fenceAudit=fence_audit,originalInputSha256=sha((PROMOTED/'original-inputs.json').read_bytes())),indent=2)+'\n')
# Exhaustively partition the new native harness at every detailed V8 endpoint.
source_name='renderer/virgl-command/tests/standard-float-image-adversarial.mjs';source=(ROOT/source_name).read_text();encoded=source.encode('utf-16-le');runs=[]
for kind in ['healthy','control']:
 for row in json.loads((PROMOTED/kind/'coverage.json').read_text())['scripts']:
  if row['source']==source_name:runs.append((kind,row['coverage']['functions']))
cuts={0,len(encoded)//2}
for _,functions in runs:
 for fn in functions:
  for r in fn['ranges']:cuts.update([r['startOffset'],r['endOffset']])
segments=[]
for a,b in zip(sorted(cuts),sorted(cuts)[1:]):
 piece=encoded[a*2:b*2].decode('utf-16-le');obs=[]
 for name,functions in runs:
  ranges=[r for fn in functions for r in fn['ranges'] if r['startOffset']<=a and b<=r['endOffset']]
  if ranges:obs.append(dict(record=name,**min(ranges,key=lambda r:r['endOffset']-r['startOffset'])))
 count=max([r['count'] for r in obs],default=0)
 line=source[:len(encoded[:a*2].decode('utf-16-le'))].count('\n')+1
 segments.append(dict(start=a,end=b,line=line,text=piece,maxCount=count,counters=obs))
(OUT/'promoted-coverage-raw.json').write_text(json.dumps(dict(source=source_name,segments=segments),indent=2)+'\n')
print(json.dumps(dict(status='passed',head=head,changedFiles=len(classifications),runtimeRegions=len(coverage['segments']),captures=captures,fencedCollections=sum(r['collected'] for r in fence_audit),newNativeRegions=len(segments),zeroNativeRegions=[{'line':s['line'],'text':s['text']} for s in segments if s['maxCount']==0 and s['text'].strip()])))
