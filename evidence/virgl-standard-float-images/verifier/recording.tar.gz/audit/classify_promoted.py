import json
from pathlib import Path
OUT=Path('/tmp/wasmvm-d25-critic');data=json.loads((OUT/'promoted-coverage-raw.json').read_text())
reasons={
 4:'Empty-byte-input transport sentinel. Every admitted image and independent original fixture has strictly nonzero dimensions/bytes; no empty input authority is claimed.',
 5:'Fatal assertion wrapper propagation for a rejected worker API call. The native experiment records successful selected calls and deliberately rejects value mismatch through the unchanged oracle; this diagnostic throw is test scaffolding.',
 6:'Assertion failure formatter. Its positive predicates execute and all values are independently checked in the sealed Python audit; formatting a failed assertion supplies no runtime semantic authority.',
 10:'Unknown-native-object logging sentinel. Every owned image/PBO/FBO/sync is assigned an ID by this recorder; this fallback carries no ownership or allocation behavior.',
 33:'Other-buffer binding logging branch. This image-only recorder creates PIXEL_PACK buffers; COPY_WRITE fallback is transport metadata and does not implement resource allocation.',
 89:'Bounded PBO timeout diagnostic. Actual successful completed waits and all later collections are independently interrogated; deliberately exhausting this harness timeout would add no task behavior.',
 95:'Out-of-corpus subnormal helper arm in the independent native comparison. The novel generator pins normal finite inputs only; the worker complete independent integer audit separately covers every original F16 word and native denormal freedoms. This helper grants no runtime representation behavior.'
}
for row in data['segments']:
 if row['maxCount']>0:row['classification']='executed'
 elif not row['text'].strip():row['classification']='waived-whitespace'
 else:assert row['line'] in reasons;row['classification']='waived-proof-diagnostic-or-domain';row['reason']=reasons[row['line']]
(OUT/'promoted-coverage-classification.json').write_text(json.dumps(data,indent=2)+'\n')
