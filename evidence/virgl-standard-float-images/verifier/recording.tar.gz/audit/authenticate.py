import hashlib,json,tarfile,gzip,subprocess
from pathlib import Path,PurePosixPath
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
OUT=Path('/tmp/wasmvm-d25-critic')
sha=lambda b:hashlib.sha256(b).hexdigest()
FROZEN='18ef4acfdebd30dd9edef9c3a1cca1e1fc4490dc'
BASE='6ec464d9b9d1daecd01a0dd5ac58d31ac23910fe'
git_cache={}
def original(head,name):
 k=(head,name)
 if k not in git_cache:git_cache[k]=subprocess.check_output(['git','show',head+':'+name],cwd=ROOT)
 return git_cache[k]
def archive(folder,extract=None):
 m=json.loads((folder/'manifest.json').read_text());iraw=(folder/'records.json').read_bytes();raw=(folder/'recording.tar.gz').read_bytes()
 assert sha(raw)==m['archiveSha256'] and sha(iraw)==m['recordIndexSha256']
 idx=json.loads(iraw);rows={r['path']:r for r in idx['records']};assert len(rows)==len(idx['records'])
 seen=set();total=0
 with tarfile.open(folder/'recording.tar.gz','r|gz') as t:
  for member in t:
   assert member.isfile() and member.name not in seen
   assert not PurePosixPath(member.name).is_absolute() and '..' not in PurePosixPath(member.name).parts
   seen.add(member.name);entry=rows[member.name];body=t.extractfile(member).read()
   assert len(body)==entry['bytes'] and len(body)==member.size and sha(body)==entry['sha256'],member.name
   total+=len(body)
   if extract:
    file=extract/member.name;file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(body)
 assert seen==rows.keys() and len(seen)==m['records']
 return dict(folder=str(folder.relative_to(ROOT)),manifest=m,records=len(seen),unpackedBytes=total)
result={'predictionFileSha256':sha((OUT/'predictions.json').read_bytes()),'archives':[],'receipts':[],'sources':[],'browserClosures':[]}
result['archives'].append(archive(ROOT/'evidence/virgl-standard-float-images/worker',OUT/'worker'))
assert result['archives'][0]['manifest']['sourceHead']==FROZEN
for prefix in ['virgl-standard-byte-color-images','virgl-standard-texture-operations']:
 for kind in ['worker','verifier']:
  folder=ROOT/'evidence'/prefix/kind
  for name in ['manifest.json','records.json','recording.tar.gz']:
   assert (folder/name).read_bytes()==original(BASE,str((folder/name).relative_to(ROOT)))
  result['archives'].append(archive(folder))
for run in ['hot','cold']:
 receipt=json.loads((OUT/'worker'/run/'receipt.json').read_text());assert receipt['gitHead']==FROZEN and receipt['status']=='passed'
 source_rows=[]
 for name,digest in receipt['sources'].items():
  assert sha(original(FROZEN,name))==digest,(run,'frozen source',name)
  if name!='tasks/epic-6-transcendence/E6-T11d25-standard-float-images.md':
   assert sha((ROOT/name).read_bytes())==digest,(run,'current source',name)
  source_rows.append(dict(path=name,sha256=digest))
 for name,digest in receipt['generated'].items():
  assert sha((OUT/'worker'/(run+'-generated')/name).read_bytes())==digest
  assert sha((ROOT/name).read_bytes())==digest
 for name,digest in receipt['files'].items():assert sha((OUT/'worker'/run/name).read_bytes())==digest,(run,name)
 result['receipts'].append(dict(run=run,gitHead=receipt['gitHead'],receiptSha256=sha((OUT/'worker'/run/'receipt.json').read_bytes()),files=len(receipt['files']),sources=len(source_rows),generated=receipt['generated']))
 for file in sorted((OUT/'worker'/run).rglob('report.json')):
  if file==OUT/'worker'/run/'report.json':continue
  r=json.loads(file.read_text())
  if r.get('gitHead'):assert r['gitHead']==FROZEN
  src={v['path']:v for v in r.get('sources',[])}
  served={v['path'].lstrip('/'):v for v in r.get('servedFiles',[])}
  for path,row in served.items():
   if path in src:assert row['sha256']==src[path]['sha256'] and row['bytes']==src[path]['bytes']
  if r.get('browserErrors'):assert r['browserErrors']==dict(console=[],page=[],requests=[])
  if r.get('browserCoverage'):
   p=file.parent/r['browserCoverage']['path'];assert sha(p.read_bytes())==r['browserCoverage']['sha256']
   for script in json.loads(p.read_text()).get('scripts',[]):
    assert script['sha256']==served[script['source']]['sha256']==src[script['source']]['sha256']
  rr=r.get('browserResult',{}).get('result') or r.get('partial')
  if rr:
   assert not rr.get('guestExecution') and not rr.get('productionNegotiation')
   for b in rr.get('blobs',[]):
    packed=(file.parent/b.get('path',b['key']+'.bin.gz')).read_bytes();body=gzip.decompress(packed)
    assert sha(packed)==b['gzipSha256'] and sha(body)==b['sha256'] and len(body)==b['bytes']
  result['browserClosures'].append(dict(path=str(file.relative_to(OUT/'worker')),sources=len(src),served=len(served),status=r.get('status')))
cold=json.loads((OUT/'worker/cold/report.json').read_text());assert cold['gitHead']==cold['cloneHead']==FROZEN and cold['status']=='passed' and not cold['statusBefore'] and not cold['statusAfter'] and cold['exitCode']==0
assert cold['receiptSha256']==result['receipts'][1]['receiptSha256']
result['cold']=cold
inverse=json.loads((ROOT/'tools/virgl-command/standard-float-image-boundary.json').read_text());assert inverse['predecessor']==BASE
for name,rows in inverse['changes'].items():
 content=original(FROZEN,name).decode()
 for row in reversed(rows):
  assert content.count(row['after'])==1,name
  content=content.replace(row['after'],row['before'],1)
 assert content.encode()==original(BASE,name),name
result['inverse']={'files':len(inverse['changes']),'allExact':True}
result['status']='passed'
(OUT/'authentication.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],archives=[{k:r[k] for k in ['folder','records','unpackedBytes']} for r in result['archives']],receipts=result['receipts'],closures=len(result['browserClosures']),cold='HELD',inverse=result['inverse'])))
