import hashlib,json,subprocess,re
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=Path('/tmp/wasmvm-d25-critic');BASE='6ec464d9b9d1daecd01a0dd5ac58d31ac23910fe'
names=['renderer/virgl-command/resources.mjs','renderer/virgl-command/float-images.mjs']
added={};name=None;line=0
for row in subprocess.check_output(['git','diff','--unified=0',BASE,'18ef4acfdebd30dd9edef9c3a1cca1e1fc4490dc','--',*names],cwd=ROOT,text=True).splitlines():
 if row.startswith('+++ b/'):name=row[6:]
 elif row.startswith('@@'):line=int(re.search(r'\+(\d+)',row)[1])
 elif row.startswith('+'):
  added.setdefault(name,[]).append(line);line+=1
 elif row.startswith(' '):line+=1
scripts=[]
for p in (OUT/'worker').rglob('browser-coverage.json'):
 if '/fault-' in str(p):continue
 for row in json.loads(p.read_text()).get('scripts',[]):
  if row['source'] in names:scripts.append(dict(source=row['source'],record=str(p.relative_to(OUT/'worker')),functions=row['coverage']['functions'],sha256=row['sha256']))
for p in (OUT/'worker').rglob('coverage-*.json'):
 for row in json.loads(p.read_text()).get('result',[]):
  for name in names:
   if row['url'].endswith('/'+name):scripts.append(dict(source=name,record=str(p.relative_to(OUT/'worker')),functions=row['functions'],sha256=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()))
segments=[];misses=[]
for name,lines in added.items():
 source=(ROOT/name).read_text();chunks=source.splitlines(keepends=True);starts=[];at=0
 for chunk in chunks:starts.append(at);at+=len(chunk.encode('utf-16-le'))//2
 group=[r for r in scripts if r['source']==name]
 for line in lines:
  start=starts[line-1];end=start+len(chunks[line-1].encode('utf-16-le'))//2
  cuts={start,end}
  for script in group:
   for fn in script['functions']:
    for region in fn['ranges']:
     for bound in [region['startOffset'],region['endOffset']]:
      if start<bound<end:cuts.add(bound)
  cuts=sorted(cuts)
  for begin,finish in zip(cuts,cuts[1:]):
   piece=source.encode('utf-16-le')[begin*2:finish*2].decode('utf-16-le');obs=[]
   for script in group:
    ranges=[dict(function=fn['functionName'],**r) for fn in script['functions'] for r in fn['ranges'] if r['startOffset']<=begin and finish<=r['endOffset']]
    if ranges:
     smallest=min(ranges,key=lambda r:r['endOffset']-r['startOffset']);obs.append(dict(record=script['record'],sha256=script['sha256'],**smallest))
   count=max([r['count'] for r in obs],default=0)
   item=dict(source=name,line=line,start=begin,end=finish,text=piece,maxCount=count,counters=obs)
   segments.append(item)
   if count==0 and piece.strip():misses.append(item)
result=dict(schema='independent-nested-float-coverage-v1',sourceHead='18ef4acfdebd30dd9edef9c3a1cca1e1fc4490dc',scripts=len(scripts),addedLines=sum(map(len,added.values())),regions=len(segments),zeroNonblank=len(misses),segments=segments)
(OUT/'nested-coverage.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['scripts','addedLines','regions','zeroNonblank']}))
for i,r in enumerate(misses):print(i,r['source'],r['line'],r['start'],r['end'],repr(r['text']))
