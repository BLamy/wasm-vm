from pathlib import Path
import hashlib,json,re,subprocess,sys
head=sys.argv[1];stage=Path(sys.argv[2]).resolve();sha=lambda b:hashlib.sha256(b).hexdigest()
pub=json.loads((stage/'publish.json').read_bytes());assert pub['head']==head and pub['exitCode']==0
urls=re.findall(r'https://([0-9a-f-]+)\.wasm-vm\.pages\.dev',(stage/'publish.stdout').read_text());assert urls
command=['npx','--yes','wrangler@4.149.0','pages','deployment','list','--project-name','wasm-vm']
r=subprocess.run(command,capture_output=True,timeout=180)
for name in ['stdout','stderr']:(stage/('deployment-list.'+name)).write_bytes(getattr(r,name))
assert r.returncode==0
rows=[]
for line in r.stdout.decode().splitlines():
 cols=[p.strip() for p in line.split('│')[1:-1]]
 if len(cols)==7 and re.fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',cols[0]) and cols[3]==head[:7] and any(cols[0].startswith(url) for url in urls):rows.append(cols)
assert len(rows)==1,rows
row=rows[0];assert row[1]=='Production' and row[2]=='main'
v=dict(source='actual wrangler@4.149.0 deployment list and publication receipt',command=command,id=row[0],url=row[4],environment=row[1],branch=row[2],observedCommitPrefix=row[3],head=head,listSha256=sha(r.stdout),publishReceiptSha256=sha((stage/'publish.json').read_bytes()))
(stage/'cloudflare-cli-confirmation.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
