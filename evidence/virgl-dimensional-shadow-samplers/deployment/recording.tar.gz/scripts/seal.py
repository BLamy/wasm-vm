from pathlib import Path
import gzip,hashlib,io,json,tarfile
repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
stage=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm/target/evidence/d62-continuation-tools/pages-d853f096');live=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm/target/evidence/d62-continuation-tools/live-d853f096');head='d853f096b3858ef390ad42b6cac33838778d849b'
sha=lambda b:hashlib.sha256(b).hexdigest()
index=json.loads((stage/'staging-index.json').read_bytes());report=json.loads((live/'report.json').read_bytes());deployment=json.loads((stage/'cloudflare-cli-confirmation.json').read_bytes())
assert report['gitHead']==index['head']==deployment['head']==head and report['status']=='passed'
assert sha((stage/'staging-index.json').read_bytes())=='bee1130ed7faf1506baa6c69cf636f36327a0a02cd9376e8fef7820b8386b399'
assert report['passed']==127 and report['failed']==0 and report['errors']==[]
assert deployment['observedCommitPrefix']==head[:7] and deployment['environment']=='Production'
assert sha((stage/'deployment-list.stdout').read_bytes())==deployment['listSha256']
assert sha((stage/'publish.json').read_bytes())==deployment['publishReceiptSha256'] and json.loads((stage/'publish.json').read_bytes())['exitCode']==0
assert 'partial' in report['graphicsRoadmapPip'] and report['proofExportAbsent'] is True
for row in index['records']:
 body=(stage/'web/dist'/row['path']).read_bytes();assert sha(body)==row['sha256'] and len(body)==row['bytes']
for row in report['served']:
 body=(live/'bodies'/row['path'].lstrip('/')).read_bytes();assert sha(body)==row['sha256'] and len(body)==row['bytes']
files={'publication/'+p.relative_to(stage).as_posix():p for p in stage.rglob('*') if p.is_file()}
files.update({'live/'+p.relative_to(live).as_posix():p for p in live.rglob('*') if p.is_file()})
files['scripts/publish.py']=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm/target/evidence/d62-continuation-tools/publish.py')
files['scripts/confirm-deployment.py']=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm/target/evidence/d62-continuation-tools/confirm-deployment.py')
files.update({'scripts/live.mjs':Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm/target/evidence/d62-continuation-tools/live-d853f096.mjs'),'scripts/seal.py':Path(__file__)})
rows=[dict(path=n,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for n,p in sorted(files.items())]
out=repo/'evidence/virgl-dimensional-shadow-samplers/deployment';assert not out.exists();out.mkdir(parents=True)
raw=(json.dumps(dict(schema='dimensional-shadow-sampler-deployment-index-v1',head=head,records=rows),indent=2)+'\n').encode();(out/'records.json').write_bytes(raw)
archive=out/'recording.tar.gz'
with archive.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
 for row in rows:
  body=files[row['path']].read_bytes();info=tarfile.TarInfo(row['path']);info.size,info.mode,info.mtime=len(body),0o644,0;tar.addfile(info,io.BytesIO(body))
count=0
with gzip.open(archive,'rb') as decoded:
 with tarfile.open(fileobj=decoded,mode='r|') as tar:
  for member in tar:
   row=rows[count];count+=1;assert member.name==row['path'];body=tar.extractfile(member).read();assert len(body)==row['bytes'] and sha(body)==row['sha256']
 while decoded.read(1024*1024):pass
assert count==len(rows)
manifest=dict(schema='dimensional-shadow-sampler-deployment-seal-v1',task='E6-T11d62',head=head,records=len(rows),reopenedMembers=count,gzipEofChecked=True,recordIndexSha256=sha(raw),archiveSha256=sha(archive.read_bytes()),archiveBytes=archive.stat().st_size,deploymentId=deployment['id'],url=deployment['url'],canonical='https://wasm-vm.pages.dev',passed=127,failed=0,productionGraphicsAuthority=False)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest));print('manifestSha256',sha((out/'manifest.json').read_bytes()))
