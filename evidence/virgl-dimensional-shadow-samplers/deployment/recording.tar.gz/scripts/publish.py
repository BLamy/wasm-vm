from pathlib import Path
import datetime,hashlib,json,subprocess,sys
repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');head=sys.argv[1];cold=Path(sys.argv[2]).resolve();stage=Path(sys.argv[3]).resolve();sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=repo,text=True).strip()
r=json.loads((cold/'report.json').read_bytes());receipt=json.loads((cold/'recording/receipt.json').read_bytes())
assert r['head']==receipt['head']==head and r['exitCode']==0 and not r['cleanAfter']
assert all(row['exitCode']==row['expected'] for row in receipt['commands'])
assert receipt['coverage']['newExecutableGaps']==0 and receipt['physical']['completedPhysicalRefutations']==2
index=json.loads((stage/'staging-index.json').read_bytes());assert index['head']==head and index['fileCount']==304
for row in index['records']:
 b=(stage/'web/dist'/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
assert not (stage/'publish.json').exists()
command=['npx','--yes','wrangler@4.149.0','pages','deploy',str(stage/'web/dist'),'--project-name','wasm-vm','--branch','main','--commit-hash',head,'--commit-dirty=true']
start=datetime.datetime.now(datetime.timezone.utc).isoformat();result=subprocess.run(command,cwd=repo,capture_output=True,timeout=600)
for name in ['stdout','stderr']:(stage/('publish.'+name)).write_bytes(getattr(result,name))
metadata=dict(command=command,head=head,startedAt=start,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitCode=result.returncode,stdoutSha256=sha(result.stdout),stderrSha256=sha(result.stderr))
(stage/'publish.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(result.stdout.decode(errors='replace'));print(result.stderr.decode(errors='replace'));assert result.returncode==0
