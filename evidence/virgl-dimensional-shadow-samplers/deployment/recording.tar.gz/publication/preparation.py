from pathlib import Path,PurePosixPath
import hashlib,io,json,shutil,subprocess,sys,tarfile
repo=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');head=sys.argv[1];out=Path(sys.argv[2]).resolve()
old=Path(__file__).resolve().parent/'held-d61-deployment/publication';sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=repo,text=True).strip()
rawIndex=(old/'staging-index.json').read_bytes();assert sha(rawIndex)=='06404b6ebaec8c7a965b2c155234eb5d6e957276d3140eab68e69615948333f1'
previous=json.loads(rawIndex);assert previous['fileCount']==304
for row in previous['records']:
 b=(old/'web/dist'/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
assert not out.exists();out.mkdir();shutil.copytree(old/'web/dist',out/'web/dist')
raw=subprocess.check_output(['git','archive',head,'web/dist'],cwd=repo);(out/'frozen-web-dist.tar').write_bytes(raw);source={}
with tarfile.open(fileobj=io.BytesIO(raw)) as packed:
 for entry in packed:
  path=PurePosixPath(entry.name);assert path.parts[0]=='web' and '..' not in path.parts
  if not entry.isfile():continue
  assert path.parts[:2]==('web','dist') and len(path.parts)>2
  name='/'.join(path.parts[2:]);body=packed.extractfile(entry).read();source[name]=body
  file=out/'web/dist'/name;file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(body)
for row in previous['carriedBootManifests']:
 name=row['path'];assert sha(source[name])==row['sourceSha256'];shutil.copyfile(old/'web/dist'/name,out/'web/dist'/name)
records=[]
for p in sorted((out/'web/dist').rglob('*')):
 if p.is_file():
  b=p.read_bytes();assert len(b)<25*1024*1024;records.append(dict(path=p.relative_to(out/'web/dist').as_posix(),bytes=len(b),sha256=sha(b)))
prior={row['path']:row for row in previous['records']};assert len(records)==304 and set(prior)=={row['path'] for row in records}
changes=[row['path'] for row in records if row!=prior[row['path']]];assert set(changes)=={'roadmap.js','sw.js'}
index=dict(head=head,sourceArchiveSha256=sha(raw),heldDeployment=previous['head'],heldIndexSha256=sha(rawIndex),heldDeploymentManifestSha256='02252e62162ee1eefcc5a56cf854123e4a5c99b37aa62a63899682676c5362b6',completeHeldDeploymentMembersReopened=511,gzipEofChecked=True,carriedBootManifests=previous['carriedBootManifests'],records=records,fileCount=304,bytes=sum(row['bytes'] for row in records),codeChanges=changes)
(out/'staging-index.json').write_text(json.dumps(index,indent=2)+'\n');shutil.copyfile(__file__,out/'preparation.py')
print(json.dumps(dict(status='prepared-only',head=head,files=304,changes=changes,indexSha256=sha((out/'staging-index.json').read_bytes()))))
