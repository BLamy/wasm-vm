#!/usr/bin/env python3
"""Independent seed over the full healthy and actual source-fault schedules."""
import json
import os
from pathlib import Path
import subprocess

root = Path.cwd()
out = root / 'target/evidence/virgl-raster-bank-verifier'
seed = 0x4a57de19
reference = subprocess.check_output(['node', 'tools/virgl-raster-bank/reference.mjs', str(seed)], cwd=root)
(out / 'independent-reference.json').write_bytes(reference)
commands = []
for mode in [None, 'drop-component', 'missing-guard', 'unapproved-decode']:
    name = 'independent-gpu' if mode is None else 'independent-fault-' + mode
    command = ['node', 'tools/virgl-raster-bank/browser.mjs', '--output', str(out / name), '--seed', str(seed)]
    if mode is not None:
        command += ['--fault', mode, '--fault-artifacts', str(root / 'target/evidence/virgl-raster-bank-worker-4999a81a/faults')]
    with (out / (name + '.log')).open('wb') as log:
        run = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT, timeout=300)
    report = json.loads((out / name / 'report.json').read_bytes())
    assert run.returncode == (0 if mode is None else 1), (name, run.returncode)
    assert report['status'] == ('passed' if mode is None else 'failed')
    commands.append({'mode': mode, 'command': command, 'exitCode': run.returncode,
                     'report': name + '/report.json', 'gitHead': report['gitHead'],
                     'failure': report['acceptance'].get('failure')})
    (out / 'independent-browser-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    print(name + ' completed', flush=True)
print('Independent hardware and all actual source faults completed', flush=True)
