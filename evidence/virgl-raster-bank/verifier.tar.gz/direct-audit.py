#!/usr/bin/env python3
"""Separate equations over full GPU records; no worker oracle or GLSL interpreter."""
import hashlib
import json
import math
from pathlib import Path
import re
import struct

root = Path.cwd()
out = root / 'target/evidence/virgl-raster-bank-verifier'
worker = root / 'target/evidence/virgl-raster-bank-worker-4999a81a'
cold = root / 'target/evidence/virgl-raster-bank-cold-4999a81a/acceptance'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
number = lambda word: struct.unpack('<f', struct.pack('<I', word))[0]
round_f32 = lambda value: struct.unpack('<f', struct.pack('<f', value))[0]
channel = lambda value: max(0, min(255, math.floor(value * 255 + .5)))
native = json.loads((worker / 'native/native-report.json').read_bytes())
certificate_checks = []
for entry in native['cases']:
    match = re.fullmatch(r'copy-([xyzw]+)-(direct|alias|branch|select|max)-(vertex|fragment)', entry['name'])
    if not match:
        continue
    mask, variant, stage = match.groups()
    live = ['xyzw'.index(c) for c in mask]
    reverse = sum(1 << (3 - lane) for lane in live)
    if variant == 'direct':
        demands = [(0, reverse)]
    elif variant == 'alias':
        selected = [0, 1, 2, 3]
        for lane in live:
            selected[lane] = [0, 2, 1, 3][lane]
        demands = [(0, sum(1 << lane for lane in set(selected)))]
    elif variant == 'branch':
        demands = [(0, 15), (1, reverse)]
    else:
        demands = [(0, reverse), (1, sum(1 << lane for lane in live))]
    observed = entry['result']['metadata']['constantRasterDomains'][0]['components']
    expected = [{'register': register, 'mask': mask} for register, mask in demands]
    assert observed == expected, entry['name']
    certificate_checks.append({'case': entry['name'], 'expected': expected, 'observed': observed})
assert len(certificate_checks) == 150

def predict(draw):
    kernel, vector = draw['kernel'], draw['vector']
    if kernel['kind'] == 'original':
        color = vector['color']
        # Every original table entry has this same literal color. The actual
        # root is .5, exactly the lower breakpoint; weight-zero UCMP copies alpha.
        start = 18 if kernel['form'] == 'nested' else 28
        stop = 26 if kernel['form'] == 'nested' else 46
        for register in range(start, stop):
            assert draw['bank'][register * 4:(register + 1) * 4] == color
        assert draw['bank'][40] == 0x3f000000 and draw['bank'][44] == 0x3f800000
        if kernel['form'] == 'loop':
            assert draw['bank'][36] == vector['count'] == 2
        values = [round_f32(number(word) * number(color[3])) for word in color[:3]] + [number(color[3])]
        return None, [channel(value) for value in values]
    a, b, variant = vector['a'], vector['b'], kernel['variant']
    assert draw['bank'][:4] == a and draw['bank'][4:8] == b and draw['bank'][20] == vector['selector']
    selected = ['xyzw'.index(c) for c in kernel['mask']]
    result = list(a) if variant in ('alias', 'branch') else [0x3f000000] * 4
    if variant == 'alias':
        for lane in selected:
            result[lane] = a[[0, 2, 1, 3][lane]]
    elif variant == 'branch':
        if vector['selector']:
            for lane in selected:
                result[lane] = b[3 - lane]
    else:
        for lane in selected:
            left, right = a[3 - lane], b[lane]
            result[lane] = left if variant == 'direct' or (variant == 'select' and vector['selector']) or (variant == 'max' and number(left) > number(right)) else right
    assert all(math.isfinite(number(w)) and (number(w) == 0 or abs(number(w)) >= 2 ** -126) for w in result)
    return result, [channel(number(w)) for w in result]

reports = []
for base in (worker, cold):
    for suffix in ('', '-2872938129', '-967105429'):
        reports.append(base / ('gpu' + suffix) / 'report.json')
reports.append(out / 'independent-gpu/report.json')
physical = []
for filename in reports:
    raw = filename.read_bytes()
    envelope = json.loads(raw)
    acceptance = envelope['acceptance']
    draw_count = pixel_count = word_count = uniform_count = fence_count = async_count = 0
    generation_points = []
    for rig_index, rig in enumerate(acceptance['rigs']):
        assert not rig['oracleStops']
        assert all(value == 0 for value in rig['finalBudgets'].values())
        assert all(value == 0 for value in rig['finalResourceBudgets'].values())
        assert rig['glObjects']['live'] == 0
        fences = {}
        for event in rig['glEvents']:
            call = event['call']
            if call == 'uniform4uiv':
                assert event['words'] == event['observed']
                uniform_count += 1
            if call == 'fenceSync':
                assert event['id'] not in fences
                fences[event['id']] = {'turn': event['turn'], 'lastPoll': event['turn'], 'signaled': False}
                fence_count += 1
            elif call == 'clientWaitSync':
                fence = fences[event['id']]
                assert event['turn'] > fence['lastPoll']
                fence['lastPoll'] = event['turn']
                assert event['actual'] in (37146, 37147, 37148)
                assert event['delivered'] in (37146, 37147, 37148)
                if event['delivered'] in (37146, 37148):
                    assert event['actual'] in (37146, 37148)
                    fence['signaled'] = True
            elif call == 'deleteSync':
                assert fences[event['id']]['signaled']
                del fences[event['id']]
        assert not fences
        for draw_index, draw in enumerate(rig['draws']):
            words, color = predict(draw)
            pixels = draw['rgbaBytes']
            assert sha(bytes(pixels)) == draw['rgbaSha256']
            for y in range(64):
                for x in range(64):
                    expected = ([((word >> (x // 2)) & 1) * 255 for word in words] if y < 2 else [0, 0, 255, 255]) if rig['kernel']['stage'] == 'vertex' else color
                    assert pixels[(y * 64 + x) * 4:(y * 64 + x + 1) * 4] == expected
            if rig['kernel']['stage'] == 'vertex':
                recovered = [sum((pixels[x * 8 + lane] // 255) << x for x in range(32)) for lane in range(4)]
                assert recovered == words == draw['words']
                word_count += 4
            else:
                assert draw['words'] is None
            for uniform in draw['uniforms']:
                assert uniform['words'] == draw['bank'][:uniform['activeCount'] * 4]
            for stage in ('vertex', 'fragment'):
                assert draw['draw'][stage + 'Shader'] == draw['bindings'][stage + 'Shader']
                assert draw['program'][stage + 'Generation'] == draw['bindings'][stage + 'Shader']['generation']
            generation_points.append({'rig': rig_index, 'draw': draw_index, 'label': draw['label'],
                                      'vertex': draw['draw']['vertexShader'], 'fragment': draw['draw']['fragmentShader'],
                                      'bankSha256': sha(struct.pack('<' + str(len(draw['bank'])) + 'I', *draw['bank'])),
                                      'pixelSha256': draw['rgbaSha256']})
            draw_count += 1
            pixel_count += 4096
        if rig['asynchronous']:
            async_count += 1
            for attack in rig['yieldAttacks']:
                assert attack['before'] == attack['after']
                assert attack['before']['jobs']['status'] == 'waiting-index'
                assert [a['name'] for a in attack['attempts']] == ['replace', 'restore', 'destroy']
                assert all(a['result']['ok'] is False and a['result']['error']['code'] == 'busy' for a in attack['attempts'])
    assert (draw_count, word_count, pixel_count, async_count) == (192, 400, 786432, 6)
    assert envelope['browserErrors'] == {'console': [], 'page': [], 'requests': []}
    physical.append({'report': str(filename.relative_to(root)), 'sha256': sha(raw), 'draws': draw_count,
                     'words': word_count, 'pixels': pixel_count, 'uniformReadbacks': uniform_count,
                     'realFences': fence_count, 'asyncRigs': async_count, 'generationPoints': generation_points})
result = {'status': 'passed', 'boundary': 'Separate literal lane equations and premultiplied-color equations; no worker interpreter or GLSL used.',
          'certificateChecks': certificate_checks, 'physical': physical}
(out / 'direct-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'certificates': len(certificate_checks), 'physicalReports': len(physical),
                  'draws': sum(r['draws'] for r in physical), 'words': sum(r['words'] for r in physical),
                  'pixels': sum(r['pixels'] for r in physical), 'fences': sum(r['realFences'] for r in physical)}))
