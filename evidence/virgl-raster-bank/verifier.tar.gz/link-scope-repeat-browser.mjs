import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {browserDocument, runVirglBrowser} from '../../../tools/lib/virgl-browser-runner.mjs';
const source='target/evidence/virgl-raster-bank-verifier/link-scope-test.mjs';
const runtime=fs.readdirSync('renderer/virgl-command').filter(x=>x.endsWith('.mjs')).map(x=>'renderer/virgl-command/'+x);
runtime.push(source,'renderer/virgl-command/tests/raster-bank.mjs','tools/virgl-raster-bank/oracle.mjs','tools/virgl-radial-domain/oracle.mjs','renderer/virgl-shader/tests/raster-bank-cases.json','renderer/virgl-shader/tests/precise-word-cases.json');
const pinnedFiles=runtime.map(path=>{const raw=fs.readFileSync(path);return {path,size:raw.length,sha256:createHash('sha256').update(raw).digest('hex')};});
await runVirglBrowser({options:{output:'target/evidence/virgl-raster-bank-verifier/link-scope-repeat-gpu'},
 task:'E6-T12f4b-link-scope', serializedAcceptance:true, boundary:'Read-only adversarial scope probe: explicit linking with invalid CPU bank',
 reportFields:{currentGuest3dAdvertisement:false}, modulePath:'/'+source, windowReportKey:'__virglRasterBankReport',
 browserArguments:{seed:0x4cbd1987}, servedFiles:runtime, pinnedFiles,
 coveragePaths:[source,'renderer/virgl-command/state.mjs','renderer/virgl-command/constant-domain.mjs'],
 html:browserDocument({title:'Raster bank link scope',heading:'Explicit link scope probe',description:'Actual link effects, skipped uploads and rejected unsafe draw'}),
 validate(r){assert.equal(r.status,'passed');assert.equal(r.rigs.length,1);assert.equal(r.rigs[0].linkScope.explicit.ok,true);assert.equal(r.rigs[0].attacks[0].result.ok,false);},
 successMessage:()=> 'Actual explicit-link/invalid-bank behavior recorded.'});
