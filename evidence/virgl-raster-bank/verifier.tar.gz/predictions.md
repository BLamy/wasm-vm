# Predictions made before inspecting recorded evidence

## P1 — Identity and losslessness

Every archive member and live recorded file must match its manifest byte count/SHA-256; runtime and harness source must match frozen 4999a81a, actual native and Wasm artifacts must bind transcripts, and cold must report the same clean frozen head.

## P2 — Bounded compiler certificate

Every admitted copy must have v27, an existing finite base, sorted complete register/lane demands obtained from literal inputs, and exact mandatory finite/indirect/count/radial/PRECISE records. Removed, duplicated, malformed or downgraded records must fail closed.

## P3 — Exact raster domain

Both zero signs and every finite normal boundary must be accepted; copied positive/negative subnormals, infinities and NaNs must be rejected before link/upload/draw effects. An uncopied subnormal may stay exact private bank data. Every demanded component must independently reject word 1.

## P4 — Internal words and physical pixels

Native/Wasm full results must agree. Hardware uploads must read back exact uint32 bank words; vertex bit-carrier pixels must reconstruct all four copied words and every fragment pixel must match independent literal computation. Wrong allowed-word decode must produce an actual pixel mismatch.

## P5 — One immutable generation

Replacing an approved bank with a copied subnormal must preserve exact CPU words, skip restoration uploads and reject draw with unchanged owned state/full framebuffer. Async waiting-index replacement/restoration/destruction must return busy without changing shader/context/program/bank generations.

## P6 — Retained originals and obligations

All 19 original shader hashes/bodies must remain unchanged; exactly four prior gradient rejections migrate to v27, giving 18/19 admissions. Count-as-output must reject; all simultaneous finite, indirect, count, radial and PRECISE obligations must remain mandatory. All complete unrelated parent results must remain identical.

## P7 — Allocation and resource caps

The actual 16,516-byte analysis allocation must fail transactionally and recover; every raster allocation site and real upstream allocation failure must have full failed results. Wasm must exhaust the real fixed 16 MiB heap then recover. Native IR/profile/flow and GLSL bounds stay within stated caps; every GPU/resource budget returns to zero.

## P8 — Real sabotages and before-effect witnesses

Exact one-line component omission and guard removal must admit a disallowed copied word and reach the independent domain oracle before calling native GPU; unsafeGpuCalled must be false and blocked attempts must be distinct from actual uniform uploads. All modified compiler/module artifacts must match recorded served hashes.

## P9 — Sufficiency

LLVM and V8 counters must exercise each changed runtime hunk. Unexecuted safety defenses must receive a bounded concrete attack or a reasoned unreachable defense waiver; declarations, metadata, docs and recording-only code get explicit waivers or direct results.

## P10 — Independent bounded attack and test sensitivity

A fresh independent nested-branch plus masked alias copy must demand the union of both reaching literal bank predecessors, only live lanes, and both selection payloads. Invalidating each required component must reject while private raw selector/count words remain exact. Promoted test must fail when the actual copy predicate is removed.
