#!/usr/bin/env python3
"""Fresh verifier replays full records without rewriting worker receipts."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

p = argparse.ArgumentParser()
p.add_argument('--root', required=True, type=Path)
p.add_argument('--recording', required=True, type=Path)
p.add_argument('--output', required=True, type=Path)
a = p.parse_args()
root, recording = a.root.resolve(), a.recording.resolve()
sys.path.insert(0, str(root / 'tools/virgl-raster-bank'))
import native_receipt
import wasm_receipt
import receipt

head = '4999a81ad93496fc25e78cbb0aeb7adec66006e3'
native = native_receipt.verify(recording / 'native', head)
wasm = wasm_receipt.verify(recording / 'wasm', head, native)
hardware = {}
for suffix, seed in [('', 0x31db9275), ('-2872938129', 2872938129), ('-967105429', 967105429)]:
    raw = subprocess.check_output(['node', 'tools/virgl-raster-bank/reference.mjs', str(seed)], cwd=root)
    fresh = json.loads(raw)
    reference = json.loads((recording / ('reference' + suffix + '.json')).read_bytes())
    assert receipt.same(reference, fresh)
    hardware[str(seed)] = receipt.physical(recording / ('gpu' + suffix), head, native, fresh)
consumer = json.loads((recording / 'consumer.json').read_bytes())
fresh = json.loads(subprocess.check_output(['node', 'tools/virgl-raster-bank/consumer.mjs'], cwd=root))
assert receipt.same(consumer, fresh)
faults = json.loads((recording / 'faults/manifest.json').read_bytes())
fault_results = {}
reference = json.loads((recording / 'reference.json').read_bytes())
for mode, fault in faults['modes'].items():
    receipt.source(fault['original'], head)
    original = (root / fault['original']['path']).read_text()
    assert original.count(fault['before']) == 1
    assert (recording / 'faults' / fault['fault']['path']).read_text() == original.replace(fault['before'], fault['after'])
    for adaptation in fault['adaptations']:
        receipt.source(adaptation['original'], head)
        text = (root / adaptation['original']['path']).read_text()
        for old, new in adaptation['edits']:
            assert text.count(old) == 1
            text = text.replace(old, new)
        assert (recording / 'faults' / adaptation['fault']['path']).read_text() == text
    for key in ('fault', 'wasm', 'buildLog', 'browserReport'):
        if key in fault:
            assert receipt.same(receipt.binding(recording / 'faults' / fault[key]['path'], recording / 'faults'), fault[key])
    fault_results[mode] = receipt.physical(recording / 'faults' / mode / 'gpu', head, native, reference, fault, recording / 'faults')
retained = {}
for label, task in [('mask', 'E6-T12f4a'), ('precise', 'E6-T12f4'), ('equality', 'E6-T12f1'), ('selected', 'E6-T12f2'), ('radial', 'E6-T12f3')]:
    envelope = receipt.envelope(recording / ('retained-' + label), head, task=task)
    retained[label] = {'status': envelope['status'], 'reportSha256': hashlib.sha256((recording / ('retained-' + label) / 'report.json').read_bytes()).hexdigest()}
result = {'status': 'passed', 'sourceRoot': str(root), 'recordingRoot': str(recording), 'frozenHead': head,
          'native': {'stats': native['stats'], 'maxima': native['recordedMaxima'], 'layout': native['layout'], 'flow': native['flow']},
          'wasm': wasm, 'hardware': hardware, 'sourceFaults': fault_results, 'retained': retained,
          'consumer': {key: len(consumer[key]) for key in ('domain', 'contracts', 'banks', 'hostile')}}
a.output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'wasm'}, indent=2))
