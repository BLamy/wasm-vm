#!/usr/bin/env python3
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'evidence/virgl-standard-buffer-roles/verifier';sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
BASE='f489b8ed5599dfe9afeb7d7d1463655e768af418';FROZEN='ed017102fd01137a7f1ff55569e9bc69da149f11';SUBMISSION='dd2ba352e8c0d9f32198b02f552d9f785388ec2d';HEAD=git('rev-parse','HEAD').decode().strip()
assert git('diff','--name-only','HEAD')==b''
selected=['predictions.json','authentication.json','wire-audit.json','recording-audit.json','independent-run-audit.json','transition-audit.json','c-wasm-assembly-audit.json','coverage-regions.json','coverage-waivers.json','fresh-custody.json','diff-classification.json','citations.json','verdict.json','authenticate.py','authenticate_fresh.py','audit_wire.py','audit_records.py','audit_transitions.py','audit_c_pixels.mjs','audit_coverage.py','classify_coverage.py','literal_model.py','physical.mjs','novel-body.mjs','promoted-final.log','c-wasm-assembly-audit.log','coverage-audit.log','fresh-custody.log','seal.py','verify-seal.py']
for name in ['authentication.json','wire-audit.json','recording-audit.json','independent-run-audit.json','transition-audit.json','c-wasm-assembly-audit.json','fresh-custody.json','promoted-final/adversarial-audit.json']:assert json.loads((OUT/name).read_text())['status']=='passed'
coverage=json.loads((OUT/'coverage-regions.json').read_text());assert coverage['status']=='held' and coverage['newRuntimeFragmentsUncovered']==0
verdict=json.loads((OUT/'verdict.json').read_text());assert verdict['promotedExecutionHead']==HEAD and all(p['status']=='HELD' for p in verdict['predictions'])
members={'critic/'+n:(OUT/n).read_bytes() for n in selected};sourceHashes={};sourceSnapshots={}
for name in ['matrix-362436069','matrix-521288629','matrix-733973753','promoted-final']:
 for p in (OUT/name).rglob('*'):
  if p.is_file():members['critic/'+p.relative_to(OUT).as_posix()]=p.read_bytes()
reports=[OUT/('matrix-'+str(s))/'report.json' for s in [362436069,521288629,733973753]]+sorted((OUT/'promoted-final').glob('*/report.json'))
for p in reports:
 report=json.loads(p.read_text());head=report['gitHead'];served={s['path'] for s in report['servedFiles']}
 for s in report['sources']:
  name=s['path']
  if '/build/' in name:raw=(OUT/'unpacked/hot-generated'/name).read_bytes();key='source/generated/'+name
  elif name.startswith('evidence/virgl-standard-buffer-roles/verifier/'):
   raw=(ROOT/name).read_bytes();key='source/untracked/'+name
   if sha(raw)!=s['sha256']:
    assert report['mode']=='matrix' and name.endswith('/novel-body.mjs') and '/'+name not in served;continue
  else:raw=git('show',head+':'+name);key='source/'+head+'/'+name
  assert sha(raw)==s['sha256'] and len(raw)==s['bytes'];assert key not in members or members[key]==raw;members[key]=raw;sourceSnapshots[key]=sha(raw)
for source in ['Makefile','tools/verify-virgl-standard-buffer-roles-adversarial.sh','tools/virgl-command/standard-buffer-role-adversarial-audit.py','tools/virgl-command/standard_buffer_role_literal_model.py']:
 raw=git('show',HEAD+':'+source);key='source/'+HEAD+'/'+source;members[key]=raw;sourceSnapshots[key]=sha(raw)
for source in ['renderer/virgl-command/resources.mjs','renderer/virgl-command/state.mjs']:
 raw=git('show',FROZEN+':'+source);assert (ROOT/source).read_bytes()==raw;sourceHashes[source]=sha(raw);members['source/'+BASE+'/'+source]=git('show',BASE+':'+source)
members['critic/submission-runtime.diff']=git('diff',BASE,SUBMISSION,'--','renderer/virgl-command/resources.mjs','renderer/virgl-command/state.mjs')
members['critic/submission.diff']=git('diff',BASE,SUBMISSION)
members['critic/promotion.diff']=git('diff',SUBMISSION,HEAD)
workerRef={'archive':'evidence/virgl-standard-buffer-roles/worker/recording.tar.gz','archiveSha256':'c785984e6a27fd49a91b9e91b7b160a443e8ea3861d12a486c282a0efda50c8f','indexSha256':'5d73e08e2ca930c1bcdc73ba4547d85b2740094f120cc86265f0ac149a7bc9de','records':16096,'mapping':'Coverage/audit unpacked/X paths reference worker archive member X. authenticate.py reauthenticates every member and materializes this mapping; unchanged D16/D17 archive references are independently authenticated in authentication.json. No worker record is replaced by a critic summary.'}
members['critic/worker-reference.json']=(json.dumps(workerRef,indent=2)+'\n').encode()
index=(json.dumps({'schema':'fresh-d18-critic-records-v1','task':'E6-T11d18','base':BASE,'reviewedSubmission':SUBMISSION,'frozenRuntimeHead':FROZEN,'promotedExecutionHead':HEAD,'worker':workerRef,'records':[dict(path=n,bytes=len(raw),sha256=sha(raw)) for n,raw in sorted(members.items())]},indent=2)+'\n').encode();(OUT/'records.json').write_bytes(index)
buf=io.BytesIO()
with gzip.GzipFile(fileobj=buf,mode='wb',mtime=0) as z:
 with tarfile.open(fileobj=z,mode='w') as t:
  for n,raw in sorted(members.items()):
   info=tarfile.TarInfo(n);info.size=len(raw);info.mtime=0;info.mode=0o644;t.addfile(info,io.BytesIO(raw))
archive=buf.getvalue();(OUT/'recording.tar.gz').write_bytes(archive)
seen=set()
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as t:
 for entry in t:
  assert entry.isfile() and entry.name not in seen and not Path(entry.name).is_absolute() and '..' not in Path(entry.name).parts;seen.add(entry.name);assert t.extractfile(entry).read()==members[entry.name]
assert seen==set(members)
manifest={'schema':'fresh-d18-critic-seal-v1','task':'E6-T11d18','verdict':'verified','base':BASE,'reviewedSubmission':SUBMISSION,'frozenRuntimeHead':FROZEN,'promotedExecutionHead':HEAD,'worker':workerRef,'records':len(members),'archiveBytes':len(archive),'archiveSha256':sha(archive),'recordIndexSha256':sha(index),'predictionSha256':sha((OUT/'predictions.json').read_bytes()),'runtimeSourceHashes':sourceHashes,'sourceSnapshots':sourceSnapshots,'proofs':{'positiveWorkerFrames':502,'positiveIndependentMatrixFrames':753,'positivePromotedFrames':9,'positiveFullPixels':374784,'assemblyFullFrames':205,'uniqueActualCPairs':9,'actualCStages':18,'independentSchedules':54,'postFenceSabotageFramesAudited':6,'newRuntimeAddedLines':30,'newRuntimeFragmentsUncovered':0,'unchangedNestedRegionsSpecificallyWaived':265},'commands':verdict['commands'],'unqualified':verdict['unqualified'],'reopen':'Extract critic/ into evidence/virgl-standard-buffer-roles/verifier with --strip-components=1. Worker archive is a separately authenticated tracked dependency, unpacked by authenticate.py. All cited JSON points and hashes are in sealed original reports or explicitly referenced worker members.'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k not in ['sourceSnapshots','commands']}))
