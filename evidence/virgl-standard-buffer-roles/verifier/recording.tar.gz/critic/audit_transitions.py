#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
OUT=Path(__file__).resolve().parent;rows=[]
for name in ['unpacked/hot/hardware','unpacked/cold/hardware']+['matrix-'+str(s) for s in [362436069,521288629,733973753]]+['promoted-final/gpu-'+str(s) for s in [362436069,521288629,733973753]]:
 d=OUT/name;r=json.loads((d/'report.json').read_text());z=r['browserResult']['result'];faults=[];delays=[]
 for runOrdinal,run in enumerate(z['runs']):
  for eventOrdinal,e in enumerate(run['faultEvents']):faults.append({'run':runOrdinal,'event':eventOrdinal,**e})
  for p in run['privateBuffers']:assert p['deleted']==1 and p['bytes']%4==0
  for owner in ['renderer','resources']:assert all(v==0 for v in run['final'][owner]['budgets'].values())
  assert run['final']['uniformAccess']['pending']==run['final']['uniformAccess']['submitted']==0
  assert all(e['sourceClass']==e['destinationClass']=='other' for e in run['classEvents'])
  if name.startswith('matrix-') or name.startswith('promoted-final'):
   seed=r['seed'];fences=[(i,e) for i,e in enumerate(run['events']) if e['name']=='fenceSync'];coefficient=2246822519 if name.startswith('promoted-final') and runOrdinal==1 else 2654435761
   for ordinal,(eventOrdinal,e) in enumerate(fences):
    polls=[x for x in run['events'] if x['name']=='clientWaitSync' and x['sync']==e['sync']];assert all(x['turn']>e['turn'] for x in polls) and len({x['turn'] for x in polls})==len(polls)
    left=1+(((seed+ordinal if coefficient==2246822519 else seed^ordinal)*coefficient)&0xffffffff)%9
    ready=[x for x in polls if x['actual'] in [37146,37148]]
    if any(x['delivered'] in [37146,37148] for x in ready):assert sum(x['delivered']==37147 for x in ready)==left
    delays.append({'run':runOrdinal,'event':eventOrdinal,'sync':e['sync'],'scheduledReadyDelays':left,'polls':len(polls)})
  for key in ['reads','stagingBytes','normalizedBuffers','normalizedBytes','normalizationScratchBytes','uniformPending','uniformHolds']:assert run['inspection']['jobs'][key]==0
 if not name.startswith('promoted-final'):
  assert len(z['suspensions'])==18 and len(z['rejections'])==18 and len(faults)==5
  expect={'revision':'stale-storage','failed-revision':'stale-storage','cancel':'cancelled','context':'stale-context','lease':'stale-storage','resource-dispose':'stale-context'}
  for n,x in enumerate(z['suspensions']):
   job=x['point']['before']['jobs'];assert job['status']==x['phase'] and job['uniformPending']==2 and job['draws']==0
   if x['action'] in expect:assert x['record']['result']['error']['code']==expect[x['action']] and x['record']['result']['draws']==[]
   else:assert x['action'] in ['unref-reuse','detach','backing'] and x['record']['result']['ok'] and x['record']['result']['gpuComplete'] and len(x['record']['result']['draws'])==1
  for rejection in z['rejections']:
   matching=next(run for run in z['runs'] if any(h['label']==rejection['label'] for h in run['history']));assert all(c['label']!=rejection['label'] for c in matching['calls'])
  assert sorted(x['mode'] for x in faults)==['error','null','private-null','private-upload','wait']
  for x in z['ownership']:
   jobs=x['point']['jobs'];assert jobs['normalizedBuffers']==(3 if x['kind']=='three-private-streams' else 1) and jobs['normalizedBytes']==(36 if x['kind']=='three-private-streams' else 12) and jobs['uniformHolds']==1
 else:
  assert len(z['frames'])==3 and len(z['runs'])==2
  x=z['ownership'][0];assert x['kind']=='retained-split-gpu' and x['oldGeneration']!=x['newGeneration'];j=x['mutation']['jobs'];assert [j[k] for k in ['status','draws','reads','uniformPending','normalizedBytes']]==['waiting-index',0,1,2,0]
  j=x['hold']['jobs'];assert [j[k] for k in ['status','draws','reads','uniformPending','normalizedBuffers','normalizedBytes','uniformHolds']]==['finishing',1,0,0,1,12,1]
  pools=[p for p in x['hold']['resources']['resources'] if p['id']==200];assert len(pools)==2;byGeneration={p['generation']:p for p in pools};assert byGeneration[x['oldGeneration']]['public'] is False and byGeneration[x['newGeneration']]['public'] is True
  for i,g in enumerate([x['oldGeneration'],x['newGeneration']]):
   f=z['frames'][i];draw=f['dump']['draws'][0]['command'];assert draw['indexResourceGeneration']==g and draw['vertexFetches'][0]['resourceGeneration']==g and [u['resourceGeneration'] for u in draw['uniformRanges']]==[g,g];assert draw['uniformRanges'][0]['offset']!=draw['uniformRanges'][1]['offset']
  assert z['frames'][0]['dump']['draws'][0]['command']['indexSize']==[1,2,4][r['seed']%3]
  j=z['ownership'][1]['point']['jobs'];assert [j[k] for k in ['status','draws','normalizedBuffers','normalizedBytes','uniformHolds']]==['finishing',1,1,12,1]
  terminal=z['frames'][2]['history'][-1]['result'];assert terminal['error']['code']=='limit-exceeded' and len(terminal['draws'])==1 and terminal['gpuComplete']
 rows.append({'record':name+'/report.json','reportSha256':hashlib.sha256((d/'report.json').read_bytes()).hexdigest(),'jsonPoints':['/browserResult/result/suspensions','/browserResult/result/ownership','/browserResult/result/runs'],'suspensions':len(z['suspensions']),'nativeFaults':faults,'delayPoints':delays,'terminalBudgetsZero':True})
(OUT/'transition-audit.json').write_text(json.dumps({'schema':'fresh-d18-scoped-transition-and-independent-schedule-audit-v1','status':'passed','runs':rows},indent=2)+'\n');print('Scoped ownership, failure, drain and actual later-task schedules HELD for',len(rows),'runs')
