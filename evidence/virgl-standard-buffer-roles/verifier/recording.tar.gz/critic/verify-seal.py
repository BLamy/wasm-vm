#!/usr/bin/env python3
import hashlib,json,tarfile
from pathlib import Path
OUT=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();manifest=json.loads((OUT/'manifest.json').read_bytes());indexRaw=(OUT/'records.json').read_bytes();index=json.loads(indexRaw);archiveRaw=(OUT/'recording.tar.gz').read_bytes();assert sha(indexRaw)==manifest['recordIndexSha256'] and sha(archiveRaw)==manifest['archiveSha256'];expected={r['path']:r for r in index['records']};assert len(expected)==len(index['records'])==manifest['records'];seen=set()
with tarfile.open(OUT/'recording.tar.gz','r:gz') as tar:
 for entry in tar:
  assert entry.isfile() and entry.name in expected and entry.name not in seen and not Path(entry.name).is_absolute() and '..' not in Path(entry.name).parts;seen.add(entry.name);raw=tar.extractfile(entry).read();row=expected[entry.name];assert entry.size==len(raw)==row['bytes'] and sha(raw)==row['sha256']
assert seen==set(expected);print('Exact critic seal membership and every record hash held:',len(seen),'records',manifest['archiveSha256'])
