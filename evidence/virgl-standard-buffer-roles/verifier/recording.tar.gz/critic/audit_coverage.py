#!/usr/bin/env python3
import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'evidence/virgl-standard-buffer-roles/verifier';E=OUT/'unpacked'
BASE='f489b8ed5599dfe9afeb7d7d1463655e768af418';HEAD='ed017102fd01137a7f1ff55569e9bc69da149f11'
sources=['renderer/virgl-command/resources.mjs','renderer/virgl-command/state.mjs']
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True)
def char_offset(text,n):return len(text[:n].encode('utf-16-le'))//2
result={'schema':'fresh-buffer-role-complete-regions-v1','base':BASE,'head':HEAD,'sources':{},'excludedMutations':[]}
for source in sources:
 text=git('show',HEAD+':'+source); raw=text.encode(); lines=text.splitlines(keepends=True);starts=[0]
 for line in lines: starts.append(starts[-1]+len(line.encode('utf-16-le'))//2)
 def lineno(offset):
  import bisect
  return bisect.bisect_right(starts,offset)
 changed=[];line=0
 for row in git('diff','--unified=0',BASE,HEAD,'--',source).splitlines():
  if row.startswith('@@'):line=int(re.search(r'\+(\d+)',row)[1])
  elif row.startswith('+') and not row.startswith('+++'):
   changed.append({'line':line,'start':starts[line-1],'end':starts[line],'text':lines[line-1].rstrip()});line+=1
  elif row.startswith(' '):line+=1
 scripts=[]
 for file in sorted(E.rglob('browser-coverage.json'))+sorted(OUT.glob('matrix-*/browser-coverage.json'))+sorted(OUT.glob('promoted-final/*/browser-coverage.json')):
  for script in json.loads(file.read_text()).get('scripts',[]):
   if script['source']==source:
    if script['sha256']!=hashlib.sha256(raw).hexdigest():
     report=json.loads((file.parent/'report.json').read_text());mutation=report['mutation']
     assert mutation['path']==source and mutation['servedSha256']==script['sha256']
     assert hashlib.sha256(raw.replace(mutation['needle'].encode(),mutation['replacement'].encode())).hexdigest()==script['sha256']
     result['excludedMutations'].append({'record':file.relative_to(OUT).as_posix(),'source':source,'mutation':mutation});continue
    scripts.append({'record':file.relative_to(OUT).as_posix(),'coverage':script['coverage']})
 for file in sorted(E.rglob('node-coverage/coverage-*.json')):
  for script in json.loads(file.read_text())['result']:
   if script['url'].endswith('/'+source):scripts.append({'record':file.relative_to(OUT).as_posix(),'coverage':script})
 all_ranges=[r for s in scripts for f in s['coverage']['functions'] for r in f['ranges']]
 def effective(script,a,b):
  matches=[r for f in script['coverage']['functions'] for r in f['ranges'] if r['startOffset']<=a and b<=r['endOffset']]
  if not matches:return 0
  length=min(r['endOffset']-r['startOffset'] for r in matches)
  return min(r['count'] for r in matches if r['endOffset']-r['startOffset']==length)
 def partition(a,b):
  points=sorted({a,b}|{max(a,min(b,r[k])) for r in all_ranges for k in ['startOffset','endOffset'] if r['startOffset']<b and a<r['endOffset']})
  output=[]
  for lo,hi in zip(points,points[1:]):
   hits=[{'record':s['record'],'count':effective(s,lo,hi)} for s in scripts];max_count=max((s['count'] for s in hits),default=0)
   fragment=text.encode('utf-16-le')[lo*2:hi*2].decode('utf-16-le')
   output.append({'start':lo,'end':hi,'line':lineno(lo),'maxCount':max_count,'text':fragment,'hits':[r for r in hits if r['count']]})
  return output
 changed_effective=[{**row,'regions':partition(row['start'],row['end'])} for row in changed]
 # Entire nested functions that enclose each changed runtime line, not selected line samples.
 functions={}
 for script in scripts:
  for f in script['coverage']['functions']:
   primary=f['ranges'][0]
   if any(primary['startOffset']<=row['start']<primary['endOffset'] for row in changed) and primary['startOffset']!=0:
    key=(primary['startOffset'],primary['endOffset'])
    functions.setdefault(key,{'name':f['functionName'],'start':key[0],'end':key[1],'line':lineno(key[0])})
 function_rows=[]
 for fn in functions.values():
  regions=partition(fn['start'],fn['end']);fn['regions']=regions;fn['zeroRegions']=[r for r in regions if not r['maxCount'] and r['text'].strip()];function_rows.append(fn)
 result['sources'][source]={'sha256':hashlib.sha256(raw).hexdigest(),'scripts':len(scripts),'changed':changed_effective,'functions':function_rows,'changedZeroRegions':[{'changedLine':row['line'],**region} for row in changed_effective for region in row['regions'] if not region['maxCount'] and region['text'].strip()]}
(OUT/'coverage-regions.json').write_text(json.dumps(result,indent=2)+'\n')
for source,row in result['sources'].items():
 print(source,'scripts',row['scripts'],'changed lines',len(row['changed']),'changed zero regions',json.dumps(row['changedZeroRegions'],indent=2))
 print('complete changed-enclosing functions:')
 for fn in row['functions']:
  print(fn['name'],fn['line'],'zero',len(fn['zeroRegions']))
  for region in fn['zeroRegions']:print(json.dumps({k:v for k,v in region.items() if k!='hits'}))
