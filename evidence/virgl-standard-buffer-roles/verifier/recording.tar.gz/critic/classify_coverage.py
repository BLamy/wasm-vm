#!/usr/bin/env python3
"""One individually cited waiver for each unchanged unexecuted nested region."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'evidence/virgl-standard-buffer-roles/verifier'
cov=json.loads((OUT/'coverage-regions.json').read_text());waivers=[]
for source,info in cov['sources'].items():
 old=subprocess.check_output(['git','show',cov['base']+':'+source],cwd=ROOT,text=True);seen=set()
 for fn in info['functions']:
  for row in fn['zeroRegions']:
   key=row['start'],row['end']
   if key in seen:continue
   seen.add(key);fragment=row['text'];at=old.find(fragment)
   assert at>=0,(source,row['line'],fragment)
   baseLine=old[:at].count('\n')+1;line=row['line'];reason=''
   if source.endswith('resources.mjs'):
    if 88<=line<=98:reason='Unchanged Z16 metadata branch. The new target0/format64 buffer admission cannot select depth textures; this task grants no new depth semantics.'
    elif 313<=line<=319 or 567<=line<=581:reason='Unchanged error aggregation for backend destruction. The buffer-role facet uses the same collect/dispose mechanism; actual private creation/upload/read/fence failures and resource/renderer disposal are exercised separately.'
    elif 335<=line<=346 or 514<=line<=535:reason='Unchanged synchronous readback/transfer path. The selected buffer renderer exposes asynchronous submissions and uses the recorded beginStorageRead/poll/release path.'
    elif 385<=line<=408 or 618<=line<=620:reason='Unchanged inline/staging-copy packet path. No creation hint changes staging admission or these packet layouts; original transfer3d exchanges cover the changed standard-buffer resource path.'
    elif 450<=line<=456:reason='Unchanged hostile backing-segment reflection guard; no new backing format, segment authority or persistent CPU mirror was introduced.'
    elif line==476:reason='Unchanged removeBacking operation. Retained native generations are independent of CPU-only backing changes, exercised by both waiting phases and the physical GPU-copy attack.'
    elif line in [499,501]:reason='Unchanged texture view/depth role predicate, preserved byte-for-byte after the new standard-buffer clause. Standard-buffer vertex/index/uniform branches cannot satisfy the texture/depth kind predicates.'
    elif 589<=line<=600 or 673<=line<=690:reason='Unchanged global scanout capability. The task expressly grants no scanout/deployment authority and this path does not depend on standard-buffer kinds.'
    elif 625<=line<=630 or 650<=line<=655:reason='Unchanged host backing description/transfer-read operation; it introduces no buffer-role selection. Actual selected index read tickets and GPU-origin authority are recorded.'
   else:
    if line<=270:reason='Unchanged legacy profile/configuration/default branch. Old exported factories still call createRenderer with bufferRoles=false; new selected profile and both selected/old standard arms execute, with no guest option or provenance selection.'
    elif 280<=line<=318 or 340<=line<=464:reason='Unchanged lease/cache/object failure or sampler allocation/destruction guard. Selected original role retention, explicit replacement and release run through the new expected-kind arms; this fragment introduces no buffer-role authority.'
    elif 474<=line<=512 or 694<=line<=700 or 990<=line<=1015 or 1100<=line<=1110:reason='Unchanged texture sampling/specialization path. The standard-buffer change does not change texture kinds, sampler state or shader sampling output; no sampler qualification is claimed.'
    elif 526<=line<=901:reason='Unchanged shader/cache/reflection/constant-bank/debug fallback. Actual selected original C/Wasm pairs, native block reflection and bytes execute; this fragment belongs to the preserved prior shader/profile behavior.'
    elif 933<=line<=938 or 1037<=line<=1039 or line in [1087,1283] or 1329<=line<=1336 or 1359<=line<=1366:reason='Unchanged depth/discard branch, separate from native buffer allocation identity. Standard-buffer normalization and fences do not alter this optional depth state.'
    elif line in [951,952]:reason='Unchanged inactive native attribute guard. All active original attributes are checked against literal roles and bytes; pruned shader inputs do not create buffer-role work.'
    elif line==1017 or 1020<=line<=1023 or 1047<=line<=1063:reason='Unchanged raster/point/blend/scissor branch. The changed buffer ownership branch changes no raster state; original-index/vertex-ID/assembly full pixels still execute.'
    elif 1079<=line<=1110 or 1154<=line<=1188 or line in [1218,1278]:reason='Unchanged non-standard/legacy fallback or old normalization ceiling arm. This selected facet always has standard=true and assembly lists; its forced private normalization, real sentinels and byte ceilings execute.'
    elif 1298<=line<=1303 or line==1371 or 1437<=line<=1442 or 1669<=line<=1693 or line==1790:reason='Unchanged synchronous/transfer/unused opcode API branch. The new factory exposes bounded asynchronous jobs; selected draw/read/cancel/drain/disposal paths execute and no synchronous escape is introduced.'
    elif 1316<=line<=1442:reason='Unchanged original state packet guard. Buffer op6/op11/op27 change only expected resource kinds; selected kind branches execute and these preserved resets/range checks introduce no new authority.'
    elif 1453<=line<=1790:reason='Unchanged asynchronous job/debug/provenance branch. Selected read/lease/revision/context/failure/partial-budget/disposal transitions are independently exercised; this fragment changes no native buffer ownership transition.'
   assert reason,(source,line,fragment)
   waivers.append(dict(source=source,line=line,start=row['start'],end=row['end'],fragment=fragment,baseLine=baseLine,baseFragmentSha256=hashlib.sha256(fragment.encode()).hexdigest(),classification='waived',reason=reason))
(OUT/'coverage-waivers.json').write_text(json.dumps({'schema':'fresh-buffer-role-specific-unchanged-region-waivers-v1','base':cov['base'],'head':cov['head'],'waivers':waivers},indent=2)+'\n')
print('Specifically inspected unchanged zero regions:',len(waivers))
