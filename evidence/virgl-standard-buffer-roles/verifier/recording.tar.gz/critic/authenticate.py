#!/usr/bin/env python3
"""Fresh verifier authentication: trust only digested bytes and frozen Git objects."""
import gzip, hashlib, io, json, subprocess, tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT/'evidence/virgl-standard-buffer-roles/verifier'
WORKER = ROOT/'evidence/virgl-standard-buffer-roles/worker'
FROZEN = 'ed017102fd01137a7f1ff55569e9bc69da149f11'
BASE = 'f489b8ed5599dfe9afeb7d7d1463655e768af418'
ARCHIVE = 'c785984e6a27fd49a91b9e91b7b160a443e8ea3861d12a486c282a0efda50c8f'
INDEX = '5d73e08e2ca930c1bcdc73ba4547d85b2740094f120cc86265f0ac149a7bc9de'
sha = lambda b: hashlib.sha256(b).hexdigest()
git = lambda *a: subprocess.check_output(['git',*a],cwd=ROOT)
def need(x, message):
    if not x: raise AssertionError(message)
index_raw = (WORKER/'records.json').read_bytes()
archive_raw = (WORKER/'recording.tar.gz').read_bytes()
need(sha(index_raw)==INDEX,'record index digest')
need(sha(archive_raw)==ARCHIVE,'archive digest')
index = json.loads(index_raw); manifest = json.loads((WORKER/'manifest.json').read_bytes())
need(index['sourceHead']==manifest['sourceHead']==FROZEN,'frozen archive sourceHead')
need(manifest['archiveSha256']==ARCHIVE and manifest['recordIndexSha256']==INDEX,'manifest hashes')
need(manifest['records']==len(index['records'])==16096,'complete record count')
expected = {r['path']:r for r in index['records']}
need(len(expected)==16096,'no duplicate indexed records')
unpacked = OUT/'unpacked'; unpacked.mkdir(exist_ok=True)
seen = set(); total = 0
with tarfile.open(fileobj=io.BytesIO(archive_raw),mode='r:gz') as tar:
    for member in tar:
        need(member.isfile() and member.name in expected and member.name not in seen,'safe unique indexed record '+member.name)
        need(not Path(member.name).is_absolute() and '..' not in Path(member.name).parts,'safe member path')
        data = tar.extractfile(member).read(); row = expected[member.name]
        need(member.size==row['bytes']==len(data) and sha(data)==row['sha256'],'record hash/size '+member.name)
        destination=unpacked/member.name; destination.parent.mkdir(parents=True,exist_ok=True); destination.write_bytes(data)
        total += len(data); seen.add(member.name)
need(seen==set(expected),'exact archive membership')
result={'schema':'fresh-buffer-roles-authentication-v1','status':'running','archiveSha256':ARCHIVE,'indexSha256':INDEX,'records':len(seen),'bytes':total,'runs':[],'receipts':[],'carry':{}}
for prefix in ['hot','cold']:
    receipt=json.loads((unpacked/prefix/'receipt.json').read_bytes())
    need(receipt['status']=='passed' and receipt['gitHead']==FROZEN,'receipt frozen head '+prefix)
    for name,digest in receipt['files'].items():
        need(sha((unpacked/prefix/name).read_bytes())==digest,'receipt record '+prefix+'/'+name)
    for name,digest in receipt['sources'].items():
        need(sha(git('show',FROZEN+':'+name))==digest,'frozen source '+name)
    for name,digest in receipt['generated'].items():
        need(sha((unpacked/(prefix+'-generated')/name).read_bytes())==digest,'generated source '+prefix+'/'+name)
    for name,digest in receipt['carriedVerifiedEvidence'].items():
        data=git('show',BASE+':'+name)
        need(sha(data)==digest and git('show',FROZEN+':'+name)==data,'unchanged predecessor '+name)
        result['carry'][name]=digest
    result['receipts'].append({'prefix':prefix,'gitHead':receipt['gitHead'],'executionHead':receipt['executionHead'],'incrementalHarnessChanges':receipt['incrementalHarnessChanges'],'sources':len(receipt['sources']),'generated':receipt['generated'],'files':len(receipt['files'])})
    for name in ['wire','hardware','fault-source-word','fault-private-index']:
        report=json.loads((unpacked/prefix/name/'report.json').read_bytes()); fault=name.startswith('fault-')
        need(report['gitHead']==receipt['executionHead'],'execution identity '+prefix+'/'+name)
        need(report['status']==('failed' if fault else 'passed'),'terminal status '+prefix+'/'+name)
        need(report['fixedMemory']==dict(bytes=16777216,stageExport='function',pairExport='function',typedPairExport='function',vertexFormatsExport='function',uniformExport='function',uniformPairExport='function'),'fixed memory exports')
        for source in report['sources']:
            if '/build/' in source['path']: data=(unpacked/(prefix+'-generated')/source['path']).read_bytes()
            else: data=git('show',receipt['executionHead']+':'+source['path'])
            need(len(data)==source['bytes'] and sha(data)==source['sha256'],'actual execution source '+source['path'])
        if name=='wire': continue
        need(not report['browser']['headless'],'headed browser')
        need(report['browserErrors']==dict(console=[],page=[],requests=[]),'browser errors')
        need(not any(any(word in a.lower() for word in ['swiftshader','llvmpipe','softpipe','lavapipe']) or a.startswith('--disable-gpu') for a in report['browser']['commandLine']),'physical flags')
        need('Apple M4' in report['browserResult'].get('result',report.get('partial',{}))['gpu']['renderer'] and 'Metal' in report['browserResult'].get('result',report.get('partial',{}))['gpu']['renderer'],'physical M4 Metal')
        served={r['path']:r for r in report['servedFiles']}
        for source in report['sources']:
            if '/'+source['path'] in served:
                need(served['/'+source['path']]['sha256']==source['sha256'],'served source '+source['path'])
        coverage=json.loads((unpacked/prefix/name/report['browserCoverage']['path']).read_bytes())
        for script in coverage['scripts']:
            need(script['sha256']==served['/'+script['source']]['sha256'],'V8 source custody')
        captured=report.get('partial') if fault else report['browserResult']['result']; blob_bytes=0
        for blob in captured['blobs']:
            compressed=(unpacked/prefix/name/blob['path']).read_bytes(); raw=gzip.decompress(compressed)
            need(sha(compressed)==blob['gzipSha256'] and len(raw)==blob['bytes'] and sha(raw)==blob['sha256'],'full native blob custody '+blob['path'])
            blob_bytes+=len(raw)
        for frame in captured['frames']:
            need(frame['history'][-1]['result']['gpuComplete'] and frame['native'],'actual fenced native frame')
        result['runs'].append({'prefix':prefix,'name':name,'gitHead':report['gitHead'],'gpu':captured['gpu'],'blobs':len(captured['blobs']),'blobBytes':blob_bytes,'frames':len(captured['frames']),'suspensions':len(captured['suspensions']),'browser':report['browser']['version'],'coverageScripts':len(coverage['scripts'])})
cold=json.loads((unpacked/'cold/report.json').read_bytes())
need(cold['gitHead']==cold['cloneHead']==FROZEN and cold['status']=='passed' and cold['exitCode']==0,'cold exact-head passed')
need(cold['statusBefore']==cold['statusAfter']=='','pristine start/end')
need(sha((unpacked/'cold/cold.log').read_bytes())==cold['logSha256'],'cold log')
need(sha((unpacked/'cold/receipt.json').read_bytes())==cold['receiptSha256'],'cold receipt')
result['cold']=cold
for key,filename in [('hotReceiptSha256','hot/receipt.json'),('coldReportSha256','cold/report.json'),('coldReceiptSha256','cold/receipt.json')]: need(sha((unpacked/filename).read_bytes())==manifest[key],'sealed receipt '+key)
need(git('diff','--name-only',BASE,FROZEN,'--','renderer/virgl-shader','crates','web','tools/guest')==b'','production/compiler scope unchanged')
result['status']='passed';(OUT/'authentication.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['carry','cold']},indent=2))
