import assert from 'node:assert/strict';
import fs from 'node:fs/promises';import path from 'node:path';import {createHash} from 'node:crypto';import {gunzipSync} from 'node:zlib';import {execFileSync} from 'node:child_process';
import {assemblyModel,comparePixels} from '../../../tools/virgl-command/standard-assembly-oracle.mjs';
import {createVirglStandardUniformShaderBridge} from '../../../renderer/virgl-shader/standard.mjs';
import {default as createModule} from '../../../renderer/virgl-shader/build/wasm/virgl-shader.mjs';
const repo=process.cwd(),out=path.join(repo,'evidence/virgl-standard-buffer-roles/verifier'),frozen='ed017102fd01137a7f1ff55569e9bc69da149f11',base='f489b8ed5599dfe9afeb7d7d1463655e768af418',sha=b=>createHash('sha256').update(b).digest('hex');
const record={schema:'fresh-d18-c-wasm-full-assembly-v1',status:'running',assemblyFrames:[],translations:[],actualStageExports:0};
const wasm=await fs.readFile(path.join(out,'unpacked/hot-generated/renderer/virgl-shader/build/wasm/virgl-shader.wasm')),glue=await fs.readFile(path.join(repo,'renderer/virgl-shader/build/wasm/virgl-shader.mjs'));
assert.equal(sha(wasm),'fc479ec92133f8b75d26043d20fca97d00b1a1556481abf5c5daf23b66e00fca');assert.equal(sha(glue),'0f42245f22cabd36d69d2494056bedd03dd4394c9cf42424ee285f95b00920b0');
for(const source of ['tools/virgl-command/standard-assembly-oracle.mjs','tools/virgl-command/standard-draw-oracle.mjs','renderer/virgl-shader/standard.mjs'])assert.deepEqual(execFileSync('git',['show',frozen+':'+source]),execFileSync('git',['show',base+':'+source]),'unchanged independent assembly/compiler dependency');
const actual=await createModule({wasmBinary:wasm});assert.equal(actual.HEAPU8.byteLength,16777216);for(const name of ['_bridge_translate_standard_uniform','_bridge_translate_standard_uniform_pair'])assert.equal(typeof actual[name],'function');
const bridge=await createVirglStandardUniformShaderBridge({wasmBinary:wasm}),requests=new Map();
const dirs=process.argv.length>2?process.argv.slice(2):['unpacked/hot/hardware','unpacked/cold/hardware'];
for(const name of dirs){const directory=path.join(out,name),report=JSON.parse(await fs.readFile(path.join(directory,'report.json'))),result=report.status==='failed'?report.partial:report.browserResult.result,blobs=new Map(result.blobs.map(row=>[row.key,row]));
 const bytes=async ref=>{const row=blobs.get(ref.key),compressed=await fs.readFile(path.join(directory,row.path)),raw=gunzipSync(compressed);assert.equal(sha(compressed),row.gzipSha256);assert.equal(sha(raw),ref.sha256);assert.equal(raw.length,row.bytes);return raw;};
 for(const run of result.runs)for(const q of run.requests??[]){const key=JSON.stringify(q.request);if(requests.has(key))assert.deepEqual(q.result,requests.get(key).result);else requests.set(key,q);}
 for(const [ordinal,frame] of result.frames.entries())if(frame.assembly){
  const uploads=new Map(),ids=new Map();for(const row of frame.created){uploads.set(row.generation,Buffer.alloc(row.metadata.width*(row.metadata.target===0?1:row.metadata.height*4)));ids.set(row.metadata.id,row.generation);}
  for(const row of frame.inputs){const b=await bytes(row.blob);uploads.get(row.resource.generation).set(b,row.layout.offset);}
  const buffers=new Map([...ids].map(([id,g])=>[id,uploads.get(g)])),model=assemblyModel(frame.history,buffers),pixels=await bytes(frame.pixels),comparison=comparePixels(pixels,model,frame.width,frame.height);
  assert.equal(comparison.held,true);assert.deepEqual(comparison.misses,[]);record.assemblyFrames.push({record:name+'/report.json',jsonPoint:'/browserResult/result/frames/'+ordinal,label:frame.label,pixelSha256:sha(pixels),comparison});
 }
}
for(const [key,{request,result}] of requests){
 const replay=bridge.translatePairUniforms(request);assert.deepEqual(replay,result,'complete C/Wasm pair output and metadata matches capture');record.translations.push({requestSha256:sha(key),resultSha256:sha(JSON.stringify(replay)),ok:replay.ok,bufferZeroMask:request.bufferZeroMask});
 for(const stage of ['vertex','fragment']){const stageResult=bridge.translate({stage,text:request[stage+'Text']});assert.equal(stageResult.ok,true,'actual stage C/Wasm output');record.actualStageExports++;}
}
record.fixedMemoryBytes=actual.HEAPU8.byteLength;record.wasmSha256=sha(wasm);record.glueSha256=sha(glue);record.status='passed';await fs.writeFile(path.join(out,'c-wasm-assembly-audit.json'),JSON.stringify(record,null,2)+'\n');console.log(JSON.stringify({status:record.status,assemblyFrames:record.assemblyFrames.length,pairs:record.translations.length,actualStageExports:record.actualStageExports}));
