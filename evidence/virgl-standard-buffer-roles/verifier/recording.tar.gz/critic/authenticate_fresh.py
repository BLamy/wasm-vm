#!/usr/bin/env python3
import gzip,hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'evidence/virgl-standard-buffer-roles/verifier';FROZEN='ed017102fd01137a7f1ff55569e9bc69da149f11';sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[]
for directory in [OUT/('matrix-'+str(s)) for s in [362436069,521288629,733973753]]+sorted((OUT/'promoted-final').glob('gpu-*'))+sorted((OUT/'promoted-final').glob('sabotage-*')):
 r=json.loads((directory/'report.json').read_bytes());fault=bool(r.get('fault'));expected='failed' if fault else 'passed';assert r['status']==expected and r['browserErrors']==dict(console=[],page=[],requests=[])
 capture=r.get('partial') if fault else r['browserResult']['result'];assert 'Apple M4' in capture['gpu']['renderer'] and 'Metal' in capture['gpu']['renderer'] and not r['browser']['headless'];assert not any(re.search('swiftshader|llvmpipe|softpipe|lavapipe|--disable-gpu',a,re.I) for a in r['browser']['commandLine'])
 assert r['fixedMemory']==dict(bytes=16777216,stageExport='function',pairExport='function',typedPairExport='function',vertexFormatsExport='function',uniformExport='function',uniformPairExport='function')
 served={s['path']:s for s in r['servedFiles']};sources={s['path']:s for s in r['sources']};variants={s['path']:s for s in r['mutations']};waived=[]
 for source in r['sources']:
  name=source['path']
  if '/build/' in name:original=(OUT/'unpacked/hot-generated'/name).read_bytes()
  elif name.startswith('evidence/virgl-standard-buffer-roles/verifier/'):
   original=(ROOT/name).read_bytes()
   if sha(original)!=source['sha256']:
    assert r['mode']=='matrix' and name.endswith('/novel-body.mjs') and '/'+name not in served
    waived.append({'path':name,'reason':'Unserved and unexecuted novel body inventory is irrelevant to the matrix closure; complete actual served matrix variant is captured and authenticated.'});continue
  else:original=subprocess.check_output(['git','show',r['gitHead']+':'+name],cwd=ROOT)
  assert sha(original)==source['sha256'] and len(original)==source['bytes'],name
  if '/'+name in served:
   variant=variants.get(name)
   if variant:
    actual=(directory/variant['variantPath']).read_bytes();assert sha(actual)==variant['servedSha256'] and variant['originalSha256']==source['sha256']
   else:actual=original
   assert sha(actual)==served['/'+name]['sha256'] and len(actual)==served['/'+name]['bytes'],name
  if name in ['renderer/virgl-command/'+s+'.mjs' for s in ['resources','state','decoder','cache','constant-domain']] or name.startswith('renderer/virgl-shader/') and '/build/' not in name:
   assert original==subprocess.check_output(['git','show',FROZEN+':'+name],cwd=ROOT),'runtime source remains frozen'
 for variant in variants.values():assert sha((directory/variant['variantPath']).read_bytes())==variant['servedSha256']
 for key in ['browserCoverage','screenshot']:assert sha((directory/r[key]['path']).read_bytes())==r[key]['sha256']
 for script in json.loads((directory/r['browserCoverage']['path']).read_text())['scripts']:assert script['sha256']==served['/'+script['source']]['sha256']
 for b in capture['blobs']:
  zipped=(directory/b['path']).read_bytes();raw=gzip.decompress(zipped);assert sha(zipped)==b['gzipSha256'] and sha(raw)==b['sha256'] and len(raw)==b['bytes']
 if fault:assert len(capture['frames'])==1 and capture['frames'][0]['history'][-1]['result']['gpuComplete'] and capture['frames'][0]['native'] and 'independent original buffer pixels after completed fence' in r['browserResult']['error']['message']
 rows.append({'path':directory.relative_to(OUT).as_posix(),'reportSha256':sha((directory/'report.json').read_bytes()),'gitHead':r['gitHead'],'seed':r['seed'],'mode':r['mode'],'status':r['status'],'frames':len(capture['frames']),'blobs':len(capture['blobs']),'waivedInventory':waived})
result={'schema':'fresh-d18-physical-custody-v1','runtimeHead':FROZEN,'status':'passed','runs':rows};(OUT/'fresh-custody.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
