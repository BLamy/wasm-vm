#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
OUT=Path(__file__).resolve().parent;rows=[];hints=[0,16,32,48,64,80,96,112]
for prefix in ['hot','cold']:
 p=OUT/'unpacked'/prefix/'wire/report.json';r=json.loads(p.read_text());assert r['status']=='passed' and r['wire']['status']=='passed';w=r['wire'];assert [x['metadata']['bind'] for x in w['records']]==hints+[1,2,8,128,0xffffffff,524288]
 for n,x in enumerate(w['records']):
  b=x['metadata']['bind'];good=b in hints;assert x['layout']['ok']==good and x['legacy']['ok']==(b in [16,32]) and x['uniform']['ok']==(b in [16,32,64,80]);assert x['created']['ok']==(good or b==524288)
  if good:
   resource=x['created']['resource'];assert resource['kind']=='standard-buffer' and resource['bind']==b;assert [row['role'] for row in x['roles']]==['vertex','index','uniform'];assert all(row['generation']==resource['generation'] and row['metadata']['kind']=='standard-buffer' and row['metadata']['bind']==b for row in x['roles'])
   assert x['layout']['layout']==dict(kind='buffer',box=x['fields']['box'],offset=0,rowBytes=64,rowCount=1,rowStride=64,layerStride=64,footprintBytes=64,requiredEnd=64,tightBytes=64,direction='upload')
  else:assert x['roles']==[]
 old=[x['observed'] for x in w['predictions'] if x['prediction']=='prior facet preserves resource admission'];assert old==[b in [16,32] for b in hints]+[b in [16,32,64,80] for b in hints]
 for prediction,value in [('hint getter rejected',False),('hint getter never invoked',0),('guest option cannot select host facet',False),('no renderer mode option escape',False)]:
  matches=[x for x in w['predictions'] if x['prediction']==prediction];assert len(matches)==1 and matches[0]['observed']==value
 rows.append(dict(record=f'{prefix}/wire/report.json',reportSha256=hashlib.sha256(p.read_bytes()).hexdigest(),jsonPoint='/wire/records',hints=hints,oldAdmissions=old,strictPredicates='all held'))
(OUT/'wire-audit.json').write_text(json.dumps(dict(schema='fresh-d18-original-wire-audit-v1',status='passed',runs=rows),indent=2)+'\n');print('Original wire metadata, shared generations, legacy admissions and host-only selectors HELD hot/cold')
