import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';
import {createVirglShaderBridge} from '../../../renderer/virgl-shader/index.mjs';
const out=new URL('.',import.meta.url),wasm=fs.readFileSync(new URL('../../../renderer/virgl-shader/build/wasm/virgl-shader.wasm',import.meta.url));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const sorted=v=>Array.isArray(v)?v.map(sorted):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,sorted(v[k])])):v;
let module;const bridge=await createVirglShaderBridge({wasmBinary:wasm,onRuntimeInitialized(){module=this;}}),memory=module.HEAPU8.buffer;
const records=fs.readFileSync(new URL('current-probe.jsonl',out),'utf8').trim().split('\n').map(x=>JSON.parse(x));
let accepted=0;const parity=[];
for(const record of records){const result=bridge.translate({stage:record.stage,text:record.text});assert.equal(result.ok,record.wanted,record.name);assert.equal(sha(JSON.stringify(sorted(result))),record.resultSha256,'full native/Wasm equality '+record.name);assert.equal(module.HEAPU8.buffer,memory);if(result.ok)accepted++;parity.push({name:record.name,resultSha256:record.resultSha256});}
const summary={status:'passed',calls:records.length,accepted,rejected:records.length-accepted,memoryBytes:memory.byteLength,bufferIdentityStable:module.HEAPU8.buffer===memory,wasmSha256:sha(wasm)};
fs.writeFileSync(new URL('wasm-probe-summary.json',out),JSON.stringify(summary,null,2)+'\n');fs.writeFileSync(new URL('wasm-parity.jsonl',out),parity.map(x=>JSON.stringify(x)).join('\n')+'\n');console.log(summary);
