#!/usr/bin/env python3
"""Fresh verifier: raw source/archive bindings and independent lane equations."""
import hashlib, json, struct, subprocess, sys, tarfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
WORKER = ROOT/'target/evidence/virgl-ordered-masks-worker-2815f3d2'
HEAD = '2815f3d23806aa5b7aaa6a12cef03d5ce54ade90'
sha = lambda b: hashlib.sha256(b).hexdigest()
def require(condition, message):
    if not condition: raise AssertionError(message)
def read(p): return json.loads(p.read_bytes())
def bits(f): return struct.unpack('<I', struct.pack('<f', f))[0]
records=[]
archive=ROOT/'evidence/virgl-ordered-masks/worker.tar.gz'
require(sha(archive.read_bytes())=='bdf9499f20d74e44a1c3f57ff207f2f7e0e5e568e0e81172130809dd7961edad','archive digest')
with tarfile.open(archive) as a:
    for m in a:
        if not m.isfile(): continue
        name=m.name.removeprefix('./');p=WORKER/name
        require(p.is_file() and p.stat().st_size==m.size,'archive member size '+name)
        h=hashlib.sha256();actual=hashlib.sha256()
        with a.extractfile(m) as f,p.open('rb') as g:
            while data:=f.read(1024*1024):
                current=g.read(len(data));require(data==current,'lossless raw member '+name)
                h.update(data);actual.update(current)
            require(not g.read(1),'no omitted archive tail '+name)
        records.append(dict(path=name,bytes=m.size,sha256=h.hexdigest()))
require(len(records)==713,'all submitted archive members')
native=read(WORKER/'native/native-report.json');gpu=read(WORKER/'gpu/report.json')
require(gpu['gitHead']==HEAD and gpu['status']=='passed' and gpu['trackedChanges']==[],'frozen browser source')
require(gpu['browserErrors']==dict(console=[],page=[],requests=[]),'browser error-free')
require(gpu['browser']['launch']['headless'] is False and gpu['browser']['gpu']['featureStatus'][gpu['browser']['webglFeature']]=='enabled','actual hardware launch')
for source in native['sources']:
    p=ROOT/source['path'];raw=p.read_bytes()
    require(len(raw)==source['bytes'] and sha(raw)==source['sha256'],'native source digest '+source['path'])
    require(subprocess.check_output(['git','show',HEAD+':'+source['path']],cwd=ROOT)==raw,'committed native source')
with tarfile.open(ROOT/'evidence/virgl-precise-word/worker.tar.gz') as f:
    held=json.load(f.extractfile('./native/native-report.json'))
labels=['raw','integer','float','numeric','component','dot','constant','structured','indirect','loop','equality','selected','radial','precise']
migrations={e['name']:e for e in native['migrationInventory']};retained=0;changed=[]
for label in labels:
    old_cases=held['cases' if label=='precise' else label+'Cases']
    old_pairs=held['pairs' if label=='precise' else label+'Pairs']
    for old,new in zip(old_cases,native[label+'Cases']):
        name=label+'::'+old['name'];require(old['text']==new['text'] and old['inputSha256']==new['inputSha256'],'retained input bytes '+name)
        if name not in migrations:
            require(old==new,'full unaffected result '+name);retained+=1
        else:
            kind=migrations[name]['kind'];require(old['result']['ok'] is False,'only previous mask rejections')
            require(new['result']['ok'] is (kind=='single'),'inventoried migration outcome')
            if kind=='rejection': require(new['result']['error']['code']=='parse-error','later undefined-source check')
            changed.append(dict(name=name,kind=kind,before=old['result'],after=new['result']))
    require(old_pairs==native[label+'Pairs'],'full retained pairs '+label)
require(retained==4428-54 and len(changed)==54,'exact historical single migration count')
for old,new in zip(held['originals'],native['originals']):
    raw=(ROOT/old['path']).read_bytes();require(sha(raw)==old['sha256']==new['sha256'],'untouched original '+old['path'])
    if old['sha256'] not in migrations: require(old==new,'complete untouched original result')
    else: require(new['result']['ok'] is True,'lighting admission')

# Independent arithmetic below consults neither worker reference nor interpreter,
# IR, compiler metadata, emitted GLSL or the recorded oracle.
proof=[];draws=pixels=0
for index,rig in enumerate(gpu['acceptance']['rigs']):
    k=rig['kernel'];require(rig['objects']['live']==0,'owned object release')
    require(all(v==0 for v in rig['finalBudgets'].values()) and all(v==0 for v in rig['finalResourceBudgets'].values()),'zero budgets')
    for di,draw in enumerate(rig['draws']):
        v=draw['vector'];variant=k['variant'];mask=k.get('mask','')
        if k['kind']=='lighting':
            wanted=[0,0x3ec00017,0,0x3ec00017]
        elif variant in ('direct','ordinary'):
            wanted=v['b'].copy()
            for c in mask:
                i='xyzw'.index(c);wanted[i]=v['a'][3-i]
        elif variant=='alias':
            wanted=v['a'].copy();mapped=[v['a'][0],v['a'][2],v['a'][1],v['a'][3]]
            for c in mask:
                i='xyzw'.index(c);wanted[i]=mapped[i]
        elif variant=='numeric':
            wanted=[bits(.25),bits(.5),bits(1),bits(0)];mapped=list(map(bits,[1.5,1,1.5,1]))
            for c in mask:
                i='xyzw'.index(c);wanted[i]=mapped[i]
        elif variant=='numeric-alias':
            wanted=list(map(bits,[.5,1,.5,1]));mapped=list(map(bits,[1,1,1.5,1.5]))
            for c in mask:
                i='xyzw'.index(c);wanted[i]=mapped[i]
        else:
            require(variant=='output','closed witness family')
            wanted=[v['a'][3-i] if c in mask else (0xffffffff if i%2 else 0) for i,c in enumerate('xyzw')]
        require(draw['words']==wanted,'independent absolute-lane words '+k['name']+'/'+v['name'])
        raw=bytes(draw['rgbaBytes']);require(len(raw)==16384 and sha(raw)==draw['rgbaSha256'],'physical RGBA digest')
        for y in range(64):
            for x in range(64):
                pixel=list(raw[4*(64*y+x):4*(64*y+x)+4])
                expected=[0,0,255,255] if y>=2 else [255*((w>>(x//2))&1) for w in wanted]
                require(pixel==expected,'independent physical pixel '+k['name']+f' {x},{y}')
        proof.append(dict(rig=index,draw=di,name=k['name'],vector=v['name'],predicted=wanted,observed=draw['words'],rgbaSha256=sha(raw)))
        draws+=1;pixels+=4096
require((draws,pixels)==(542,2220032),'all independently interrogated physical draws')
faults=read(WORKER/'faults/manifest.json');fault_proof=[]
for name,f in faults['modes'].items():
    original=(ROOT/f['original']['path']).read_text();fault=(WORKER/'faults'/f['fault']['path']).read_text()
    require(original.count(f['before'])==1 and fault==original.replace(f['before'],f['after']),'actual isolated compiler-source fault '+name)
    artifact=(WORKER/'faults'/f['wasm']['path']).read_bytes();require(sha(artifact)==f['wasm']['sha256'] and artifact[:4]==b'\x00asm','compiled fault wasm')
    report=read(WORKER/'faults'/name/'gpu/report.json');a=report['acceptance'];require(a['faultWasmSha256']==sha(artifact),'actual hardware consumed fault')
    rig=a['rigs'][-1];draw=rig['draws'][-1];failure=draw['failure'];x,y=failure['x'],failure['y'];pixel=draw['rgbaBytes'][4*(64*y+x):4*(64*y+x)+4]
    require(pixel==failure['observedPixel'] and pixel!=failure['expectedPixel'],'physical first failure '+name)
    fault_proof.append(dict(name=name,kernel=rig['input'],vector=draw['vector']['name'],failure=failure,wasmSha256=sha(artifact)))
summary=dict(status='passed',head=HEAD,archiveSha256=sha(archive.read_bytes()),archiveFiles=len(records),archiveBytes=sum(r['bytes'] for r in records),retainedCompleteCases=retained,retainedCompletePairs=511,migrationCases=len(changed),gpuDraws=draws,gpuWords=draws*4,gpuPixels=pixels,faults=fault_proof)
(OUT/'worker-audit.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'archive-members.json').write_text(json.dumps(records,indent=2)+'\n')
(OUT/'word-predictions.jsonl').write_text(''.join(json.dumps(e,separators=(',',':'))+'\n' for e in proof))
(OUT/'migrations-audit.json').write_text(json.dumps(changed,indent=2)+'\n')
print(json.dumps(summary))
