#!/usr/bin/env python3
"""Independent bounded parser/authority probes; immutable production sources."""
import ctypes, hashlib, itertools, json, os, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
source=ROOT/'renderer/virgl-shader'
def require(c,m):
 if not c:raise AssertionError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
sources=[source/p for p in ('bridge.c','raw_bits.c','generated/u_format_table.c','checked_upstream.c')]
sources+=sorted((source/'vendor/src/gallium/auxiliary/tgsi').glob('*.c'))
sources+=[source/'vendor/src/gallium/auxiliary/cso_cache'/p for p in ('cso_hash.c','cso_cache.c')]
sources+=[source/'vendor/src/mesa/util/u_debug.c']
common=['-std=gnu11','-D_GNU_SOURCE','-D_DARWIN_C_SOURCE','-DUTIL_ARCH_LITTLE_ENDIAN=1','-DUTIL_ARCH_BIG_ENDIAN=0','-DHAVE___BUILTIN_CLZ=1','-DHAVE___BUILTIN_CLZLL=1','-DHAVE___BUILTIN_POPCOUNT=1']
common+=['-I'+str(source/p) for p in ('.','generated','vendor/src','vendor/src/mesa','vendor/src/mesa/pipe','vendor/src/mesa/compat','vendor/src/gallium/include','vendor/src/gallium/auxiliary','vendor/src/gallium/auxiliary/util')]
mode=sys.argv[1] if len(sys.argv)>1 else 'current'
if mode=='old-boundary':
 original=(source/'bridge.c').read_text();before='(kind == DESTINATION && count != 0)';require(original.count(before)==1,'single isolated fault')
 fault=OUT/'old-boundary-bridge.c';fault.write_text(original.replace(before,'(kind == DESTINATION && count == 1)'));sources[0]=fault
libfile=OUT/(mode+'.dylib');command=['clang',*common,'-O2','-g','-dynamiclib',*map(str,sources),'-lm','-o',str(libfile)]
with (OUT/(mode+'-build.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
(OUT/(mode+'-build.json')).write_text(json.dumps(dict(command=command,sources=[dict(path=str(p.relative_to(ROOT)),sha256=sha(p.read_bytes())) for p in sources],binarySha256=sha(libfile.read_bytes())),indent=2)+'\n')
lib=ctypes.CDLL(str(libfile));translate=lib.bridge_translate;translate.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_size_t];translate.restype=ctypes.c_char_p
f=json.loads((ROOT/'renderer/virgl-shader/tests/ordered-mask-cases.json').read_bytes())
records=[];counts={};accepted=0
def call(name,stage,text,wanted):
 global accepted
 raw=text.encode();result=json.loads(translate(int(stage=='fragment'),raw,len(raw)))
 record=dict(name=name,stage=stage,text=text,wanted=wanted,resultSha256=sha(canonical(result)),resultOk=result['ok'],error=result.get('error'))
 records.append(record);require(result['ok'] is wanted,name+' expected '+str(wanted)+' got '+str(result))
 if wanted:accepted+=1
 else:require(set(result)=={'ok','error'} and set(result['error'])=={'code','message'},'owned complete rejection')
def base(stage):return next(e['text'] for e in f['cases'] if e['name']=='mask-yz-direct-'+stage)
def simple(stage,mask,swizzle):
 return ('VERT\nDCL IN[0]\nDCL OUT[0], POSITION\n' if stage=='vertex' else 'FRAG\nDCL OUT[0], COLOR\n')+'DCL TEMP[0..1]\nIMM[0] UINT32 {11,22,33,44}\nIMM[1] FLT32 {0,0,0,1}\nMOV TEMP[0].x, IMM[0].xxxx\nMOV_PRECISE TEMP[1].'+mask+', TEMP[0].'+swizzle+'\nMOV OUT[0], '+('IN[0]' if stage=='vertex' else 'IMM[1]')+'\nEND\n'
try:
 for stage in ('vertex','fragment'):
  text=base(stage);start=len(records)
  for n in range(6):
   for components in itertools.product('xyzw',repeat=n):
    mask=''.join(components);wanted=0<n<=4 and len(set(mask))==n and mask==''.join(sorted(mask,key='xyzw'.index))
    call('grammar-'+(mask or 'empty')+'-'+stage,stage,text.replace('TEMP[117].yz,','TEMP[117].'+mask+','),wanted)
  counts['grammar-'+stage]=len(records)-start
  start=len(records)
  for mask in f['masks']:
   for components in itertools.product('xyzw',repeat=4):
    selector=''.join(components);wanted=all(selector['xyzw'.index(c)]=='x' for c in mask)
    call('consumed-'+mask+'-'+selector+'-'+stage,stage,simple(stage,mask,selector),wanted)
  counts['consumed-'+stage]=len(records)-start
  start=len(records)
  for authority in ('xy','xyz'):
   for mask in f['masks']:
    if stage=='vertex':
     b=text.replace('DCL OUT[1], GENERIC[0]','DCL OUT[1].'+authority+', GENERIC[0]').replace('MOV OUT[1], TEMP[115]','MOV OUT[1].'+authority+', TEMP[115]\nMOV OUT[1].'+mask+', IMM[0].xxxx')
    else:
     b=text.replace('DCL IN[0], GENERIC[0]','DCL IN[0].'+authority+', GENERIC[0]').replace('MOV_PRECISE TEMP[117].yz, TEMP[0].wzyx','MOV_PRECISE TEMP[117].'+mask+', IN[0].xyzw')
    call('authority-'+authority+'-'+mask+'-'+stage,stage,b,set(mask)<=set(authority))
  counts['authority-'+stage]=len(records)-start
 result=dict(status='passed',mode=mode,calls=len(records),accepted=accepted,rejected=len(records)-accepted,counts=counts,binarySha256=sha(libfile.read_bytes()))
except Exception as e:
 result=dict(status='failed',mode=mode,calls=len(records),failure=str(e));sys.exit_code=1
finally:
 (OUT/(mode+'-probe.jsonl')).write_text(''.join(json.dumps(e,separators=(',',':'))+'\n' for e in records))
 (OUT/(mode+'-probe-summary.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if result['status']!='passed':raise SystemExit(1)
