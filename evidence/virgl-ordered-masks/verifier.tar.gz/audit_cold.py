#!/usr/bin/env python3
import hashlib,json,subprocess,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
worker=ROOT/'target/evidence/virgl-ordered-masks-worker-2815f3d2';cold=ROOT/'target/evidence/virgl-ordered-masks-cold-2815f3d2';package=ROOT/'evidence/virgl-ordered-masks'
sha=lambda b:hashlib.sha256(b).hexdigest()
def require(c,m):
 if not c:raise AssertionError(m)
def read(p):return json.loads(p.read_bytes())
manifest=read(package/'manifest.json');bindings=[]
for key in ('archives','receipts','artifacts'):
 for item in manifest[key]:
  raw=(package/item['path']).read_bytes();require(len(raw)==item['bytes'] and sha(raw)==item['sha256'],'submitted package binding '+item['path']);bindings.append(item)
report=read(cold/'report.json');clone=Path(report['clone']);head=report['gitHead']
require(head=='2815f3d23806aa5b7aaa6a12cef03d5ce54ade90' and report['status']=='passed' and report['exitCode']==0,'final direct acceptance')
require(report['cloneHead']==head==report['cloneHeadAfter'] and not report['statusBefore'] and not report['statusAfter'],'clean detached clone at recorded head')
require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==head,'still exact clone head')
require(not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=clone),'clone still pristine')
require(sha((cold/'acceptance/receipt.json').read_bytes())==report['receiptSha256'],'cold receipt raw digest')
require(sha((ROOT/'tools/virgl-ordered-masks/cold.py').read_bytes())==report['harnessSha256'],'frozen cold harness')
require(sha((cold/'cold.log').read_bytes())==report['logSha256'],'complete direct cold log')
for item in report['acceptanceFiles']:
 raw=(cold/item['path']).read_bytes();require(len(raw)==item['bytes'] and sha(raw)==item['sha256'],'all copied raw cold files')
archive=package/'cold.tar.gz';members=[]
with tarfile.open(archive) as t:
 for m in t:
  if not m.isfile():continue
  name=m.name.removeprefix('./');p=cold/name;require(p.is_file() and p.stat().st_size==m.size,'cold member size '+name)
  h=hashlib.sha256()
  with t.extractfile(m) as a,p.open('rb') as f:
   while data:=a.read(1024*1024):require(f.read(len(data))==data,'lossless cold member '+name);h.update(data)
   require(not f.read(1),'no cold tail omitted')
  members.append(dict(path=name,bytes=m.size,sha256=h.hexdigest()))
require(len(members)==715 and len(report['acceptanceFiles'])==713,'all final cold files')
identical=[]
for name in ('native/native-input.bin','native/native.log','wasm/calls.jsonl','reference.json'):
 a=(worker/name).read_bytes();b=(cold/'acceptance'/name).read_bytes();require(a==b,'complete warm/cold transcript '+name);identical.append(dict(path=name,sha256=sha(a)))
a=read(worker/'native/native-report.json');b=read(cold/'acceptance/native/native-report.json')
for key in ['stats','layout','flow','recordedMaxima','originals','cases','pairs','allocationFaults','upstreamCalibrations','migrationInventory']+[label+suffix for label in ('raw','integer','float','numeric','component','dot','constant','structured','indirect','loop','equality','selected','radial','precise') for suffix in ('Cases','Pairs')]:
 require(a[key]==b[key],'full cold native counterpart '+key)
w=read(worker/'wasm/report.json');c=read(cold/'acceptance/wasm/report.json')
for key in ('counts','memory','maxima','limits','ownership','stress','allocationPressure'):require(w[key]==c[key],'full cold Wasm counterpart '+key)
g=read(worker/'gpu/report.json')['acceptance'];c=read(cold/'acceptance/gpu/report.json')['acceptance']
for key in ('rigs','checkedWords','checkedPixels','drawCount','proof','fixture','partners'):require(g[key]==c[key],'complete cold hardware counterpart '+key)
summary=dict(status='passed',head=head,clone=str(clone),stillClean=True,packageBindings=bindings,coldFiles=len(members),coldAcceptanceFiles=len(report['acceptanceFiles']),completeIdenticalTranscripts=identical,nativeAndWasmResultsEqual=True,completeHardwareRigsEqual=True)
(OUT/'cold-package-audit.json').write_text(json.dumps(summary,indent=2)+'\n');(OUT/'cold-archive-members.json').write_text(json.dumps(members,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='packageBindings'}))
