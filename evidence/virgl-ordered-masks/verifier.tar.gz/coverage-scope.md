# Changed-hunk sufficiency

Frozen runtime/harness 2815f3d2; diff base 5f02a20e. Runtime contains a single
changed expression at bridge.c:180. LLVM coverage.json SHA-256
e7580d2461eb01e795492fa4d12f3697f143a9da5864bbf1edaf5fb19aac8aaf
records kind==DESTINATION true20,156,983/false4 and count!=0
true20,156,977/false6. Nearby strict order/count checks and source/declaration
alternatives execute. The 15 masks and malformed controls have complete native
and Wasm results. No unexecuted product line remains.

All six raw/ordinary/numeric/alias/OUT families execute in both stages: 182
rigs, 542 actual indexed draws. Literal shader input, actual single/paired
translation, uploaded shader source, compile/link and all physical pixels bind
the emission path. The existing unchanged emitter's raw_rhs and numeric
snapshot paths run and are independently falsified by the four actual faults.
LLVM names positive raw_emit, checked_source, precise_source and float_snapshot
counters; all raw profile/recovery anchors run. No new emitter code is inferred.

New GPU helper/oracle code: source-bound V8 counters cover all ordinary paths,
mask/alias/output/numeric branches, lighting arms, geometry/upload/readback,
literal proof, renderer lifecycle and every mask. Normal run zero ranges are
failure throws, missing object-id fallback, fault-Wasm setup and catch paths;
the four recorded source-fault runs execute the fault setup/mismatch/catch.
The missing object-id fallback is defensive diagnostics, never a product path.

Per-file remainder:

| Diff file | Evidence or waiver |
|---|---|
| Makefile | Static command routing; direct canonical logs call the new target. |
| README.md | Documentation only; claims checked against full recordings. |
| build.sh | guard-check/ordered-mask-sanitize/wasm command lines recorded in acceptance.log; build configuration is a static waiver. |
| native_tests/ordered_masks.c | Entire recorded original/case/pair/fault/hostile/truncation/mutation/recovery schedule executes with ASan/UBSan and LLVM counters. MAX_CASES/MAX_PAIRS/record structs are static test data. --smoke path is explicitly a non-evidence diagnostic and waived. Failed require/malformed stream exit arms are harness infrastructure, not admitted product behavior. |
| tests/ordered-mask-cases.json | Every 215 single/182 pair input, all 180 masks/families and two original bodies execute; metadata/ledger are declarative fixtures verified against byte-identical F4 data. |
| verify-virgl-ordered-masks.sh | Every success command executes in warm and cold logs. Existing npm/SDK setup alternatives and rm/mkdir/tee plumbing are environment infrastructure. |
| browser.mjs | Actual envelope, source binding, hardware launch, validation and counters execute; fault option also executes for each real artifact. CLI misuse assertions are infrastructure. |
| cold.py | Direct final scrubbed exact-head clone success executes. Timeout/kill/copy-error branches are recorder infrastructure and waived; no concurrency/deployment claim. |
| faults.py | All four unique C mutations build isolated Wasm and fail hardware oracle. Setup/copy/assert error arms are test infrastructure. |
| generate_cases.py | Static fixture-generation tool; output semantically inspected and exercised, F4 baseline hash/ledger preserved. Generator execution is not product behavior. |
| native.py/native_receipt.py | Full no-argument transcript production and replay execute for worker and cold. Typed record/reconstruction/bounds checks are rechecked, infrastructure failure arms attacked by tampered evidence. |
| oracle.mjs/reference.mjs | All 15 proof checks, every mask family, raw/numeric/lighting arms run. Direct independent algebra separately checks all words/pixels; no worker interpreter serves as the only oracle. |
| receipt.py/shared.py | Source/archive/artifact bindings and successful full record/pixel checks execute. Four fault physical paths execute. Evidence corruption attacks cover key failure checks; other typed failure diagnostics are infrastructure. |
| wasm.mjs/wasm_receipt.py | All full native counterparts, owned responses, maximal text stresses, real heap-pressure and recovery paths execute with stable16MiB memory. Error/unknown input guards are infrastructure or preserved predecessor product behavior. |

New verifier regression script is test-only. Its direct10,470-call proof and
actual isolated old-boundary Wasm sabotage are retained; it changes no frozen
compiler, consumer or recording source. Earlier F4 HELD semantic, contract,
allocator, cap and authority results carry forward across unchanged sources.
