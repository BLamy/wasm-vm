#!/usr/bin/env python3
"""Bounded typed/provenance/physical corruption probes, with recomputed digests."""
import copy,hashlib,json,shutil,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;WORKER=ROOT/'target/evidence/virgl-ordered-masks-worker-2815f3d2'
sys.path.insert(0,str(ROOT/'tools/virgl-ordered-masks'));import receipt
head='2815f3d23806aa5b7aaa6a12cef03d5ce54ade90';native=receipt.read(WORKER/'native/native-report.json');reference=receipt.read(WORKER/'reference.json');results=[]
def require(c,m):
 if not c:raise AssertionError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def expect(name,fn):
 try:fn()
 except (ValueError,AssertionError,KeyError,IndexError) as e:results.append(dict(name=name,status='rejected',message=str(e)));return
 raise AssertionError('proof forgery survived '+name)

# A complete forged physical readback has a correct new raw digest, but cannot
# change the independently predicted absolute destination/source lane equation.
for name,change in [('pixel-with-recomputed-digest',lambda r:r['acceptance']['rigs'][0]['draws'][0]['rgbaBytes'].__setitem__(0,255)),('word-and-oracle-forgery',lambda r:r['acceptance']['rigs'][0]['draws'][0]['words'].__setitem__(0,0))]:
 d=OUT/name;d.mkdir(exist_ok=True)
 for filename in ('browser.png','browser-coverage.json'):shutil.copy2(WORKER/'gpu'/filename,d/filename)
 r=receipt.read(WORKER/'gpu/report.json');change(r);draw=r['acceptance']['rigs'][0]['draws'][0];draw['rgbaSha256']=sha(bytes(draw['rgbaBytes']));write(d/'report.json',r)
 expect(name,lambda:receipt.physical(d,head,native,reference))
for name,key,value in [('wasm-float-calls','calls',51287.0),('wasm-bool-count','originals',True)]:
 d=OUT/name;d.mkdir(exist_ok=True)
 # Actual nativeReport path stays ../native, provided as a symlink to raw data.
 link=OUT/'native'
 if not link.exists():link.symlink_to(WORKER/'native',target_is_directory=True)
 shutil.copy2(WORKER/'wasm/calls.jsonl',d/'calls.jsonl');r=receipt.read(WORKER/'wasm/report.json');r['counts'][key]=value;write(d/'report.json',r)
 expect(name,lambda:receipt.wasm_receipt.verify(d,head,native))
d=OUT/'omitted-coverage-source';shutil.copytree(WORKER/'native',d,dirs_exist_ok=True);r=receipt.read(d/'native-report.json');e=receipt.read(d/'coverage.json');e['data'][0]['files'].pop();write(d/'coverage.json',e)
record=next(x for x in r['coverage']['records'] if x['path']=='coverage.json');raw=(d/'coverage.json').read_bytes();record.update(bytes=len(raw),sha256=sha(raw));write(d/'native-report.json',r)
expect('omitted-coverage-source',lambda:receipt.native_receipt.verify(d,head))
d=OUT/'invented-migration';shutil.copytree(WORKER/'native',d,dirs_exist_ok=True);r=receipt.read(d/'native-report.json');next(x for x in r['migrationInventory'] if x['kind']=='single')['kind']='rejection';write(d/'native-report.json',r)
# The separate fresh migration auditor will reject a digest-consistent ledger
# divergence even where runtime arrays still match the genuine source fixture.
fixture=receipt.read(ROOT/'renderer/virgl-shader/tests/ordered-mask-cases.json')
def migration():
 expected={x['name']:('single' if x['ok'] else 'rejection') for x in fixture['migrationCandidates']}
 for x in r['migrationInventory']:
  if x['kind']!='original':require(x['kind']==expected[x['name']],'migration kind agrees with unchanged authored input')
expect('invented-migration',migration)
(OUT/'receipt-attack-report.json').write_text(json.dumps(dict(status='passed',attacks=results),indent=2)+'\n');print(json.dumps(results))
