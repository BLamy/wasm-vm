# Fresh verifier commands and scope

All code/evidence writes were in target/evidence/virgl-ordered-masks-verifier
until the worker's final submission9ca23afb. Subsequent writes are the promoted
test, task status/verdict, regenerated queue and packaged verifier evidence.
No production shader/renderer source, generated normal compiler artifact,
original capture, guest negotiation, deployed site or pull request was changed.

Read AGENTS.md, whole F4a/F4 tasks, diff5f02a20e..2815f3d2 and handoff first.
Recorded predictions.md before opening any worker/cold evidence.

```sh
python3 -B target/evidence/virgl-ordered-masks-verifier/audit_worker.py
python3 -B target/evidence/virgl-ordered-masks-verifier/native_probe.py
node target/evidence/virgl-ordered-masks-verifier/wasm_probe.mjs
python3 -B target/evidence/virgl-ordered-masks-verifier/native_probe.py old-boundary
node target/evidence/virgl-ordered-masks-verifier/gpu-runner.mjs normal 0x41d2c675
node target/evidence/virgl-ordered-masks-verifier/gpu-runner.mjs novel 0x29bd6731
node target/evidence/virgl-ordered-masks-verifier/gpu-runner.mjs fault-widen-yz 0x41d2c675
node target/evidence/virgl-ordered-masks-verifier/gpu-runner.mjs fault-packed-source 0x41d2c675
node target/evidence/virgl-ordered-masks-verifier/gpu-runner.mjs fault-neighbor-write 0x41d2c675
node target/evidence/virgl-ordered-masks-verifier/gpu-runner.mjs fault-early-alias 0x41d2c675
python3 -B target/evidence/virgl-ordered-masks-verifier/audit_cold.py
python3 -B target/evidence/virgl-ordered-masks-verifier/receipt_attacks.py
python3 -B target/evidence/virgl-ordered-masks-verifier/exact_points.py
node --check renderer/virgl-command/tests/ordered-mask-regressions.mjs
node renderer/virgl-command/tests/ordered-mask-regressions.mjs
node renderer/virgl-command/tests/ordered-mask-regressions.mjs target/evidence/virgl-ordered-masks-verifier/old-boundary-wasm-source/build/wasm/virgl-shader.wasm
git diff --check
```

old-boundary native and promoted-test old-boundary Wasm commands are expected
failures at the xz-admission assertion. Four source-fault browser wrappers
return success only when a real independent pixel mismatch is observed; raw
browser reports retain their failed status and physical readback.

Worker/cold source-bound replay invoked native_receipt.verify,
wasm_receipt.verify and receipt.physical directly, without overwriting the
canonical receipt. Cold replay ran in its report's exact named clone, with
Python -B to avoid writing there. Results are worker-reader-replay.json and
cold-reader-replay.json. Cold archive/files and entire counterpart arrays are
rechecked by audit_cold.py. Native probe JSON binds actual compile commands,
all source hashes and isolated binaries. Old-boundary Wasm compiler command
was bash build.sh wasm in the scratch-only copied shader tree, with the pinned
existing Emscripten4.0.22 wrapper; normal compiler sources were never patched.

Restore this verifier archive under the original target/evidence directory
for relative imports/scripts. The worker archive restores its named canonical
target directory. Coverage-reader path identity requires the named original
worktree or cold clone; path differences are not runtime failures.

Corrected invalid verifier fixtures are preserved in probe-fixture-correction.md,
invalid-authority-fixture-* and invalid-raster-fixture-*. All final outcome
artifacts use the corrected fixtures. No product refutation was silently fixed.
