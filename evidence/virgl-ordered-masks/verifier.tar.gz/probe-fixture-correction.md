The first independent authority probe incorrectly treated a partial TEMP
declaration as an admitted declaration. Existing bridge.c declaration line322
allows partial masks only for GENERIC input/output semantics, preserving the
predecessor boundary. It therefore correctly rejected the initial probe before
the write. This is an invalid verifier fixture, not a product refutation.

The corrected predictions, before rerunning: vertex GENERIC output declarations
xy/xyz permit exactly their contained destination subsets; fragment GENERIC input
declarations xy/xyz permit a masked identity source exactly when every consumed
component is declared. Partial TEMP declarations remain rejected. The initial
transcript is retained as invalid-authority-fixture-current-probe.jsonl.

The first fragment consumed-source probe also attempted to rasterize arbitrary
raw words 11/22/33/44, which the unchanged ordinary-output authority correctly
rejects. Replaced only that unobserved fragment output with independent finite
FLT32 {0,0,0,1}; source register raw sentinels and consumed-lane predictions
remain identical. Initial transcript retained as invalid-raster-fixture files.

Initial receipt corruption probe attempted to replace the first migration's
kind with rejection, but that entry already was a rejection. This was a no-op
fixture, not a surviving proof forgery. Corrected before final adjudication to
flip an actual admission to rejection. Syntax-only failures in the scratch
novel browser module were corrected before executing its physical predictions;
the final 74-draw novel recording has zero browser errors. No product code was
changed by any verifier fixture correction.
