import {createVirglShaderBridge} from '/renderer/virgl-shader/index.mjs';
import {digest} from '/renderer/virgl-shader/tests/browser.mjs';
import {makeRig,resources,setup,readPixels,constants,join,CLEAR} from './gpu-helpers.mjs';
const require=(c,m)=>{if(!c)throw new Error(m);};
const same=(a,b,m)=>require(JSON.stringify(a)===JSON.stringify(b),m);
const bit=f=>{const a=new DataView(new ArrayBuffer(4));a.setFloat32(0,f,true);return a.getUint32(0,true);};
function vectors(seed){let s=seed>>>0;const next=()=>{s^=s<<13;s^=s>>>17;s^=s<<5;return s>>>0;};
 const v=[{name:'crossing-alias-words',a:[0x12345678,0x87654321,0x80000000,0x7fc01234],b:[0xfedcba98,0x7f801111,1,0x807fffff]},
 {name:'opposite-zeros',a:[0,0x80000000,0,0x80000000],b:[0x80000000,0,0x80000000,0]},
 {name:'nan-and-subnormal',a:[0x7f801111,0xffc01234,1,0x80000001],b:[0x007fffff,0x807fffff,0x00800000,0x80800000]},
 {name:'distinct-finite',a:[0x3f800000,0xbf800000,0x3f000000,0xbf000000],b:[0x40000000,0xc0000000,0x40800000,0xc0800000]}];
 for(let i=0;i<8;i++)v.push({name:'independent-seed-'+i,a:Array.from({length:4},next),b:Array.from({length:4},next)});return v;
}
function bank(v){const w=Array(24).fill(0);for(let l=0;l<4;l++){w[l]=0x3f800000|(v.a[l]>>>16);w[4+l]=0x3f800000|(v.a[l]&65535);w[8+l]=0x3f800000|(v.b[l]>>>16);w[12+l]=0x3f800000|(v.b[l]&65535);}return w;}
function text(fixture,stage,mode){
 const name='mask-'+(mode==='numeric'?'yz-numeric-alias':mode==='output'?'xzw-output':'yz-direct')+'-'+stage;
 let source=fixture.cases.find(e=>e.name===name).text;
 if(mode==='precise'||mode==='ordinary'){
  const mark=mode==='precise'?'_PRECISE':'';
  source=source.replace('MOV_PRECISE TEMP[117].yz, TEMP[0].wzyx\n','MOV'+mark+' TEMP[117].yz, TEMP[0].wzyx\nMOV'+mark+' TEMP[117].xz, TEMP[117].zyxw\nMOV_PRECISE TEMP[117].yw, TEMP[117].wxyy\n');
 }else if(mode==='numeric')source=source.replace('ADD TEMP[0].yz, TEMP[0].xzyw, IMM[3].yyyy\n','ADD TEMP[0].yz, TEMP[0].xzyw, IMM[3].yyyy\nADD TEMP[0].xz, TEMP[0].zyxw, IMM[3].xxxx\nADD TEMP[0].yw, TEMP[0].wxyy, IMM[3].yyyy\n');
 else{const dest=stage==='vertex'?'OUT[1]':'OUT[0]';source=source.replace('MOV '+dest+'.xzw, TEMP[115].wzyx','MOV '+dest+'.xzw, TEMP[115].wzyx\nMOV '+dest+'.yz, TEMP[115].xxyx');}
 return source;
}
export async function runAcceptance({seed=0x29bd6731}={}){
 const report={schema:'ordered-mask-novel-verifier-v1',status:'running',guestExecution:false,seed:seed>>>0,rigs:[],draws:0,words:0,pixels:0};window.__virglOrderedMasksNovelReport=report;
 try{
  const fixture=await(await fetch('/renderer/virgl-shader/tests/ordered-mask-cases.json')).json(),partners=await(await fetch('/renderer/virgl-command/tests/bounded-loops-shaders.json')).json();
  let module;const bridge=await createVirglShaderBridge({onRuntimeInitialized(){module=this;}});const memory=module.HEAPU8.buffer;same(memory.byteLength,16777216,'fixed compiler heap');
  const gl=document.querySelector('#gpu').getContext('webgl2',{antialias:false,preserveDrawingBuffer:true,failIfMajorPerformanceCaveat:true});require(gl instanceof WebGL2RenderingContext,'actual WebGL2');const debug=gl.getExtension('WEBGL_debug_renderer_info');report.renderer={vendor:gl.getParameter(debug.UNMASKED_VENDOR_WEBGL),renderer:gl.getParameter(debug.UNMASKED_RENDERER_WEBGL)};require(!/software|swiftshader|llvmpipe|softpipe|fake|null/i.test(report.renderer.renderer),'actual hardware');
  const all=vectors(seed);
  for(const stage of ['vertex','fragment'])for(const mode of ['precise','ordinary','numeric','output']){
   const kernel={name:'novel-'+mode+'-'+stage,kind:'mask',stage,mode},record={kernel,text:text(fixture,stage,mode)},rig=makeRig(gl,bridge,record);report.rigs.push(record);
   try{
    resources(rig,kernel);const vertex=stage==='vertex'?record.text:partners.shaders.find(e=>e.name==='pass-vertex').text,fragment=stage==='fragment'?record.text:partners.shaders.find(e=>e.name==='pass-fragment').text;
    setup(rig,vertex,fragment,bank(all[0]));
    for(const vector of (mode==='numeric'?all.slice(0,1):all)){
     // Predictions are literal algebra over pre-write words, before GPU calls.
     const wanted=mode==='numeric'?[1.75,2.25,.75,1.5].map(bit):mode==='output'?[vector.a[3],vector.a[0],vector.a[1],vector.a[0]]:[vector.a[1],vector.a[1],vector.b[0],vector.a[2]];
     const words=bank(vector),draw={vector,wanted,bank:words,predictedBeforeDraw:true};record.draws.push(draw);
     rig.run(join(constants(0,words),constants(1,words)),'novel banks');rig.run(CLEAR.slice(),'novel clear');draw.submission=rig.run(rig.draw(),'novel shared draw');const bytes=readPixels(rig);draw.rgbaBytes=[...bytes];draw.rgbaSha256=await digest(bytes);draw.checkedPixels=4096;
     const actual=[0,0,0,0];
     for(let y=0;y<64;y++)for(let x=0;x<64;x++){
      const pixel=[...bytes.slice(4*(64*y+x),4*(64*y+x)+4)];
      const expected=y>=2?[0,0,255,255]:wanted.map(w=>255*((w>>>Math.floor(x/2))&1));
      same(pixel,expected,kernel.name+'/'+vector.name+' novel pixel '+x+','+y);
      if(y===0&&x%2===0)for(let l=0;l<4;l++)actual[l]=(actual[l]|((pixel[l]/255)<<(x/2)))>>>0;
     }
     draw.words=actual;same(actual,wanted,'novel independent word prediction');
     report.draws++;report.words+=4;report.pixels+=4096;same(module.HEAPU8.buffer,memory,'stable actual compiler heap');
    }
   }finally{rig.dispose();}
  }
  report.status='passed';document.querySelector('#status').textContent=report.words+' novel sequential masked words';return report;
 }catch(e){report.status='failed';report.failure={message:e.message,stack:e.stack};return report;}
}
