# Fresh verifier predictions, recorded before worker evidence inspection

Frozen source: 2815f3d23806aa5b7aaa6a12cef03d5ce54ade90. Diff base: 5f02a20e.
Read AGENTS.md, the full F4a task and F4 verified log, actual production/harness
diff, literal fixture/generator, parser and independent oracle, and worker
handoff before this file. No worker/cold report or counter was inspected yet.

1. PROVENANCE. The archive has SHA-256 bdf9499f20d74e44a1c3f57ff207f2f7e0e5e568e0e81172130809dd7961edad.
   Its complete members equal the canonical worker files. Receipts bind frozen
   2815f3d2, unmodified production/compiler sources and actual native/Wasm files.
   All 19 original input hashes are unchanged from the verified F4 baseline.
2. ADMISSION. Each of the 15 strictly increasing nonempty xyzw subsets admits
   in both stages. Duplicate, reversed, overlong and empty masks reject;
   uninitialized consumed source lanes, undeclared destination lanes, sparse
   declarations, short source swizzles and OUT sources still reject. MAD/TEX
   explicit-mask gates survive. An independent exhaustive mask probe will obey
   the same grammar, not merely the selected fixture negatives.
3. LANE IDENTITY. A masked write uses the absolute destination component to
   index the source selector, not its packed position. For MOV d.yz,s.wzyx,
   new d=[old d.x,s.z,s.y,old d.w]. Every physical word and RGBA pixel in all
   direct/ordinary/output rigs must match this equation or its numeric analogue.
4. ALIAS SNAPSHOT. For alias MOV r.yz,r.xzyw and initial
   [12345678,87654321,80000000,7fc01234], the pre-write result is
   [12345678,80000000,87654321,7fc01234]. Raw and numeric aliases in both
   stages must snapshot sources before writing, preserving every unselected
   neighbor. Independent swizzles and a sequential sparse-write novel case
   must also obey this equation through the actual compiler/hardware.
5. LIGHTING. Untouched 12f6d594/d4f702f7 accept and pair-link as raw-v18,
   eight-word-vector vertex bank, with both finite-bank and MAX precise-word
   contracts. Actual shaderSource/compileShader/linkProgram evidence must
   include those exact bodies and outputs. With the submitted negative unit
   normal/identity matrices, the observer words are
   [00000000,3ec00017,00000000,3ec00017]. No backward RSQ/DP3 exactness is inferred.
6. RETENTION. All 4,428 prior cases and 511 prior pairs retain complete F4
   results except the exact inventoried 24 admissions, 30 later parse-errors
   and two original lighting admissions. Unrelated precision/arithmetic,
   numeric/output authority and metadata contracts remain unchanged. Relevant
   precise/equality/selected/radial rerun leaves and promoted regressions pass.
7. BOUNDS/RECOVERY. Native ASan/UBSan output contains no diagnostic failure.
   Layout remains raw IR 26,480, instruction 112, profile 7,616, flow 52,644
   within 53,248. Instruction 179 admits; 180 rejects. Wasm full results equal
   native, fixed 16MiB buffer identity survives all calls, allocation failures
   publish owned complete errors then recover all 58 single/56 paired anchors.
8. FAULTS. The four artifacts actually contain the recorded isolated C
   source changes and compiled Wasm. Each first failed draw has a physical
   pixel that differs from the independent literal prediction. Replacing a
   fault with healthy production output must make the sabotage expectation fail.
9. SUFFICIENCY. LLVM has positive counters at the sole changed runtime branch
   and both acceptance/rejection surroundings; V8 counters and raw submissions
   exercise all new ordinary/raw/alias/output mask families. Remaining harness,
   fixture/configuration and error-reporting hunks are executed or individually
   waived as non-product infrastructure. Every behavioral diff hunk is covered.
10. COLD/PROOF ROBUSTNESS. The one final exact-head pristine clone records a
    clean detached checkout before/after and a successful scrubbed canonical
    acceptance. Its full native/Wasm results match worker. Digest-consistent
    forged pixel/counter/migration/provenance evidence must be rejected by the
    source-bound reader. The cold root path may differ; path-bound counters are
    interrogated in its named clone.

F4 carry-forward: per-instruction token semantics, exact comparison/tie/NaN
word behavior, contracts/authority, checked upstream allocator wrapper, caps,
and prior promoted regressions are HELD only where their sources, dependency
boundary and evidence digests remain unchanged. The mask-sensitive admissions,
original bodies, rerun leaves and shared emission paths are interrogated here.
