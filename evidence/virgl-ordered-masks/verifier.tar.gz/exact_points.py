#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;WORKER=ROOT/'target/evidence/virgl-ordered-masks-worker-2815f3d2'
names={'mask-yz-direct-vertex','mask-yz-alias-vertex','mask-yz-numeric-alias-fragment','mask-xzw-output-fragment','original-12f6d594-vertex','original-d4f702f7-vertex'}
points=[]
for rel in ['gpu/report.json']+['faults/'+f+'/gpu/report.json' for f in ('widen-yz','packed-source','neighbor-write','early-alias')]:
 raw=(WORKER/rel).read_bytes();r=json.loads(raw);lines=raw.decode().splitlines();digest=hashlib.sha256(raw).hexdigest()
 for i,rig in enumerate(r['acceptance']['rigs']):
  if rel=='gpu/report.json' and rig['input'] not in names:continue
  if rel!='gpu/report.json' and i!=len(r['acceptance']['rigs'])-1:continue
  start=next(j for j,line in enumerate(lines) if line.strip().rstrip(',')=='"name": "'+rig['kernel']['name']+'"')
  cursor=start
  for d,draw in enumerate(rig['draws']):
   cursor=next(j for j in range(cursor,len(lines)) if '"rgbaSha256": "'+draw['rgbaSha256']+'"' in lines[j])
   word=next(j for j in range(cursor,cursor+10) if '"words":' in lines[j])
   point=dict(file=rel,line=word+1,digest=digest,pointer=f'/acceptance/rigs/{i}/draws/{d}/words',kernel=rig['input'],vector=draw['vector']['name'],words=draw['words'],rgbaSha256=draw['rgbaSha256'])
   if draw.get('failure'):
    point['failure']=draw['failure'];point['failureLine']=next(j+1 for j in range(word,len(lines)) if '"failure": {' in lines[j])
   points.append(point);cursor=word+1
(OUT/'exact-trace-points.jsonl').write_text(''.join(json.dumps(p,separators=(',',':'))+'\n' for p in points));print([(p['kernel'],p['vector'],p['line'],p.get('failureLine')) for p in points])
