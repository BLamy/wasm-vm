#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def require(c,m):
 if not c:raise AssertionError(m)
records=[]
for folder in ['independent-normal-41d2c675','independent-novel-29bd6731']+['independent-fault-'+name+'-41d2c675' for name in ('widen-yz','packed-source','neighbor-write','early-alias')]:
 raw=(OUT/folder/'report.json').read_bytes();r=json.loads(raw);a=r['acceptance']
 require(r['browserErrors']==dict(console=[],page=[],requests=[]),'no independent browser errors')
 require(r['browser']['launch']['headless'] is False and r['browser']['gpu']['featureStatus'][r['browser']['webglFeature']]=='enabled','actual enabled hardware')
 for source in r['sources']+r['servedFiles']:
  b=(ROOT/source['path']).read_bytes();require(len(b)==source['size'] and sha(b)==source['sha256'],'frozen independent source/artifact '+source['path'])
 for key in ('browserCoverage','screenshot','failureScreenshot'):
  if key in r:require(sha((OUT/folder/r[key]['path']).read_bytes())==r[key]['sha256'],'saved independent '+key)
 for rig in a['rigs']:
  require(rig['objects']['live']==0 and all(v==0 for v in rig['finalBudgets'].values()) and all(v==0 for v in rig['finalResourceBudgets'].values()),'zero independent object/budget')
  for draw in rig['draws']:require(sha(bytes(draw['rgbaBytes']))==draw['rgbaSha256'],'lossless independent physical readback')
 fault='-fault-' in folder
 if fault:require(r['status']=='failed' and a['rigs'][-1]['draws'][-1].get('failure'),'actual fault refutation')
 else:require(r['status']=='passed' and a['status']=='passed','healthy independent proof')
 records.append(dict(path=folder+'/report.json',sha256=sha(raw),status=r['status'],hardware=a['renderer'],draws=a.get('drawCount',a.get('draws')),words=a.get('checkedWords',a.get('words')),sources=len(r['sources'])))
verdict=json.loads((OUT/'verdict.json').read_bytes())
verdict['predictions'][3]['evidence']['sha256']=sha((OUT/verdict['predictions'][3]['evidence']['path']).read_bytes())
verdict['independentHardware']=records
(OUT/'verdict.json').write_text(json.dumps(verdict,indent=2)+'\n')
(OUT/'independent-record-audit.json').write_text(json.dumps(dict(status='passed',records=records),indent=2)+'\n');print(json.dumps(records))
