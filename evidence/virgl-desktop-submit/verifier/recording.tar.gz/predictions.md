# E6-T11d52 fresh verifier predictions

These predictions were written after reading AGENTS.md, the complete task, the
runtime diff and acceptance harness, and before opening any recorded state.
Submission: 75b6a0d7b01eb2885d497ef6a716b9baae6acd24. Base:
0660eebf08a1b047109ed4e2e508132b68d103ba. Authoritative cold source:
17433963c8f2489598841bb648dfbe26287dbfb7. Host rr is waived by policy.

- P1 authentication: every worker index row resolves to one complete archive
  body, with exactly the declared byte length and SHA256; no extra, cyclic or
  unknown link entry exists. All six held D49/D50/D51 seals match base Git bytes
  and their bodies, and carried runtime/compiler sources match current bytes.
- P2 lifetime selection: each of 56 compositor and eight kmscube successful
  original enter/return pairs produces OK 0x1100 on a real selected queue; the
  glmark2 34th control at event3025, format17, produces BAD 0x1205 before any
  host allocation. The independently reconstructed IDs, generations, metadata,
  logical bytes and GPU bytes agree at every before/after checkpoint.
- P3 capacity: selected native resources100..163 admit, resource164 (65th)
  returns OOM 0x1201 without native/host state or allocation change; its actual
  native beginJob callback carries exactly64 sorted matching identities. Used
  index is unchanged during host admission/pumping and only a later guest step
  writes the exact 0x1100 fenced response and intact40-byte guard.
- P4 historical routing: new(callback,true) admits16 and refuses17/depth20;
  its real16-owner empty job completes. A forged17-owner accepted snapshot is
  refused before renderer publication. new(callback,false) exposes no control
  or submission snapshot, advertises no VIRGL, and refuses context creation.
- P5 stale/foreign envelopes and tightened limits: resource65, malformed metadata,
  foreign or stale identity, mismatched backing, epoch and rejected host
  admission preserve all owner state and publish no pending renderer work.
  A selected resources:1 quota permits one packed-depth20 owner and refuses
  the next. Fresh tests will cite actual refusal and unchanged state points.
- P6 ownership after acceptance: accepted command/metadata/backing inputs are
  immutable to later caller or guest-source mutation. With64 attached owners,
  a transfer of the last owner followed by ordered unref/recreate/backing reuse
  cannot read a stale generation or later guest bytes. A fresh full state/ring/
  guard and literal8-byte DMA oracle will falsify leakage across those owners.
- P7 GPU/state: three fresh withheld-fence schedules execute original210 packets
  and three real indexed draws apiece; first full32x32 readback is exactly the
  literal quadrant plane. Every getBufferSubData follows a signaled hardware
  fence, no finish occurs, and completion is posted only after GPU ownership
  retires. Output is never used to initialize guest DMA.
- P8 cancellation/failure: pending reset/reconfiguration invalidates the old key,
  leaves old response/ring unchanged, deletes pending GL fences, and reset
  recreates the selected packed-depth store. WAIT_FAILED reports code6 and
  gpuComplete=false, poisons until reset, and disposals leave zero objects.
- P9 sufficiency: every changed native body operand has positive execution;
  selected/historical/disabled branches of moved Wasm assemble execute in the
  recorded browser, and all inserted JS dynamic token ranges have positive V8
  counts. Static declarations/config/docs and unchanged moved lines are waived
  only with byte equality or a specific no-dynamic-operand reason.
- P10 provenance/default: final cold receipt comes from a clean, scrubbed clone
  at frozen head and all25 scoped commands pass; final source differs from that
  head only by sealing/evidence/log metadata. Local/deployed default demo shows
  127/0, absent proof exports, live scalar-memory and partial disabled graphics;
  committed/default served Wasm bytes match its recorded digest.
- P11 sabotage: serve only normalizeJob(input,16) in place of the selected64
  bound. The real64-owner callback still arrives, but queue response becomes
  0x1205, no host job publishes,64 owner allocations remain unchanged and the
  independent expected0x1100 guard/ring oracle fails. The normal source remains
  untouched and the served mutation's body/digest is retained.

No production capabilities, scanout, Linux guest execution or throughput is
predicted. Held facts are carried only across matching code/dependency/evidence
identities; no unrelated gate or second pristine clone is planned.
