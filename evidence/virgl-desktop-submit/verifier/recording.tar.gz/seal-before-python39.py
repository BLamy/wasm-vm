#!/usr/bin/env python3
"""Seal full fresh verifier recordings and bind promoted test bodies to Git."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root=Path(__file__).resolve().parent
repo=root.parents[2]
destination=repo/'evidence/virgl-desktop-submit/verifier'
assert not destination.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head=='3aa457775627311bb517b1e35b53687cbae9f5b7'
paths=['renderer/virgl-command/tests/desktop-submit-acceptance.mjs',
       'renderer/virgl-command/tests/desktop-submit-critic.mjs','tools/virgl-desktop-submit/sources.json']
changed=subprocess.check_output(['git','diff','--name-only','75b6a0d7b01eb2885d497ef6a716b9baae6acd24',head],cwd=repo,text=True).splitlines()
assert sorted(changed)==sorted(paths)
bindings=[]
for path in paths:
    raw=(repo/path).read_bytes()
    assert raw==subprocess.check_output(['git','show',f'{head}:{path}'],cwd=repo)
    assert raw==(root/'promoted-harness/source'/path).read_bytes()
    assert raw==(root/'exact-head-regression/source'/path).read_bytes()
    bindings.append({'path':path,'bytes':len(raw),'sha256':sha(raw)})
exact=json.loads((root/'exact-head-regression/report.json').read_bytes())
assert exact['gitHead']==head and not exact['trackedChanges'] and exact['status']=='passed'
assert exact['browserResult']['result']['critic']['assertions']==2784
harness=json.loads((root/'promoted-harness/report.json').read_bytes())
assert harness['status']=='passed' and harness['browserResult']['result']['critic']['status']=='passed'
# The full promoted harness ran before its commit, with precisely these tested
# overlay bodies; exact-head regression reopens the same bodies at the Git head.
source_binding={'sourceHead':head,'runtimeSubmissionHead':'75b6a0d7b01eb2885d497ef6a716b9baae6acd24',
    'sourceChanges':bindings,'fullHarnessRecordedHead':harness['gitHead'],
    'fullHarnessRecordedOverlay':harness['trackedChanges'],'exactHeadRegression':exact['gitHead']}
(root/'source-bindings.json').write_text(json.dumps(source_binding,indent=2)+'\n')
index_paths={str(p.relative_to(root)):p for p in root.rglob('*') if p.is_file()
    and p.relative_to(root).parts[0]!='worker' and p.name not in {'seal.stdout','seal.stderr'}}
rows=[]
for name,path in sorted(index_paths.items()):
    raw=path.read_bytes();rows.append({'path':name,'bytes':len(raw),'sha256':sha(raw)})
index={'schema':'desktop-submit-verifier-index-v1','task':'E6-T11d52','head':head,'records':rows}
index_raw=(json.dumps(index,indent=2)+'\n').encode()
destination.mkdir(parents=True)
(destination/'records.json').write_bytes(index_raw)
archive=destination/'recording.tar.gz'
with archive.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as zipped,tarfile.open(fileobj=zipped,mode='w|') as packed:
    for row in rows:
        raw=index_paths[row['path']].read_bytes()
        assert (len(raw),sha(raw))==(row['bytes'],row['sha256'])
        info=tarfile.TarInfo(row['path']);info.size=len(raw);info.mode=0o644;info.mtime=0
        packed.addfile(info,io.BytesIO(raw))
reopened=0
with tarfile.open(archive,'r|gz') as packed:
    for member,row in zip(packed,rows,strict=True):
        assert member.isfile() and member.name==row['path']
        raw=packed.extractfile(member).read();assert (len(raw),sha(raw))==(row['bytes'],row['sha256'])
        reopened+=1
assert reopened==len(rows)
authentication=json.loads((root/'authentication.json').read_bytes())
manifest={'schema':'desktop-submit-verifier-seal-v1','task':'E6-T11d52','verdict':'verified','head':head,
    'submissionHead':'75b6a0d7b01eb2885d497ef6a716b9baae6acd24','base':'0660eebf08a1b047109ed4e2e508132b68d103ba',
    'authoritativeColdHead':'17433963c8f2489598841bb648dfbe26287dbfb7','sourceBindings':source_binding,
    'records':len(rows),'reopenedMembers':reopened,'recordIndexSha256':sha(index_raw),
    'archiveSha256':sha(archive.read_bytes()),'archiveBytes':archive.stat().st_size,
    'decodedBytes':sum(r['bytes'] for r in rows),'predictionsSha256':sha((root/'predictions.md').read_bytes()),
    'workerSeal':authentication['worker'],'dependencySeals':authentication['dependencies'],
    'authenticatedDependencyBodies':authentication['completeDependencies'],
    'workerBodiesLocation':'evidence/virgl-desktop-submit/worker/recording.tar.gz; cold/recording is authoritative',
    'freshSchedules':[0x9135,0xbf02,0x764d],'freshFullPlanes':3,'freshPixels':3072,
    'nativeCoverageBodyLines':13,'jsCoveredDynamicTokens':30,'promotedTestAssertions':2784,
    'independentSnapshotSabotages':2,'guestExecution':False,'productionAuthority':False}
(destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'head':head,'records':len(rows),'manifestSha256':sha((destination/'manifest.json').read_bytes()),
    'indexSha256':manifest['recordIndexSha256'],'archiveSha256':manifest['archiveSha256'],'archiveBytes':manifest['archiveBytes']}))
