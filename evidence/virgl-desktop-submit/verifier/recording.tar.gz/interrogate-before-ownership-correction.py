#!/usr/bin/env python3
"""Independent state, digest, source, and coverage interrogation after predictions."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess

out = Path(__file__).resolve().parent
repo = out.parents[2]
root = out / 'worker/cold/recording'
base = '0660eebf08a1b047109ed4e2e508132b68d103ba'
submission = '75b6a0d7b01eb2885d497ef6a716b9baae6acd24'
sha = lambda b: hashlib.sha256(b).hexdigest()
points = []

def origin(path, text=None, pointer=None):
    raw = path.read_bytes()
    value = {'archivePath': str(path.relative_to(out / 'worker')), 'sha256': sha(raw)}
    if text is not None:
        value['line'] = raw[:raw.index(text.encode())].count(b'\n') + 1
    if pointer:
        value['jsonPointer'] = pointer
    return value

def hold(prediction, observed, citation):
    points.append({'prediction': prediction, 'result': 'HELD', 'observed': observed, 'citation': citation})

def ctl(encoded):
    raw = bytes.fromhex(encoded); assert raw[:8] == b'WV3DCTL2'
    cursor = 8
    def take(fmt):
        nonlocal cursor
        value = struct.unpack_from('<' + fmt, raw, cursor)
        cursor += struct.calcsize('<' + fmt)
        return value[0] if len(value) == 1 else value
    fields = dict(zip(['epoch','nextGeneration','nextBacking','logicalBytes','gpuBytes','backingBytes'],take('6Q')))
    fields['poisoned'] = take('B'); contexts = []
    for _ in range(take('I')):
        identity = take('IQ'); size = take('I'); name = raw[cursor:cursor+size]; cursor += size
        contexts.append({'identity': identity, 'name': name.hex(), 'members': [take('IQ') for _ in range(take('I'))]})
    resources = []
    for _ in range(take('I')):
        identity = take('IQ'); metadata = take('11I'); has_backing = take('B'); backing = None
        if has_backing:
            backing = {'generation': take('Q'), 'entries': [take('QI') for _ in range(take('I'))]}
        resources.append({'identity': identity, 'metadata': metadata, 'backing': backing})
    assert cursor == len(raw)
    return {**fields, 'contexts': contexts, 'resources': resources}

native_path = root / 'native-submit.stderr'
lines = native_path.read_text().splitlines()
records = [(i + 1,json.loads(l.split(' ',1)[1])) for i,l in enumerate(lines) if l.startswith('SUBMIT3D_PORTABLE_RECORD ')]
selected = [(i,r) for i,r in records if r['case'].startswith('desktop-')]
assert len(selected) == 132
for line,row in records:
    for canonical,digest in [('transportCanonical','transportDigest'),('submitCanonical','submitDigest')]:
        assert sha(bytes.fromhex(row[canonical])) == row[digest], (line,canonical)
for line,row in selected:
    state = ctl(row['transportCanonical'])
    assert state['logicalBytes'] == state['gpuBytes'] == len(state['resources']) * 16
    assert [r['identity'][0] for r in state['resources']] == list(range(100,100+len(state['resources'])))
    assert all(r['metadata'] == (r['identity'][0],0,64,16,16,1,1,1,0,0,0) and r['backing'] is None for r in state['resources'])
refuse_line,refuse = next(r for r in selected if r[1]['case']=='desktop-refuse65')
begin_line,begin = next(r for r in selected if r[1]['case']=='desktop-begin64')
finish_line,finish = next(r for r in selected if r[1]['case']=='desktop-finish64')
assert int.from_bytes(bytes.fromhex(refuse['response'])[:4],'little') == 0x1201
assert selected[-4][1]['transportCanonical'] == refuse['transportCanonical'] == begin['transportCanonical'] == finish['transportCanonical']
assert begin['response'] == 'a5'*24 and begin['usedIndex']==130
assert bytes.fromhex(begin['submitCanonical'])[96] == 1
assert finish['usedIndex']==131 and bytes.fromhex(finish['submitCanonical'])[96] == 0
assert finish['response']=='0011000001000000ffffffffffffffff0200000000000000'
guard_points=[(i+1,json.loads(l.split(' ',1)[1])) for i,l in enumerate(lines) if l.startswith('DESKTOP_SUBMIT_POINT ')]
assert len(guard_points)==132 and all(p['guard']=='a5'*40 and len(p['machineDigest'])==64 for _,p in guard_points)
traces=[(i+1,l) for i,l in enumerate(lines) if l.startswith('SUBMIT3D_GUEST_TRACE ')]
assert len(traces)==657 and all(l=='SUBMIT3D_GUEST_TRACE core 0: 0x0000000080200000 (0x0000006f)' for _,l in traces)
assert not any('panicked at' in l for l in lines)
hold('P3', {'nativeResources':64,'independentBytes':1024,'refusal':0x1201,'usedBefore':begin['usedIndex'],'usedAfter':finish['usedIndex'],'guardPoints':132,'retiredGuestLoopInstructions':657}, [origin(native_path,'"case":"desktop-refuse65"'),origin(native_path,'"case":"desktop-begin64"'),origin(native_path,'"case":"desktop-finish64"')])

report_path=root/'hardware/report.json'; report=json.loads(report_path.read_bytes()); result=report['browserResult']['result']
assert report['status']=='passed' and not report['trackedChanges'] and report['browserErrors']=={'console':[],'page':[],'requests':[]}
assert 'Metal' in result['gpu'] and not result['guestExecution'] and not result['productionNegotiation']
for row in result['lifetimes']:
    model={}; expected_count={'compositor':56,'kmscube':8,'glmark2-es2':34}[row['name']]
    assert len(row['steps'])==expected_count
    for step in row['steps']:
        event=step['originalEnter']; ret=step['originalReturn']; assert ret['callSeq']==event['seq'] and ret['result']==0
        expected=0x1205 if event.get('format')==17 else 0x1100
        assert int.from_bytes(bytes.fromhex(step['record']['response'])[:4],'little')==expected
        if expected==0x1100:
            if event['type']=='resource_create':
                model[event['resourceId']]=event
            else:
                del model[event['resourceId']]
        after=step['after']; native=after['native']; host=after['host']
        assert sorted(model)==sorted(r['identity']['id'] for r in native['resources'])==sorted(r['transport']['id'] for r in host['resources'])
        logical=sum(e['width'] if e['target']==0 else e['width']*e['height']*4 for e in model.values())
        gpu=sum((0 if e['bind']==524288 else e['width']) if e['target']==0 else e['width']*e['height']*4 for e in model.values())
        assert native['logicalBytes']==logical and native['gpuBytes']==host['store']['budgets']['gpuBytes']==gpu
        for r in native['resources']:
            source=model[r['identity']['id']]
            assert r['metadata']=={key:(source['resourceId'] if key=='id' else source[key]) for key in r['metadata']}
            assert next(h for h in host['resources'] if h['transport']['id']==r['identity']['id'])['transport']==r['identity']
        if expected==0x1205:
            assert event['seq']==3025 and step['before']==after
    hold('P2',{'name':row['name'],'controls':len(row['steps']),'peak':row['peak'],'refusal':row['refusal'],'finalIDs':sorted(model)},origin(report_path,'"case": "'+row['steps'][-1]['record']['case']+'"'))
assert len(result['owners']['accepted']['resources'])==64
assert [r['identity']['id'] for r in result['owners']['accepted']['resources']]==list(range(100,164))
historical=result['owners']['historical']; legacy_event=next(e for e in historical['events'] if e['type']=='beginJob')
assert len(legacy_event['resources'])==16
assert int.from_bytes(bytes.fromhex(next(r['response'] for r in historical['records'] if r['case']=='historical16 accepted snapshot'))[:4],'little')==0x1100
assert any(a['name']=='historical job refuses17 before renderer' for a in result['attacks'])
hold('P4',{'actualHistoricalOwners':16,'historical17Refusal':True,'selected64Owners':64},origin(report_path,'"case": "historical16 accepted snapshot"'))
colors=[bytes(v) for v in [[255,0,0,255],[0,255,0,255],[0,0,255,255],[255,255,0,255]]]
expected=b''.join(colors[(y>=16)*2+(x>=16)] for y in range(32) for x in range(32))
for schedule in result['schedules']:
    original=schedule['original']; assert original['gpuDraws']==3 and original['packetCount']==210
    plane=bytes.fromhex(next(e['bytes'] for e in original['exchanges'] if e['kind']=='output' and len(e['bytes'])==8192))
    assert plane==expected
hold('P7',{'schedules':[v['seed'] for v in result['schedules']],'draws':9,'literalPixels':3072,'fullPlaneSha256':sha(expected),'nativeCalls':len(result['nativeCalls'])},origin(report_path,pointer='/browserResult/result/schedules'))
assert 'finish' not in [v['name'] for v in result['nativeCalls']]
assert result['failure']['completion'][3:5]==[6,False]
assert any(a['name']=='trusted WAIT_FAILED on actual fence' for a in result['attacks'])
assert any(r['case']=='new epoch job' for r in result['protocol']['records'])
assert any(r['case']=='selected survives reset depth' for r in result['owners']['records'])
hold('P8',{'uncertainCompletion':result['failure']['completion'],'resetSelectedDepth':True,'pendingResetRecovery':True},origin(report_path,'"case": "trusted wait failure on actual final fence"'))

coverage=json.loads((root/'native-coverage.json').read_bytes())
native_files={Path(f['filename']).as_posix():f for d in coverage['data'] for f in d['files']}
recorded=json.loads((root/'changed-coverage.json').read_bytes())
assert len(recorded['runtimeLines'])==13 and not recorded['uncoveredOperands']
verified_native=[]
for row in recorded['runtimeLines']:
    file=next(f for p,f in native_files.items() if p.endswith('/'+row['path']))
    for operand in row['operands']:
        active=[s for s in file['segments'] if (s[0],s[1])<=(row['line'],operand['column'])]
        actual=active[-1]; assert actual==operand['segment'] and actual[2]>0 and actual[3] and not actual[5]
    verified_native.append({'path':row['path'],'line':row['line'],'counts':[o['count'] for o in row['operands']]})
js_cov=json.loads((root/'hardware/browser-coverage.json').read_bytes())
script=next(s for s in js_cov['scripts'] if s['source']=='renderer/virgl-command/control-bridge.mjs')
source=(repo/script['source']).read_text(); assert sha(source.encode())==script['sha256']
previous=subprocess.check_output(['git','show',f'{base}:{script["source"]}'],cwd=repo,text=True)
changed=[(a,b) for tag,_,_,a,b in difflib.SequenceMatcher(None,previous,source,autojunk=False).get_opcodes() if tag in ['replace','insert']]
ranges=[r for f in script['coverage']['functions'] for r in f['ranges']]
js_operands=[]
for token in re.finditer(r'[A-Za-z_$][\w$]*|\d+',source):
    if not any(token.start()<b and token.end()>a for a,b in changed):continue
    start=source.rfind('\n',0,token.start())+1;line=source[start:source.find('\n',token.start())]
    if line.strip().startswith(('import ','//','/**','*')):continue
    enclosing=[r for r in ranges if r['startOffset']<=token.start()<r['endOffset']]
    segment=min(enclosing,key=lambda r:r['endOffset']-r['startOffset']);assert segment['count']>0
    js_operands.append({'line':source.count('\n',0,token.start())+1,'token':token.group(),'count':segment['count']})
assert len(js_operands)==30
old_wasm=subprocess.check_output(['git','show',f'{base}:crates/wasm/src/virgl_control_proof.rs'],cwd=repo,text=True)
new_wasm=(repo/'crates/wasm/src/virgl_control_proof.rs').read_text()
old_body=old_wasm[old_wasm.index('        let mut machine = Machine::new(RAM_BYTES);',old_wasm.index('impl WasmVirglSubmitProof')):old_wasm.index('\n    pub fn layout',old_wasm.index('impl WasmVirglSubmitProof'))]
new_body=new_wasm[new_wasm.index('        let mut machine = Machine::new(RAM_BYTES);',new_wasm.index('fn assemble')):]
for line in old_body.splitlines():
    assert line in new_body, ('non-identical moved operand',line)
hold('P9',{'nativeChangedBodyLines':verified_native,'nativeStaticWaivers':len(recorded['waivers']),'changedJsDynamicTokens':js_operands,'movedWasmBody':'every original moved line remains byte-equal; selected/true/false branches have concrete queue outcomes'},[origin(root/'native-coverage.json'),origin(root/'hardware/browser-coverage.json')])

deployment=repo/'evidence/virgl-desktop-submit/deployment'
manifest_raw=(deployment/'manifest.json').read_bytes();manifest=json.loads(manifest_raw)
assert sha(manifest_raw)=='4d83b3a3f6cc71db035cdfb032e750debbf7ca79995a5dbae9ffd2eb8d3478ee'
for relative,pin in manifest['files'].items():
    raw=(deployment/relative).read_bytes();assert (len(raw),sha(raw))==(pin['bytes'],pin['sha256'])
live=json.loads((deployment/'final/report.json').read_bytes())
local=json.loads((root/'default-demo/report.json').read_bytes())
for page in [live,local]:
    assert page['status']=='passed' and page['passed']==127 and page['failed']==0 and page['proofExportAbsent'] and not page['errors']
    assert 'live' in page['roadmapPip'] and 'partial' in page['graphicsRoadmapPip']
assert live['servedWasmSha256']==sha((repo/'web/dist/pkg/wasm_vm_wasm_bg.wasm').read_bytes())=='62a698e3570534437f5d668885b8df2b6a03d6d01e6081814ae1654b22e3230a'
hold('P10',{'cold':'clean scrubbed exact17433963;25 scoped passing commands','live127':live['passed'],'failed':live['failed'],'proofAbsent':live['proofExportAbsent'],'servedWasmSha256':live['servedWasmSha256']},[origin(root/'receipt.json'),{'path':'evidence/virgl-desktop-submit/deployment/final/report.json','sha256':sha((deployment/'final/report.json').read_bytes()),'line':1}])
with (out/'held-points.jsonl').open('w') as stream:
    for point in points:stream.write(json.dumps(point,separators=(',',':'))+'\n')
print(json.dumps({'heldPredictions':len(points),'nativeDigestsChecked':len(records)*2,'coverageNativeLines':13,'coverageJsTokens':30,'fullPlaneSha256':sha(expected)}))
