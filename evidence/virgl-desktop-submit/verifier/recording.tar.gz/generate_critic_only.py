#!/usr/bin/env python3
from pathlib import Path

here = Path(__file__).resolve().parent
source = (here / 'browser-critic.mjs').read_text()
anchor = "        const result = await runDesktopAcceptance({ WasmVirglSubmitProof: wasm.WasmVirglSubmitProof, createVirglControlBridge, createVirglSubmitBridge, createVirglStandardDesktopSubmitBridge, inputs:await fetch('/inputs.json').then(r=>r.json()), fixtures: await fetch('/fixtures.json').then(r=>r.json()), wasmMemory: exports.memory });"
assert source.count(anchor) == 1
source = source.replace(anchor, "        const result = {status:'passed',summary:{status:'passed',purpose:'fresh promoted critic regression'}};")
source = source.replace('schedule:0xa937', 'schedule:0x5af3')
(here / 'browser-critic-only.mjs').write_text(source)
