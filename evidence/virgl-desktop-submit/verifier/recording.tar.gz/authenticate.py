#!/usr/bin/env python3
"""Fresh full-body streaming authentication; archives are never random-seeked."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

repo = Path(__file__).resolve().parents[3]
out = Path(__file__).resolve().parent
base = '0660eebf08a1b047109ed4e2e508132b68d103ba'
sha = lambda b: hashlib.sha256(b).hexdigest()

def digest_file(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def reopen(directory, expected_manifest=None, extract=None, interested=()):
    manifest_raw = (directory / 'manifest.json').read_bytes()
    manifest = json.loads(manifest_raw)
    index_raw = (directory / 'records.json').read_bytes()
    index = json.loads(index_raw)
    rows = index['records'] if isinstance(index, dict) else index
    archive = directory / 'recording.tar.gz'
    assert expected_manifest is None or sha(manifest_raw) == expected_manifest
    assert sha(index_raw) == manifest['recordIndexSha256']
    assert digest_file(archive) == manifest['archiveSha256']
    expected = {row['path']: row for row in rows}
    assert len(expected) == len(rows)
    hashes, links, retained = {}, {}, {}
    with tarfile.open(archive, 'r|gz') as packed:
        for member in packed:
            name = member.name
            assert name in expected and name not in hashes and name not in links
            p = Path(name)
            assert not p.is_absolute() and '..' not in p.parts
            if member.isfile():
                raw = packed.extractfile(member).read()
                hashes[name] = (len(raw), sha(raw))
                if name in interested:
                    retained[name] = raw
                if extract:
                    dest = extract / name
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_bytes(raw)
            else:
                assert member.islnk(), (name, member.type)
                link = Path(member.linkname)
                assert not link.is_absolute() and '..' not in link.parts
                links[name] = member.linkname
    assert set(hashes) | set(links) == set(expected)
    def resolve(name, visiting=frozenset()):
        if name in hashes:
            return hashes[name]
        assert name in links and name not in visiting, ('unknown/cyclic hardlink', name)
        value = resolve(links[name], visiting | {name})
        hashes[name] = value
        if extract:
            (extract / name).parent.mkdir(parents=True, exist_ok=True)
            (extract / name).write_bytes((extract / links[name]).read_bytes())
        return value
    for name, row in expected.items():
        assert resolve(name) == (row['bytes'], row['sha256']), name
    return {'manifestSha256': sha(manifest_raw), 'indexSha256': sha(index_raw),
            'archiveSha256': manifest['archiveSha256'], 'records': len(rows),
            'completeBytes': sum(row['bytes'] for row in rows), 'hardlinks': len(links)}, retained

worker = repo / 'evidence/virgl-desktop-submit/worker'
worker_meta, _ = reopen(worker, 'b214d4b6e6e777e979e0de709c4bf29e8d35159cf370c1e259b2bea8e632e64f', out / 'worker')
assert worker_meta['indexSha256'] == 'a18a823a7e1b0cdcdbb4f9ba11abd5e01ddb7d93334a1cbdad3611bb505ed61c'
assert worker_meta['archiveSha256'] == 'dd08f3e7f8446276c006034fae32fc0c9aada49b13030f6d4969bbd0a1d13c7b'
dependencies, carried, compiler = [], {}, {}
for family in ['virgl-resource-capacity', 'virgl-desktop-control', 'virgl-shadow-samplers']:
    for role in ['worker', 'verifier']:
        directory = repo / 'evidence' / family / role
        manifest_raw = (directory / 'manifest.json').read_bytes()
        assert manifest_raw == subprocess.check_output(['git', 'show', f'{base}:evidence/{family}/{role}/manifest.json'], cwd=repo)
        interested = ['hot/receipt.json'] if family == 'virgl-resource-capacity' and role == 'worker' else []
        if family == 'virgl-shadow-samplers' and role == 'worker':
            interested += ['cold-generated/renderer/virgl-shader/build/wasm/virgl-shader.mjs',
                           'cold-generated/renderer/virgl-shader/build/wasm/virgl-shader.wasm']
        meta, kept = reopen(directory, interested=interested)
        dependencies.append({'family': family, 'role': role, **meta})
        if 'hot/receipt.json' in kept:
            held = json.loads(kept['hot/receipt.json'])
            carried = {**held['sources'], **held['carriedSources']}
            (out / 'held-storage-receipt.json').write_bytes(kept['hot/receipt.json'])
        for name, raw in kept.items():
            if name.startswith('cold-generated/'):
                compiler[name.removeprefix('cold-generated/')] = sha(raw)
        print(f'{family}/{role}: {meta["records"]} full bodies authenticated', flush=True)
assert len(compiler) == 2
for relative, digest in compiler.items():
    assert digest_file(repo / relative) == digest, relative
pins = {p: d for p, d in carried.items() if p.startswith('renderer/') and p not in {
    'renderer/virgl-command/control-bridge.mjs', 'renderer/virgl-command/tests/submit-acceptance.mjs'}}
for relative, digest in pins.items():
    assert digest_file(repo / relative) == digest, relative
for relative in ['crates/core/src/dev/virtio/gpu/control3d.rs', 'crates/core/src/dev/virtio/gpu/submit3d.rs']:
    pins[relative] = sha(subprocess.check_output(['git', 'show', f'{base}:{relative}'], cwd=repo))
    assert digest_file(repo / relative) == pins[relative]
cold = out / 'worker/cold'
receipt_raw = (cold / 'recording/receipt.json').read_bytes()
receipt = json.loads(receipt_raw)
report = json.loads((cold / 'report.json').read_bytes())
assert sha(receipt_raw) == report['receiptSha256'] == '1813019b7977834e2ebc16ed5a07668947879610734e3a2479a4365a94b2b195'
assert report['head'] == receipt['head'] == '17433963c8f2489598841bb648dfbe26287dbfb7'
assert not report['cleanBefore'] and not report['cleanAfter'] and report['exitCode'] == 0
assert len(receipt['commands']) == 25
assert all(c['exitCode'] == c['expected'] for c in receipt['commands'])
for relative, pin in receipt['sources'].items():
    raw = (cold / 'recording/sources' / relative).read_bytes()
    assert (len(raw), sha(raw)) == (pin['bytes'], pin['sha256'])
    assert raw == subprocess.check_output(['git', 'show', f'{receipt["head"]}:{relative}'], cwd=repo), relative
    if relative != 'tools/virgl-desktop-submit/seal.py':
        assert raw == (repo / relative).read_bytes(), relative
current_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
changed = subprocess.check_output(['git', 'diff', '--name-only', receipt['head'], current_head], cwd=repo, text=True).splitlines()
summary = {'schema': 'desktop-submit-fresh-authentication-v1', 'submissionHead': current_head,
           'worker': worker_meta, 'dependencies': dependencies, 'heldRuntimePins': pins,
           'compilerPins': compiler, 'cold': report, 'coldCommands': receipt['commands'],
           'postRecordingFiles': changed, 'completeDependencies': sum(r['records'] for r in dependencies)}
(out / 'authentication.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'worker': worker_meta, 'heldBodies': summary['completeDependencies'],
                  'coldCommands': len(receipt['commands']), 'postRecordingFiles': changed}))
