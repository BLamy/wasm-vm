#!/usr/bin/env python3
from pathlib import Path

repo = Path(__file__).resolve().parents[3]
here = Path(__file__).resolve().parent
source = (repo / 'tools/virgl-desktop-submit/browser.mjs').read_text()
source = source.replace("from '../virgl-command/draw-fixtures.mjs'", "from '" + (repo / 'tools/virgl-command/draw-fixtures.mjs').as_uri() + "'")
source = source.replace("from '../virgl-command/fixtures.mjs'", "from '" + (repo / 'tools/virgl-command/fixtures.mjs').as_uri() + "'")
source = source.replace('const codePaths = JSON.parse(', "const codePaths = JSON.parse(")
source = source.replace('for(const input of drawInputs)', "codePaths.push('renderer/virgl-command/tests/desktop-submit-critic.mjs');\nfor(const input of drawInputs)")
anchor = '  const servedSources = new Map(sources);'
assert source.count(anchor) == 1
source = source.replace(anchor, anchor + '''
  const freshPath = 'renderer/virgl-command/tests/desktop-submit-acceptance.mjs';
  const oldSeeds = '[0x37a1,0x82cd,0xe419]', freshSeeds = '[0x9135,0xbf02,0x764d]';
  assert.equal(sources.get(freshPath).toString().split(oldSeeds).length, 2);
  const fresh = Buffer.from(sources.get(freshPath).toString().replace(oldSeeds, freshSeeds));
  servedSources.set(freshPath, fresh);
  report.freshSchedules = [0x9135,0xbf02,0x764d];
  report.freshServedSources = [{path:freshPath, originalSha256:sha256(sources.get(freshPath)), servedSha256:sha256(fresh)}];
  await fs.writeFile(path.join(output,'fresh-acceptance.mjs'),fresh);
''')
anchor = "        document.querySelector('#status').textContent = 'Passed: fresh DMA, ordered GPU completion and exact guest responses';"
assert source.count(anchor) == 1
source = source.replace(anchor, '''
        const { runDesktopSubmitCritic } = await import('/renderer/virgl-command/tests/desktop-submit-critic.mjs');
        result.critic = await runDesktopSubmitCritic({WasmVirglSubmitProof:wasm.WasmVirglSubmitProof,createVirglStandardDesktopSubmitBridge,createVirglSubmitBridge,schedule:0xa937});
''' + anchor)
source = source.replace('partial:window.__desktopProof??null, point:', 'partial:window.__desktopProof??null, critic:window.__desktopCritic??null, point:')
source = source.replace('    servedSources.set(filename, after);', "    servedSources.set(filename, after);\n    await fs.writeFile(path.join(output,'sabotage-control-bridge.mjs'),after);")
(here / 'browser-critic.mjs').write_text(source)
print('Generated full fresh browser critic runner with three fresh schedule seeds and novel owner64 regression.')
