#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path

out=Path(__file__).resolve().parent
repo=out.parents[2]
sha=lambda b:hashlib.sha256(b).hexdigest()
points=[]
def citation(path,needle=None,pointer=None):
    raw=path.read_bytes();value={'path':str(path.relative_to(out)),'sha256':sha(raw)}
    if needle:value['line']=raw[:raw.index(needle.encode())].count(b'\n')+1
    if pointer:value['jsonPointer']=pointer
    return value
def hold(prediction,observed,origin):
    points.append({'prediction':prediction,'result':'HELD','observed':observed,'citation':origin})
path=out/'fresh/report.json';report=json.loads(path.read_bytes());result=report['browserResult']['result']
assert report['status']=='passed' and report['browserErrors']=={'console':[],'page':[],'requests':[]}
feature=report['browser']['webglFeature'];assert report['browser']['gpu']['featureStatus'][feature]=='enabled'
assert not any(any(word in arg.lower() for word in ['swiftshader','llvmpipe','softpipe','lavapipe','--disable-gpu']) for arg in report['browser']['commandLine'])
assert [s['seed'] for s in result['schedules']]==[0x9135,0xbf02,0x764d]
source=(out/'fresh/source/renderer/virgl-command/tests/desktop-submit-acceptance.mjs').read_bytes()
served=(out/'fresh/fresh-acceptance.mjs').read_bytes()
assert served==source.replace(b'[0x37a1,0x82cd,0xe419]',b'[0x9135,0xbf02,0x764d]')
assert sha(served)==report['freshServedSources'][0]['servedSha256']
colors=[bytes(v) for v in [[255,0,0,255],[0,255,0,255],[0,0,255,255],[255,255,0,255]]]
expected=b''.join(colors[(y>=16)*2+(x>=16)] for y in range(32) for x in range(32))
for schedule in result['schedules']:
    original=schedule['original'];assert original['packetCount']==210 and original['gpuDraws']==3
    assert bytes.fromhex(next(e['bytes'] for e in original['exchanges'] if e['kind']=='output' and len(e['bytes'])==8192))==expected
assert not any(call['name']=='finish' for call in result['nativeCalls'])
assert result['failure']['completion'][3:5]==[6,False]
required=['selected accepted owner metadata','selected accepted owner generation','selected accepted owner foreign',
          'selected accepted owner backing','selected accepted owner count65','historical job refuses17 before renderer',
          'tightened selected refusal','stale resource generation rejected','trusted WAIT_FAILED on actual fence']
for label in required:assert any(a['name']==label for a in result['attacks']),label
hold('P5/P7/P8',{'freshSeeds':[s['seed'] for s in result['schedules']],'hardwareCalls':len(result['nativeCalls']),
    'assertions':result['assertions'],'literalPixels':3072,'planeSha256':sha(expected),'attacks':result['attacks'],
    'uncertainGPUResult':result['failure']['completion']},citation(path,pointer='/browserResult/result'))

path=out/'promoted-exact/report.json';report=json.loads(path.read_bytes());critic=report['browserResult']['result']['critic'];owner=critic['ownership']
assert report['status']=='passed' and critic['status']=='passed' and report['browserErrors']=={'console':[],'page':[],'requests':[]}
assert sha((out/'promoted-exact/source/renderer/virgl-command/tests/desktop-submit-critic.mjs').read_bytes())==sha((repo/'renderer/virgl-command/tests/desktop-submit-critic.mjs').read_bytes())
assert critic['disabled']['native'] is None and critic['disabled']['submit'] is None and not critic['disabled']['events']
assert critic['disabled']['records'][0]['response']=='001200000000000000000000000000000200000000000000'
for mismatch in critic['mismatchedSelections']:
    assert mismatch['before']['native']==mismatch['after']['native'] and mismatch['before']['host']==mismatch['after']['host']
    assert len(mismatch['after']['host']['resources'])==16
    assert int.from_bytes(bytes.fromhex(next(r['response'] for r in mismatch['records'] if r['case'].endswith('refuse17')))[:4],'little')==0x1201
assert len(owner['accepted']['resources'])==64 and not owner['mutatedCallback']['resources']
assert owner['mutatedCallback']['context']['id']==999 and owner['mutatedCallback']['transfer']['resourceId']==999
first=next(r for r in owner['records'] if r['case']=='critic64 upload owns immutable source')
assert first['response']=='001100000100000031000000000020000200000000000000'
assert owner['originalWire']!=owner['mutatedWire']
old=bytes([2,31,71,109,149,181,223,251]);new=bytes([241,211,173,137,103,67,29,3])
assert owner['literalOldBytes']==old.hex() and owner['literalNewBytes']==new.hex()
assert [e['bytes'] for e in owner['exchanges']]==[old.hex(),old.hex(),new.hex(),new.hex()]
assert owner['oldIdentity']=={'id':163,'generation':'0000000000000041'}
assert owner['newIdentity']=={'id':163,'generation':'0000000000000042'}
assert len(owner['native']['resources'])==len(owner['host']['resources'])==64
assert all(r['identity']==next(h['transport'] for h in owner['host']['resources'] if h['transport']['id']==r['identity']['id']) for r in owner['native']['resources'])
assert owner['host']['pending'] is None and len(owner['machineDigest'])==64
for key in ['transport','submit']:
    for r in owner['records']:assert sha(bytes.fromhex(r[key+'Canonical']))==r[key+'Digest']
hold('P4/P6',{'disabledResponse':critic['disabled']['records'][0]['response'],'mismatchOwners':[16,16],
    'actualAcceptedOwners':64,'mutatedEnvelopeOwners':0,'exactOriginalFenceResponse':first['response'],
    'literalExchanges':[e['bytes'] for e in owner['exchanges']],'oldIdentity':owner['oldIdentity'],
    'newIdentity':owner['newIdentity'],'nativeHostOwners':64,'assertions':critic['assertions'],'nativeCalls':len(critic['nativeCalls'])},citation(path,'"case": "critic64 upload owns immutable source"'))

for name in ['sabotage','promoted-oracle-sabotage']:
    path=out/name/'report.json';report=json.loads(path.read_bytes());point=report['browserResult']['point']
    assert report['status']=='failed' and report['browserResult']['status']=='failed'
    message=report['browserResult']['error']['message'];assert 'exact fence response' in message and '00110000' in message and '05120000' in message
    assert len(point['events'][-1]['resources'])==64
    assert int.from_bytes(bytes(point['response'][:4]),'little')==0x1205
    assert point['response'][24:]==[0xa5]*40
    assert point['host']['pending'] is None and len(point['host']['resources'])==64
    original=(out/name/'source/renderer/virgl-command/control-bridge.mjs').read_bytes()
    served=(out/name/'sabotage-control-bridge.mjs').read_bytes()
    assert served==original.replace(b'normalizeJob(input, desktop ? 64 : 16)',b'normalizeJob(input, 16)')
    assert sha(served)==report['sabotage']['servedSha256']
    hold('P11',{'run':name,'independentOracleFailure':message,'receivedNativeOwners':64,'response':hex(0x1205),
        'guard':'a5'*40,'hostOwners':64,'hostPending':None,'servedFaultSha256':sha(served)},citation(path,'"message":'))
with (out/'fresh-points.jsonl').open('w') as f:
    for point in points:f.write(json.dumps(point,separators=(',',':'))+'\n')
print(json.dumps({'freshHardwareSchedules':3,'newTestAssertions':critic['assertions'],'snapshotSabotages':2,'promotedTestSha256':sha((repo/'renderer/virgl-command/tests/desktop-submit-critic.mjs').read_bytes())}))
