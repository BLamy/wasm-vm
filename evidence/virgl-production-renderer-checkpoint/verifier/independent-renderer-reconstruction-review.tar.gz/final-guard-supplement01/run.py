from pathlib import Path
import subprocess,json,time,hashlib
out=Path(__file__).resolve().parent
plan=json.loads((out/'plan.json').read_text());report={'scope':plan['scope'],'status':'running','commands':[]}
try:
 for item in plan['commands']:
  start=time.time()
  with (out/(item['name']+'.stdout')).open('wb')as stdout,(out/(item['name']+'.stderr')).open('wb')as stderr:
   result=subprocess.run(item['cmd'],stdout=stdout,stderr=stderr,timeout=180)
  report['commands'].append({'name':item['name'],'command':item['cmd'],'exitCode':result.returncode,'seconds':time.time()-start})
  assert result.returncode==0,item['name']
 report['status']='passed'
finally:
 report['files']=[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(out.rglob('*'))if p.is_file()and p.name!='report.json']
 (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['status'])
