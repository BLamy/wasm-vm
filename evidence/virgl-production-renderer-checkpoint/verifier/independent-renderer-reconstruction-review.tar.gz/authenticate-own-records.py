from pathlib import Path
import json,gzip,hashlib,datetime
root=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
expected={'novel01':'passed','epoch-healthy01':'passed','epoch-negative01':'failed','corrupt-frame01':'passed','abort-activation01':'failed','abort-activation02':'failed','abort-activation-fixed03':'passed','loss-during-save01':'passed','save-mutation-race01':'failed','save-mutation-race02':'passed','promoted-all01':'passed'}
records=[]
for name,status in expected.items():
 directory=root/name; raw=(directory/'report.json').read_bytes();report=json.loads(raw);assert report['status']==status,(name,report['status'])
 sourcepins={entry['path']:entry for entry in report['sources']}
 for rel,pin in sourcepins.items():
  b=(directory/'source'/rel).read_bytes();assert len(b)==pin['bytes'] and sha(b)==pin['sha256'],(name,rel)
 for pin in report['served']:
  if pin['path']=='/':continue
  original=sourcepins[pin['path'].lstrip('/')];assert pin['bytes']==original['bytes'] and pin['sha256']==original['sha256']
 for field in ['browserCoverage','screenshot']:
  pin=report[field];assert sha((directory/pin['path']).read_bytes())==pin['sha256']
 rows=[]
 for pin in report['runs']:
  packed=(directory/pin['path']).read_bytes();assert len(packed)==pin['gzipBytes'] and sha(packed)==pin['gzipSha256']
  data=gzip.decompress(packed);assert len(data)==pin['bytes'] and sha(data)==pin['sha256'];row=json.loads(data)
  rows.append({'path':pin['path'],'sha256':pin['sha256'],'name':row['name'],'status':row['status'],'assertions':row['assertions'],'ownersAfter':row['ownersAfter'],'failure':row.get('failure',{}).get('message')})
 if status=='passed':assert all(row['status']=='passed' for row in rows) and all(not v for v in report['browserErrors'].values())
 records.append({'directory':name,'status':report['status'],'reportSha256':sha(raw),'sourcePins':len(sourcepins),'serverDeliveryPins':len(report['served']),'rows':rows,'browserErrors':report['browserErrors']})
output={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'custody':'HELD','stage':'Independent pre-freeze components only; no task verdict or warm-worker claim','records':records,'preservedNegatives':{'epoch-negative01':'Intended single-hunk in-memory graphics control: stale epoch incorrectly accepted.','abort-activation01':'Actual14-object leak before runtime repair.','abort-activation02':'Same concrete leak reproduced independently.','save-mutation-race01':'Harness attached rejection handler too late; product refused capture correctly, but outer failed unhandled page rejection. Corrected test only in02.'}}
(root/'own-record-authentication.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({'custody':output['custody'],'recordings':len(records),'rows':sum(len(r['rows']) for r in records),'sourcePinsChecked':sum(r['sourcePins'] for r in records),'preservedNegatives':list(output['preservedNegatives'])},indent=2))
