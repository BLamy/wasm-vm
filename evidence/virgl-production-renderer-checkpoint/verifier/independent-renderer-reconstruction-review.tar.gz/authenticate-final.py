from pathlib import Path,PurePosixPath
import json,tarfile,hashlib,gzip,subprocess,datetime
root=Path(__file__).resolve().parent
repo=root.parents[2]
archive=repo/'evidence/virgl-production-renderer-checkpoint/worker/physical-renderer-reconstruction-submission.tar.gz'
sha=lambda b:hashlib.sha256(b).hexdigest()
frozen='d38bec548bf0884067d639c7e13b1798b75d483c'
assert archive.stat().st_size==20019730 and sha(archive.read_bytes())=='69e04e2d872fd3915c1aaa978d67885dc5d8489565078811e13166c486cc210e'
with tarfile.open(archive) as tar:
 members=tar.getmembers();assert len(members)==589 and len({m.name for m in members})==589
 for member in members:assert member.isfile() and not PurePosixPath(member.name).is_absolute() and '..'not in PurePosixPath(member.name).parts
 get=lambda name:tar.extractfile(name).read()
 identities=json.loads(get('identities.json'))['files'];assert len(identities)==588 and {x['path']for x in identities}=={m.name for m in members}-{'identities.json'}
 for pin in identities:
  b=get(pin['path']);assert len(b)==pin['bytes'] and sha(b)==pin['sha256'],pin['path']
 claim=json.loads(get('claim.json'));assert claim['head']==frozen and claim['runtimeHead']=='de33c99f'
 for name in claim['sourceChanges']:
  b=get('source/'+name);assert b==subprocess.check_output(['git','show',frozen+':'+name]),name
 cold=json.loads(get('cold01/report.json'));acceptance=json.loads(get('cold01/acceptance/report.json'));hot=json.loads(get('frozen01/report.json'))
 assert cold['status']=='passed' and cold['head']==frozen and '--no-local' in cold['cloneMethod']
 assert acceptance['status']=='passed' and acceptance['head']==frozen and [c['name'] for c in acceptance['commands']]==(['policy']+['syntax-'+str(i)for i in range(13)]+['portable-codec','proof-wasm','web-build','physical-checkpoint','independent-attacks','generation-negative','multisample-regression','default-browser'])
 assert all(c['exitCode']==c['expectedExitCode'] for c in acceptance['commands'])
 assert hot['status']=='failed' and hot['commands'][-1]['name']=='generation-negative' and hot['commands'][-1]['exitCode']==1
 for pin in acceptance['files']:
  b=get('cold01/acceptance/'+pin['path']);assert len(b)==pin['bytes'] and sha(b)==pin['sha256'],pin['path']
 browser=[]
 for name,expected,count in [('physical-checkpoint','passed',3),('independent-attacks','passed',6),('generation-negative','failed',1),('multisample-regression','passed',3)]:
  prefix='cold01/acceptance/'+name;report=json.loads(get(prefix+'/report.json'));assert report['status']==expected and report['head']==frozen
  assert len(report['runs'])==count and all(not v for v in report['browserErrors'].values())
  sourcepins={s['path']:s for s in report['sources']}
  for path,pin in sourcepins.items():
   b=get(prefix+'/source/'+path);assert len(b)==pin['bytes'] and sha(b)==pin['sha256'],(name,path)
   if path.startswith('renderer/') and '/build/'not in path and not(name=='generation-negative'and path.endswith('/control-bridge.mjs')):
    assert b==subprocess.check_output(['git','show',frozen+':'+path]),(name,path)
  for item in report['served']:
   if item['path']=='/':continue
   pin=sourcepins[item['path'].lstrip('/')];assert item['sha256']==pin['sha256'] and item['bytes']==pin['bytes']
  rows=[]
  for pin in report['runs']:
   packed=get(prefix+'/'+pin['path']);assert len(packed)==pin['gzipBytes'] and sha(packed)==pin['gzipSha256'];raw=gzip.decompress(packed);assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256'];row=json.loads(raw)
   if expected=='passed':assert row['status']=='passed'
   rows.append({'name':row['name'],'status':row['status'],'assertions':row.get('assertions'),'runSha256':pin['sha256']})
   if name=='generation-negative':
    assert row['failure']['message']=='stale expected epoch refuses rejected: expected false, got true'
    assert row['stale']['ok'] is True and row['after']['epoch']=='0000000000000003' and row['before']['epoch']=='0000000000000002'
    assert row['ownersAfter']=={'objects':0,'syncs':0}
  browser.append({'name':name,'status':report['status'],'sourcePins':len(sourcepins),'serverDeliveryPins':len(report['served']),'rows':rows})
 default=json.loads(get('cold01/acceptance/default-browser/report.json'))
 assert default['status']=='passed' and default['gitHead']==frozen and default['passed']==127 and default['failed']==0 and default['proofExportAbsent'] and default['errors']==[]
 for pin in default['served']:
  b=subprocess.check_output(['git','show',frozen+':'+pin['path']]);assert len(b)==pin['bytes'] and sha(b)==pin['sha256'],pin['path']
 assert default['servedWasmSha256']=='326dcb17f437069c1ecd3acf07912b4ef61013f08e8e05c3b108e2adbb59e358'
 clone=repo/'target/evidence/production-renderer-checkpoint-cold01/repo';assert not(clone/'.git/objects/info/alternates').exists()
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==frozen
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=clone)
 assert not subprocess.check_output(['git','diff','e26e3e83',frozen,'--','crates/core','crates/wasm'])
 assert not subprocess.check_output(['git','diff','de33c99f',frozen,'--','renderer','web','crates'])
 supplement=root/'final-guard-supplement01';s=json.loads((supplement/'report.json').read_text());assert s['status']=='passed' and len(s['commands'])==4 and all(c['exitCode']==0 for c in s['commands'])
 extra=json.loads((supplement/'browser/report.json').read_text());assert extra['status']=='passed' and len(extra['runs'])==4 and all(not x for x in extra['browserErrors'].values())
 for source in extra['sources']:
  if source['path'].startswith('renderer/')and '/build/'not in source['path']:assert sha(subprocess.check_output(['git','show',frozen+':'+source['path']]))==source['sha256']
 extras=[]
 for pin in extra['runs']:
  b=gzip.decompress((supplement/'browser'/pin['path']).read_bytes());assert sha(b)==pin['sha256'];r=json.loads(b);assert r['status']=='passed';extras.append({'name':r['name'],'assertions':r['assertions'],'refusal':(r.get('guardRefusal')or r.get('corruptRefusal')or{}).get('message'),'appliedPrefix':r.get('actualPrefix'),'runSha256':pin['sha256']})
 output={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'HELD','task':'E6-T11d74b','scope':'Physical renderer reconstruction only; paired worker/native GPU warm path74c and shipped Omarchy warm artifact/deployment74d remain unverified','workerCapsule':{'path':str(archive.relative_to(repo)),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(members),'identities':len(identities)},'acceptanceHead':frozen,'runtimeHead':'de33c99f','coldClone':{'head':frozen,'trackedClean':True,'alternates':False,'cloneMethod':cold['cloneMethod']},'coldCommands':acceptance['commands'],'acceptancePins':len(acceptance['files']),'sourceCopies':len(claim['sourceChanges']),'browser':browser,'default':{k:default[k]for k in ['passed','failed','proofExportAbsent','servedWasmSha256','errors']},'defaultSourcePins':len(default['served']),'supplement':{'reportSha256':sha((supplement/'report.json').read_bytes()),'commands':s['commands'],'rows':extras},'preservedNegatives':{'hotFrozen01':hot['failure'],'abortActivation':'Original two14-object leaks preserved; fixed cancellation observed zero owners.','self08':'Worker helper float-vs-word fixture error remains failed.','mutationRace01':'Own delayed rejection-handler harness error remains failed.'},'carry':'Native74a core/Wasm sources unchanged; de33 runtime unchanged through d38 and worker metadata. Only two test/harness files now differ for four missing guard cases.'}
 (root/'final-authentication.json').write_text(json.dumps(output,indent=2)+'\n')
 print(json.dumps({'status':output['status'],'capsuleMembers':len(members),'sourceCopies':len(claim['sourceChanges']),'coldGates':len(acceptance['commands']),'coldBrowserRows':sum(len(x['rows'])for x in browser),'default127':default['passed'],'supplementRows':len(extras),'supplementAssertions':sum(x['assertions']for x in extras)},indent=2))
