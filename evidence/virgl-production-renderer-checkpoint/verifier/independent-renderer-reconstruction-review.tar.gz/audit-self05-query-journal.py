from pathlib import Path
import json,gzip,hashlib,struct,datetime
root=Path(__file__).resolve().parent
repo=root.parents[2]
p=repo/'target/evidence/production-renderer-checkpoint-self05'
sha=lambda b:hashlib.sha256(b).hexdigest()
report=json.loads((p/'report.json').read_text());pin=report['runs'][0];z=(p/pin['path']).read_bytes();assert sha(z)==pin['gzipSha256'];raw=gzip.decompress(z);assert sha(raw)==pin['sha256'];row=json.loads(raw)
class Reader:
 def __init__(self,b):self.b=b;self.at=0;self.nodes=0
 def take(self,n):
  assert 0<=n<=len(self.b)-self.at
  result=self.b[self.at:self.at+n];self.at+=n;return result
 def count(self):return struct.unpack('<I',self.take(4))[0]
 def item(self,depth=0):
  self.nodes+=1;assert self.nodes<=1000000 and depth<=64
  tag=self.take(1)[0]
  if tag==0:return None
  if tag in (1,2):return tag==2
  if tag==3:return struct.unpack('<d',self.take(8))[0]
  if tag==4:return self.take(self.count()).decode('utf8')
  if tag==5:return self.take(self.count())
  if tag==6:
   count=self.count();assert count<=1000000 and count<=len(self.b)-self.at
   return [self.item(depth+1) for _ in range(count)]
  assert tag==7
  count=self.count();assert count<=1024
  result={};prior=None
  for _ in range(count):
   key=self.item(depth+1);assert isinstance(key,str) and (prior is None or key>prior);prior=key;result[key]=self.item(depth+1)
  return result
 def read(self):
  result=self.item();assert self.at==len(self.b);return result
artifact=bytes(row['checkpoint']['bytes']);assert artifact[:8]==b'WVGJRN01' and struct.unpack('<II',artifact[8:16])==(1,len(artifact)-48)
assert hashlib.sha256(artifact[:-32]).digest()==artifact[-32:]
assert sha(artifact)==row['checkpoint']['sha256']
payload=Reader(artifact[16:-32]).read();frames=[Reader(f).read() for f in payload['frames']]
query=[{'frame':i,'id':int(f['id']),'parameter':f['parameter'],'value':f['value']} for i,f in enumerate(frames)if f['op']=='query']
scatter=[]
for i,f in enumerate(frames):
 if f['op'].startswith('scatter'):
  scatter.append({'frame':i,'op':f['op'],'args':f['args'],'bytes':len(f['data']),'u32words':list(struct.unpack('<'+'I'*(len(f['data'])//4),f['data'])) if len(f['data'])<=16 and len(f['data'])%4==0 else None})
original=[(i,e)for i,e in enumerate(row['native'][0])if e['name']=='getQueryParameter']
fresh=[(i,e)for i,e in enumerate(row['native'][1])if e['name']=='getQueryParameter']
assert any(e['result'] is True and e.get('delivered') is False for _,e in original)
assert any(q['parameter']=='availability' and q['value'] is False for q in query)
assert any(q['parameter']=='availability' and q['value'] is True for q in query)
assert any(q['parameter']=='result' and q['value']==6 for q in query)
assert any(s['u32words']==[2,0,0,0] for s in scatter)
assert any(s['u32words']==[1,4,2,0] for s in scatter)
assert [q['value'] for q in query if q['parameter']=='result']==[6.0]
assert [e['result'] for _,e in fresh if e['args'][1]==34918]==[6,6]
assert row['beforeDispose']['renderer']['budgets']['queries']['nativeParts']==0
out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'HELD','scope':'Actual recorded WAIT -> ready replay timing and new physical TF query; no independent product verdict','workerRunSha256':pin['sha256'],'artifactSha256':sha(artifact),'artifactBytes':len(artifact),'queryFrames':query,'originalQueryReads':[{'eventIndex':i,**e}for i,e in original],'freshQueryReads':[{'eventIndex':i,**e}for i,e in fresh],'scatterFrames':scatter,'finalLogicalQuery':payload['logical']['queries'],'afterNewQueryOwners':row['beforeDispose']['renderer']['budgets']['queries'],'restore':row['restore'],'interpretation':'Native transform-feedback POINTS measurement6 divided by original triangle size3 yields logical2. Recorded false availability delays underlying actual ready measurements; replay never fabricates a true result. Fresh observation IDs are per-context labels, not shared handles.'}
(root/'self05-query-journal-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'artifactBytes':len(artifact),'journalFrames':len(frames),'queryFrames':query,'smallScatter':scatter,'nativeResultValues':[e['result']for _,e in original if e['args'][1]==34918],'freshResultValues':[e['result']for _,e in fresh if e['args'][1]==34918],'finalQueryOwners':out['afterNewQueryOwners']},indent=2))
