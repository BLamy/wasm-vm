// Independent original-MMIO checkpoint content/state probe. No transport substitution.
import {checker,makeRig,context,resource,idCommand,header,submission,backing,transfer} from '../../renderer/virgl-command/tests/submit-acceptance.mjs';
import {packet,join,shader,word} from '../virgl-command/standard-image-fixtures.mjs';
import {createVirglProductionBridge} from '../../renderer/virgl-command/control-bridge.mjs';
import {qualifyVirglHost,createWorkerScanoutPresenter} from '../../renderer/virgl-command/production.mjs';
import {createVirglStandardStreamOutputShaderBridge} from '../../renderer/virgl-shader/standard.mjs';
const copy=v=>JSON.parse(JSON.stringify(v,(_,x)=>ArrayBuffer.isView(x)?[...x]:typeof x==='bigint'?x.toString():x));
const vertex='VERT\nDCL IN[0]\nDCL OUT[0], POSITION\n0: MOV OUT[0], IN[0]\n1: END\n';
const fragment='FRAG\nDCL OUT[0], COLOR\nIMM[0] FLT32 {1,0,1,1}\n0: MOV OUT[0], IMM[0]\n1: END\n';
const draw=()=>packet(8,0,[0,4,5,0,1,0,0,0,0,0,0xffffffff,0]);
function observer(gl) {
  const objects=new Map(),syncs=new Set(),events=[];let next=1,phase='original';
  const value=v=>ArrayBuffer.isView(v)?{type:v.constructor.name,bytes:v.byteLength}:typeof v==='object'&&v!==null?{native:objects.get(v)??v.constructor.name}:v;
  const observed=new Proxy(gl,{get(target,name){const fn=Reflect.get(target,name,target);if(typeof fn!=='function')return fn;
    return (...args)=>{const result=fn.apply(target,args);if(/^create/.test(name)&&result&&typeof result==='object')objects.set(result,next++);
      if(name==='fenceSync'&&result){objects.set(result,next++);syncs.add(result);}if(/^delete/.test(name)&&args[0]){objects.delete(args[0]);syncs.delete(args[0]);}
      events.push({n:events.length,phase,name,args:args.map(value),...(name==='getError'?{result}:{})});return result;};}});
  return{gl:observed,events,objects,syncs,setPhase:v=>{phase=v;}};
}
async function one(Wasm,qualified,native,compiler,schedule) {
  const c=checker(),observed=observer(native),Selected=class{constructor(callback){return Wasm.qualified(callback,qualified.hostWords,qualified.formatRoles,qualified.renderer);}};
  // Queue/transport remain original. A transparent observer permits the explicit
  // synchronous checkpoint read; the shared async-only GL oracle is not applied.
  const rig=makeRig(Selected,options=>createVirglProductionBridge({...options,gl:observed.gl,presenter:createWorkerScanoutPresenter(()=>{})}),native,compiler,c,schedule,true,false,true);
  const base=rig.q.base,addresses={color:base+0x210000n,vertex:base+0x220000n,depth:base+0x230000n};
  const row={name:'original-gpu-only-readback-and-post-capture-draw/'+schedule,predictions:{
    color:'All sixteen GPU pixels are literal magenta while unchanged guest color backing remains0xd3.',
    depth:'All sixteen Z16 values are32768 (within one UN16 LSB) after original depth ALWAYS draw; guest backing remains0xe1.',
    subsequent:'Immediate same-state original draw succeeds; a later half-width draw produces magenta left and blue right, not a saved frame.',
    authority:'Checkpoint contents does not call any native transport exchange or complete/used publication.'}};
  const send=(label,wire)=>rig.expect(label,submission(7,wire));
  const originalRead=async(label)=>{await rig.expect(label,transfer(7,17,2,[0,0,0,4,4,1]));return rig.q.read(addresses.color,64);};
  const pixels=(bytes,rightBlue=false)=>{for(let y=0;y<4;y++)for(let x=0;x<4;x++)c.same([...bytes.slice((y*4+x)*4,(y*4+x+1)*4)],rightBlue&&x>=2?[0,0,255,255]:[255,0,255,255],'literal independently predicted pixel'+x+','+y);};
  try {
    await rig.expect('context7 interleaved generation',context(7));
    for(const [id,target,format,bind,width,height,address,length] of [[17,2,67,2,4,4,addresses.color,64],[19,2,16,1,4,4,addresses.depth,32],[23,0,64,16,64,1,addresses.vertex,64]]){
      await rig.expect('resource'+id,resource(id,target,format,bind,width,height));await rig.expect('member'+id,idCommand(0x202,7,id));await rig.expect('backing'+id,backing(id,[[address,length]]));
    }
    rig.q.write(addresses.color,new Uint8Array(64).fill(0xd3));rig.q.write(addresses.depth,new Uint8Array(32).fill(0xe1));
    rig.q.write(addresses.vertex,new Uint8Array(new Float32Array([-1,-1,0,1,1,-1,0,1,-1,1,0,1,1,1,0,1]).buffer));
    await rig.expect('original vertex DMA',transfer(7,23,1,[0,0,0,64,1,1]));
    await send('original shader/state setup',join(shader(10,0,vertex),shader(11,1,fragment),packet(31,0,[10,0]),packet(31,0,[11,1]),
      packet(1,5,[12,0,0,0,31]),packet(2,5,[12]),packet(6,0,[16,0,23]),packet(1,8,[20,17,67,0,0]),packet(1,8,[21,19,16,0,0]),
      packet(5,0,[1,21,20]),packet(4,0,[0,...[2,2,.5,2,2,.5].map(word)]),packet(1,1,[30,0,0,15<<27,0,0,0,0,0,0,0]),packet(2,1,[30]),
      packet(1,2,[40,2|1<<29,word(1),0,0xffff,word(1),0,0,0]),packet(2,2,[40]),packet(1,3,[50,31,0,0,0]),packet(2,3,[50]),draw()));
    c.same([...rig.q.read(addresses.color,64)],[...new Uint8Array(64).fill(0xd3)],'draw did not overwrite CPU color backing');
    c.same([...rig.q.read(addresses.depth,32)],[...new Uint8Array(32).fill(0xe1)],'draw did not overwrite CPU depth backing');
    const before={used:rig.q.usedIndex(),exchanges:rig.exchanges.length,completions:rig.completions.length,trace:rig.q.vm.commandTrace()};
    observed.setPhase('checkpoint');const state=c.ok(rig.host.bridge.checkpointState(),'capture actual GPU-written allocations');observed.setPhase('original');
    row.contents=copy(state.contents);row.logical=copy(state.logical);
    const color=state.contents.resources.find(r=>r.metadata.id===17),depth=state.contents.resources.find(r=>r.metadata.id===19);
    c.truth(color&&depth,'both GPU-only allocations present');pixels(state.contents.allocations[color.storage].levels[0].bytes);
    const z=state.contents.allocations[depth.storage].levels[0].bytes,v=new DataView(z.buffer,z.byteOffset,z.byteLength);
    for(let i=0;i<16;i++)c.truth(Math.abs(v.getUint16(i*2,true)-32768)<=1,'independent Z16 expected0.5'+i);
    c.same({used:rig.q.usedIndex(),exchanges:rig.exchanges.length,completions:rig.completions.length,trace:rig.q.vm.commandTrace()},before,'capture has no original DMA/completion/queue effects');
    await send('immediate identical original draw after checkpoint',draw());pixels(await originalRead('original post-capture transfer'));
    // Original CLEAR8 words: color bit4, blue, depth double0, stencil0.
    await send('new asymmetric GPU output',join(packet(7,0,[4,word(0),word(0),word(1),word(1),0,0,0]),packet(4,0,[0,...[1,2,.5,1,2,.5].map(word)]),draw()));
    pixels(await originalRead('original new asymmetric transfer'),true);c.equal(native.getError(),native.NO_ERROR,'no native API error');row.status='passed';
  }catch(error){row.status='failed';row.failure={message:error.message,stack:error.stack};}
  finally{row.native=observed.events;row.records=copy(rig.q.records);row.events=copy(rig.events);row.exchanges=copy(rig.exchanges);row.completions=copy(rig.completions);row.beforeDispose=copy(rig.host.bridge.inspect());row.guestTrace=rig.q.vm.commandTrace();row.machineDigest=rig.q.vm.machineDigest();row.disposed=copy(rig.host.bridge.dispose());rig.q.vm.free();row.ownersAfter={objects:observed.objects.size,syncs:observed.syncs.size};row.assertions=c.assertions;if(row.ownersAfter.objects||row.ownersAfter.syncs){row.status='failed';row.cleanupFailure='Native owner leak';}}
  return row;
}
export async function runProductionRendererCheckpointCritic({WasmVirglSubmitProof,schedules=[271828]}){
  const native=document.querySelector('#gpu').getContext('webgl2',{antialias:false,failIfMajorPerformanceCaveat:true}),qualified=await qualifyVirglHost(native),compiler=await createVirglStandardStreamOutputShaderBridge();
  const report={status:'running',rows:[],hardware:copy(qualified.identity)};window.__productionCriticReport=report;
  for(const schedule of schedules){const row=await one(WasmVirglSubmitProof,qualified,native,compiler,schedule),pin=await window.__recordProductionCriticRun(report.rows.length,JSON.stringify(row));report.rows.push({...pin,name:row.name,status:row.status,...(row.failure?{failure:row.failure}:{})});}
  report.status=report.rows.every(r=>r.status==='passed')?'passed':'failed';report.summary={status:report.status,runs:report.rows.length,failed:report.rows.filter(r=>r.status!=='passed'),hardware:report.hardware};return report;
}
