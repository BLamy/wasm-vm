#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define UTIL_ARCH_BIG_ENDIAN 0
#define MIN2(a,b) ((a)<(b)?(a):(b))
void p253(const uint32_t *src,uint8_t *dst) {
#if UTIL_ARCH_BIG_ENDIAN
         uint32_t value = 0;
         value |= (uint32_t)((uint32_t)MIN2(src[3], 3)) << 30;
         value |= (uint32_t)(((uint32_t)MIN2(src[2], 1023)) & 0x3ff) << 20;
         value |= (uint32_t)(((uint32_t)MIN2(src[1], 1023)) & 0x3ff) << 10;
         value |= ((uint32_t)MIN2(src[0], 1023)) & 0x3ff;
         memcpy(dst, &value, sizeof value);
#else
         uint32_t value = 0;
         value |= ((uint32_t)MIN2(src[0], 1023)) & 0x3ff;
         value |= (uint32_t)(((uint32_t)MIN2(src[1], 1023)) & 0x3ff) << 10;
         value |= (uint32_t)(((uint32_t)MIN2(src[2], 1023)) & 0x3ff) << 20;
         value |= (uint32_t)((uint32_t)MIN2(src[3], 3)) << 30;
         memcpy(dst, &value, sizeof value);
#endif

}
void p225(const uint32_t *src,uint8_t *dst) {
#if UTIL_ARCH_BIG_ENDIAN
         uint32_t value = 0;
         value |= (uint32_t)((uint32_t)MIN2(src[3], 3)) << 30;
         value |= (uint32_t)(((uint32_t)MIN2(src[0], 1023)) & 0x3ff) << 20;
         value |= (uint32_t)(((uint32_t)MIN2(src[1], 1023)) & 0x3ff) << 10;
         value |= ((uint32_t)MIN2(src[2], 1023)) & 0x3ff;
         memcpy(dst, &value, sizeof value);
#else
         uint32_t value = 0;
         value |= ((uint32_t)MIN2(src[2], 1023)) & 0x3ff;
         value |= (uint32_t)(((uint32_t)MIN2(src[1], 1023)) & 0x3ff) << 10;
         value |= (uint32_t)(((uint32_t)MIN2(src[0], 1023)) & 0x3ff) << 20;
         value |= (uint32_t)((uint32_t)MIN2(src[3], 3)) << 30;
         memcpy(dst, &value, sizeof value);
#endif

}
int main(void){uint32_t inputs[][4]={{1024,4294967295u,2147483648u,4},{4294967295u,1025,4097,4294967295u},{1023,17,683,3},{1,1022,683,2},{0,0,0,0}};for(int i=0;i<5;i++){uint32_t a,b;p225(inputs[i],(uint8_t*)&a);p253(inputs[i],(uint8_t*)&b);printf("%08x %08x\n",a,b);}return 0;}
