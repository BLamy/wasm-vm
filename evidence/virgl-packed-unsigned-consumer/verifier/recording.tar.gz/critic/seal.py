import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
verdict=json.loads((OUT/'verdict.json').read_text());assert verdict['firstLine']=='VERDICT: verified' and not verdict['findings']
members={};add=lambda name,raw:members.__setitem__(name,raw)
# Fresh browser records contain every original packet, response, native/input blob,
# full coverage script, actual GPU/browser metadata and screenshot, including failures.
roots=[(p.name,p) for p in OUT.iterdir() if p.is_dir() and (p.name.startswith(('fresh-','novel-')))]
roots += [('promoted/clean',ROOT/'target/evidence/virgl-packed-unsigned-consumer-critic-promoted'),('promoted/sabotage',ROOT/'target/evidence/virgl-packed-unsigned-consumer-critic-sabotage')]
for prefix,root in roots:
    for p in root.rglob('*'):
        if p.is_file():add('critic/'+prefix+'/'+p.relative_to(root).as_posix(),p.read_bytes())
for p in OUT.iterdir():
    if p.is_file() and p.name not in ['recording.tar.gz','records.json','manifest.json','seal.log']:
        add('critic/'+p.name,p.read_bytes())
for prefix in ['hot','cold']:
    replay=OUT/'inverse-replay'/prefix
    for p in replay.rglob('*'):
        if p.is_file() and not p.is_symlink():add('critic/worker-replays/'+prefix+'/'+p.relative_to(replay).as_posix(),p.read_bytes())
for p in (OUT/'predecessor').rglob('*'):
    if p.is_file():add('critic/predecessor/'+p.relative_to(OUT/'predecessor').as_posix(),p.read_bytes())
sources=set()
for prefix in ['hot','cold']:
    sources.update(json.loads((OUT/'unpacked'/prefix/'receipt.json').read_text())['sources'])
for prefix,root in roots:
    path=root/'report.json'
    if path.exists():sources.update(s['path'] for s in json.loads(path.read_text())['sources'])
sources.update(['Makefile','AGENTS.md','tools/virgl-packed-unsigned-consumer/critic.py','renderer/virgl-command/tests/standard-packed-unsigned-consumer-critic.mjs','tools/verify-virgl-standard-packed-unsigned-consumer-critic.mjs','web/package.json','web/package-lock.json'])
snapshot={}
for name in sorted(sources):
    raw=(ROOT/name).read_bytes();add('source-current/'+name,raw);snapshot[name]=sha(raw)
for name in ['renderer/virgl-shader/build/wasm/virgl-shader.mjs','renderer/virgl-shader/build/wasm/virgl-shader.wasm']:
    raw=(ROOT/name).read_bytes();add('source-current/'+name,raw);snapshot[name]=sha(raw)
add('critic/source-snapshot.json',(json.dumps(dict(workerHead=verdict['workerSubmissionHead'],runtimeHead=verdict['runtimeRecordedHead'],sources=snapshot,uncommittedPromotedHarnessSourcesAreExplicitlyPinned=True),indent=2)+'\n').encode())
index=(json.dumps(dict(schema='packed-uint-fresh-critic-full-records-v1',task='E6-T11d38',workerSubmissionHead=verdict['workerSubmissionHead'],runtimeHead=verdict['runtimeRecordedHead'],
                        records=[dict(path=n,bytes=len(b),sha256=sha(b)) for n,b in sorted(members.items())]),indent=2)+'\n').encode()
(OUT/'records.json').write_bytes(index);archive=io.BytesIO()
with gzip.GzipFile(fileobj=archive,mode='wb',mtime=0) as gz:
    with tarfile.open(fileobj=gz,mode='w') as tar:
        for n,b in sorted(members.items()):
            t=tarfile.TarInfo(n);t.size=len(b);t.mtime=0;t.mode=0o644;tar.addfile(t,io.BytesIO(b))
payload=archive.getvalue();(OUT/'recording.tar.gz').write_bytes(payload)
seen=set()
with tarfile.open(OUT/'recording.tar.gz','r:gz') as tar:
    for t in tar:
        assert t.isfile() and t.name not in seen and t.name in members
        raw=tar.extractfile(t).read();assert raw==members[t.name];seen.add(t.name)
assert seen==set(members)
manifest=dict(schema='packed-uint-fresh-critic-full-seal-v1',task='E6-T11d38',verdict='verified',workerSubmissionHead=verdict['workerSubmissionHead'],runtimeRecordedHead=verdict['runtimeRecordedHead'],
              records=len(members),reopenedMembers=len(seen),rawBytes=sum(len(b) for b in members.values()),archiveBytes=len(payload),archiveSha256=sha(payload),recordIndexSha256=sha(index),
              completeFreshSourcesInputsNativeCoverageBrowserScreenshots=True,sourceClosure=len(snapshot),freshRootRecordings=len(roots),
              workerArchiveSha256='8faad34f84ccfce10b8645598ad92f53a2e3b58414949d4dee6fc59a5ed7a0c6',workerArchiveReopenedMembers=26639,predecessorReopenedMembers=123156,
              runtimeEdited=False,guestExecution=False,productionNegotiation=False,productionDrawAuthority=False)
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(dict(**manifest,manifestSha256=sha((OUT/'manifest.json').read_bytes()))))
