import hashlib,json,struct
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
records=[]
for prefix in ['unpacked/hot/wire','unpacked/cold/wire','fresh-wire']:
    path=OUT/prefix/'report.json';raw=path.read_bytes();r=json.loads(raw);wire=r['wire']
    assert r['status']==wire['status']=='passed' and len(wire['records'])==18 and len(wire['emptyProfiles'])==12
    names={p['name'] for p in wire['emptyProfiles']};assert len(names)==12 and all(p['result']['ok'] and p['result']['profile']!='virgl-standard-packed-unsigned-image-commands-v1' for p in wire['emptyProfiles'])
    accepted=[];refusals=[]
    for i,record in enumerate(wire['records']):
        raw_packet=bytes.fromhex(record['hex']);words=struct.unpack('<'+'I'*(len(raw_packet)//4),raw_packet)
        assert words[0]>>16==len(words)-1 and words[0]&255==1
        if record['kind'] in ['base-view','swizzled-mip-view','mip-surface']:
            assert record['format'] in [225,253];selected=record['selected'];assert selected['ok'] and selected['profile']=='virgl-standard-packed-unsigned-image-commands-v1'
            command=selected['commands'][0];fields=command['fields'];assert fields['format']==record['format'] and fields['resourceHandle']==6
            if record['kind']=='mip-surface':
                assert words[0]>>8&255==8 and words[3]==record['format'] and words[4]==fields['level']==2 and words[5]==0
            else:
                assert words[0]>>8&255==6 and words[3]&0xffffff==record['format'] and words[3]>>24==fields['target']==2 and words[4]==0
                first,last=words[5]&255,words[5]>>8&255;swizzle=[words[6]>>(3*j)&7 for j in range(4)]
                assert (first,last)==((0,0) if record['kind']=='base-view' else (1,3)) and swizzle==([0,1,2,3] if first==0 else [2,4,0,5])
                assert fields['firstLevel']==first and fields['lastLevel']==last and fields['swizzle']==swizzle
            assert {p['name'] for p in record['prior']}==names
            assert all(not p['result']['ok'] and p['result']['error']['code']=='unsupported-feature' for p in record['prior'])
            accepted.append(dict(index=i,kind=record['kind'],format=record['format'],packetSha256=sha(raw_packet)))
        else:
            assert not record['result']['ok'];refusals.append(dict(index=i,kind=record['kind'],reason=record.get('reason'),code=record['result']['error']['code'],packetSha256=sha(raw_packet)))
    assert len(accepted)==6 and len(refusals)==12
    records.append(dict(record=prefix+'/report.json',sha256=sha(raw),selected=accepted,priorRefusals=72,malformed=refusals))
gap=json.loads((ROOT/'evidence/virgl-production-readiness/standard-packed-unsigned-consumer-gap.json').read_text())
assert gap['gitHead']=='f9f479c20d37d89d0d6da18675777a4a8fd7a7b9' and not gap['nativeExecuted'] and len(gap['records'])==6
assert all(not r['result']['ok'] and r['result']['error']['code']=='unsupported-feature' for r in gap['records'])
vertices=[]
for prefix in ['hot','cold']:
    path=OUT/'unpacked'/prefix/'hardware-samples/report.json';raw=path.read_bytes();r=json.loads(raw);e=r['browserResult']['result']
    for ri,run in enumerate(e['runs']):
        if run['stage']!='vertex':continue
        assert 'GENERIC[0], CONSTANT' in run['fragment']
        for di,draw in enumerate(run['draws']):
            vertex=next(s['glsl'] for s in draw['shaders'] if s['type']==35633);fragment=next(s['glsl'] for s in draw['shaders'] if s['type']==35632)
            assert 'flat out uvec4 vso_g0;' in vertex and 'flat in uvec4 vso_g0;' in fragment and 'out uvec4 fsout_c0;' in fragment
            assert 'uniform highp usampler2D vssamp3;' in vertex and draw['samplers'][0]['type']==36306
            vertices.append(dict(record=str(path.relative_to(OUT)),reportSha256=sha(raw),jsonPoint=f'$.browserResult.result.runs[{ri}].draws[{di}]',format=run['format'],opcode=run['opcode'],vertexSha256=sha(vertex.encode()),fragmentSha256=sha(fragment.encode()),actual='flat uvec4 link'))
(OUT/'wire-audit.json').write_text(json.dumps(dict(status='passed',prediction=['P5-sampling','P6-refusal'],records=records,heldVertexContract=vertices),indent=2)+'\n')
print(json.dumps(dict(status='passed',wireRecordings=len(records),vertexLinks=len(vertices))))
