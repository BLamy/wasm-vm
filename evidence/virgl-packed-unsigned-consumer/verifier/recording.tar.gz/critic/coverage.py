import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
BASE='f9f479c20d37d89d0d6da18675777a4a8fd7a7b9';sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
changed={};name=None;ln=0
for row in git('diff','--unified=0',BASE,'83b2e147f7134bb807b699500ba91bd4a42e9090','--','renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs').decode().splitlines():
    if row.startswith('+++ b/'):name=row[6:]
    elif row.startswith('@@'):ln=int(re.search(r'\+(\d+)',row)[1])
    elif row.startswith('+'):changed.setdefault(name,[]).append(ln);ln+=1
    elif row.startswith(' '):ln+=1
waiver_rows=json.loads((ROOT/'tools/virgl-packed-unsigned-consumer/coverage-waivers.json').read_text())['waivers']
waivers={(r['source'],r['startOffset'],r['endOffset']):r for r in waiver_rows}
prior=json.loads((OUT/'predecessor/virgl-packed-normalized-consumer/verifier/critic/coverage-audit.json').read_text())
preheld=[]
for prefix in prior['results']:
    preheld += [p for p in prefix['partitions'] if p['classification'].startswith('waived')]
results=[]
for prefix in ['hot','cold']:
    directory=OUT/'unpacked'/prefix;rows=[];authority=[]
    for path in directory.rglob('browser-coverage.json'):
        if '/fault-' in str(path):continue
        data=json.loads(path.read_text());report=json.loads((path.parent/'report.json').read_text())
        assert report['browserCoverage']['sha256']==sha(path.read_bytes())
        for s in data['scripts']:
            if s['source'] not in changed:continue
            assert sha((ROOT/s['source']).read_bytes())==s['sha256']
            authority.append(dict(record=str(path.relative_to(OUT)),sha256=sha(path.read_bytes()),source=s['source'],sourceSha256=s['sha256']))
            rows.append((s['source'],str(path.relative_to(OUT)),s['coverage']))
    for path in (directory/'node-coverage').glob('coverage-*.json'):
        for s in json.loads(path.read_text())['result']:
            for n in changed:
                if s['url'].endswith('/'+n):
                    rows.append((n,str(path.relative_to(OUT)),s));authority.append(dict(record=str(path.relative_to(OUT)),sha256=sha(path.read_bytes()),source=n,sourceSha256=sha((ROOT/n).read_bytes())))
    partitions=[]
    for n,lines in changed.items():
        raw=(ROOT/n).read_text().encode('utf-16-le');offsets=[0]
        for line in (ROOT/n).read_text().splitlines(keepends=True):offsets.append(offsets[-1]+len(line.encode('utf-16-le'))//2)
        scripts=[(p,s) for source,p,s in rows if source==n]
        for line in lines:
            lo,hi=offsets[line-1],offsets[line];cuts={lo,hi}
            for p,s in scripts:
                for f in s['functions']:
                    for r in f['ranges']:
                        assert r['startOffset']<=r['endOffset'] and r['count']>=0
                        cuts.update(x for x in [r['startOffset'],r['endOffset']] if lo<x<hi)
            cuts=sorted(cuts)
            for a,b in zip(cuts,cuts[1:]):
                counters=[]
                for p,s in scripts:
                    covers=[r for f in s['functions'] for r in f['ranges'] if r['startOffset']<=a and b<=r['endOffset']]
                    if covers:counters.append(dict(record=p,**sorted(covers,key=lambda r:r['endOffset']-r['startOffset'])[0]))
                count=max((r['count'] for r in counters),default=0);text=raw[a*2:b*2].decode('utf-16-le');key=(n,a,b)
                item=dict(source=n,line=line,startOffset=a,endOffset=b,text=text,maxCount=count,governing=counters,classification='executed' if count else 'unproven')
                if count==0:
                    w=waivers.get(key);assert w and w['text']==text and w['sha256']==sha(text.encode())
                    old=git('show',BASE+':'+n);assert sha(old)==w['predecessorSourceSha256']
                    pa,pb=w['predecessorStartOffset'],w['predecessorEndOffset'];assert old.decode().encode('utf-16-le')[pa*2:pb*2].decode('utf-16-le')==text
                    assert 'unsigned' not in text.lower() and 'integerFormat' not in text
                    if w.get('heldTask'):
                        assert any(p['source']==n and p['startOffset']==pa and p['endOffset']==pb and p['text']==text for p in preheld),(n,pa,pb,text)
                        item['carry']='exact verified D36 critic partition'
                    else:
                        assert text in ['?? 0',': null'] and n.endswith('state.mjs')
                        item['carry']='unchanged single-target/disabled-integer fallback; selected consumer fixes multipleColors=integers=true'
                    item.update(classification='waived',reason=w['reason'],predecessorSourceSha256=sha(old),predecessorStartOffset=pa,predecessorEndOffset=pb)
                partitions.append(item)
    positive=sum(p['classification']=='executed' for p in partitions);waived=sum(p['classification']=='waived' for p in partitions)
    assert (positive,waived)==(254,16) and sum(p.get('carry')=='exact verified D36 critic partition' for p in partitions)==14
    asserted=json.loads((directory/'coverage-audit.json').read_text())
    assert {(p['source'],p['startOffset'],p['endOffset'],p['maxCount']) for p in partitions}=={(p['source'],p['startOffset'],p['endOffset'],p['maxCount']) for p in asserted['partitions']}
    results.append(dict(prefix=prefix,positive=positive,waived=waived,unaccounted=[],partitions=partitions,fullRegionAuthority=authority))
(OUT/'coverage-audit.json').write_text(json.dumps(dict(status='passed',prediction='P9-coverage',independentlyDerived=True,results=results),indent=2)+'\n')
print(json.dumps(dict(status='passed',results=[{k:r[k] for k in ['prefix','positive','waived','unaccounted']} for r in results])))
