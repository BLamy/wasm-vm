import datetime,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads((OUT/p).read_text())
for name in ['authentication.json','primary-audit.json','replay-audit.json','coverage-audit.json','fresh-audit.json','wire-audit.json']:
    assert load(name)['status']=='passed'
predictions=load('predictions.json')['predictions'];results=[]
refs={
 'P1-auth':['authentication.json'],
 'P2-pure-width':['primary-audit.json'],
 'P3-saturation':['replay-audit.json'],
 'P4-output-masks':['replay-audit.json','fresh-audit.json'],
 'P5-sampling':['replay-audit.json','wire-audit.json','fresh-audit.json'],
 'P6-refusal':['wire-audit.json','fresh-audit.json'],
 'P7-generation-fence':['fresh-audit.json'],
 'P8-controls':['replay-audit.json','fresh-audit.json'],
 'P9-coverage':['coverage-audit.json'],
 'P10-fresh':['fresh-audit.json'],
 'P11-novel':['novel-promoted/critic-audit.json'],
 'P12-promoted-sabotage':['novel-sabotage/critic-audit.json']}
for p in predictions:
    results.append(dict(**p,result='HELD',citations=[dict(path=n,sha256=sha((OUT/n).read_bytes())) for n in refs[p['id']]]))
runtime={n:sha((ROOT/n).read_bytes()) for n in ['renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs','renderer/virgl-command/resources.mjs','renderer/virgl-command/constant-domain.mjs','renderer/virgl-command/packed-unsigned-images.mjs','renderer/virgl-shader/build/wasm/virgl-shader.mjs','renderer/virgl-shader/build/wasm/virgl-shader.wasm']}
assert not subprocess.check_output(['git','diff','--name-only','83b2e147f7134bb807b699500ba91bd4a42e9090','--','renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs','renderer/virgl-command/resources.mjs','renderer/virgl-command/constant-domain.mjs','renderer/virgl-command/packed-unsigned-images.mjs','renderer/virgl-shader'],cwd=ROOT).strip()
result=dict(firstLine='VERDICT: verified',task='E6-T11d38',role='fresh-adversarial-verifier',createdAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            workerSubmissionHead='83b2e147f7134bb807b699500ba91bd4a42e9090',runtimeRecordedHead='11326fe597196cb75d0853d230da0a3ed22683c5',predecessor='f9f479c20d37d89d0d6da18675777a4a8fd7a7b9',
            predictionsSha256=sha((OUT/'predictions.json').read_bytes()),results=results,findings=[],runtimeEdited=False,pristineCloneRepeated=False,
            runtimeSources=runtime,scope='one false-by-default original packed UINT command consumer in decoder/state; unchanged D37 storage and C/Wasm/constant boundary',
            guestExecution=False,productionNegotiation=False,productionDrawAuthority=False,performanceClaim=False,
            suite=dict(promoted=['renderer/virgl-command/tests/standard-packed-unsigned-consumer-critic.mjs','tools/verify-virgl-standard-packed-unsigned-consumer-critic.mjs','tools/virgl-packed-unsigned-consumer/critic.py','Makefile:verify-E6-T11d38-adversarial'],
                command='make verify-E6-T11d38-adversarial',sabotageChecked=True,inverseSha256=load('novel-promoted/critic-audit.json')['inverseSha256']),
            leaseRelease='all leases released after verdict commit; no owned process will remain')
(OUT/'verdict.json').write_text(json.dumps(result,indent=2)+'\n');print(result['firstLine'])
