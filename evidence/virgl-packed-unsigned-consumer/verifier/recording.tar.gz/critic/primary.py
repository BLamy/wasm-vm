import contextlib,hashlib,importlib.util,io,json,re,subprocess,sys,types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
spec=ROOT/'tools/virgl-packed-unsigned-consumer/spec'
# The format parser needs only its Channel/Format classes here. No YAML loader is
# used: this critic reads the two literal primary descriptors directly.
stub=types.ModuleType('yaml');stub.CSafeLoader=object;stub.SafeLoader=object;sys.modules['yaml']=stub
sys.path.insert(0,str(spec))
import u_format_parse as parser
import u_format_pack as pack
pins={'u_format_pack.py':'a4a2510d443c84059d25f2346c521d28d503c1744b76b2aa3079198ecc33f2bc','u_format_parse.py':'d523a751f6a3334f7cbe2e5bdede1065c3629390cdbbe98e5d41109e3cf63ebb'}
for n,digest in pins.items():assert sha((spec/n).read_bytes())==digest
header=ROOT/'renderer/virgl-shader/vendor/src/virgl_hw.h';raw=header.read_bytes();assert sha(raw)=='191ca5cea527949a29e9753b1e31d550f2fed922895d78dabc5c5c3585aa2ff7'
mesa=ROOT/'tools/virgl-command/standard-packed-unsigned-mesa-formats.yaml';text=mesa.read_text();assert sha(mesa.read_bytes())=='6b2973fbcad86bc83e1b6ca0db4a235724f5837da1d2cbb9911c25e6f692742e'
table=json.loads((ROOT/'tools/virgl-command/standard-packed-unsigned-formats.json').read_text())
descriptors=[];kernels=[];exprs=[]
for name,channels,swizzles in re.findall(r'- name: (\w+)\n.*?channels: \[([^]]+)\]\n  swizzles: \[([^]]+)\]',text,re.S):
    f=parser.Format(dict(name=name,layout='plain',colorspace='RGB',block=dict(width=1,height=1,depth=1),channels=channels.split(', '),swizzles=swizzles.split(', ')))
    ident=int(re.search(r'VIRGL_FORMAT_'+name+r'\s*=\s*(\d+)',raw.decode())[1])
    assert f.is_pure_unsigned() and f.is_bitmask() and f.block_size()==32
    fields=[dict(bits=f.le_channels[s].size,offset=f.le_channels[s].shift,ignored=False) for s in f.le_swizzles]
    d=dict(originalFormat=ident,originalName=name,fields=fields,pure=True,normalized=False,maxima=[f.le_channels[s].max() for s in f.le_swizzles])
    original=next(r for r in table['records'] if r['originalFormat']==ident)
    assert fields==original['rgbaFields'] and d['maxima']==[1023,1023,1023,3] and original['guestPixelBytes']==4 and original['readPixelBytes']==16
    src=parser.Channel(parser.UNSIGNED,False,True,32)
    expr=[pack.conversion_expr(src,f.le_channels[s],'uint32_t','src['+str(i)+']') for i,s in enumerate(f.le_swizzles)]
    assert all('MIN2' in e for e in expr) and all('1023' in e for e in expr[:3]) and '3)' in expr[3]
    out=io.StringIO()
    with contextlib.redirect_stdout(out):pack.generate_pack_kernel(f,src,'unsigned')
    kernel=out.getvalue();kernels.append(f'void p{ident}(const uint32_t *src,uint8_t *dst) {{\n{kernel}\n}}\n');exprs.append(dict(format=ident,expressions=expr,kernel=kernel));descriptors.append(d)
c='#include <stdint.h>\n#include <stdio.h>\n#include <string.h>\n#define UTIL_ARCH_BIG_ENDIAN 0\n#define MIN2(a,b) ((a)<(b)?(a):(b))\n'+''.join(kernels)
c+='int main(void){uint32_t inputs[][4]={{1024,4294967295u,2147483648u,4},{4294967295u,1025,4097,4294967295u},{1023,17,683,3},{1,1022,683,2},{0,0,0,0}};for(int i=0;i<5;i++){uint32_t a,b;p225(inputs[i],(uint8_t*)&a);p253(inputs[i],(uint8_t*)&b);printf("%08x %08x\\n",a,b);}return 0;}\n'
(OUT/'primary-pack.c').write_text(c)
subprocess.run(['cc','-Wall','-Wextra','-Werror','-O0',str(OUT/'primary-pack.c'),'-o',str(OUT/'primary-pack')],check=True)
result=subprocess.check_output([str(OUT/'primary-pack')],text=True);(OUT/'primary-pack.log').write_text(result)
inputs=[[1024,4294967295,2147483648,4],[4294967295,1025,4097,4294967295],[1023,17,683,3],[1,1022,683,2],[0,0,0,0]]
ordered=sorted(descriptors,key=lambda d:d['originalFormat']);expected=[]
for row in inputs:
    expected.append([sum(min(v,(1<<field['bits'])-1)<<field['offset'] for v,field in zip(row,d['fields'])) for d in ordered])
assert [[int(w,16) for w in line.split()] for line in result.splitlines()]==expected
report=dict(status='passed',prediction='P2-pure-width',sources=pins,headerSha256=sha(raw),mesaSha256=sha(mesa.read_bytes()),descriptors=descriptors,
            generated=exprs,inputs=inputs,expected=expected,compile=['cc','-Wall','-Wextra','-Werror','-O0','primary-pack.c','-o','primary-pack'],primaryPackSourceSha256=sha(c.encode()),
            hardwareConversionStillRequiresRecordedEvidence=True,officialReference='https://registry.khronos.org/OpenGL/specs/es/3.0/es_spec_3.0.pdf',referenceSections=['4.1.7 integer blending bypass','4.2.3 unsigned integer ClearBufferuiv','4.3.2 integer readback elements remain unmodified'])
(OUT/'primary-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status='passed',descriptors=descriptors,packing=expected)))
