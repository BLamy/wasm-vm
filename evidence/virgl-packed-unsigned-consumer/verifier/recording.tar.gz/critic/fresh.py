import gzip,hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
names=[];audits=[]
for seed in [1541459225,2773480762,3355599323]:
 for kind,script in [('target','boundaries.py'),('sample','samples.py')]:
    name=f'fresh-{kind}-{seed}';directory=OUT/name
    with (directory/'inverse.log').open('w') as log:subprocess.run(['python3',str(ROOT/'tools/virgl-packed-unsigned-consumer'/script),str(directory)],stdout=log,stderr=subprocess.STDOUT,check=True)
    audit=directory/('boundary-audit.json' if kind=='target' else 'sample-audit.json');a=json.loads(audit.read_text())
    assert a['status']=='passed' and a['counts']['frames']==(19 if kind=='target' else 60)
    names.append(name);audits.append(dict(record=name,seed=seed,status=a['status'],auditSha256=sha(audit.read_bytes()),counts=a['counts']))
for name,script in [('fresh-wrong-attachment','pixels.py'),('fresh-completed-output','pixels.py'),('fresh-wrong-sampler','samples.py')]:
 directory=OUT/name
 with (directory/'inverse.log').open('w') as log:subprocess.run(['python3',str(ROOT/'tools/virgl-packed-unsigned-consumer'/script),str(directory),'--control'],stdout=log,stderr=subprocess.STDOUT,check=True)
 audit=directory/('sample-audit.json' if 'sampler' in name else 'pixel-audit.json');a=json.loads(audit.read_text())
 assert a['status']=='refuted' and a['differences'];names.append(name);audits.append(dict(record=name,status=a['status'],auditSha256=sha(audit.read_bytes()),differences=a['differences'],counts=a['counts']))
for name in ['novel-promoted','novel-sabotage']:
 directory=OUT/name;a=json.loads((directory/'critic-audit.json').read_text());assert a['status']==('refuted' if name.endswith('sabotage') else 'passed')
 names.append(name);audits.append(dict(record=name,status=a['status'],auditSha256=sha((directory/'critic-audit.json').read_bytes()),inverseSha256=a['inverseSha256'],counts=a['counts'],differences=a['differences']))
assert audits[-1]['inverseSha256']==audits[-2]['inverseSha256']
authentication=[];point_citations=[]
all_dirs=[(OUT/name,name) for name in names]
for prefix in ['hot','cold']:
 all_dirs += [(path.parent,str(path.parent.relative_to(OUT))) for path in (OUT/'unpacked'/prefix).glob('*/report.json')]
for directory,name in all_dirs:
 raw_report=(directory/'report.json').read_bytes();r=json.loads(raw_report);e=r.get('browserResult',{}).get('result') or r.get('partial')
 assert r['browserErrors']==dict(console=[],page=[],requests=[])
 for source in r['sources']:
    raw=(ROOT/source['path']).read_bytes();assert len(raw)==source['bytes'] and sha(raw)==source['sha256'],(name,source['path'])
 if name.startswith('fresh-') or name.startswith('novel-'):assert r['gitHead']=='83b2e147f7134bb807b699500ba91bd4a42e9090'
 if r.get('wire'):continue
 assert r['browser']['headless'] is False and 'Metal' in e['gpu']
 assert r['browser']['gpu']['featureStatus'].get('webgl2',r['browser']['gpu']['featureStatus'].get('webgl'))=='enabled'
 assert not any(re.search(r'swiftshader|llvmpipe|softpipe|lavapipe|--disable-gpu',x,re.I) for x in r['browser']['commandLine'])
 for key in ['browserCoverage','screenshot']:
    ref=r[key];assert sha((directory/ref['path']).read_bytes())==ref['sha256']
 bysource={s['path']:s for s in r['sources']}
 for served in r['servedFiles']:
    if served['path']=='/':continue
    s=bysource[served['path'][1:]];assert s['sha256']==served['sha256'] and s['bytes']==served['bytes']
 blobs={b['key']:b for b in e['blobs']};assert len(blobs)==len(e['blobs'])
 decompressed={};total=0
 for key,b in blobs.items():
    compressed=(directory/b['path']).read_bytes();assert sha(compressed)==b['gzipSha256']
    raw=gzip.decompress(compressed);assert len(raw)==b['bytes'] and sha(raw)==b['sha256'];total+=len(raw);decompressed[key]=raw
 custody=dict(syncs=0,polls=0,cpuReads=0,objects=0)
 for ri,run in enumerate(e['runs']):
    if 'fenceObjects' not in run or 'events' not in run:continue
    # The four historical paths have their held native audits; selected D38
    # records are interrogated again, including actual copy operations as writes.
    if name.split('/')[-1].startswith('historical'):continue
    events=run['events'];assert [ev['sequence'] for ev in events]==list(range(1,len(events)+1))
    syncs={s['id']:s for s in run['fenceObjects']};assert len(syncs)==len(run['fenceObjects']);custody['syncs']+=len(syncs)
    for s in syncs.values():
        creates=[ev for ev in events if ev['name']=='fenceSync' and ev['sync']==s['id']];deletes=[ev for ev in events if ev['name']=='deleteSync' and ev['sync']==s['id']]
        polls=[ev for ev in events if ev['name']=='clientWaitSync' and ev['sync']==s['id']]
        assert len(creates)==len(deletes)==s['deleted']==1 and s['identity']=='WebGLSync' and creates[0]['sequence']==s['createdSequence'] and polls==s['polls']
        assert all(s['createdSequence']<p['sequence']<deletes[0]['sequence'] and p['args']==[0,0] and (p['delivered']==37147 or p['delivered']==p['actual']) for p in polls)
        custody['polls']+=len(polls)
    writer=0
    for ev in events:
        if ev['name'] in ['drawArrays','drawElements','drawArraysInstanced','drawElementsInstanced','clearBufferiv','clearBufferuiv','clearBufferfv','clear','texSubImage2D','bufferSubData','copyBufferSubData','blitFramebuffer']:writer=ev['sequence']
        if ev['name'] in ['readPixels','getBufferSubData'] and ev['cpu']:
            p=ev['completion'];assert ev['sequence']>p['sequence']>writer and syncs[p['sync']]['createdSequence']>writer
            assert p['actual'] in [37146,37148] and p['delivered']==p['actual'] and any(q['sequence']==p['sequence'] for q in syncs[p['sync']]['polls']);custody['cpuReads']+=1
    assert all(o['deleted']==1 for o in run['nativeObjects']);custody['objects']+=len(run['nativeObjects'])
    assert all(n==0 for owner in ['renderer','resources'] for n in run['final'][owner]['budgets'].values())
    for hi,h in enumerate(run['history']):
        if h['result'].get('ok',True):continue
        if h['result']['error']['code'] not in ['incompatible-resource','unsupported-sampler','unsupported-feature','framebuffer-feedback','incomplete-framebuffer','invalid-value','backend-error']:continue
        label=h['label'];assert not any(d['label']==label for d in run['draws'])
        if h['result']['error']['code'] in ['incompatible-resource','unsupported-sampler','unsupported-feature','framebuffer-feedback']:
            assert not any(ev['label']==label and ev['name'] in ['drawArrays','drawElements','drawArraysInstanced','drawElementsInstanced','blitFramebuffer'] for ev in events)
        point_citations.append(dict(record=name+'/report.json',reportSha256=sha(raw_report),jsonPoint=f'$.browserResult.result.runs[{ri}].history[{hi}]',label=label,error=h['result']['error']['code'],noGuestDraw=True))
 authentication.append(dict(record=name,reportSha256=sha(raw_report),sources=len(r['sources']),blobs=len(blobs),rawBlobBytes=total,custody=custody,
                        coverageSha256=r['browserCoverage']['sha256'],screenshotSha256=r['screenshot']['sha256'],gpu=e['gpu'],browser=r['browser']['version']))
result=dict(status='passed',predictions=['P4-output-masks','P5-sampling','P6-refusal','P7-generation-fence','P8-controls','P10-fresh','P11-novel','P12-promoted-sabotage'],
            freshRecordings=len(names),audits=audits,allRecordingAuthentication=authentication,refusalPoints=point_citations,
            completeBlobDecompression=True,fullFenceAndCopyCustody=True,originalExpectedArraysAreNotAuthority=True)
(OUT/'fresh-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status='passed',freshRecordings=len(names),allRecordings=len(authentication),rawBlobs=sum(a['blobs'] for a in authentication),refusals=len(point_citations))))
