import copy,gzip,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
records=[];points=[]
specs=[('hardware-targets','pixels.py',False),('hardware-samples','samples.py',False)]
for seed in [362514859,2882400001,1629686191]:specs += [(f'target-boundary-{seed}','boundaries.py',False),(f'sample-boundary-{seed}','samples.py',False)]
specs += [('fault-nonzero-attachment','pixels.py',True),('fault-completed-output','pixels.py',True),('fault-sample-plane','samples.py',True)]
specs += [('historical','../virgl-multiple-color/pixels.py',False),('historical-integer','historical.py',False),('historical-float','historical.py',False),('historical-normalized','../virgl-packed-normalized-consumer/pixels.py',False)]
for prefix in ['hot','cold']:
 for name,script,control in specs:
    original=OUT/'unpacked'/prefix/name;dest=OUT/'inverse-replay'/prefix/name;dest.mkdir(parents=True,exist_ok=True)
    raw=(original/'report.json').read_bytes();r=json.loads(raw);e=r.get('browserResult',{}).get('result') or r.get('partial')
    poison=not name.startswith('historical')
    if e and poison:
        e['predictions']=[]
        for run in e['runs']:
            for key in ['expected','expectedSample','words']:
                if key in run:run[key]='deliberately forged critic expectation'
        for f in e['frames']:
            if 'expected' in f:f['expected']='deliberately forged critic expectation'
            for t in f.get('targets',[]):
                if 'expected' in t:t['expected']='deliberately forged critic expectation'
    if e:
        for blob in e['blobs']:
            link=dest/blob['path']
            if not link.exists():link.symlink_to((original/blob['path']).resolve())
    (dest/'report.json').write_text(json.dumps(r,indent=2)+'\n')
    command=['python3',str((ROOT/'tools/virgl-packed-unsigned-consumer'/script).resolve()),str(dest)]+(['--control'] if control else [])
    with (dest/'inverse.log').open('w') as log:subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
    audit=next(dest.glob('*-audit.json'));a=json.loads(audit.read_text())
    assert a['status']==('refuted' if control else 'passed')
    records.append(dict(record=f'{prefix}/{name}/report.json',originalSha256=sha(raw),poisonedExpectations=poison,inverse=script,auditSha256=sha(audit.read_bytes()),status=a['status'],counts=a.get('counts',{})))
    if name=='hardware-targets':
        original_r=json.loads(raw);oe=original_r['browserResult']['result'];bykey={b['key']:b for b in oe['blobs']}
        def blob(ref):
            b=bykey[ref['key']];return gzip.decompress((original/b['path']).read_bytes())
        saturation=next(i for i,run in enumerate(oe['runs']) if run['name']=='packed-unsigned-output-saturates')
        run=oe['runs'][saturation]
        for fi in run['frames'][:3]:
            frame=oe['frames'][fi]
            for t in frame['targets']:
                if t['metadata']['format'] not in [225,253]:continue
                native=blob(t['native']);expected=b'\xff\x03\x00\x00'*3+b'\x03\x00\x00\x00';assert native==expected*(run['width']*run['height'])
                public=blob(t['backing']);w=run['width'];stride=w*4+3
                assert all(public[5+y*stride:5+y*stride+w*4]==bytes([255])*(w*4) for y in range(run['height']))
                points.append(dict(prediction='P3-saturation',record=f'{prefix}/{name}/report.json',reportSha256=sha(raw),jsonPoint=f'$.browserResult.result.frames[{fi}].targets[slot={t["slot"]}]',
                    nativePath=t['native']['key']+'.bin.gz',nativeSha256=t['native']['sha256'],publicSha256=t['backing']['sha256'],observedNative=[1023,1023,1023,3],observedOriginalWord='0xffffffff',packetHistory=frame['historyIndex'],kind=frame['kind']))
(OUT/'replay-audit.json').write_text(json.dumps(dict(status='passed',workerRecordings=len(records),records=records,points=points,
        independentlyInterrogatedInverseSources=True,productRuntimeImports=False,ignoredExpectedArraysProved=True,nativeBlobTolerance=0),indent=2)+'\n')
print(json.dumps(dict(status='passed',recordings=len(records),saturationPoints=len(points))))
