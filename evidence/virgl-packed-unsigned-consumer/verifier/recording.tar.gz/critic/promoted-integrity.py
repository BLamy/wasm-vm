import gzip, hashlib, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
inverse = sha((ROOT / 'tools/virgl-packed-unsigned-consumer/critic.py').read_bytes())
records = []
for mode in ['promoted', 'sabotage']:
    directory = ROOT / 'target/evidence' / ('virgl-packed-unsigned-consumer-critic-' + mode)
    raw_report = (directory / 'report.json').read_bytes()
    report = json.loads(raw_report)
    audit = json.loads((directory / 'critic-audit.json').read_text())
    assert report['status'] == ('passed' if mode == 'promoted' else 'failed')
    assert report['gitHead'] == '83b2e147f7134bb807b699500ba91bd4a42e9090'
    assert audit['status'] == ('passed' if mode == 'promoted' else 'refuted')
    assert audit['reportSha256'] == sha(raw_report) and audit['inverseSha256'] == inverse
    assert report['browserErrors'] == dict(console=[], page=[], requests=[])
    assert report['browser']['headless'] is False
    for source in report['sources']:
        raw = (ROOT / source['path']).read_bytes()
        assert len(raw) == source['bytes'] and sha(raw) == source['sha256']
    bysource = {s['path']: s for s in report['sources']}
    for served in report['servedFiles']:
        if served['path'] == '/':
            continue
        source = bysource[served['path'][1:]]
        assert (source['bytes'], source['sha256']) == (served['bytes'], served['sha256'])
    for name in ['browserCoverage', 'screenshot']:
        ref = report[name]
        assert sha((directory / ref['path']).read_bytes()) == ref['sha256']
    result = report['browserResult'].get('result') or report['partial']
    assert 'Metal' in result['gpu']
    blob_bytes = 0
    for blob in result['blobs']:
        compressed = (directory / blob['path']).read_bytes()
        assert sha(compressed) == blob['gzipSha256']
        raw = gzip.decompress(compressed)
        assert len(raw) == blob['bytes'] and sha(raw) == blob['sha256']
        blob_bytes += len(raw)
    if mode == 'sabotage':
        miss = audit['differences'][0]
        assert miss['frame'] == 8 and miss['slot'] == 3
        assert miss['miss'] == [dict(at=36, observed=16, expected=17)]
        a, b = audit['points'][7]['completion'], audit['points'][8]['completion']
        assert a['sync'] == 30 and b['sync'] == 31 and a['sequence'] == 1446 and b['sequence'] == 1505
        assert a['actual'] in [37146, 37148] and b['actual'] in [37146, 37148]
    records.append(dict(mode=mode, reportSha256=sha(raw_report),
                        auditSha256=sha((directory / 'critic-audit.json').read_bytes()),
                        sources=len(report['sources']), blobs=len(result['blobs']),
                        rawBlobBytes=blob_bytes, counts=audit['counts']))
verdict = dict(status='passed', inverseSha256=inverse, recordings=records,
               entirePromotedRawBlobsAuthenticated=True, sameInverseForBaselineAndActualPhysicalSabotage=True)
(OUT / 'promoted-integrity.json').write_text(json.dumps(verdict, indent=2) + '\n')
print(json.dumps(verdict))
