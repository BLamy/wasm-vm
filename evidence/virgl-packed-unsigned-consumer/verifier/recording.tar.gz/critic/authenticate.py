import hashlib,json,subprocess,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
BASE='f9f479c20d37d89d0d6da18675777a4a8fd7a7b9'
FREEZE='11326fe597196cb75d0853d230da0a3ed22683c5'
HEAD='83b2e147f7134bb807b699500ba91bd4a42e9090'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert not git('diff','--name-only','HEAD').strip()
def reopen(base,extract=None):
    manifest_raw=(base/'manifest.json').read_bytes(); index_raw=(base/'records.json').read_bytes()
    m=json.loads(manifest_raw);idx=json.loads(index_raw);archive=base/'recording.tar.gz'
    assert sha(index_raw)==m['recordIndexSha256'] and sha(archive.read_bytes())==m['archiveSha256']
    wanted={r['path']:r for r in idx['records']};assert len(wanted)==len(idx['records'])==m['records']
    seen=set();total=0;selected={}
    with tarfile.open(archive,'r:gz') as tar:
        for e in tar:
            assert e.isfile() and e.name in wanted and e.name not in seen
            raw=tar.extractfile(e).read();w=wanted[e.name]
            assert len(raw)==w['bytes'] and sha(raw)==w['sha256'],e.name
            assert not Path(e.name).is_absolute() and '..' not in Path(e.name).parts
            if extract:
                dest=extract/e.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
            if e.name.endswith(('coverage-audit.json','coverage-waivers.json','verdict.json')) or e.name.startswith('hot-generated/'):
                selected[e.name]=raw
            seen.add(e.name);total+=len(raw)
    assert seen==set(wanted)
    return dict(path=str(base.relative_to(ROOT)),members=len(seen),rawBytes=total,archiveBytes=archive.stat().st_size,
                archiveSha256=m['archiveSha256'],indexSha256=sha(index_raw),manifestSha256=sha(manifest_raw)),m,idx,selected
worker,manifest,index,_=reopen(ROOT/'evidence/virgl-packed-unsigned-consumer/worker',OUT/'unpacked')
assert worker['members']==26639 and worker['rawBytes']==545436693 and worker['archiveBytes']==18851139
assert worker['archiveSha256']=='8faad34f84ccfce10b8645598ad92f53a2e3b58414949d4dee6fc59a5ed7a0c6'
assert worker['indexSha256']=='a9004074786c4e82196bf4177986b7cf150c16bdd6f611ecda330f8c314cb567'
assert worker['manifestSha256']=='59503b08e0af721884fd8496d02ba4bc72f17c7982208c13d5ded7354fb66e3e'
assert manifest['sourceHead']==index['sourceHead']==FREEZE
source=[]
for e in index['records']:
    if e['path'].startswith('source/'):
        name=e['path'][7:];raw=(OUT/'unpacked'/e['path']).read_bytes()
        assert raw==git('show',FREEZE+':'+name),name
        source.append(dict(path=name,bytes=len(raw),sha256=sha(raw)))
allowed=['evidence/virgl-packed-unsigned-consumer/worker/','tasks/QUEUE.md','tasks/epic-6-transcendence/E6-T11d38-standard-packed-unsigned-consumer.md']
since=git('diff','--name-only',FREEZE,HEAD).decode().splitlines()
assert all(any(n==p or n.startswith(p) for p in allowed) for n in since),since
receipts=[]
for prefix in ['hot','cold']:
    root=OUT/'unpacked'/prefix;raw=(root/'receipt.json').read_bytes();r=json.loads(raw)
    assert r['status']=='passed' and r['gitHead']==FREEZE and r['predecessor']==BASE
    for name,digest in r['files'].items():assert sha((root/name).read_bytes())==digest,(prefix,name)
    for name,digest in r['sources'].items():assert sha((OUT/'unpacked/source'/name).read_bytes())==digest,(prefix,name)
    for name,digest in r['generated'].items():assert sha((OUT/'unpacked'/(prefix+'-generated')/name).read_bytes())==digest,(prefix,name)
    receipts.append(dict(prefix=prefix,sha256=sha(raw),files=len(r['files']),sources=len(r['sources']),generated=r['generated']))
assert receipts[0]['sha256']=='3b25b9a5a58139decdcb807a3feef5a7179bcd035634a0fa9a109a3a465160d7'
assert receipts[1]['sha256']=='61801e6a8853e61c1900edc65ada84156347346a00db44e7714c86461c449ce6'
cold_raw=(OUT/'unpacked/cold/report.json').read_bytes();cold=json.loads(cold_raw)
assert sha(cold_raw)=='0a25da170eb7f46b8e46c984f272b37cc17cd2ae9f70961613abcbcd116ba8e6'
assert cold['status']=='passed' and cold['gitHead']==cold['cloneHead']==FREEZE and not cold['statusBefore'] and not cold['statusAfter']
assert cold['receiptSha256']==receipts[1]['sha256'] and sha((OUT/'unpacked/cold/cold.log').read_bytes())==cold['logSha256']
assert cold['command']==['make','verify-E6-T11d38'] and cold['exitCode']==0
pred=[];unchanged=[]
for family in ['virgl-standard-packed-unsigned-images','virgl-packed-normalized-consumer']:
    for role in ['worker','verifier']:
        base=ROOT/'evidence'/family/role;p,m,idx,selected=reopen(base)
        for name in ['manifest.json','records.json','recording.tar.gz']:
            rel=(base/name).relative_to(ROOT).as_posix();assert (base/name).read_bytes()==git('show',BASE+':'+rel)
        for name,raw in selected.items():
            dest=OUT/'predecessor'/family/role/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
            if name.startswith('hot-generated/'):
                rel=name[len('hot-generated/'):];assert raw==(ROOT/rel).read_bytes()
        pred.append(p)
assert sum(r['members'] for r in pred)==123156
prefixes=['renderer/virgl-shader','renderer/virgl-command/constant-domain.mjs','renderer/virgl-command/resources.mjs','renderer/virgl-command/packed-unsigned-images.mjs','renderer/virgl-command/packed-normalized-images.mjs','renderer/virgl-command/integer-images.mjs','renderer/virgl-command/shared-exponent-gpu.mjs','renderer/virgl-command/color-images.mjs','renderer/virgl-command/float-images.mjs','renderer/virgl-command/packed-float-images.mjs','renderer/virgl-command/shared-exponent-images.mjs']
for name in git('ls-tree','-r','--name-only',BASE,'--',*prefixes).decode().splitlines():
    raw=(ROOT/name).read_bytes();assert raw==git('show',BASE+':'+name)
    unchanged.append(dict(path=name,bytes=len(raw),sha256=sha(raw)))
assert len(unchanged)==290
assert not git('diff','--name-only',BASE,HEAD,'--','crates','web','tools/guest','.github/workflows').strip()
result=dict(status='passed',prediction='P1-auth',worker=worker,sourceClosure=source,sourceChangesSinceFreeze=since,receipts=receipts,cold=cold,
            predecessors=pred,unchanged=unchanged,carry='HELD D37 storage/D36 compiler, resource ownership and constant contract; D38 changed consumer re-evaluated independently')
(OUT/'authentication.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status='passed',workerMembers=worker['members'],predecessorMembers=sum(r['members'] for r in pred),sourceClosure=len(source),unchanged=len(unchanged),coldClone=cold['clone'])))
