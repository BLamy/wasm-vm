import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createServer} from 'node:http';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const root='/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm',out='/tmp/e6-t12g6l-critic',directory=out+'/novel-gpu';fs.mkdirSync(directory,{recursive:true});
const sha=bytes=>createHash('sha256').update(bytes).digest('hex'),served=new Map(),errors={console:[],page:[],requests:[]};
const server=createServer((request,response)=>{try{const url=new URL(request.url,'http://127.0.0.1');if(url.pathname==='/favicon.ico'){response.writeHead(204).end();return;}
 if(url.pathname==='/'){response.writeHead(200,{'Content-Type':'text/html'}).end('<!doctype html><html><head><title>Independent fragment discard critic</title><style>body{font:16px sans-serif;padding:16px}#images{display:flex;flex-wrap:wrap}figure{width:170px}figcaption{font-size:11px}</style></head><body><h1>Fresh fragment-discard source-version attack</h1><p id="status">running</p><canvas id="gpu"></canvas><div id="images"></div></body></html>');return;}
 const relative=url.pathname.slice(1);let filename=relative==='critic-test.mjs'?out+'/independent-gpu-browser.mjs':relative==='critic-plan.json'?out+'/independent-gpu-plan.json':path.resolve(root,relative);assert.ok(filename.startsWith(root+'/renderer/virgl-shader/')||filename===out+'/independent-gpu-browser.mjs'||filename===out+'/independent-gpu-plan.json');
 const raw=fs.readFileSync(filename);served.set(relative,{path:relative,sha256:sha(raw),bytes:raw.length});response.writeHead(200,{'Content-Type':filename.endsWith('.wasm')?'application/wasm':filename.endsWith('.json')?'application/json':'text/javascript','Cache-Control':'no-store'}).end(raw);
}catch(e){response.writeHead(404).end(String(e));}});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const {chromium}=await import(pathToFileURL(root+'/web/node_modules/playwright/index.mjs'));
let browser,report={task:'E6-T12g6l',status:'running',sourceBoundary:'4a1e9a36e33e072a58fd60815b1e6ae8c93460ab',headless:false,planSha256:sha(fs.readFileSync(out+'/independent-gpu-plan.json')),errors};
try{
 browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:false,args:['--enable-gpu']});
 const session=await browser.newBrowserCDPSession();report.systemInfo=await session.send('SystemInfo.getInfo');assert.equal(report.systemInfo.gpu.featureStatus.webgl,'enabled');report.commandLine=(await session.send('Browser.getBrowserCommandLine')).arguments;assert.ok(!report.commandLine.some(a=>/swiftshader|--disable-gpu(?:$|=)/i.test(a)));
 const page=await browser.newPage({viewport:{width:1120,height:900}});page.on('console',m=>{if(m.type()==='error')errors.console.push(m.text());});page.on('pageerror',e=>errors.page.push(e.message));page.on('requestfailed',r=>errors.requests.push(r.failure()));
 await page.goto('http://127.0.0.1:'+server.address().port);report.acceptance=await page.evaluate(async()=>JSON.stringify(await(await import('/critic-test.mjs')).run())).then(JSON.parse);assert.equal(report.acceptance.status,'passed');assert.equal(report.acceptance.planSha256,report.planSha256);assert.equal(report.acceptance.checkedPixels,864);assert.deepEqual(errors,{console:[],page:[],requests:[]});
 await page.screenshot({path:directory+'/browser.png',fullPage:true});report.screenshotSha256=sha(fs.readFileSync(directory+'/browser.png'));report.served=[...served.values()];report.status='passed';
}catch(e){report.status='failed';report.failure={message:e.message,stack:e.stack};throw e;}finally{
 if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));fs.writeFileSync(directory+'/report.json',JSON.stringify(report,null,2)+'\n');
}
console.log('24 fresh source-version/alias/signed-special programs passed 864 literal physical Metal cells.');
