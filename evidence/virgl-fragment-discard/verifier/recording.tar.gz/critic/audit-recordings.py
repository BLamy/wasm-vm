from pathlib import Path
import json,hashlib,subprocess,struct,re,importlib.util
BASE=Path('/tmp/e6-t12g6l-critic');WORKER=BASE/'worker';ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
spec=importlib.util.spec_from_file_location('critic_literal',BASE/'literal-oracle.py');literal=importlib.util.module_from_spec(spec);spec.loader.exec_module(literal)
planned=json.loads((BASE/'independent-pixel-predictions.json').read_bytes());summary=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
for prefix,gen in [('hot','generated'),('cold/acceptance','cold-generated')]:
 nativePath=WORKER/prefix/'native/report.json';raw=nativePath.read_bytes();native=json.loads(raw)
 wasm=json.loads((WORKER/prefix/'wasm/report.json').read_bytes());assert wasm['nativeSha256']==sha(raw)
 assert len(native['cases'])==len(wasm['cases'])==2007
 tokenCount=accepted=rejected=0;markers=[]
 for c,w in zip(native['cases'],wasm['cases']):
  assert c['result']['ok']==c['ok'] and c['pairResult']['ok']==c['pairOk']
  assert w['name']==c['name']and w['result']==c['result']and w['pair']==c['pairResult']
  if c['ok']:
   accepted+=1;md=c['result']['metadata'];assert md['discardContract']['authority']=='no-new-numeric-range-or-initialization-facts'
   if 'always'in c:assert md['discardContract']['alwaysDiscards']==c['always']
   if c['name'].startswith(tuple(['positive-','negative-'])):
    assert md['discardContract']['alwaysDiscards']==literal.killed(c['text'],[],0,0)
   assert md['discardContract']['alwaysDiscards'] or md['outputs'][0]['writtenMask']==15
  else:
   rejected+=1;assert 'glsl'not in c['result'] and 'metadata'not in c['result']
   assert all(k not in c['pairResult']for k in ['vertex','fragment','metadata'])
  if c['primary']:
   expected=[]
   for rawline in c['text'].splitlines():
    line=re.sub(r'^\d+:\s*','',rawline)
    if line=='KILL':expected.append(dict(opcode='KILL',destinations=0,sources=0,precise=0,saturate=0))
    elif line.startswith('KILL_IF '):
     m=re.fullmatch(r'KILL_IF (-?)(\|?)(CONST|IN|TEMP|IMM)\[(\d+)\](?:\.([xyzw]{4}))?(\|?)',line);assert m
     neg,absolute,file,index,swizzle,close=m.groups();assert absolute==close
     expected.append(dict(opcode='KILL_IF',destinations=0,sources=1,precise=0,saturate=0,file={'CONST':1,'IN':2,'TEMP':4,'IMM':7}[file],index=int(index),negate=int(bool(neg)),absolute=int(bool(absolute)),swizzle=['xyzw'.index(v)for v in swizzle or 'xyzw']))
   assert c['primaryResult']['discardInstructions']==expected
   tokenCount+=len(expected)
  if any(s in c['name']for s in ['init','authority','partial-known','depth-','instruction-bound','conditional-terminal','source','label-','vertex-','raster-bank']):markers.append(dict(index=c['index'],name=c['name'],ok=c['result']['ok'],always=c['result'].get('metadata',{}).get('discardContract',{}).get('alwaysDiscards')))
 binary=WORKER/gen/'discard-sanitize/discard-test';binary.chmod(0o755)
 replay=BASE/('hot-replay'if prefix=='hot'else'cold-replay');replay.mkdir(exist_ok=True)
 import os
 env=dict(os.environ,LLVM_PROFILE_FILE=str(replay/'new-independent-run.profraw'),ASAN_OPTIONS='abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
 run=subprocess.run([str(binary)],input=(WORKER/prefix/'native/cases.bin').read_bytes(),capture_output=True,env=env)
 assert run.returncode==0 and run.stderr==b'' and run.stdout==(WORKER/prefix/'native/native.log').read_bytes()
 (replay/'native.log').write_bytes(run.stdout);(replay/'native.stderr').write_bytes(run.stderr)
 consumer=json.loads((WORKER/prefix/'consumer.json').read_bytes());assert consumer['accessorInvocations']==0 and len(consumer['forgeries'])==1011 and all(f['result']['ok']is False for f in consumer['forgeries'])
 assert len(consumer['banks'])==6 and len(consumer['combined'])==4 and all(c['base']==c['restored']for c in consumer['combined'])
 for b in consumer['banks']:
  for check in b['checks']:assert check['result']['ok']==check['wanted']
 direct=indirect=qualified=0;browserMarkers=[];errors=[]
 for seed in [2654435769,608135816,2242054355]:
  path=WORKER/prefix/f'gpu-{seed}/report.json';report=json.loads(path.read_bytes());a=report['acceptance'];pp=planned[str(seed)]
  assert report['status']==a['status']=='passed' and not report['trackedChanges'];assert report['browserErrors']==dict(console=[],page=[],requests=[])
  assert not report['browser']['launch']['headless'];assert report['browser']['gpu']['featureStatus'][report['browser']['webglFeature']]=='enabled'
  assert 'Metal'in a['renderer']['renderer'] and a['objects']['live']==0
  assert len(a['probes'])==640 and len(a['consumers'])==2
  for i,(p,wanted)in enumerate(zip(a['probes'],pp)):
   assert all(p[k]==wanted[k]for k in ['name','text','words','geometry','backend'])
   assert sha(bytes(p['rgbaBytes']))==p['sha256'];assert len(p['rgbaBytes'])==len(wanted['pixels'])*4
   for j,point in enumerate(wanted['pixels']):
    observed=p['rgbaBytes'][j*4:j*4+4]
    if observed!=point['rgba']:
     assert not wanted['normative'] and point['inside'] and observed in [[17,34,51,68],[64,128,191,255]],(p['name'],j,point,observed)
     qualified+=1
    direct+=1
   assert p['mutation']is None and p['logs']==dict(vertex='',fragment='',link='')
   output=p['reflection']['output'];assert output==0 or output==-1 and p['policy']['discard']['alwaysDiscards']
   upload=p.get('bankUpload',{})
   if upload.get('words'):
    assert upload['words']==p['words'][:upload['declaredCount']*4]
    assert upload['observed']==[upload['words'][j*4:j*4+4]for j in range(upload['count'])]
    assert set(upload['callerAfter'])=={0xdeadbeef}
   if p['backend']=='owned'and p['variant']in ['kill-only','raster-bank','conditional-raster-bank','both-killed']:browserMarkers.append(dict(seed=seed,index=i,name=p['name'],output=output,always=p['policy']['discard']['alwaysDiscards'],rawSha256=p['sha256']))
  for c in a['consumers']:
   assert c['commandsPerStep']==1+seed%3 and len(c['captures'])==20 and len(c['rejections'])==10
   assert all(v==0for v in c['finalBudgets'].values()) and all(v==0for v in c['finalResourceBudgets'].values())
   assert all(set(s['after'])=={255}for s in c['submissions'])
   for capture in c['captures']:
    wanted=pp[capture['sourceIndex']];assert wanted['backend']=='owned'and capture['fragmentText']==wanted['text']and capture['words']==wanted['words']
    own=dict(wanted,text=capture['fragmentText']);points=literal.pixels(own,width=32,height=32)
    assert len(capture['rgbaBytes'])==len(points)*4 and sha(bytes(capture['rgbaBytes']))==capture['sha256']
    assert all(capture['rgbaBytes'][j*4:j*4+4]==p['rgba']for j,p in enumerate(points))
    indirect+=len(points)
    terminal=capture['pair']['fragment']['metadata']['discardContract']['alwaysDiscards'];output=capture['program']['reflection']['outputs'][0]['location']
    assert output==0 or output==-1 and terminal
    assert capture['drawBuffer']==(0 if output==-1 else 36064)
    assert capture['program']['interfaceKey'].endswith('|tgsi-fragment-discard-v1:ordered-any-negative/raw-words/always-'+str(int(terminal)))
   for rejection in c['rejections']:
    assert rejection['result']['ok']is False and rejection['result']['appliedCommands']==0and rejection['before']==rejection['after']
    assert all(c['asynchronous']and e['call']in ['fenceSync','deleteSync']for e in rejection['nativeEvents'])
  assert a['directPixels']==sum(len(p['pixels'])for p in pp) and a['consumerPixels']==40960
 faults=[]
 for fault in ['inhibit','invert','x-only','unconditional']:
  path=WORKER/prefix/f'fault-{fault}/report.json';report=json.loads(path.read_bytes());a=report['acceptance'];assert report['status']=='failed'and a['status']=='failed'and not a['consumers']
  assert report['browserErrors']==dict(console=[],page=[],requests=[])and a['objects']['live']==0
  mutations=[(i,p)for i,p in enumerate(a['probes'])if p['mutation']];assert len(mutations)==1
  i,p=mutations[0];wanted=planned[str(a['seed'])][i];mutation=p['mutation'];assert mutation['kind']==fault
  assert mutation['original']==p['pair']['fragment']['glsl']and mutation['served']==mutation['original'].replace(mutation['needle'],mutation['replacement'],1)
  assert any(e['call']=='shaderSource'and e['source']==mutation['served']for e in a['events'])
  mismatches=[dict(x=q['x'],y=q['y'],expected=q['rgba'],observed=p['rgbaBytes'][j*4:j*4+4])for j,q in enumerate(wanted['pixels'])if p['rgbaBytes'][j*4:j*4+4]!=q['rgba']]
  assert len(mismatches)>0 and 'independent discard pixel mismatch'in a['failure']['message']
  faults.append(dict(fault=fault,sourceIndex=i,first=mismatches[0],mismatches=len(mismatches),reportSha256=sha(path.read_bytes())))
 legacy=json.loads((WORKER/prefix/'legacy.json').read_bytes());assert len(legacy['cases'])==8349 and len(legacy['extensions'])==2
 retained=json.loads((WORKER/prefix/'retained/report.json').read_bytes());assert len(retained['originals'])==25and sum(c['native']['ok']for c in retained['originals'])==23
 failedOriginals=[dict(c)for c in retained['originals']if not c['native']['ok']]
 for c in failedOriginals:assert any(v in json.dumps(c)for v in ['c5806d','92cb86'])
 guards=[]
 for file in sorted((WORKER/prefix).glob('independent-*-guards.json')):
  g=json.loads(file.read_bytes());assert g['status']=='passed'and g['cases']==len(g['native'])==len(g['wasm'])
  for n,w in zip(g['native'],g['wasm']):assert n['result']==w['result']or n['result'].get('error',{}).get('code')==w['result'].get('error',{}).get('code')=='invalid-input'
  guards.append(dict(path=file.name,cases=g['cases'],sha256=sha(file.read_bytes())))
 summary.append(dict(recording=prefix,nativeCases=2007,accepted=accepted,rejected=rejected,pinnedDiscardTokens=tokenCount,nativeReplayExact=True,nativeReplaySha256=sha(run.stdout),directPixels=direct,consumerPixels=indirect,qualifiedPrimaryPixels=qualified,faults=faults,markers=markers,browserMarkers=browserMarkers,metadataForgeries=1011,inheritedBanks=6,combinedMetadata=4,legacyPreserved=8347,legacyExtensions=2,retainedAdmission='23/25',guards=guards))
 assert direct==201600 and indirect==122880 and qualified==6336
(BASE/'recording-audit.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps([dict(recording=r['recording'],nativeCases=r['nativeCases'],nativeReplayExact=r['nativeReplayExact'],directPixels=r['directPixels'],consumerPixels=r['consumerPixels'],qualifiedPrimaryPixels=r['qualifiedPrimaryPixels'],faults=r['faults'])for r in summary],indent=2))
