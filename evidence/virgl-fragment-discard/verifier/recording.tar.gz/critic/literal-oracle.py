"""Independent critic: decoded TGSI values and literal clip rectangle; no GLSL or recorded expectations."""
import struct,re,json,hashlib,subprocess
from pathlib import Path

def word(v):return struct.unpack('<I',struct.pack('<f',v))[0]
def floating(w):return struct.unpack('<f',struct.pack('<I',w))[0]
def killed(text,bank,x,y):
 regs={('CONST',i):list(bank[i*4:i*4+4]) for i in range(len(bank)//4)}
 regs['IN',0]=[word(x+.5),word(y+.5),word(.5),word(1.)]
 enabled=[True];choices=[]
 def read(token):
  m=re.fullmatch(r'(-?)(\|?)(IMM|CONST|TEMP|IN)\[(\d+)\](?:\.([xyzw]{4}))?(\|?)',token)
  assert m,'literal operand '+token
  negative,absolute,file,index,swizzle,close=m.groups();assert absolute==close
  result=[regs[file,int(index)]['xyzw'.index(c)] for c in (swizzle or 'xyzw')]
  assert all(v is not None for v in result),'literal source initialized'
  if absolute:result=[v&0x7fffffff for v in result]
  if negative:result=[v^0x80000000 for v in result]
  return result
 for raw in text.splitlines():
  line=re.sub(r'^\d+:\s*','',raw).strip()
  if not line or line=='FRAG' or line.startswith(('PROPERTY ','DCL ')):continue
  imm=re.fullmatch(r'IMM\[(\d+)\] (FLT32|UINT32) \{(.*)\}',line)
  if imm:
   i,kind,values=imm.groups();regs['IMM',int(i)]=[int(v) if kind=='UINT32' else word(float(v)) for v in values.split(',')];continue
  opcode,_,args=line.partition(' ')
  if opcode=='END':break
  if opcode=='UIF':
   choices.append(read(args)[0]!=0 if enabled[-1] else False);enabled.append(enabled[-1] and choices[-1]);continue
  if opcode=='ELSE':enabled[-1]=enabled[-2] and not choices[-1];continue
  if opcode=='ENDIF':enabled.pop();choices.pop();continue
  if not enabled[-1]:continue
  if opcode=='KILL':return True
  if opcode=='KILL_IF':
   values=read(args)
   if any(floating(v)<0. for v in values):return True
   continue
  tokens=args.split(', ');m=re.fullmatch(r'(OUT|TEMP)\[(\d+)\](?:\.([xyzw]+))?',tokens[0]);assert m,line
  file,index,mask=m.groups();operands=[read(v) for v in tokens[1:]]
  if opcode=='MOV':new=list(operands[0])
  elif opcode=='AND':new=[a&b for a,b in zip(*operands)]
  elif opcode=='OR':new=[a|b for a,b in zip(*operands)]
  elif opcode=='FSLT':new=[0xffffffff if floating(a)<floating(b) else 0 for a,b in zip(*operands)]
  else:raise AssertionError('unmodeled literal instruction '+opcode)
  existing=regs.setdefault((file,int(index)),[None]*4)
  for c in mask or 'xyzw':existing['xyzw'.index(c)]=new['xyzw'.index(c)]
 assert enabled==[True] and not choices
 assert regs['OUT',0]==[word(.25),word(.5),word(.75),word(1.)],'literal color'
 return False

def pixels(probe,width=None,height=None):
 g=probe['geometry'];width=width or g['width'];height=height or g['height']
 assert g['vertices']==[[-1,-1,0,1],[1,-1,0,1],[-1,1,0,1],[-1,1,0,1],[1,-1,0,1],[1,1,0,1]] and g['indices']==list(range(6))
 x0,y0,w,h=g['viewport'];out=[]
 for y in range(height):
  for x in range(width):
   inside=x0<=x<x0+w and y0<=y<y0+h
   discarded=killed(probe['text'],probe['words'],x,y) if inside else None
   out.append(dict(x=x,y=y,inside=inside,discarded=discarded,rgba=[64,128,191,255] if inside and not discarded else [17,34,51,68]))
 return out

if __name__=='__main__':
 root=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');out=Path('/tmp/e6-t12g6l-critic');plans={}
 for seed in [2654435769,608135816,2242054355,1831565813]:
  raw=subprocess.check_output(['node','--input-type=module','-e',f"import{{physicalPlan}}from'./tools/virgl-fragment-discard/cases.mjs';process.stdout.write(JSON.stringify(physicalPlan({seed})));"],cwd=root)
  plan=json.loads(raw);assert len(plan)==640
  plans[str(seed)]=[dict(name=p['name'],text=p['text'],words=p['words'],geometry=p['geometry'],backend=p['backend'],normative=p['backend']=='owned' or p['portablePrimary'],pixels=pixels(p))for p in plan]
 target=out/'independent-pixel-predictions.json';target.write_text(json.dumps(plans,separators=(',',':'))+'\n');print('Independent literal predictions saved before checking framebuffer bytes:',hashlib.sha256(target.read_bytes()).hexdigest())
