import {createVirglShaderBridge} from '/renderer/virgl-shader/index.mjs';
import {createProgram,texture2d,bindSystemBlocks,digest} from '/renderer/virgl-shader/tests/browser.mjs';
const require=(ok,label)=>{if(!ok)throw new Error(label);};
const same=(a,b,label)=>require(JSON.stringify(a)===JSON.stringify(b),label);
export async function run(){
 const canvas=document.querySelector('#gpu');canvas.width=canvas.height=6;
 const gl=canvas.getContext('webgl2',{antialias:false,preserveDrawingBuffer:true,failIfMajorPerformanceCaveat:true});require(gl instanceof WebGL2RenderingContext,'actual WebGL2');
 const debug=gl.getExtension('WEBGL_debug_renderer_info');require(debug,'physical device identity');
 const report={task:'E6-T12g6l',status:'running',guestExecution:false,productionNegotiation:false,seed:0x6d2b79f5,renderer:gl.getParameter(debug.UNMASKED_RENDERER_WEBGL),captures:[],events:[],created:0,deleted:0};window.__criticDiscard=report;
 require(report.renderer.includes('Metal')&&!/swiftshader|software|llvmpipe/i.test(report.renderer),'physical Metal');
 const bridge=await createVirglShaderBridge(),response=await fetch('/critic-plan.json'),bytes=new Uint8Array(await response.arrayBuffer());report.planSha256=await digest(bytes);const {plan}=JSON.parse(new TextDecoder().decode(bytes));
 const vertex='VERT\nDCL IN[0]\nDCL OUT[0], POSITION\nMOV OUT[0], IN[0]\nEND\n';
 let checked=0;
 for(const item of plan){
  const pair=bridge.translatePair({vertexText:vertex,fragmentText:item.text});same(pair,item.nativePair,'actual native/Wasm pair');
  const shaders=[],built=createProgram(gl,pair.vertex,pair.fragment),program=built.program;report.events.push({source:pair.fragment.glsl,logs:built.logs});
  const buffers=[],vao=gl.createVertexArray(),framebuffer=gl.createFramebuffer();let texture=null;
  try{
   gl.useProgram(program);gl.bindVertexArray(vao);bindSystemBlocks(gl,program,pair.vertex.metadata,buffers);
   const mesh=gl.createBuffer(),indices=gl.createBuffer();buffers.push(mesh,indices);gl.bindBuffer(gl.ARRAY_BUFFER,mesh);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(item.geometry.vertices.flat()),gl.STATIC_DRAW);
   const location=gl.getAttribLocation(program,'in_0');require(location>=0,'actual vertex binding');gl.enableVertexAttribArray(location);gl.vertexAttribPointer(location,4,gl.FLOAT,false,16,0);
   gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,indices);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,new Uint16Array(item.geometry.indices),gl.STATIC_DRAW);
   const uniform=pair.fragment.metadata.uniforms[0],bankLocation=uniform?gl.getUniformLocation(program,uniform.name+'[0]'):null;
   if(bankLocation){const words=new Uint32Array(item.words);gl.uniform4uiv(bankLocation,words);same([...gl.getUniform(program,bankLocation)],item.words,'actual raw bank word copy');}
   const output=gl.getFragDataLocation(program,'fsout_c0'),always=pair.fragment.metadata.discardContract.alwaysDiscards;require(output===0||output===-1&&always,'checked terminal output');
   texture=texture2d(gl,6,6,null);gl.bindFramebuffer(gl.FRAMEBUFFER,framebuffer);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,texture,0);same(gl.checkFramebufferStatus(gl.FRAMEBUFFER),gl.FRAMEBUFFER_COMPLETE,'literal RGBA8 surface');
   for(const c of [gl.DITHER,gl.BLEND,gl.DEPTH_TEST,gl.CULL_FACE,gl.SCISSOR_TEST,gl.STENCIL_TEST,gl.RASTERIZER_DISCARD,gl.SAMPLE_COVERAGE])gl.disable(c);
   gl.colorMask(true,true,true,true);gl.viewport(...item.geometry.viewport);gl.drawBuffers([gl.COLOR_ATTACHMENT0]);gl.readBuffer(gl.COLOR_ATTACHMENT0);gl.clearColor(17/255,34/255,51/255,68/255);gl.clear(gl.COLOR_BUFFER_BIT);
   gl.drawBuffers([output===-1?gl.NONE:gl.COLOR_ATTACHMENT0]);gl.drawElements(gl.TRIANGLES,6,gl.UNSIGNED_SHORT,0);
   const raw=new Uint8Array(6*6*4);gl.readPixels(0,0,6,6,gl.RGBA,gl.UNSIGNED_BYTE,raw);same(gl.getError(),gl.NO_ERROR,'physical novel draw');
   const entry={name:item.name,text:item.text,words:item.words,pair,reflectionOutput:output,bankActive:Boolean(bankLocation),rgbaBytes:[...raw],sha256:await digest(raw),prediction:item.prediction};report.captures.push(entry);
   for(const point of item.prediction){const at=(point.y*6+point.x)*4;same([...raw.subarray(at,at+4)],point.rgba,'literal novel pixel '+item.name+' '+point.x+','+point.y);checked++;}
   const figure=document.createElement('figure'),image=document.createElement('canvas'),caption=document.createElement('figcaption');image.width=image.height=6;image.style.width=image.style.height='96px';image.style.imageRendering='pixelated';const flipped=new Uint8ClampedArray(raw.length);for(let y=0;y<6;y++)flipped.set(raw.subarray(y*24,(y+1)*24),(5-y)*24);image.getContext('2d').putImageData(new ImageData(flipped,6,6),0,0);caption.textContent=item.sourceCase;figure.append(image,caption);document.querySelector('#images').append(figure);
  }finally{
   gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.bindVertexArray(null);gl.useProgram(null);gl.deleteTexture(texture);gl.deleteFramebuffer(framebuffer);gl.deleteVertexArray(vao);for(const b of buffers)gl.deleteBuffer(b);gl.deleteProgram(program);require(!gl.isFramebuffer(framebuffer)&&!gl.isVertexArray(vao)&&!gl.isProgram(program)&&buffers.every(b=>!gl.isBuffer(b))&&(!texture||!gl.isTexture(texture)),'actual object deletion');report.deleted++;
  }
 }
 require(report.deleted===plan.length,'every case disposed');same(gl.getError(),gl.NO_ERROR,'final physical error');report.checkedPixels=checked;report.status='passed';document.querySelector('#status').textContent=checked+' independently predicted Metal pixels';return report;
}
