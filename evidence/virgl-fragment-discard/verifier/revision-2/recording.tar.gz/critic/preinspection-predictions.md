# E6-T12g6l incremental revision-2 predictions

Recorded before revised evidence inspection. Root retains repository/Git custody.

Source: `e7137ce55e714c4a5759175529a82cc056a6d097`; previous source: `4a1e9a36e33e072a58fd60815b1e6ae8c93460ab`.
Oriented change: exactly five deleted lines in bridge.c; no other runtime/harness delta.
Carry unchanged P1-P8, N1 and predecessor HELD results from critic verdict `a83cb7e2f428d1fff53d6682c319742a41f4bad112283bbd8d9fc6bf9b926983`.

- P9-R2 — new original hot/cold LLVM exports against changed runtime hunks. Predicted: The deleted guard has no remaining executable region. Every surviving changed executable line maps to a positive hit in both final original profiles; retained nonbehavior waivers remain unchanged. Bridge lines after the deletion map back by +5 to the old source; no new runtime behavior or waiver is needed. Falsified by: Any surviving added executable statement without a profile hit, new source mismatch, or newly introduced behavior.

- S1-R2 — revision-2 seal index/archive and hot/cold source receipts. Predicted: Every indexed member matches byte length and SHA-256; hot/cold report heads and source entries bind e7137ce55e714c4a5759175529a82cc056a6d097, including bridge.c ddedaeb403cdcd0f9353826bb208417af8661e07d359d9f07cefbe27f0d2b42c. Corrected-source receipts pass; no old profile, report or binary is relabeled. Falsified by: Any mismatch, old bound source head, nonexact source entry or absent corrected-source acceptance receipt.

- S2-R2 — revision-2 original sanitizer binaries and raw/merged profiles. Predicted: Each archived profraw merges successfully using preserved raw bytes; coverage export with that recording's archived original executable reproduces its recorded coverage. The binaries and profile source paths correspond to the revised hot/cold lineage. Falsified by: Profile mismatch, absent original binary, incompatible instrumentation, reconstructed binary treated as original, or coverage not bound to revised source.

- S3-R2 — immutable initial worker and critic seals plus unchanged runtime/dependency boundary. Predicted: All initial seal hashes remain identical. Outside the exactly deleted guard the runtime and acceptance harness bytes match the prior frozen source; P1-P8/N1/predecessor proofs carry without repeating their semantic attacks. Falsified by: Changed seal bytes or any changed runtime/harness/dependency beyond the five-line deletion.

- S4-R2 — revised acceptance/pristine reports. Predicted: Complete corrected-source hot/cold acceptance passes with the same recorded scoped counts and no sanitizer/browser errors. Cold clone is committed revised source with scrubbed environment. No broader product claim is introduced. Falsified by: Acceptance failure, missing scope markers, nonscrubbed clone, uncommitted source dependency, or broadened negotiation/deployment/performance claim.

- T1-R2 — bounded promotion candidates, if promoted after coverage holds. Predicted: Promoted deterministic literal/version guards retain the independently verified oracle and fixtures, only touched harness gates rerun, and no runtime file changes. Falsified by: Self-derived oracle, modified semantics, missing candidate assertions, or runtime edit.
