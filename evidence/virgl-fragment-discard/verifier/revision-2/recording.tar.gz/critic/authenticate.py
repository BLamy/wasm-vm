from pathlib import Path,PurePosixPath
import subprocess,hashlib,json,tarfile
root=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');out=Path('/tmp/e6-t12g6l-critic/revision-2');dest=out/'worker';seal=root/'evidence/virgl-fragment-discard/worker/revision-2'
sha=lambda b:hashlib.sha256(b).hexdigest()
expected={'manifest.json':'a7e58892ccf37211ac6c2b14b02a5fee08850aec4e560c929fa10bdcd0233439','recording.tar.gz':'50136a98be6a8e559f69a783eb96bae859ff5afb60765c07da77177d5e49107e','records.json':'02958d5e896190be2704d42a8f58cc7fc00e5dfc5bd2e5259b97d1822bb70883'}
for file,digest in expected.items():assert sha((seal/file).read_bytes())==digest,file
manifest=json.loads((seal/'manifest.json').read_text());index=json.loads((seal/'records.json').read_text());head='e7137ce55e714c4a5759175529a82cc056a6d097'
assert manifest['sourceHead']==index['sourceHead']==head
for key in ['archive','recordIndex']:
 spec=manifest[key];data=(seal/spec['path']).read_bytes();assert len(data)==spec['bytes'] and sha(data)==spec['sha256'],key
records={r['path']:r for r in index['records']};assert len(records)==len(index['records'])==manifest['records']==148
with tarfile.open(seal/'recording.tar.gz') as tar:
 members=tar.getmembers();assert len(members)==len(records);assert set(m.name for m in members)==set(records)
 for m in members:
  p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts,m.name
  data=tar.extractfile(m).read();r=records[m.name];assert len(data)==r['bytes'] and sha(data)==r['sha256'],m.name
  path=dest/p;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
old={
 'worker/manifest.json':'daf510538b80e3da376a7d003457657f6266ce07a6b23fcac638733efbbcd31a',
 'worker/records.json':'a7614d8db95e013dd72d431788cf82e6626d6465024bac1eae08018148475730',
 'worker/recording.tar.gz':'dcd4019e8fc1b9a03bdd6e7471b758ae47a61a1d1a38ee3e8409e8fd826ea0bf',
 'verifier/manifest.json':'21ce3644f99d69b8c4c7bc2518e395baebc45adc129699c508e7842d12d8c6cd',
 'verifier/records.json':'9cbc5263cc7fa006fe303deb4e952494311d6048eae45bd0fc682d3d94f941d9',
 'verifier/recording.tar.gz':'65a9e6775bf946e20fda667e6e83daa04aefdd0c0e19549860b32f4a4603bc60'}
for file,digest in old.items():assert sha((root/'evidence/virgl-fragment-discard'/file).read_bytes())==digest,file
saved=Path('/tmp/e6-t12g6l-critic/custody-untracked-paths.bin').read_bytes();untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=root);assert untracked==saved
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='408b6637c255d0a9dfac6461c0789f0598ecd997'
assert subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root)==b''
result={'sourceHead':head,'workerSubmissionHead':'408b6637c255d0a9dfac6461c0789f0598ecd997','sealDigests':expected,'records':len(records),'memberAuthentication':'all member byte lengths and SHA-256 held','originalSeals':old,'historicalUntracked':4202,'untrackedSha256':sha(saved),'recordsIndex':index['records']}
(out/'authentication.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'authenticatedMembers':len(records),'initialSealsUnchanged':True,'historicalUntracked':4202,'extracted':str(dest),'memberPaths':[p for p in records if ('receipt' in p or 'pristine' in p or 'native/' in p or 'source' in p or p.endswith('report.json'))]},indent=2))
