from pathlib import Path
import subprocess,json,hashlib
root=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');out=Path('/tmp/e6-t12g6l-critic/revision-2');w=out/'worker';old=Path('/tmp/e6-t12g6l-critic/worker');head='e7137ce55e714c4a5759175529a82cc056a6d097'
sha=lambda b:hashlib.sha256(b).hexdigest()
tracked=set(subprocess.check_output(['git','ls-tree','-r','--name-only',head],cwd=root,text=True).splitlines());cache={}
seals=json.loads((out/'authentication.json').read_bytes());result=[]
for prefix,generated in [('hot','generated'),('cold/acceptance','cold-generated')]:
 receipt_path=w/prefix/'receipt.json';receipt=json.loads(receipt_path.read_bytes());previous=json.loads((old/prefix/'receipt.json').read_bytes());previous_sources={s['path']:s for s in previous['sources']}
 assert receipt['gitHead']==head and receipt['status']=='passed'
 expected={'nativeCases':2007,'wasmCases':2007,'wasmPairs':2007,'primaryComparisons':1975,'legacyCases':8349,'legacyExtensions':2,'metadataAttacks':1011,'ownedBanks':6,'combinedBases':4,'directPixels':201600,'consumerPixels':122880,'checkedPixels':324480,'qualifiedPrimaryPixels':6336}
 for key,value in expected.items():assert receipt[key]==value,key
 assert receipt['guestExecution']is receipt['productionNegotiation']is False
 for spec in receipt['records']:
  raw=(w/prefix/spec['path']).read_bytes();assert len(raw)==spec['bytes'] and sha(raw)==spec['sha256'],spec['path']
 authenticated=generated_count=carried_generated=0;source_index={s['path']:s for s in receipt['sources']}
 assert len(source_index)==len(receipt['sources'])
 for s in receipt['sources']:
  path=s['path']
  if path in tracked:
   if path not in cache:cache[path]=subprocess.check_output(['git','show',head+':'+path],cwd=root)
   raw=cache[path];authenticated+=1
  else:
   assert path.startswith('renderer/virgl-shader/build/'),path
   artifact=w/generated/path.removeprefix('renderer/virgl-shader/build/')
   if artifact.exists():raw=artifact.read_bytes();generated_count+=1
   else:
    assert previous_sources[path]==s,path
    raw=(root/path).read_bytes();carried_generated+=1
  assert len(raw)==s['bytes'] and sha(raw)==s['sha256'],path
 assert source_index['renderer/virgl-shader/bridge.c']['sha256']=='ddedaeb403cdcd0f9353826bb208417af8661e07d359d9f07cefbe27f0d2b42c'
 for path in sorted((w/prefix).glob('gpu-*/report.json'))+sorted((w/prefix).glob('fault-*/report.json')):
  report=json.loads(path.read_bytes());assert report['gitHead']==head and report['trackedChanges']==[]
  assert report['browserErrors']==dict(console=[],page=[],requests=[])
  assert report['guestExecution']is report['productionNegotiation']is False
  for s in report['sources']:
   bound=source_index[s['path']];assert s['sha256']==bound['sha256'] and s.get('size',s.get('bytes'))==bound['bytes'],s['path']
  for s in report['servedFiles']:assert s['sha256']==source_index[s['path']]['sha256'],s['path']
  assert report['acceptance']['objects']['live']==0
  assert not report['browser']['launch']['headless']
  assert report['browser']['gpu']['featureStatus'][report['browser']['webglFeature']]=='enabled'
  assert 'Metal' in report['acceptance']['renderer']['renderer']
  if '/gpu-' in str(path):assert report['status']==report['acceptance']['status']=='passed' and report['acceptance']['checkedPixels']==report['acceptance']['directPixels']+report['acceptance']['consumerPixels']
  else:assert report['status']==report['acceptance']['status']=='failed'
  coverage=json.loads((path.parent/report['browserCoverage']['path']).read_bytes())
  for script in coverage['scripts']:assert script['sha256']==source_index[script['source']]['sha256']
 native=json.loads((w/prefix/'native/report.json').read_bytes());assert native['gitHead']==head and native['status']=='passed' and len(native['cases'])==2007
 assert (w/prefix/'native/native.stderr').read_bytes()==b''
 for file in ['cases.bin','native.log']:
  assert (w/prefix/'native'/file).read_bytes()==(old/prefix/'native'/file).read_bytes(),file+' held-output parity'
 wasm=json.loads((w/prefix/'wasm/report.json').read_bytes());assert wasm['gitHead']==head and wasm['status']=='passed' and len(wasm['cases'])==2007
 assert wasm['nativeSha256']==sha((w/prefix/'native/report.json').read_bytes())
 for n,v in zip(native['cases'],wasm['cases']):assert n['name']==v['name'] and n['result']==v['result'] and n['pairResult']==v['pair']
 binary=w/generated/'discard-sanitize/discard-test';original=binary.read_bytes();assert len(original)==native['binary']['bytes'] and sha(original)==native['binary']['sha256']
 profraw=w/prefix/'native/native.profraw';profdata=out/('hot-remerged.profdata' if prefix=='hot' else 'cold-remerged.profdata')
 subprocess.run(['xcrun','llvm-profdata','merge','-sparse',str(profraw),'-o',str(profdata)],check=True)
 assert profdata.read_bytes()==(w/prefix/'native/native.profdata').read_bytes()
 export=json.loads(subprocess.check_output(['xcrun','llvm-cov','export',str(binary),'-instr-profile='+str(profdata)],stderr=subprocess.PIPE))
 names=['bridge.c','raw_bits.c','native_tests/fragment_discard.c']
 for d in export['data']:
  d['files']=[f for f in d['files'] if any(f['filename'].endswith('/'+n)for n in names)]
  d['functions']=[f for f in d['functions']if any(any(name.endswith('/'+n)for n in names) for name in f['filenames'])]
 assert export==json.loads((w/prefix/'native/coverage.json').read_bytes())
 export_path=out/('hot-original-coverage.json'if prefix=='hot'else'cold-original-coverage.json');export_path.write_text(json.dumps(export,indent=2)+'\n')
 functions=[dict(name=f['name'],count=f['count'])for d in export['data']for f in d['functions']if f['name'].split(':')[-1]in ['validate_body','discard_instruction','discard_contract','interface_key','raw_discard_guaranteed','raw_record','raw_emit','raster_graph']]
 result.append({'recording':prefix,'receiptSha256':sha(receipt_path.read_bytes()),'sourceEntries':len(source_index),'committedSourceEntries':authenticated,'sealedGeneratedEntries':generated_count,'unchangedCollectorOnlyGeneratedEntries':carried_generated,'correctedBridgeSha256':source_index['renderer/virgl-shader/bridge.c']['sha256'],'originalBinarySha256':sha(original),'originalRawProfileSha256':sha(profraw.read_bytes()),'originalMergedProfileSha256':sha(profdata.read_bytes()),'profileReproduced':True,'coverageReproduced':True,'coverageSha256':sha(export_path.read_bytes()),'functions':functions,'completeNativeWasmCases':2007,'heldNativeOutputBytesIdentical':True,'checkedPixels':324480})
cold=json.loads((w/'cold/report.json').read_bytes());assert cold['gitHead']==cold['cloneHead']==head and cold['status']=='passed' and cold['exitCode']==0 and cold['statusBefore']==cold['statusAfter']==''
assert cold['receiptSha256']==sha((w/'cold/acceptance/receipt.json').read_bytes()) and cold['logSha256']==sha((w/'cold/cold.log').read_bytes())
assert cold['command']==['make','verify-E6-T12g6l'] and cold['environmentOverride']=='VIRGL_DISCARD_EVIDENCE_DIR'
result={'sourceHead':head,'recordings':result,'pristine':cold,'coldScrubPolicyUnchanged':True,'priorHeldSemanticsCarried':True,'narrowScope':True}
(out/'source-profile-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
