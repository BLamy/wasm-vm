from pathlib import Path
import json,subprocess,re,hashlib
root=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');out=Path('/tmp/e6-t12g6l-critic/revision-2');worker=out/'worker'
sha=lambda b:hashlib.sha256(b).hexdigest()
changed={}
for filename in ['renderer/virgl-shader/bridge.c','renderer/virgl-shader/raw_bits.c','renderer/virgl-shader/raw_bits.h','renderer/virgl-command/constant-domain.mjs','renderer/virgl-command/state.mjs']:
 diff=subprocess.check_output(['git','diff','--unified=0','cca9a570fe061107ff05e3697b99cfc3566fabe5..e7137ce55e714c4a5759175529a82cc056a6d097','--',filename],cwd=root,text=True)
 rows=[];current=0
 for line in diff.splitlines():
  if line.startswith('@@'):current=int(re.search(r'\+(\d+)',line)[1])
  elif line.startswith('+')and not line.startswith('+++'):rows.append(current);current+=1
  elif not line.startswith('-'):current+=1
 changed[filename]=rows
result=[]
for prefix in ['hot','cold/acceptance']:
 c=json.loads((worker/prefix/'native/coverage.json').read_bytes())
 for name,lines in changed.items():
  source=(root/name).read_text();texts=source.splitlines();rows=[]
  if name.endswith('.h'):
   for line in lines:rows.append(dict(line=line,source=texts[line-1],classification='waived: enum/type/flag/static assertion or interface declaration; no executable statement'))
  elif name.endswith('.c'):
   f=next(f for d in c['data']for f in d['files']if f['filename'].endswith('/'+name.split('/')[-1]));segments=f['segments']
   for line in lines:
    positive=[];zero=[]
    for i,s in enumerate(segments):
     if not s[3]or s[5]:continue
     end=segments[i+1][:2]if i+1<len(segments)else[s[0],s[1]+1]
     if s[0]<=line<=end[0]and not(line==end[0]and end[1]==1):(positive if s[2]else zero).append(s[2])
    count=max(positive,default=0)
    if count:classification='executed'
    elif not texts[line-1].strip()or texts[line-1].strip().startswith(('/*','*','static bool','bool raw_discard','static void')):classification='waived: declaration or documentation has no executable statement'
    elif name.endswith('raw_bits.c')and line in [458,459]:classification='waived: exhaustive enum case labels; the earlier RAW_CONTROL_OPCODES return handles these before the per-destination switch, so these labels have no body or effects'
    else:classification='NEEDS EVIDENCE'
    rows.append(dict(line=line,source=texts[line-1],maxRegionCount=count,zeroRegions=len(zero),classification=classification))
  else:
   scripts=[]
   for file in sorted((worker/prefix).glob('gpu-*/browser-coverage.json')):
    for script in json.loads(file.read_bytes())['scripts']:
     if script['source']==name:
      assert script['sha256']==sha(source.encode());scripts.append(dict(origin=str(file.relative_to(worker)),functions=script['coverage']['functions']if isinstance(script['coverage'],dict)else script['coverage']))
   for file in sorted((worker/prefix/'node-consumer-coverage').glob('*.json')):
    for script in json.loads(file.read_bytes())['result']:
     if script['url'].endswith('/'+name):scripts.append(dict(origin=str(file.relative_to(worker)),functions=script['functions']))
   offsets=[0]
   for line in source.splitlines(True):offsets.append(offsets[-1]+len(line))
   for line in lines:
    positions=[offsets[line-1]+i for i,ch in enumerate(texts[line-1])if not ch.isspace()];counts=[]
    for script in scripts:
     for p in positions:
      covering=[r for f in script['functions']for r in f['ranges']if r['startOffset']<=p<r['endOffset']]
      if covering:counts.append(min(covering,key=lambda r:r['endOffset']-r['startOffset'])['count'])
    maximum=max(counts,default=0)
    classification='executed'if maximum else 'waived: documentation/import or literal exported feature name'if texts[line-1].strip().startswith(('//','export const','import '))else'NEEDS EVIDENCE'
    rows.append(dict(line=line,source=texts[line-1],maxPreciseV8Count=maximum,classification=classification))
  result.append(dict(recording=prefix,path=name,sourceSha256=sha(source.encode()),rows=rows))
(out/'coverage-audit.json').write_text(json.dumps(result,indent=2)+'\n')
for file in result:
 print(file['recording'],file['path'])
 for r in file['rows']:
  if r['classification'].startswith(('DEAD','NEEDS')):print(r)
from collections import Counter
for prefix in ['hot','cold/acceptance']:
 counts=Counter(r['classification'].split(':')[0]for f in result if f['recording']==prefix for r in f['rows']);assert 'DEAD'not in counts and 'NEEDS EVIDENCE'not in counts;print(prefix,dict(counts))
print('All surviving changed runtime hunks execute or have unchanged nonbehavior waivers.')
