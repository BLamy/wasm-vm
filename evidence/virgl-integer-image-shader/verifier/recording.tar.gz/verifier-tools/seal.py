"""Seal the independent D32 verifier capture and reopen every indexed byte."""
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');CAP=ROOT/'target/evidence/virgl-integer-image-shader-critic';OUT=ROOT/'evidence/virgl-integer-image-shader/verifier';OUT.mkdir(parents=True,exist_ok=True)
HEAD='a899bee2eb6a50cf472c11181eb3bb9f89746e6d';RUNTIME='3c0a3e348048c0ff293a6b67638a96fb5c3561cb';sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_text())
audit=load(CAP/'final-audit.json');assert audit['status']=='HELD' and audit['recordedHarnessHead']==HEAD and all(s=='HELD' for s in audit['allPredictions'].values())
members={}
def add(name,raw):
 assert name and not Path(name).is_absolute() and '..' not in Path(name).parts
 assert name not in members or members[name]==raw,name
 members[name]=raw
for name in ['authentication.json','original-word-audit.json','coverage.json','module-replay.json','fresh-native-audit.json','final-audit.json','predictions.json','full-scoped.diff','critic.log','verdict.md']:
 add(name,(CAP/name).read_bytes())
for name in ['fresh','complete-custody','novel-native','sabotage-post-completion','cold-harness']:
 for p in sorted((CAP/name).rglob('*')):
  if p.is_file():add(p.relative_to(CAP).as_posix(),p.read_bytes())
for row in audit['sourceRows']:
 raw=subprocess.check_output(['git','show',HEAD+':'+row['path']],cwd=ROOT);assert len(raw)==row['bytes'] and sha(raw)==row['sha256'];add('source/'+row['path'],raw)
for name in ['final-audit.py','cold-harness.py','seal.py']:
 add('verifier-tools/'+name,(Path('/tmp/wasm-vm-d32-critic')/name).read_bytes())
for name in ['worker/hot/native/cases.json','worker/hot/native/native.jsonl','worker/hot/native/allocations.jsonl','worker/hot/native/facade.json','worker/hot/native/historical-abi.jsonl','worker/hot/native/selected-float.json']:
 add('authenticated-inputs/'+name,(CAP/name).read_bytes())
for role in ['worker','verifier']:
 for p in sorted((CAP/('d31-'+role)).rglob('*')):
  if p.is_file():add('authenticated-inputs/'+p.relative_to(CAP).as_posix(),p.read_bytes())
source_bindings=[]
for row in audit['nativeRecords']:
 report=load(CAP/row['path']);is_cold=row['path'].startswith('cold-harness/');directory=Path(audit['pristineAddedHarness']['clone']) if is_cold else ROOT
 for item in report['sources']+report['servedFiles']:
  path=item['path'];raw=(directory/path).read_bytes();assert len(raw)==item['size'] and sha(raw)==item['sha256'],path
  if path.startswith('target/'):
   name='bound-inputs/'+path
  elif '/build/' in path:name='generated/'+path
  else:
   assert raw==subprocess.check_output(['git','show',HEAD+':'+path],cwd=ROOT),path;name='source/'+path
  add(name,raw);source_bindings.append({'capture':row['path'],'recordedPath':path,'member':name,'bytes':len(raw),'sha256':sha(raw)})
for mode,binary in [('standard-integer-image-shader-native','standard-integer-image-shader-test'),('standard-integer-image-shader-sanitize','standard-integer-image-shader-test'),('standard-integer-image-shader-allocation-sanitize','standard-integer-image-shader-allocation-test')]:
 p=ROOT/'renderer/virgl-shader/build'/mode/binary;add('generated/'+p.relative_to(ROOT).as_posix(),p.read_bytes())
add('source-bindings.json',(json.dumps({'schema':'d32-verifier-capture-source-bindings-v1','status':'HELD','recordedHarnessHead':HEAD,'bindings':source_bindings},indent=2)+'\n').encode())
index=(json.dumps({'schema':'d32-independent-verifier-records-v1','task':'E6-T11d32','recordedHarnessHead':HEAD,'unchangedCompilerHead':RUNTIME,'records':[{'path':name,'bytes':len(raw),'sha256':sha(raw)} for name,raw in sorted(members.items())]},indent=2)+'\n').encode();(OUT/'records.json').write_bytes(index)
stream=io.BytesIO()
with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0) as compressed:
 with tarfile.open(fileobj=compressed,mode='w') as tar:
  for name,raw in sorted(members.items()):
   info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(raw))
archive=stream.getvalue();(OUT/'recording.tar.gz').write_bytes(archive)
expected={r['path']:r for r in json.loads((OUT/'records.json').read_bytes())['records']};seen=set()
with tarfile.open(OUT/'recording.tar.gz','r:gz') as reopened:
 for entry in reopened:
  assert entry.isfile() and entry.name in expected and entry.name not in seen
  name=Path(entry.name);assert not name.is_absolute() and '..' not in name.parts
  raw=reopened.extractfile(entry).read();e=expected[entry.name];assert len(raw)==e['bytes'] and sha(raw)==e['sha256'],entry.name;seen.add(entry.name)
assert seen==set(expected)
manifest={'schema':'d32-independent-verifier-seal-v1','task':'E6-T11d32','verdict':'verified','sourceHead':HEAD,'recordedHarnessHead':HEAD,'unchangedCompilerHead':RUNTIME,'dependencyHead':audit['dependencyHead'],'records':len(members),'reopenedMembers':len(seen),'uncompressedBytes':sum(len(raw) for raw in members.values()),'archiveBytes':len(archive),'archiveSha256':sha(archive),'recordIndexSha256':sha(index),'sourceClosureIncluded':True,'completeOriginalInputsIncluded':True,'generatedModulesIncluded':True,'sourceBindings':len(source_bindings),'allPredictions':audit['allPredictions'],'beforeEvidencePredictionsSha256':audit['beforeEvidencePredictionsSha256'],'workerSeal':audit['frozenWorkerSeal'],'coldAddedHarnessSha256':sha((CAP/'cold-harness/report.json').read_bytes()),'finalAuditSha256':sha((CAP/'final-audit.json').read_bytes()),'guestExecution':False,'productionNegotiation':False,'productionDrawAuthority':False,'authority':'isolated-original-integer-shader-compiler'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['predictions.json','final-audit.json','verdict.md']:(OUT/name).write_bytes((CAP/name).read_bytes())
print(json.dumps(manifest))
