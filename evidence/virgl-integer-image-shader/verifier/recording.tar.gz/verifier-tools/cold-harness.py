import hashlib,json,os,shutil,subprocess,tempfile
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');CAP=ROOT/'target/evidence/virgl-integer-image-shader-critic';OUT=CAP/'cold-harness';OUT.mkdir(parents=True,exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();clone=Path(tempfile.mkdtemp(prefix='wasm-vm-d32-critic-cold-'))/'wasm-vm'
env=dict(os.environ);removed=sorted(k for k in env if k.startswith(('CARGO_','RUST','VIRGL_','npm_config_','NPM_CONFIG_')) or k in {'NODE_OPTIONS','NODE_PATH','PYTHONPATH','PYTHONHOME','CHROME','CC','CXX','CFLAGS','CPPFLAGS','LDFLAGS','EMCC','EM_CONFIG','EMSDK','EMSDK_NODE','EMSDK_PYTHON','NODE_V8_COVERAGE'})
for k in removed:del env[k]
report={'schema':'d32-independent-pristine-instrumentation-v1','status':'running','head':head,'clone':str(clone),'removedEnvironmentNames':removed,'scope':'Only added verifier native instrumentation and assertions; original final compiler pristine proof carried at unchanged 3c0a3e34','commands':[],'inputs':{},'generated':{}}
sha=lambda b:hashlib.sha256(b).hexdigest()
def clean():return subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=clone,text=True).strip()
def command(args,cwd,log,expected=0):
 result=subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300);report['commands'].append({'argv':args,'cwd':str(cwd),'exitCode':result.returncode,'expected':expected});assert (result.returncode==0) if expected==0 else (result.returncode!=0)
try:
 with (OUT/'cold.log').open('w') as log:
  command(['git','clone','--shared','--no-checkout',str(ROOT),str(clone)],ROOT,log)
  command(['git','checkout','--detach',head],clone,log);report['cloneHead']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip();report['statusBefore']=clean();assert report['cloneHead']==head and not report['statusBefore']
  command(['npm','ci','--ignore-scripts','--no-audit','--no-fund'],clone/'web',log)
  data=clone/'target/evidence/virgl-integer-image-shader-critic';data.mkdir(parents=True)
  for name in ['worker/hot/native/cases.json','worker/hot/native/native.jsonl','fresh/native.jsonl','fresh/cases.json','fresh/predictions-before-native.json']:
   raw=(CAP/name).read_bytes();p=data/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);report['inputs'][name]={'sha256':sha(raw),'bytes':len(raw)}
  for name in ['virgl-shader.mjs','virgl-shader.wasm']:
   source=CAP/'worker/hot-generated/renderer/virgl-shader/build/wasm'/name;raw=source.read_bytes();p=clone/'renderer/virgl-shader/build/wasm'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);report['generated'][str(p.relative_to(clone))]={'sha256':sha(raw),'bytes':len(raw),'authenticatedOrigin':'worker/hot-generated at 3c0a3e34'}
  command(['node','tools/virgl-integer-image-shader/critic-replay-browser.mjs','--inputs',str(data/'worker/hot'),'--output',str(data/'complete-custody/hardware')],clone,log)
  for fault in ['wrong-level','wrong-words']:
   command(['node','tools/virgl-integer-image-shader/critic-replay-browser.mjs','--inputs',str(data/'worker/hot'),'--output',str(data/('complete-custody/fault-'+fault)),'--fault',fault],clone,log,1)
  command(['node','tools/virgl-integer-image-shader/critic-browser.mjs','--inputs',str(data/'fresh'),'--output',str(data/'novel-native')],clone,log)
  command(['node','tools/virgl-integer-image-shader/critic-browser.mjs','--inputs',str(data/'fresh'),'--output',str(data/'sabotage-post-completion'),'--fault','post-pixel'],clone,log,1)
  report['statusAfter']=clean();assert not report['statusAfter']
  for name in ['complete-custody','novel-native','sabotage-post-completion']:
   shutil.copytree(data/name,OUT/name)
 report['status']='HELD'
except Exception as e:report['status']='FAILED';report['error']=str(e);raise
finally:
 report['logSha256']=sha((OUT/'cold.log').read_bytes());(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['commands','inputs','generated']}))
