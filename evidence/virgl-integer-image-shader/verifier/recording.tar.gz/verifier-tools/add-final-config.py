import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=ROOT/'evidence/virgl-integer-image-shader/verifier';sha=lambda b:hashlib.sha256(b).hexdigest();manifest=json.loads((OUT/'manifest.json').read_text());index=json.loads((OUT/'records.json').read_text())
assert sha((OUT/'recording.tar.gz').read_bytes())==manifest['archiveSha256'];assert sha((OUT/'records.json').read_bytes())==manifest['recordIndexSha256'];expected={r['path']:r for r in index['records']};members={}
with tarfile.open(OUT/'recording.tar.gz','r:gz') as tar:
 for entry in tar:
  assert entry.isfile() and entry.name in expected and entry.name not in members
  raw=tar.extractfile(entry).read();e=expected[entry.name];assert len(raw)==e['bytes'] and sha(raw)==e['sha256'];members[entry.name]=raw
assert set(members)==set(expected)
name='tools/verify-virgl-integer-image-shader-adversarial.sh';before=subprocess.check_output(['git','show',manifest['recordedHarnessHead']+':'+name],cwd=ROOT);after=(ROOT/name).read_bytes();a=before.splitlines();b=after.splitlines();assert len(a)==len(b) and all(x==y for i,(x,y) in enumerate(zip(a,b)) if i!=3)
assert b[3]==b'evidence=${VIRGL_INTEGER_SHADER_CRITIC_EVIDENCE_DIR:-target/evidence/virgl-integer-image-shader-critic-$(git rev-parse --short=12 HEAD)}';subprocess.run(['bash','-n',str(ROOT/name)],check=True)
waiver={'schema':'d32-verifier-declarative-output-path-waiver-v1','status':'HELD','file':name,'line':4,'recordedHarnessHead':manifest['recordedHarnessHead'],'recordedSha256':sha(before),'finalPromotedSha256':sha(after),'reason':'Only the default output directory is qualified with HEAD, avoiding stale-record checks after later metadata commits. Every test, input, command and assertion remains byte-identical; the explicitly recorded a899bee2 run keeps its original source and full record closure. This is output-path configuration, with no runtime/native assertion change.','validation':['bash -n tools/verify-virgl-integer-image-shader-adversarial.sh','all bytes other than line4 identical'],'nativeRuntimeUnchanged':True}
members['post-record-config-waiver.json']=(json.dumps(waiver,indent=2)+'\n').encode();members['source-addendum/'+name]=after;members['verifier-tools/add-final-config.py']=Path('/tmp/wasm-vm-d32-critic/add-final-config.py').read_bytes()
index['records']=[{'path':name,'bytes':len(raw),'sha256':sha(raw)} for name,raw in sorted(members.items())];raw_index=(json.dumps(index,indent=2)+'\n').encode();(OUT/'records.json').write_bytes(raw_index);stream=io.BytesIO()
with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0) as compressed:
 with tarfile.open(fileobj=compressed,mode='w') as tar:
  for name,raw in sorted(members.items()):
   info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
archive=stream.getvalue();(OUT/'recording.tar.gz').write_bytes(archive)
manifest.update(records=len(members),reopenedMembers=len(members),uncompressedBytes=sum(len(raw) for raw in members.values()),archiveBytes=len(archive),archiveSha256=sha(archive),recordIndexSha256=sha(raw_index),postRecordDeclarativeConfigWaiverSha256=sha(members['post-record-config-waiver.json']))
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(OUT/'post-record-config-waiver.json').write_bytes(members['post-record-config-waiver.json']);print(json.dumps(manifest))
