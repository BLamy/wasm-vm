import hashlib,json,shutil,subprocess
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');OUT=ROOT/'target/evidence/virgl-integer-image-shader-critic';HEAD='a899bee2eb6a50cf472c11181eb3bb9f89746e6d';RUNTIME='3c0a3e348048c0ff293a6b67638a96fb5c3561cb';BASE='d8d510a689cfb5440cc8b3b65fd94adb9baee109'
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda name:json.loads((OUT/name).read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=ROOT,text=True).strip()
log=(OUT/'critic.log').read_bytes();assert log.endswith(b'INTEGER_IMAGE_SHADER_CRITIC_RECORDING_COMPLETE\n')
for name in ['authentication.json','original-word-audit.json','coverage.json','module-replay.json','fresh/audit.json','fresh-native-audit.json','cold-harness/report.json','cold-harness/complete-word-audit.json','cold-harness/fresh-native-audit.json']:
 assert load(name)['status']=='HELD',name
unchanged_paths=['*.c','*.h','renderer/virgl-shader/standard.mjs','renderer/virgl-shader/build.sh','renderer/virgl-shader/build-wasm.sh','renderer/virgl-command','crates','web','tools/guest']
assert not subprocess.check_output(['git','diff','--name-only',RUNTIME,HEAD,'--',*unchanged_paths],cwd=ROOT,text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only',BASE,HEAD,'--','renderer/virgl-command','crates','web','tools/guest','tools/virgl-standard-texture'],cwd=ROOT,text=True).strip()
pred=Path('/tmp/wasm-vm-d32-critic/predictions.json').read_bytes();assert sha(pred)=='66166ffc993417f6e0518653fe959b2853dd58c1856aee2c4b154782d134121d';(OUT/'predictions.json').write_bytes(pred)
diff=Path('/tmp/wasm-vm-d32-critic/full-scoped.diff').read_bytes();assert sha(diff)=='a75ae7284c4ec871701aa4dced2b07447f0f2ccd5090d5490b1c4393b0f3da69';(OUT/'full-scoped.diff').write_bytes(diff)
summary={};bindings={};native=[]
for prefix in ['', 'cold-harness/']:
 for name,expected in [('complete-custody/hardware','passed'),('complete-custody/fault-wrong-level','failed'),('complete-custody/fault-wrong-words','failed'),('novel-native','passed'),('sabotage-post-completion','failed')]:
  relative=prefix+name+'/report.json';r=load(relative);assert r['gitHead']==HEAD and not r['trackedChanges'] and r['status']==expected and r['browserErrors']=={'console':[],'page':[],'requests':[]}
  for item in r['sources']+r['servedFiles']:
   path=item['path'];key=('cold-harness/' if prefix else '')+path;assert key not in bindings or bindings[key]==item;bindings[key]=item
   if path.startswith('target/') or '/build/' in path:
    p=(Path(load('cold-harness/report.json')['clone']) if prefix else ROOT)/path
    assert p.is_file() and len(p.read_bytes())==item['size'] and sha(p.read_bytes())==item['sha256'],key
   else:
    raw=subprocess.check_output(['git','show',HEAD+':'+path],cwd=ROOT);assert len(raw)==item['size'] and sha(raw)==item['sha256'],key
  a=r['acceptance'];rows=a.get('nativeFenceCustody',[]);native.append({'path':relative,'sha256':sha((OUT/relative).read_bytes()),'status':r['status'],'frames':len(a.get('frames',a.get('runs',[]))),'nativeFences':len(rows) or sum(len(x['fences']) for x in a['runs']),'completeReadEvents':sum(len(x['reads']) for x in rows),'completePollEvents':sum(len(x['polls']) for x in rows)})
  if name=='sabotage-post-completion':
   assert a['runs'][0]['fences'][0]['id']==1 and a['runs'][0]['fences'][1]['id']==2 and a['runs'][0]['sabotage']['afterOriginalFence']==1
   assert a['runs'][0]['outputs'][0]['originalCompletedWords'][0]==608135816 and a['runs'][0]['outputs'][0]['nativeWords'][0]==608135817
matrix=(OUT/'fresh/native.jsonl').read_bytes();assert matrix==(OUT/'fresh/sanitize.jsonl').read_bytes();alloc=[json.loads(row) for row in (OUT/'fresh/allocations.jsonl').read_text().splitlines()];assert alloc[-1]=={'kind':'summary','faults':165,'recoveries':165,'callerMutation':True,'partialResults':False}
for row in alloc:
 if row['kind'] in ['upstream-fault','calloc-fault']:assert not row['result']['ok'] and set(row['result'])=={'ok','error'}
source_names=set(r['path'] for r in load('authentication.json')['sourceClosure'])
source_names.update(subprocess.check_output(['git','ls-files','--','tools/virgl-integer-image-shader/critic-*','tools/verify-virgl-integer-image-shader-adversarial.sh','renderer/virgl-shader/tests/standard-integer-image-shader-critic.mjs','renderer/virgl-shader/tests/standard-integer-image-shader-custody.mjs','AGENTS.md'],cwd=ROOT,text=True).splitlines())
source_rows=[]
for name in sorted(source_names):
 raw=subprocess.check_output(['git','show',HEAD+':'+name],cwd=ROOT);assert raw==(ROOT/name).read_bytes();source_rows.append({'path':name,'sha256':sha(raw),'bytes':len(raw)})
result={'schema':'d32-independent-final-criterion-audit-v1','status':'HELD','recordedHarnessHead':HEAD,'unchangedCompilerHead':RUNTIME,'dependencyHead':BASE,'allPredictions':{k:'HELD' for k in json.loads(pred)['predictions']},'beforeEvidencePredictionsSha256':sha(pred),'fullScopedDiffSha256':sha(diff),'fullScopedDiffBytes':len(diff),'nativeRecords':native,'allSourceBindingsHeld':True,'sourceRows':source_rows,'runtimeUnchangedPaths':unchanged_paths,'unchangedD31Boundary':['renderer/virgl-command','crates','web','tools/guest','tools/virgl-standard-texture'],'freshNativeSanitizeSha256':sha(matrix),'genuineAllocationSummary':alloc[-1],'frozenWorkerSeal':{k:load('authentication.json')['worker'][k] for k in ['manifestSha256','indexSha256','archiveSha256','members']},'coldCompilerCarriedByActualBoundary':load('authentication.json')['cold'],'pristineAddedHarness':load('cold-harness/report.json'),'noUndefinedNumericalAuthority':True,'guestExecution':False,'productionNegotiation':False,'noRuntimeEdits':True}
(OUT/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['sourceRows','coldCompilerCarriedByActualBoundary','pristineAddedHarness','nativeRecords']}))
