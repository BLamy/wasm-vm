"""Read-only raw-to-manifest and stored chunk equality; never writes image/chunks."""
from pathlib import Path
import hashlib,json,time,sys
root=Path(sys.argv[1]);out=Path(sys.argv[2]);expected=sys.argv[3]
mp=root/'manifest.json';m=json.loads(mp.read_text());start=time.monotonic();whole=hashlib.sha256();seen=set();total=0
assert m['chunk_size']==262144 and len(m['chunks'])==49152
with (root/'omarchy.ext4').open('rb') as stream:
    for pin in m['chunks']:
        data=stream.read(m['chunk_size']);total+=len(data);whole.update(data)
        assert hashlib.sha256(data).hexdigest()==pin
        if pin not in seen:
            path=root/'chunks'/(pin+'.bin')
            assert path.stat().st_size==len(data) and path.read_bytes()==data
            seen.add(pin)
    assert not stream.read(1)
assert total==m['image_len']==12884901888 and whole.hexdigest()==expected
r={'status':'passed','scope':'Independent read-only raw image and every stored unique chunk; no duplicate output','imageSha256':whole.hexdigest(),'imageBytes':total,'manifestSha256':hashlib.sha256(mp.read_bytes()).hexdigest(),'slots':len(m['chunks']),'uniqueChunks':len(seen),'seconds':time.monotonic()-start}
out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
