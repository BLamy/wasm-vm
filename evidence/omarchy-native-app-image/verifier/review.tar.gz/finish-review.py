from pathlib import Path
import json,hashlib,tarfile,io,gzip,subprocess
base=Path('target/evidence/critic-omarchy-native-app-image05b')
worker=Path('evidence/omarchy-native-app-image/worker/submission.tar.gz')
sha=lambda b:hashlib.sha256(b).hexdigest()
with tarfile.open(worker,'r:gz') as t:
 bodies={m.name:t.extractfile(m).read() for m in t.getmembers()}
 citations={}
 for name,needles in {
  'main/install.log':['Good signature','checking package integrity','checking for file conflicts','checking dependencies','libuv.so.1','gpgconf','umount'],
  'pristine/install.log':['Good signature','libuv.so.1','gpgconf','umount'],
  'main/build.log':['mke2fs','e2fsck','clean'],
 }.items():
  lines=bodies[name].decode().splitlines();citations[name]={needle:[i+1 for i,s in enumerate(lines) if needle in s] for needle in needles}
 (base/'worker-citations.json').write_text(json.dumps(citations,indent=2)+'\n')
coverage=[
 {'path':'Makefile','classification':'HELD','proof':'main and pristine acceptance policy/whitespace plus nine child commands; test-only verifier additions run narrowly after frozen source'},
 {'path':'tasks/QUEUE.md and task frontmatter','classification':'WAIVED metadata','proof':'generated lifecycle metadata; final policy/queue rechecked with verifier verdict'},
 {'path':'tools/image/build-omarchy-image.py','classification':'HELD','proof':'both actual 12288MiB builds; image bounds in existing changed unit test; no change to default4096'},
 {'path':'tools/image/configure-omarchy-demo.py','classification':'HELD','proof':'both fresh build commands run configurator; independent read-only final ext4 verifies /repo/$repo mirror and required signature policy'},
 {'path':'tools/image/fetch-omarchy-app-packages.py','classification':'HELD','proof':'archived fresh npm download/signature exact bytes and473 cached identities; independent existing-cache/symlink/inherited-partial controls. Network exception/error reporting paths only fail closed and are not recovery claims'},
 {'path':'tools/image/install-omarchy-apps.py preflight/ELF','classification':'HELD','proof':'all473 actual archives; real-bsdtar traversal/identity/arch guards; own full6167-body RISC-V rehash; actual three loader checks and missing-libuv negative; no every-plugin closure claim'},
 {'path':'tools/image/install-omarchy-apps.py install/cleanup/reassembly','classification':'HELD','proof':'two actual network-disabled signed transactions, original accepted input/archive/tools mounts read-only; literal receipt/log signatures, pgp DB validation, dependencies, strict reverse unmount, frozen inputs and final mtree reassembly. Preserved busy-agent/capability/disk-exhaustion failures are not relabeled'},
 {'path':'tools/image/check-native-app-filesystem.py','classification':'HELD','proof':'two actual debugfs outputs have exact7ownership and7capabilities; independent actual signed archive/header/script and final ext4 priority-body/account reads agree'},
 {'path':'tools/image/omarchy-apps/native-packages.lock.json','classification':'HELD declarative input','proof':'473 frozen pins/signatures/.PKGINFO match source, main and pristine; no lock hash is treated as signing authority'},
 {'path':'tools/image/omarchy-apps/reviewed-overlays.json','classification':'HELD declarative input','proof':'seven exact cap attrs independently derived from signed btop/gsr metadata or inetutils/gvfs/gstreamer scripts; five older script overlays carry verified assembly boundary'},
 {'path':'tools/image/verify-native-app-image.py','classification':'HELD','proof':'all nine control paths exercised twice; report hashes/source/pristine/readonly Docker wiring authenticated; independent full raw+manifest+every chunk streaming checks. Exception text/CLI argument declarations are diagnostic/config wrappers, no recovery semantics'},
 {'path':'tools/image/test_build_omarchy_image.py and test_install_omarchy_apps.py','classification':'HELD','proof':'117 host and117 Linux tests in both main/pristine, explicit skips; worker mocked preflight is supplemented with independent actual bsdtar/native signature checks'},
 {'path':'tools/image/omarchy-apps/README.md','classification':'WAIVED prose','proof':'read against actual boundary: signing distinct from pins, three loader closures, explicit inputs, no UI/full-app/deployment claim'},
]
(base/'coverage.json').write_text(json.dumps({'source':'2f27c1d8efb734ce115b1a7f07840c456916d816','changedPaths':14,'coverage':coverage,'unchangedBoundaries':'accepted389 package provenance/sanitizer/image tooling and all emulator/native GPU proofs carry; graphics profile overlay remains T05c; no broad emulator rerun','exceptions':'Exception-only diagnostics are waived as fail-closed reporting, not advertised recovery behavior. CLI imports/argument declarations and generated task docs are config/metadata.'},indent=2)+'\n')
pred=json.loads((base/'pre-data-predictions.json').read_text())
refs={
'M1':['final-worker-authentication.json','healthy-final02/stderr','guard-removal-final02/stderr'],
'M2':['signature-control01/attempt02-decoded-input/stdout','signature-control01/cache-identity.json','worker-citations.json'],
'M3':['worker-citations.json','metadata-readonly.stdout'],
'M4':['assembly-readonly.stdout','metadata-readonly.stdout','healthy-final02/stderr'],
'M5':['final-worker-authentication.json','coverage.json'],
'M6':['archive-install-scripts.stdout','metadata-readonly.stdout','final-worker-authentication.json'],
'M7':['metadata-readonly.stdout','final-worker-authentication.json'],
'M8':['worker-citations.json','coverage.json'],
'M9':['image-chunks-readonly.json','pristine-image-chunks-readonly.json'],
'M10':['frozen-source.json','final-worker-authentication.json','metadata-readonly-command.json'],
'M11':['final-worker-authentication.json','pristine-image-chunks-readonly.json'],
'M12':['healthy-final02/stderr','guard-removal-final02/stderr','path-guard-control01/guard.diff']}
for row in pred['predictions']:
 row['result']='HELD';row['citations']=refs[row['id']]
pred.update(phase='final independent review',source='2f27c1d8efb734ce115b1a7f07840c456916d816',workerSubmission='d305912826774dd237308054ca84bbcc3d6427ee',verdict='verified',scope='Signed native package/image construction only. Three actual loader closures, all runtime ELF architecture/hash checks. No normal app execution, full upstream app set, proven GPU profile reapplication, warm release or deployment.')
(base/'final-predictions.json').write_text(json.dumps(pred,indent=2)+'\n')
