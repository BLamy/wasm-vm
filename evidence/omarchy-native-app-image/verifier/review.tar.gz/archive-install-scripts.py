import pathlib,json,hashlib,subprocess,base64,struct
packages=pathlib.Path('/packages');lock=json.loads(pathlib.Path('/tools/omarchy-apps/native-packages.lock.json').read_text());records={p['name']:p for p in lock['packages']};overlays={e['path']:e for e in json.loads(pathlib.Path('/tools/omarchy-apps/reviewed-overlays.json').read_text())['entries']};rows=[]
for name, paths, caps, literal in [('inetutils',['/usr/bin/rcp','/usr/bin/rlogin','/usr/bin/rsh'],1<<10,'setcap cap_net_bind_service=+ep'),('gvfs-nfs',['/usr/lib/gvfsd-nfs'],1<<10,"setcap 'cap_net_bind_service=+ep'"),('gstreamer',['/usr/lib/gstreamer-1.0/gst-ptp-helper'],(1<<10)|(1<<12),'setcap cap_net_bind_service,cap_net_admin+ep')]:
 rec=records[name];path=packages/rec['archive'];assert hashlib.file_digest(path.open('rb'),'sha256').hexdigest()==rec['sha256']
 script=subprocess.check_output(['bsdtar','-xOf',str(path),'.INSTALL']).decode()
 assert literal in script and all(p.lstrip('/') in script for p in paths)
 expected=base64.b64encode(struct.pack('<IIIII',0x02000001,caps,0,0,0)).decode()
 for p in paths:assert overlays[p]['xattrs']['security.capability']==expected
 rows.append({'package':name,'archiveSha256':rec['sha256'],'installScript':script,'reviewedPaths':paths,'expectedFinalCapability':expected})
# Two archives carry their capabilities directly, independently of scriptlets.
raw=json.loads(pathlib.Path('/evidence/metadata-readonly.stdout').read_text())
for row in raw['signedArchiveMetadata']:
 if row['package'] not in ['btop','gpu-screen-recorder'] or 'path' not in row:continue
 text=row['paxCapabilities']['LIBARCHIVE.xattr.security.capability'];canonical=base64.b64encode(base64.b64decode(text+'='*(-len(text)%4))).decode();assert overlays['/'+row['path']]['xattrs']['security.capability']==canonical
 rows.append({'package':row['package'],'path':row['path'],'archiveCapabilityMatchesOverlay':True,'canonicalBase64':canonical})
print(json.dumps({'status':'passed','scriptedCaps':3,'directArchiveCaps':2,'finalCapPaths':7,'rows':rows,'note':'GStreamer archive capability includes a broader bit; its actual signed post-install script selects the narrower exact reviewed final capabilities.'},indent=2))
