import pathlib,hashlib,json,subprocess,tarfile,base64
root=pathlib.Path('/accepted/native/assembled');packages=pathlib.Path('/packages');image='/image/omarchy.ext4'
lock=json.loads(pathlib.Path('/tools/omarchy-apps/native-packages.lock.json').read_text());records={p['name']:p for p in lock['packages']};overlays={e['path'].lstrip('/'):e for e in json.loads(pathlib.Path('/tools/omarchy-apps/reviewed-overlays.json').read_text())['entries']};sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
license_candidates=['usr/lib/node_modules/npm/LICENSE','usr/lib/libreoffice/LICENSE','usr/lib/libreoffice/COPYING','usr/lib/libreoffice/NOTICE','usr/lib/libreoffice/share/readme/README_en-US','usr/share/licenses/chromium/LICENSE','usr/share/licenses/nodejs/LICENSE']
licenses=[]
for n in license_candidates:
 p=root/n
 if p.is_file():licenses.append({'path':n,'bytes':p.stat().st_size,'sha256':sha(p)})
assert any('/npm/' in x['path'] for x in licenses) and any('/libreoffice/' in x['path'] for x in licenses)
archive=[]
for name in ['btop','gpu-screen-recorder','inetutils','gvfs-nfs','gstreamer']:
 record=records[name];p=packages/record['archive'];assert sha(p)==record['sha256']
 proc=subprocess.Popen(['zstd','-dc',str(p)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 with tarfile.open(fileobj=proc.stdout,mode='r|') as stream:
  for m in stream:
   path=m.name.lstrip('./')
   if path in overlays and overlays[path].get('xattrs'):
    data=stream.extractfile(m).read();actual=hashlib.sha256(data).hexdigest();assert actual==overlays[path]['sha256']
    attrs={k:v for k,v in m.pax_headers.items() if 'capability' in k}
    archive.append({'package':name,'path':path,'sha256':actual,'paxCapabilities':attrs})
   if path=='.INSTALL':
    data=stream.extractfile(m).read().decode();archive.append({'package':name,'installScript':data})
 proc.stdout.close();err=proc.stderr.read();assert proc.wait()==0,err
assert len([x for x in archive if 'path' in x])==7
priority=[]
for n in ['usr/bin/node','usr/lib/chromium/chromium','usr/lib/libreoffice/program/soffice.bin']:
 process=subprocess.Popen(['debugfs','-R','cat /'+n,image],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 h=hashlib.sha256();count=0
 while True:
  block=process.stdout.read(1048576)
  if not block:break
  h.update(block);count+=len(block)
 process.stdout.close();err=process.stderr.read().decode();assert process.wait()==0,err
 assert h.hexdigest()==sha(root/n) and count==(root/n).stat().st_size
 priority.append({'path':n,'bytes':count,'sha256':h.hexdigest(),'source':'actual read-only ext4 debugfs cat'})
def cat(name):
 p=subprocess.run(['debugfs','-R','cat '+name,image],capture_output=True,check=True)
 return p.stdout
passwords={line.split(b':',1)[0].decode():line.split(b':')[1] for line in cat('/etc/shadow').splitlines()}
assert all(value.startswith((b'!',b'*')) for value in passwords.values())
assert cat('/etc/machine-id')==b''
config=cat('/etc/pacman.conf').decode();assert 'LocalFileSigLevel = Required' in config and 'SigLevel = Required DatabaseOptional' in config and '/repo/$repo' in config and '/$repo/os/$arch' not in config
assert cat('/etc/passwd').count(b'omarchy:x:1000:1000:Omarchy demo:/home/omarchy:/bin/bash')==1
print(json.dumps({'status':'passed','priorityFinalImageBodies':priority,'licenses':licenses,'signedArchiveMetadata':archive,'allShadowEntriesLocked':True,'shadowAccountNames':sorted(passwords),'machineIdEmpty':True,'correctMirrorAndRequiredSignatures':True,'privateGpgKeyringExcluded':not(root/'etc/pacman.d/gnupg').exists(),'access':'read-only accepted assembly, archives and raw ext4; no mounts or writes'},indent=2))
