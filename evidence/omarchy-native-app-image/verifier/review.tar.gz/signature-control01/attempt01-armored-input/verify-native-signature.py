import pathlib,json,hashlib,subprocess,os
root=pathlib.Path('/accepted/assembled-r3');program=root/'usr/bin/gpgv';keyring=root/'usr/share/pacman/keyrings/archlinux.gpg';h=program.read_bytes()[:64];assert h[:6]==b'\x7fELF\x02\x01' and int.from_bytes(h[18:20],'little')==243
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();filename='npm-12.2.0-1-any.pkg.tar.zst';rows=[]
for variant in ['healthy','changed-signature']:
 home=pathlib.Path('/tmp')/variant;home.mkdir(mode=0o700);cache=pathlib.Path('/fixtures')/variant
 command=[str(program),'--homedir',str(home),'--keyring',str(keyring),'--status-fd=1',str(cache/(filename+'.sig')),str(cache/filename)]
 r=subprocess.run(command,env=dict(os.environ,QEMU_LD_PREFIX=str(root)),capture_output=True,text=True)
 rows.append({'variant':variant,'command':command,'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'packageSha256':sha(cache/filename),'signatureSha256':sha(cache/(filename+'.sig'))})
print(json.dumps({'scope':'Actual RISC-V gpgv verifies a detached public package signature against unchanged packaged public keyring; not a claim to reproduce full pacman key-trust policy','programSha256':sha(program),'keyringSha256':sha(keyring),'programArchitecture':'ELF64LE RISC-V243','rows':rows},indent=2))
