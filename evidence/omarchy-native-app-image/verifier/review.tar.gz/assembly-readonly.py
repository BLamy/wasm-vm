import pathlib,json,hashlib,os,stat
root=pathlib.Path('/accepted/native/assembled');expected=json.loads(pathlib.Path('/evidence/runtime-elf.json').read_text());sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
rows=[];different_modes=[]
for row in expected:
 p=root/row['path'];assert p.is_file() and not p.is_symlink(),row['path']
 with p.open('rb') as f:
  h=f.read(64);digest=hashlib.sha256(h)
  for block in iter(lambda:f.read(1048576),b''):digest.update(block)
 assert h[:6]==b'\x7fELF\x02\x01' and int.from_bytes(h[18:20],'little')==243,row['path']
 assert int.from_bytes(h[16:18],'little') in (2,3),row['path']
 assert digest.hexdigest()==row['sha256'],row['path']
 mode=oct(stat.S_IMODE(p.stat().st_mode))
 if mode!=row['mode']:different_modes.append({'path':row['path'],'transactionMode':row['mode'],'assembledMode':mode})
 if row['path'] in ('usr/bin/node','usr/lib/chromium/chromium','usr/lib/libreoffice/program/soffice.bin'):
  rows.append({'path':row['path'],'bytes':p.stat().st_size,'sha256':digest.hexdigest(),'uid':p.stat().st_uid,'gid':p.stat().st_gid,'mode':mode,'elfFlags':int.from_bytes(h[48:52],'little')})
licenses={}
for name in ('chromium','libreoffice-fresh','nodejs','npm'):
 d=root/'usr/share/licenses'/name
 licenses[name]=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(d.rglob('*')) if p.is_file() and not p.is_symlink()] if d.exists() else []
print(json.dumps({'status':'passed','runtimeElfsChecked':len(expected),'allExactRiscv64':True,'priority':rows,'modeDifferences':different_modes,'licenses':licenses,'npmLink':os.readlink(root/'usr/bin/npm'),'gpgvExists':(root/'usr/bin/gpgv').is_file(),'packageCacheDirectoryExists':(root/'var/cache/pacman/pkg').is_dir(),'keyringSha256':sha(root/'usr/share/pacman/keyrings/archlinux.gpg')},indent=2))
