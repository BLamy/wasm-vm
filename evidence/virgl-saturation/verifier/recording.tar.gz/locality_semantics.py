import json,hashlib,struct
from pathlib import Path
from source_semantics import execute
OUT=Path('evidence/virgl-saturation/verifier');p=OUT/'locality-gpu/report.json';raw=p.read_bytes();j=json.loads(raw);a=j['acceptance'];assert j['status']==a['status']=='passed';assert j['browserErrors']=={'console':[],'page':[],'requests':[]};assert a['objects']['live']==0;assert len(a['vertices'])==6
primary=json.loads((OUT/'locality-primary.json').read_text());sources=[e['source'] for e in a['events'] if e['call']=='shaderSource'];rows=[]
for i,v in enumerate(a['vertices']):
 c=next(c for c in primary if c['name']==v['name']);assert v['text']==c['text'];assert v['primary']==c['primary'];assert v['sourceSha256']==hashlib.sha256(v['text'].encode()).hexdigest()
 wanted=execute(v['text'],{0:v['attributes']},[],v['backend']);outputs=[*wanted[0],*wanted[1],*wanted[2]];b=bytes(v['bytes']);assert hashlib.sha256(b).hexdigest()==v['sha256'];observed=list(struct.unpack('<12I',b));assert observed==v['observed'];assert all(w in choices for w,choices in zip(observed,outputs)),(i,v['name'],observed,outputs)
 assert [(r['name'],r['type'],r['size']) for r in v['reflection']]==[('gl_Position',35666,1),('vso_g0',35666,1),('vso_g1',35666,1)]
 assert sources[2*i]==(v['primary']['glsl'] if v['backend']=='mesa' else v['pair']['vertex']['glsl']) and sources[2*i+1]==v['pair']['fragment']['glsl']
 reconstructed=[((observed[8+k]&511)<<23)|(observed[4+k]&0x7fffff) for k in range(4)]
 rows.append({'record':i,'name':v['name'],'backend':v['backend'],'rawSha256':v['sha256'],'observed':observed,'reconstructed':reconstructed})
r={'schema':'virgl-saturation-critic-locality-semantics-v1','status':'passed','reportSha256':hashlib.sha256(raw).hexdigest(),'predictionsSha256':hashlib.sha256((OUT/'locality-predictions.json').read_bytes()).hexdigest(),'checkedWords':72,'vertices':rows,'sourceSequenceBound':True,'disposed':True}
(OUT/'locality-semantics.json').write_text(json.dumps(r,indent=2)+'\n');print('72 physical words hold in six mixed SAT/plain-DIV and masked alias/raw-copy probes on both backends.')
