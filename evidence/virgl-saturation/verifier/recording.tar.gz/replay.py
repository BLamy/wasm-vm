import os,json,hashlib,subprocess
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'evidence/virgl-saturation/verifier'; U=OUT/'unpacked';sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[]
for label,prefix,generated in [('hot','hot','generated'),('cold','cold/acceptance','cold-generated')]:
 binary=U/generated/'saturation-sanitize/saturation-test';inputfile=U/prefix/'native/cases.bin'; env=dict(os.environ);env.update(LLVM_PROFILE_FILE=str(OUT/(label+'-replay.profraw')),UBSAN_OPTIONS='halt_on_error=1',ASAN_OPTIONS='abort_on_error=1')
 run=subprocess.run([str(binary)],input=inputfile.read_bytes(),env=env,capture_output=True,cwd=ROOT);assert run.returncode==0 and not run.stderr;assert run.stdout==(U/prefix/'native/native.log').read_bytes()
 (OUT/(label+'-native-replay.log')).write_bytes(run.stdout)
 # Re-export the ORIGINAL raw profile with its actual recorded binary, not
 # the newly run profile and not a current rebuild.
 profile=U/prefix/'native/native.profraw';merged=OUT/(label+'-recorded.profdata')
 subprocess.run(['xcrun','llvm-profdata','merge','-sparse',str(profile),'-o',str(merged)],check=True)
 assert merged.read_bytes()==(U/prefix/'native/native.profdata').read_bytes()
 export=json.loads(subprocess.check_output(['xcrun','llvm-cov','export',str(binary),'-instr-profile='+str(merged)]))
 for d in export['data']:
  d['files']=[f for f in d['files'] if any(f['filename'].endswith('/'+n) for n in ['bridge.c','raw_bits.c','native_tests/saturation.c'])]
  d['functions']=[f for f in d['functions'] if any(any(name.endswith('/'+n) for n in ['bridge.c','raw_bits.c','native_tests/saturation.c']) for name in f['filenames'])]
 recorded=json.loads((U/prefix/'native/coverage.json').read_bytes());assert export==recorded
 (OUT/(label+'-coverage-export.json')).write_text(json.dumps(export,indent=2)+'\n')
 rows.append({'set':label,'binarySha256':sha(binary.read_bytes()),'fixtureSha256':sha(inputfile.read_bytes()),'transcriptSha256':sha(run.stdout),'originalRawProfileSha256':sha(profile.read_bytes()),'originalMergedProfileSha256':sha(merged.read_bytes()),'recordedCoverageSha256':sha((U/prefix/'native/coverage.json').read_bytes()),'exactTranscript':True,'exactOriginalProfileExport':True})
report={'schema':'virgl-saturation-critic-native-replays-v1','status':'passed','replays':rows};(OUT/'native-replays.json').write_text(json.dumps(report,indent=2)+'\n');print('Both actual sanitizer binaries replay exactly; original raw/merged profiles and coverage exports match.')
