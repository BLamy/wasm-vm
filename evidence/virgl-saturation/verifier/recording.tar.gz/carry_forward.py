from pathlib import Path
import hashlib,json,tarfile,subprocess
ROOT=Path.cwd();OUT=ROOT/'evidence/virgl-saturation/verifier';U=OUT/'unpacked';sha=lambda b:hashlib.sha256(b).hexdigest()
boundaries=['virgl-precise-fraction','virgl-minimum-selection','virgl-scalar-operations','virgl-signed-conversions','virgl-signed-integers','virgl-hex-literals','virgl-compiler-bounds'];seals=[];parent_carry=None
for name in boundaries:
 p=ROOT/'evidence'/name/'verifier';m=json.loads((p/'manifest.json').read_bytes());idx=m.get('recordIndex',m.get('index'));index=(p/idx['path']).read_bytes();a=p/m['archive']['path'];assert sha(index)==idx['sha256'] and sha(a.read_bytes())==m['archive']['sha256'];entries={r['path']:r for r in json.loads(index)['records']};count=0
 with tarfile.open(a) as t:
  members=t.getmembers();assert len(members)==len(entries) and {e.name for e in members}==set(entries)
  for entry in members:
   assert entry.isfile();raw=t.extractfile(entry).read();r=entries[entry.name];assert len(raw)==r['bytes'] and sha(raw)==r['sha256'];count+=1
   if name=='virgl-precise-fraction' and entry.name=='carry-forward.json':parent_carry=json.loads(raw)
 assert m['verdict']=='verified';seals.append(dict(boundary=name,manifestSha256=sha((p/'manifest.json').read_bytes()),archiveSha256=m['archive']['sha256'],indexSha256=idx['sha256'],members=count,verdict='verified'))
unchanged=[]
for row in parent_carry['unchangedDependencies']:
 path=row.get('path',row.get('file'));p=ROOT/path
 if p.is_file() and sha(p.read_bytes())==row['sha256']:unchanged.append(row)
helper_paths=['renderer/virgl-shader/raw_binary32.h','renderer/virgl-shader/raw_conversions.h','renderer/virgl-shader/raw_scalar.h','renderer/virgl-shader/raw_fraction.h','renderer/virgl-shader/tests/precise-fraction-capture-regressions.mjs','renderer/virgl-shader/tests/precise-fraction-regressions.mjs']
helpers=[];base='bad92bfdaba16295b064a78c0767652da09be158'
for p in helper_paths:
 b=(ROOT/p).read_bytes();assert b==subprocess.check_output(['git','show',base+':'+p]);helpers.append({'path':p,'sha256':sha(b)})
held=json.loads((U/'hot/held-fraction/report.json').read_text());assert held['physicalWords']==36096 and held['capture']['member']['sha256']=='023f32f8d6a0b7d95b9f7f494c649a48934beb585ea5e4d02fb2fa6bd22c33af';assert held['fault']['member']['sha256']=='6c19286ef40a059e7e4dc1f297c5685ca25998bf41d9ebf95ba2bb3b7f9a9414'
legacy=[]
for prefix in ['hot','cold/acceptance']:
 j=json.loads((U/prefix/'legacy.json').read_text());assert len(j['cases'])==2933
 for c in j['cases']:
  assert c['parent']==c['old'] and c['old']['ok']==c['added']['ok']
  if c['old']['ok']:
   actual=dict(c['added']['metadata']);actual['profile']=actual.pop('saturationBaseProfile');actual.pop('saturationContract');baseline=dict(c['old']['metadata'])
   if c['baseTransition']:baseline['profile']='virgl-webgl2-raw-bits-v1'
   assert actual==baseline
 legacy.append({'set':prefix,'sha256':sha((U/prefix/'legacy.json').read_bytes()),'wholeResponses':2933})
production=['web/main.js','web/index.html','web/dist/main.js','web/dist/index.html','web/roadmap.js','crates/core/Cargo.toml','crates/core/src/dev/virtio/gpu/mod.rs']
gates=[]
for p in production:
 if (ROOT/p).is_file():
  b=(ROOT/p).read_bytes();assert b==subprocess.check_output(['git','show',base+':'+p]);gates.append({'path':p,'sha256':sha(b)})
r={'schema':'virgl-saturation-critic-carry-v1','status':'passed','priorHeldSeals':seals,'unchangedDependencies':unchanged,'unchangedHelpers':helpers,'wholePredecessorResponses':legacy,'heldFraction':held,'unchangedProductionGates':gates,'policy':'Carry HELD only for authenticated unchanged evidence/dependency boundaries. Current changed compiler/consumer paths receive new proof; historical full gauntlets and cold clones are not repeated.'}
(OUT/'carry-forward.json').write_text(json.dumps(r,indent=2)+'\n');print(len(seals),'verified critic seals,',len(unchanged),'unchanged dependencies,',len(helpers),'unchanged helpers and',len(gates),'production gates carry HELD.')
