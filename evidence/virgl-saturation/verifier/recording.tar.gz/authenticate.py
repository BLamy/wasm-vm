import hashlib,json,tarfile,subprocess
from pathlib import Path
ROOT=Path.cwd(); OUT=ROOT/'evidence/virgl-saturation/verifier'; WORKER=ROOT/'evidence/virgl-saturation/worker'
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((WORKER/'manifest.json').read_bytes()); rawindex=(WORKER/'records.json').read_bytes(); archive=WORKER/m['archive']['path']
assert len(rawindex)==m['recordIndex']['bytes'] and sha(rawindex)==m['recordIndex']['sha256']
assert archive.stat().st_size==m['archive']['bytes'] and sha(archive.read_bytes())==m['archive']['sha256']
idx=json.loads(rawindex); entries={r['path']:r for r in idx['records']}; assert len(entries)==len(idx['records'])==m['records']==123
assert idx['sourceHead']==m['sourceHead']=='81dfb7c010eb117d93335bc3a7c91878546449f8'
unpacked=OUT/'unpacked'; unpacked.mkdir(exist_ok=True); verified=[]
with tarfile.open(archive) as t:
 ms=t.getmembers(); assert len(ms)==len(entries) and {r.name for r in ms}==set(entries)
 for item in ms:
  assert item.isfile() and not item.name.startswith('/') and '..' not in Path(item.name).parts
  b=t.extractfile(item).read(); r=entries[item.name]; assert len(b)==item.size==r['bytes'] and sha(b)==r['sha256'], item.name
  target=unpacked/item.name; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(b)
  if 'generated/' in item.name and item.name.endswith(('saturation-test','virgl-shader')):target.chmod(0o700)
  verified.append(r)
tracked=[]
for prefix in ['hot','cold/acceptance']:
 receipt=json.loads((unpacked/prefix/'receipt.json').read_bytes()); assert receipt['gitHead']==m['sourceHead']
 for r in receipt['sources']:
  if r['path'].startswith('renderer/virgl-shader/build/'):continue
  b=subprocess.check_output(['git','show',m['sourceHead']+':'+r['path']],cwd=ROOT)
  assert len(b)==r['bytes'] and sha(b)==r['sha256'],r['path']
  assert (ROOT/r['path']).read_bytes()==b or r['path']=='tools/verify-virgl-saturation.sh',r['path']  # only the critic's promoted-guard target wiring may differ
  tracked.append({'set':prefix,**r})
 for r in receipt['records']:
  b=(unpacked/prefix/r['path']).read_bytes(); assert len(b)==r['bytes'] and sha(b)==r['sha256']
for path,key in [('hot/receipt.json','hotReceiptSha256'),('cold/acceptance/receipt.json','coldReceiptSha256'),('cold/report.json','coldReportSha256')]:assert sha((unpacked/path).read_bytes())==m[key]
runtime='31641b3fb5fa4e09256531df67dfaaadf651b0ea'; changed=subprocess.check_output(['git','diff','--name-only',runtime,m['sourceHead']],text=True).splitlines()
assert set(changed)<={'tools/virgl-saturation/receipt.py','tools/virgl-saturation/cases.mjs','tools/virgl-saturation/README.md','tools/virgl-saturation/precision-source.json'}
report={'schema':'virgl-saturation-critic-authentication-v1','status':'passed','workerManifestSha256':sha((WORKER/'manifest.json').read_bytes()),'archive':m['archive'],'index':m['recordIndex'],'members':verified,'trackedSourceBindings':tracked,'evidenceOnlyRepairFiles':changed}
(OUT/'authentication.json').write_text(json.dumps(report,indent=2)+'\n')
print('Authenticated',len(verified),'members and',len(tracked),'frozen tracked source bindings; extracted only authenticated bytes.')
