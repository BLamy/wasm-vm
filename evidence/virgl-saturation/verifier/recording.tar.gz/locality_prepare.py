from pathlib import Path
import subprocess,struct,json,os,hashlib
OUT=Path('evidence/virgl-saturation/verifier');U=OUT/'unpacked';words=[0xc0000000,0xbf000000,0x40000000,0x40800000];den=[0x3f800000,0x40000000,0x3f800000,0x40000000]
head=['VERT','DCL IN[0]','DCL OUT[0], POSITION','DCL OUT[1], GENERIC[0]','DCL OUT[2], GENERIC[1]','DCL TEMP[0..3]','IMM[0] UINT32 {'+','.join(map(str,words))+'}','IMM[1] UINT32 {'+','.join(map(str,den))+'}','IMM[2] UINT32 {8388607,1056964608,23,0}']
tail=['AND TEMP[2], TEMP[1], IMM[2].xxxx','OR TEMP[2], TEMP[2], IMM[2].yyyy','USHR TEMP[3], TEMP[1], IMM[2].zzzz','OR TEMP[3], TEMP[3], IMM[2].yyyy','MOV OUT[0], IN[0]','MOV OUT[1], TEMP[2]','MOV OUT[2], TEMP[3]','END','']
cases=[{'name':'MOV_SAT-adjacent-plain-DIV','body':['MOV_SAT TEMP[0], IMM[0]','DIV TEMP[1], IMM[0], IMM[1]']},{'name':'DIV_SAT-adjacent-plain-DIV','body':['DIV_SAT TEMP[0], IMM[0], IMM[1]','DIV TEMP[1], IMM[0], IMM[1]']},{'name':'plain-DIV-masked-alias-SAT-raw-copy','body':['DIV TEMP[0], IMM[0], IMM[1]','MOV_SAT TEMP[0].xz, TEMP[0].wzyx','MOV TEMP[1], TEMP[0]']}]
for c in cases:c['text']='\n'.join(head+c.pop('body')+tail)
u=lambda n:struct.pack('<I',n);stream=b'VSA1'+u(len(cases))+b''.join(u(0)+u(1)+u(1)+u(len(c['text'].encode()))+c['text'].encode() for c in cases);(OUT/'locality-cases.bin').write_bytes(stream)
env=dict(os.environ);env.update(LLVM_PROFILE_FILE=str(OUT/'locality.profraw'),ASAN_OPTIONS='abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1');run=subprocess.run([str((U/'generated/saturation-sanitize/saturation-test').resolve())],input=stream,capture_output=True,env=env);assert run.returncode==0 and not run.stderr;(OUT/'locality-native.log').write_bytes(run.stdout)
for line in run.stdout.decode().splitlines():
 if line.startswith(('CASE ','PRIMARY ')):
  kind,index,data=line.split(' ',2);cases[int(index)]['pairVertex' if kind=='CASE' else 'primary']=json.loads(data)
(OUT/'locality-primary.json').write_text(json.dumps(cases,indent=2)+'\n');print('Three predeclared mixed saturation/plain DIV and aliased-copy probes compiled through both actual backends.')
