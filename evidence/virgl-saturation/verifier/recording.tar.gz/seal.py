#!/usr/bin/env python3
"""Seal independent critic records and authenticate every archive member."""
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
EXCLUDE = {'unpacked', '__pycache__', 'manifest.json', 'records.json', 'recording.tar.gz', 'README.md', 'seal-authentication.json'}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(name):
    return json.loads((OUT / name).read_text())

def binding(path):
    return {'path': str(path.relative_to(OUT)), 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}

verdict = read('verdict.json')
assert verdict['verdict'] == 'verified' and verdict['held'] == 14
paths = sorted(p for p in OUT.rglob('*') if p.is_file() and not p.is_symlink()
               and not any(part in EXCLUDE or part.endswith('.dSYM') for part in p.relative_to(OUT).parts))
index = {'schema': 'virgl-saturation-critic-records-v1', 'task': 'E6-T12g6h',
         'sourceHead': verdict['sourceHead'], 'runtimeHead': verdict['runtimeHead'],
         'workerSubmission': verdict['workerSubmission'], 'records': [binding(p) for p in paths]}
(OUT / 'records.json').write_text(json.dumps(index, indent=2) + '\n')
with (OUT / 'recording.tar.gz').open('wb') as stream:
    with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for p in paths:
                data = p.read_bytes()
                member = tarfile.TarInfo(str(p.relative_to(OUT)))
                member.size = len(data)
                member.mode = 0o644
                member.mtime = 0
                archive.addfile(member, io.BytesIO(data))

# No unindexed, repeated, nonregular or traversal member may enter this seal.
actual = []
with tarfile.open(OUT / 'recording.tar.gz', 'r:gz') as archive:
    for member in archive.getmembers():
        path = PurePosixPath(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts, member.name
        data = archive.extractfile(member).read()
        actual.append({'path': member.name, 'bytes': len(data), 'sha256': sha(data)})
assert len({r['path'] for r in actual}) == len(actual)
assert actual == index['records'], 'All bytes and sizes must authenticate in exact indexed order'
for promoted in verdict['promoted']:
    path = ROOT / promoted['path']
    assert sha(path.read_bytes()) == promoted['testSha256']
    assert sha((OUT / promoted['archiveMember']).read_bytes()) == promoted['testSha256']
    assert sha((OUT / promoted['report']).read_bytes()) == promoted['reportSha256']
assert sha((ROOT / verdict['targetWiring']['path']).read_bytes()) == verdict['targetWiring']['sha256']
manifest = {
    'schema': 'virgl-saturation-critic-seal-v1', 'task': 'E6-T12g6h', 'verdict': 'verified',
    'sourceHead': verdict['sourceHead'], 'runtimeHead': verdict['runtimeHead'],
    'workerSubmission': verdict['workerSubmission'], 'base': verdict['base'],
    'records': len(paths), 'allMembersAuthenticated': True,
    'archive': binding(OUT / 'recording.tar.gz'), 'recordIndex': binding(OUT / 'records.json'),
    'verdictRecord': binding(OUT / 'verdict.json'), 'predictions': {'held': 14, 'failed': 0, 'needsEvidence': 0},
    'workerDependencies': verdict['workerDependencies'], 'priorHeldSeals': verdict['priorHeldSeals'],
    'promoted': verdict['promoted'], 'targetWiring': verdict['targetWiring'],
    'coverage': {'runtimeHunks': 22, 'addedRuntimeLines': 85, 'needsEvidence': 0, 'dead': 0,
                 'defensiveZeroHitEdge': 'waived as unreachable under independently attacked prior numeric-authority invariant'},
    'physical': {'sealedWords': 242064, 'sealedPixels': 159744, 'fourthWords': 39576, 'fourthPixels': 26624,
                 'localityWords': 72, 'bothBackends': True},
    'carried': verdict['carried'], 'scope': verdict['scope'],
}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(OUT / 'README.md').write_text(f'''# E6-T12g6h fresh adversarial critic recording

VERDICT: **verified**. This verifier did not implement the task and did not edit
runtime. P1–P14 were written before recorded-state inspection; every prediction
held. `manifest.json`, `records.json` and `recording.tar.gz` are the independent
record: all {len(paths)} unique regular members, their byte sizes and SHA256s
were authenticated after sealing. The archive contains the initial and final
predictions, complete audit scripts/reports, actual archived-binary replay
transcripts and original-profile exports, V8 records, fourth-seed and additional
locality hardware captures/screenshots, original critic expectation correction,
real source-fault points, bounded implementation/fixture sabotage, and exact
promoted guards. `verdict.json` binds every report, command, source and limitation.

Worker submission `{verdict['workerSubmission']}` is reviewed against verified
predecessor `{verdict['base']}`. Runtime is `{verdict['runtimeHead']}` and the
frozen evidence source is `{verdict['sourceHead']}`. The worker archive remains
the authority for the original 123 members: both actual sanitizer binaries,
fixtures, original profiles and hot/cold raw recordings. Its archive digest is
`{verdict['workerDependencies']['archiveSha256']}`; index digest is
`{verdict['workerDependencies']['indexSha256']}`. `unpacked/` is deliberately
excluded as an extracted duplicate of that authenticated seal.

Independent TGSI/Fraction equations checked 242,064 sealed physical words and
159,744 pixels, 39,576 words/26,624 pixels at fourth seed 19,088,743, and 72
mixed SAT/plain-DIV/alias-copy words on both owned and pinned Mesa backends.
Numerical zero signs follow ESSL's allowance; owned raw MOV/copy and untouched
lanes stay exact. All six actual clamp/order faults contradict these equations.
One copied C lower-bound mutation and one test-fixture mutation fail the guards.

Actual native/profile and V8 evidence accounts for 22 runtime hunks/85 added
lines. The unsafe-known-numerator true edge has zero hits and is expressly
waived under the earlier numeric-authority invariant, supported by a source
argument and 88 independent producer cases; it is not claimed exercised.
Seven predecessor critic seals, 247 dependencies, six helpers/critic oracles
and seven production gates retain authenticated unchanged HELD results.

The permanent native/Wasm guard has 1,160 cases; the permanent capture guard
independently reconstructs actual full-word carriers and all 32 fragment planes.
Both are wired into `make verify-E6-T12g6h`; exact promotion identities are in
the manifest. Metadata attacks cover 26 contracts, 1,876 hostile mutations,
18 banks, ownership/restoration and zero accessor execution.

One pristine clone was authenticated. Its original interrupted second-seed
attempt and recovery remain preserved; only missing browser/fault/receipt
commands completed in the same unchanged clean clone. No uninterrupted cold
make, additional cold clone, guest offload, full-original admission, FPS/MIPS,
production negotiation, live demo or deployment is claimed. rr/ssh-dev are
waived by current policy. The private saturation compiler boundary is verified.
''')
result = {'status': 'passed', 'members': len(actual), 'archive': manifest['archive'],
          'recordIndex': manifest['recordIndex'], 'verdictRecord': manifest['verdictRecord'],
          'manifest': binding(OUT / 'manifest.json'), 'promoted': verdict['promoted']}
(OUT / 'seal-authentication.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
