import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {physicalPlan} from '../../../tools/virgl-saturation/plan.mjs';
const out='evidence/virgl-saturation/verifier/',hash=b=>createHash('sha256').update(b).digest('hex'),primary=JSON.parse(fs.readFileSync(out+'unpacked/generated/saturation-primary.json')),rows=[];
for(const prefix of ['unpacked/hot','unpacked/cold/acceptance'])for(const seed of [1640573655,3073696041,3798507267]){
 const path=out+prefix+'/gpu-'+seed+'/report.json',raw=fs.readFileSync(path),a=JSON.parse(raw).acceptance,plan=physicalPlan(seed,primary);
 assert.equal(a.planSha256,hash(JSON.stringify(plan)));assert.equal(a.vertices.length,plan.vertices.length);assert.equal(a.fragments.length,plan.fragments.length);
 for(let i=0;i<plan.vertices.length;i++){
  const p=plan.vertices[i],v=a.vertices[i];for(const key of ['op','variant','bank','backend','modifier','inputSource','text'])assert.deepEqual(v[key],p[key]);assert.equal(v.vectors.length,p.vectors.length);
  for(let k=0;k<p.vectors.length;k++){const expected=p.vectors[k],observed=v.vectors[k];assert.deepEqual(observed.input,expected.input);assert.equal(observed.condition,expected.condition);assert.deepEqual(observed.position,plan.positions[expected.position]);}
 }
 for(let i=0;i<plan.fragments.length;i++)for(const key of ['op','input','plane','text','backend'])assert.deepEqual(a.fragments[i][key],plan.fragments[i][key]);
 for(const op of ['MOV','MOV_SAT','DIV','DIV_SAT'])for(const backend of ['owned','mesa']){
  const vs=a.vertices.filter(v=>v.op===op&&v.backend===backend);for(let mask=1;mask<=15;mask++){const variant=mask===15?'direct':mask===5?'masked':'mask-'+mask;assert.ok(vs.some(v=>v.bank&&v.variant===variant));}
  for(const variant of ['alias','swizzled'])assert.ok(vs.some(v=>v.variant===variant));assert.ok(vs.some(v=>v.inputSource));if(op!=='MOV')assert.ok(vs.some(v=>v.modifier==='neg'));
  for(let plane=0;plane<32;plane++)assert.ok(a.fragments.some(f=>f.op===op&&f.backend===backend&&f.plane===plane));
 }
 for(const op of ['MOV_SAT','DIV_SAT'])assert.ok(a.vertices.some(v=>v.op===op&&v.variant==='join'&&v.vectors.some(x=>x.condition===0)&&v.vectors.some(x=>x.condition===0xffffffff)));
 const captures=a.vertices.filter(v=>v.capture);assert.equal(captures.length,8);for(const v of captures){const b=fs.readFileSync(v.capture.path);assert.equal(hash(b),v.capture.sha256);assert.equal(b.toString().split('\n')[v.capture.line-1].split(':').slice(1).join(':').trim(),v.capture.statement);assert.ok(v.text.includes(v.capture.statement));}
 rows.push({path:path.slice(out.length),reportSha256:hash(raw),planSha256:a.planSha256,vertices:a.vertices.length,fragments:a.fragments.length,allMasks:true,allPlanes:true,modifierAliasVersionPaths:true,exactCapturedStatements:captures.length});
}
fs.writeFileSync(out+'plan-audit.json',JSON.stringify({schema:'virgl-saturation-critic-plan-audit-v1',status:'passed',oracleScope:'The worker plan binds completeness only. Numerical observations are independently checked by the separate TGSI/Fraction interpreter.',records:rows},null,2)+'\n');console.log('Every scheduled shader, input, condition, position, backend, mask, all 32 planes and exact captured SAT statement is present.');
