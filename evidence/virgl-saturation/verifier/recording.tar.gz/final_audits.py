from pathlib import Path
import json,subprocess,hashlib,re
ROOT=Path.cwd();OUT=ROOT/'evidence/virgl-saturation/verifier';U=OUT/'unpacked';sha=lambda b:hashlib.sha256(b).hexdigest();worker=json.loads((ROOT/'evidence/virgl-saturation/worker/manifest.json').read_bytes())
source='81dfb7c010eb117d93335bc3a7c91878546449f8';runtime='31641b3fb5fa4e09256531df67dfaaadf651b0ea';base='bad92bfdaba16295b064a78c0767652da09be158';generated=[];record_heads=[]
for prefix,generation in [('hot','generated'),('cold/acceptance','cold-generated')]:
 receipt=json.loads((U/prefix/'receipt.json').read_bytes());assert receipt['gitHead']==source
 for row in receipt['sources']:
  if not row['path'].startswith('renderer/virgl-shader/build/'):continue
  path=U/generation/row['path'].removeprefix('renderer/virgl-shader/build/');b=path.read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'];generated.append({'set':prefix,**row})
 for path in [U/prefix/'native/report.json',U/prefix/'wasm/report.json',*[U/prefix/f'gpu-{seed}/report.json' for seed in [1640573655,3073696041,3798507267]]]:
  r=json.loads(path.read_bytes());head=r['gitHead'];changed=subprocess.check_output(['git','diff','--name-only',head,source],text=True).splitlines();assert set(changed)<={'tools/virgl-saturation/README.md','tools/virgl-saturation/cases.mjs','tools/virgl-saturation/precision-source.json','tools/virgl-saturation/receipt.py'};record_heads.append({'path':str(path.relative_to(OUT)),'head':head,'evidenceOnlyDrift':changed})
 report=json.loads((U/prefix/'retained/report.json').read_text());assert len(report['originals'])==25 and sum(c['native']['ok'] for c in report['originals'])==23;assert len(report['historical'])==112 and sum(c['native']['ok'] for c in report['historical'])==5
cold=json.loads((U/'cold/report.json').read_bytes());first=json.loads((U/'cold/initial-attempt/report.json').read_bytes());assert first['status']=='failed' and first['exitCode']==2;assert cold['status']=='passed' and cold['gitHead']==cold['cloneHead']==source;assert not any(cold[k] for k in ['statusBefore','statusAfter','recoveryStatusBefore']);assert first['clone']==cold['clone'];assert cold['removedEnvironmentNames']==cold['recoveryRemovedEnvironmentNames']==['RUST_LOG']
interrupted=json.loads((U/'cold/acceptance/browser-context-interruption/gpu-3073696041/report.json').read_bytes());assert interrupted['status']=='failed' and not interrupted.get('acceptance');assert 'Execution context was destroyed' in json.dumps(interrupted)
assert len(cold['recoveryCommands'])==6;assert [r['exitCode'] for r in cold['recoveryCommands']]==[0,0,1,1,1,0]
clone=Path(cold['clone']);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==source;assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=clone).strip()
for path in ['renderer/virgl-shader/raw_bits.c','renderer/virgl-shader/raw_bits.h','renderer/virgl-shader/bridge.c','renderer/virgl-command/constant-domain.mjs']:
 b=(ROOT/path).read_bytes();assert b==subprocess.check_output(['git','show',runtime+':'+path]);assert b==(clone/path).read_bytes()
# Bind the fourth seed's served runtime bytes; the only non-frozen tracked
# change reported during capture was the newly authored, unserved critic test.
fourth=json.loads((OUT/'gpu-19088743/report.json').read_bytes());assert fourth['trackedChanges']==['?? renderer/virgl-shader/tests/saturation-regressions.mjs'];sources={s['path']:s for s in fourth['sources']};bound=[]
for served in fourth['servedFiles']:
 p=ROOT/served['path'];b=p.read_bytes();assert sha(b)==served['sha256']==sources[served['path']]['sha256'];bound.append(served)
checks=[]
for cmd in [['node','--check','renderer/virgl-shader/tests/saturation-regressions.mjs'],['python3','-m','py_compile','renderer/virgl-shader/tests/saturation-capture-regressions.py'],['bash','-n','tools/verify-virgl-saturation.sh'],['git','diff','--check']]:
 r=subprocess.run(cmd,capture_output=True);assert r.returncode==0;checks.append({'command':cmd,'exitCode':r.returncode})
diff=subprocess.check_output(['git','diff',base,'8bb489e0','--','renderer','tools','Makefile'],text=True);assert not re.search(r'^\+.*(?:#\[ignore\]|NDEBUG|\.github/workflows)',diff,re.M)
r={'schema':'virgl-saturation-critic-final-audits-v1','status':'passed','generatedBindings':generated,'recordingHeads':record_heads,'coldClone':{'clone':str(clone),'sourceHead':source,'cleanStill':True,'initialAttemptPreserved':True,'interruptedNoNumericalResult':True,'sameCloneRecovery':cold['recoveryCommands'],'scrubbedEnvironment':cold['removedEnvironmentNames'],'classification':'incremental completion of one pristine clone; no portability/environment-isolation finding'},'fourthSourceBindings':bound,'checks':checks,'runtimeUnchanged':True,'testScope':'Only promoted critic guards, their target wiring, task status/log and evidence may change. No runtime implementation was edited.'}
(OUT/'final-checks.json').write_text(json.dumps(r,indent=2)+'\n');print('Frozen runtime/generated bindings, single clean clone recovery, fourth served sources and touched harness checks passed.')
