import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {parseConstantDomain,checkConversionBank,checkIndirectBank,checkRasterBank,checkRadialBank,checkLoopBank} from '../../../renderer/virgl-command/constant-domain.mjs';
const hash=b=>createHash('sha256').update(b).digest('hex'),directory='evidence/virgl-saturation/verifier/';
const native=JSON.parse(fs.readFileSync(directory+'unpacked/hot/native/report.json'));
const contracts=[...new Map(native.cases.filter(c=>c.ok&&c.saturation!==false).map(c=>[JSON.stringify(c.result.metadata),c])).values()];
const out={schema:'virgl-saturation-critic-consumer-attacks-v1',status:'running',contracts:[],attacks:[],banks:[],accessorInvocations:0};
const inert=x=>{if(x===null||typeof x!=='object')return x;const y=Array.isArray(x)?[]:{};for(const[key,d]of Object.entries(Object.getOwnPropertyDescriptors(x)))if(d.enumerable)y[key]=Object.hasOwn(d,'value')?inert(d.value):'[accessor]';return y;};
const attack=(c,name,mutate)=>{const m=structuredClone(c.result.metadata);mutate(m);const result=parseConstantDomain(m,c.stage);out.attacks.push({source:c.name,name,metadata:inert(m),result});assert.equal(result.ok,false,c.name+'/'+name);assert.equal(result.error.code,'shader-domain-error');};
try{
 for(const c of contracts){
  const m=c.result.metadata,parsed=parseConstantDomain(m,c.stage);assert.equal(parsed.ok,true);assert.ok(Object.isFrozen(parsed)&&Object.isFrozen(parsed.saturation)&&Object.isFrozen(parsed.saturation.operations));
  const owned=structuredClone(m),approved=parseConstantDomain(owned,c.stage),before=JSON.stringify(approved);owned.saturationContract.operations.fill('SABOTAGE');owned.saturationContract.equation='SABOTAGE';owned.uniforms.fill(null);assert.equal(JSON.stringify(approved),before);
  out.contracts.push({source:c.name,metadata:m,parsed,ownership:true});
  for(const key of ['saturationContract','saturationBaseProfile']){
   attack(c,'delete '+key,m=>delete m[key]);attack(c,'accessor '+key,m=>Object.defineProperty(m,key,{enumerable:true,get(){out.accessorInvocations++;throw Error('invoked');}}));
   attack(c,'array '+key,m=>m[key]=[]);attack(c,'null '+key,m=>m[key]=null);attack(c,'boolean '+key,m=>m[key]=true);
  }
  for(const key of Object.keys(m.saturationContract)){
   attack(c,'delete policy '+key,m=>delete m.saturationContract[key]);attack(c,'accessor policy '+key,m=>Object.defineProperty(m.saturationContract,key,{enumerable:true,get(){out.accessorInvocations++;return null;}}));
   attack(c,'type policy '+key,m=>m.saturationContract[key]=1);attack(c,'unknown policy '+key,m=>m.saturationContract[key]='unproved');
  }
  for(const profile of ['virgl-webgl2-raw-bits-v0','virgl-webgl2-raw-bits-v34','virgl-webgl2-raw-bits-v35','virgl-webgl2-straight-line-v5','__proto__',true,33,null])attack(c,'bad base '+profile,m=>m.saturationBaseProfile=profile);
  attack(c,'wrong top stage',m=>m.stage=c.stage==='vertex'?'fragment':'vertex');
 }
}catch(e){out.status='failed';out.failure=e.message;fs.writeFileSync(directory+'consumer-attacks.json',JSON.stringify(out,null,2)+'\n');throw e;}
// Complete matrix without any reliance on the worker's metadata mutations.
for(const c of contracts){
 const m=c.result.metadata;
 const other=c.stage==='vertex'?'fragment':'vertex',wrong=parseConstantDomain(m,other);assert.equal(wrong.ok,false);out.attacks.push({source:c.name,name:'wrong expected stage',result:wrong});
 for(const operations of [[],['MOV_SAT','DIV_SAT'],['MOV_SAT','MOV_SAT'],['DIV_SAT','MOV_SAT','ADD_SAT'],[0],[null],new Uint32Array([1]),{0:'MOV_SAT',length:1}])attack(c,'malformed operations '+JSON.stringify(operations),m=>m.saturationContract.operations=operations);
 attack(c,'sparse operations',m=>{m.saturationContract.operations.length=2;delete m.saturationContract.operations[0];});
 attack(c,'accessor operation',m=>Object.defineProperty(m.saturationContract.operations,0,{enumerable:true,get(){out.accessorInvocations++;return 'MOV_SAT';}}));
 attack(c,'symbol policy',m=>m.saturationContract[Symbol('extra')]=true);attack(c,'symbol metadata',m=>m[Symbol('extra')]=true);
 attack(c,'nonenumerable policy',m=>Object.defineProperty(m.saturationContract,'hidden',{value:true}));
 attack(c,'profile downgrade retaining SAT',m=>m.profile=m.saturationBaseProfile);
 for(const key of Object.keys(m).filter(k=>!['profile','stage','inputs','outputs','attributes','uniforms','samplers','uniformBlocks','saturationContract','saturationBaseProfile'].includes(k)))attack(c,'erase inherited '+key,m=>delete m[key]);
 const parsed=parseConstantDomain(m,c.stage);if(!parsed.domain&&!parsed.conversionDomain&&!m.uniforms.length)continue;
 const count=(parsed.domain??parsed.conversionDomain)?.count??m.uniforms[0].count;
 const words=Array(Math.min(count,46)*4).fill(0);if(parsed.radialDomain)words[16]=0x3f800000;
 const check=w=>parsed.conversionDomain?checkConversionBank(w,parsed.conversionDomain,parsed):parsed.rasterDomain?checkRasterBank(w,parsed.rasterDomain,!!parsed.constraint,!!parsed.radialDomain):parsed.radialDomain?checkRadialBank(w,count,!!parsed.constraint):parsed.constraint?checkLoopBank(w,count):checkIndirectBank(w,count,parsed.domain!==null);
 const good=check(words);assert.equal(good.ok,true);const old=good.words.slice();words.fill(0xdeadbeef);assert.deepEqual(good.words,old);assert.ok(Object.isFrozen(good.words));
 const attacks=[];for(const [name,w]of [['short',old.slice(0,-4)],['boolean',old.map((w,i)=>i? w:false)],['fraction',old.map((w,i)=>i?w:.5)],['overflow',old.map((w,i)=>i?w:0x100000000)],['NaN',old.map((w,i)=>i?w:NaN)]]){const result=check(w);assert.equal(result.ok,false);attacks.push({name,result});}
 out.banks.push({source:c.name,contract:parsed,owned:old,attacks});
}
assert.equal(out.accessorInvocations,0);out.status='passed';fs.writeFileSync(directory+'consumer-attacks.json',JSON.stringify(out,null,2)+'\n');console.log(contracts.length,'authentic contracts,',out.attacks.length,'independent hostile metadata attacks and',out.banks.length,'owned bank boundaries passed.');
