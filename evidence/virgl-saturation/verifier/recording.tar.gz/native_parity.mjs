import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createVirglShaderBridge} from '../../../renderer/virgl-shader/index.mjs';
import {PARTNER_VERTEX,PARTNER_FRAGMENT} from '../../../tools/virgl-signed-conversions/cases.mjs';
const out='evidence/virgl-saturation/verifier/',hash=b=>createHash('sha256').update(b).digest('hex'),bridge=await createVirglShaderBridge();
const records=[];
for(const prefix of ['hot','cold/acceptance']){
 const native=JSON.parse(fs.readFileSync(out+'unpacked/'+prefix+'/native/report.json')),wasm=JSON.parse(fs.readFileSync(out+'unpacked/'+prefix+'/wasm/report.json'));
 const bytes=fs.readFileSync(out+'unpacked/'+prefix+'/native/cases.bin');let at=0;assert.equal(bytes.toString('ascii',0,4),'VSA1');at=4;const u=()=>{const w=bytes.readUInt32LE(at);at+=4;return w;};assert.equal(u(),native.cases.length);
 const log=fs.readFileSync(out+'unpacked/'+prefix+'/native/native.log','utf8').trim().split('\n'),cases=new Map(),primary=new Map();
 for(const line of log){if(line==='STATUS passed')continue;const m=/^(CASE|PRIMARY) (\d+) (.*)$/.exec(line);assert.ok(m);(m[1]==='CASE'?cases:primary).set(Number(m[2]),JSON.parse(m[3]));}
 for(const c of native.cases){const stage=u()?'fragment':'vertex',ok=Boolean(u()),reference=Boolean(u()),length=u(),text=bytes.toString('utf8',at,at+length);at+=length;
  assert.equal(c.stage,stage);assert.equal(c.ok,ok);assert.equal(c.primary,reference);assert.equal(c.text,text);assert.equal(c.textSha256,hash(text));assert.deepEqual(c.result,cases.get(c.index));assert.deepEqual(bridge.translate({stage,text}),c.result);assert.deepEqual(wasm.cases[c.index].result,c.result);
  if(reference){assert.deepEqual(c.primaryResult,primary.get(c.index));const expected=[...text.matchAll(/^(?:\d+:\s*)?(MOV(?:_SAT)?|DIV(?:_SAT)?)\s+(?:TEMP|OUT)\[\d+\](?:\.([xyzw]+))?,/gm)].map(m=>({opcode:m[1],sourceType:m[1].startsWith('MOV')?0:4,destinationType:m[1].startsWith('MOV')?0:4,mask:m[2]?[...m[2]].reduce((n,c)=>n|(1<<'xyzw'.indexOf(c)),0):15}));assert.deepEqual(c.primaryResult.saturationInstructions,expected,c.name+' actual token mask/arity/typed SAT witness');}
 }
 assert.equal(at,bytes.length);assert.equal(cases.size,1313);assert.equal(primary.size,1245);
 records.push({set:prefix,recordSha256:hash(fs.readFileSync(out+'unpacked/'+prefix+'/native/report.json')),fixtureSha256:hash(bytes),cases:cases.size,pinnedWitnesses:primary.size,currentWasmFullResponseParity:true});
}
const physical=[];
for(const prefix of ['unpacked/hot/gpu-1640573655','unpacked/cold/acceptance/gpu-1640573655','gpu-19088743']){
 const j=JSON.parse(fs.readFileSync(out+prefix+'/report.json')),a=j.acceptance;
 for(const c of [...a.vertices,...a.fragments]){
  const request=Object.hasOwn(c,'variant')?{vertexText:c.text,fragmentText:PARTNER_FRAGMENT}:{vertexText:PARTNER_VERTEX,fragmentText:c.text};
  assert.ok(request);assert.deepEqual(bridge.translatePair(request),c.pair);
 }
 const sources=a.events.filter(e=>e.call==='shaderSource').map(e=>e.source),consumerSources=sources.slice(-8);
 for(let i=0;i<a.consumers.length;i++){const c=a.consumers[i],pair=bridge.translatePair(c.sources);assert.equal(pair.ok,true);assert.equal(consumerSources[2*i],pair.vertex.glsl);assert.equal(consumerSources[2*i+1],pair.fragment.glsl);}
 physical.push({set:prefix,pairs:a.vertices.length+a.fragments.length,consumerSources:8,completePairSourceParity:true});
}
fs.writeFileSync(out+'native-source-parity.json',JSON.stringify({schema:'virgl-saturation-critic-native-parity-v1',status:'passed',records,physical},null,2)+'\n');console.log('All 2,626 fixture requests, 2,490 actual pinned typed/mask witnesses and complete owned physical pair sources independently bound.');
