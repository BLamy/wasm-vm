import {createVirglShaderBridge} from '/renderer/virgl-shader/index.mjs';
import {createProgram,bindSystemBlocks,digest} from '/renderer/virgl-shader/tests/browser.mjs';
const assert=(v,s)=>{if(!v)throw Error(s);};
const partner='FRAG\nDCL IN[0], GENERIC[0], PERSPECTIVE\nDCL IN[1], GENERIC[1], PERSPECTIVE\nDCL OUT[0], COLOR\nMOV OUT[0], IN[0]\nEND\n';
export async function runAcceptance(){
 const report={status:'running',guestExecution:false,productionNegotiation:false,vertices:[],events:[]};window.__virglCriticLocalityReport=report;
 const canvas=document.querySelector('#gpu'),native=canvas.getContext('webgl2',{antialias:false,preserveDrawingBuffer:true,failIfMajorPerformanceCaveat:true});assert(native,'actual WebGL2');
 const debug=native.getExtension('WEBGL_debug_renderer_info');assert(debug,'hardware identity');report.renderer=native.getParameter(debug.UNMASKED_RENDERER_WEBGL);assert(!/software|swiftshader|llvmpipe|softpipe/i.test(report.renderer),'physical GPU');
 const live=new Map(),ids=new WeakMap();let id=0;
 const gl=new Proxy(native,{get(t,k){const f=Reflect.get(t,k,t);if(typeof f!=='function')return f;return(...args)=>{const x=f.apply(t,args);if(/^create/.test(k)&&x){ids.set(x,++id);live.set(id,String(k).slice(6));}if(/^delete/.test(k)&&args[0])live.delete(ids.get(args[0]));if(k==='shaderSource')report.events.push({call:k,source:args[1]});return x;};}});
 const bridge=await createVirglShaderBridge(),cases=await(await fetch('/evidence/virgl-saturation/verifier/locality-primary.json')).json();
 for(const c of cases)for(const backend of ['owned','mesa']){
  const pair=bridge.translatePair({vertexText:c.text,fragmentText:partner});assert(pair.ok,'actual pair admission');
  const vertex=backend==='mesa'?{...pair.vertex,glsl:c.primary.glsl}:pair.vertex;
  const built=createProgram(gl,vertex,pair.fragment),program=built.program,buffers=[],vao=gl.createVertexArray(),tf=gl.createTransformFeedback(),out=gl.createBuffer();buffers.push(out);
  const entry={name:c.name,backend,text:c.text,sourceSha256:await digest(c.text),pair,primary:c.primary,reflection:[],position:[.25,-.5,.125,1]};report.vertices.push(entry);
  try{gl.transformFeedbackVaryings(program,['gl_Position','vso_g0','vso_g1'],gl.INTERLEAVED_ATTRIBS);gl.linkProgram(program);assert(gl.getProgramParameter(program,gl.LINK_STATUS),'physical link');for(let i=0;i<3;i++){const v=gl.getTransformFeedbackVarying(program,i);entry.reflection.push({name:v.name,type:v.type,size:v.size});}
   gl.useProgram(program);gl.bindVertexArray(vao);bindSystemBlocks(gl,program,pair.vertex.metadata,buffers);const at=gl.getAttribLocation(program,'in_0');assert(at>=0,'physical position');gl.disableVertexAttribArray(at);gl.vertexAttrib4fv(at,new Float32Array(entry.position));entry.attributes=[...gl.getVertexAttrib(at,gl.CURRENT_VERTEX_ATTRIB)].map(x=>new Uint32Array(new Float32Array([x]).buffer)[0]);
   gl.bindTransformFeedback(gl.TRANSFORM_FEEDBACK,tf);gl.bindBuffer(gl.TRANSFORM_FEEDBACK_BUFFER,out);gl.bufferData(gl.TRANSFORM_FEEDBACK_BUFFER,48,gl.DYNAMIC_READ);gl.bindBufferBase(gl.TRANSFORM_FEEDBACK_BUFFER,0,out);gl.enable(gl.RASTERIZER_DISCARD);gl.beginTransformFeedback(gl.POINTS);gl.drawArrays(gl.POINTS,0,1);gl.endTransformFeedback();const raw=new Uint8Array(48);gl.getBufferSubData(gl.TRANSFORM_FEEDBACK_BUFFER,0,raw);entry.bytes=[...raw];entry.sha256=await digest(raw);entry.observed=[...new Uint32Array(raw.buffer)];assert(gl.getError()===gl.NO_ERROR,'physical feedback errors');
  }finally{gl.disable(gl.RASTERIZER_DISCARD);gl.bindBufferBase(gl.TRANSFORM_FEEDBACK_BUFFER,0,null);gl.bindTransformFeedback(gl.TRANSFORM_FEEDBACK,null);gl.bindVertexArray(null);gl.useProgram(null);gl.deleteTransformFeedback(tf);gl.deleteVertexArray(vao);for(const b of buffers)gl.deleteBuffer(b);gl.deleteProgram(program);}
 }
 assert(live.size===0,'all actual objects disposed');assert(gl.getError()===gl.NO_ERROR,'final GL errors');report.objects={created:id,live:live.size};report.status='passed';document.querySelector('#status').textContent='Mixed SAT/plain DIV and aliased raw copies captured on both backends';return report;
}
