#!/usr/bin/env python3
"""Finalize the independent critic ledger without editing runtime implementation."""
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
TASK = ROOT / 'tasks/epic-6-transcendence/E6-T12g6h-saturation.md'
BASE = 'bad92bfdaba16295b064a78c0767652da09be158'
SOURCE = '81dfb7c010eb117d93335bc3a7c91878546449f8'
RUNTIME = '31641b3fb5fa4e09256531df67dfaaadf651b0ea'
SUBMISSION = '8bb489e04170afd3a9158afeb4a9808386db5997'

def read(name):
    return json.loads((OUT / name).read_text())

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def point(name, key='status'):
    path = OUT / name
    line = next(i for i, s in enumerate(path.read_text().splitlines(), 1) if '"' + key + '"' in s)
    return {'path': name, 'line': line, 'sha256': digest(path)}

reports = [
    'authentication.json', 'source-semantics.json', 'fourth-seed-semantics.json',
    'independent-regressions.json', 'consumer-attacks.json', 'coverage-audit.json',
    'carry-forward.json', 'sensitivity.json', 'locality-semantics.json',
    'native-source-parity.json', 'native-replays.json', 'plan-audit.json',
    'final-checks.json', 'independent-capture-regressions.json',
]
for name in reports:
    assert read(name)['status'] == 'passed', name
proofs = {
    'P1': ['authentication.json', 'final-checks.json'],
    'P2': ['independent-regressions.json', 'coverage-audit.json'],
    'P3': ['source-semantics.json', 'fourth-seed-semantics.json'],
    'P4': ['independent-regressions.json', 'plan-audit.json'],
    'P5': ['independent-regressions.json', 'locality-semantics.json'],
    'P6': ['native-replays.json', 'native-source-parity.json', 'final-checks.json'],
    'P7': ['consumer-attacks.json', 'coverage-audit.json'],
    'P8': ['source-semantics.json', 'consumer-attacks.json'],
    'P9': ['plan-audit.json', 'source-semantics.json', 'native-source-parity.json'],
    'P10': ['sensitivity.json'],
    'P11': ['coverage-audit.json', 'native-replays.json', 'independent-regressions.json'],
    'P12': ['final-checks.json'],
    'P13': ['carry-forward.json'],
    'P14': ['fourth-seed-semantics.json', 'independent-regressions.json', 'locality-semantics.json'],
}
initial = OUT / 'initial-predictions.json'
if not initial.exists():
    shutil.copyfile(OUT / 'predictions.json', initial)
predictions = read('initial-predictions.json')
assert all(p['result'] == 'PENDING' for p in predictions['predictions'])
predictions['completedStatus'] = 'all-predictions-held'
predictions['originalPredictionsSha256'] = digest(initial)
for p in predictions['predictions']:
    p['result'] = 'HELD'
    p['evidence'] = [point(name) for name in proofs[p['id']]]
(OUT / 'predictions.json').write_text(json.dumps(predictions, indent=2) + '\n')

promoted = []
for path, report, counts in [
    ('renderer/virgl-shader/tests/saturation-regressions.mjs', 'independent-regressions.json', {'cases': 1160}),
    ('renderer/virgl-shader/tests/saturation-capture-regressions.py', 'independent-capture-regressions.json', {'physicalWords': 39576, 'physicalPixels': 26624}),
]:
    copy = OUT / 'promoted' / Path(path).name
    copy.parent.mkdir(exist_ok=True)
    shutil.copyfile(ROOT / path, copy)
    promoted.append({'path': path, 'testSha256': digest(ROOT / path), 'archiveMember': str(copy.relative_to(OUT)),
                     'report': report, 'reportSha256': digest(OUT / report), 'schema': read(report)['schema'], **counts})
shutil.copyfile(ROOT / 'tools/verify-virgl-saturation.sh', OUT / 'promoted/verify-virgl-saturation.sh')

verdict = {
    'schema': 'virgl-saturation-critic-verdict-v1', 'task': 'E6-T12g6h', 'verdict': 'verified',
    'date': '2026-10-04', 'base': BASE, 'sourceHead': SOURCE, 'runtimeHead': RUNTIME, 'workerSubmission': SUBMISSION,
    'role': 'Fresh adversarial verifier; did not implement this task and never edited runtime implementation.',
    'predictions': predictions['predictions'], 'held': 14, 'failed': 0, 'needsEvidence': 0,
    'reports': [point(name) for name in reports],
    'workerDependencies': {
        'manifestSha256': read('authentication.json')['workerManifestSha256'],
        'archiveSha256': read('authentication.json')['archive']['sha256'],
        'indexSha256': read('authentication.json')['index']['sha256'],
        'authenticatedMembers': 123, 'trackedSourceBindings': 610,
    },
    'native': {'recordedBinaries': read('native-replays.json')['replays'], 'requests': 2626, 'pinnedWitnesses': 2490,
               'independentNativeWasmCases': 1160, 'actualFixtureAndResponseParity': True},
    'physical': {'sealedWords': 242064, 'sealedPixels': 159744, 'fourthSeed': 19088743,
                 'fourthWords': 39576, 'fourthPixels': 26624, 'localityWords': 72,
                 'backends': ['owned', 'pinned-mesa'],
                 'equation': 'Interpret actual TGSI source with independent Fraction arithmetic and independent binary32 rounding/enclosures; post-operation ternary clamp.',
                 'budget': 'Highp division: 5/2 ULP on positive denominators in [2^-126,2^126]; independently enclose permitted numeric zero signs; ordinary owned raw MOV/copy and untouched lanes remain exact.',
                 'primarySpecification': {'url': 'https://registry.khronos.org/OpenGL/specs/es/3.0/GLSL_ES_Specification_3.00.pdf',
                                          'point': 'ESSL 3.00 section 4.5.1; PDF page index 58, printed page 52'},
                 'sourceSchedulesAndReflections': point('plan-audit.json'), 'sourceParity': point('native-source-parity.json'),
                 'localityPredictions': point('locality-predictions.json', 'schema')},
    'metadata': {'contracts': 26, 'hostileAttacks': 1876, 'ownedBanks': 18, 'accessorInvocations': 0},
    'coverage': {'runtimeHunks': 22, 'addedRuntimeLines': 85, 'needsEvidence': [], 'dead': [],
                 'classification': 'Actual archived native binaries and original profiles, actual V8 hit counts, explicit static/type/control waivers.',
                 'divisionPredicate': read('coverage-audit.json')['divisionPredicate'],
                 'defensiveZeroHitEdge': read('coverage-audit.json')['unsafeKnownNumeratorPremise'],
                 'harnessAndEvidence': 'New build/guard/seal/receipt paths ran in recorded acceptance; declarative numerical policy and capture records bind actual source/readbacks; verifier-only target wiring is directly validated. Documentation/index/log hunks are nonexecutable proof records.'},
    'sensitivity': read('sensitivity.json'),
    'novelAttack': '16 independent consumed-lane divisor poison/swizzle/alias cases; authority producer matrix has 88 independent cases. Additional physical mixed SAT/plain DIV and alias-copy probes have 72 words.',
    'expectationCorrection': read('expectation-correction.json'),
    'correctionClassification': 'A critic case initially ignored the already-predicted nonunit exponent margin. FRC_PRECISE(2^-126)/2 correctly rejects at exponent difference -127. The original source/failure are preserved; only the critic prediction was corrected before completing the matrix. No runtime contradiction.',
    'coldClone': read('final-checks.json')['coldClone'],
    'coldQualification': 'One pristine clone, original failed attempt preserved; second-seed Playwright context interruption had no numerical state; only missing browser/fault/receipt commands recovered in the same clean unchanged clone. No uninterrupted cold make is claimed.',
    'priorHeldSeals': read('carry-forward.json')['priorHeldSeals'],
    'carried': {'unchangedDependencies': 247, 'unchangedHelpers': 6, 'unchangedProductionGates': 7,
                'wholePredecessorResponsesPerSet': 2933, 'heldFractionPhysicalWords': 36096,
                'boundary': 'Carry only authenticated unchanged source, dependencies, complete prior metadata and evidence digests. Changed compiler and consumer hunks receive current proof.'},
    'promoted': promoted,
    'targetWiring': {'path': 'tools/verify-virgl-saturation.sh', 'sha256': digest(ROOT / 'tools/verify-virgl-saturation.sh'),
                     'archiveMember': 'promoted/verify-virgl-saturation.sh'},
    'commands': [
        'python3 evidence/virgl-saturation/verifier/authenticate.py',
        'python3 evidence/virgl-saturation/verifier/source_semantics.py',
        'python3 evidence/virgl-saturation/verifier/replay.py',
        'node renderer/virgl-shader/tests/saturation-regressions.mjs --native evidence/virgl-saturation/verifier/unpacked/generated/native/virgl-shader --output evidence/virgl-saturation/verifier/independent-regressions.json',
        'node tools/virgl-saturation/browser.mjs --output evidence/virgl-saturation/verifier/gpu-19088743 --seed 19088743',
        'python3 evidence/virgl-saturation/verifier/source_semantics.py --fourth',
        'node evidence/virgl-saturation/verifier/consumer_attacks.mjs',
        'python3 evidence/virgl-saturation/verifier/coverage_audit.py',
        'python3 evidence/virgl-saturation/verifier/carry_forward.py',
        'python3 evidence/virgl-saturation/verifier/sabotage.py',
        'python3 renderer/virgl-shader/tests/saturation-capture-regressions.py --report evidence/virgl-saturation/verifier/gpu-19088743/report.json --output evidence/virgl-saturation/verifier/independent-capture-regressions.json',
        'python3 evidence/virgl-saturation/verifier/sensitivity.py',
        'node evidence/virgl-saturation/verifier/native_parity.mjs',
        'python3 evidence/virgl-saturation/verifier/locality_prepare.py',
        'node evidence/virgl-saturation/verifier/locality.mjs',
        'python3 evidence/virgl-saturation/verifier/locality_semantics.py',
        'node evidence/virgl-saturation/verifier/plan_audit.mjs',
        'python3 evidence/virgl-saturation/verifier/final_audits.py',
    ],
    'scope': {'runtimeEdited': False, 'productionAdmission': False, 'guestOffload': False, 'fullOriginalAdmission': False,
              'fpsMipsOrDeploymentClaim': False, 'rrHostLayer': 'waived by current AGENTS.md',
              'retainedOriginals': '23/25 and 5/112 remain unchanged; both complete compositor originals stay rejected'},
}
(OUT / 'verdict.json').write_text(json.dumps(verdict, indent=2) + '\n')

def cite(name, key='status'):
    p = point(name, key)
    return f"`{p['path']}:{p['line']}`, SHA256 `{p['sha256']}`"

entry = f'''\n### 2026-10-04 — fresh adversarial verifier — VERDICT: verified

VERDICT: verified. Reviewed the complete `{BASE}..{SUBMISSION}` diff before
recorded states, wrote P1–P14 first, and attempted to refute every scoped criterion.
All fourteen predictions are HELD. Runtime `{RUNTIME}` and frozen source
`{SOURCE}` remain unchanged; this session edited only critic guards, acceptance
wiring, status/log/queue and evidence. Report citations below name archive members
in `evidence/virgl-saturation/verifier/recording.tar.gz`; `verdict.json` and the
index bind every report, exact command, source and raw point.

- **P1 seal/source — HELD.** Authenticated all 123 worker members and 610 tracked
  source bindings, including both actual sanitizer binaries and original profiles.
  Evidence-only signed-zero and byte-set repairs did not change runtime.
  {cite('authentication.json')}.
- **P2/P4 domain, authority, versions — HELD.** 1,160 independent native/Wasm
  cases reject zero/special/subnormal/unknown/out-of-domain divisors, enforce
  consumed post-modifier versions and exponent margins, and attack killed/saved
  facts, aliases, liveness, masks and control-flow joins. Unit and nonunit paths
  consume existing numeric authority. The 88-case producer matrix attacks the
  defensive authority premise; 16 cases poison unused/consumed divisor lanes.
  {cite('independent-regressions.json')}.
- **P3 equations and actual hardware — HELD.** Independently interpreted actual
  TGSI with Fraction arithmetic and separate binary32 rounding, then checked
  all 242,064 hot/cold words and 159,744 pixels on owned and pinned Mesa backends.
  Division uses the ESSL highp 2.5-ULP bound and permits numerical zero signs;
  ordinary owned raw MOV/copy and untouched lanes stay exact. No worker oracle,
  emitted GLSL inverse, or recorded expected value supplies these equations.
  {cite('source-semantics.json')}.
- **P5 locality, clamp order, ranges — HELD.** The independent guard rejects
  unsupported SAT/PRECISE spellings and computed F2I range authority. An additional
  physical three-program probe checked 72 words: adjacent plain DIV stays
  `[-2,-.25,2,2]`; masked aliased MOV_SAT reads the old `.wzyx` and yields
  `[1,-.25,0,2]`, preserving untouched DIV words. Predictions were written before
  readbacks, not inferred from them. {cite('locality-semantics.json')}.
- **P6 actual native/Wasm/pinned converter — HELD.** Replayed both archived
  sanitizer binaries with their exact fixture; transcripts are byte-identical,
  no sanitizer error appears, and original raw profiles merge/export identically.
  Independently parsed 2,626 requests and 2,490 pinned token witnesses, including
  actual SAT masks. Complete Wasm pair sources also match physical captures.
  {cite('native-replays.json')}; {cite('native-source-parity.json')}.
- **P7 metadata ownership — HELD.** 1,876 hostile attacks across 26 distinct
  contracts preserve complete old obligations, descending versions, stages,
  immutable copies and strict shapes/keys/types. No accessor executes; malformed
  ranges/banks reject. {cite('consumer-attacks.json')}.
- **P8 owning banks/lifetime — HELD.** Independently checked physical uniforms,
  mutated-caller A/B/A snapshots, sync/async restoration and all 18 bank variants.
  Nonfinite updates reject atomically; successful and faulty runs dispose objects,
  leave zero live budgets and report no unexpected GL/browser errors.
  {cite('source-semantics.json')}.
- **P9 reflection, schedules, captures — HELD.** Actual shaderSource events bind
  current pair/pinned sources. All scheduled positions execute: each seed has
  305 vertex probes and 1,664 fragment probes, masks 1–15, both carriers, all
  32 planes, aliases/swizzles/control arms, and four exact captured instructions
  on each backend. Reflection types/extents and physical banks match.
  {cite('plan-audit.json')}.
- **P10 numerical faults and sabotage — HELD.** All six actual emitted-source
  lower/upper/order faults contradict the independent capture guard and dispose
  resources. For example, hot order fault vertex 225/vector 0/lane 4 observes
  `0x3f000000` outside predicted `0x3f400000` ±2 ULP; raw capture
  `76eab8c6ffb75662ab50457fc5239f8ced00566ceceb8dd2c75818663b28384c` is at
  hot fault report line 1,631,264. Copy-only native lower-bound sabotage admits
  forbidden 0/0 and fails `bounded-division-0-0-false`; fixture sabotage calling
  raw word 1 normal fails `numeric-authority-MOV_SAT-1-false` against correct code.
  {cite('sensitivity.json')}.
- **P11 changed-hunk coverage — HELD.** Actual recorded binaries/profiles and
  five V8 records cover 22 runtime hunks/85 added runtime lines. Every line has
  hits or an explicit static/type/comment/control waiver; no dead/unproven hunk.
  The predicate has 3,172 calls per set. The true edge of
  `!safe_raw_float(a)` has zero hits and is **waived**, not called exercised:
  existing numeric authority rejects raw unsafe words first; fully known numeric
  producers preserve safe words, unknown arithmetic erases facts, and copy/join/
  negation preserves the invariant. Source points `raw_bits.c:77–87,127–153,
  208–219,265–339` and 88 independent producer cases support the argument.
  Defensive rejection stays as a future invariant guard.
  {cite('coverage-audit.json')}.
- **P12 pristine clone — HELD, qualified.** One exact-source clean clone with
  scrubbed environment was inspected directly. The original second-seed browser
  context interruption and failed make are preserved; they supplied no numerical
  state. Only missing two-seed/three-fault/receipt commands were recovered in
  that same unchanged clean clone. This is incremental completion, not a claim
  of an uninterrupted cold make or an extra clone.
  {cite('final-checks.json', 'coldClone')}.
- **P13 carried HELD — HELD.** Authenticated seven predecessor critic seals and
  unchanged boundaries: 247 dependencies, six helpers/critic oracles and seven
  production gates. All 2,933 whole predecessor responses per set match; precise
  FRC retains its 36,096-word capture and real negative-complement fault.
  Original partitions remain 23/25 and 5/112; both complete compositor bodies
  remain rejected. {cite('carry-forward.json')}.
- **P14 independent seed and novel attack — HELD.** Physical seed 19,088,743
  adds 39,576 independently checked words/26,624 pixels on both backends. All
  served bytes match frozen runtime; the sole untracked critic guard was not
  served. The novel lane/version poison cases and physical adjacency/alias probe
  above held. {cite('fourth-seed-semantics.json')}.

The original critic producer-case failure is also archived. Its first expectation
ignored the already-stated quotient margin: FRC_PRECISE(2^-126)/2 correctly
rejects at exponent difference -127. Only that critic expectation was corrected
before the complete matrix; no product contradiction was found
({cite('expectation-correction.json', 'finding')}). The numerical budget is
grounded in [ESSL 3.00 §4.5.1, printed page 52](https://registry.khronos.org/OpenGL/specs/es/3.0/GLSL_ES_Specification_3.00.pdf).

SUITE: promoted `saturation-regressions.mjs` (1,160 native/Wasm cases) and
`saturation-capture-regressions.py` (source-equation checks on actual full-word
carriers and all fragment planes), wired into `make verify-E6-T12g6h`. Both guards
passed directly and failed bounded sabotage. Syntax, Python compilation, shell
syntax and diff whitespace checks passed. Exact commands and test SHA256s are in
`verdict.json`. No runtime repair was made. rr is waived by current policy; no
FPS, MIPS, live guest, full-original, production admission or deployment proof
is claimed. The private compiler boundary alone is verified.
'''
text = TASK.read_text()
assert 'status: implemented\n' in text
assert 'fresh adversarial verifier — VERDICT:' not in text
TASK.write_text(text.replace('status: implemented\n', 'status: verified\n', 1) + entry)
print(json.dumps({'verdict': 'verified', 'predictionsHeld': 14, 'verdictSha256': digest(OUT / 'verdict.json'), 'promoted': promoted}))
