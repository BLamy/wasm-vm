import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
ROOT=Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
OUT=ROOT/'target/evidence/virgl-saturation-cold'
CLONE=Path('/var/folders/nr/cyvk1qc14jj5c081vj1xts000000gn/T/wasm-vm-virgl-saturation-cold-hoqdvuzq/wasm-vm')
EVIDENCE=CLONE/'target/evidence/virgl-saturation-cold'
HEAD='81dfb7c010eb117d93335bc3a7c91878546449f8'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=CLONE,text=True).strip()
report=json.loads((OUT/'report.json').read_bytes())
assert report['status']=='failed' and report['clone']==str(CLONE)
assert git('rev-parse','HEAD')==HEAD and not git('status','--porcelain','--untracked-files=all')
preserved=OUT/'initial-attempt';preserved.mkdir()
for name in ['report.json','cold.log']:shutil.copy2(OUT/name,preserved/name)
interruption=EVIDENCE/'browser-context-interruption';interruption.mkdir()
shutil.copytree(EVIDENCE/'gpu-3073696041',interruption/'gpu-3073696041')
shutil.copy2(EVIDENCE/'acceptance.log',interruption/'acceptance.log')
shutil.copy2(preserved/'report.json',interruption/'initial-cold-report.json')
shutil.copy2(Path(__file__),interruption/'recovery.py')
env=dict(os.environ)
removed=sorted(k for k in env if k.startswith(('CARGO_','RUST','VIRGL_','npm_config_','NPM_CONFIG_')) or k in {'NODE_OPTIONS','NODE_PATH','PYTHONPATH','PYTHONHOME','CHROME','CC','CXX','CFLAGS','CPPFLAGS','LDFLAGS','EMCC','EM_CONFIG','EMSDK','EMSDK_NODE','EMSDK_PYTHON','NODE_V8_COVERAGE'})
for k in removed:del env[k]
commands=[]
for seed in [3073696041,3798507267]:commands.append((['node','tools/virgl-saturation/browser.mjs','--output',str(EVIDENCE/f'gpu-{seed}'),'--seed',str(seed)],False))
for fault in ['lower','upper','order']:commands.append((['node','tools/virgl-saturation/browser.mjs','--output',str(EVIDENCE/f'fault-{fault}'),'--fault',fault],True))
commands.append((['python3','tools/virgl-saturation/receipt.py',str(EVIDENCE)],False))
report['initialAttempt']={'status':'failed','exitCode':report['exitCode'],'reportSha256':sha(preserved/'report.json'),'logSha256':sha(preserved/'cold.log'),'path':'initial-attempt'}
report['completionMethod']='same pristine clone; carry completed native/wasm/first-seed evidence, replay only missing browser/fault/receipt commands after Playwright execution-context loss'
report['recoveryRemovedEnvironmentNames']=removed
report['recoveryStartedAt']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
report['recoveryStatusBefore']=git('status','--porcelain','--untracked-files=all')
report['recoveryCommands']=[]
report['status']='running'
try:
    with (OUT/'cold.log').open('ab') as log:
        log.write(b'\nRECOVERY: same frozen pristine clone, initial Chrome context interruption preserved.\n');log.flush()
        for command,negative in commands:
            log.write((json.dumps({'command':command,'expectNonzero':negative})+'\n').encode());log.flush()
            result=subprocess.run(command,cwd=CLONE,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
            report['recoveryCommands'].append({'command':command,'exitCode':result.returncode,'expectNonzero':negative})
            if bool(result.returncode)!=negative:raise ValueError('unexpected recovery command result: '+repr(command))
    report['cloneHead']=git('rev-parse','HEAD');report['statusAfter']=git('status','--porcelain','--untracked-files=all')
    assert report['cloneHead']==HEAD and not report['statusAfter']
    shutil.copytree(EVIDENCE,OUT/'acceptance',dirs_exist_ok=True)
    receipt=json.loads((OUT/'acceptance/receipt.json').read_bytes())
    assert receipt['status']=='passed' and receipt['gitHead']==HEAD
    report['receiptSha256']=sha(OUT/'acceptance/receipt.json');report['status']='passed';report['exitCode']=0
    report.pop('error',None)
except Exception as error:
    report['status']='failed';report['error']=str(error)
    shutil.copytree(EVIDENCE,OUT/'acceptance',dirs_exist_ok=True)
    raise
finally:
    report['recoveryFinishedAt']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());report['logSha256']=sha(OUT/'cold.log')
    (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print('Cold saturation acceptance complete in original pristine clone:',CLONE)
