#!/usr/bin/env python3
import gzip,hashlib,json,subprocess,tarfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
FROZEN='001f3d42f3d55f2c225af65a81996d0c8b9d087c'
BASE='3e5e41429aadc9acbe68fade926d2763d1e2a356'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert json.loads((OUT/'predictions.json').read_text())['phase']=='before-recording-inspection'

def reopen(base,expected=None,extract=None,carry_current=True,source_commit=None):
    parts={n:(base/n).read_bytes() for n in ['manifest.json','records.json','recording.tar.gz']}
    digests={n:sha(b) for n,b in parts.items()}
    if expected:assert digests==expected,(base,digests)
    manifest=json.loads(parts['manifest.json']);index=json.loads(parts['records.json'])
    assert sha(parts['records.json'])==manifest['recordIndexSha256']
    assert sha(parts['recording.tar.gz'])==manifest['archiveSha256']
    records={r['path']:r for r in index['records']};assert len(records)==len(index['records'])==manifest['records']
    seen=set();rawbytes=0;sources=[]
    with tarfile.open(base/'recording.tar.gz','r:gz') as archive:
        for m in archive:
            assert m.isfile() and m.name in records and m.name not in seen and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts,m.name
            raw=archive.extractfile(m).read();r=records[m.name]
            assert len(raw)==r['bytes']==m.size and sha(raw)==r['sha256'],m.name
            seen.add(m.name);rawbytes+=len(raw)
            if m.name.startswith('source/'):
                name=m.name[len('source/'):];source_head=source_commit or index.get('sourceHead') or manifest.get('sourceHead') or index['runtimeSourceHead'];old=git('show',source_head+':'+name);assert raw==old,(m.name,'recorded source')
                if carry_current and name not in ['tasks/epic-6-transcendence/E6-T11d36-standard-packed-normalized-consumer.md']:
                    assert (ROOT/name).read_bytes()==raw,(name,'current source')
                sources.append(dict(path=name,sha256=r['sha256']))
            if extract:
                dest=extract/m.name;dest.parent.mkdir(parents=True,exist_ok=True)
                if not dest.is_file() or dest.read_bytes()!=raw:dest.write_bytes(raw)
    assert seen==set(records)
    return dict(path=base.relative_to(ROOT).as_posix(),digests=digests,members=len(seen),rawBytes=rawbytes,sourceHead=index.get('sourceHead'),sourceCount=len(sources)),records,sources

start=time.time();worker=ROOT/'evidence/virgl-packed-normalized-consumer/worker';unpacked=OUT/'unpacked'
winfo,wrecords,wsources=reopen(worker,dict(**{'manifest.json':'bb8e9018f976d3da260244fc7336ec0715b151a31ca3e9c2a0b7ccfe10c63efa','records.json':'79362e795d016d5653defb8c017cde0f40e51eea807a6e32e6b36d666b9328f7','recording.tar.gz':'c3ad79b7cc0fb58e1cbc93929f509719ccbd832214a65b00fbe154224b645c4f'}),unpacked)
assert winfo['members']==83780 and winfo['sourceHead']==FROZEN
worker_manifest=json.loads((worker/'manifest.json').read_text())
receipts={}
for prefix in ['hot','cold']:
    receiptpath=unpacked/prefix/'receipt.json';receipt=json.loads(receiptpath.read_text())
    wanted='aff2dcd143e6bed1e190d583958ab1408fd7e196d313bbb3b169c03ec7845437' if prefix=='hot' else '6fe4aa9fdcaaa0f9c767d54392f424fa83e3eaa25127c666aa90f2fdf7a44fa3'
    assert sha(receiptpath.read_bytes())==wanted and receipt['status']=='passed' and receipt['gitHead']==FROZEN
    for name,digest in receipt['files'].items():assert sha((unpacked/prefix/name).read_bytes())==digest,(prefix,name)
    for name,digest in receipt['sources'].items():assert sha(git('show',FROZEN+':'+name))==digest,(prefix,name)
    for name,digest in receipt['generated'].items():
        raw=(unpacked/(prefix+'-generated')/name).read_bytes();assert sha(raw)==digest and raw==(ROOT/name).read_bytes(),name
    receipts[prefix]=dict(sha256=wanted,files=len(receipt['files']),sources=len(receipt['sources']),generated=receipt['generated'])
    for reportfile in (unpacked/prefix).rglob('report.json'):
        if reportfile==unpacked/'cold/report.json':continue
        report=json.loads(reportfile.read_text())
        assert report['gitHead']==FROZEN and report['browserErrors']==dict(console=[],page=[],requests=[]),str(reportfile)
        for source in report['sources']:
            member='hot-generated/'+source['path'] if '/build/' in source['path'] else 'source/'+source['path']
            assert wrecords[member]['sha256']==source['sha256'] and wrecords[member]['bytes']==source['bytes'],(reportfile,source['path'])
        if 'browser' in report:
            assert report['browser']['headless'] is False and report['browser']['gpu']['featureStatus'].get('webgl2',report['browser']['gpu']['featureStatus'].get('webgl'))=='enabled'
            assert not any(__import__('re').search(r'swiftshader|llvmpipe|softpipe|lavapipe|--disable-gpu(?:$|=)',a,__import__('re').I) for a in report['browser']['commandLine'])
            evidence=report.get('partial') or report['browserResult']['result'];assert 'Metal' in evidence['gpu']
            assert sha((reportfile.parent/report['screenshot']['path']).read_bytes())==report['screenshot']['sha256']
            assert sha((reportfile.parent/report['browserCoverage']['path']).read_bytes())==report['browserCoverage']['sha256']
            for blob in evidence['blobs']:
                compressed=(reportfile.parent/blob['path']).read_bytes();assert sha(compressed)==blob['gzipSha256']
                raw=gzip.decompress(compressed);assert len(raw)==blob['bytes'] and sha(raw)==blob['sha256']
            for served in report['servedFiles']:
                if served['path']=='/':continue
                source=next(s for s in report['sources'] if '/'+s['path']==served['path']);assert source['sha256']==served['sha256'] and source['bytes']==served['bytes']

coldraw=(unpacked/'cold/report.json').read_bytes();cold=json.loads(coldraw)
assert sha(coldraw)=='6d2f2b2dc62137e8e7d740d333f42ce6ebe52b4057d3e4cbbb1aa86c61206ced'
assert cold['status']=='passed' and cold['gitHead']==cold['cloneHead']==FROZEN and cold['statusBefore']==cold['statusAfter']=='' and cold['exitCode']==0
assert cold['receiptSha256']==receipts['cold']['sha256'] and cold['logSha256']==sha((unpacked/'cold/cold.log').read_bytes())
clone=Path(cold['clone']);assert git('rev-parse','HEAD').decode().strip()=='6e89fb7a25156136eb701dd8a4e475c563190ecb'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==FROZEN
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=clone,text=True)
for name,digest in json.loads((unpacked/'cold/receipt.json').read_text())['sources'].items():assert sha((clone/name).read_bytes())==digest,(name,'clone current')
predecessors=[];dependency_sources={}
for role in ['worker','verifier']:
    base=ROOT/'evidence/virgl-standard-packed-normalized-images'/role
    for n in ['manifest.json','records.json','recording.tar.gz']:assert (base/n).read_bytes()==git('show',BASE+':'+base.relative_to(ROOT).as_posix()+'/'+n)
    info,records,sources=reopen(base,carry_current=False,source_commit=BASE if role=='verifier' else None)
    predecessors.append(info)
    with tarfile.open(base/'recording.tar.gz','r:gz') as arc:
        for m in arc:
            if m.name in ['source/renderer/virgl-command/decoder.mjs','source/renderer/virgl-command/state.mjs'] or m.name.startswith('hot-generated/'):
                raw=arc.extractfile(m).read()
                if m.name.startswith('source/'):
                    name=m.name[7:];assert raw==git('show',BASE+':'+name);dependency_sources[name]=sha(raw)
                else:
                    name=m.name[len('hot-generated/'):];assert raw==(ROOT/name).read_bytes(),name
assert sum(p['members'] for p in predecessors)==42989
held=json.loads((unpacked/'hot/predecessor/authentication.json').read_text())
assert held==json.loads((unpacked/'cold/predecessor/authentication.json').read_text())
for source in held['unchanged']:
    raw=(ROOT/source['path']).read_bytes();assert raw==git('show',BASE+':'+source['path']) and len(raw)==source['bytes'] and sha(raw)==source['sha256']
assert len(held['unchanged'])==289
unchanged_git=git('diff','--name-only',BASE,FROZEN,'--','renderer/virgl-shader','renderer/virgl-command/resources.mjs','renderer/virgl-command/constant-domain.mjs','renderer/virgl-command/packed-normalized-images.mjs','crates','web','tools/guest').decode()
assert not unchanged_git
result=dict(status='passed',worker=winfo,receipts=receipts,cold=dict(sha256=sha(coldraw),clone=cold['clone'],scrubbedNames=cold['removedEnvironmentNames'],currentClonePristine=True),predecessors=predecessors,dependencySources=dependency_sources,unchangedSources=held['unchanged'],elapsedSeconds=time.time()-start)
(OUT/'authentication.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['unchangedSources']}))
