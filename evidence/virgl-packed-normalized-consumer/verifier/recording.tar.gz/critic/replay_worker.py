#!/usr/bin/env python3
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
for prefix in ['hot','cold']:
    origin=OUT/'unpacked'/prefix
    jobs=[('hardware-targets','pixels',False),('hardware-samples','samples',False),('historical','historical',False)]
    for seed in [362514859,2882400001,1629686191]:jobs.extend([(f'target-boundary-{seed}','boundaries',False),(f'sample-boundary-{seed}','samples',False)])
    jobs.extend([('fault-nonzero-attachment','pixels',True),('fault-completed-output','pixels',True),('fault-sample-plane','samples',True)])
    for name,kind,control in jobs:
        target=OUT/'rechecks'/prefix/name;target.mkdir(parents=True,exist_ok=True)
        for p in (origin/name).iterdir():
            if p.name=='report.json' or p.name.endswith('.bin.gz'):
                link=target/p.name
                if not link.exists():link.symlink_to(p.resolve())
        script=ROOT/('tools/virgl-multiple-color/pixels.py' if kind=='historical' else f'tools/virgl-packed-normalized-consumer/{kind}.py')
        command=['python3',str(script),str(target)]+(['--control'] if control else [])
        with (target/'independent.log').open('w') as log:result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
        assert result.returncode==0,(prefix,name,(target/'independent.log').read_text())
        audit=target/('pixel-audit.json' if kind in ['pixels','historical'] else 'sample-audit.json' if kind=='samples' else 'boundary-audit.json')
        data=json.loads(audit.read_text());assert data['status']==('refuted' if control else 'passed')
        records.append(dict(origin=prefix+'/'+name,reportSha256=sha(origin/name/'report.json'),command=command,status=data['status'],counts=data.get('counts'),audit=str(audit.relative_to(OUT)),auditSha256=sha(audit)))
        print(json.dumps(records[-1]),flush=True)
(OUT/'independent-recordings.json').write_text(json.dumps(dict(status='passed',jobs=records),indent=2)+'\n')
