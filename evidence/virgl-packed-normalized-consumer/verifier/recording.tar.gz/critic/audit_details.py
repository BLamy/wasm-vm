#!/usr/bin/env python3
import gzip,hashlib,json,re,struct,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools/virgl-packed-normalized-consumer'))
from pixels import NORMALIZED,packets
sha=lambda b:hashlib.sha256(b).hexdigest()
requests={};alpha_points=[];cache_points=[];controls=[];counts=dict(reports=0,requests=0,programKeys=0,implicitPixels=0)
for prefix in ['hot','cold']:
 for p in sorted((OUT/'unpacked'/prefix).glob('*/report.json')):
  report=json.loads(p.read_text());e=report.get('partial') or report.get('browserResult',{}).get('result')
  if not e or not e.get('runs') or p.parent.name=='historical':continue
  counts['reports']+=1;blobs={b['key']:b for b in e['blobs']}
  def load(ref):
   b=blobs[ref['key']];assert b['sha256']==ref['sha256'];data=(p.parent/b['path']).read_bytes();assert sha(data)==b['gzipSha256']
   raw=gzip.decompress(data);assert len(raw)==b['bytes'] and sha(raw)==b['sha256'];return raw
  def alpha(ref,fmt,point):
   d=NORMALIZED.get(fmt)
   if not d or not d['implicitAlpha']:return
   raw=load(ref)
   if d['guestPixelBytes']==4:
    field=d['rgbaFields'][3];maximum=2**field['bits']-1
    assert all((int.from_bytes(raw[a:a+4],'little')>>d['nativeOffsets'][3])&maximum==maximum for a in range(0,len(raw),4)),point
   else:assert all(raw[a]==255 for a in range(3,len(raw),4)),point
   counts['implicitPixels']+=len(raw)//4;alpha_points.append(dict(**point,pixels=len(raw)//4,sha256=ref['sha256']))
  for ri,run in enumerate(e['runs']):
   original_shaders=set()
   for hi,h in enumerate(run['history']):
    for op,kind,w,raw in packets(h['hex']):
     if op==1 and kind==4:original_shaders.add(raw[24:24+w[2]-1].decode('ascii'))
    dump=h['dump']
    if dump:
     assert dump['complete'] and all(n==0 for n in dump['dropped'].values())
     for program in dump['programs']:
      assert program['vertexTGSI'] in original_shaders and program['fragmentTGSI'] in original_shaders
      assert '|multiple-color-formats-v1:' in program['key'] or run.get('kind')=='historical-integer-blend-bypass'
      key=program['key'];assert sha(program['vertexESSL300'].encode()) and sha(program['fragmentESSL300'].encode())
      cache_points.append(dict(report=p.relative_to(OUT).as_posix(),run=ri,history=hi,generation=program['generation'],key=key,hash=program['hash']));counts['programKeys']+=1
   for qi,q in enumerate(run['requests']):
    request=q['request'];assert q['result']['ok']
    if q['method']=='stage':assert request['text'] in original_shaders
    else:assert request['vertexText'] in original_shaders and request['fragmentText'] in original_shaders
    stages=[q['result']] if q['method']=='stage' else [q['result']['vertex'],q['result']['fragment']]
    for stage in stages:assert stage['metadata']['profile']=='virgl-webgl2-standard-integer-image-gles3-v1'
    key=json.dumps(dict(method=q['method'],request=request),sort_keys=True,separators=(',',':'))
    if key in requests:assert requests[key]['result']==q['result'],'one actual C request may not return different bodies'
    else:requests[key]=dict(method=q['method'],request=request,result=q['result'],points=[])
    requests[key]['points'].append(dict(report=p.relative_to(OUT).as_posix(),run=ri,request=qi));counts['requests']+=1
   for fi in run['frames']:
    frame=e['frames'][fi]
    for target in frame.get('targets',[]):
     for level,ref in [(target['level'],target['native'])]+[(a['level'],a['native']) for a in target['planes']]:alpha(ref,target['metadata']['format'],dict(report=p.relative_to(OUT).as_posix(),run=ri,frame=fi,slot=target['slot'],level=level))
    for binding in frame.get('bindings',[]):
     for plane in binding['planes']:alpha(plane['native'],run['format'],dict(report=p.relative_to(OUT).as_posix(),run=ri,frame=fi,local=plane['local']))
   if report.get('fault')=='completed-output':
    frame=e['frames'][-1];target=frame['targets'][-1];assert target['slot']==3 and target['metadata']['format']==8
    before=load(frame['beforeSabotage']);after=load(target['native']);assert len(before)==len(after)==64
    assert int.from_bytes(after[:4],'little')==int.from_bytes(before[:4],'little')^1 and after[4:]==before[4:]
    original,sabotage=frame['originalCompletion'],frame['sabotageCompletion'];assert original['sync']!=sabotage['sync'] and original['sequence']<sabotage['sequence']
    upload=next(u for u in run['uploads'] if u['name']=='texSubImage2D' and u['sequence']>original['sequence']);assert load(upload['bytes'])==after
    sync=next(s for s in run['fenceObjects'] if s['id']==sabotage['sync']);assert original['sequence']<upload['sequence']<sync['createdSequence']<sabotage['sequence']
    read=next(r for r in run['readbacks'] if r['target']==target['texture'] and r['sequence']>sabotage['sequence'] and r['cpu']);assert read['completion']==sabotage and load(read['bytes'])==after
    expected=int(2<<30|959<<20|737<<10);assert int.from_bytes(before[:4],'little')==expected and before==before[:4]*16
    controls.append(dict(report=p.relative_to(OUT).as_posix(),frame=frame['historyIndex'],targetTexture=target['texture'],before=expected,after=expected^1,originalFence=original,sabotageFence=sabotage,uploadSequence=upload['sequence'],captureSequence=read['sequence'],beforeSha256=sha(before),afterSha256=sha(after)))
(OUT/'c-requests.json').write_text(json.dumps(dict(requests=list(requests.values())),indent=2)+'\n')
result=dict(status='passed',counts=counts,uniqueRequests=len(requests),physicalCanonicalAlpha=alpha_points,programKeys=cache_points,postCompletionPhysicalControls=controls)
(OUT/'recording-details.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status='passed',counts=counts,uniqueRequests=len(requests),postCompletionPhysicalControls=controls)))
