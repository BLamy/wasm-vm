import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {createVirglStandardIntegerImageShaderBridge} from '../../../renderer/virgl-shader/standard.mjs';
const output=path.dirname(fileURLToPath(import.meta.url)),input=JSON.parse(await fs.readFile(path.join(output,'c-requests-fresh.json'),'utf8'));
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const bridge=await createVirglStandardIntegerImageShaderBridge(),responses=[];
for(const [index,q]of input.requests.entries()){
 const actual=q.method==='stage'?bridge.translateImages(q.request):bridge.translatePairImages(q.request);
 assert.deepEqual(actual,q.result,'actual generated C/Wasm request '+index);
 responses.push({index,method:q.method,request:q.request,result:actual,sourcePoints:q.points,responseSha256:sha(JSON.stringify(actual))});
}
const generated={};
for(const name of ['virgl-shader.mjs','virgl-shader.wasm'])generated[name]=sha(await fs.readFile(path.join(output,'../../../renderer/virgl-shader/build/wasm',name)));
const result={status:'passed',requests:responses.length,recordedResponses:responses.reduce((sum,r)=>sum+r.sourcePoints.length,0),generated,responses};
await fs.writeFile(path.join(output,'c-replay-fresh.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({status:result.status,requests:result.requests,recordedResponses:result.recordedResponses,generated}));
