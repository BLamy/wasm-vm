#!/usr/bin/env python3
import hashlib,json,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
load=lambda n:json.loads((OUT/n).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['authentication.json','independent-recordings.json','coverage-audit.json','recording-details.json','c-replay.json','c-replay-fresh.json','wire-replay.json','fresh-runs.json','fresh-custody.json']:assert load(name)['status']=='passed'
assert len(load('independent-recordings.json')['jobs'])==24 and len(load('fresh-runs.json')['records'])==12
assert load('c-replay.json')['requests']==46 and load('c-replay-fresh.json')['requests']==19
promoted=ROOT/'target/evidence/virgl-packed-normalized-consumer-critic-promoted';assert json.loads((promoted/'critic-audit.json').read_text())['status']=='passed'
assert json.loads((promoted/'pixel-audit.json').read_text())['counts']['frames']==30
points={
'P0':['authentication.json'],
'P1':['wire-replay.json','fresh-novel-3242072501/critic-audit.json','fresh-boundaries-3242072501/boundary-audit.json'],
'P2':['rechecks/hot/hardware-targets/pixel-audit.json','rechecks/cold/hardware-targets/pixel-audit.json','recording-details.json'],
'P3':['rechecks/hot/hardware-samples/sample-audit.json','rechecks/cold/hardware-samples/sample-audit.json','c-replay.json','c-replay-fresh.json'],
'P4':['rechecks/hot/hardware-targets/pixel-audit.json','rechecks/hot/hardware-samples/sample-audit.json','fresh-novel-3242072501/critic-audit.json'],
'P5':['independent-recordings.json','fresh-runs.json','fresh-custody.json'],
'P6':['coverage-audit.json'],
'P7':['physical-control.json','fresh-fault-completed-output/pixel-audit.json','fresh-fault-nonzero-attachment/pixel-audit.json','fresh-fault-sample-plane/sample-audit.json'],
'P8':['fresh-attack-plan.json','fresh-novel-3242072501/critic-audit.json','fresh-novel-2113343427/critic-audit.json','fresh-novel-375936213/critic-audit.json','physical-control.json']}
observations={
'P0':'83,780 complete worker members, 802 recorded source members, both receipts, the exact-head pristine cold clone, 42,989 D35 members and 289 unchanged compiler/storage sources authenticate.',
'P1':'39 original streams replay as D35 refusals through all 11 old decoders; current selected admission succeeds. Exact native-equivalent alias surface/view refusals apply zero commands and mutate no native state/storage/ownership; only an owned completion fence is permitted.',
'P2':'Both whole-original-wire inverses match all 181 target cases, 724 frames, 2,740 targets, 245,248 components and 4,924 planes per recording. Direct additional native alpha audit checks 114,828 implicit pixels.',
'P3':'Both full sampler inverses match 104 cases, 312 frames, 18,720 output and 46,488 retained-range components per recording. 46 unique worker requests / 2,898 responses and 19 unique fresh requests / 669 responses re-execute exactly in unchanged actual C/Wasm.',
'P4':'Per recording, 54,800,000 complete target and 6,240,000 sampler public bytes match independent original layout/packing. Each novel run checks 480,000 boxed backing bytes and 10,125 physical canonical-alpha pixels; untouched levels/padding stay isolated.',
'P5':'All worker schedule sets and three fresh schedules pass native ownership, original/retained generations, cache shape/context reuse, range refresh, complete/cancel/disposal, exact physical fences and once-only retirement.',
'P6':'Each recording independently derives 179 executed smallest governing V8 partitions and 14 individually mapped exact historical operands. No new normalized operand is waived; no unaccounted partition remains.',
'P7':'Fresh physical wrong target/sample controls refute their unchanged independent inverses. Native COLOR3 word changes 1477311616 to 1477311617 after fence30 seq1214, upload seq1220, distinct fence31 seq1227, CPU capture seq1231; independent red field is 129 against predicted 128 and complete mip/public backing is refuted.',
'P8':'Three mixed-target odd-mip alpha-mask/alias/boxed-read runs and the promoted make target pass. Exact private stage/pair key custody contains normalized profile at state.mjs:410/423. The same full inverse catches the physical post-completion corruption.'}
rows=[]
for p in load('predictions.json')['predictions']:
 rows.append(dict(id=p['id'],status='HELD',prediction=p['prediction'],observation=observations[p['id']],points=[dict(path=n,sha256=sha(OUT/n)) for n in points[p['id']]],**({'scopeRefinement':'fresh-attack-plan.json','harnessCorrection':'harness-correction.json'} if p['id']=='P8' else {})))
verdict=dict(firstLine='VERDICT: verified',task='E6-T11d36',createdAt=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),workerSubmissionHead='6e89fb7a25156136eb701dd8a4e475c563190ecb',runtimeRecordedHead='001f3d42f3d55f2c225af65a81996d0c8b9d087c',predecessor='3e5e41429aadc9acbe68fade926d2763d1e2a356',predictionsSha256=sha(OUT/'predictions.json'),results=rows,findings=[],runtimeEdited=False,pristineCloneRepeated=False,scope='isolated host-selected original packed UNORM consumer only',guestExecution=False,productionNegotiation=False,productionDrawAuthority=False,suite=dict(command='make verify-E6-T11d36-adversarial',test='renderer/virgl-command/tests/standard-packed-normalized-consumer-critic.mjs',inverse='tools/virgl-packed-normalized-consumer/critic.py',reportSha256=sha(promoted/'report.json'),pixelAuditSha256=sha(promoted/'pixel-audit.json'),criticAuditSha256=sha(promoted/'critic-audit.json')),leases=dict(heldUntilFinalCommit=['Git','index','shared-worktree','compiler','Node','browser','headed Chrome','GPU'],remainingOwnedBrowserProcesses=[]))
(OUT/'verdict.json').write_text(json.dumps(verdict,indent=2)+'\n')
with (OUT/'citations.jsonl').open('w') as f:
 for row in rows:f.write(json.dumps(row)+'\n')
print(json.dumps(dict(verdict=verdict['firstLine'],held=len(rows),findings=0,promotedReportSha256=verdict['suite']['reportSha256'])))
