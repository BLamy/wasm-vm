#!/usr/bin/env python3
import hashlib,json,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
seeds=[3242072501,2113343427,375936213];jobs=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for seed in seeds:
 for mode,oracle in [('boundaries','boundaries'),('sample-boundaries','samples')]:jobs.append(dict(name=f'fresh-{mode}-{seed}',seed=seed,mode=mode,oracle=oracle,novel=False,control=False))
 if seed!=seeds[0]:jobs.append(dict(name=f'fresh-novel-{seed}',seed=seed,mode='matrix',oracle='critic',novel=True,control=False))
for fault,mode,oracle,novel in [('nonzero-attachment','matrix','pixels',False),('sample-plane','samples','samples',False),('completed-output','matrix','critic',True)]:jobs.append(dict(name='fresh-fault-'+fault,seed=seeds[2],mode=mode,oracle=oracle,novel=novel,control=True,fault=fault))
records=[]
for job in jobs:
 out=OUT/job['name'];log=OUT/(job['name']+'.log');runner='tools/verify-virgl-standard-packed-normalized-consumer'+('-critic' if job['novel'] else '')+'.mjs'
 command=['node',runner,'--output',str(out),'--seed',str(job['seed']),'--mode',job['mode']]+(['--fault',job['fault']] if job['control'] else [])
 with log.open('w') as sink:result=subprocess.run(command,cwd=ROOT,stdout=sink,stderr=subprocess.STDOUT,timeout=300)
 assert (result.returncode!=0)==job['control'],(job,log.read_text())
 oracle=['python3',f'tools/virgl-packed-normalized-consumer/{job["oracle"]}.py',str(out)]+(['--control'] if job['control'] else [])
 with (out/'independent.log').open('w') as sink:result=subprocess.run(oracle,cwd=ROOT,stdout=sink,stderr=subprocess.STDOUT)
 assert result.returncode==0,(job,(out/'independent.log').read_text())
 report=json.loads((out/'report.json').read_text());assert report['browserErrors']==dict(console=[],page=[],requests=[])
 records.append(dict(**job,command=command,oracleCommand=oracle,reportSha256=sha(out/'report.json'),browserStatus=report['status'],complete=True))
 print(json.dumps(records[-1]),flush=True)
first=OUT/'fresh-novel-3242072501';records.insert(0,dict(name=first.name,seed=seeds[0],mode='matrix',oracle='critic',novel=True,control=False,reportSha256=sha(first/'report.json'),browserStatus='passed',complete=True))
(OUT/'fresh-runs.json').write_text(json.dumps(dict(status='passed',records=records),indent=2)+'\n')
