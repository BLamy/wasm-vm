#!/usr/bin/env python3
import gzip,hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest();results=[];requests={};profiles=[]
reports=[p for p in OUT.glob('fresh-*/report.json')]+[OUT/'novel-harness-v0/report.json',ROOT/'target/evidence/virgl-packed-normalized-consumer-critic-promoted/report.json']
for file in reports:
 report=json.loads(file.read_text());e=report.get('partial') or report['browserResult']['result'];assert 'Metal' in e['gpu'] and report['browser']['headless'] is False
 assert report['browserErrors']==dict(console=[],page=[],requests=[]) and report['gitHead']=='6e89fb7a25156136eb701dd8a4e475c563190ecb'
 assert sha(Path(report['browser']['executable']).read_bytes())==report['browser']['sha256']
 assert report['browser']['gpu']['featureStatus'].get('webgl2',report['browser']['gpu']['featureStatus'].get('webgl'))=='enabled'
 assert not any(re.search(r'swiftshader|llvmpipe|softpipe|lavapipe|--disable-gpu(?:$|=)',a,re.I) for a in report['browser']['commandLine'])
 profiles.extend(a.split('=',1)[1] for a in report['browser']['commandLine'] if a.startswith('--user-data-dir='))
 for source in report['sources']:
  raw=(ROOT/source['path']).read_bytes()
  if sha(raw)!=source['sha256']:
   assert file==OUT/'novel-harness-v0/report.json' and source['path']=='renderer/virgl-command/tests/standard-packed-normalized-consumer-critic.mjs'
   raw=(OUT/'iterations/critic-v0.mjs').read_bytes()
  assert len(raw)==source['bytes'] and sha(raw)==source['sha256'],source['path']
 for asset in ['screenshot','browserCoverage']:assert sha((file.parent/report[asset]['path']).read_bytes())==report[asset]['sha256']
 for script in json.loads((file.parent/report['browserCoverage']['path']).read_text())['scripts']:
  source=next(s for s in report['sources'] if s['path']==script['source']);assert script['sha256']==source['sha256']
 by={b['key']:b for b in e['blobs']};assert len(by)==len(e['blobs'])
 for b in e['blobs']:
  compressed=(file.parent/b['path']).read_bytes();assert sha(compressed)==b['gzipSha256'];raw=gzip.decompress(compressed);assert len(raw)==b['bytes'] and sha(raw)==b['sha256']
 def load(ref):
  b=by[ref['key']];assert b['sha256']==ref['sha256'];return gzip.decompress((file.parent/b['path']).read_bytes())
 for ri,run in enumerate(e['runs']):
  for qi,q in enumerate(run['requests']):
   key=json.dumps(dict(method=q['method'],request=q['request']),sort_keys=True,separators=(',',':'))
   if key in requests:assert requests[key]['result']==q['result']
   else:requests[key]=dict(method=q['method'],request=q['request'],result=q['result'],points=[])
   requests[key]['points'].append(dict(report=file.relative_to(ROOT).as_posix(),run=ri,request=qi))
 if file.parent.name=='fresh-fault-completed-output':
  run=e['runs'][0];frame=e['frames'][-1];target=frame['targets'][-1];before=load(frame['beforeSabotage']);after=load(target['native']);assert len(before)==len(after)==128
  assert int.from_bytes(before[:4],'little')==1477311616 and int.from_bytes(after[:4],'little')==1477311617 and before[4:]==after[4:]
  original,sabotage=frame['originalCompletion'],frame['sabotageCompletion'];assert original['sync']!=sabotage['sync']
  upload=next(u for u in run['uploads'] if u['name']=='texSubImage2D' and u['sequence']>original['sequence']);assert upload['texture']==target['texture'] and load(upload['bytes'])==after
  sync=next(s for s in run['fenceObjects'] if s['id']==sabotage['sync']);assert original['sequence']<upload['sequence']<sync['createdSequence']<sabotage['sequence']
  capture=next(r for r in run['readbacks'] if r['target']==target['texture'] and r['sequence']>sabotage['sequence'] and r['cpu']);assert capture['completion']==sabotage and load(capture['bytes'])==after
  control=dict(report=file.relative_to(ROOT).as_posix(),frame=4,targetTexture=target['texture'],before=1477311616,after=1477311617,originalFence=original,uploadSequence=upload['sequence'],sabotageFence=sabotage,captureSequence=capture['sequence'],beforeSha256=sha(before),afterSha256=sha(after),nativeBlob=target['native'])
  (OUT/'physical-control.json').write_text(json.dumps(control,indent=2)+'\n')
 results.append(dict(report=file.relative_to(ROOT).as_posix(),status=report['status'],sha256=sha(file.read_bytes()),runs=len(e['runs']),frames=len(e['frames']),blobs=len(by),sources=len(report['sources']),seed=e['seed']))
for name in ['renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs','renderer/virgl-command/resources.mjs','renderer/virgl-command/packed-normalized-images.mjs','renderer/virgl-shader/bridge.c','renderer/virgl-shader/standard.mjs']:
 assert (ROOT/name).read_bytes()==subprocess.check_output(['git','show','001f3d42f3d55f2c225af65a81996d0c8b9d087c:'+name],cwd=ROOT)
(OUT/'c-requests-fresh.json').write_text(json.dumps(dict(requests=list(requests.values())),indent=2)+'\n')
processes=subprocess.check_output(['ps','-axo','pid=,args='],text=True).splitlines();remaining=[line for line in processes if any(profile in line for profile in profiles) and not line.lstrip().startswith(str(__import__('os').getpid()))]
assert not remaining,'owned private browser process survived its recorded run'
result=dict(status='passed',reports=results,freshUniqueCompilerRequests=len(requests),physicalControl=control,privateBrowserProfiles=sorted(set(profiles)),remainingOwnedBrowserProcesses=[])
(OUT/'fresh-custody.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status='passed',reports=len(results),freshUniqueCompilerRequests=len(requests),physicalControl=control,remainingOwnedBrowserProcesses=[])))
