#!/usr/bin/env python3
import gzip,hashlib,json,subprocess,tarfile
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((OUT/'verdict.json').read_text())['firstLine']=='VERDICT: verified'
members={}
for p in OUT.rglob('*'):
 if not p.is_file() or p.is_symlink():continue
 name=p.relative_to(OUT).as_posix()
 if name.split('/')[0] in ['unpacked','source-current','__pycache__'] or '__pycache__' in p.parts:continue
 if name in ['manifest.json','records.json','recording.tar.gz','seal.log']:continue
 members['critic/'+name]=p
promoted=ROOT/'target/evidence/virgl-packed-normalized-consumer-critic-promoted'
for p in promoted.rglob('*'):
 if p.is_file():members['promoted/'+p.relative_to(promoted).as_posix()]=p
sources={'Makefile','AGENTS.md','web/package.json','web/package-lock.json','tools/check_task_policy.py','tools/build_queue.py','tools/verify-virgl-standard-packed-normalized-consumer-critic.mjs','renderer/virgl-command/tests/standard-packed-normalized-consumer-critic.mjs'}
for reportfile in [*OUT.glob('fresh-*/report.json'),promoted/'report.json']:
 for s in json.loads(reportfile.read_text())['sources']:sources.add(s['path'])
sources.update(r['path'] for r in json.loads((OUT/'authentication.json').read_text())['unchangedSources'])
sources.update(subprocess.check_output(['git','ls-files','tools/virgl-packed-normalized-consumer','renderer/virgl-shader'],cwd=ROOT,text=True).splitlines())
sources.add('tools/virgl-packed-normalized-consumer/critic.py')
for name in sorted(sources):
 p=ROOT/name;assert p.is_file();members['source-current/'+name]=p
# Worker/dependency recordings remain whole, independently authenticated, committed seals.
# Carry their full member indexes and digests; duplicate neither bulk tar nor extracted data.
auth=json.loads((OUT/'authentication.json').read_text())
for info in [auth['worker']]+auth['predecessors']:
 for n in ['manifest.json','records.json']:
  p=ROOT/info['path']/n;members['carried/'+info['path']+'/'+n]=p
records=[dict(path=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(members.items())]
index=dict(schema='D36-fresh-critic-complete-index-v1',task='E6-T11d36',runtimeHead='001f3d42f3d55f2c225af65a81996d0c8b9d087c',workerSubmissionHead='6e89fb7a25156136eb701dd8a4e475c563190ecb',records=records)
(OUT/'records.json').write_text(json.dumps(index,indent=2)+'\n')
with (OUT/'recording.tar.gz').open('wb') as sink:
 with gzip.GzipFile(fileobj=sink,filename='',mtime=0,compresslevel=6) as compressed:
  with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as archive:
   for r in records:
    p=members[r['path']];assert sha(p)==r['sha256']
    info=tarfile.TarInfo(r['path']);info.size=r['bytes'];info.mode=0o644;info.mtime=0
    with p.open('rb') as source:archive.addfile(info,source)
wanted={r['path']:r for r in records};seen=set();total=0
with tarfile.open(OUT/'recording.tar.gz','r|gz') as archive:
 for m in archive:
  path=PurePosixPath(m.name);assert m.isfile() and not path.is_absolute() and '..' not in path.parts and m.name in wanted and m.name not in seen
  raw=archive.extractfile(m).read();r=wanted[m.name];assert len(raw)==m.size==r['bytes'] and hashlib.sha256(raw).hexdigest()==r['sha256']
  seen.add(m.name);total+=len(raw)
assert seen==set(wanted)
manifest=dict(schema='D36-fresh-adversarial-critic-seal-v1',task='E6-T11d36',verdict='verified',runtimeHead=index['runtimeHead'],workerSubmissionHead=index['workerSubmissionHead'],records=len(records),reopenedMembers=len(seen),sourceClosureIncluded=True,uncompressedBytes=total,archiveBytes=(OUT/'recording.tar.gz').stat().st_size,archiveSha256=sha(OUT/'recording.tar.gz'),recordIndexSha256=sha(OUT/'records.json'),predictionsSha256=sha(OUT/'predictions.json'),verdictSha256=sha(OUT/'verdict.json'),carriedWorkerSeal=auth['worker'],carriedPredecessors=auth['predecessors'],freshRecordingsIncluded=True,pristineCloneRepeated=False,runtimeEdited=False,earlierHarnessFailureIncluded='critic/novel-harness-v0/report.json',scope='isolated host-selected original packed UNORM consumer',guestExecution=False,productionNegotiation=False,productionDrawAuthority=False)
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:manifest[k] for k in ['verdict','records','reopenedMembers','uncompressedBytes','archiveBytes','archiveSha256','recordIndexSha256','verdictSha256']}))
