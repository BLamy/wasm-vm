#!/usr/bin/env python3
import difflib,hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
BASE='3e5e41429aadc9acbe68fade926d2763d1e2a356';HEAD='001f3d42f3d55f2c225af65a81996d0c8b9d087c'
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=['renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs']
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
added={};name=None
for row in git('diff','--unified=0',BASE,HEAD,'--',*paths).decode().splitlines():
    if row.startswith('+++ b/'):name=row[6:]
    elif row.startswith('@@'):line=int(re.search(r'\+(\d+)',row)[1])
    elif row.startswith('+') and name:added.setdefault(name,[]).append(line);line+=1
    elif row.startswith(' '):line+=1
waivers={(r['source'],r['startOffset'],r['endOffset']):r for r in json.loads((ROOT/'tools/virgl-packed-normalized-consumer/coverage-waivers.json').read_text())['waivers']}
auth=json.loads((OUT/'authentication.json').read_text());outputs=[]
for prefix in ['hot','cold']:
    directory=OUT/'unpacked'/prefix;scripts=[]
    for p in directory.rglob('browser-coverage.json'):
        if any(part.startswith('fault-') for part in p.relative_to(directory).parts):continue
        for row in json.loads(p.read_text())['scripts']:
            if row['source'] in paths:scripts.append(dict(record=p.relative_to(OUT).as_posix(),**row))
    for p in (directory/'node-coverage').glob('*.json'):
        for script in json.loads(p.read_text())['result']:
            for name in paths:
                if script['url'].endswith('/'+name):scripts.append(dict(record=p.relative_to(OUT).as_posix(),source=name,sha256=sha(git('show',HEAD+':'+name)),coverage=script))
    partitions=[]
    for name,lines in added.items():
        raw=git('show',HEAD+':'+name);text=raw.decode();rows=text.splitlines(keepends=True);offsets=[0]
        for row in rows:offsets.append(offsets[-1]+len(row.encode('utf-16-le'))//2)
        selected=[s for s in scripts if s['source']==name]
        assert selected and all(s['sha256']==sha(raw) for s in selected)
        oldraw=git('show',BASE+':'+name);assert sha(oldraw)==auth['dependencySources'][name]
        oldrows=oldraw.decode().splitlines(keepends=True);outer=difflib.SequenceMatcher(None,oldrows,rows,autojunk=False).get_opcodes()
        for line in lines:
            start,end=offsets[line-1],offsets[line];points={start,end}
            for script in selected:
                for fn in script['coverage']['functions']:
                    for r in fn['ranges']:
                        if start<r['startOffset']<end:points.add(r['startOffset'])
                        if start<r['endOffset']<end:points.add(r['endOffset'])
            points=sorted(points)
            for a,b in zip(points,points[1:]):
                governing=[]
                for script in selected:
                    ranges=[r for fn in script['coverage']['functions'] for r in fn['ranges'] if r['startOffset']<=a and b<=r['endOffset']]
                    if ranges:governing.append(dict(record=script['record'],**min(ranges,key=lambda r:r['endOffset']-r['startOffset'])))
                rawpart=text.encode('utf-16-le')[a*2:b*2].decode('utf-16-le')
                p=dict(source=name,line=line,startOffset=a,endOffset=b,text=rawpart,maxCount=max((r['count'] for r in governing),default=0),governing=governing)
                if p['maxCount']==0:
                    w=waivers.get((name,a,b));assert w and w['text']==rawpart and sha(rawpart.encode())==w['sha256'] and 'normalized' not in rawpart.lower()
                    assert w['predecessorSourceSha256']==sha(oldraw)
                    block=next(o for o in outer if o[3]<=line-1<o[4]);oldcandidates=range(block[1],block[2]);line_text=rows[line-1];assert line_text.isascii()
                    mapped=[]
                    for oldline in oldcandidates:
                        oldtext=oldrows[oldline];assert oldtext.isascii()
                        for equal in difflib.SequenceMatcher(None,oldtext,line_text,autojunk=False).get_matching_blocks():
                            rel=a-start;relend=b-start
                            if equal.b<=rel and relend<=equal.b+equal.size:
                                oldcol=equal.a+rel-equal.b
                                if oldtext[oldcol:oldcol+(b-a)]==rawpart:mapped.append(dict(line=oldline+1,startColumn=oldcol+1,endColumn=oldcol+1+b-a,text=rawpart))
                    assert mapped,(name,line,rawpart,'waived operand is not an unchanged corresponding predecessor operand')
                    p['classification']='waived-historical-exact-operand';p['predecessorMatches']=mapped;p['predecessorSourceSha256']=sha(oldraw)
                else:p['classification']='executed'
                partitions.append(p)
    result=dict(prefix=prefix,positive=sum(p['maxCount']>0 for p in partitions),waived=sum(p['maxCount']==0 for p in partitions),unaccounted=[],partitions=partitions)
    assert result['positive']==179 and result['waived']==14
    worker=json.loads((directory/'coverage-audit.json').read_text());assert worker['positive']==result['positive'] and len(worker['waived'])==result['waived'] and not worker['zero']
    assert [(p['source'],p['line'],p['startOffset'],p['endOffset'],p['maxCount']) for p in worker['partitions']]==[(p['source'],p['line'],p['startOffset'],p['endOffset'],p['maxCount']) for p in partitions]
    outputs.append(result)
(OUT/'coverage-audit.json').write_text(json.dumps(dict(status='passed',independentlyDerived=True,predecessor=BASE,runtimeHead=HEAD,results=outputs),indent=2)+'\n')
print(json.dumps(dict(status='passed',results=[{k:r[k] for k in ['prefix','positive','waived','unaccounted']} for r in outputs])))
