import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
import * as prior from './prior-source/renderer/virgl-command/decoder.mjs';
import * as current from '../../../renderer/virgl-command/decoder.mjs';
const gap=JSON.parse(await fs.readFile('evidence/virgl-production-readiness/standard-packed-normalized-consumer-gap.json','utf8')),rows=[];
assert.equal(gap.records.length,39);assert.equal(gap.gitHead,'3e5e41429aadc9acbe68fade926d2763d1e2a356');
const decoders=Object.entries(prior).filter(([name])=>/^decode.*Submission$/.test(name));
for(const row of gap.records){
 const bytes=Uint8Array.from(Buffer.from(row.hex,'hex'));
 const actual=prior.decodeStandardMultipleColorSubmission(bytes);assert.deepEqual(actual,row.result);
 for(const [name,fn]of decoders)assert.equal(fn(bytes).ok,false,'D35 original refusal '+name);
 const admitted=current.decodeStandardPackedNormalizedImageSubmission(bytes);assert.equal(admitted.ok,true);assert.equal(admitted.profile,current.STANDARD_PACKED_NORMALIZED_IMAGE_PROFILE);
 for(const [name]of decoders)assert.equal(current[name](bytes).ok,false,'old authority remains closed '+name);
 rows.push({...row,actual,selected:admitted,priorDecoders:decoders.map(([n])=>n),sha256:createHash('sha256').update(bytes).digest('hex')});
}
const result={status:'passed',rows,recordedPrerequisiteSha256:createHash('sha256').update(await fs.readFile('evidence/virgl-production-readiness/standard-packed-normalized-consumer-gap.json')).digest('hex')};
await fs.writeFile('evidence/virgl-packed-normalized-consumer/verifier/wire-replay.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({status:'passed',originalRefusals:rows.length,oldEntryPoints:decoders.length,priorHead:gap.gitHead}));
