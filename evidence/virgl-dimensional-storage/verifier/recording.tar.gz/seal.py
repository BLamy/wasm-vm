#!/usr/bin/env python3
"""Seal complete critic artifacts and independently reopen every archive member."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
out=Path(__file__).resolve().parent;repo=out.parents[2]
sha=lambda b:hashlib.sha256(b).hexdigest()
excluded={'manifest.json','records.json','recording.tar.gz'}
files={str(p.relative_to(out)):p for p in out.rglob('*') if p.is_file() and str(p.relative_to(out)) not in excluded}
assert not (out/'manifest.json').exists()
rows=[{'path':name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for name,p in sorted(files.items())]
index={'schema':'dimensional-storage-critic-index-v1','task':'E6-T11d55','submissionHead':'d9e58259ec36a2bb0d7fa3fa5a1dcf8f442313a0','runtimeHead':'bae5df1f1973e93d331bc7662b3ce89bbc1c98ef','records':rows}
raw=(json.dumps(index,indent=2)+'\n').encode();(out/'records.json').write_bytes(raw)
archive=out/'recording.tar.gz'
with archive.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as zipped,tarfile.open(fileobj=zipped,mode='w') as packed:
 for row in rows:
  body=files[row['path']].read_bytes();info=tarfile.TarInfo(row['path']);info.size,info.mode,info.mtime=len(body),0o644,0
  packed.addfile(info,io.BytesIO(body))
with tarfile.open(archive,'r:gz') as packed:
 members=packed.getmembers();assert len(members)==len(rows)
 for m,row in zip(members,rows):
  assert m.isfile() and m.name==row['path'];body=packed.extractfile(m).read()
  assert len(body)==row['bytes'] and sha(body)==row['sha256']
manifest={'schema':'dimensional-storage-critic-seal-v1','task':'E6-T11d55','verdict':'verified',
 'submissionHead':index['submissionHead'],'runtimeHead':index['runtimeHead'],'records':len(rows),'reopenedMembers':len(rows),
 'recordIndexSha256':sha(raw),'archiveSha256':sha(archive.read_bytes()),'archiveBytes':archive.stat().st_size,
 'workerManifestSha256':'15815d6dc767934fbb4e5fbd493c1d927edc622d6ceb1833d6d9eac062c6e8a1',
 'dependencySeals':json.loads((out/'authentication.json').read_bytes())['seals'][1:],
 'allPredictionsHeld':True,'guestExecution':False,'productionAuthority':False,'publicationVerified':True}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'manifestSha256':sha((out/'manifest.json').read_bytes()),**{k:v for k,v in manifest.items() if k!='dependencySeals'}}))
