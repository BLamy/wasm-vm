#!/usr/bin/env python3
"""Critic checks native outputs, every refusal, novel literal bytes, and full custody."""
from pathlib import Path
import hashlib,json,re,struct,subprocess,shutil
repo=Path(__file__).resolve().parents[3];out=Path(__file__).resolve().parent
worker=repo/'target/evidence/d55-critic-worker-unpacked/cold/recording'
sha=lambda b:hashlib.sha256(b).hexdigest()
pins=[];points=[];boundaries=[]
def read(path):
 raw=path.read_bytes();return json.loads(raw),raw

def pin_body(path,pin):
 raw=path.read_bytes();assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256'],str(path)
 return raw

def native_line(text,sequence):
 match=re.search(r'"sequence": '+str(sequence)+r'\s*,',text);assert match
 return text[:match.start()].count('\n')+1

for tag,directory in [('worker',worker/'hardware'),('fresh',out/'fresh-hardware'),('novel',out/'novel-hardware')]:
 report,raw=read(directory/'report.json');r=report['browserResult']['result'];text=raw.decode();calls=r['nativeCalls']
 assert report['status']==report['browserResult']['status']==r['status']=='passed'
 assert report['browserErrors']=={'console':[],'page':[],'requests':[]}
 assert not report['productionAuthority'] and not report['actualLinuxGuest'] and not r['productionAuthority']
 assert 'Metal' in json.dumps(report['browser']['gpu'])
 assert report['browser']['gpu']['featureStatus'][report['browser']['webglFeature']]=='enabled'
 assert not any(re.search(r'swiftshader|llvmpipe|softpipe|lavapipe|--disable-gpu(?:$|=)',a,re.I) for a in report['browser']['commandLine'])
 for pin in report['sources']:
  body=pin_body(directory/'source'/pin['path'],pin)
  assert body==(repo/pin['path']).read_bytes(),pin['path']
 for pin in report['servedFiles']:
  if pin['path']=='/':continue
  body=pin_body(directory/'source'/pin['path'].lstrip('/'),pin)
  assert body==(repo/pin['path'].lstrip('/')).read_bytes()
 pin_body(directory/report['screenshot']['path'],{'bytes':(directory/report['screenshot']['path']).stat().st_size,'sha256':report['screenshot']['sha256']})
 live=set()
 for i,c in enumerate(calls):
  assert c['sequence']==i
  if (c['name'].startswith('create') or c['name']=='fenceSync') and c['result'] is not None:
   id_=c['result']['object'];assert id_ not in live;live.add(id_)
  if c['name'].startswith('delete') and c['before'][0] is not None:
   id_=c['before'][0]['object'];assert id_ in live;live.remove(id_)
 assert not live
 native_limits={c['before'][0]:c['result'] for c in calls if c['name']=='getParameter' and c['before'][0] in [3379,32883,34076,35071]}
 assert native_limits=={3379:16384,32883:2048,34076:16384,35071:2048}
 pins.append({'kind':tag,'report':str(directory/'report.json'),'sha256':sha(raw),'nativeCalls':len(calls),'terminalNativeObjects':len(live),'nativeLimits':native_limits})
 if tag!='novel':
  for run_index,run in enumerate(r['runs']):
   m=run['metadata'];t=m['target'];cost={3:448,4:720,7:504}[t];assert run['cost']==cost
   assert run['beforeReuse']['budgets']['gpuBytes']==cost
   assert run['final']['budgets']=={k:0 for k in run['final']['budgets']}
   previous=run['nativeCallsStart']
   for observation_index,o in enumerate(run['observations']):
    interval=calls[previous:o['nativeCallsEnd']];previous=o['nativeCallsEnd']
    if 'label' not in o:continue
    output=[c for c in interval if c['name']=='getBufferSubData']
    assert len(output)==1
    actual=bytes.fromhex(output[0]['after'][2]['bytes']);assert actual==bytes.fromhex(o['actual'])==bytes.fromhex(o['expected'])
    points.append({'kind':tag,'run':run_index,'observation':observation_index,'target':t,'seed':run['seed'],'level':o['level'],'label':o['label'],
     'publicEnd':o['layout']['requiredEnd'],'denseBytes':len(actual),'denseSha256':sha(actual),'nativeCall':output[0]['sequence'],
     'report':str(directory/'report.json'),'line':native_line(text,output[0]['sequence']),'reportSha256':sha(raw)})
  assert len(r['boundaries'])==146 and len(r['faults'])==15
  for i,b in enumerate(r['boundaries']):
   name=b['name']
   if name=='role-hint':
    m=b['input'];resource=b['resource'];assert all(resource[k]==v for k,v in m.items())
    assert resource['byteLength']==resource['gpuByteLength']=={3:448,4:720,7:504}[m['target']]
    assert m['bind']&10 in [2,8,10] and m['bind']&~(10|262144|1048576)==0
   elif name=='actual-limit-neighbor':
    assert b['limit'] in [2048,16384]
    if b['input']['target']==4:assert not b['result']['ok']
    else:assert b['result']['ok']
   elif name=='exact-layout':
    assert b['backingBytes']==631 and b['result']['requiredEnd']==631 and b['result']['footprintBytes']==626 and b['result']['tightBytes']==420
   elif name in ['short-layout','transfer-budget','backend-qualification']:assert not b['result']['ok']
   elif name=='historical-decoder':
    assert b['result']['ok'] and not b['overflow']['ok'] and b['overflow']['error']['message']=='Transfer row arithmetic overflows u32.'
   elif name=='decoder-boundary':assert not b['historical']['ok']
   elif name=='inline-decode':assert not b['result']['ok']
   else:
    assert not b['result']['ok'] and b['state']==b['after'],(name,b)
   boundaries.append({'kind':tag,'index':i,'name':name,'result':b.get('result'), 'nativeCallsEnd':b.get('nativeCallsEnd')})
  assert {f['phase'] for f in r['faults']}=={'allocate','upload','sync-read','pbo-read','pending-dispose'}
 else:
  partial=[p for p in r['points'] if p['kind']=='partial-final-layer'];assert len(partial)==30
  assert {(p['seed'],p['metadata']['target'],p['level']) for p in partial}=={(seed,t,level) for seed in [38197,115937,219173] for t,count in [(3,4),(4,3),(7,3)] for level in range(count)}
  for i,p in enumerate(partial):
   m=p['metadata'];t=m['target'];level=p['level'];dims=p['dimensions'];box=p['box'];seed=p['seed'];w,h,layers=dims
   literal={3:[[7,5,9],[3,2,4],[1,1,2],[1,1,1]],4:[[7,7,6],[3,3,6],[1,1,6]],7:[[7,5,9],[3,2,9],[1,1,9]]}[t][level]
   assert dims==literal and box['z']+box['depth']==layers
   pattern=lambda x,y,z,lane:(seed+t*37+level*41+z*47+y*23+x*19+lane*61)&255
   source=bytes(pattern(x,y,z,lane) for z in range(layers) for y in range(h) for x in range(w) for lane in range(4))
   expected=bytes(pattern(x+box['x'],y+box['y'],z+box['z'],lane) for z in range(box['depth']) for y in range(box['height']) for x in range(box['width']) for lane in range(4))
   assert bytes.fromhex(p['nativeSource'])==source and bytes.fromhex(p['expected'])==bytes.fromhex(p['asyncOutput'])==expected
   words=struct.unpack('<14I',bytes.fromhex(p['wire']));assert words[0]==43+(13<<16) and words[1:4]==(711,level,0) and words[13]==2
   stride=words[4] or w*4;pitch=words[5] or stride*h;offset=words[12]
   end=offset+(box['depth']-1)*pitch+(box['height']-1)*stride+box['width']*4;assert end==p['end']==p['layout']['requiredEnd']
   inverse=bytearray([0xd9]*end);row=box['width']*4
   for z in range(box['depth']):
    for y in range(box['height']):
     a=offset+z*pitch+y*stride;b=(z*box['height']+y)*row;inverse[a:a+row]=expected[b:b+row]
   assert bytes(inverse)==bytes.fromhex(p['inverse'])==bytes.fromhex(p['publicExpected'])
   assert bytes.fromhex(p['untouched'])==bytes([0xd9]*end) and not p['short']['ok']
   interval=calls[p['nativeCallsStart']:p['nativeCallsEnd']]
   uploads=[c for c in interval if c['name'] in ['texSubImage2D','texSubImage3D']]
   assert len(uploads)==(6 if t==4 else 1)
   for z,c in enumerate(uploads):
    a=c['before'];assert a[1]==level
    if t==4:assert a[:8]==[34069+z,level,0,0,w,h,6408,5121] and bytes.fromhex(a[8]['bytes'])==source[z*w*h*4:(z+1)*w*h*4]
    else:assert a[:10]==[{3:32879,7:35866}[t],level,0,0,0,w,h,layers,6408,5121] and bytes.fromhex(a[10]['bytes'])==source
   attachments=[c for c in interval if c['name']==('framebufferTexture2D' if t==4 else 'framebufferTextureLayer') and c['before'][3 if t==4 else 2]==p['nativeTexture']]
   assert len(attachments)==box['depth']*2
   for j,c in enumerate(attachments):
    a=c['before'];z=box['z']+j%box['depth']
    assert (a[2],a[4])==(34069+z,level) if t==4 else (a[3],a[4])==(level,z)
   output=[c for c in interval if c['name']=='getBufferSubData'];assert len(output)==1 and bytes.fromhex(output[0]['after'][2]['bytes'])==expected
   points.append({'kind':tag,'partial':i,'target':t,'seed':seed,'level':level,'box':box,'publicEnd':end,'denseBytes':len(expected),'denseSha256':sha(expected),
    'nativeCall':output[0]['sequence'],'report':str(directory/'report.json'),'line':native_line(text,output[0]['sequence']),'reportSha256':sha(raw)})
  for p in r['points']:
   if p['kind']=='terminal':assert not any(p['state']['budgets'].values())
   if p['kind']=='unsupported-target':assert not p['result']['ok']
# The original cold checkout still has no tracked or untracked modifications.
cold,raw=read(repo/'target/evidence/d55-critic-worker-unpacked/cold/report.json')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=cold['clone'],text=True).strip()==cold['head']
assert subprocess.check_output(['git','status','--porcelain'],cwd=cold['clone'],text=True)==''
# Authenticate every prior failed publication body, including the full negative live page.
deploy=repo/'evidence/virgl-dimensional-storage/deployment';manifest,_=read(deploy/'manifest.json')
for pin in manifest['records']:pin_body(deploy/pin['path'],pin)
negative,_=read(deploy/'final/report.json');assert negative['status']=='failed' and negative['passed']==127 and negative['failed']==0 and negative['errors']==[]
assert 'E6-T11d54' in negative['failure']['message']
# Final publication: authenticate the entire staging set and each served byte.
staging=Path('/tmp/wasmvm-dimensional-storage-pages-bae5df1f/web/dist')
index,_=read(out/'publication/staging-index.json');assert index['head']=='bae5df1f1973e93d331bc7662b3ce89bbc1c98ef'
assert len(index['records'])==304 and len({p['path'] for p in index['records']})==304
staged={p['path']:p for p in index['records']}
for pin in index['records']:pin_body(staging/pin['path'],pin)
published,_=read(out/'publication/publish-success.json');canonical=published['canonical_deployment']
assert published['success'] and canonical['id']==published['latest_deployment']['id']=='1e10e572-1fdd-41ff-8d1e-014942c306f9'
assert canonical['environment']=='production' and canonical['latest_stage']['status']=='success'
assert canonical['deployment_trigger']['metadata']['commit_hash']==index['head']
shutil.copyfile('/tmp/wasmvm-dimensional-storage-live.mjs',out/'live/source.mjs')
live,raw=read(out/'live/report.json');assert live['status']=='passed' and live['passed']==127 and live['failed']==0 and live['errors']==[] and live['proofExportAbsent']
assert live['roadmapPip']=='cap-pip live' and live['graphicsRoadmapPip']=='cap-pip partial'
served=[]
for pin in live['served']:
 name=pin['path'].lstrip('/');body=pin_body(out/'live/bodies'/name,pin)
 key=name if name in staged else name+'.html'
 assert key in staged and staged[key]['sha256']==sha(body),name
 served.append({'path':name,'bytes':len(body),'sha256':sha(body),'stagedPath':key})
roadmap=(out/'live/bodies/roadmap.js').read_bytes();assert roadmap==(repo/'web/dist/roadmap.js').read_bytes() and b'E6-T11d55' in roadmap and b'production acceleration disabled' in roadmap
assert (out/'live/bodies/pkg/wasm_vm_wasm_bg.wasm').read_bytes()==(repo/'web/dist/pkg/wasm_vm_wasm_bg.wasm').read_bytes()
built,built_raw=read(worker/'default-demo/report.json');assert built['status']=='passed' and built['passed']==127 and built['failed']==0 and built['errors']==[] and built['proofExportAbsent']
for pin in built['served']:pin_body(worker/'sources'/pin['path'],pin)
result={'schema':'dimensional-storage-critic-recording-audit-v1','status':'passed','reports':pins,'points':points,'boundaries':boundaries,
 'novelPlanes':30,'frozenCloneClean':True,'failedPublicationBodies':len(manifest['records']),'stagingBodies':len(staged),'liveBodies':served,
 'publication':canonical,'builtReportSha256':sha(built_raw),'liveReportSha256':sha(raw),'productionAuthority':False,'guestExecution':False}
(out/'recording-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','novelPlanes','frozenCloneClean','failedPublicationBodies','stagingBodies']}|{'inversePoints':len(points),'boundaryPoints':len(boundaries),'liveBodies':len(served)}))
