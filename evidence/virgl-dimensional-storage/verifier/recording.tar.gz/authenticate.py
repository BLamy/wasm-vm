#!/usr/bin/env python3
"""Fresh critic: authenticate complete archives and unchanged verified seals."""
from pathlib import Path,PurePosixPath
import hashlib,json,subprocess,tarfile
repo=Path(__file__).resolve().parents[3]
out=Path(__file__).resolve().parent
base='37a6794437424049d38acb733191a16c1cdca998'
runtime='bae5df1f1973e93d331bc7662b3ce89bbc1c98ef'
sha=lambda b:hashlib.sha256(b).hexdigest()
unpacked=repo/'target/evidence/d55-critic-worker-unpacked'
assert not unpacked.exists()
pins={'manifest':'15815d6dc767934fbb4e5fbd493c1d927edc622d6ceb1833d6d9eac062c6e8a1','index':'3818f85ddc3f083764334ef80c4c615615dafe9d9c89dbe54776e0183aaac0a4','archive':'c32c662034196c07d06ec9103bb68de55bc461fc0623930fe2fed9ee0bc8d691'}
reports=[]
for family,role in [('virgl-dimensional-storage','worker'),('virgl-native-image','worker'),('virgl-native-image','verifier'),('virgl-resource-capacity','worker'),('virgl-resource-capacity','verifier')]:
    directory=repo/'evidence'/family/role
    raw=(directory/'manifest.json').read_bytes();manifest=json.loads(raw)
    index_raw=(directory/'records.json').read_bytes();index=json.loads(index_raw)
    archive=directory/'recording.tar.gz';archive_sha=sha(archive.read_bytes())
    assert sha(index_raw)==manifest['recordIndexSha256'] and archive_sha==manifest['archiveSha256']
    if family=='virgl-dimensional-storage':
        assert manifest['head']==runtime
        assert {'manifest':sha(raw),'index':sha(index_raw),'archive':archive_sha}==pins
    else:
        for file,body in [('manifest.json',raw),('records.json',index_raw)]:
            assert body==subprocess.check_output(['git','show',f'{base}:evidence/{family}/{role}/{file}'],cwd=repo)
        assert archive_sha==sha(subprocess.check_output(['git','show',f'{base}:evidence/{family}/{role}/recording.tar.gz'],cwd=repo))
    rows=index['records'] if isinstance(index,dict) else index
    assert len(rows)==len({r['path'] for r in rows})
    expected={r['path']:r for r in rows};bodies={};links={}
    with tarfile.open(archive,'r|gz') as packed:
        for member in packed:
            name=member.name
            assert name in expected and name not in bodies and name not in links
            path=PurePosixPath(name);assert not path.is_absolute() and '..' not in path.parts
            if member.isfile():bodies[name]=packed.extractfile(member).read()
            else:assert member.islnk();links[name]=member.linkname
    assert set(bodies)|set(links)==set(expected)
    def resolve(name,seen=frozenset()):
        assert name not in seen
        if name in bodies:return bodies[name]
        value=resolve(links[name],seen|{name});bodies[name]=value;return value
    for name,pin in expected.items():
        body=resolve(name)
        assert len(body)==pin['bytes'] and sha(body)==pin['sha256'],name
        if family=='virgl-dimensional-storage':
            file=unpacked/name;file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(body)
    reports.append(dict(family=family,role=role,manifestSha256=sha(raw),indexSha256=sha(index_raw),archiveSha256=archive_sha,
                        completeBodies=len(rows),completeBytes=sum(r['bytes'] for r in rows),verifiedParentEqual=family!='virgl-dimensional-storage'))
    print(f'Authenticated {family}/{role}: {len(rows)} complete bodies',flush=True)
    del bodies,links
cold=unpacked/'cold';recording=cold/'recording';receipt_raw=(recording/'receipt.json').read_bytes();receipt=json.loads(receipt_raw)
cold_report=json.loads((cold/'report.json').read_bytes())
assert cold_report['head']==receipt['head']==runtime
assert cold_report['exitCode']==0 and cold_report['cleanBefore']==cold_report['cleanAfter']==''
assert sha(receipt_raw)==cold_report['receiptSha256']
commands=[]
for c in receipt['commands']:
    assert c['exitCode']==c['expected']
    for stream in ['stdout','stderr']:
        assert sha((recording/f"{c['name']}.{stream}").read_bytes())==c[stream+'Sha256']
    commands.append({'name':c['name'],'command':c['command'],'exitCode':c['exitCode'],'expected':c['expected']})
for name,pin in receipt['sources'].items():
    body=(recording/'sources'/name).read_bytes()
    assert len(body)==pin['bytes'] and sha(body)==pin['sha256']
    assert body==subprocess.check_output(['git','show',f'{runtime}:{name}'],cwd=repo),name
    assert body==(repo/name).read_bytes(),name
carried=[]
for name,pin in receipt['carriedSources'].items():
    body=(repo/name).read_bytes();assert sha(body)==pin['sha256']
    assert body==subprocess.check_output(['git','show',f'{base}:{name}'],cwd=repo),name
    carried.append({'path':name,**pin})
for p in receipt['carriedOwnerRegions']:
    old=subprocess.check_output(['git','show',f"{base}:{p['source']}"],cwd=repo).decode();new=(repo/p['source']).read_text()
    def section(text):return text[text.index(p['start']):text.index(p['end'],text.index(p['start']))]
    body=section(new).encode();assert body==section(old).encode() and len(body)==p['bytes'] and sha(body)==p['sha256']
assert receipt['dependencySeals']==[{k:v for k,v in r.items() if k in ['family','role','manifestSha256','indexSha256','archiveSha256']}|{'reopenedBodies':r['completeBodies']} for r in reports[1:]]
result={'schema':'dimensional-storage-critic-authentication-v1','status':'passed','runtimeHead':runtime,'base':base,'seals':reports,
        'totalBodies':sum(r['completeBodies'] for r in reports),'commands':commands,'coldReport':cold_report,'receiptSha256':sha(receipt_raw),
        'carriedSources':carried,'carriedOwnerRegions':receipt['carriedOwnerRegions'],'authenticatedSources':len(receipt['sources']),
        'unpacked':str(unpacked),'guestExecution':False,'productionAuthority':False}
(out/'authentication.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['carriedSources','commands']}))
