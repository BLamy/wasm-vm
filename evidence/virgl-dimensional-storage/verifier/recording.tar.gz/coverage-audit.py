#!/usr/bin/env python3
"""Critic reconstruction of every changed runtime line's governing V8 partitions."""
import hashlib,json,re,subprocess
from pathlib import Path
repo=Path(__file__).resolve().parents[3];out=Path(__file__).resolve().parent
base='37a6794437424049d38acb733191a16c1cdca998'
worker=repo/'target/evidence/d55-critic-worker-unpacked/cold/recording'
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=['renderer/virgl-command/resources.mjs','renderer/virgl-command/decoder.mjs']
raw_diff=subprocess.check_output(['git','diff','--unified=0',base,'--',*paths],cwd=repo,text=True)
(out/'runtime.diff').write_text(raw_diff)
changed={};hunks=[];file=None;line=0;hunk=None
for row in raw_diff.splitlines():
 if row.startswith('+++ b/'):file=row[6:]
 elif row.startswith('@@'):
  line=int(re.search(r'\+(\d+)',row)[1]);hunk={'source':file,'header':row,'addedLines':[]};hunks.append(hunk)
 elif row.startswith('+') and not row.startswith('+++'):
  changed.setdefault(file,[]).append(line);hunk['addedLines'].append(line);line+=1
 elif row.startswith(' '):line+=1
observed={name:[] for name in paths};coverage_pins=[]
for tag,directory in [('worker-hardware',worker/'hardware'),('historical-resource',worker/'historical-resources'),('historical-image',worker/'historical-images'),('fresh-hardware',out/'fresh-hardware'),('novel-hardware',out/'novel-hardware')]:
 report=json.loads((directory/'report.json').read_bytes());assert report['status']=='passed'
 coverage_raw=(directory/'browser-coverage.json').read_bytes();assert sha(coverage_raw)==report['browserCoverage']['sha256']
 obj=json.loads(coverage_raw)
 for script in obj.get('scripts',[obj]):
  name=script['source']
  if name not in observed:continue
  source_path=directory/'source'/name
  if not source_path.exists():source_path=worker/'sources'/name
  source=source_path.read_bytes()
  assert sha(source)==script['sha256'] and source==(repo/name).read_bytes()
  script_pin={'tag':tag,'path':str(directory/'browser-coverage.json'),'sha256':sha(coverage_raw),'source':name,'sourceSha256':script['sha256']}
  coverage_pins.append(script_pin);observed[name].append((script_pin,[r for f in script['coverage']['functions'] for r in f['ranges']]))
partitions=[]
for name,lines in changed.items():
 text=(repo/name).read_text();chars=text.encode('utf-16-le');offsets=[0]
 for row in text.splitlines(keepends=True):offsets.append(offsets[-1]+len(row.encode('utf-16-le'))//2)
 for line in lines:
  start,end=offsets[line-1],offsets[line];breaks={start,end}
  for pin,ranges in observed[name]:
   for r in ranges:
    breaks.update(p for p in [r['startOffset'],r['endOffset']] if start<p<end)
  points=sorted(breaks)
  for a,b in zip(points,points[1:]):
   segment=chars[a*2:b*2].decode('utf-16-le');counters=[]
   for pin,ranges in observed[name]:
    enclosing=[r for r in ranges if r['startOffset']<=a and b<=r['endOffset']]
    if not enclosing:continue
    span=min(r['endOffset']-r['startOffset'] for r in enclosing)
    finest=[r for r in enclosing if r['endOffset']-r['startOffset']==span]
    counters.append({'tag':pin['tag'],'count':min(r['count'] for r in finest),'ranges':finest})
   executed=any(r['count']>0 for r in counters)
   syntax=not segment.strip() or re.fullmatch(r'[\s{}(),;]+',segment) is not None
   comment=text.splitlines()[line-1].lstrip().startswith(('//','/*','*'))
   classification='executed' if executed else 'waived' if syntax or comment else 'needs-evidence'
   partitions.append({'source':name,'line':line,'startOffset':a,'endOffset':b,'text':segment,'sha256':sha(segment.encode()),'classification':classification,'counters':counters,
    **({'reason':'Only structural delimiters, whitespace or a literal comment; no executable operand.'} if classification=='waived' else {})})
assert not [p for p in partitions if p['classification']=='needs-evidence']
worker_audit=json.loads((worker/'coverage-audit.json').read_bytes())
assert worker_audit['changedLines']==changed and not worker_audit['needsEvidence']
for p in worker_audit['executed']+worker_audit['waived']:
 parts=[r for r in partitions if r['source']==p['source'] and p['startOffset']<=r['startOffset']<r['endOffset']<=p['endOffset']]
 assert parts and parts[0]['startOffset']==p['startOffset'] and parts[-1]['endOffset']==p['endOffset']
 assert sha(''.join(r['text'] for r in parts).encode())==p['sha256']
for h in hunks:
 h['classification']='executed/structural' if h['addedLines'] else 'deletion';h['partitions']=sum(p['source']==h['source'] and p['line'] in h['addedLines'] for p in partitions)
result={'schema':'dimensional-storage-critic-finest-v8-v1','base':base,'runtimeHead':'bae5df1f1973e93d331bc7662b3ce89bbc1c98ef','changedLines':changed,'hunks':hunks,'coveragePins':coverage_pins,'partitions':partitions,
 'executed':sum(p['classification']=='executed' for p in partitions),'waived':sum(p['classification']=='waived' for p in partitions),'needsEvidence':0,
 'otherDiff':{'renderer/virgl-command/tests/dimensional-storage-acceptance.mjs':'Executed final hardware and fresh independent seeds.',
 'tools/virgl-dimensional-storage':'Authenticated complete sources and cold command receipts; seal reopens every member, critic independently reopens them.',
 'renderer/virgl-command/resources-README.md':'Declarative boundary documentation; matches isolated selection.',
 'web/roadmap.js, web/dist/roadmap.js':'Complete built served body matches frozen Git and preserves partial status.',
 'web/dist/sw.js':'Declarative content namespace regenerated by authenticated build; exact Git bytes.',
 'Makefile, task files, queue, evidence':'Declarative acceptance/lifecycle and authenticated evidence; no runtime operand.'}}
(out/'coverage-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['executed','waived','needsEvidence']}))
