// E4-T32: page-side entry point for the whole-machine worker. The protocol module owns the
// allow-listed controller surface, byte ownership, fatal settlement, and stop/terminate ordering.
import { createLinuxWorkerClient } from "./linux-worker-protocol.js";

// Main-thread controllers do not own their outer storage lifecycle in stop(); whole-worker
// controllers do. Keep the page's destructive-reset/reboot path ordered and backend-neutral.
export async function stopLinuxController(controller) {
  if (!controller) return;
  let firstError = null;
  try { await controller.stop?.(); } catch (error) { firstError = error; }
  if (controller.backend !== "whole-machine-worker") {
    try { await controller.releaseWriterLock?.(); } catch (error) { firstError ??= error; }
    try { await controller.closeStorage?.(); } catch (error) { firstError ??= error; }
  }
  if (firstError) throw firstError;
}

export async function startLinuxBootWorker(opts = {}) {
  const retainedGpu = opts.gpuRuntime === "published-factory-v1";
  if (opts.gpuRuntime !== undefined && !retainedGpu) throw new Error("unknown GPU runtime");
  if (retainedGpu && (opts.virgl !== true || opts.bootSnapshot === false)) {
    throw new Error("published GPU runtime requires an accelerated factory warm boot");
  }
  const WorkerCtor = opts.WorkerCtor ?? globalThis.Worker;
  if (typeof WorkerCtor !== "function") {
    throw new Error("whole-machine Web Worker is unavailable");
  }

  // The authenticated factory worker retains its original protocol as well as its Wasm/renderer.
  // Select the matching page client before starting it, so no startup message can be lost.
  const createClient = retainedGpu
    ? (await import('./gpu-runtime/222950026e3e01edc32462dc531795d49c262c4780d24ac9cebbb01c2d22cea0/linux-worker-protocol.js')).createLinuxWorkerClient
    : createLinuxWorkerClient;

  const worker = new WorkerCtor(new URL(retainedGpu ? "./gpu-runtime-worker.js" : "./linux-worker.js", import.meta.url), {
    type: "module",
    name: "wasm-vm-linux",
  });

  // DOM/xterm callbacks stay on the page. Everything else is structured-clone boot data.
  const {
    onState = () => {},
    onProgress = () => {},
    onOutput = () => {},
    onAgentOutput = () => {},
    onError = () => {},
    onWriterStatus = () => {},
    onStorage = () => {},
    onQuota = () => {},
    onCaptureStart = () => {},
    onDisplayFrame = () => {},
    onGpuEvent = () => {},
    onCursorState = () => {},
    onTailscaleEvent = (message) => globalThis.__wasmVmTailscaleEvent?.(message),
    onWorker = () => {},
    workerHeartbeatIntervalMs,
    workerHeartbeatTimeoutMs,
    workerBootTimeoutMs,
    WorkerCtor: _ignored,
    gpuRuntime: _runtimeChoice,
    ...dataOpts
  } = opts;
  try { onWorker(worker); } catch (error) {
    worker.terminate();
    throw error;
  }

  let detachVisibility = () => {};
  const client = createClient(worker, {
    onState,
    onProgress,
    onOutput,
    onAgentOutput,
    onError,
    onWriterStatus,
    onStorage,
    onQuota,
    onCaptureStart,
    onDisplayFrame,
    onGpuEvent,
    onCursorState,
    onTailscaleEvent,
    heartbeatIntervalMs: workerHeartbeatIntervalMs,
    heartbeatTimeoutMs: workerHeartbeatTimeoutMs,
    bootTimeoutMs: workerBootTimeoutMs,
    isHeartbeatSuspended: () => globalThis.document?.hidden === true,
    onTerminate: () => detachVisibility(),
  });
  if (globalThis.document?.addEventListener) {
    const onVisibility = () => client.setHeartbeatSuspended(globalThis.document.hidden);
    globalThis.document.addEventListener("visibilitychange", onVisibility);
    detachVisibility = () => globalThis.document.removeEventListener("visibilitychange", onVisibility);
    onVisibility();
  }
  worker.addEventListener?.("error", (event) => {
    client.fail(new Error(event?.message || "whole-machine worker error"));
  });
  worker.addEventListener?.("messageerror", () => {
    client.fail(new Error("whole-machine worker received an un-clonable message"));
  });
  return client.boot(dataOpts);
}
