#!/usr/bin/env python3
"""Fresh precise-partition and frozen browser/source audit, no worker audit import."""
import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-standard-packed-depth-consumer-critic';TREE=OUT/'worker-reopened';BASE='c60bf20abcd42c1c10fb1863c2666a344d5c8e70';BB='bb12868a5fceea81acec5a8ff42496e13007ddd8';sha=lambda b:hashlib.sha256(b).hexdigest()
def need(x,m):
 if not x:raise AssertionError(m)
source={n:subprocess.check_output(['git','show',BB+':'+n],cwd=ROOT) for n in ['renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs']};old={n:subprocess.check_output(['git','show',BASE+':'+n],cwd=ROOT) for n in source};waivers=json.loads((TREE/'source/tools/virgl-packed-depth-consumer/coverage-waivers.json').read_text())['waivers'];added={};name=None;line=0
for row in subprocess.check_output(['git','diff','--unified=0',BASE,BB,'--',*source],cwd=ROOT,text=True).splitlines():
 if row.startswith('+++ b/'):name=row[6:]
 elif row.startswith('@@'):line=int(re.search(r'\+(\d+)',row)[1])
 elif row.startswith('+'):added.setdefault(name,[]).append(line);line+=1
 elif row.startswith(' '):line+=1
browser=[];results={}
for prefix in ['hot','cold']:
 directory=TREE/prefix;observed=[]
 for file in sorted(directory.rglob('report.json')):
  env=json.loads(file.read_text())
  if 'browserErrors' not in env:continue
  need(env['gitHead']==BB,'frozen report head');need(env['browserErrors']==dict(console=[],page=[],requests=[]),'zero complete console/page/request errors');sources={r['path']:r for r in env['sources']}
  for path,row in sources.items():
   b=(file.parent/'source'/path).read_bytes();need(len(b)==row['bytes'] and sha(b)==row['sha256'],'complete report source '+path)
   if '/build/wasm/' not in path:need(b==subprocess.check_output(['git','show',BB+':'+path],cwd=ROOT),'frozen reported source '+path)
  if 'browser' not in env:
   need(file.parent.name=='wire' and env['status']=='passed' and len(env['wire']['records'])==22,'whole original wire cases');continue
  browserSpec=env['browser'];need(browserSpec['headless'] is False,'real headed browser');need(not any(re.search(r'swiftshader|llvmpipe|softpipe|lavapipe|--disable-gpu(?:$|=)',v,re.I) for v in browserSpec['commandLine']),'no software renderer');e=env.get('partial') or env['browserResult']['result'];need('Metal' in str(e.get('gpu',e.get('renderer'))) and 'M4' in str(e.get('gpu',e.get('renderer'))),'actual M4 Metal device');need(not e['guestExecution'] and not e['productionNegotiation'],'isolated selected factory authority')
  served={r['path']:r for r in env['servedFiles']};covered=json.loads((file.parent/env['browserCoverage']['path']).read_text())['scripts']
  for script in covered:
   b=script['sourceBody'].encode();path=script['source'];need(sha(b)==script['sha256']==sources[path]['sha256']==served['/'+path]['sha256'] and len(b)==sources[path]['bytes']==served['/'+path]['bytes'],'whole served coverage source custody '+path)
   if path in source and not file.parent.name.startswith('fault-'):observed.append(dict(record=str(file.relative_to(OUT)),**script))
  for key in ['browserCoverage','screenshot']:
   row=env[key];need(sha((file.parent/row['path']).read_bytes())==row['sha256'],'whole screenshot/coverage body')
  browser.append(dict(record=str(file.relative_to(OUT)),sha256=sha(file.read_bytes()),status=env['status'],coverageScripts=len(covered),gpu=e.get('gpu',e.get('renderer')),errors=env['browserErrors']))
 for file in (directory/'node-coverage').glob('coverage-*.json'):
  for script in json.loads(file.read_text())['result']:
   for path in source:
    if script['url'].endswith('/'+path):observed.append(dict(record=str(file.relative_to(OUT)),source=path,sha256=sha(source[path]),coverage=script))
 partitions=[]
 for path,lines in added.items():
  text=source[path].decode();offsets=[0]
  for body in text.splitlines(keepends=True):offsets.append(offsets[-1]+len(body.encode('utf-16-le'))//2)
  scripts=[r for r in observed if r['source']==path]
  for ln in lines:
   start,end=offsets[ln-1:ln+1];boundaries={start,end}
   for s in scripts:
    need(s['sha256']==sha(source[path]),'runtime coverage source')
    for f in s['coverage']['functions']:
     for r in f['ranges']:
      boundaries.update(x for x in [r['startOffset'],r['endOffset']] if start<x<end)
   borders=sorted(boundaries)
   for a,b in zip(borders,borders[1:]):
    counters=[]
    for s in scripts:
     ranges=[(f['functionName'],r) for f in s['coverage']['functions'] for r in f['ranges'] if r['startOffset']<=a and b<=r['endOffset']]
     if ranges:
      fn,r=min(ranges,key=lambda pair:pair[1]['endOffset']-pair[1]['startOffset']);counters.append(dict(record=s['record'],function=fn,**r))
    raw=text.encode('utf-16-le')[a*2:b*2].decode('utf-16-le');count=max((r['count'] for r in counters),default=0);p=dict(source=path,line=ln,startOffset=a,endOffset=b,text=raw,textSha256=sha(raw.encode()),maximumFinestCount=count,counters=counters)
    if count:p['result']='EXECUTED'
    else:
     matches=[w for w in waivers if (w['source'],w['startOffset'],w['endOffset'])==(path,a,b)];need(len(matches)==1,'unproven governing partition '+str((path,ln,a,b,raw)));w=matches[0];need(w['text']==raw and w['sha256']==sha(raw.encode()) and 'packedDepth' not in raw,'no new semantic waiver');need(w['classification']=='unchanged-operand' and w['predecessorSourceSha256']==sha(old[path]) and old[path].decode().encode('utf-16-le')[w['predecessorStartOffset']*2:w['predecessorEndOffset']*2].decode('utf-16-le')==raw,'exact predecessor operand waiver');p['result']='HELD UNCHANGED OPERAND';p['waiver']=w
    partitions.append(p)
 result=dict(status='passed',sourceHead=BB,predecessor=BASE,positive=sum(p['result']=='EXECUTED' for p in partitions),waived=sum(p['result']=='HELD UNCHANGED OPERAND' for p in partitions),zero=0,addedLines=added,partitions=partitions)
 need(result['positive']==194 and result['waived']==8,'full finest partition count');results[prefix]=result
(OUT/'precise-coverage-audit.json').write_text(json.dumps(dict(status='passed',records=results),indent=2)+'\n');(OUT/'worker-browser-source-audit.json').write_text(json.dumps(dict(status='passed',records=browser),indent=2)+'\n');print(json.dumps(dict(status='passed',browserRecords=len(browser),coverage={k:{p:v[p] for p in ['positive','waived','zero']} for k,v in results.items()})))
