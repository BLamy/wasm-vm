#!/usr/bin/env python3
"""Reopen ALL fresh blobs/source/coverage/browser/error/screenshot bodies."""
import gzip,hashlib,json,re,subprocess
from functools import lru_cache
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-standard-packed-depth-consumer-critic';sha=lambda b:hashlib.sha256(b).hexdigest()
BB='bb12868a5fceea81acec5a8ff42496e13007ddd8';DD='dd466604ee2c1f61c9a2cb7e22750107f09b0425';FINAL='1b03feb0b60422ba706f14c7f0fcd22d222fa903'
@lru_cache(None)
def git(head,path):
 p=subprocess.run(['git','show',head+':'+path],capture_output=True);return p.stdout if p.returncode==0 else None
generated={'renderer/virgl-shader/build/wasm/virgl_shader.mjs':'6bb07a0b2a056d21ae52b22d7700ce10577854c1cdcf0877dd80be938e30e0fa','renderer/virgl-shader/build/wasm/virgl_shader.wasm':'acbe036afcdc4f1d8aa8cfb0fb107f48ba27759a6af4a7b9d6c83e3aa679d6cc'}
roots=sorted([p for p in OUT.iterdir() if p.is_dir() and (p.name.startswith('hardware-') or p.name.startswith('fault-'))])+[OUT/'promoted/hardware-novel',OUT/'promoted/fault-novel-completed-stencil',OUT/'promoted-final/hardware-novel',OUT/'promoted-final/fault-novel-completed-stencil']
records=[];totalRuns=totalBlobs=totalBytes=totalSources=totalCoverage=0
for directory in roots:
 file=directory/'report.json';env=json.loads(file.read_text());head=env['gitHead'];initial=directory.name=='hardware-novel-initial';e=env.get('partial') or env['browserResult']['result']
 assert env['browserErrors']==dict(console=[],page=[],requests=[])
 assert env['browser']['headless'] is False and 'M4 Max' in str(e['gpu']) and 'Metal' in str(e['gpu'])
 assert not any(re.search('swiftshader|llvmpipe|softpipe|lavapipe|--disable-gpu(?:$|=)',v,re.I) for v in env['browser']['commandLine'])
 assert not e['guestExecution'] and not e['productionNegotiation'];assert head in [DD,FINAL,'0def15a9bf5a828e784ab2597cb570d9c0f5fdd26'] or head.startswith('0def15a9')
 sources={};exploratory=[]
 for row in env['sources']:
  path=row['path'];raw=(directory/'source'/path).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'];sources[path]=row
  if path in generated:assert sha(raw)==generated[path]
  elif raw!=git(head,path):
   assert initial and path in ['renderer/virgl-command/tests/standard-packed-depth-consumer-critic.mjs','tools/verify-virgl-packed-depth-consumer-critic.mjs','tools/virgl-packed-depth-consumer/critic.py','tools/verify-virgl-packed-depth-consumer-critic.sh'],(directory,path)
   exploratory.append(dict(path=path,bytes=len(raw),sha256=sha(raw),classification='untracked exploratory harness body; frozen runtime/compiler only'))
  if path.startswith('renderer/') and '/build/wasm/' not in path and 'standard-packed-depth-consumer-critic.mjs' not in path:assert raw==git(BB,path),(directory,path,'runtime source changed')
  totalSources+=1
 served={r['path']:r for r in env['servedFiles']};coverageRaw=(directory/env['browserCoverage']['path']).read_bytes();coverage=json.loads(coverageRaw)['scripts']
 for script in coverage:
  path=script['source'];raw=script['sourceBody'].encode();assert sha(raw)==script['sha256']==sources[path]['sha256']==served['/'+path]['sha256'];assert len(raw)==sources[path]['bytes']==served['/'+path]['bytes'];assert raw==(directory/'source'/path).read_bytes();totalCoverage+=1
 for kind in ['browserCoverage','screenshot']:
  row=env[kind];raw=(directory/row['path']).read_bytes();assert sha(raw)==row['sha256'];assert kind!='screenshot' or raw.startswith(b'\x89PNG\r\n\x1a\n')
 blobs={}
 for ref in e['blobs']:
  assert ref['key'] not in blobs;compressed=(directory/ref['path']).read_bytes();raw=gzip.decompress(compressed);assert sha(compressed)==ref['gzipSha256'] and sha(raw)==ref['sha256'] and len(raw)==ref['bytes'];blobs[ref['key']]=ref;totalBytes+=len(raw);totalBlobs+=1
 runPoints=[]
 def refs(value):
  if isinstance(value,dict):
   if value.get('key','').startswith('blob-') and 'sha256' in value:
    body=blobs[value['key']];assert body['sha256']==value['sha256'] and body['bytes']==value['bytes'];assert value.get('gzipSha256',body['gzipSha256'])==body['gzipSha256']
   for v in value.values():refs(v)
  elif isinstance(value,list):
   for v in value:refs(v)
 for index,ref in enumerate(e['runs']):
  if 'path' in ref:
   raw=(directory/ref['path']).read_bytes();assert len(raw)==ref['bytes'] and sha(raw)==ref['sha256'];run=json.loads(raw);bodyPath=ref['path'];digest=sha(raw)
  else:run=ref;bodyPath='report.json#/partial/runs/'+str(index);digest=sha(json.dumps(run,separators=(',',':')).encode())
  refs(run);runPoints.append(dict(index=index,path=bodyPath,sha256=digest,nativeEvents=len(run['events']),draws=len(run['draws']),histories=len(run['history'])));totalRuns+=1
 records.append(dict(record=str(file.relative_to(OUT)),reportSha256=sha(file.read_bytes()),sourceHead=head,status=env['status'],sources=len(sources),coverageScripts=len(coverage),blobs=len(blobs),runs=runPoints,exploratorySourceExceptions=exploratory,gpu=e['gpu'],browserErrors=env['browserErrors'],screenshot=env['screenshot'],browserCoverage=env['browserCoverage']))
assert len(records)==9 and len(next(r for r in records if 'hardware-novel-initial' in r['record'])['exploratorySourceExceptions'])>=2
result=dict(status='passed',frozenWorkerRuntime=BB,frozenFinalPromotedHarness=FINAL,records=records,counts=dict(recordings=len(records),runs=totalRuns,completeBlobs=totalBlobs,completeUncompressedBlobBytes=totalBytes,sourceBodies=totalSources,wholeCoverageScripts=totalCoverage),generatedCompiler=generated)
(OUT/'fresh-custody-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status='passed',**result['counts'])))
