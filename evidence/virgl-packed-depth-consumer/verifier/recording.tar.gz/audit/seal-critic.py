#!/usr/bin/env python3
"""Full fresh-body sealing; independent stream reopening, no worker tool imports."""
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-standard-packed-depth-consumer-critic';DEST=ROOT/'evidence/virgl-packed-depth-consumer/verifier';DEST.mkdir(parents=True,exist_ok=True)
HEAD='1b03feb0b60422ba706f14c7f0fcd22d222fa903';BB='bb12868a5fceea81acec5a8ff42496e13007ddd8';DD='dd466604ee2c1f61c9a2cb7e22750107f09b0425';sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()==HEAD
def git(path):return subprocess.check_output(['git','show',HEAD+':'+path])
paths={};closure=[]
def add(name,path):
 assert name not in paths and '..' not in Path(name).parts and not name.startswith('/');paths[name]=path
for f in sorted(OUT.iterdir()):
 if f.is_file() and f.name!='source-closure-audit.json':add('audit/'+f.name,f)
roots=sorted([p for p in OUT.iterdir() if p.is_dir() and (p.name.startswith('hardware-') or p.name.startswith('fault-'))])+[OUT/'promoted',OUT/'promoted-final']
for directory in roots:
 for f in sorted(directory.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts:add('fresh/'+str(f.relative_to(OUT)),f)
for prefix in ['hot','cold']:
 root=OUT/'worker-reopened'/prefix
 for f in sorted(root.rglob('*')):
  if f.is_file() and (f.name.endswith('audit.json') or f.name=='independent-values.json'):add('worker-independent/'+prefix+'/'+str(f.relative_to(root)),f)
baseline=OUT/'worker-reopened/source';sourcePaths={str(f.relative_to(baseline)) for f in baseline.rglob('*') if f.is_file()}
for env in [OUT/'promoted-final/hardware-novel/report.json',OUT/'promoted-final/fault-novel-completed-stencil/report.json']:
 sourcePaths.update(s['path'] for s in json.loads(env.read_text())['sources'])
sourcePaths.update(['tools/check_task_policy.py','tools/build_queue.py','evidence/virgl-production-readiness/standard-packed-depth-consumer-gap.mjs','evidence/virgl-production-readiness/standard-packed-depth-consumer-gap.json','renderer/virgl-command/tests/standard-packed-depth-consumer-critic.mjs','tools/verify-virgl-packed-depth-consumer-critic.mjs','tools/verify-virgl-packed-depth-consumer-critic.sh','tools/virgl-packed-depth-consumer/critic.py'])
generated={'renderer/virgl-shader/build/wasm/virgl-shader.mjs':'6bb07a0b2a056d21ae52b22d7700ce10577854c1cdcf0877dd80be938e30e0fa','renderer/virgl-shader/build/wasm/virgl-shader.wasm':'acbe036afcdc4f1d8aa8cfb0fb107f48ba27759a6af4a7b9d6c83e3aa679d6cc'}
closureDir=OUT/'frozen-source-closure'
for path in sorted(sourcePaths):
 if path in generated:
  raw=(OUT/'promoted-final/hardware-novel/source'/path).read_bytes();assert sha(raw)==generated[path];kind='unchanged actual generated compiler'
 else:raw=git(path);kind='exact frozen Git source'
 target=closureDir/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);add('source/'+path,target);closure.append(dict(path=path,bytes=len(raw),sha256=sha(raw),boundary=kind))
(OUT/'source-closure-audit.json').write_text(json.dumps(dict(status='passed',sourceHead=HEAD,frozenWorkerRuntime=BB,generatedCompiler=generated,sourceBodies=len(closure),records=closure),indent=2)+'\n');add('audit/source-closure-audit.json',OUT/'source-closure-audit.json')
archive=DEST/'recording.tar.gz';records=[];seen={};physicalCount=logicalBytes=physicalBytes=0
with archive.open('wb') as output:
 with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0,compresslevel=6) as zipped:
  with tarfile.open(fileobj=zipped,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for name,path in sorted(paths.items()):
    raw=path.read_bytes();digest=sha(raw);length=len(raw);info=tarfile.TarInfo(name);info.mode=0o644;info.uid=info.gid=info.mtime=0;info.uname=info.gname='';key=(digest,length)
    row=dict(path=name,bytes=length,sha256=digest)
    if key in seen:info.type=tarfile.LNKTYPE;info.linkname=seen[key];row['earlierPhysicalBody']=seen[key];tar.addfile(info)
    else:info.size=length;tar.addfile(info,io.BytesIO(raw));seen[key]=name;physicalCount+=1;physicalBytes+=length
    records.append(row);logicalBytes+=length
index=DEST/'records.json';index.write_text(json.dumps(dict(schema='packed-depth-consumer-fresh-critic-full-bodies-v1',records=records),indent=2)+'\n')
# Reopen actual complete bytes from the newly sealed stream. A logical hardlink
# may refer only to an earlier regular physical body, never a link/index claim.
physical={};expected={r['path']:r for r in records};reopened=[];allNames=set()
with tarfile.open(archive,mode='r|gz') as tar:
 for member in tar:
  assert member.name not in allNames and member.name in expected;allNames.add(member.name)
  if member.isreg():
   raw=tar.extractfile(member).read();assert len(raw)==member.size;actual=dict(bytes=len(raw),sha256=sha(raw));physical[member.name]=actual
  else:
   assert member.islnk() and member.linkname in physical;actual=physical[member.linkname];assert expected[member.name].get('earlierPhysicalBody')==member.linkname
  row=expected[member.name];assert (actual['bytes'],actual['sha256'])==(row['bytes'],row['sha256']);reopened.append(dict(path=member.name,**actual,physical=member.name if member.isreg() else member.linkname))
assert allNames==set(expected)
audit=DEST/'reopening-audit.json';audit.write_text(json.dumps(dict(status='passed',logicalMembers=len(reopened),physicalMembers=len(physical),logicalBytes=logicalBytes,physicalBytes=physicalBytes,records=reopened),indent=2)+'\n')
manifest=dict(schema='packed-depth-consumer-fresh-critic-seal-v1',task='E6-T11d43',sourceHead=HEAD,frozenWorkerRuntime=BB,workerSubmission=DD,workerSeal=dict(manifestSha256='50d98b1a99ec9ffc0dce2567126a59fa7785536140275c2c62951d47378dfbdb',archiveSha256='cee5f6525922a02a14885affebcf763df18468b6434267a251f1a1f5b3e313a4',indexSha256='012d2a73e5d3d61db1b98a399ebda30d2d0f8592ec54df06e15a0f9cc6be11cf',independentlyReopenedLogicalMembers=61957,heldD42LogicalBodies=43044),archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes())),index=dict(path=index.name,bytes=index.stat().st_size,sha256=sha(index.read_bytes())),reopening=dict(path=audit.name,bytes=audit.stat().st_size,sha256=sha(audit.read_bytes()),logicalMembers=len(reopened),physicalMembers=len(physical),logicalBytes=logicalBytes,physicalBytes=physicalBytes),wholeFreshRecordings=9,sourceClosureBodies=len(closure),guestExecution=False,productionNegotiation=False,productionDrawAuthority=False,authority='isolated original packed UN24 consumers; unchanged held predecessor boundaries only')
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(dict(status='passed',sourceHead=HEAD,archiveBytes=archive.stat().st_size,logicalMembers=len(reopened),physicalMembers=len(physical),manifestSha256=sha((DEST/'manifest.json').read_bytes()),archiveSha256=manifest['archive']['sha256'],indexSha256=manifest['index']['sha256'],reopeningSha256=manifest['reopening']['sha256'])))
