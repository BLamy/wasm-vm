#!/usr/bin/env python3
"""Additional custody only: original views -> actual compiler -> actual native source.

No product imports. This is never an expected-image oracle. Numeric acceptance uses
original TGSI, original input bytes, recorded native fields and public bytes.
"""
import copy,hashlib,json,re,struct,subprocess
from pathlib import Path
OUT=Path.cwd()/'target/evidence/virgl-standard-packed-depth-consumer-critic'
sha=lambda s:hashlib.sha256(s.encode() if isinstance(s,str) else s).hexdigest()
BB='bb12868a5fceea81acec5a8ff42496e13007ddd8';C60='c60bf20abcd42c1c10fb1863c2666a344d5c8e70'
def git(ref,path):return subprocess.check_output(['git','show',ref+':'+path]).decode()
source=git(BB,'renderer/virgl-command/state.mjs');old=git(C60,'renderer/virgl-command/state.mjs')
start='    const samplingFor = ';end='    const specializeBlend = '
emitter=source[source.index(start):source.index(end)]
assert emitter==old[old.index(start):old.index(end)]
integrationStart='        let fragmentText = specializeViews('
integrationEnd='        const vertexVariant = '
integration=source[source.index(integrationStart):source.index(integrationEnd)]
assert integration==old[old.index(integrationStart):old.index(integrationEnd)]
(OUT/'unchanged-view-emitter.txt').write_text(emitter+integration)
def packets(h):
 raw=bytes.fromhex(h);i=0
 while i<len(raw):
  word=struct.unpack_from('<I',raw,i)[0];length=word>>16;body=raw[i+4:i+4+length*4];assert len(body)==length*4
  yield word&255,word>>8&255,struct.unpack('<'+'I'*length,body),body
  i+=4+length*4
 assert i==len(raw)
def specialize(text,views,stage):
 helpers='';used=[]
 for slot,view in sorted((slot,v) for (s,slot),v in views.items() if s==stage and v and v['swizzle']!=[0,1,2,3]):
  assert view['format'] in [20,21];name=('vssamp' if stage==0 else 'fssamp')+str(slot)
  if not re.search(r'\buniform highp sampler2D '+name+r';',text):continue
  lanes=['v.r','v.g','v.b','v.a','0.0','1.0'];swizzle=','.join(lanes[x] for x in view['swizzle'])
  for op,args,values in [('texture','vec2 coord','coord'),('textureLod','vec2 coord,float lod','coord,lod'),('texelFetch','ivec2 coord,int lod','coord,lod'),('textureGrad','vec2 coord,vec2 dx,vec2 dy','coord,dx,dy')]:
   fn='wv_view_'+str(slot)+'_'+op;text,hits=re.subn(r'\b'+op+r'\s*\(\s*'+name+r'\s*,',fn+'(',text)
   if hits:
    helpers+='vec4 '+fn+'('+args+'){vec4 v='+op+'('+name+','+values+');return vec4('+swizzle+');}\n'
    if op=='texture' and stage==1:helpers+='vec4 '+fn+'(vec2 coord,float bias){vec4 v=texture('+name+',coord,bias);return vec4('+swizzle+');}\n'
    used.append(dict(stage=stage,slot=slot,originalView=copy.deepcopy(view),operation=op,replacements=hits))
 if helpers:
  main=text.index('\nvoid main(');text=text[:main+1]+helpers+text[main+1:]
 return text,used
files=[]
for root in [OUT/'worker-reopened/hot',OUT/'worker-reopened/cold',OUT]:files+=sorted(root.glob('hardware-*/report.json'))
files += [OUT/'promoted/hardware-novel/report.json',OUT/'promoted-final/hardware-novel/report.json']
records=[];total=wrapped=0;initial=None
for file in files:
 env=json.loads(file.read_text())
 if env['status']!='passed':continue
 e=env['browserResult']['result'];points=[]
 for ref in e['runs']:
  raw=(file.parent/ref['path']).read_bytes();assert sha(raw)==ref['sha256'];r=json.loads(raw)
  states={};draws={};original=[]
  for n,d in enumerate(r['draws']):draws.setdefault(d['label'],[]).append((n,d))
  for hi,h in enumerate(r['history']):
   ctx=states.setdefault(h['ctx'],dict(shaders={},stages={},views={},bound={}))
   applied=h['result'].get('appliedCommands',h.get('appliedBeforeDispose',0))
   for ci,(op,kind,w,body) in enumerate(packets(h['hex'])):
    if ci>=applied:continue
    if op==1 and kind==4:ctx['shaders'][w[0]]=body[20:20+w[2]-1].decode('ascii')
    elif op==31:ctx['stages'][w[1]]=ctx['shaders'][w[0]]
    elif op==1 and kind==6:ctx['views'][w[0]]=dict(handle=w[0],resource=w[1],format=w[2]&0xffffff,first=w[4]&255,last=w[4]>>8&255,swizzle=[w[5]>>(i*3)&7 for i in range(4)])
    elif op==10:
     for slot,handle in enumerate(w[2:],w[1]):ctx['bound'][w[0],slot]=ctx['views'].get(handle)
    elif op==8:
     n,d=draws[h['label']].pop(0);original.append((n,d,copy.deepcopy(ctx),hi,ci))
  assert len(original)==len(r['draws']),(str(file),ref['path'],len(original),len(r['draws']),[(h['label'],h['result'],h.get('appliedBeforeDispose')) for h in r['history'] if h['label'] in draws and draws[h['label']]])
  for n,d,ctx,hi,ci in original:
   shaders={s['type']:s['glsl'] for s in d['shaders']};assert set(shaders)=={35633,35632}
   calls={}
   for typ,text in shaders.items():
    matches=[v for v in r['events'] if v['name']=='shaderSource' and v['sequence']<d['sequence'] and v['args'][1]==text]
    assert matches,'queried attached native body absent from preceding actual shaderSource calls'
    call=matches[-1];obj=next(o for o in r['nativeObjects'] if o['id']==call['args'][0]);assert obj['name']=='createShader' and obj['deleted']==1
    calls[typ]=dict(sequence=call['sequence'],nativeShaderObject=call['args'][0],sha256=sha(text))
   found=[]
   for qi,q in enumerate(r['requests']):
    if q['method']!='pair' or not q['result']['ok']:continue
    if q['request']['vertexText']!=ctx['stages'][0] or q['request']['fragmentText']!=ctx['stages'][1]:continue
    vertex,vu=specialize(q['result']['vertex']['glsl'],ctx['bound'],0);fragment,fu=specialize(q['result']['fragment']['glsl'],ctx['bound'],1)
    if vertex==shaders[35633] and fragment==shaders[35632]:found.append((qi,q,vu+fu))
   assert found,(file,ref['path'],n,'actual native body lacks raw compiler + original view provenance')
   qi,q,uses=found[0];total+=1;wrapped+=bool(uses)
   point=dict(run=ref['path'],runSha256=ref['sha256'],draw=n,label=d['label'],nativeSequence=d['sequence'],program=d['native']['program'],originalHistory=hi,originalCommand=ci,actualCompilerRequest=qi,originalVertexSha256=sha(ctx['stages'][0]),originalFragmentSha256=sha(ctx['stages'][1]),compilerVertexSha256=sha(q['result']['vertex']['glsl']),compilerFragmentSha256=sha(q['result']['fragment']['glsl']),nativeCalls=calls,wrappers=uses)
   points.append(point)
   if 'worker-reopened/hot/hardware-boundaries-0x13579bdf/' in str(file) and ref['path']=='run-0001.json' and n==0:initial=point
 records.append(dict(record=str(file.relative_to(OUT)),status='passed',points=points))
assert initial and initial['wrappers'][0]['originalView']['swizzle']==[0,0,0,5]
audit=dict(status='passed',sourceBoundary=dict(predecessor=C60,frozen=BB,emitterSha256=sha(emitter),integrationSha256=sha(integration),frozenEmitterLine=source[:source.index(start)].count('\n')+1,frozenIntegrationLine=source[:source.index(integrationStart)].count('\n')+1),nativeDraws=total,viewWrappedDraws=wrapped,initialPrediction=dict(status='FAILED',classification='supplemental raw-body assumption; no product numerical refutation',refinedObservation=initial),nativeShaderIdentityLimitation='Draws query actual attached shader source/type but do not export attached object IDs; full body equality to preceding actual native calls on createShader objects is proven, not a separately exported attached-object-ID equality.',records=records)
(OUT/'actual-compiler-native-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps(dict(status='passed',nativeDraws=total,viewWrappedDraws=wrapped,records=len(records),emitterSha256=sha(emitter),integrationSha256=sha(integration))))
