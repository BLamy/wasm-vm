#!/usr/bin/env python3
"""Bind queried native shader bodies to the unchanged compiler's actual responses."""
import hashlib,json
from pathlib import Path
OUT=Path.cwd()/'target/evidence/virgl-standard-packed-depth-consumer-critic';sha=lambda s:hashlib.sha256(s.encode()).hexdigest();records=[];total=0
roots=[OUT/'worker-reopened/hot',OUT/'worker-reopened/cold',OUT]
files=[]
for root in roots:
 files += sorted(root.glob('hardware-*/report.json'))
files += [OUT/'promoted-final/hardware-novel/report.json']
for file in files:
 env=json.loads(file.read_text())
 if env['status']!='passed':continue
 e=env['browserResult']['result'];points=[]
 for ref in e['runs']:
  raw=(file.parent/ref['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==ref['sha256'];r=json.loads(raw)
  pairs={(sha(q['result']['vertex']['glsl']),sha(q['result']['fragment']['glsl'])) for q in r['requests'] if q['method']=='pair' and q['result']['ok']}
  for index,d in enumerate(r['draws']):
   shaders={s['type']:sha(s['glsl']) for s in d['shaders']};assert set(shaders)=={35633,35632} and (shaders[35633],shaders[35632]) in pairs,(file,ref['path'],index,'queried native program differs actual compiler response');points.append(dict(run=ref['path'],runSha256=ref['sha256'],draw=index,label=d['label'],nativeSequence=d['sequence'],program=d['native']['program'],nativeVertexSha256=shaders[35633],nativeFragmentSha256=shaders[35632]));total+=1
 records.append(dict(record=str(file.relative_to(OUT)),status='passed',points=points))
(OUT/'actual-compiler-native-audit.json').write_text(json.dumps(dict(status='passed',nativeDraws=total,records=records),indent=2)+'\n');print(json.dumps(dict(status='passed',nativeDraws=total,records=len(records))))
