#!/usr/bin/env python3
"""Fresh full-body custody audit; no product or worker Python imports."""
import gzip,hashlib,json,os,subprocess,tarfile
from pathlib import Path,PurePosixPath
ROOT=Path.cwd();OUT=ROOT/'target/evidence/virgl-standard-packed-depth-consumer-critic';BB='bb12868a5fceea81acec5a8ff42496e13007ddd8';C60='c60bf20abcd42c1c10fb1863c2666a344d5c8e70'
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(v,m):
 if not v:raise AssertionError(m)
def reopen(folder,destination=None,pins=None):
 mb=(folder/'manifest.json').read_bytes();ib=(folder/'records.json').read_bytes();m=json.loads(mb);index=json.loads(ib);rows=index['records'];expected={r['path']:r for r in rows};need(len(expected)==len(rows),'duplicate index path');need(sha(ib)==m['recordIndexSha256'],'index digest')
 if pins:need(sha(mb)==pins['manifest'] and sha(ib)==pins['index'],'outer pinned bodies')
 stream=b''
 for part in m['archiveParts']:
  b=(folder/part['path']).read_bytes();need(len(b)==part['bytes'] and sha(b)==part['sha256'],'archive part');stream+=b
 need(sha(stream)==m['archiveSha256'],'archive complete digest')
 if pins:need(sha(stream)==pins['archive'],'outer archive pin')
 physical={};seen=set();audit=[];total=0;physical_total=0
 import io
 with tarfile.open(fileobj=io.BytesIO(stream),mode='r|gz') as tar:
  for t in tar:
   name=t.name;p=PurePosixPath(name);need(not p.is_absolute() and '..' not in p.parts and str(p)==name,'unsafe member');need(name in expected and name not in seen,'archive membership '+name);need(t.isfile() or t.islnk(),'archive kind');seen.add(name)
   if t.isfile():
    b=tar.extractfile(t).read();need(len(b)==t.size,'truncated physical body');physical[name]=(b,t.offset);physical_total+=len(b)
   else:
    need(t.linkname in physical,'hardlink does not name prior real physical '+name);b,offset=physical[t.linkname];need(offset<t.offset,'hardlink chronology')
   actual=sha(b);r=expected[name];need(len(b)==r['bytes'] and actual==r['sha256'],'actual complete body differs '+name);total+=len(b)
   audit.append(dict(path=name,bytes=len(b),sha256=actual,kind='file' if t.isfile() else 'hardlink',physical=t.linkname if t.islnk() else name,tarOffset=t.offset))
   if destination:
    target=destination/name;target.parent.mkdir(parents=True,exist_ok=True)
    if t.islnk():os.link(destination/t.linkname,target)
    else:target.write_bytes(b)
 need(seen==set(expected),'archive complete exact membership')
 return dict(folder=str(folder.relative_to(ROOT)),manifestSha256=sha(mb),indexSha256=sha(ib),archiveSha256=sha(stream),logicalMembers=len(seen),physicalMembers=len(physical),logicalBytes=total,physicalBytes=physical_total,records=audit),m
outer,m=reopen(ROOT/'evidence/virgl-packed-depth-consumer/worker',OUT/'worker-reopened',dict(manifest='50d98b1a99ec9ffc0dce2567126a59fa7785536140275c2c62951d47378dfbdb',archive='cee5f6525922a02a14885affebcf763df18468b6434267a251f1a1f5b3e313a4',index='012d2a73e5d3d61db1b98a399ebda30d2d0f8592ec54df06e15a0f9cc6be11cf'))
need(m['sourceHead']==BB and outer['logicalMembers']==61957,'frozen head/full count');(OUT/'outer-reopening-audit.json').write_text(json.dumps(outer,indent=2)+'\n')
source=[];tree=OUT/'worker-reopened'
for f in sorted((tree/'source').rglob('*')):
 if not f.is_file():continue
 n=f.relative_to(tree/'source').as_posix();b=f.read_bytes();g=subprocess.check_output(['git','show',BB+':'+n],cwd=ROOT);need(b==g,'source differs frozen Git '+n);source.append(dict(path=n,bytes=len(b),sha256=sha(b)))
for prefix in ['hot','cold']:
 receipt=json.loads((tree/prefix/'receipt.json').read_bytes());need(receipt['gitHead']==BB and receipt['status']=='passed','receipt frozen/pass')
 for n,h in receipt['sources'].items():
  b=subprocess.check_output(['git','show',BB+':'+n],cwd=ROOT);need(sha(b)==h,'receipt source not frozen '+n)
 for n,h in receipt['generated'].items():need(sha((tree/(prefix+'-generated')/n).read_bytes())==h,'complete generated binary '+n)
 for n,h in receipt['files'].items():need(sha((tree/prefix/n).read_bytes())==h,'receipt complete body '+n)
held=[]
for role in ['worker','verifier']:
 folder=ROOT/'evidence/virgl-packed-depth-images'/role
 h,manifest=reopen(folder)
 for n in ['manifest.json','records.json']+[p['path'] for p in manifest['archiveParts']]:need((folder/n).read_bytes()==subprocess.check_output(['git','show',C60+':'+str(folder.relative_to(ROOT))+'/'+n],cwd=ROOT),'held seal Git drift')
 held.append(h)
need(sum(r['logicalMembers'] for r in held)==43044,'held logical count');(OUT/'held-reopening-audit.json').write_text(json.dumps(dict(predecessor=C60,records=held),indent=2)+'\n')
boundaries={};names=['resources','unorm-depth-images','floating-depth-gpu','floating-depth-images','constant-domain','integer-images','packed-normalized-images','float-images','packed-float-images','shared-exponent-images','shared-exponent-gpu','color-images','packed-unsigned-images']
paths=['renderer/virgl-command/'+n+'.mjs' for n in names]+subprocess.check_output(['git','ls-files','renderer/virgl-shader'],cwd=ROOT,text=True).splitlines()
for n in paths:
 a=subprocess.check_output(['git','show',C60+':'+n],cwd=ROOT);b=subprocess.check_output(['git','show',BB+':'+n],cwd=ROOT);need(a==b,'held code boundary drift '+n);boundaries[n]=sha(b)
cold=json.loads((tree/'cold/report.json').read_text());need(cold['gitHead']==cold['cloneHead']==BB and cold['status']=='passed' and cold['exitCode']==0 and not cold['statusBefore'] and not cold['statusAfter'],'pristine clone custody')
need(sha((tree/'cold/receipt.json').read_bytes())==cold['receiptSha256']==m['coldReceiptSha256'],'cold receipt body')
result=dict(status='passed',sourceHead=BB,predecessor=C60,outer={k:v for k,v in outer.items() if k!='records'},held=[{k:v for k,v in h.items() if k!='records'} for h in held],sources=source,unchangedBoundaries=boundaries,cold=cold,compiler=json.loads((tree/'hot/receipt.json').read_text())['generated'])
(OUT/'custody-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status='passed',outer=outer['logicalMembers'],held=sum(r['logicalMembers'] for r in held),frozenSources=len(source),logicalBytes=outer['logicalBytes'])))
