#!/usr/bin/env python3
"""Extra independent checks: native/public image identity and uniform GPU clears."""
import gzip,hashlib,json,struct
from pathlib import Path
OUT=Path.cwd()/'target/evidence/virgl-standard-packed-depth-consumer-critic';sha=lambda b:hashlib.sha256(b).hexdigest();results=[]
for prefix in ['hot','cold']:
 for file in sorted((OUT/'worker-reopened'/prefix).glob('hardware-*/report.json')):
  d=file.parent;env=json.loads(file.read_text());e=env['browserResult']['result'];blobs={b['key']:b for b in e['blobs']};checks=[];public=0;uniform=0;backingStates=0
  def load(ref):
   b=blobs[ref['key']];z=(d/b['path']).read_bytes();assert sha(z)==b['gzipSha256'];r=gzip.decompress(z);assert len(r)==b['bytes'] and sha(r)==b['sha256']==ref['sha256'];return r
  def same_clear(ref,width,height,point):
   nonlocal_stub=None
   raw=load(ref);bits=[struct.unpack_from('<I',raw,i*16)[0] for i in range(width*height)];assert len(set(bits))==1,point;checks.append(dict(prediction='uniform primary GPU depth clear choice',point=point,bits=bits[0],nativeSha256=ref['sha256'],pixels=width*height));return width*height
  for ri,ref in enumerate(e['runs']):
   raw=(d/ref['path']).read_bytes();assert sha(raw)==ref['sha256'];run=json.loads(raw)
   depthBacking=bytearray(load(run['sourceBacking']))
   for action in run['actions']:
    if action.get('kind')!='depth-public':continue
    assert load(action['backingBefore'])==depthBacking,(prefix,d.name,ref['path'],'original input/prior independently validated public backing state')
    backingStates+=1
    for read in action['reads']:
     observed=load(read['backing']);wire=bytes.fromhex(run['history'][read['historyIndex']]['hex']);w=struct.unpack_from('<13I',wire,4);assert w[0]==6 and w[12]==2
     for y in range(w[9]):
      a=w[11]+y*w[3];b=a+w[8]*4;depthBacking[a:b]=observed[a:b]
     assert observed==depthBacking,(prefix,d.name,ref['path'],'every original input/prior backing byte outside original read region')
     backingStates+=1
   checks.append(dict(prediction='each source backing state equals original inputs plus prior independently validated public native fields, preserving all other bytes',point=ref['path']+':1 actions depth-public',sourceSha256=run['sourceBacking']['sha256']))
   for fi in run['frames']:
    f=e['frames'][fi]
    if 'backing' in f:
     wire=bytes.fromhex(run['history'][f['publicHistory']]['hex']);w=struct.unpack_from('<13I',wire,4);native=load(f['native']);backing=load(f['backing']);assert len(native)==w[8]*w[9]*16
     for y in range(w[9]):assert backing[w[11]+y*w[3]:w[11]+y*w[3]+w[8]*16]==native[y*w[8]*16:(y+1)*w[8]*16],(prefix,d.name,ri,fi,y)
     public+=len(native);checks.append(dict(prediction='exact native/public image word identity beyond normalized original tolerance',point=f'{ref["path"]}:1 frames[{fi}] history[{f["publicHistory"]}]',nativeSha256=f['native']['sha256'],backingSha256=f['backing']['sha256'],nativeBytes=len(native)))
    for event in run['clearEvents']:
     if event['historyIndex']>f['historyIndex']:continue
     for kind in ['bindings','depths']:
      for binding in f.get(kind,[]):
       for p in binding['planes']:
        if p['original']==event['level']:uniform+=same_clear(p['native'],p['width'],p['height'],f'{ref["path"]}:1 frames[{fi}] {kind} mip{p["original"]}')
   for binding in run.get('depthClear',{}).get('depths',[]):
    for p in binding['planes']:
     if p['original']==run['clearEvents'][0]['level']:uniform+=same_clear(p['native'],p['width'],p['height'],f'{ref["path"]}:1 depthClear mip{p["original"]}')
   for kind in ['switchDepths','switchPreserved']:
    for p in run.get(kind,[]):uniform+=same_clear(p['native'],p['width'],p['height'],f'{ref["path"]}:1 {kind} resource{p["resource"]}')
   for action in run['actions']:
    if action.get('kind')!='depth-public':continue
    for p in action['reads']:
     if p.get('nativeChoice'):
      original=run['planes'][p['level']];uniform+=same_clear(p['nativeChoice'],original['width'],original['height'],f'{ref["path"]}:1 depth-public nativeChoice mip{p["level"]}')
  results.append(dict(record=str(file.relative_to(OUT)),status='passed',exactNativePublicImageBytes=public,uniformClearPixels=uniform,originalBackingStates=backingStates,checks=checks))
(OUT/'supplemental-native-public-uniform-audit.json').write_text(json.dumps(dict(status='passed',records=results),indent=2)+'\n');print(json.dumps(dict(status='passed',records=len(results),exactNativePublicImageBytes=sum(r['exactNativePublicImageBytes'] for r in results),uniformClearPixels=sum(r['uniformClearPixels'] for r in results),originalBackingStates=sum(r['originalBackingStates'] for r in results))))
