#!/usr/bin/env python3
"""Independent original wire field and unchanged refusal audit; no product import."""
import hashlib,json,struct,subprocess
from pathlib import Path
OUT=Path.cwd()/'target/evidence/virgl-standard-packed-depth-consumer-critic';sha=lambda b:hashlib.sha256(b).hexdigest();BASE='c60bf20abcd42c1c10fb1863c2666a344d5c8e70';BB='bb12868a5fceea81acec5a8ff42496e13007ddd8';records=[]
negative=Path('evidence/virgl-production-readiness/standard-packed-depth-consumer-gap.json');raw=negative.read_bytes();assert sha(raw)=='5942c360ab065ee349e815df71c49c95b09f54febdd1871b93dcd22b4c0b58f2';n=json.loads(raw);assert n['gitHead']==BASE and len(n['rows'])==6 and not n['nativeExecuted']
for row in n['sources']:
 original=subprocess.check_output(['git','show',BASE+':'+row['path']]);assert sha(original)==row['sha256'];assert original==subprocess.check_output(['git','show',BB+':'+row['path']]) or row['path'] in ['renderer/virgl-command/decoder.mjs','renderer/virgl-command/state.mjs']
for prefix in ['hot','cold']:
 p=OUT/'worker-reopened'/prefix/'wire/report.json';env=json.loads(p.read_text());rows=env['wire']['records'];assert len(rows)==22
 accepted=refused=old=0;points=[]
 for index,row in enumerate(rows):
  b=bytes.fromhex(row['hex']);w=struct.unpack('<'+'I'*(len(b)//4),b);assert w[0]>>16==len(w)-1;kind=w[0]>>8&255;result=row['result'];valid=row['kind'] in ['base-view','swizzled-private-view','mip-surface'];assert result['ok']==valid
  if valid:
   assert w[0]&255==1 and w[2]==6;fmt=w[3]&0xffffff;assert fmt==row['format'] in [20,21];assert result['profile']=='virgl-standard-packed-depth-image-commands-v1'
   if kind==6:
    assert w[3]>>24==2 and w[4]==0;first,last=w[5]&255,w[5]>>8&255;swizzle=[w[6]>>(i*3)&7 for i in range(4)];assert (first,last,swizzle)==((0,0,[0,1,2,3]) if row['kind']=='base-view' else (1,3,[2,4,0,5]))
    expected=dict(handle=w[1],resourceHandle=w[2],format=fmt,target=2,firstLayer=0,lastLayer=0,firstLevel=first,lastLevel=last,swizzle=swizzle)
   else:
    assert kind==8 and w[4]==2 and w[5]==0;expected=dict(handle=w[1],resourceHandle=w[2],format=fmt,level=2,firstLayer=0,lastLayer=0)
   assert result['commands'][0]['fields']==expected;assert len(row['refusals'])==15
   for refusal in row['refusals']:assert refusal['result']['ok'] is False and refusal['result']['error']['code']=='unsupported-feature';old+=1
   accepted+=1
  else:assert result['error']['code'] in ['unsupported-feature','invalid-enum','invalid-value'];refused+=1
  points.append(dict(index=index,kind=row['kind'],format=row.get('format'),originalHex=row['hex'],originalWords=w,observedResult=result,oldDecoderRefusals=len(row.get('refusals',[]))))
 assert (accepted,refused,old)==(6,16,90);records.append(dict(record=str(p.relative_to(OUT)),sha256=sha(p.read_bytes()),accepted=accepted,refused=refused,unchangedRefusals=old,points=points))
audit=dict(status='passed',negative=dict(path=str(negative),sha256=sha(raw),head=BASE,originalRefusals=6,nativeExecuted=False),records=records)
(OUT/'original-admission-audit.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(dict(status='passed',gates=2,acceptedPerGate=6,refusedPerGate=16,oldDecoderRefusalsPerGate=90)))
