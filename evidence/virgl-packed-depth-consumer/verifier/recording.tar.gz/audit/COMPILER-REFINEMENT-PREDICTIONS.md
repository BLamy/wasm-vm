# Additional shader custody prediction and refinement

The initial additional custody prediction required queried native shader bodies to equal a raw successful compiler pair verbatim. It FAILED at hot hardware-boundaries-0x13579bdf/run-0001.json draw 0, floating-sample-draw-1-first. This observation and the initial script/log are preserved.

Before inspecting corresponding remaining event bodies, predict:
1. Both the vertex and fragment bodies of every successful recorded native draw equal a full string passed to a recorded actual native shaderSource call on the same shader object.
2. Each such native body comes from a successful actual compiler pair body, either verbatim or through the unchanged view-swizzle wrapper defined by original bound views. The original native draw bindings select the same slots, stages and original swizzle. No different sampled arithmetic is introduced. The wrapper emitter and integration hunks are byte-identical at independently verified C60 and frozen BB.
3. The initial differing fragment at original slot15 uses only replicated original R and literal one, matching independently parsed original wire swizzle [0,0,0,5]. The emitted native body therefore has precisely one wrapper, without a replacement expected-image oracle.
4. Independent original TGSI/input/native/public numerical predictions stay unchanged. Raw compiler string identity was an additional model assumption and cannot become an unstated product requirement; if actual native calls lack this retained-source provenance, classify the added custody check NEEDS EVIDENCE.
