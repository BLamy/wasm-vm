import assert from 'node:assert/strict';
import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {runSignedConversionRegressions} from '../../../renderer/virgl-shader/tests/signed-conversion-regressions.mjs';
import {createVirglShaderBridge} from './scratch/current/renderer/virgl-shader/index.mjs';

const head = ['FRAG', 'DCL OUT[0], COLOR', 'DCL TEMP[0..2]', 'DCL CONST[0..45]', 'DCL ADDR[0]',
  'IMM[0] UINT32 {7,7,7,7}', 'IMM[1] UINT32 {0,0,0,0}', 'IMM[2] UINT32 {1056964608,1056964608,1056964608,1056964608}'];
const program = body => [...head, ...body, 'END', ''].join('\n');
const cases = [];
const add = (name, body, ok, extra = {}) => cases.push({name, stage: 'fragment', text: program(body), ok, ...extra});
for (const [name, source] of [['plain', 'CONST[ADDR[0].x]'], ['negated', '-CONST[ADDR[0].x]'],
  ['absolute', '|CONST[ADDR[0].x]|'], ['negative-absolute', '-|CONST[ADDR[0].x]|']]) {
  add('unproven-indirect-F2I-' + name, ['UARL ADDR[0].x, IMM[1].xxxx', `F2I TEMP[0], ${source}`, 'MOV OUT[0], IMM[2]'], false);
}
add('defined-total-indirect-I2F', ['UARL ADDR[0].x, IMM[1].xxxx', 'I2F OUT[0], CONST[ADDR[0].x]'], true, {noRangeBank: true});
add('bounded-indirect-computed-F2I', ['UARL ADDR[0].x, IMM[1].xxxx', 'AND TEMP[0], CONST[ADDR[0].x], IMM[0]',
  'F2I TEMP[1], TEMP[0]', 'MOV OUT[0], TEMP[1]'], true, {noRangeBank: true});
for (const source of ['-IMM[0]', '|IMM[0]|', '-|IMM[0]|']) {
  add('unsupported-integer-modifier-' + source, [`I2F TEMP[0], ${source}`, 'MOV OUT[0], IMM[2]'], false);
}
for (const opcode of ['I2F0', 'F2I0', 'I2F_SAT', 'F2I_SAT', 'I2F_PRECISE', 'F2I_PRECISE', 'i2f', 'f2i']) {
  add('lexical-' + opcode, [`${opcode} TEMP[0], IMM[0]`, 'MOV OUT[0], IMM[2]'], false);
}
for (const opcode of ['SIN', 'TRUNC', 'POW']) {
  add('still-forbidden-' + opcode, ['I2F TEMP[1], IMM[0]', `${opcode} TEMP[0], IMM[0]${opcode === 'POW' ? ', IMM[0]' : ''}`, 'MOV OUT[0], IMM[2]'], false);
}
const binary = new URL('./scratch/current/renderer/virgl-shader/build/native/virgl-shader', import.meta.url);
const bridge = await createVirglShaderBridge();
const native = runSignedConversionRegressions(({stage, text}) => JSON.parse(execFileSync(fileURLToPath(binary), [stage], {input: text})), cases);
const wasm = runSignedConversionRegressions(request => bridge.translate(request), cases);
for (let i = 0; i < cases.length; i++) assert.deepEqual(native[i].result, wasm[i].result);
const report = {schema: 'critic-conversion-boundary-attacks-v1', task: 'E6-T12g6e', status: 'passed', cases: cases.length,
  nativeBinarySha256: createHash('sha256').update(fs.readFileSync(binary)).digest('hex'), native, wasm};
fs.writeFileSync(new URL('./boundary-attacks.json', import.meta.url), JSON.stringify(report, null, 2) + '\n');
console.log(`${cases.length} independent indirect/modifier/lexical/opcode boundaries passed native/Wasm.`);
