import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {parseConstantDomain, checkConversionBank, signedConversionBinary32Word} from '../../../renderer/virgl-command/constant-domain.mjs';

const input = new URL('./unpacked/hot/native/report.json', import.meta.url);
const native = JSON.parse(fs.readFileSync(input));
const report = {schema: 'critic-conversion-consumer-attacks-v1', task: 'E6-T12g6e', status: 'running',
  sourceSha256: createHash('sha256').update(fs.readFileSync(new URL('../../../renderer/virgl-command/constant-domain.mjs', import.meta.url))).digest('hex'),
  nativeSha256: createHash('sha256').update(fs.readFileSync(input)).digest('hex'), metadata: [], banks: [], words: [], getterCalls: 0};
const inert = value => {
  if (value === null || typeof value !== 'object') return value;
  const copy = Array.isArray(value) ? [] : {};
  for (const [key, d] of Object.entries(Object.getOwnPropertyDescriptors(value))) {
    if (d.enumerable) copy[key] = Object.hasOwn(d, 'value') ? inert(d.value) : '[accessor]';
  }
  return copy;
};
const failedMetadata = (metadata, stage, name) => {
  const result = parseConstantDomain(metadata, stage);
  report.metadata.push({name, predicted: 'closed rejection without getter access', metadata: inert(metadata), result});
  assert.equal(result.ok, false, name);
  assert.equal(result.error.code, 'shader-domain-error', name);
};
for (const c of native.cases.filter(c => c.ok)) {
  const original = c.result.metadata;
  const contract = parseConstantDomain(original, c.stage);
  assert.equal(contract.ok, true);
  for (const key of ['conversionBaseProfile', 'signedConversionContract', 'profile']) {
    const forged = structuredClone(original);
    Object.defineProperty(forged, key, {enumerable: true, get() { report.getterCalls++; return original[key]; }});
    failedMetadata(forged, c.stage, c.name + '/top accessor ' + key);
  }
  const symbols = structuredClone(original);
  symbols.signedConversionContract.operations[Symbol('untrusted')] = 'I2F';
  failedMetadata(symbols, c.stage, c.name + '/symbol operation property');
  const inherited = structuredClone(original);
  delete inherited.signedConversionContract.domain;
  Object.setPrototypeOf(inherited.signedConversionContract, {domain: original.signedConversionContract.domain});
  failedMetadata(inherited, c.stage, c.name + '/inherited policy domain');
  if (!contract.conversionDomain) continue;
  const domain = contract.conversionDomain;
  const attacks = [
    ['negative register', d => d.components[0].register = -1],
    ['boolean register', d => d.components[0].register = true],
    ['fractional register', d => d.components[0].register = 1.5],
    ['guest-excluded register46', d => d.components[0].register = 46],
    ['zero mask', d => d.components[0].mask = 0],
    ['boolean mask', d => d.components[0].mask = true],
    ['wide mask', d => d.components[0].mask = 16],
    ['duplicate register', d => d.components.push({...d.components[0]})],
    ['unsorted registers', d => d.components = [{register: 45, mask: 1}, {register: 0, mask: 1}]],
    ['empty components', d => d.components = []],
    ['sparse components', d => { d.components = Array(1); }],
    ['extra component property', d => d.components[0].untrusted = true],
    ['extra component array property', d => d.components.extra = 1],
    ['accessor mask', d => Object.defineProperty(d.components[0], 'mask', {enumerable: true, get() { report.getterCalls++; return 15; }})],
    ['accessor component', d => Object.defineProperty(d.components, '0', {enumerable: true, get() { report.getterCalls++; return {register: 0, mask: 15}; }})],
    ['empty bank extent', d => d.count = 0],
    ['oversized bank extent', d => d.count = 48],
    ['boolean bank extent', d => d.count = true],
    ['fractional bank extent', d => d.count = 2.5],
  ];
  for (const [name, change] of attacks) {
    const forged = structuredClone(original);
    change(forged.constantConversionDomains[0]);
    failedMetadata(forged, c.stage, c.name + '/' + name);
  }
  const words = Array(Math.min(domain.count, 46) * 4).fill(0);
  if (contract.radialDomain) words[16] = 0x3f800000;
  const check = (name, bank, d, base, wanted) => {
    const result = checkConversionBank(bank, d, base);
    report.banks.push({name: c.name + '/' + name, predicted: wanted, bank: inert(bank), domain: inert(d), base: inert(base), result});
    assert.equal(result.ok, wanted, name);
    return result;
  };
  const owned = check('one frozen owned prefix', words, domain, contract, true);
  const saved = words.slice();
  words.fill(0x4f000000);
  assert.deepEqual(owned.words, saved);
  assert.equal(Object.isFrozen(owned.words), true);
  check('false base approval', saved, domain, {...contract, ok: false}, false);
  check('invalid direct component contract', saved, {...domain, components: [{register: 46, mask: 1}]}, contract, false);
  for (const key of ['domain', 'access', 'constraint', 'radialDomain', 'rasterDomain']) {
    if (!contract[key]) continue;
    check('mismatched base extent ' + key, saved, domain, {...contract, [key]: {...contract[key], count: contract[key].count + 1}}, false);
  }
  const hostileWords = saved.slice();
  Object.defineProperty(hostileWords, '0', {enumerable: true, get() { report.getterCalls++; return 0; }});
  check('accessor bank word', hostileWords, domain, contract, false);
}
const v = new DataView(new ArrayBuffer(4));
for (const input of [0, 0x80000000, 1, 0x80000001, 0x3f7fffff, 0xbf7fffff, 0x4effffff, 0xceffffff,
  0xcf000000, 0x4f000000, 0xcf000001, 0x7f800000, 0xff800000, 0x7fc12345, 0xffc12345, true, -1, 1.5]) {
  const proper = typeof input === 'number' && Number.isInteger(input) && input >= 0 && input <= 0xffffffff;
  v.setUint32(0, proper ? input : 0, true);
  const f = v.getFloat32(0, true);
  const predicted = proper && Number.isFinite(f) && f >= -(2 ** 31) && f < 2 ** 31;
  const observed = signedConversionBinary32Word(input);
  report.words.push({input, predicted, observed});
  assert.equal(observed, predicted);
}
// Cover the defensive unexpected-exception propagation with a scoped intrinsic
// fault. This alters no shader or metadata and is restored before any next call.
const sample = native.cases.find(c => c.ok && c.result.metadata.constantConversionDomains);
const contract = parseConstantDomain(sample.result.metadata, sample.stage);
const originalInteger = Number.isInteger, error = new Error('critic scoped intrinsic fault');
try {
  Number.isInteger = () => { throw error; };
  assert.throws(() => checkConversionBank([], contract.conversionDomain, contract), thrown => thrown === error);
  report.foreignException = {predicted: 'same exception identity propagates', name: error.name, message: error.message, held: true};
} finally {
  Number.isInteger = originalInteger;
}
assert.equal(report.getterCalls, 0);
report.status = 'passed';
fs.writeFileSync(new URL('./consumer-attacks.json', import.meta.url), JSON.stringify(report, null, 2) + '\n');
console.log(`${report.metadata.length} independent metadata attacks, ${report.banks.length} direct owned-bank attacks, zero getter calls.`);
