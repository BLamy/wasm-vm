import bisect,hashlib,json,pathlib,subprocess
R=pathlib.Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');O=pathlib.Path('/tmp/d23-independent-verifier');U=O/'unpacked'; boundary=json.loads((R/'tools/virgl-standard-texture/boundary.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
products={x['path']:x for x in boundary['files']}; texts={n:(R/n).read_text() for n in products}; offsets={n:[0] for n in products}
for n,s in texts.items():
 for line in s.splitlines(keepends=True):offsets[n].append(offsets[n][-1]+len(line))
def pos(name,l,c):return offsets[name][l-1]+c-1
def relevant(name):return name in products
llvm={n:[] for n in products};v8={n:[] for n in products};sources=[]
for prefix in ['hot','cold']:
 base=U/prefix
 for f in sorted((base/'coverage').glob('*.json')):
  d=json.loads(f.read_text());digest=sha(f.read_bytes())
  for fn in d['data'][0]['functions']:
   for k,name in enumerate(fn['filenames']):
    match=next((n for n in products if name.endswith('/'+n)),None)
    if not match:continue
    regs=[]
    for z in fn['regions']:
     if z[5]!=k or z[7]!=0:continue
     a,b=pos(match,z[0],z[1]),pos(match,z[2],z[3]);
     if a<b:regs.append({'start':a,'end':b,'count':z[4],'region':z})
    llvm[match].append({'record':str(f.relative_to(U)),'digest':digest,'function':fn['name'],'functionCount':fn['count'],'regions':regs})
 for f in [base/'node-coverage-runtime.json',*base.glob('*/browser-coverage.json')]:
  data=json.loads(f.read_text())
  for row in data['scripts']:
   n=row['source'];assert sha((R/n).read_bytes())==row['sha256'],n
   if not relevant(n):continue
   regs=[]
   for fn in row['coverage']['functions']:
    for z in fn['ranges']:regs.append({'start':z['startOffset'],'end':z['endOffset'],'count':z['count'],'function':fn['functionName'],'block':fn['isBlockCoverage']})
   v8[n].append({'record':str(f.relative_to(U)),'digest':sha(f.read_bytes()),'regions':regs})
report={'schema':'independent-d23-full-region-audit-v1','predictionsSha256':sha((O/'predictions.json').read_bytes()),'files':[]}
for n,entry in products.items():
 s=texts[n]; rows=[]
 for i,c in enumerate(entry['changes']):
  if not c['after']:continue
  start=offsets[n][c['afterLine']-1]; end=start+len(c['after']);datasets=v8[n] if n.endswith('.mjs') else llvm[n]
  cuts={start,end}
  for data in datasets:
   for z in data['regions']:
    if start<z['start']<end:cuts.add(z['start'])
    if start<z['end']<end:cuts.add(z['end'])
  cuts=sorted(cuts);regions=[]
  for a,b in zip(cuts,cuts[1:]):
   segment=s[a:b];observed=[]
   for data in datasets:
    contains=[z for z in data['regions'] if z['start']<=a and b<=z['end']]
    if contains:
     smallest=min(z['end']-z['start'] for z in contains);best=[z for z in contains if z['end']-z['start']==smallest]
     z=min(best,key=lambda x:x['count'])
     observed.append({'record':data['record'],'count':z['count'],'function':data.get('function',z.get('function')),'region':z.get('region',[z['start'],z['end']])})
   meaningful=bool(segment.strip());count=max((z['count'] for z in observed),default=0)
   regions.append({'startLine':bisect.bisect_right(offsets[n],a),'endLine':bisect.bisect_right(offsets[n],b-1),'startOffset':a,'endOffset':b,'text':segment,'count':count,'meaningful':meaningful,'counters':observed})
  rows.append({'migration':i,'afterLine':c['afterLine'],'beforeLine':c['beforeLine'],'intervals':regions})
 report['files'].append({'source':n,'sha256':sha(s.encode()),'llvmFunctionRecords':len(llvm[n]),'v8ScriptRecords':len(v8[n]),'migrations':rows})
(O/'coverage-regions.json').write_text(json.dumps(report,indent=2)+'\n')
for file in report['files']:
 zeros=[(m['migration'],z['startLine'],z['endLine'],z['text'].strip().replace('\n',' ')[:180]) for m in file['migrations'] for z in m['intervals'] if z['meaningful'] and not z['count']]
 print(json.dumps({'source':file['source'],'llvmFunctionRecords':file['llvmFunctionRecords'],'v8ScriptRecords':file['v8ScriptRecords'],'zeroMeaningful':zeros}))
