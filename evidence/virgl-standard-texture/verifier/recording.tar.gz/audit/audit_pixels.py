import collections,gzip,hashlib,json,math,pathlib,re,struct
O=pathlib.Path('/tmp/d23-independent-verifier');U=O/'unpacked';sha=lambda x:hashlib.sha256(x).hexdigest();shrink=lambda n,l:max(1,n//(1<<l))
def immediate(text):
 out={}
 for m in re.finditer(r'^IMM\[(\d+)\]\s+(FLT32|INT32|UINT32)\s*\{([^}]+)\}',text,re.M):
  values=[float(s) if m[2]=='FLT32' else int(s,0) for s in m[3].split(',')]
  if m[2]=='FLT32':values=list(struct.unpack('<4f',struct.pack('<4f',*values)))
  out[int(m[1])]=values
 return out
def source_value(term,immediates):
 neg=term.startswith('-');term=term.removeprefix('-');absolute=term.startswith('|') and term.endswith('|');term=term[1:-1] if absolute else term
 m=re.fullmatch(r'IMM\[(\d+)\](?:\.([xyzw]+))?',term);assert m,term
 value=immediates[int(m[1])];sw=m[2] or 'xyzw';sw=sw*4 if len(sw)==1 else sw;values=[value['xyzw'.index(c)] for c in sw]
 if absolute:values=[abs(v) for v in values]
 if neg:values=[-v for v in values]
 return values

def audit_frame(frame,blobs,native,cases):
 c=cases[frame['nativeIndex']];assert (c['a'],c['b'],c['selectors'])==(frame['vertexText'],frame['fragmentText'],frame['selectors']);assert frame['pair']==native[frame['nativeIndex']]['result'];assert frame['logs']=={'vertex':'','fragment':'','link':''} or all(not v for v in frame['logs'].values())
 text=frame['vertexText'] if frame['stage']=='vertex' else frame['fragmentText'];im=immediate(text)
 found=re.findall(r'^\d+:\s+(TXL|TXF|TXD|TXB|TXQ)((?:_SAT|_PRECISE)*)\s+([^\n]+)',text,re.M);assert len(found)==1
 op,flags,terms=found[0];terms=[x.strip() for x in terms.split(',')];dest,srcs,target=terms[0],terms[1:-1],terms[-1];assert op==frame['opcode'] and target=='2D' and srcs[-1]=='SAMP['+str(frame['slot'])+']'
 w,h,levels=frame['width'],frame['height'],frame['levels'];assert (w,h)==(shrink(frame['resourceWidth'],frame['firstLevel']),shrink(frame['resourceHeight'],frame['firstLevel']));assert levels==frame['lastLevel']-frame['firstLevel']+1
 texels=0;planes=[];assert len(frame['planes'])==levels
 for l,p in enumerate(frame['planes']):
  assert p['level']==l and (p['width'],p['height'])==(shrink(w,l),shrink(h,l));expected_internal={'unorm':32856,'snorm':36759,'srgb':35907}[frame['kind']];expected_type=5120 if frame['kind']=='snorm' else 5121
  assert p['internal']==expected_internal and p['type']==p['readType']==expected_type and p['arrayType']==('Int8Array' if expected_type==5120 else 'Uint8Array')
  original,stored=blobs[p['original']],blobs[p['native']];assert len(original)==len(stored)==p['width']*p['height']*4
  norm=lambda b:max(-1,(b-256 if b>=128 else b)/127)
  assert original==stored or (frame['kind']=='snorm' and all(norm(a)==norm(b) for a,b in zip(original,stored)))
  planes.append((p['width'],p['height'],original));texels+=p['width']*p['height']
 attrs={}
 for a in frame['attributes']:
  assert a['type']==5126 and a['offset']==0 and blobs[a['original']]==blobs[a['native']];raw=blobs[a['original']];assert len(raw)==96;attrs[a['index']]=struct.unpack('<24f',raw)
 assert attrs[0]==(-1.,-1.,0.,1.,1.,-1.,0.,1.,-1.,1.,0.,1.,-1.,1.,0.,1.,1.,-1.,0.,1.,1.,1.,0.,1.)
 def texel(l,x,y):
  pw,ph,raw=planes[l];assert 0<=x<pw and 0<=y<ph;values=[]
  for i,b in enumerate(raw[(y*pw+x)*4:(y*pw+x)*4+4]):
   if frame['kind']=='snorm':v=norm(b)
   elif frame['kind']=='srgb' and i<3:
    n=b/255;v=n/12.92 if n<=0.04045 else ((n+0.055)/1.055)**2.4
   else:v=b/255
   values.append(v)
  return values
 def sample(l,u,v):
  pw,ph,_=planes[l];clamp=lambda n,maxi:max(0,min(maxi-1,n))
  if not frame['linear']:return texel(l,clamp(math.floor(u*pw),pw),clamp(math.floor(v*ph),ph))
  px,py=u*pw-0.5,v*ph-0.5;x,y=math.floor(px),math.floor(py);fx,fy=px-x,py-y
  result=[0.0]*4
  for ox,oy,weight in [(0,0,(1-fx)*(1-fy)),(1,0,fx*(1-fy)),(0,1,(1-fx)*fy),(1,1,fx*fy)]:
   vtx=texel(l,clamp(x+ox,pw),clamp(y+oy,ph));result=[a+weight*b for a,b in zip(result,vtx)]
  return result
 fw,fh=frame['frameWidth'],frame['frameHeight'];output=blobs[frame['pixels']];assert len(output)==fw*fh*16;values=struct.unpack('<'+'f'*(fw*fh*4),output);mismatches=[];maxerror=0;query_mask=None
 for y in range(fh):
  for x in range(fw):
   if op=='TXQ':
    lod=source_value(srcs[0],im)[0];assert isinstance(lod,int) and 0<=lod<levels;mask=dest.split('.')[-1] if '.' in dest else 'xyzw';assert 'z' not in mask;query_mask=mask
    initial=re.search(r'^\d+: MOV TEMP\[0\], IMM\[(\d+)\]$',text,re.M);assert initial;expected=list(im[int(initial[1])]);defined=[shrink(w,lod),shrink(h,lod),None,levels]
    for lane in mask:expected['xyzw'.index(lane)]=defined['xyzw'.index(lane)]
    assert len(frame['queries'])==int('w' in mask)
    for q in frame['queries']:
     assert q['index']==frame['slot'] and q['name']==('vs' if frame['stage']=='vertex' else 'fs')+'samplevels'+str(frame['slot']) and q['type']=='int' and q['semantic']=='TEXTURE_LEVELS';assert q['expected']==levels and q['nativeType']==5124 and q['actual']==q['readback']
     assert q['readback']==levels+(1 if frame['fault']=='query-levels' else 0)
   elif op=='TXF':
    ix,iy,_,lod=source_value(srcs[0],im);assert all(isinstance(n,int) for n in [ix,iy,lod]) and 0<=lod<levels;expected=texel(lod,ix,iy)
   else:
    if op=='TXB':
     assert srcs[0]=='IN[0]' and frame['stage']=='fragment';a=attrs[1];assert a[0:3]==(0.,0.,0.) and a[4:7]==(1.,0.,0.) and a[8:11]==(0.,1.,0.);bias=a[3];assert all(a[i]==bias for i in [7,11,15,19,23]);u,v=(x+.5)/fw,(y+.5)/fh;rho=max(w/fw,h/fh);lod=math.log2(rho)+bias
    else:
     u,v,_,lod=source_value(srcs[0],im)
     if op=='TXD':
      dx,dy=source_value(srcs[1],im),source_value(srcs[2],im);rho=max(math.sqrt((w*dx[0])**2+(h*dx[1])**2),math.sqrt((w*dy[0])**2+(h*dy[1])**2));assert rho>0;lod=math.log2(rho)
    mip=max(0,min(levels-1,math.floor(lod+.5)));expected=sample(mip,u,v)
   if '_SAT' in flags:expected=[max(0,min(1,a)) for a in expected]
   tolerance=0 if op=='TXQ' else .005 if frame['kind']=='srgb' else .0003 if frame['linear'] else .00002
   for lane,exp in enumerate(expected):
    got=values[(y*fw+x)*4+lane];error=abs(got-exp);maxerror=max(maxerror,error)
    if not math.isfinite(got) or error>tolerance:
     if len(mismatches)<12:mismatches.append({'x':x,'y':y,'lane':lane,'predicted':exp,'observed':got,'tolerance':tolerance})
 fence=frame['gpuComplete'];assert fence['submitted'] and fence['fenced'] and fence['status'] in [37146,37148] and fence['waits']>=1 and frame['cleaned'] and frame['calls']==[{'name':'drawArrays','mode':4,'first':0,'count':6}]
 # Native sampler reflection may preserve a declared textureSize operand even when only w is consumed.
 return {'name':frame['name'],'opcode':op,'stage':frame['stage'],'slot':frame['slot'],'pixels':fw*fh,'words':len(values),'texels':texels,'held':not mismatches,'maxError':maxerror,'mismatches':mismatches,'fence':fence,'queryMask':query_mask,'nativeQueries':frame['queries']}
rows=[]
for prefix in ['hot','cold']:
 base=U/prefix;native=[json.loads(x) for x in (base/'native/native.jsonl').read_text().splitlines()];cases=json.loads((base/'native/cases.json').read_text())['cases']
 for gate in ['hardware','fault-lod-selection','fault-gradient-state','fault-query-levels']:
  path=base/gate/'report.json';report=json.loads(path.read_text());acc=report['acceptance'];fault=gate!='hardware';assert report['status']==('failed' if fault else 'passed') and report['gitHead']=='bd1f39244d74a86a811a064eaa4e9a8989bcee8c' and report['trackedChanges']==[] and report['browserErrors']=={'console':[],'page':[],'requests':[]};assert 'Apple M4 Max' in acc['gl']['renderer'] and 'Metal' in acc['gl']['renderer']
  browser=report['browser'];assert not browser['launch']['headless'] and browser['gpu']['featureStatus'][browser['webglFeature']]=='enabled';assert not any(any(bad in a.lower() for bad in ['swiftshader','llvmpipe','lavapipe','softpipe']) or a.startswith('--disable-gpu') for a in browser['actualCommandLine']);assert not acc['guestExecution'] and not acc['productionNegotiation']
  blobs={}
  for b in acc['blobs']:
   zipped=(path.parent/b['path']).read_bytes();assert sha(zipped)==b['gzipSha256'];raw=gzip.decompress(zipped);assert sha(raw)==b['sha256'] and len(raw)==b['bytes'] and b['key'] not in blobs;blobs[b['key']]=raw
  audits=[audit_frame(f,blobs,native,cases) for f in acc['frames']];assert len(audits)==(1 if fault else 246);assert all(a['held']!=fault for a in audits)
  if not fault:
   assert len(acc['compiles'])==909
   for stage in acc['compiles']:
    c=cases[stage['case']];n=native[stage['case']]['result'];body=n[stage['stage']] if 'vertex' in n else n;assert stage['source']==body['glsl'] and stage['metadata']==body['metadata'] and stage['okay'] and not stage['log']
  else:assert 'original texture pixels after consumed fence' in acc['error']
  rows.append({'record':str(path.relative_to(U)),'sha256':sha(path.read_bytes()),'healthy':not fault,'nativeCompiles':len(acc['compiles']),'frames':audits,'fullBlobBodies':len(blobs),'pixels':sum(a['pixels'] for a in audits),'words':sum(a['words'] for a in audits),'texels':sum(a['texels'] for a in audits)})
report={'status':'passed','independentOriginalInputOracle':True,'workerOracleImported':False,'reports':rows,'pixels':sum(a['pixels'] for a in rows),'words':sum(a['words'] for a in rows),'texels':sum(a['texels'] for a in rows),'frames':sum(len(a['frames']) for a in rows)};(O/'pixel-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='reports'}))
