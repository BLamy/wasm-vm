import hashlib,json,os,pathlib,subprocess
O=pathlib.Path('/tmp/d23-independent-verifier');U=O/'unpacked';D=O/'native-replay';D.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();env=dict(os.environ);env.update(ASAN_OPTIONS='abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1');runs=[]
for mode in ['native','sanitize','allocation-sanitize']:
 binary=U/'hot-generated/renderer/virgl-shader/build'/('standard-texture-'+mode)/('standard-texture-'+('allocation-test' if mode=='allocation-sanitize' else 'test'));binary.chmod(0o755);profile=D/(mode+'.profraw');env['LLVM_PROFILE_FILE']=str(profile)
 out=D/(mode+'.jsonl');err=D/(mode+'.stderr');args=[str(binary)]+([] if mode=='allocation-sanitize' else [str(U/'hot/native/cases.bin')])
 with out.open('wb') as f,err.open('wb') as e:result=subprocess.run(args,stdout=f,stderr=e,env=env,timeout=60)
 assert result.returncode==0 and not err.read_bytes();expected=U/('hot/native/allocations.jsonl' if mode=='allocation-sanitize' else 'hot/native/native.jsonl');assert out.read_bytes()==expected.read_bytes()
 item={'mode':mode,'binarySha256':sha(binary.read_bytes()),'outputSha256':sha(out.read_bytes()),'outputBytes':out.stat().st_size,'exitCode':result.returncode,'stderrBytes':0,'byteExact':True}
 if mode!='native':
  merged=D/(mode+'.profdata');export=D/(mode+'-coverage.json');subprocess.run(['xcrun','llvm-profdata','merge','-sparse',str(profile),'-o',str(merged)],check=True,capture_output=True)
  with export.open('wb') as f:subprocess.run(['xcrun','llvm-cov','export',str(binary),'-instr-profile='+str(merged)],stdout=f,check=True)
  item['independentCoverageSha256']=sha(export.read_bytes());item['profileSha256']=sha(profile.read_bytes())
 runs.append(item)
report={'status':'passed','authenticatedBinariesExecuted':True,'sourceHead':'bd1f39244d74a86a811a064eaa4e9a8989bcee8c','runs':runs};(O/'native-replay.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
