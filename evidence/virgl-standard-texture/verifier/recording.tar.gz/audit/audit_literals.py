import collections,hashlib,json,pathlib,re,struct
R=pathlib.Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');O=pathlib.Path('/tmp/d23-independent-verifier');U=O/'unpacked';sha=lambda b:hashlib.sha256(b).hexdigest()
h=(R/'renderer/virgl-shader/vendor/src/gallium/include/pipe/p_shader_tokens.h').read_text()
def enum(name):
 body=re.search(r'\benum\s+'+name+r'\s*\{(.*?)\}',h,re.S)[1];body=re.sub(r'/\*.*?\*/|//[^\n]*','',body,flags=re.S);result={};n=0
 for part in body.split(','):
  m=re.fullmatch(r'\s*(\w+)(?:\s*=\s*(\d+))?\s*',part)
  if m:
   if m[2]:n=int(m[2])
   result[m[1]]=n;n+=1
 return result
ops,files,targets,types=[enum(x) for x in ['tgsi_opcode','tgsi_file_type','tgsi_texture_type','tgsi_imm_type']]
arity={'TEX':2,'TXL':2,'TXF':2,'TXD':4,'TXB':2,'TXQ':2};op_hist=collections.Counter();mods=collections.Counter();results=[]
def tokens(text):
 imm=[]
 for m in re.finditer(r'^IMM\[(\d+)\]\s+(FLT32|INT32|UINT32)\s*\{([^}]+)\}',text,re.M):
  words=[]
  for v in m[3].split(','):
   v=v.strip()
   if m[2]=='FLT32' and not re.match(r'[-+]?0[xX]',v):word=struct.unpack('<I',struct.pack('<f',float(v)))[0]
   else:word=int(v,0) & 0xffffffff
   words.append(word)
  assert len(words)==4
  imm.append({'index':int(m[1]),'type':types[{'FLT32':'TGSI_IMM_FLOAT32','INT32':'TGSI_IMM_INT32','UINT32':'TGSI_IMM_UINT32'}[m[2]]],'words':words})
 tex=[]
 for m in re.finditer(r'^\s*(\d+):\s+(TEX|TXL|TXF|TXD|TXB|TXQ)((?:_SAT|_PRECISE)*)\s+([^\n]+)',text,re.M):
  terms=[x.strip() for x in m[4].split(',')];dest=terms.pop(0);target=terms.pop();assert target=='2D' and len(terms)==arity[m[2]]
  mask=dest.split('.')[-1] if '.' in dest else 'xyzw';sources=[]
  for term in terms:
   neg=term.startswith('-');term=term.removeprefix('-');absolute=term.startswith('|') and term.endswith('|');term=term[1:-1] if absolute else term
   reg=re.fullmatch(r'(IMM|IN|TEMP|CONST|SAMP|SV)\[(\d+)\](?:\[(\d+)\])?(?:\.([xyzw]{1,4}))?',term);assert reg,term
   register={'IMM':'IMMEDIATE','IN':'INPUT','TEMP':'TEMPORARY','CONST':'CONSTANT','SAMP':'SAMPLER','SV':'SYSTEM_VALUE'}[reg[1]];swiz=reg[4] or 'xyzw';swiz=swiz*4 if len(swiz)==1 else swiz;assert len(swiz)==4
   sources.append({'file':files['TGSI_FILE_'+register],'index':int(reg[3] or reg[2]),'slot':int(reg[2]) if reg[3] else 0,'negate':int(neg),'absolute':int(absolute),'swizzle':['xyzw'.index(x) for x in swiz],'indirect':0})
   mods[(m[2],neg,absolute,swiz)]+=1
  tex.append({'instruction':int(m[1]),'opcode':ops['TGSI_OPCODE_'+m[2]],'target':targets['TGSI_TEXTURE_'+target],'writeMask':sum(1<<'xyzw'.index(x) for x in mask),'saturate':int('_SAT' in m[3]),'precise':int('_PRECISE' in m[3]),'offsets':0,'sources':sources});op_hist[m[2]]+=1
 return imm,tex
for prefix in ['hot','cold']:
 base=U/prefix;cases=json.loads((base/'native/cases.json').read_text())['cases'];native=[json.loads(x) for x in (base/'native/native.jsonl').read_text().splitlines()];wasm=[json.loads(x) for x in (base/'native/wasm.jsonl').read_text().splitlines()];old=[json.loads(x) for x in (base/'native/historical-abi.jsonl').read_text().splitlines()]
 assert len(cases)==len(native)==len(wasm)==len(old)==932;assert (base/'native/native.jsonl').read_bytes()==(base/'native/sanitize.jsonl').read_bytes()
 data=(base/'native/cases.bin').read_bytes();at=0
 def word():
  global at
  v=struct.unpack_from('<I',data,at)[0];at+=4;return v
 assert word()==len(cases);accepted=0;queried=0;glsl_ops=0;lines=[]
 for index,(c,n,w,a) in enumerate(zip(cases,native,wasm,old)):
  assert n['case']==a['case']==index and w['name']==a['name']==c['name'];assert word()==c['kind'];assert [word() for _ in range(5)]==[c['selectors'][k] for k in ['signedMask','unsignedMask','packedSignedMask','packedNormalizedMask','bufferZeroMask']]
  for name in ['a','b']:
   size=word();assert data[at:at+size]==c[name].encode();at+=size
  result=n['result'];assert result==w['result'];assert result['ok']==c['okay'];assert a['originalResponse']==a['currentResponse'];json.loads(a['originalResponse'])
  if not result['ok']:
   assert list(result)==['ok','error'] and result['error']['code']==c['code'] and n['originalTokens'] is None;continue
  accepted+=1;pair='vertex' in result;stages=[('vertex',result['vertex'],c['a']),('fragment',result['fragment'],c['b'])] if pair else [('vertex' if c['kind'] in [0,7,12] else 'fragment',result,c['a'])];assert len(n['originalTokens'])==len(stages)
  for j,(stage,body,text) in enumerate(stages):
   immediates,texture=tokens(text);record=n['originalTokens'][j];assert record['immediates']==immediates,(prefix,index,'immediate');assert record['textureInstructions']==texture,(prefix,index,'texture')
   query=[]
   for instr in texture:
    opcode=next(k for k,v in ops.items() if v==instr['opcode']).removeprefix('TGSI_OPCODE_');slot=instr['sources'][-1]['index'];assert 'uniform highp sampler2D '+('vs' if stage=='vertex' else 'fs')+'samp'+str(slot)+';' in body['glsl']
    nativeOp={'TEX':'texture(', 'TXL':'textureLod(', 'TXF':'texelFetch(', 'TXD':'textureGrad(', 'TXB':'texture(', 'TXQ':'textureSize('}[opcode];assert nativeOp+('vs' if stage=='vertex' else 'fs')+'samp'+str(slot)+',' in body['glsl'],(c['name'],opcode)
    assert opcode!='TXB' or stage=='fragment'
    if opcode=='TXQ' and instr['writeMask'] & 8:query.append(slot)
    glsl_ops+=1
   if c['kind']<7:
    assert body['metadata']['profile']=='virgl-webgl2-standard-texture-gles3-v1';expected=[{'index':i,'name':('vs' if stage=='vertex' else 'fs')+'samplevels'+str(i),'type':'int','semantic':'TEXTURE_LEVELS'} for i in sorted(set(query))];assert body['metadata']['textureQueries']==expected
    declarations=re.findall(r'^uniform highp int (\w+);$',body['glsl'],re.M);assert declarations==[v['name'] for v in expected];queried+=len(expected)
   lines.append({'case':index,'name':c['name'],'stage':stage,'textures':len(texture),'querySlots':sorted(set(query))})
 assert at==len(data);assert accepted==647 and queried==73 and glsl_ops==528
 allocations=[json.loads(x) for x in (base/'native/allocations.jsonl').read_text().splitlines()];base_rows={x['mode']:x for x in allocations if x['kind']=='baseline'};faults=collections.Counter()
 for mode,baseline in base_rows.items():
  for kind,key in [('upstream-fault','allocations'),('calloc-fault','callocs')]:
   observed=[x for x in allocations if x['kind']==kind and x['mode']==mode];assert [x['site'] for x in observed]==list(range(1,baseline[key]+1));faults[kind]+=len(observed)
   assert all(list(x['result'])==['ok','error'] and not x['result']['ok'] for x in observed)
 custody=[x for x in allocations if x['kind']=='caller-custody'];assert len(custody)==5 and all(x['mutatedBeforeAllocation'] and x['recovered'] for x in custody);assert sum(faults.values())==165
 final=allocations[-1];assert final['faults']==final['recoveries']==165 and final['callerMutation'] and not final['partialResults']
 facade=json.loads((base/'native/facade.json').read_text());assert facade['getters']==0 and len(facade['rejections'])==61 and facade['pressure']['bytes']==16777216 and facade['pressure']['recovered']
 retained=[]
 for family,count in [('uniform',508),('packed',59),('integer',48)]:
  d=base/('retained-'+family);assert (d/'native.jsonl').read_bytes()==(d/'sanitize.jsonl').read_bytes();report=json.loads((d/'node.json').read_text());assert report['cases']==count and report['exactNativeWasm'];retained.append({'family':family,'cases':count})
 results.append({'prefix':prefix,'cases':len(cases),'admitted':accepted,'refused':932-accepted,'textureInstructions':glsl_ops,'queryBindings':queried,'allocationSites':dict(faults),'sourceOwnershipModes':len(custody),'strictRefusals':61,'retained':retained,'citations':lines})
report={'status':'passed','independentParser':True,'pinnedEnums':{k:v for k,v in ops.items() if k.removeprefix('TGSI_OPCODE_') in arity},'runs':results,'opcodeCounts':dict(op_hist),'modifierCustody':[{'opcode':k[0],'negate':k[1],'absolute':k[2],'swizzle':k[3],'count':v} for k,v in sorted(mods.items())]};(O/'literal-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'passed','runs':[{k:v for k,v in r.items() if k!='citations'} for r in results],'opcodes':dict(op_hist)}))
