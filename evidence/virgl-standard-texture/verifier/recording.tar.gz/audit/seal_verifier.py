import gzip,hashlib,io,json,pathlib,subprocess,tarfile,urllib.parse
R=pathlib.Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');O=pathlib.Path('/tmp/d23-independent-verifier');D=R/'evidence/virgl-standard-texture/verifier';D.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();members={};pathmap=[]
def add(name,b):
 assert name not in members and name and not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts;members[name]=b

def file(name,p):add(name,p.read_bytes())
def tree(prefix,p):
 pathmap.append({'original':str(p),'archive':prefix})
 for f in sorted(p.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts:file(prefix+'/'+f.relative_to(p).as_posix(),f)
for p in sorted(O.iterdir()):
 if p.is_file() and p.name not in ['baseline-status.txt','stack-instrumented.wat','product.wat','stack-instrumented.wasm']:file('audit/'+p.name,p)
for name in ['stack-instrumented.wat','product.wat','stack-instrumented.wasm']:file('stack/'+name,O/name)
tree('native-replay',O/'native-replay');tree('source-snapshots',O/'source-snapshots')
for part in ['final','covered','precheck','precheck-corrected','precheck-control']:tree(part,R/('target/evidence/virgl-standard-texture-critic-'+part))
selected=[]
for f in sorted((O/'promoted-node-v8').glob('*.json')):
 data=json.loads(f.read_bytes())
 if any(x.get('url','').endswith('/tools/virgl-standard-texture/adversarial.mjs') for x in data['result']):file('node/promoted/'+f.name,f);selected.append(f.name)
assert len(selected)==3
for p in ['Makefile','renderer/virgl-shader/tests/standard-texture-adversarial.mjs','tools/virgl-standard-texture/adversarial.mjs','tools/virgl-standard-texture/adversarial-fixtures.mjs','tools/virgl-standard-texture/adversarial-pixels.py','tools/verify-virgl-standard-texture-adversarial.sh','tools/virgl-standard-texture/boundary.json','tools/lib/virgl-browser-runner.mjs']:
 file('recurring-source/'+p,R/p)
for mode,name in [('standard-texture-native','standard-texture-test'),('standard-texture-sanitize','standard-texture-test'),('standard-texture-allocation-sanitize','standard-texture-allocation-test')]:file('authenticated-generated/'+mode+'/'+name,O/'unpacked/hot-generated/renderer/virgl-shader/build'/mode/name)
for name in ['virgl-shader.mjs','virgl-shader.wasm']:file('authenticated-generated/wasm/'+name,O/'unpacked/hot-generated/renderer/virgl-shader/build/wasm'/name)
for prefix,names in [('hot',['receipt.json']),('cold',['report.json','receipt.json','cold.log'])]:
 for name in names:file('carried-worker/'+prefix+'/'+name,O/'unpacked'/prefix/name)
for task in ['virgl-standard-texture','virgl-standard-byte-color-images']:
 for role in ['worker','verifier']:
  q=R/'evidence'/task/role
  if q==D:continue
  for name in ['manifest.json','records.json']:file('carried-seal-index/'+task+'/'+role+'/'+name,q/name)
add('audit/seal-receipt-test.json',(json.dumps({'status':'passed','command':['python3','tools/virgl-standard-texture/seal-test.py'],'exitCode':0,'result':'Exact receipt-prefix authentication and five tamper rejections passed.','sourceSha256':sha((R/'tools/virgl-standard-texture/seal-test.py').read_bytes())},indent=2)+'\n').encode())
raw_index=(json.dumps({'schema':'independent-original-texture-verifier-records-v1','task':'E6-T11d23','sourceHead':HEAD,'records':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())]},indent=2)+'\n').encode();(D/'records.json').write_bytes(raw_index)
with (D/'recording.tar.gz').open('wb') as stream:
 with gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0,compresslevel=9) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as archive:
   for n,b in sorted(members.items()):
    entry=tarfile.TarInfo(n);entry.size=len(b);entry.mtime=0;entry.mode=0o644;entry.uid=entry.gid=0;entry.uname=entry.gname='';archive.addfile(entry,io.BytesIO(b))
archive_raw=(D/'recording.tar.gz').read_bytes();auth=json.loads((O/'authentication.json').read_bytes());coverage=json.loads((O/'coverage-classified.json').read_bytes());fresh=json.loads((O/'fresh-authentication.json').read_bytes())
manifest={'schema':'independent-original-texture-verifier-seal-v1','task':'E6-T11d23','status':'HELD','verdict':'verified','sourceHead':HEAD,'workerSubmission':'3595fdc062bf4649461d3aba05ddab3fe9ddbe56','unchangedProductHead':'bd1f39244d74a86a811a064eaa4e9a8989bcee8c','recurringGateHead':'1b13f9e0c176fee1d043e483bf705d8267f99cd6','predecessor':'ac2b1ed7a77e82afb21321d6dfdabe0b2da12d4c','records':len(members),'uncompressedBytes':sum(map(len,members.values())),'archiveBytes':len(archive_raw),'archiveSha256':sha(archive_raw),'recordIndexSha256':sha(raw_index),'workerArchiveSha256':auth['worker']['archiveSha256'],'workerIndexSha256':auth['worker']['recordIndexSha256'],'dependencies':auth['carriedD22'],'coldCarry':{'head':auth['sourceHead'],'reportSha256':'014be7a0dec5eb110f8055773986944404543e29cf2de833366f03f22088c92a','receiptSha256':auth['cold']['receiptSha256'],'reason':'The single final exact-head scrubbed pristine clone is authenticated. Subsequent changes are only sealing/test/evidence/log/status/queue; no product/dependency/portability failure or runtime edit.'},'predictionsSha256':sha((O/'predictions.json').read_bytes()),'coverage':{'exactMigrations':39,'fullNestedIntervals':250,'intervalCounts':coverage['intervalCounts'],'unprovenExecutableRegions':0,'fullChangedConditionalBranches':53,'conditionalBothDirectionsCovered':49,'conditionalWaivers':4,'conditionalWaiverAuthority':'audit/llvm-branches-classified.json: two retained dimensional checks, one defensive pinned query-bit consistency invariant, one forbidden vertex TXB stage label.','permittedZeroLabel':'Vertex TXB stage-label configuration in a covered fragment formatter; all original vertex TXB forms refuse at the actual guard before emission.'},'pathMap':pathmap,'suite':{'command':'make verify-E6-T11d23-adversarial','sourceHead':'1b13f9e0c176fee1d043e483bf705d8267f99cd6','status':'passed','healthySeeds':[826366247,655894553],'physicalControl':'Actual TEXTURE_BASE_LEVEL=1 completes consumed native fence37148 and fails original complete pixels unchanged.','focusedCounterHead':HEAD,'healthyFrames':32,'nativeStandaloneCompiles':64,'fullPixelControlFrames':1,'pixels':2112,'rawWords':8448,'nativeTexels':2244},'stack':{'originalWasmSha256':fresh['generatedWasmSha256'],'memoryMinMaxPages':256,'fixedMemoryBytes':16777216,'stackBudgetBytes':262144,'actualObservedStagePeakBytes':147040,'actualObservedPairPeakBytes':202736,'method':'Scratch observer of all305 original stack-pointer writes;964 cases retain all exact response bytes. Repository/generated product untouched.'},'precheck':'Three precheck directories preserve one critic-only unused dimensional block binding assumption and its correction. They carry no additional runtime claim; final/covered records are authority.','guestExecution':False,'productionNegotiation':False,'resourceConsumerAuthority':False,'productionDrawAuthority':False,'scope':'Local original explicitly host-selected2D/FLOAT texture compiler and sorted owned integer query metadata.'}
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Reread every compressed member and compare the complete index, with no trusted producer shortcut.
seen={}
with tarfile.open(D/'recording.tar.gz','r:gz') as archive:
 for entry in archive:
  assert entry.isfile() and entry.name not in seen
  b=archive.extractfile(entry).read();seen[entry.name]={'bytes':len(b),'sha256':sha(b)}
assert seen=={x['path']:{'bytes':x['bytes'],'sha256':x['sha256']} for x in json.loads((D/'records.json').read_bytes())['records']};assert sha((D/'recording.tar.gz').read_bytes())==manifest['archiveSha256'];assert sha((D/'records.json').read_bytes())==manifest['recordIndexSha256']
print(json.dumps({k:manifest[k] for k in ['status','verdict','sourceHead','records','uncompressedBytes','archiveBytes','archiveSha256','recordIndexSha256']}))
