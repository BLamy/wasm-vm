import hashlib,json,pathlib,subprocess
O=pathlib.Path('/tmp/d23-independent-verifier');R=pathlib.Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');sha=lambda b:hashlib.sha256(b).hexdigest()
original=json.loads((O/'predictions.json').read_bytes());citations={
'P1-seal':['authentication.json#/worker','authentication.json#/cold'],
'P2-original-tokens':['literal-audit.json#/pinnedEnums','literal-audit.json#/runs/0/citations','literal-audit.json#/runs/1/citations'],
'P3-native-selection':['literal-audit.json#/opcodeCounts','worker:hot/native/native.jsonl:299','worker:hot/native/native.jsonl:578'],
'P4-response-custody':['native-replay.json#/runs','wasm-replay.json#/rows','worker:hot/native/historical-abi.jsonl'],
'P5-query-metadata':['literal-audit.json#/runs/0/queryBindings','prediction-correction.json','worker:hot/hardware/report.json#/acceptance/frames/229','covered/seed-826366247/report.json#/acceptance/frames/4/queries'],
'P6-worker-pixels':['pixel-audit.json#/reports','pixel-audit.json#/words'],
'P7-fault-physical':['pixel-audit.json#/reports','covered/fault-lod-selection/report.json#/acceptance/frames/0/gpuComplete'],
'P8-allocations':['literal-audit.json#/runs/0/allocationSites','literal-audit.json#/runs/0/sourceOwnershipModes','native-replay.json#/runs/2','worker:hot/native/allocations.jsonl'],
'P9-facade-memory':['wasm-replay.json#/ownDataRefusals','wasm-replay.json#/genuineHeapAndScratchPressureRecovery','stack-observation.json#/rows/298','worker:hot/stack/bridge.su','original-Wasm:memory-section'],
'P10-coverage-migrations':['authentication.json#/migrations','coverage-classified.json#/files','fresh-full-v8-classified.json#/scripts','all-path-classification.json'],
'P11-cold-carry':['authentication.json#/carriedD22','authentication.json#/cold','worker:cold/report.json','worker:cold/receipt.json'],
'P12-novel':['covered/independent-audit.json','covered/seed-826366247/original-inputs.json','covered/seed-655894553/original-inputs.json','covered/fault-lod-selection/report.json#/acceptance/frames/0','fresh-authentication.json']}
observations={
'P1-seal':'All5814 unique regular members and exact bytes/digests authenticated; both final frozen-head receipts and exact stdout append match.',
'P2-original-tokens':'Both932-case matrices reconstruct literal pinned opcode/operand/types/masks/modifiers/immediates; each has528 accepted texture operations and73 sorted query bindings.',
'P3-native-selection':'All admitted native operations correspond to original numeric sources and stage/target restrictions. Original vertexTXBcases577-617 refuse before the emitter.',
'P4-response-custody':'Native/ASan/UBSan full outputs replay byte-exactly; every actual generated-Wasm response matches raw original C; all932 historical responses equal the independently authenticated predecessor.',
'P5-query-metadata':'GL_INT5124/count1 integer view-level binding and initialized masked lanes match. w-only sampler remains active on this ANGLE/Metal platform: elimination is permitted, never numerically required. Initial overstrong elimination expectation retained separately; no numeric oracle changed.',
'P6-worker-pixels':'498 healthy/fault frames across hot/cold independently reconstructed from original full image and attributes:31872 pixels,127488 raw output words,61002 native texels. UndefinedTXQz never assigned a numeric assertion.',
'P7-fault-physical':'All six worker controls and fresh base-LOD control complete a consumed native fence, clean resources, keep zero errors and fail original pixels unchanged.',
'P8-allocations':'144 upstream and21 calloc genuine allocation failures plusfive before-allocation source-ownership modes recover byte-exactly; actual failure binaries replay unchanged.',
'P9-facade-memory':'Own-data refusals invoke zero getters, stable snapshots/old results/independent memories/genuine OOM recover. Actual scratch observation964cases leaves every response byte unchanged; stage147040/pair202736 peak within262144; original fixed memory256min/max pages.',
'P10-coverage-migrations':'All39 inverses/forwards exact;250 nested product intervals classified220positive/30waived. Sole zero emitted value is forbidden vertexTXB stage-label configuration in otherwise executed fragment formatter. Full nested critic helper/driver/Node ranges retained including diagnostic-only zeros.',
'P11-cold-carry':'All30256 D22worker and1824verifier members authenticated at unchanged resource/transport/guest boundary. Carry the one pristine scrubbed exactbd1clone clean before/after; no unrelated suite repeated.',
'P12-novel':'Two seeds,16 complete original modifier/mip/query cases each at new slots7/14 and allconstant unused samplers. Actual32 healthy frames/64 standalone accepted native stage compiles, plus one real wrong native base-LOD frame. Independent oracle2112pixels/8448words/2244native texels; wrong output [255,110,109,186]/255 differs from original [19,28,108,208]/255 after fence37148.'}
rows=[]
for p in original['predictions']:rows.append({'id':p['id'],'status':'HELD','beforeInspectionPrediction':p['prediction'],'observed':observations[p['id']],'citations':citations[p['id']]})
result={'verdict':'verified','originalPredictionsSha256':sha((O/'predictions.json').read_bytes()),'workerSubmission':'3595fdc062bf4649461d3aba05ddab3fe9ddbe56','productHead':'bd1f39244d74a86a811a064eaa4e9a8989bcee8c','freshHarnessHead':'c1d6643cdf9b7849a86b945b167f57585cccec8f','predictions':rows,'noRuntimeEdits':True,'physicalControlHeld':True,'numericOriginalOracleNeverChanged':True,'diagnosticPrecheck':'novel-precheck-correction.json: unrelated unused dimensional constant-block binding assumption removed; initial diagnostic preserved and not used as positive proof.','suite':'make verify-E6-T11d23-adversarial','scope':'local original explicitly host-selected2D/FLOAT texture compiler and owned query metadata only','guestExecution':False,'resourceConsumerAuthority':False,'productionDrawAuthority':False}
(O/'verdict.json').write_text(json.dumps(result,indent=2)+'\n');print('Resolved12 preinspection predictions: HELD; verified bounded compiler claim.')
