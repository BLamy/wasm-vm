import hashlib, json, pathlib, subprocess, tarfile, time
R=pathlib.Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm'); O=pathlib.Path('/tmp/d23-independent-verifier'); U=O/'unpacked'; U.mkdir(exist_ok=True)
SOURCE='bd1f39244d74a86a811a064eaa4e9a8989bcee8c'; SEAL='7eda9f021bdcbda82dc6c3bc1fc9b81a0bae41c8'; PRE='ac2b1ed7a77e82afb21321d6dfdabe0b2da12d4c'
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=R)
def authenticate(base, extract=False, pinned=None):
 mraw=(base/'manifest.json').read_bytes(); iraw=(base/'records.json').read_bytes(); a=(base/'recording.tar.gz').read_bytes(); m=json.loads(mraw); ix=json.loads(iraw)
 assert sha(iraw)==m['recordIndexSha256']; assert sha(a)==m['archiveSha256']
 if pinned:
  assert (sha(a),sha(iraw),len(ix['records']))==pinned
 exp={x['path']:x for x in ix['records']}; assert len(exp)==len(ix['records'])==m['records']; seen=set(); size=0
 with tarfile.open(base/'recording.tar.gz','r:gz') as t:
  for member in t:
   path=pathlib.PurePosixPath(member.name)
   assert member.isfile() and not path.is_absolute() and '..' not in path.parts and str(path)==member.name
   assert member.name in exp and member.name not in seen
   raw=t.extractfile(member).read(); e=exp[member.name]; assert member.size==e['bytes']==len(raw) and sha(raw)==e['sha256'], member.name
   seen.add(member.name); size+=len(raw)
   if extract:
    dest=U/member.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
 assert seen==set(exp)
 return {'role':base.name,'members':len(seen),'unpackedBytes':size,'manifestSha256':sha(mraw),'recordIndexSha256':sha(iraw),'archiveSha256':sha(a)}
worker=authenticate(R/'evidence/virgl-standard-texture/worker',True,('0e3941c6a1dc117bc27f4e319ca2f768357ec20e733841410d8ad74ac7b73e20','35159ac22757fd992efc8184a023207850eeef29286e7372f432a714ccbea792',5814))
manifest=json.loads((R/'evidence/virgl-standard-texture/worker/manifest.json').read_bytes()); assert manifest['sourceHead']==SOURCE and manifest['sealingHead']==SEAL
assert git('diff','--name-only',SOURCE,SEAL).decode().splitlines()==['tools/virgl-standard-texture/seal-test.py','tools/virgl-standard-texture/seal.py']
for name in ['tools/virgl-standard-texture/seal.py','tools/virgl-standard-texture/seal-test.py']:
 assert (U/'sealing'/name).read_bytes()==git('show',SEAL+':'+name)
confirmation=b'Frozen original texture operations, physical pixels, retained ABIs and complete custody authenticated.\n'
source_checks=0; generated_checks=0
for prefix,key in [('hot','hotReceiptSha256'),('cold','coldReceiptSha256')]:
 raw=(U/prefix/'receipt.json').read_bytes(); receipt=json.loads(raw); assert sha(raw)==manifest[key]; assert receipt['status']=='passed' and receipt['gitHead']==SOURCE
 for name,digest in receipt['files'].items(): assert sha((U/prefix/name).read_bytes())==digest, name
 original=(U/prefix/'acceptance.log').read_bytes(); final=(U/prefix/'acceptance.log.final').read_bytes(); assert final==original+confirmation
 assert original.endswith(b'STANDARD_TEXTURE_RECORDING_COMPLETE\n'), original[-100:]
 for name,digest in receipt['sources'].items(): assert sha(git('show',SOURCE+':'+name))==digest, name; source_checks+=1
 for name,digest in receipt['generated'].items(): assert sha((U/(prefix+'-generated')/name).read_bytes())==digest,name; generated_checks+=1
cold_raw=(U/'cold/report.json').read_bytes(); cold=json.loads(cold_raw); assert sha(cold_raw)==manifest['coldReportSha256']
assert cold['status']=='passed' and cold['gitHead']==cold['cloneHead']==SOURCE and cold['exitCode']==0 and cold['statusBefore']==cold['statusAfter']==''
assert sha((U/'cold/cold.log').read_bytes())==cold['logSha256'] and cold['receiptSha256']==manifest['coldReceiptSha256']; assert cold['command']==['make','verify-E6-T11d23']
carried=[]
for role in ['worker','verifier']:
 base=R/'evidence/virgl-standard-byte-color-images'/role; rec=authenticate(base);carried.append(rec)
 for name in ['manifest.json','records.json','recording.tar.gz']:
  assert (base/name).read_bytes()==git('show',PRE+':'+(base/name).relative_to(R).as_posix())
for prefix in ['hot','cold']:
 a=json.loads((U/prefix/'native/predecessor/authentication.json').read_bytes());assert a['predecessor']==PRE
 for role in ['worker','verifier']:
  observed=next(x for x in a['carried'] if x['role']==role); actual=next(x for x in carried if x['role']==role)
  for k in ['archiveSha256','recordIndexSha256','manifestSha256']:assert observed[k]==actual[k]
  assert observed['records']==actual['members']
 assert sha((U/prefix/'native/predecessor/virgl-shader.wasm').read_bytes())=='fc479ec92133f8b75d26043d20fca97d00b1a1556481abf5c5daf23b66e00fca'
 assert sha((U/prefix/'native/predecessor/virgl-shader.mjs').read_bytes())=='0f42245f22cabd36d69d2494056bedd03dd4394c9cf42424ee285f95b00920b0'
assert not git('diff','--name-only',PRE,SOURCE,'--','renderer/virgl-command','crates','web','tools/guest').strip()
boundary=json.loads((R/'tools/virgl-standard-texture/boundary.json').read_bytes()); migrations=[]
for f in boundary['files']:
 name=f['path']; before=git('show',PRE+':'+name); after=git('show',SOURCE+':'+name)
 assert sha(before)==f['beforeSha256'] and sha(after)==f['afterSha256']; assert (R/name).read_bytes()==after
 inverted=after.decode().splitlines(keepends=True);forward=before.decode().splitlines(keepends=True)
 for c in reversed(f['changes']):
  old=c['before'].splitlines(keepends=True);new=c['after'].splitlines(keepends=True);pos=c['afterLine']-1
  assert inverted[pos:pos+len(new)]==new,(name,c['afterLine']);inverted[pos:pos+len(new)]=old
  pos=c['beforeLine']-1;assert forward[pos:pos+len(old)]==old,(name,c['beforeLine']);forward[pos:pos+len(old)]=new
 assert ''.join(inverted).encode()==before and ''.join(forward).encode()==after,name
 migrations.append({'source':name,'changes':len(f['changes']),'inverseExact':True,'forwardExact':True,'beforeSha256':sha(before),'afterSha256':sha(after)})
assert len(migrations)==7 and sum(x['changes'] for x in migrations)==39
result={'status':'passed','predictionsSha256':sha((O/'predictions.json').read_bytes()),'submissionHead':git('rev-parse','3595fdc0').decode().strip(),'sourceHead':SOURCE,'worker':worker,'sourceDigestsAuthenticated':source_checks,'generatedDigestsAuthenticated':generated_checks,'receiptConfirmationExact':True,'cold':cold,'carriedD22':carried,'migrations':migrations,'unchangedResourceTransportGuest':True,'runtimeBuildOrGpuRun':False}
(O/'authentication.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps({k:v for k,v in result.items() if k not in ['cold','migrations']}))
