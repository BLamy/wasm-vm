import collections,hashlib,json,pathlib
R=pathlib.Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm');O=pathlib.Path('/tmp/d23-independent-verifier');b=json.loads((R/'tools/virgl-standard-texture/boundary.json').read_text());products={f['path']:f for f in b['files']};offsets={};segments={}
for n,f in products.items():
 s=(R/n).read_text();offsets[n]=[0]
 for line in s.splitlines(keepends=True):offsets[n].append(offsets[n][-1]+len(line))
 segments[n]=[(offsets[n][c['afterLine']-1],offsets[n][c['afterLine']-1]+len(c['after'])) for c in f['changes'] if c['after']]
def off(n,l,c):return offsets[n][l-1]+c-1
unique={};records=[]
for prefix in ['hot','cold']:
 for file in sorted((O/'unpacked'/prefix/'coverage').glob('*.json')):
  d=json.loads(file.read_bytes())
  for fn in d['data'][0]['functions']:
   for idx,br in enumerate(fn.get('branches',[])):
    n=fn['filenames'][br[6]];name=next((x for x in products if n.endswith('/'+x)),None)
    if not name:continue
    a,z=off(name,br[0],br[1]),off(name,br[2],br[3]);
    if not any(x<z and a<y for x,y in segments[name]):continue
    key=(name,fn['name'],*br[:4]);u=unique.setdefault(key,{'source':name,'function':fn['name'],'branch':br[:4],'true':0,'false':0,'records':[]});u['true']=max(u['true'],br[4]);u['false']=max(u['false'],br[5]);item={'record':str(file.relative_to(O/'unpacked')),'recordSha256':hashlib.sha256(file.read_bytes()).hexdigest(),'function':fn['name'],'branchIndex':idx,'branch':br};u['records'].append(item);records.append(item)
for u in unique.values():
 if u['true'] and u['false']:u['classification']='EXECUTED';u['reason']='Both conditional directions independently have positive full branch counters.'
 else:
  u['classification']='WAIVED';line=u['branch'][0]
  if u['source'].endswith('bridge.c') and line==2408:u['reason']='Identical retained dimensional bank/indirection metadata checks at the old dependency boundary. Both exact39-migration inversion and unchanged D22 HELD evidence authenticate the retained expression; this change adds only the following query comparison.'
  elif u['source'].endswith('bridge.c') and line==2409:u['reason']='Defensive pinned-converter consistency invariant. The comparison itself executes901 times and all observed original query export/guard bits agree; no public call can forge converter info and no upstream patch is permitted. The shared error return is independently executed by genuine affected allocation failures. No added standalone rejection body is unexecuted.'
  elif u['source'].endswith('standard_emit.c') and line==242:u['reason']='Forbidden vertex TXB stage-label configuration, same specific guard waiver as coverage-classified.json. Fragment direction212 hits; vertex direction0 with original vertexTXBcases577-617 refusing before emission.'
  else:raise AssertionError(u)
report={'status':'passed','exactByteOverlap':True,'rawChangedBranchRecords':len(records),'uniqueChangedBranches':len(unique),'classes':dict(collections.Counter(u['classification'] for u in unique.values())),'branches':list(unique.values())};(O/'llvm-branches-classified.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='branches'}))
