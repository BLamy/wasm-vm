//! E5-T26h: whole-machine desktop device state rides the CPU/RAM resume boundary.

#![cfg(not(feature = "zicsr-stub"))]

use std::cell::{Cell, RefCell};
use std::rc::Rc;

use wasm_vm_core::bus::Bus;
use wasm_vm_core::dev::virtio::console::{
    AGENT_PORT_ID, AGENT_TRANSMIT_QUEUE, CONTROL_RECEIVE_QUEUE, CONTROL_TRANSMIT_QUEUE,
    ConsoleControl, PORT0_TRANSMIT_QUEUE, VIRTIO_CONSOLE_DEVICE_READY, VIRTIO_CONSOLE_PORT_OPEN,
    VIRTIO_CONSOLE_PORT_READY,
};
use wasm_vm_core::dev::virtio::gpu::protocol::{
    CMD_GET_DISPLAY_INFO, CMD_RESOURCE_FLUSH, CMD_UPDATE_CURSOR, CTRL_HDR_SIZE, CtrlHeader,
    CursorPos, DISPLAY_INFO_RESPONSE_SIZE, RESOURCE_FLUSH_SIZE, RESP_OK_NODATA, Rect,
    ResourceFlush, UPDATE_CURSOR_SIZE, UpdateCursor,
};
use wasm_vm_core::dev::virtio::gpu::{FrameSink, TestSink};
use wasm_vm_core::dev::virtio::input::EV_KEY;
use wasm_vm_core::dev::virtio::rng::EntropySource;
use wasm_vm_core::dev::virtio::snd::{JACK_INFO_SIZE, QueryInfo, VIRTIO_SND_R_JACK_INFO};
use wasm_vm_core::platform::{Platform, virt};
use wasm_vm_core::resume::{SectionReader, SnapshotError, SnapshotWriter, section};
use wasm_vm_core::trace::HashSink;
use wasm_vm_core::{Machine, RunOutcome};

const RAM: usize = 32 * 1024 * 1024;
const QUEUE_SIZE: u32 = 8;
const STATUS: u64 = 0x070;
const QUEUE_SEL: u64 = 0x030;
const QUEUE_NUM: u64 = 0x038;
const QUEUE_READY: u64 = 0x044;
const QUEUE_DESC_LOW: u64 = 0x080;
const QUEUE_DRIVER_LOW: u64 = 0x090;
const QUEUE_DEVICE_LOW: u64 = 0x0a0;
const QUEUE_NOTIFY: u64 = 0x050;
const DESC_WRITE: u16 = 2;
const DESC_READ: u16 = 0;
const DESC_NEXT: u16 = 1;
const DRIVER_OK: u32 = 0x0f;
// A valid application HELLO; only tests know its framing, never the resume implementation.
const AGENT_HELLO: [u8; 18] = [10, 0, 0, 0, 0, 0, 0, 0, 1, 0, 7, 0, 0, 0, 0, 0, 0, 0];

#[derive(Clone)]
struct CountingSink(Rc<Cell<u32>>);

impl FrameSink for CountingSink {
    fn flush(
        &mut self,
        _scanout: Option<u32>,
        _format: u32,
        _rect: wasm_vm_core::dev::virtio::gpu::Rect,
        _resource_width: u32,
        _resource_height: u32,
        _pixels: &[u32],
    ) {
        self.0.set(self.0.get() + 1);
    }

    fn clear(&mut self) {}
}

#[derive(Default)]
struct FixedEntropy;

impl EntropySource for FixedEntropy {
    fn fill(&mut self, out: &mut [u8]) {
        out.fill(0x5a);
    }
}

fn queue_addresses(slot: usize, queue: usize) -> (u64, u64, u64, u64) {
    let base = virt::DRAM_BASE + 0x10000 + ((slot * 8 + queue) as u64) * 0x2000;
    (base, base + 0x800, base + 0xa00, base + 0xc00)
}

fn configure_queue(machine: &mut Machine, slot: usize, queue: usize) {
    let (desc, avail, used, _) = queue_addresses(slot, queue);
    let base = Platform::virtio_base(slot as u64);
    let write = |machine: &mut Machine, offset: u64, value: u32| {
        machine.bus_mut().store32(base + offset, value).unwrap();
    };
    write(machine, QUEUE_SEL, queue as u32);
    write(machine, QUEUE_NUM, QUEUE_SIZE);
    write(machine, QUEUE_DESC_LOW, desc as u32);
    write(machine, QUEUE_DESC_LOW + 4, (desc >> 32) as u32);
    write(machine, QUEUE_DRIVER_LOW, avail as u32);
    write(machine, QUEUE_DRIVER_LOW + 4, (avail >> 32) as u32);
    write(machine, QUEUE_DEVICE_LOW, used as u32);
    write(machine, QUEUE_DEVICE_LOW + 4, (used >> 32) as u32);
    write(machine, QUEUE_READY, 1);
    write(machine, STATUS, DRIVER_OK);
    machine.bus_mut().store16(avail + 2, 0).unwrap();
    machine.bus_mut().store16(used + 2, 0).unwrap();
}

fn configure_all_queues(machine: &mut Machine) {
    for (slot, queues) in [(2, 1), (3, 2), (4, 2), (5, 2), (6, 4), (7, 2), (8, 6)] {
        for queue in 0..queues {
            configure_queue(machine, slot, queue);
        }
    }
}

// Keep the four wire descriptor fields explicit at each DMA fixture callsite.
#[allow(clippy::too_many_arguments)]
fn write_descriptor(
    machine: &mut Machine,
    slot: usize,
    queue: usize,
    index: u16,
    addr: u64,
    len: u32,
    flags: u16,
    next: u16,
) {
    let (desc, _, _, _) = queue_addresses(slot, queue);
    let address = desc + 16 * u64::from(index);
    machine.bus_mut().store64(address, addr).unwrap();
    machine.bus_mut().store32(address + 8, len).unwrap();
    machine.bus_mut().store16(address + 12, flags).unwrap();
    machine.bus_mut().store16(address + 14, next).unwrap();
}

fn post_descriptor(machine: &mut Machine, slot: usize, queue: usize, ordinal: u16, head: u16) {
    let (_, avail, _, _) = queue_addresses(slot, queue);
    machine
        .bus_mut()
        .store16(avail + 4 + 2 * u64::from(ordinal % QUEUE_SIZE as u16), head)
        .unwrap();
    machine
        .bus_mut()
        .store16(avail + 2, ordinal.wrapping_add(1))
        .unwrap();
}

fn kick(machine: &mut Machine, slot: usize, queue: usize) {
    machine
        .bus_mut()
        .store32(
            Platform::virtio_base(slot as u64) + QUEUE_NOTIFY,
            queue as u32,
        )
        .unwrap();
}

fn desktop_machine(
    sentinel: u32,
    gpu_sink: Box<dyn FrameSink>,
) -> (
    Machine,
    Rc<RefCell<wasm_vm_core::dev::virtio::input::InputState>>,
) {
    let mut machine = Machine::new(RAM);
    machine.enable_plic();
    machine.enable_virtio_slots(None);
    machine.enable_virtio_rng(Box::new(FixedEntropy));
    let (_, keyboard, _) = machine.enable_virtio_keyboard();
    machine.enable_virtio_pointer();
    machine.enable_virtio_snd();
    machine
        .enable_virtio_gpu(gpu_sink)
        .expect("GPU slot 7 is free");
    machine.enable_virtio_console_at(8);

    machine.hart_mut().regs.pc = virt::DRAM_BASE;
    machine
        .bus_mut()
        .store32(virt::DRAM_BASE + 0x200, sentinel)
        .expect("sentinel");
    (machine, keyboard)
}

fn source_with_workload(gpu_sink: Box<dyn FrameSink>) -> Machine {
    let (mut machine, keyboard) = desktop_machine(0x1122_3344, gpu_sink);
    configure_all_queues(&mut machine);

    let (_, gpu) = machine.virtio_gpu().expect("GPU handle");
    {
        let mut gpu_state = gpu.borrow_mut();
        let resource = gpu_state
            .resources
            .create(
                1,
                wasm_vm_core::dev::virtio::gpu::protocol::FORMAT_B8G8R8A8_UNORM,
                2,
                2,
            )
            .expect("small GPU resource");
        resource.host_pixels[0] = 0x1122_3344;
        gpu_state.scanout_resource = Some(1);
    }

    // Keyboard: consume head 0 before save; save_resume then emits a protected release frame for
    // the fresh host rather than carrying a held physical key across the boundary.
    let (_, _, _, buffer) = queue_addresses(3, 0);
    write_descriptor(&mut machine, 3, 0, 0, buffer, 8, DESC_WRITE, 0);
    post_descriptor(&mut machine, 3, 0, 0, 0);
    assert!(keyboard.borrow_mut().inject_event(EV_KEY, 30, 1));
    keyboard.borrow_mut().sync();

    // GPU controlq: complete one request so the resumed target must continue at used/avail 1.
    let (_, _, _, gpu_buffer) = queue_addresses(7, 0);
    let gpu_request = gpu_buffer + 0x100;
    let gpu_response = gpu_buffer + 0x200;
    let gpu_command = CtrlHeader {
        ty: CMD_GET_DISPLAY_INFO,
        ..CtrlHeader::default()
    }
    .to_bytes();
    for (offset, byte) in gpu_command.into_iter().enumerate() {
        machine
            .bus_mut()
            .store8(gpu_request + offset as u64, byte)
            .unwrap();
    }
    write_descriptor(
        &mut machine,
        7,
        0,
        0,
        gpu_request,
        CTRL_HDR_SIZE as u32,
        DESC_NEXT,
        1,
    );
    write_descriptor(
        &mut machine,
        7,
        0,
        1,
        gpu_response,
        DISPLAY_INFO_RESPONSE_SIZE as u32,
        DESC_WRITE,
        0,
    );
    post_descriptor(&mut machine, 7, 0, 0, 0);

    // Sound controlq: complete one independent control request before save.
    let (_, _, _, snd_buffer) = queue_addresses(6, 0);
    let snd_request = snd_buffer + 0x100;
    let snd_response = snd_buffer + 0x200;
    let query = QueryInfo {
        code: VIRTIO_SND_R_JACK_INFO,
        start_id: 0,
        count: 1,
        size: JACK_INFO_SIZE as u32,
    }
    .to_bytes();
    for (offset, byte) in query.into_iter().enumerate() {
        machine
            .bus_mut()
            .store8(snd_request + offset as u64, byte)
            .unwrap();
    }
    write_descriptor(&mut machine, 6, 0, 0, snd_request, 16, DESC_NEXT, 1);
    write_descriptor(
        &mut machine,
        6,
        0,
        1,
        snd_response,
        (4 + JACK_INFO_SIZE) as u32,
        DESC_WRITE,
        0,
    );
    post_descriptor(&mut machine, 6, 0, 0, 0);

    // Start the real named-port protocol. Complete it below before recording the snapshot;
    // application data is deliberately not part of the resumable host session.
    let (_, _, _, console_rx_buffer) = queue_addresses(8, CONTROL_RECEIVE_QUEUE as usize);
    let (_, _, _, console_tx_buffer) = queue_addresses(8, CONTROL_TRANSMIT_QUEUE as usize);
    let console_data = console_tx_buffer + 0x100;
    let control = ConsoleControl::new(0, VIRTIO_CONSOLE_DEVICE_READY, 1).to_bytes();
    for (offset, byte) in control.into_iter().enumerate() {
        machine
            .bus_mut()
            .store8(console_data + offset as u64, byte)
            .unwrap();
    }
    write_descriptor(
        &mut machine,
        8,
        CONTROL_TRANSMIT_QUEUE as usize,
        0,
        console_data,
        8,
        DESC_READ,
        0,
    );
    write_descriptor(
        &mut machine,
        8,
        CONTROL_RECEIVE_QUEUE as usize,
        0,
        console_rx_buffer + 0x100,
        64,
        DESC_WRITE,
        0,
    );
    post_descriptor(&mut machine, 8, CONTROL_TRANSMIT_QUEUE as usize, 0, 0);
    post_descriptor(&mut machine, 8, CONTROL_RECEIVE_QUEUE as usize, 0, 0);

    for offset in (0..32).step_by(4) {
        machine
            .bus_mut()
            .store32(virt::DRAM_BASE + offset, 0x0000_0013)
            .expect("NOP");
    }
    kick(&mut machine, 3, 0);
    kick(&mut machine, 7, 0);
    kick(&mut machine, 6, 0);
    kick(&mut machine, 8, CONTROL_TRANSMIT_QUEUE as usize);
    assert_eq!(machine.run(1), RunOutcome::MaxInstrs);
    assert!(machine.virtio_console().unwrap().borrow().agent_announced());

    for (slot, queue) in [(3, 0), (7, 0), (6, 0), (8, CONTROL_TRANSMIT_QUEUE as usize)] {
        let (_, _, used, _) = queue_addresses(slot, queue);
        assert_eq!(
            machine.bus_mut().load16(used + 2),
            Ok(1),
            "slot {slot} queue {queue}"
        );
    }
    let (_, _, console_used, _) = queue_addresses(8, CONTROL_RECEIVE_QUEUE as usize);
    assert_eq!(machine.bus_mut().load16(console_used + 2), Ok(1));
    for (ordinal, event) in [
        (1, VIRTIO_CONSOLE_PORT_READY),
        (2, VIRTIO_CONSOLE_PORT_OPEN),
    ] {
        // Consume PORT_NAME, then the host PORT_OPEN notification, through the live receive ring.
        post_descriptor(&mut machine, 8, CONTROL_RECEIVE_QUEUE as usize, ordinal, 0);
        kick(&mut machine, 8, CONTROL_RECEIVE_QUEUE as usize);
        assert_eq!(machine.run(1), RunOutcome::MaxInstrs);
        let address = console_data + u64::from(ordinal) * 0x20;
        for (offset, byte) in ConsoleControl::new(AGENT_PORT_ID, event, 1)
            .to_bytes()
            .into_iter()
            .enumerate()
        {
            machine
                .bus_mut()
                .store8(address + offset as u64, byte)
                .unwrap();
        }
        write_descriptor(
            &mut machine,
            8,
            CONTROL_TRANSMIT_QUEUE as usize,
            ordinal,
            address,
            8,
            DESC_READ,
            0,
        );
        post_descriptor(
            &mut machine,
            8,
            CONTROL_TRANSMIT_QUEUE as usize,
            ordinal,
            ordinal,
        );
        kick(&mut machine, 8, CONTROL_TRANSMIT_QUEUE as usize);
        assert_eq!(machine.run(1), RunOutcome::MaxInstrs);
    }
    assert_eq!(machine.bus_mut().load16(console_used + 2), Ok(3));
    machine
        .confirm_virtio_console_agent_hello()
        .expect("source HELLO");
    assert!(
        machine
            .virtio_console()
            .unwrap()
            .borrow()
            .agent_ready_for_restore()
    );
    machine
}

fn corrupt_section(blob: &[u8], wanted: u32) -> Vec<u8> {
    let mut out = blob.to_vec();
    let mut pos = 84usize;
    while pos < out.len() {
        let tag = u32::from_le_bytes(out[pos..pos + 4].try_into().unwrap());
        let len = u32::from_le_bytes(out[pos + 4..pos + 8].try_into().unwrap()) as usize;
        if tag == wanted {
            // The first GPU codec byte follows the 277-byte MMIO transport and the two
            // five-byte ring shadows. Corrupting that magic exercises codec refusal rather
            // than merely changing a valid transport status byte.
            const TRANSPORT_BYTES: usize = 277;
            const RING_SHADOW_BYTES: usize = 10;
            out[pos + 8 + TRANSPORT_BYTES + RING_SHADOW_BYTES] ^= 0xff;
            return out;
        }
        pos += 8 + len;
    }
    panic!("missing section {wanted}");
}

#[test]
fn desktop_devices_resume_with_ring_continuity_and_fresh_host_state() {
    let source_sink_count = Rc::new(Cell::new(0));
    let target_sink_count = Rc::new(Cell::new(0));
    let mut source = source_with_workload(Box::new(CountingSink(Rc::clone(&source_sink_count))));
    let blob = source.save_resume().expect("desktop resume save");

    let (mut target, _) = desktop_machine(
        0xaabb_ccdd,
        Box::new(CountingSink(Rc::clone(&target_sink_count))),
    );
    assert_eq!(
        target.bus_mut().load32(virt::DRAM_BASE + 0x200),
        Ok(0xaabb_ccdd)
    );
    target.load_resume(&blob).expect("desktop resume load");
    assert_eq!(
        target_sink_count.get(),
        1,
        "restore publishes its full repair frame to the fresh sink"
    );
    assert_eq!(
        target.bus_mut().load32(virt::DRAM_BASE + 0x200),
        Ok(0x1122_3344)
    );

    let (_, gpu) = target.virtio_gpu().expect("restored GPU");
    assert_eq!(gpu.borrow().scanout_resource, Some(1));
    assert_eq!(
        gpu.borrow().resources.get(1).unwrap().host_pixels[0],
        0x1122_3344
    );
    assert_eq!(
        target.bus_mut().load32(Platform::virtio_base(7) + STATUS),
        Ok(DRIVER_OK)
    );

    // Keyboard/GPU/sound resume from index 1; the fully opened console resumes from index 3.
    // New heads after those boundaries prove the target did not restart its transport cursors.
    let (_, _, used, buffer) = queue_addresses(3, 0);
    write_descriptor(&mut target, 3, 0, 1, buffer + 8, 8, DESC_WRITE, 0);
    post_descriptor(&mut target, 3, 0, 1, 1);
    kick(&mut target, 3, 0);

    let (_, _, gpu_used, gpu_buffer) = queue_addresses(7, 0);
    let flush = ResourceFlush {
        header: CtrlHeader {
            ty: CMD_RESOURCE_FLUSH,
            ..CtrlHeader::default()
        },
        rect: Rect {
            x: 0,
            y: 0,
            width: 2,
            height: 2,
        },
        resource_id: 1,
        padding: 0,
    }
    .to_bytes();
    for (offset, byte) in flush.into_iter().enumerate() {
        target
            .bus_mut()
            .store8(gpu_buffer + 0x300 + offset as u64, byte)
            .unwrap();
    }
    write_descriptor(
        &mut target,
        7,
        0,
        2,
        gpu_buffer + 0x300,
        RESOURCE_FLUSH_SIZE as u32,
        DESC_NEXT,
        3,
    );
    write_descriptor(
        &mut target,
        7,
        0,
        3,
        gpu_buffer + 0x380,
        CTRL_HDR_SIZE as u32,
        DESC_WRITE,
        0,
    );
    post_descriptor(&mut target, 7, 0, 1, 2);
    kick(&mut target, 7, 0);

    let (_, _, snd_used, snd_buffer) = queue_addresses(6, 0);
    for (offset, byte) in (QueryInfo {
        code: VIRTIO_SND_R_JACK_INFO,
        start_id: 0,
        count: 1,
        size: JACK_INFO_SIZE as u32,
    })
    .to_bytes()
    .into_iter()
    .enumerate()
    {
        target
            .bus_mut()
            .store8(snd_buffer + 0x300 + offset as u64, byte)
            .unwrap();
    }
    write_descriptor(&mut target, 6, 0, 2, snd_buffer + 0x300, 16, DESC_NEXT, 3);
    write_descriptor(
        &mut target,
        6,
        0,
        3,
        snd_buffer + 0x400,
        (4 + JACK_INFO_SIZE) as u32,
        DESC_WRITE,
        0,
    );
    post_descriptor(&mut target, 6, 0, 1, 2);
    kick(&mut target, 6, 0);

    let (_, _, console_used, console_buffer) = queue_addresses(8, CONTROL_RECEIVE_QUEUE as usize);
    write_descriptor(
        &mut target,
        8,
        CONTROL_RECEIVE_QUEUE as usize,
        1,
        console_buffer + 0x200,
        64,
        DESC_WRITE,
        0,
    );
    post_descriptor(&mut target, 8, CONTROL_RECEIVE_QUEUE as usize, 3, 1);
    kick(&mut target, 8, CONTROL_RECEIVE_QUEUE as usize);

    let mut continuation = HashSink::new();
    assert_eq!(
        target.run_traced(1, &mut continuation),
        RunOutcome::MaxInstrs
    );
    assert_eq!(continuation.retired(), 1);
    println!(
        "desktop resume continuation: hash={:016x}, retired={}",
        continuation.hash(),
        continuation.retired()
    );
    assert_eq!(target.bus_mut().load16(used + 2), Ok(2));
    assert_eq!(target.bus_mut().load16(gpu_used + 2), Ok(2));
    assert_eq!(target.bus_mut().load16(snd_used + 2), Ok(2));
    assert_eq!(target.bus_mut().load16(console_used + 2), Ok(4));
    assert_eq!(
        target.bus_mut().load16(console_buffer + 0x204),
        Ok(VIRTIO_CONSOLE_PORT_OPEN)
    );
    assert_eq!(target.bus_mut().load16(console_buffer + 0x206), Ok(0));
    assert_eq!(
        target_sink_count.get(),
        2,
        "new guest flush follows the repair frame on the fresh sink handle"
    );
    assert_eq!(
        source_sink_count.get(),
        0,
        "source sink was not reused by restore"
    );

    // A new application HELLO generation is still required; a fresh machine does not inherit a
    // stale host-session acknowledgement from the saved console lifecycle.
    assert!(
        !target
            .virtio_console()
            .unwrap()
            .borrow()
            .agent_ready_for_restore(),
        "source HELLO must not attest the fresh host"
    );
    target
        .confirm_virtio_console_agent_hello()
        .expect("fresh host HELLO");
    assert!(
        target
            .virtio_console()
            .unwrap()
            .borrow()
            .agent_ready_for_restore()
    );
    drop(source);
}

#[test]
fn gpu_queued_control_and_cursor_notifications_survive_resume_without_rekick() {
    let source_sink = TestSink::new();
    let mut source = desktop_machine(0x1122_3344, Box::new(source_sink.clone())).0;
    configure_all_queues(&mut source);

    let (_, gpu) = source.virtio_gpu().expect("GPU handle");
    {
        let mut gpu_state = gpu.borrow_mut();
        let resource = gpu_state
            .resources
            .create(
                1,
                wasm_vm_core::dev::virtio::gpu::protocol::FORMAT_B8G8R8A8_UNORM,
                2,
                2,
            )
            .expect("small GPU resource");
        resource.host_pixels.fill(0x1122_3344);
        gpu_state.scanout_resource = Some(1);
    }

    // Queue one frame-producing control command, but leave it unserviced.  QueueNotify is the
    // only wake-up for this pending ring work; no later target-side kick is allowed in this test.
    let (_, _, control_used, gpu_buffer) = queue_addresses(7, 0);
    let flush_request = gpu_buffer + 0x100;
    let flush_response = gpu_buffer + 0x180;
    let flush = ResourceFlush {
        header: CtrlHeader {
            ty: CMD_RESOURCE_FLUSH,
            ..CtrlHeader::default()
        },
        rect: Rect {
            x: 0,
            y: 0,
            width: 2,
            height: 2,
        },
        resource_id: 1,
        padding: 0,
    }
    .to_bytes();
    for (offset, byte) in flush.into_iter().enumerate() {
        source
            .bus_mut()
            .store8(flush_request + offset as u64, byte)
            .unwrap();
    }
    write_descriptor(
        &mut source,
        7,
        0,
        0,
        flush_request,
        RESOURCE_FLUSH_SIZE as u32,
        DESC_NEXT,
        1,
    );
    write_descriptor(
        &mut source,
        7,
        0,
        1,
        flush_response,
        CTRL_HDR_SIZE as u32,
        DESC_WRITE,
        0,
    );
    post_descriptor(&mut source, 7, 0, 0, 0);

    // Queue one cursor update in the independent cursorq, also unserviced.  UPDATE_CURSOR uses
    // the restored scanout resource and provides a concrete cursor callback after the resume.
    let (_, _, cursor_used, cursor_buffer) = queue_addresses(7, 1);
    let cursor_request = cursor_buffer + 0x100;
    let cursor_response = cursor_buffer + 0x180;
    let update_cursor = UpdateCursor {
        header: CtrlHeader {
            ty: CMD_UPDATE_CURSOR,
            ..CtrlHeader::default()
        },
        pos: CursorPos {
            scanout_id: 0,
            x: 37,
            y: 41,
            padding: 0,
        },
        resource_id: 1,
        hot_x: 0,
        hot_y: 0,
        padding: 0,
    }
    .to_bytes();
    assert_eq!(update_cursor.len(), UPDATE_CURSOR_SIZE);
    for (offset, byte) in update_cursor.into_iter().enumerate() {
        source
            .bus_mut()
            .store8(cursor_request + offset as u64, byte)
            .unwrap();
    }
    write_descriptor(
        &mut source,
        7,
        1,
        0,
        cursor_request,
        UPDATE_CURSOR_SIZE as u32,
        DESC_NEXT,
        1,
    );
    write_descriptor(
        &mut source,
        7,
        1,
        1,
        cursor_response,
        CTRL_HDR_SIZE as u32,
        DESC_WRITE,
        0,
    );
    post_descriptor(&mut source, 7, 1, 0, 0);

    for offset in (0..32).step_by(4) {
        source
            .bus_mut()
            .store32(virt::DRAM_BASE + offset, 0x0000_0013)
            .expect("NOP");
    }
    kick(&mut source, 7, 0);
    kick(&mut source, 7, 1);
    assert_eq!(source.bus_mut().load16(control_used + 2), Ok(0));
    assert_eq!(source.bus_mut().load16(cursor_used + 2), Ok(0));
    assert!(source_sink.records().is_empty());
    assert!(source_sink.cursor_records().is_empty());

    let blob = source.save_resume().expect("desktop resume save");

    let target_sink = TestSink::new();
    let (mut target, _) = desktop_machine(0xaabb_ccdd, Box::new(target_sink.clone()));
    target.load_resume(&blob).expect("desktop resume load");

    // Restore keeps both guest rings pending and the fresh sink's repair frame is separate from
    // the frame/cursor callbacks caused by servicing those restored notifications.
    assert_eq!(target.bus_mut().load16(control_used + 2), Ok(0));
    assert_eq!(target.bus_mut().load16(cursor_used + 2), Ok(0));
    let frames_before_service = target_sink.records().len();
    let cursors_before_service = target_sink.cursor_records().len();

    assert_eq!(target.run(1), RunOutcome::MaxInstrs);
    assert_eq!(target.bus_mut().load16(control_used + 2), Ok(1));
    assert_eq!(target.bus_mut().load16(cursor_used + 2), Ok(1));
    assert_eq!(target.bus_mut().load32(flush_response), Ok(RESP_OK_NODATA));
    assert_eq!(target.bus_mut().load32(cursor_response), Ok(RESP_OK_NODATA));

    let frames = target_sink.records();
    assert_eq!(frames.len(), frames_before_service + 1);
    assert_eq!(frames.last().unwrap().scanout, Some(0));
    assert_eq!(frames.last().unwrap().rect.width, 2);
    assert_eq!(frames.last().unwrap().rect.height, 2);

    let cursors = target_sink.cursor_records();
    assert_eq!(cursors.len(), cursors_before_service + 1);
    assert_eq!(cursors.last().unwrap().resource_id, 1);
    assert_eq!(cursors.last().unwrap().pos.x, 37);
    assert_eq!(cursors.last().unwrap().pos.y, 41);

    // A second service boundary without a new QueueNotify must not replay either restored
    // descriptor.  Keep both used indices and both host callback streams pinned at the first
    // completion; this is the post-restore double-completion boundary.
    let frames_after_first_service = frames.len();
    let cursors_after_first_service = cursors.len();
    assert_eq!(target.run(1), RunOutcome::MaxInstrs);
    assert_eq!(target.bus_mut().load16(control_used + 2), Ok(1));
    assert_eq!(target.bus_mut().load16(cursor_used + 2), Ok(1));
    assert_eq!(target_sink.records().len(), frames_after_first_service);
    assert_eq!(
        target_sink.cursor_records().len(),
        cursors_after_first_service
    );

    // Reset the restored device, configure fresh empty rings, and service twice.  There is no
    // saved work in this cross-flow, so reset/reconfigure must not resurrect the old completions.
    target
        .bus_mut()
        .store32(Platform::virtio_base(7) + STATUS, 0)
        .unwrap();
    let cursors_after_reset = target_sink.cursor_records().len();
    assert_eq!(
        cursors_after_reset,
        cursors_after_first_service + 1,
        "reset publishes exactly one hide-cursor state for the active cursor"
    );
    configure_queue(&mut target, 7, 0);
    configure_queue(&mut target, 7, 1);
    kick(&mut target, 7, 0);
    kick(&mut target, 7, 1);
    assert_eq!(target.run(1), RunOutcome::MaxInstrs);
    assert_eq!(target.bus_mut().load16(control_used + 2), Ok(0));
    assert_eq!(target.bus_mut().load16(cursor_used + 2), Ok(0));
    assert_eq!(target_sink.records().len(), frames_after_first_service);
    assert_eq!(target_sink.cursor_records().len(), cursors_after_reset);
    assert_eq!(target.run(1), RunOutcome::MaxInstrs);
    assert_eq!(target.bus_mut().load16(control_used + 2), Ok(0));
    assert_eq!(target.bus_mut().load16(cursor_used + 2), Ok(0));
    assert_eq!(target_sink.records().len(), frames_after_first_service);
    assert_eq!(target_sink.cursor_records().len(), cursors_after_reset);
}

#[test]
fn malformed_desktop_section_and_missing_device_refuse_without_partial_restore() {
    let mut source = source_with_workload(Box::new(CountingSink(Rc::new(Cell::new(0)))));
    let blob = source.save_resume().expect("desktop resume save");

    let (mut target, _) =
        desktop_machine(0xaabb_ccdd, Box::new(CountingSink(Rc::new(Cell::new(0)))));
    let baseline = target.save_resume().expect("baseline target save");
    let malformed = corrupt_section(&blob, section::VIRTIO_GPU);
    assert!(matches!(
        target.load_resume(&malformed),
        Err(wasm_vm_core::resume::SnapshotError::BadComponentState {
            tag: section::VIRTIO_GPU
        })
    ));
    assert_eq!(target.save_resume().unwrap(), baseline);

    let (header, reader) = SectionReader::new(&blob).unwrap();
    let mut writer = SnapshotWriter::new(
        &header.core_hash,
        &header.base_image_hash,
        header.overlay_generation,
    );
    for item in reader {
        let item = item.unwrap();
        if item.tag != section::VIRTIO_GPU {
            writer.section(item.tag, item.payload);
        }
    }
    let missing = writer.finish();
    assert!(matches!(
        target.load_resume(&missing),
        Err(wasm_vm_core::resume::SnapshotError::BadComponentState {
            tag: section::VIRTIO_GPU
        })
    ));
    assert_eq!(target.save_resume().unwrap(), baseline);
}

#[test]
fn headless_resume_remains_compatible_without_desktop_sections() {
    let mut source = Machine::new(2 * 1024 * 1024);
    source.hart_mut().regs.pc = virt::DRAM_BASE;
    source
        .bus_mut()
        .store32(virt::DRAM_BASE, 0x0000_0013)
        .unwrap();
    let blob = source.save_resume().unwrap();
    let mut target = Machine::new(2 * 1024 * 1024);
    target.load_resume(&blob).unwrap();
}

#[test]
fn pending_console_transmits_survive_while_stale_host_session_is_discarded() {
    let mut source = source_with_workload(Box::new(CountingSink(Rc::new(Cell::new(0)))));
    let console = source.virtio_console().unwrap();
    let transmit_queues = [PORT0_TRANSMIT_QUEUE as usize, AGENT_TRANSMIT_QUEUE as usize];
    for (ordinal, bytes) in [b"old session".as_slice(), b"pending guest".as_slice()]
        .into_iter()
        .enumerate()
    {
        for queue in transmit_queues {
            let (_, _, _, buffer) = queue_addresses(8, queue);
            let data = buffer + ordinal as u64 * 0x100;
            for (offset, &byte) in bytes.iter().enumerate() {
                source.bus_mut().store8(data + offset as u64, byte).unwrap();
            }
            write_descriptor(
                &mut source,
                8,
                queue,
                ordinal as u16,
                data,
                bytes.len() as u32,
                0,
                0,
            );
            post_descriptor(&mut source, 8, queue, ordinal as u16, ordinal as u16);
            kick(&mut source, 8, queue);
        }
        if ordinal == 0 {
            assert_eq!(source.run(1), RunOutcome::MaxInstrs);
            assert_eq!(console.borrow().agent_output_bytes(), bytes.len());
            assert_eq!(console.borrow().serial_output_bytes(), bytes.len());
        }
    }
    assert_eq!(
        console
            .borrow_mut()
            .enqueue_agent_input(b"stale host bytes"),
        16
    );
    let blob = source.save_resume().unwrap();
    let (mut target, _) =
        desktop_machine(0xaabb_ccdd, Box::new(CountingSink(Rc::new(Cell::new(0)))));
    target.load_resume(&blob).unwrap();
    let restored = target.virtio_console().unwrap();
    assert_eq!(restored.borrow().agent_input_bytes(), 0);
    assert_eq!(restored.borrow().agent_output_bytes(), 0);
    assert_eq!(restored.borrow().application_hello_generation(), 0);
    assert!(!restored.borrow().agent_ready_for_restore());

    for queue in transmit_queues {
        let (_, _, used, _) = queue_addresses(8, queue);
        // Agent application data is discarded/completed before the guest resumes; serial
        // data remains available for the ordinary device service boundary.
        let expected = if queue == AGENT_TRANSMIT_QUEUE as usize {
            2
        } else {
            1
        };
        assert_eq!(target.bus_mut().load16(used + 2), Ok(expected));
    }
    // No target QueueNotify: these notifications already happened in the saved machine.
    assert_eq!(target.run(1), RunOutcome::MaxInstrs);
    assert!(!restored.borrow().agent_ready_for_restore());
    assert_eq!(restored.borrow().agent_output_bytes(), 0);
    assert_eq!(
        restored.borrow().serial_output_bytes(),
        b"pending guest".len()
    );
    assert_eq!(target.run(1), RunOutcome::MaxInstrs);
    for queue in transmit_queues {
        let (_, _, used, _) = queue_addresses(8, queue);
        assert_eq!(target.bus_mut().load16(used + 2), Ok(2));
        assert_eq!(target.bus_mut().load32(used + 4), Ok(0));
        assert_eq!(target.bus_mut().load32(used + 12), Ok(1));
    }
    assert!(restored.borrow_mut().take_agent_output().is_empty());
    assert_eq!(restored.borrow_mut().take_serial_output(), b"pending guest");
    // A valid HELLO posted after load_resume is permitted; the core does not inspect the
    // application framing. Only this new output is offered to the fresh Channel.
    let queue = AGENT_TRANSMIT_QUEUE as usize;
    let (_, _, used, buffer) = queue_addresses(8, queue);
    target
        .bus_mut()
        .ram_mut()
        .write_slice(buffer, &AGENT_HELLO)
        .unwrap();
    write_descriptor(
        &mut target,
        8,
        queue,
        0,
        buffer,
        AGENT_HELLO.len() as u32,
        0,
        0,
    );
    post_descriptor(&mut target, 8, queue, 2, 0);
    kick(&mut target, 8, queue);
    target.hart_mut().regs.pc = virt::DRAM_BASE;
    assert_eq!(target.run(1), RunOutcome::MaxInstrs);
    assert_eq!(target.bus_mut().load16(used + 2), Ok(3));
    assert_eq!(restored.borrow_mut().take_agent_output(), AGENT_HELLO);
    assert!(target.confirm_virtio_console_agent_hello().is_some());
    assert!(restored.borrow().agent_ready_for_restore());
}

fn empty_console_topology() -> Machine {
    let mut machine = Machine::new(1024 * 1024);
    machine.enable_plic();
    machine.enable_virtio_slots(None);
    machine.enable_virtio_console_at(8);
    machine.hart_mut().regs.pc = virt::DRAM_BASE + 0x100;
    machine.hart_mut().regs.write(5, 0xdead_beef);
    machine
        .bus_mut()
        .store32(virt::DRAM_BASE, 0xdead_beef)
        .unwrap();
    machine
}

fn start_console_agent(machine: &mut Machine) {
    configure_queue(machine, 8, CONTROL_TRANSMIT_QUEUE as usize);
    configure_queue(machine, 8, AGENT_TRANSMIT_QUEUE as usize);
    // An actual guest instruction per boundary, without a finite NOP runway.
    machine
        .bus_mut()
        .store32(virt::DRAM_BASE, 0x0000_006f)
        .unwrap();
    machine.hart_mut().regs.pc = virt::DRAM_BASE;
    machine.hart_mut().regs.write(5, 0x1122_3344);
    for (ordinal, control) in [
        ConsoleControl::new(0, VIRTIO_CONSOLE_DEVICE_READY, 1),
        ConsoleControl::new(AGENT_PORT_ID, VIRTIO_CONSOLE_PORT_READY, 1),
        ConsoleControl::new(AGENT_PORT_ID, VIRTIO_CONSOLE_PORT_OPEN, 1),
    ]
    .into_iter()
    .enumerate()
    {
        let queue = CONTROL_TRANSMIT_QUEUE as usize;
        let (_, _, _, buffer) = queue_addresses(8, queue);
        machine
            .bus_mut()
            .ram_mut()
            .write_slice(buffer, &control.to_bytes())
            .unwrap();
        write_descriptor(machine, 8, queue, 0, buffer, 8, DESC_READ, 0);
        post_descriptor(machine, 8, queue, ordinal as u16, 0);
        kick(machine, 8, queue);
        assert_eq!(machine.run(1), RunOutcome::MaxInstrs);
    }
    assert!(
        machine
            .virtio_console()
            .unwrap()
            .borrow()
            .agent_ready_for_host()
    );
}

fn post_agent_hello(machine: &mut Machine, ordinal: u16) {
    let queue = AGENT_TRANSMIT_QUEUE as usize;
    let (_, _, _, buffer) = queue_addresses(8, queue);
    let head = ordinal % QUEUE_SIZE as u16;
    let data = buffer + u64::from(head) * 32;
    machine
        .bus_mut()
        .ram_mut()
        .write_slice(data, &AGENT_HELLO)
        .unwrap();
    write_descriptor(
        machine,
        8,
        queue,
        head,
        data,
        AGENT_HELLO.len() as u32,
        DESC_READ,
        0,
    );
    post_descriptor(machine, 8, queue, ordinal, head);
}

#[test]
fn agent_resume_frontier_wraps_and_allows_fresh_tx_before_first_guest_step() {
    let queue = AGENT_TRANSMIT_QUEUE as usize;
    let (_, avail, used, _) = queue_addresses(8, queue);
    let mmio = Platform::virtio_base(8);
    let mut seed = empty_console_topology();
    start_console_agent(&mut seed);
    let source_console = seed.virtio_console().unwrap();
    // Establish the cursor through actual completions, not a fabricated snapshot or a target
    // pre-seeded with the desired cursor. Pending work below crosses 65535 -> 0.
    const CONSUMED: u16 = u16::MAX - 1;
    for start in (0..u32::from(CONSUMED)).step_by(QUEUE_SIZE as usize) {
        let end = (start + QUEUE_SIZE).min(u32::from(CONSUMED));
        for ordinal in start..end {
            post_agent_hello(&mut seed, ordinal as u16);
        }
        kick(&mut seed, 8, queue);
        assert_eq!(seed.run(1), RunOutcome::MaxInstrs);
        assert_eq!(
            source_console.borrow_mut().take_agent_output(),
            AGENT_HELLO.repeat((end - start) as usize)
        );
    }
    assert_eq!(seed.bus_mut().load16(used + 2), Ok(CONSUMED));
    let seeded = seed.save_resume().unwrap();

    // Empty, partially pending across wrap, and a full ring: the bounded drain must consume
    // exactly the old frontier in each case, even when the saved agent port is closed.
    for pending in [0_u16, 3, QUEUE_SIZE as u16] {
        let mut source = empty_console_topology();
        source.load_resume(&seeded).unwrap();
        if pending == 3 {
            source
                .virtio_console()
                .unwrap()
                .borrow_mut()
                .set_host_connected(false);
        }
        for offset in 0..pending {
            post_agent_hello(&mut source, CONSUMED.wrapping_add(offset));
        }
        if pending == QUEUE_SIZE as u16 {
            source.bus_mut().store16(avail, 1).unwrap(); // VRING_AVAIL_F_NO_INTERRUPT
        }
        kick(&mut source, 8, queue);
        source.bus_mut().store32(mmio + 0x64, 3).unwrap(); // acknowledge old IRQs
        let snapshot = source.save_resume().unwrap();
        // Section order is not part of the contract: RAM last must still be drained only after
        // it is restored, not against the target's sentinel RAM.
        let (header, reader) = SectionReader::new(&snapshot).unwrap();
        let mut writer = SnapshotWriter::new(
            &header.core_hash,
            &header.base_image_hash,
            header.overlay_generation,
        );
        let mut ram = None;
        for item in reader {
            let item = item.unwrap();
            if item.tag == section::RAM {
                ram = Some(item.payload);
            } else {
                writer.section(item.tag, item.payload);
            }
        }
        writer.section(section::RAM, ram.unwrap());
        let mut target = empty_console_topology();
        let console = target.virtio_console().unwrap();
        assert_eq!(target.bus_mut().load32(mmio + STATUS), Ok(0));
        assert_eq!(target.bus_mut().load16(used + 2), Ok(0));
        target.load_resume(&writer.finish()).unwrap();
        assert!(Rc::ptr_eq(&console, &target.virtio_console().unwrap()));
        assert_eq!(target.hart().regs.pc, virt::DRAM_BASE);
        assert_eq!(target.hart().regs.read(5), 0x1122_3344);
        assert_eq!(target.bus_mut().load32(virt::DRAM_BASE), Ok(0x0000_006f));
        assert_eq!(target.bus_mut().load32(mmio + STATUS), Ok(DRIVER_OK));
        assert_eq!(
            target.bus_mut().load32(mmio + 0x60),
            Ok(u32::from(pending != 0 && pending != QUEUE_SIZE as u16))
        );
        let frontier = CONSUMED.wrapping_add(pending);
        assert_eq!(target.bus_mut().load16(used + 2), Ok(frontier));
        assert!(console.borrow_mut().take_agent_output().is_empty());
        assert_eq!(console.borrow().application_hello_generation(), 0);
        assert!(!console.borrow().agent_ready_for_restore());
        for offset in 0..pending {
            let head = CONSUMED.wrapping_add(offset) % QUEUE_SIZE as u16;
            let entry = used + 4 + 8 * u64::from(head);
            assert_eq!(target.bus_mut().load32(entry), Ok(u32::from(head)));
            assert_eq!(target.bus_mut().load32(entry + 4), Ok(0));
        }
        // This descriptor did not exist at load time, yet is posted before the first guest
        // step. A lazy fence captured at first service would incorrectly discard its HELLO.
        console.borrow_mut().set_host_connected(true);
        if pending == 3 {
            // The saved port was closed. Reopen it through its existing control ring, without
            // reconfiguration, in the same first boundary as the genuinely fresh HELLO.
            let control_queue = CONTROL_TRANSMIT_QUEUE as usize;
            let (_, _, _, buffer) = queue_addresses(8, control_queue);
            let open = ConsoleControl::new(AGENT_PORT_ID, VIRTIO_CONSOLE_PORT_OPEN, 1);
            target
                .bus_mut()
                .ram_mut()
                .write_slice(buffer, &open.to_bytes())
                .unwrap();
            write_descriptor(&mut target, 8, control_queue, 0, buffer, 8, DESC_READ, 0);
            post_descriptor(&mut target, 8, control_queue, 3, 0);
            kick(&mut target, 8, control_queue);
        }
        post_agent_hello(&mut target, frontier);
        kick(&mut target, 8, queue);
        assert_eq!(target.run(1), RunOutcome::MaxInstrs);
        assert_eq!(
            target.bus_mut().load16(used + 2),
            Ok(frontier.wrapping_add(1))
        );
        assert_eq!(console.borrow_mut().take_agent_output(), AGENT_HELLO);
        assert!(target.confirm_virtio_console_agent_hello().is_some());
        assert!(console.borrow().agent_ready_for_restore());
        assert_eq!(target.run(1), RunOutcome::MaxInstrs);
        assert_eq!(
            target.bus_mut().load16(used + 2),
            Ok(frontier.wrapping_add(1))
        );
        assert!(console.borrow_mut().take_agent_output().is_empty());
    }
}

#[test]
fn malformed_saved_agent_dma_blocks_tx_until_transport_reset() {
    let queue = AGENT_TRANSMIT_QUEUE as usize;
    let (desc, _, used, _) = queue_addresses(8, queue);
    let mmio = Platform::virtio_base(8);
    let mut source = empty_console_topology();
    start_console_agent(&mut source);
    post_agent_hello(&mut source, 0);
    post_agent_hello(&mut source, 1);
    // The first pending HELLO can complete, but the second descriptor cannot DMA outside RAM.
    // This is valid snapshot encoding of a malformed guest ring, not a section-codec error.
    source.bus_mut().store64(desc + 16, 0).unwrap();
    kick(&mut source, 8, queue);
    source.bus_mut().store32(mmio + 0x64, 3).unwrap();
    let blob = source.save_resume().unwrap();
    let mut target = empty_console_topology();
    target.load_resume(&blob).unwrap();
    let console = target.virtio_console().unwrap();
    assert_eq!(target.bus_mut().load32(mmio + STATUS), Ok(DRIVER_OK | 64));
    assert_eq!(target.bus_mut().load32(mmio + 0x60).unwrap() & 2, 2);
    assert_eq!(target.bus_mut().load16(used + 2), Ok(1));
    assert_eq!(target.bus_mut().load32(used + 4), Ok(0));
    assert_eq!(target.bus_mut().load32(used + 8), Ok(0));
    assert!(console.borrow_mut().take_agent_output().is_empty());
    assert!(target.confirm_virtio_console_agent_hello().is_none());
    // Repairing the descriptor and notifying/draining without the required reset must not
    // replay the already completed head or expose the remaining old-session bytes.
    post_agent_hello(&mut target, 1);
    kick(&mut target, 8, queue);
    assert_eq!(target.run(1), RunOutcome::MaxInstrs);
    assert_eq!(target.bus_mut().load16(used + 2), Ok(1));
    assert!(console.borrow_mut().take_agent_output().is_empty());
    assert!(!console.borrow().agent_ready_for_restore());

    target.bus_mut().store32(mmio + STATUS, 0).unwrap();
    start_console_agent(&mut target);
    post_agent_hello(&mut target, 0);
    kick(&mut target, 8, queue);
    assert_eq!(target.run(1), RunOutcome::MaxInstrs);
    assert_eq!(target.bus_mut().load32(mmio + STATUS), Ok(DRIVER_OK));
    assert_eq!(target.bus_mut().load16(used + 2), Ok(1));
    assert_eq!(console.borrow_mut().take_agent_output(), AGENT_HELLO);
    assert!(target.confirm_virtio_console_agent_hello().is_some());
    assert!(console.borrow().agent_ready_for_restore());
}

fn legacy_machine(sentinel: u64, sink: Box<dyn FrameSink>) -> Machine {
    let mut machine = Machine::new(1024 * 1024);
    machine.enable_clint(10);
    machine.enable_plic();
    machine.enable_virtio_blk(Box::new(wasm_vm_core::block::MemBackend::new(vec![0; 512])));
    machine.enable_virtio_net(Box::new(
        wasm_vm_core::dev::virtio::net::LoopbackBackend::new(),
    ));
    machine.enable_uart16550();
    machine.enable_rtc(Box::new(wasm_vm_core::dev::rtc::FixedClock(sentinel)));
    machine.enable_virtio_gpu(sink).unwrap();
    machine.enable_virtio_console_at(8);
    machine.hart_mut().regs.write(5, sentinel);
    machine
        .bus_mut()
        .store64(virt::DRAM_BASE, sentinel)
        .unwrap();
    machine
}

#[test]
fn every_fallible_legacy_section_refuses_before_live_state_or_host_callbacks_change() {
    let mut source = legacy_machine(0x1122_3344, Box::new(CountingSink(Rc::new(Cell::new(0)))));
    {
        let (_, gpu) = source.virtio_gpu().unwrap();
        let mut gpu = gpu.borrow_mut();
        gpu.resources
            .create(
                77,
                wasm_vm_core::dev::virtio::gpu::protocol::FORMAT_B8G8R8A8_UNORM,
                2,
                2,
            )
            .unwrap();
        gpu.scanout_resource = Some(77);
    }
    let blob = source.save_resume().unwrap();
    let (header, _) = SectionReader::new(&blob).unwrap();
    for tag in [
        section::CPU,
        section::RAM,
        section::CLINT,
        section::PLIC,
        section::UART,
        section::RTC,
        section::CLOCK,
        section::VIRTIO_BLK,
        section::VIRTIO_NET,
    ] {
        let payload = SectionReader::new(&blob)
            .unwrap()
            .1
            .map(Result::unwrap)
            .find(|item| item.tag == tag)
            .unwrap()
            .payload;
        let mut trailing = payload.to_vec();
        trailing.push(0);
        let mut corruptions = vec![
            (
                vec![0],
                if tag == section::RAM {
                    SnapshotError::BadSparseEncoding
                } else {
                    SnapshotError::BadComponentState { tag }
                },
            ),
            (
                trailing,
                if tag == section::RAM {
                    SnapshotError::BadSparseEncoding
                } else {
                    SnapshotError::BadComponentState { tag }
                },
            ),
        ];
        // Exercise semantic checks as well as lengths; the RAM overrun is checked without
        // expanding its attacker-controlled zero run into an allocation.
        if tag == section::RAM {
            corruptions.push((
                vec![0, 255, 255, 255, 255],
                SnapshotError::SparseRunExceedsTotal,
            ));
        } else if let Some(offset) = match tag {
            section::CPU => Some(512), // LR/SC reservation-present boolean.
            section::CLINT => Some(16),
            section::UART => Some(7),
            section::RTC => Some(24),
            section::VIRTIO_BLK | section::VIRTIO_NET => Some(277), // has_queue.
            _ => None,
        } {
            let mut invalid = payload.to_vec();
            invalid[offset] = 2;
            corruptions.push((invalid, SnapshotError::BadComponentState { tag }));
        }
        for (invalid, expected) in corruptions {
            // Put the invalid payload last: successful validation of every preceding section
            // must still have no effect on CPU/RAM, MMIO, device state, or the host sink.
            let mut writer = SnapshotWriter::new(
                &header.core_hash,
                &header.base_image_hash,
                header.overlay_generation,
            );
            for item in SectionReader::new(&blob).unwrap().1 {
                let item = item.unwrap();
                if item.tag != tag {
                    writer.section(item.tag, item.payload);
                }
            }
            writer.section(tag, &invalid);
            let calls = Rc::new(Cell::new(0));
            let mut target = legacy_machine(0xaabb_ccdd, Box::new(CountingSink(Rc::clone(&calls))));
            let baseline = target.save_resume().unwrap();
            assert_eq!(
                target.load_resume(&writer.finish()),
                Err(expected),
                "section {tag}"
            );
            assert_eq!(
                calls.get(),
                0,
                "section {tag} refusal called the host GPU sink"
            );
            assert_eq!(
                target.save_resume().unwrap(),
                baseline,
                "section {tag} refusal changed the machine"
            );
        }
    }

    // Legacy blk/net also have a fallible target-slot lookup. A well-formed payload targeting a
    // headless machine must refuse before replacing its earlier CPU/RAM sections.
    for tag in [section::VIRTIO_BLK, section::VIRTIO_NET] {
        let mut writer = SnapshotWriter::new(
            &header.core_hash,
            &header.base_image_hash,
            header.overlay_generation,
        );
        for item in SectionReader::new(&blob).unwrap().1 {
            let item = item.unwrap();
            if matches!(item.tag, section::CPU | section::RAM | section::CLOCK) || item.tag == tag {
                writer.section(item.tag, item.payload);
            }
        }
        let mut target = Machine::new(1024 * 1024);
        target.hart_mut().regs.write(5, 0xaabb_ccdd);
        target
            .bus_mut()
            .store64(virt::DRAM_BASE, 0xaabb_ccdd)
            .unwrap();
        let baseline = target.save_resume().unwrap();
        assert_eq!(
            target.load_resume(&writer.finish()),
            Err(SnapshotError::BadComponentState { tag })
        );
        assert_eq!(target.save_resume().unwrap(), baseline);
    }
}
