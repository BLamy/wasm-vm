//! Physical Memory Protection (E1-T15, Priv §3.7): 16 entries with OFF/TOR/NA4/NAPOT matching,
//! R/W/X permissions, and the L lock bit, checked on every physical access (fetch/load/store/
//! AMO, and the E1-T16 page-table walker).
//!
//! Matching rule: the LOWEST-numbered entry that matches ANY byte of the access wins,
//! irrespective of other entries. If that entry matches ALL bytes, the access is allowed/denied
//! by its L/R/W/X bits; if it matches only SOME bytes (a straddle), the access FAILS. If no entry
//! matches: an M-mode access succeeds, but an S/U access FAILS (because ≥1 entry is implemented).
//! An unlocked entry (L=0) never restricts M-mode — M bypasses it — while a locked entry (L=1)
//! applies to M too.

use crate::csr::Priv;

/// The kind of access being checked, selecting which permission bit governs it.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PmpAccess {
    Read,
    Write,
    Exec,
}

// pmpcfg byte layout (Priv §3.7.1).
const CFG_R: u8 = 1 << 0;
const CFG_W: u8 = 1 << 1;
const CFG_X: u8 = 1 << 2;
const CFG_A: u8 = 0b11 << 3;
const CFG_L: u8 = 1 << 7;
// A-field encodings.
const A_OFF: u8 = 0;
const A_TOR: u8 = 1;
const A_NA4: u8 = 2;
const A_NAPOT: u8 = 3;
/// Software-legal cfg bits: R/W/X/A/L (bits 5–6 are reserved WPRI, read 0).
const CFG_WMASK: u8 = CFG_R | CFG_W | CFG_X | CFG_A | CFG_L;
/// pmpaddr holds physical address[55:2] — 54 bits; [63:54] read 0.
const ADDR_MASK: u64 = (1 << 54) - 1;
/// Number of PMP entries.
pub const NUM_ENTRIES: usize = 64;

/// The 16-entry PMP unit. `cfg[i]` is entry i's configuration byte; `addr[i]` is its raw pmpaddr
/// value (address[55:2]).
#[derive(Debug, Clone)]
pub struct Pmp {
    cfg: [u8; NUM_ENTRIES],
    addr: [u64; NUM_ENTRIES],
    /// Perf: cached `any_armed()`. It was an O(NUM_ENTRIES=64) scan run on EVERY instruction fetch
    /// (via `pmp_ok`'s fast-path gate) — the profiler showed it as ~40% of pure-compute interpreter
    /// self-time. `cfg` (the only input) changes ONLY in `write_cfg`/`restore_bytes` (rare — PMP is
    /// configured at boot), so recompute the flag there and serve O(1) reads. Behaviourally identical.
    armed: bool,
    /// Microarchitectural change detector for decoded/compiled code caches. PMP regions can split a
    /// page, so validating only a cached block's entry parcel is insufficient after a CSR write;
    /// Machine observes this revision at execution boundaries and invalidates all cached code.
    /// Deliberately excluded from architectural equality and snapshots.
    revision: u64,
    /// Perf (derived, never serialized, excluded from equality like `revision`): the byte range
    /// `[first_lo, first_hi)` and cfg of the LOWEST-numbered non-OFF entry, valid iff `first_ok`.
    /// `check`'s scan skips every lower (OFF) entry and lands on this one first, so an access lying
    /// wholly inside it is decided by its cfg alone — the common case (OpenSBI/`allow_all` open one
    /// all-memory entry), which otherwise recomputed the region on every data access. Rebuilt by
    /// every `cfg`/`addr` mutator (`refresh_derived`), so a restore rebuilds it too.
    first_lo: u64,
    first_hi: u64,
    first_cfg: u8,
    first_ok: bool,
}

impl PartialEq for Pmp {
    fn eq(&self, other: &Self) -> bool {
        self.cfg == other.cfg && self.addr == other.addr && self.armed == other.armed
    }
}

impl Eq for Pmp {}

impl Default for Pmp {
    /// Reset: every entry A=OFF, L=0 (Priv §3.7 recommendation).
    fn default() -> Self {
        Self {
            cfg: [0; NUM_ENTRIES],
            addr: [0; NUM_ENTRIES],
            armed: false,
            revision: 0,
            first_lo: 0,
            first_hi: 0,
            first_cfg: 0,
            first_ok: false,
        }
    }
}

impl Pmp {
    /// True if any entry is armed (A != OFF) — the fast-path gate for the hot memory path.
    /// O(1) cached read; `armed` is recomputed by the (rare) `cfg` mutators (`write_cfg`,
    /// `restore_bytes`). See the `armed` field comment.
    pub fn any_armed(&self) -> bool {
        self.armed
    }

    /// Monotonic microarchitectural revision, bumped only when effective PMP state changes.
    pub fn revision(&self) -> u64 {
        self.revision
    }

    fn bump_revision(&mut self) {
        self.revision = self.revision.wrapping_add(1);
    }

    /// Recompute the derived fast-path state from `cfg`/`addr`: the `any_armed` gate and the
    /// lowest armed entry's region. Called by every `cfg`/`addr` mutator (all rare: PMP is
    /// configured at boot).
    fn refresh_derived(&mut self) {
        self.armed = self.cfg.iter().any(|c| c & CFG_A != 0);
        self.first_ok = false;
        if let Some(i) = self.cfg.iter().position(|c| c & CFG_A != 0)
            && let Some((lo, hi)) = self.region_checked(i)
        {
            self.first_lo = lo;
            self.first_hi = hi;
            self.first_cfg = self.cfg[i];
            self.first_ok = true;
        }
    }

    /// [`Self::region`] for an armed entry, or `None` when that computation would overflow (a
    /// NAPOT/NA4 region reaching past 2^64 — possible only for a hostile restored `pmpaddr`). Such an
    /// entry is simply not cached, so `check` keeps its exact slow-path arithmetic for it.
    fn region_checked(&self, i: usize) -> Option<(u64, u64)> {
        match (self.cfg[i] & CFG_A) >> 3 {
            A_OFF => None,
            A_TOR => self.region(i),
            A_NA4 => {
                let lo = self.addr[i] << 2;
                Some((lo, lo.checked_add(4)?))
            }
            _ => {
                let t = (!self.addr[i]).trailing_zeros();
                if t + 3 >= 64 {
                    return None;
                }
                let base = (self.addr[i] & !((1u64 << (t + 1)) - 1)) << 2;
                Some((base, base.checked_add(1u64 << (t + 3))?))
            }
        }
    }

    /// E3-T12b: append the full PMP state (all `NUM_ENTRIES` cfg bytes + addr words) to a CPU-section
    /// payload, fixed-layout little-endian. Every architectural field, no elision.
    pub(crate) fn snapshot_bytes(&self, out: &mut alloc::vec::Vec<u8>) {
        out.extend_from_slice(&self.cfg);
        for a in &self.addr {
            out.extend_from_slice(&a.to_le_bytes());
        }
    }
    /// E3-T12b: restore PMP state from a [`crate::resume::Reader`]. Called on a LOCAL Pmp during
    /// [`crate::csr::Csrs::parse`] so a mid-parse error never touches the live hart (all-or-nothing).
    pub(crate) fn restore_bytes(
        &mut self,
        r: &mut crate::resume::Reader,
    ) -> Result<(), crate::resume::SnapshotError> {
        let old_cfg = self.cfg;
        let old_addr = self.addr;
        for c in self.cfg.iter_mut() {
            *c = r.u8()?;
        }
        for a in self.addr.iter_mut() {
            *a = r.u64()?;
        }
        self.refresh_derived(); // restored `cfg`/`addr` → rebuild the derived fast-path state
        if self.cfg != old_cfg || self.addr != old_addr {
            self.bump_revision();
        }
        Ok(())
    }

    // ── CSR views ─────────────────────────────────────────────────────────────────
    /// Read an even pmpcfg CSR (`pmpcfg{0,2,4,…,14}` on RV64 — odd CSRs are illegal). `bank` is
    /// the CSR index, so bank `2b` maps to entries `[8b, 8b+8)`: eight cfg bytes packed
    /// little-endian into the 64-bit CSR. (64 entries → 8 even banks, 0..=14.)
    pub fn read_cfg(&self, bank: usize) -> u64 {
        let base = bank * 4; // bank 0→0, 2→8, 4→16, …, 14→56
        let mut v = 0u64;
        for k in 0..8 {
            v |= u64::from(self.cfg[base + k]) << (k * 8);
        }
        v
    }
    /// Write a pmpcfg bank. Each byte is WARL-legalized (reserved bits cleared) and skipped if
    /// its entry is LOCKED (L=1) — a locked cfg/addr can't change until reset.
    pub fn write_cfg(&mut self, bank: usize, v: u64) {
        let old = self.cfg;
        let base = bank * 4;
        for k in 0..8 {
            let i = base + k;
            if self.cfg[i] & CFG_L != 0 {
                continue; // locked
            }
            let mut c = ((v >> (k * 8)) as u8) & CFG_WMASK;
            // R=0,W=1 is a RESERVED encoding (§3.7.1); Spike legalizes it by clearing W (so the
            // region is neither readable nor writable). Match that — otherwise a store to such a
            // region would be wrongly ALLOWED.
            if c & CFG_W != 0 && c & CFG_R == 0 {
                c &= !CFG_W;
            }
            self.cfg[i] = c;
        }
        self.refresh_derived(); // `cfg` changed → rebuild the derived fast-path state
        if self.cfg != old {
            self.bump_revision();
        }
    }
    /// Read `pmpaddr[i]` (address[55:2]; [63:54] read 0).
    pub fn read_addr(&self, i: usize) -> u64 {
        self.addr[i] & ADDR_MASK
    }
    /// Write `pmpaddr[i]`, honoring locks: ignored if entry i is locked, OR if entry i+1 is a
    /// LOCKED TOR entry (whose base is `pmpaddr[i]`) — the TOR-neighbor lock quirk (§3.7.1).
    pub fn write_addr(&mut self, i: usize, v: u64) {
        if self.cfg[i] & CFG_L != 0 {
            return;
        }
        if i + 1 < NUM_ENTRIES {
            let hi = self.cfg[i + 1];
            if hi & CFG_L != 0 && (hi & CFG_A) >> 3 == A_TOR {
                return;
            }
        }
        let v = v & ADDR_MASK;
        if self.addr[i] != v {
            self.addr[i] = v;
            self.refresh_derived(); // an entry's region moved
            self.bump_revision();
        }
    }

    // ── the check ─────────────────────────────────────────────────────────────────
    /// The byte range `[lo, hi)` (byte addresses) that entry `i` covers, or `None` if OFF.
    fn region(&self, i: usize) -> Option<(u64, u64)> {
        let a = (self.cfg[i] & CFG_A) >> 3;
        match a {
            A_OFF => None,
            A_TOR => {
                let lo = if i == 0 { 0 } else { self.addr[i - 1] << 2 };
                let hi = self.addr[i] << 2;
                Some((lo, hi))
            }
            A_NA4 => {
                let lo = self.addr[i] << 2;
                Some((lo, lo + 4))
            }
            _ => {
                // NAPOT: the number of trailing ones `t` sets a 2^(t+3)-byte aligned region.
                let t = (!self.addr[i]).trailing_zeros();
                let base = (self.addr[i] & !((1u64 << (t + 1)) - 1)) << 2;
                Some((base, base + (1u64 << (t + 3))))
            }
        }
    }

    /// Is an access of `len` bytes at `addr` by `mode` permitted for `access`? (E1-T15.)
    #[inline]
    pub fn check(&self, addr: u64, len: u64, access: PmpAccess, mode: Priv) -> bool {
        let end = addr.wrapping_add(len); // access covers [addr, end)
        // Fast path: the scan below would skip the (OFF) entries below the lowest armed one and
        // stop there — it matches (`addr < hi && lo < end`) and fully contains the access — so the
        // verdict is exactly that entry's cfg decision.
        if self.first_ok
            && addr < self.first_hi
            && self.first_lo < end
            && addr >= self.first_lo
            && end <= self.first_hi
        {
            return Self::permits(self.first_cfg, access, mode);
        }
        self.check_scan(addr, end, access, mode)
    }

    /// The matched entry's verdict: an unlocked entry does not restrict M-mode; otherwise the
    /// access kind's R/W/X bit decides.
    #[inline(always)]
    fn permits(cfg: u8, access: PmpAccess, mode: Priv) -> bool {
        if matches!(mode, Priv::M) && cfg & CFG_L == 0 {
            return true;
        }
        match access {
            PmpAccess::Read => cfg & CFG_R != 0,
            PmpAccess::Write => cfg & CFG_W != 0,
            PmpAccess::Exec => cfg & CFG_X != 0,
        }
    }

    /// The full priority scan over `[addr, end)` (the reference semantics; see [`Self::check`]).
    fn check_scan(&self, addr: u64, end: u64, access: PmpAccess, mode: Priv) -> bool {
        for i in 0..NUM_ENTRIES {
            let Some((lo, hi)) = self.region(i) else {
                continue;
            };
            // Does this entry match ANY byte of the access?
            if addr < hi && lo < end {
                // The lowest-numbered matching entry wins. A straddle (not fully contained) fails.
                if addr < lo || end > hi {
                    return false;
                }
                return Self::permits(self.cfg[i], access, mode);
            }
        }
        // No entry matched: M succeeds; S/U fail (≥1 entry implemented).
        matches!(mode, Priv::M)
    }

    // ── test/harness helper ─────────────────────────────────────────────────────────
    /// Open entry 0 as an all-address NAPOT region granting R/W/X to every mode — the "allow
    /// everything" grant OpenSBI/the riscv-tests p-env install (and bare-metal test harnesses
    /// need) so S/U can touch memory. pmpaddr0 = all-ones NAPOT covers the whole space.
    pub fn allow_all(&mut self) {
        let changed =
            self.cfg[0] != CFG_R | CFG_W | CFG_X | (A_NAPOT << 3) || self.addr[0] != ADDR_MASK;
        self.cfg[0] = CFG_R | CFG_W | CFG_X | (A_NAPOT << 3);
        self.addr[0] = ADDR_MASK; // NAPOT with all trailing ones → entire address space
        self.refresh_derived(); // arms entry 0 directly → rebuild the derived fast-path state
        if changed {
            self.bump_revision();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// xorshift64* — a tiny deterministic generator (fixed seeds, no dev-dependency).
    fn next(s: &mut u64) -> u64 {
        *s ^= *s >> 12;
        *s ^= *s << 25;
        *s ^= *s >> 27;
        s.wrapping_mul(0x2545_F491_4F6C_DD1D)
    }

    /// The first-entry fast path must be invisible: across randomized PMP programs (OFF/TOR/NA4/
    /// NAPOT, locks, entries armed at any index, pmpaddr rewrites after cfg writes, restores) and
    /// accesses aimed at region edges, `check` agrees with the reference `check_scan` for every
    /// access kind and mode.
    #[test]
    fn first_entry_fast_path_matches_full_scan() {
        for seed in 1..=64u64 {
            let mut s = seed.wrapping_mul(0x9E37_79B9_7F4A_7C15) | 1;
            let mut p = Pmp::default();
            for step in 0..40 {
                match next(&mut s) % 4 {
                    0 => {
                        let bank = ((next(&mut s) % 8) * 2) as usize;
                        // Mostly-OFF bytes so the lowest armed entry varies; lock rarely.
                        let mut v = 0u64;
                        for k in 0..8 {
                            let r = next(&mut s);
                            let a = if r.is_multiple_of(3) { (r >> 8) % 4 } else { 0 } as u8;
                            let l = if r.is_multiple_of(23) { CFG_L } else { 0 };
                            let c = ((r >> 16) as u8 & 0b111) | (a << 3) | l;
                            v |= u64::from(c) << (k * 8);
                        }
                        p.write_cfg(bank, v);
                    }
                    1 | 2 => {
                        let i = (next(&mut s) % 8) as usize; // the low entries matter most
                        let v = match next(&mut s) % 4 {
                            0 => ADDR_MASK,                                             // all-memory NAPOT
                            1 => (0x8000_0000 >> 2) | ((1 << (next(&mut s) % 20)) - 1), // NAPOT
                            2 => (0x8000_0000 + (next(&mut s) % 0x10_0000)) >> 2,
                            _ => next(&mut s),
                        };
                        p.write_addr(i, v);
                    }
                    _ => {
                        // Round-trip through a snapshot into a fresh unit (rebuilds derived state).
                        let mut bytes = alloc::vec::Vec::new();
                        p.snapshot_bytes(&mut bytes);
                        let mut q = Pmp::default();
                        let mut r = crate::resume::Reader::new(&bytes, crate::resume::section::CPU);
                        q.restore_bytes(&mut r).unwrap();
                        assert_eq!(p, q);
                        p = q;
                    }
                }
                if step % 7 == 0 {
                    p.allow_all();
                }
                for _ in 0..64 {
                    // Probe around the cached region's edges and the NAPOT/TOR boundaries.
                    let edge = match next(&mut s) % 4 {
                        0 => p.first_lo,
                        1 => p.first_hi,
                        2 => 0x8000_0000,
                        _ => next(&mut s),
                    };
                    let addr = edge.wrapping_add((next(&mut s) % 17).wrapping_sub(8));
                    let len = [1u64, 2, 4, 8, 16][(next(&mut s) % 5) as usize];
                    let end = addr.wrapping_add(len);
                    for access in [PmpAccess::Read, PmpAccess::Write, PmpAccess::Exec] {
                        for mode in [Priv::U, Priv::S, Priv::M] {
                            assert_eq!(
                                p.check(addr, len, access, mode),
                                p.check_scan(addr, end, access, mode),
                                "seed {seed} step {step} addr {addr:#x} len {len} {access:?} {mode:?}"
                            );
                        }
                    }
                }
            }
        }
    }
}
