//! E3-T12: the **resume-snapshot container format** — a versioned, sectioned (TLV) blob that a
//! whole-machine snapshot serializes into, plus the coherence guards that make restoring one safe.
//! This is the pure format + parser + RAM zero-elision codec; the per-component `Snapshot`/`Restore`
//! visitors (CPU/RAM/CLINT/PLIC/UART/virtio) and the determinism trace-diff are the integration pass
//! (they need the running machine). See `docs/design/snapshot-format.md`.
//!
//! Distinct from [`crate::snapshot`], which is the E0-T17 *state digest* (an assertion helper).
//!
//! **Why the guards matter.** A snapshot is only valid against the *same emulator build* (a changed
//! instruction semantics would resume into a different machine), the *same base disk image*, and an
//! *overlay generation consistent with it*. Restoring a snapshot whose overlay generation no longer
//! matches the disk means the guest's page cache and the disk disagree → silent corruption. So the
//! header binds all three (`core_hash`, `base_image_hash`, `overlay_generation`) and
//! [`SnapshotHeader::validate_for`] refuses a mismatch with a typed error — the caller falls back to
//! a cold boot. **The parser never panics or reads out of bounds** on a truncated/garbage/hand-edited
//! blob (fuzzed): every length is checked against the remaining bytes.

use alloc::vec::Vec;

/// Blob magic — `"WVMRESU1"` (WasmVM RESUme, format family 1).
pub const MAGIC: [u8; 8] = *b"WVMRESU1";
/// The one container-format version this reader understands. An incompatible change bumps it; an
/// unknown version is a hard error (not a best-effort parse).
pub const FORMAT_VERSION: u32 = 1;

const HEADER_LEN: usize = 8 + 4 + 32 + 32 + 8; // magic + version + core_hash + base_hash + overlay_gen
const SECTION_HEADER_LEN: usize = 8; // tag(4) + len(4)

/// Known section tags. The reader **fails loudly** on any tag outside this set (a snapshot written by
/// a newer build with a section this build can't restore must not be silently half-applied).
pub mod section {
    pub const CPU: u32 = 1;
    pub const RAM: u32 = 2;
    pub const CLINT: u32 = 3;
    pub const PLIC: u32 = 4;
    pub const UART: u32 = 5;
    pub const VIRTIO_BLK: u32 = 6;
    pub const VIRTIO_NET: u32 = 7;
    pub const RTC: u32 = 8;
    /// E3-T12b: the deterministic-clock phase (the sub-`clock_div` `mtime` remainder + `clock_div`).
    /// Machine-level state — kept OFF the CLINT's RefCell so the per-instruction tick stays a plain
    /// field write — but it must be snapshotted for instruction-exact timer placement on resume.
    pub const CLOCK: u32 = 9;
    /// virtio-rng slot — a real device the machine can enable, whose snapshot visitor is a later
    /// increment; reserved-but-unsupported for now (its ring state matters far less than blk/net).
    pub const VIRTIO_RNG: u32 = 10;
    /// E5-T26f: virtio-console transport and ring positions. The host-side application channel is
    /// re-fenced after resume, but the guest-visible transport must match the restored RAM so a
    /// reload can continue without reprobe or a cold Linux boot.
    pub const VIRTIO_CONSOLE: u32 = 11;
    /// E5-T26h: virtio-gpu transport, queue shadows, and the existing GPU codec payload.
    pub const VIRTIO_GPU: u32 = 12;
    /// E5-T26h: virtio-input keyboard transport, queue shadows, and the existing input codec.
    pub const VIRTIO_KEYBOARD: u32 = 13;
    /// E5-T26h: absolute tablet transport, queue shadows, and the existing input codec.
    pub const VIRTIO_TABLET: u32 = 14;
    /// E5-T26h: relative mouse transport, queue shadows, and the existing input codec.
    pub const VIRTIO_MOUSE: u32 = 15;
    /// E5-T26h: virtio-snd transport, queue shadows, and the existing sound codec.
    pub const VIRTIO_SND: u32 = 16;
    /// Format-family reservation for a future device visitor; intentionally unsupported here.
    pub const RESERVED_FUTURE: u32 = 17;
}

/// Is `tag` a section number this format family reserves (the whole reserved universe, whether or
/// not *this* build can restore it)? A tag outside this set is a garbage/foreign tag.
pub fn is_known_section(tag: u32) -> bool {
    matches!(
        tag,
        section::CPU
            | section::RAM
            | section::CLINT
            | section::PLIC
            | section::UART
            | section::VIRTIO_BLK
            | section::VIRTIO_NET
            | section::RTC
            | section::CLOCK
            | section::VIRTIO_RNG
            | section::VIRTIO_CONSOLE
            | section::VIRTIO_GPU
            | section::VIRTIO_KEYBOARD
            | section::VIRTIO_TABLET
            | section::VIRTIO_MOUSE
            | section::VIRTIO_SND
            | section::RESERVED_FUTURE
    )
}

/// Is `tag` a section this build actually has a restorer for? The bounded-component foundation
/// ships CPU (E3-T12b) + RAM + CLINT + PLIC + UART + RTC; the virtio sections are reserved
/// numbers whose visitors land in later integration passes (E3-T12c). A known-but-unsupported tag
/// is refused loudly ([`SnapshotError::UnsupportedSection`]) rather than accepted and skipped. When a
/// visitor lands, its tag moves here and the reserved list shrinks — no format-version bump needed
/// because the reader already fails closed on it.
pub fn is_supported_section(tag: u32) -> bool {
    matches!(
        tag,
        section::CPU
            | section::RAM
            | section::CLINT
            | section::PLIC
            | section::UART
            | section::RTC
            | section::CLOCK
            | section::VIRTIO_BLK
            | section::VIRTIO_NET
            | section::VIRTIO_CONSOLE
            | section::VIRTIO_RNG
            | section::VIRTIO_GPU
            | section::VIRTIO_KEYBOARD
            | section::VIRTIO_TABLET
            | section::VIRTIO_MOUSE
            | section::VIRTIO_SND
    )
}

/// A bounds-checked little-endian cursor for component `restore` parsers (E3-T12b). Every read is
/// fallible: a short payload yields `Err(BadComponentState { tag })` rather than a panic, and the
/// section-level all-or-nothing contract is upheld by parsing wholly into locals before the caller
/// commits. `finish()` refuses trailing garbage so a longer-than-expected payload is also rejected.
pub struct Reader<'a> {
    buf: &'a [u8],
    pos: usize,
    tag: u32,
}

impl<'a> Reader<'a> {
    pub fn new(buf: &'a [u8], tag: u32) -> Self {
        Reader { buf, pos: 0, tag }
    }
    fn err(&self) -> SnapshotError {
        SnapshotError::BadComponentState { tag: self.tag }
    }
    fn take(&mut self, n: usize) -> Result<&'a [u8], SnapshotError> {
        let end = self.pos.checked_add(n).ok_or_else(|| self.err())?;
        if end > self.buf.len() {
            return Err(self.err());
        }
        let s = &self.buf[self.pos..end];
        self.pos = end;
        Ok(s)
    }
    pub fn u8(&mut self) -> Result<u8, SnapshotError> {
        Ok(self.take(1)?[0])
    }
    pub fn bool(&mut self) -> Result<bool, SnapshotError> {
        // Only 0/1 are legal — any other byte is a malformed (or hand-edited) payload.
        match self.u8()? {
            0 => Ok(false),
            1 => Ok(true),
            _ => Err(self.err()),
        }
    }
    pub fn u16(&mut self) -> Result<u16, SnapshotError> {
        let b = self.take(2)?;
        Ok(u16::from_le_bytes([b[0], b[1]]))
    }
    pub fn u32(&mut self) -> Result<u32, SnapshotError> {
        let b = self.take(4)?;
        Ok(u32::from_le_bytes([b[0], b[1], b[2], b[3]]))
    }
    pub fn u64(&mut self) -> Result<u64, SnapshotError> {
        let b = self.take(8)?;
        Ok(u64::from_le_bytes([
            b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7],
        ]))
    }
    /// Assert the payload is fully consumed — a trailing byte means the payload is longer than this
    /// build's encoding (corrupt / version-skewed), rejected rather than silently ignored.
    pub fn finish(self) -> Result<(), SnapshotError> {
        if self.pos == self.buf.len() {
            Ok(())
        } else {
            Err(self.err())
        }
    }

    /// Consume and return the remaining component payload. Device resume visitors use this after
    /// decoding their fixed transport/ring prefix; the outer section length already bounds it.
    pub fn remaining_bytes(&mut self) -> Result<&'a [u8], SnapshotError> {
        let bytes = self.take(self.buf.len().saturating_sub(self.pos))?;
        Ok(bytes)
    }
}

/// A rejected snapshot — every failure is one of these, never a panic.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SnapshotError {
    /// The blob is shorter than the fixed header (or a section runs past the end).
    Truncated,
    /// The leading magic is not [`MAGIC`].
    BadMagic,
    /// `format_version` is not [`FORMAT_VERSION`].
    VersionMismatch { found: u32, supported: u32 },
    /// The snapshot was taken by a different emulator build (`core_hash` differs).
    CoreHashMismatch,
    /// The snapshot is for a different base disk image (`base_image_hash` differs) — refuse.
    BaseImageMismatch,
    /// The overlay has advanced since the snapshot (or is otherwise inconsistent) — refuse rather
    /// than resume a stale CPU/RAM state over a newer disk (the corruption case).
    OverlayGenerationMismatch { snapshot: u64, current: u64 },
    /// A section tag this build does not understand at all — fail loudly.
    UnknownSection { tag: u32 },
    /// A section tag this format family reserves but this build has no restorer for yet (e.g. the
    /// CPU / virtio sections, whose visitors are later integration passes). Recognised, but refused
    /// rather than accepted-and-silently-skipped — the same "must not be half-applied" rule as an
    /// unknown tag, kept a *distinct* variant so a reserved-not-yet-implemented section is
    /// observably different from a garbage tag.
    UnsupportedSection { tag: u32 },
    /// A section's declared length exceeds the bytes remaining in the blob.
    SectionLengthOverflow { tag: u32 },
    /// The zero-elision payload decoded to a different length than expected, or is malformed.
    BadSparseEncoding,
    /// A zero-elision run declared a length that would push the output past `expected_len` — rejected
    /// **before** growing the buffer, so a hostile multi-gigabyte run can't force an allocation. This
    /// is a *distinct* variant from [`Self::BadSparseEncoding`] precisely so the pre-allocation bound
    /// is observable: deleting it changes this error (fast) into a trailing length mismatch (after a
    /// giant allocation).
    SparseRunExceedsTotal,
    /// A component-state section payload was the wrong length or otherwise malformed for its
    /// component (`tag`) — restore refuses it rather than half-applying a corrupt state.
    BadComponentState { tag: u32 },
    /// E3-T12c2: a snapshot was requested while the virtio-blk device still had `in_flight` parked
    /// descriptor chains that could not be drained within the bounded quiesce pass budget. Rather
    /// than serialize a torn boundary (a half-processed request that would double-complete or vanish
    /// on restore), the save REFUSES — the caller retries or falls back. `reason` names the residual
    /// the drain could not clear; `in_flight` is how many chains remain parked.
    NotQuiesced {
        reason: QuiesceReason,
        in_flight: usize,
    },
}

/// E3-T12c2: why the virtio-blk in-flight set could not be drained to empty at a snapshot boundary —
/// the residual [`SnapshotError::NotQuiesced`] carries. A build-agnostic mirror of the device's park
/// reasons so the resume format does not depend on the block-device types.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum QuiesceReason {
    /// A read/write parked awaiting a base-chunk fetch that never arrived within the budget.
    Chunk,
    /// A FLUSH parked awaiting a durability barrier the backend did not clear within the budget.
    Flush,
    /// A persistent WRITE parked awaiting its durable commit within the budget.
    Write,
}

/// A machine component (CLINT, PLIC, UART, …) whose full state serializes to a resume-format
/// section payload and restores from one. Encodings are **fixed-layout little-endian**; `restore`
/// rejects a wrong-length/malformed payload with [`SnapshotError::BadComponentState`] — never a
/// panic — so a truncated or hand-edited snapshot can't half-apply a corrupt device state.
///
/// This is the seam the whole-machine snapshot is built from: each component writes its
/// [`Self::SECTION`] section on save and restores it on load. The CPU/RAM visitors and the
/// determinism trace-diff (which proves *completeness*, not just round-trip) are the boot-gated
/// integration pass; a bounded device like the CLINT/PLIC is fully round-trip-verifiable headlessly
/// because its entire behavioural state is enumerable.
pub trait ComponentSnapshot {
    /// The resume-format section tag this component's state is stored under.
    const SECTION: u32;
    /// Serialize the component's full behavioural state to a section payload.
    fn to_snapshot(&self) -> Vec<u8>;
    /// Restore behavioural state from a payload. A wrong-length/malformed payload is a typed error.
    fn restore(&mut self, payload: &[u8]) -> Result<(), SnapshotError>;
}

/// The parsed, fixed-size container header.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SnapshotHeader {
    pub format_version: u32,
    /// Identity of the emulator build that wrote this (e.g. the core-crate git hash).
    pub core_hash: [u8; 32],
    /// Identity of the base disk image this snapshot rides (the base-image manifest hash).
    pub base_image_hash: [u8; 32],
    /// The overlay commit generation at snapshot time.
    pub overlay_generation: u64,
}

impl SnapshotHeader {
    /// Parse + magic/version-check the header. Returns the header and the offset where sections
    /// begin. Does not check the identity guards — use [`Self::validate_for`].
    pub fn parse(blob: &[u8]) -> Result<(SnapshotHeader, usize), SnapshotError> {
        if blob.len() < HEADER_LEN {
            return Err(SnapshotError::Truncated);
        }
        if blob[0..8] != MAGIC {
            return Err(SnapshotError::BadMagic);
        }
        let format_version = u32_le(&blob[8..12]);
        if format_version != FORMAT_VERSION {
            return Err(SnapshotError::VersionMismatch {
                found: format_version,
                supported: FORMAT_VERSION,
            });
        }
        let mut core_hash = [0u8; 32];
        core_hash.copy_from_slice(&blob[12..44]);
        let mut base_image_hash = [0u8; 32];
        base_image_hash.copy_from_slice(&blob[44..76]);
        let overlay_generation = u64_le(&blob[76..84]);
        Ok((
            SnapshotHeader {
                format_version,
                core_hash,
                base_image_hash,
                overlay_generation,
            },
            HEADER_LEN,
        ))
    }

    /// The coherence guards: refuse a snapshot from a different build, a different base image, or an
    /// overlay generation that no longer matches the live disk. `Ok(())` means it is safe to restore.
    pub fn validate_for(
        &self,
        expected_core_hash: &[u8; 32],
        expected_base_image_hash: &[u8; 32],
        current_overlay_generation: u64,
    ) -> Result<(), SnapshotError> {
        if self.core_hash != *expected_core_hash {
            return Err(SnapshotError::CoreHashMismatch);
        }
        if self.base_image_hash != *expected_base_image_hash {
            return Err(SnapshotError::BaseImageMismatch);
        }
        if self.overlay_generation != current_overlay_generation {
            return Err(SnapshotError::OverlayGenerationMismatch {
                snapshot: self.overlay_generation,
                current: current_overlay_generation,
            });
        }
        Ok(())
    }
}

/// E3-T12d: why a stored snapshot must be discarded in favour of a cold boot. Every reason a
/// browser reload can reject a persisted snapshot collapses to one of these, so the UI/host has a
/// *typed* answer (not a free-form string) for "why did we cold-boot?". The variants partition the
/// whole failure space: nothing stored, a header/section the parser rejects, a foreign build, a
/// foreign base image, or a stale overlay generation. Deliberately build-agnostic (mirrors, but does
/// not re-expose, the [`SnapshotError`] space) so the persistence layer can log/branch on it without
/// depending on the device internals.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ColdBootReason {
    /// No snapshot is persisted for this base image — first boot, or it was cleared.
    Missing,
    /// The blob is truncated, has bad magic, an unknown version, or any malformed/oversized section —
    /// i.e. it does not parse as a coherent container. Never resumed.
    Corrupt,
    /// The snapshot was written by a different emulator build (`core_hash` differs) — resuming it
    /// could land on divergent instruction semantics.
    ForeignBuild,
    /// The snapshot rides a different base disk image (`base_image_hash` differs).
    ForeignImage,
    /// The overlay has advanced past (or diverged from) the snapshot's generation — resuming a stale
    /// CPU/RAM state over a newer disk is the silent-corruption case.
    Stale { snapshot: u64, current: u64 },
}

impl ColdBootReason {
    /// Map a restore-time [`SnapshotError`] onto the cold-boot reason space. The coherence variants
    /// map one-to-one; everything else (bad magic, truncation, version, unknown/unsupported/oversized
    /// section, malformed component/sparse state, a not-quiesced blob that should never have been
    /// stored) is [`Self::Corrupt`] — none of them is safe to resume.
    pub fn from_snapshot_error(err: &SnapshotError) -> Self {
        match err {
            SnapshotError::CoreHashMismatch => ColdBootReason::ForeignBuild,
            SnapshotError::BaseImageMismatch => ColdBootReason::ForeignImage,
            SnapshotError::OverlayGenerationMismatch { snapshot, current } => {
                ColdBootReason::Stale {
                    snapshot: *snapshot,
                    current: *current,
                }
            }
            _ => ColdBootReason::Corrupt,
        }
    }

    /// A stable, machine-readable code for logs and the JS decision API. Kept in lockstep with the
    /// variants so the browser layer can branch on a string without re-deriving the taxonomy.
    pub fn code(&self) -> &'static str {
        match self {
            ColdBootReason::Missing => "missing",
            ColdBootReason::Corrupt => "corrupt",
            ColdBootReason::ForeignBuild => "foreign_build",
            ColdBootReason::ForeignImage => "foreign_image",
            ColdBootReason::Stale { .. } => "stale",
        }
    }
}

/// E3-T12d: the resume-vs-cold-boot decision for a persisted snapshot. `Resume` means the stored
/// blob's complete section framing is coherent with the live machine identity and it is safe to hand
/// to [`crate::Machine::load_resume`]; `ColdBoot` carries the typed reason it was rejected.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RestoreDecision {
    Resume,
    ColdBoot(ColdBootReason),
}

impl RestoreDecision {
    /// Decide from a stored blob (`None` = nothing persisted) against the live machine identity. The
    /// fixed header and every section boundary/tag are checked before the identity guards, so a
    /// truncated or framing-corrupt blob cannot receive a false `Resume` verdict. Component payload
    /// semantics remain enforced by `load_resume` itself (map its error via
    /// [`ColdBootReason::from_snapshot_error`]).
    pub fn decide(
        stored: Option<&[u8]>,
        expected_core_hash: &[u8; 32],
        expected_base_image_hash: &[u8; 32],
        current_overlay_generation: u64,
    ) -> RestoreDecision {
        let Some(blob) = stored else {
            return RestoreDecision::ColdBoot(ColdBootReason::Missing);
        };
        let (header, sections) = match SectionReader::new(blob) {
            Ok(parsed) => parsed,
            Err(err) => {
                return RestoreDecision::ColdBoot(ColdBootReason::from_snapshot_error(&err));
            }
        };
        // Walk the entire TLV framing before accepting the identity. In particular, removing the
        // final byte from a valid snapshot must be classified as corrupt even when the IndexedDB
        // metadata was rebuilt from that shortened input.
        for section in sections {
            if let Err(err) = section {
                return RestoreDecision::ColdBoot(ColdBootReason::from_snapshot_error(&err));
            }
        }
        match header.validate_for(
            expected_core_hash,
            expected_base_image_hash,
            current_overlay_generation,
        ) {
            Ok(()) => RestoreDecision::Resume,
            Err(err) => RestoreDecision::ColdBoot(ColdBootReason::from_snapshot_error(&err)),
        }
    }

    /// `true` iff this is a `Resume`.
    pub fn is_resume(&self) -> bool {
        matches!(self, RestoreDecision::Resume)
    }

    /// The cold-boot reason code, or `"resume"` for a resume verdict — the single string the JS
    /// decision API surfaces.
    pub fn code(&self) -> &'static str {
        match self {
            RestoreDecision::Resume => "resume",
            RestoreDecision::ColdBoot(reason) => reason.code(),
        }
    }
}

/// Builds a snapshot blob: fixed header, then TLV sections in the order added.
pub struct SnapshotWriter {
    buf: Vec<u8>,
}

impl SnapshotWriter {
    pub fn new(core_hash: &[u8; 32], base_image_hash: &[u8; 32], overlay_generation: u64) -> Self {
        let mut buf = Vec::with_capacity(HEADER_LEN);
        buf.extend_from_slice(&MAGIC);
        buf.extend_from_slice(&FORMAT_VERSION.to_le_bytes());
        buf.extend_from_slice(core_hash);
        buf.extend_from_slice(base_image_hash);
        buf.extend_from_slice(&overlay_generation.to_le_bytes());
        Self { buf }
    }

    /// Append a section `[tag][len][payload]`. Panics only on the impossible case of a payload longer
    /// than `u32::MAX` (a >4 GiB section) — callers pass component state far smaller.
    pub fn section(&mut self, tag: u32, payload: &[u8]) -> &mut Self {
        let len: u32 = payload
            .len()
            .try_into()
            .expect("snapshot section exceeds u32::MAX bytes");
        // A RAM section can approach a GiB. Reserving geometrically again for
        // its trailing device sections can require a second GiB of unused
        // capacity and exhaust wasm32 memory while the live RAM is retained.
        self.buf.reserve_exact(
            SECTION_HEADER_LEN
                .checked_add(payload.len())
                .expect("snapshot section size overflow"),
        );
        self.buf.extend_from_slice(&tag.to_le_bytes());
        self.buf.extend_from_slice(&len.to_le_bytes());
        self.buf.extend_from_slice(payload);
        self
    }

    /// The finished blob.
    pub fn finish(self) -> Vec<u8> {
        self.buf
    }
}

/// One parsed section.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Section<'a> {
    pub tag: u32,
    pub payload: &'a [u8],
}

/// Iterates the sections after the header, **bounds-checking every length** and rejecting any tag
/// this build does not know. Stops (yields `None`) at the exact end of the blob; a partial trailing
/// section is [`SnapshotError::Truncated`].
pub struct SectionReader<'a> {
    blob: &'a [u8],
    pos: usize,
    done: bool,
}

impl<'a> SectionReader<'a> {
    /// Position the reader after the header (which is parsed + version-checked here).
    pub fn new(blob: &'a [u8]) -> Result<(SnapshotHeader, SectionReader<'a>), SnapshotError> {
        let (header, start) = SnapshotHeader::parse(blob)?;
        Ok((
            header,
            SectionReader {
                blob,
                pos: start,
                done: false,
            },
        ))
    }
}

impl<'a> Iterator for SectionReader<'a> {
    type Item = Result<Section<'a>, SnapshotError>;

    fn next(&mut self) -> Option<Self::Item> {
        if self.done || self.pos == self.blob.len() {
            return None;
        }
        // A started-but-incomplete section header is a truncation.
        if self.pos + SECTION_HEADER_LEN > self.blob.len() {
            self.done = true;
            return Some(Err(SnapshotError::Truncated));
        }
        let tag = u32_le(&self.blob[self.pos..self.pos + 4]);
        let len = u32_le(&self.blob[self.pos + 4..self.pos + 8]) as usize;
        let body = self.pos + SECTION_HEADER_LEN;
        // Bounds-check the declared length against what's actually there — the core fuzz guard.
        let end = match body.checked_add(len) {
            Some(e) if e <= self.blob.len() => e,
            _ => {
                self.done = true;
                return Some(Err(SnapshotError::SectionLengthOverflow { tag }));
            }
        };
        if !is_known_section(tag) {
            self.done = true;
            return Some(Err(SnapshotError::UnknownSection { tag }));
        }
        // A reserved tag with no restorer in this build is refused loudly, not accepted-and-skipped:
        // silently dropping a section a restore loop can't apply is exactly the half-applied hazard
        // the format forbids. The length is still bounds-checked above, so this stays panic-free.
        if !is_supported_section(tag) {
            self.done = true;
            return Some(Err(SnapshotError::UnsupportedSection { tag }));
        }
        self.pos = end;
        Some(Ok(Section {
            tag,
            payload: &self.blob[body..end],
        }))
    }
}

/// Validate the complete container framing without allocating or mutating machine state. This is
/// the persistence boundary's independent check: a store may describe any supplied byte length, but
/// it cannot make a missing section byte satisfy that section's declared length.
pub fn validate_container(blob: &[u8]) -> Result<(), SnapshotError> {
    let (_, reader) = SectionReader::new(blob)?;
    for section in reader {
        section?;
    }
    Ok(())
}

// ── RAM zero-elision codec ───────────────────────────────────────────────────
//
// A 256 MiB guest RAM that is mostly zero must not serialize to a 256 MiB blob. This is a
// run-length codec that collapses zero runs: the byte stream is a sequence of chunks
// `[kind: u8][len: u32 LE]` where `kind = 0` is a run of `len` implicit zero bytes (no payload) and
// `kind = 1` is `len` literal bytes that follow. Decoding is fully bounds-checked and asserts the
// reconstructed length, so a truncated/garbage payload is a typed error, never an over-read.

const CHUNK_ZERO: u8 = 0;
const CHUNK_DATA: u8 = 1;

/// Encode `buf` with zero-run elision. A mostly-zero buffer shrinks to roughly the size of its
/// non-zero spans.
pub fn encode_sparse(buf: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    let mut i = 0;
    while i < buf.len() {
        let is_zero = buf[i] == 0;
        let start = i;
        while i < buf.len() && (buf[i] == 0) == is_zero {
            i += 1;
        }
        // Split a run longer than u32::MAX into multiple chunks (unreachable on wasm32 usize=u32).
        let mut run = i - start;
        let mut span_start = start;
        while run > 0 {
            let take = run.min(u32::MAX as usize);
            if is_zero {
                out.push(CHUNK_ZERO);
                out.extend_from_slice(&(take as u32).to_le_bytes());
            } else {
                out.push(CHUNK_DATA);
                out.extend_from_slice(&(take as u32).to_le_bytes());
                out.extend_from_slice(&buf[span_start..span_start + take]);
            }
            span_start += take;
            run -= take;
        }
    }
    out
}

/// Decode a [`encode_sparse`] payload back to exactly `expected_len` bytes. A payload that is
/// malformed, over-reads, or reconstructs to the wrong length is [`SnapshotError::BadSparseEncoding`].
///
/// A run length is checked against `expected_len` **before** the buffer grows, so a hostile
/// zero-chunk claiming a 4 GiB run (whose length is not bounded by the input size) is rejected
/// rather than triggering an unbounded allocation.
pub fn decode_sparse(enc: &[u8], expected_len: usize) -> Result<Vec<u8>, SnapshotError> {
    let mut out = Vec::with_capacity(expected_len.min(enc.len().saturating_mul(2)));
    walk_sparse(enc, expected_len, |len, bytes| match bytes {
        None => out.resize(out.len() + len, 0),
        Some(bytes) => out.extend_from_slice(bytes),
    })?;
    Ok(out)
}

/// Check RAM before any live component is restored, without allocating another guest-sized
/// buffer. Validation and decoding share the same run parser and typed errors.
pub(crate) fn validate_sparse(enc: &[u8], expected_len: usize) -> Result<(), SnapshotError> {
    walk_sparse(enc, expected_len, |_, _| {})
}

fn walk_sparse(
    enc: &[u8],
    expected_len: usize,
    mut emit: impl FnMut(usize, Option<&[u8]>),
) -> Result<(), SnapshotError> {
    let mut decoded_len = 0usize;
    let mut i = 0;
    while i < enc.len() {
        // kind byte + u32 length.
        if enc.len() - i < 5 {
            return Err(SnapshotError::BadSparseEncoding);
        }
        let kind = enc[i];
        let len = u32_le(&enc[i + 1..i + 5]) as usize;
        i += 5;
        // Bound the run against the declared total BEFORE allocating — an untrusted zero-run length
        // must not be able to force a multi-gigabyte resize. This uses a DISTINCT error variant from
        // the trailing length check so the guard is observable (mutation-testable).
        let new_len = decoded_len
            .checked_add(len)
            .ok_or(SnapshotError::SparseRunExceedsTotal)?;
        if new_len > expected_len {
            return Err(SnapshotError::SparseRunExceedsTotal);
        }
        match kind {
            CHUNK_ZERO => {
                emit(len, None);
            }
            CHUNK_DATA => {
                let end = i.checked_add(len).ok_or(SnapshotError::BadSparseEncoding)?;
                if end > enc.len() {
                    return Err(SnapshotError::BadSparseEncoding);
                }
                emit(len, Some(&enc[i..end]));
                i = end;
            }
            _ => return Err(SnapshotError::BadSparseEncoding),
        }
        decoded_len = new_len;
    }
    if decoded_len != expected_len {
        return Err(SnapshotError::BadSparseEncoding);
    }
    Ok(())
}

#[inline]
fn u32_le(b: &[u8]) -> u32 {
    u32::from_le_bytes([b[0], b[1], b[2], b[3]])
}

#[inline]
fn u64_le(b: &[u8]) -> u64 {
    u64::from_le_bytes([b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7]])
}

#[cfg(test)]
#[path = "resume_tests.rs"]
mod resume_tests;
