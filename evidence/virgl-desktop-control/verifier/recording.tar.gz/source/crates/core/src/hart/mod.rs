//! The hart (hardware thread): architectural CPU state and the fetch-decode-execute
//! step loop (E0-T07).
//!
//! Trap model: [`Hart::step`] stays PURE — a trap *returns* `Err(Trap)` with the PC still
//! pointing at the faulting instruction and no other architectural state modified. E1-T10
//! layers precise DELIVERY on top via [`Hart::take_trap`]: the run loop takes the trap
//! (mepc/mcause/mtval + the mstatus stack) and vectors to mtvec. Keeping `step` pure is what
//! makes delivery precise — the faulting instruction has zero side effects, so the trap-entry
//! CSRs are the only state that changes. Cause codes mirror the privileged spec's `mcause`
//! numbering (Privileged ISA 20211203, Table 3.6).
//!
//! Scope ledger (each arm is replaced by its owning task):
//! - Computational ops (LUI/AUIPC/OP-IMM/OP-IMM-32/OP/OP-32): executed (E0-T07).
//! - Loads/stores (LB..LWU, SB..SD): executed (E0-T08). Misaligned-data POLICY: the
//!   bus requires natural alignment (E0-T03), so misaligned data accesses trap with
//!   causes 4/6 — matching Spike's default (no `--misaligned`); qemu-riscv64
//!   silently emulates them, a documented differential asymmetry for E0-T20.
//! - FENCE: retires as a no-op — architecturally correct for a single in-order hart
//!   with no devices reordering memory; revisited when it matters (E4 JIT, E6 SMP).
//! - Control flow (JAL/JALR/branches): executed (E0-T09). §2.5 semantics: a misaligned
//!   target would raise cause 0 (tval = target) from the TAKEN jump with no link write. With
//!   IALIGN=16 (C extension, E1-T08) every jump/branch target is even and JALR masks bit 0,
//!   so cause 0 is only reachable via a genuinely misaligned FETCH (an odd PC) — see E1-T10.
//! - ECALL/EBREAK: executed (E0-T11) as precise traps (cause 11 / cause 3). E1-T10 delivers
//!   them (and every other synchronous exception) through mtvec via [`Hart::take_trap`].

pub mod fregs;
pub mod regs;

use crate::bus::{Bus, BusFault};
use crate::decode::{Instr, decode};
use crate::softfloat::{F32, F64, SoftFloat};
use regs::XRegs;

/// Every F/D instruction requires `mstatus.FS != Off` (E1-T06); this identifies them so the
/// check happens once, before any architectural state is read.
const fn is_fp(i: &Instr) -> bool {
    use Instr::*;
    matches!(
        i,
        Flw { .. }
            | Fsw { .. }
            | FpArithS { .. }
            | FsqrtS { .. }
            | FpFusedS { .. }
            | FsgnjS { .. }
            | FminmaxS { .. }
            | FpCmpS { .. }
            | FclassS { .. }
            | FmvXW { .. }
            | FmvWX { .. }
            | FcvtToIntS { .. }
            | FcvtFromIntS { .. }
            | Fld { .. }
            | Fsd { .. }
            | FpArithD { .. }
            | FsqrtD { .. }
            | FpFusedD { .. }
            | FsgnjD { .. }
            | FminmaxD { .. }
            | FpCmpD { .. }
            | FclassD { .. }
            | FmvXD { .. }
            | FmvDX { .. }
            | FcvtToIntD { .. }
            | FcvtFromIntD { .. }
            | FcvtSD { .. }
            | FcvtDS { .. }
    )
}

/// Exception causes, numbered exactly as `mcause` (Privileged ISA Table 3.6).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u64)]
pub enum Exception {
    InstrAddrMisaligned = 0,
    InstrAccessFault = 1,
    IllegalInstruction = 2,
    Breakpoint = 3,
    LoadAddrMisaligned = 4,
    LoadAccessFault = 5,
    StoreAddrMisaligned = 6,
    StoreAccessFault = 7,
    EcallFromU = 8,
    EcallFromS = 9,
    EcallFromM = 11,
    // Sv39 page faults (E1-T16).
    InstrPageFault = 12,
    LoadPageFault = 13,
    StorePageFault = 15,
}

/// A trap: why, plus the `mtval`-equivalent payload (faulting address or raw
/// instruction word, per cause).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Trap {
    pub cause: Exception,
    pub tval: u64,
}

/// One RV64 hart. The PC lives inside [`XRegs`] (single authority, E0-T05);
/// `regs.pc` is the architectural PC.
#[derive(PartialEq, Eq)]
pub struct Hart {
    pub regs: XRegs,
    /// Reset-relevant control/status registers (E1-T01): misa, mstatus, mcause, mhartid,
    /// privilege mode. The single source of architectural reset state.
    pub csr: crate::csr::Csrs,
    /// LR/SC reservation (A extension, E1-T04): `Some((addr, width_bytes))` after a
    /// load-reserved, consumed/cleared by SC. Also invalidated by an overlapping store,
    /// and by MRET/WFI (our documented conservative policy — see the execute arms).
    pub resv: Option<(u64, u8)>,
    /// Floating-point register file (F/D extensions, E1-T06): FLEN=64 with NaN-boxing.
    pub fregs: fregs::FRegs,
    /// Software TLB (E1-T17): ASID-tagged cache in front of the Sv39 walker. Microarchitectural
    /// state — NOT part of the architectural snapshot; SFENCE.VMA is its only invalidation.
    pub tlb: crate::tlb::Tlb,
    /// E2-T20: the just-executed instruction was `WFI`. Microarchitectural (NOT snapshotted),
    /// set by the WFI arm and cleared by the run loop after it reads it for the WFI-deadlock
    /// watchdog.
    pub last_was_wfi: bool,
    /// QUARANTINED CSR scaffolding for the riscv-tests p-env (E0-T19). Present only under
    /// `feature = "zicsr-stub"`; Epic 1 replaces it with the real CSR file above.
    #[cfg(feature = "zicsr-stub")]
    pub csrs: crate::zicsr_stub::CsrFile,
}

impl Default for Hart {
    /// Every constructor funnels through [`Self::reset`] so there is ONE authoritative
    /// initial state (E1-T01). Default resets to the `virt`/Spike vector `DRAM_BASE`.
    fn default() -> Self {
        let mut h = Hart {
            regs: XRegs::default(),
            csr: crate::csr::Csrs::at_reset(),
            resv: None,
            fregs: fregs::FRegs::default(),
            tlb: crate::tlb::Tlb::new(),
            last_was_wfi: false,
            #[cfg(feature = "zicsr-stub")]
            csrs: crate::zicsr_stub::CsrFile::default(),
        };
        h.reset(crate::bus::mmap::DRAM_BASE);
        h
    }
}

impl core::fmt::Debug for Hart {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        // The stable dump format IS the debug representation (one authority).
        core::fmt::Display::fmt(&self.regs, f)
    }
}

/// Sign-extend the low 32 bits — the RV64 `*W` retirement rule (Unprivileged ISA
/// Ch. 5: *W ops compute on 32 bits and sign-extend the 32-bit result).
#[inline(always)]
const fn sext32(x: u32) -> u64 {
    x as i32 as i64 as u64
}

/// The one effective-address formula for every memory op (§2.6): base plus
/// sign-extended immediate in wrapping two's-complement u64 arithmetic.
#[inline(always)]
const fn ea(base: u64, imm: i64) -> u64 {
    base.wrapping_add(imm as u64)
}

/// AMO read-modify-write on the 32-bit (W) value: MIN/MAX are 32-bit comparisons
/// (signed for MIN/MAX, unsigned for MINU/MAXU), NOT 64-bit (A-extension spec).
#[inline(always)]
const fn amo_w(op: crate::decode::AmoOp, old: u32, rhs: u32) -> u32 {
    use crate::decode::AmoOp::*;
    match op {
        Swap => rhs,
        Add => old.wrapping_add(rhs),
        Xor => old ^ rhs,
        And => old & rhs,
        Or => old | rhs,
        Min => {
            if (old as i32) < (rhs as i32) {
                old
            } else {
                rhs
            }
        }
        Max => {
            if (old as i32) > (rhs as i32) {
                old
            } else {
                rhs
            }
        }
        Minu => {
            if old < rhs {
                old
            } else {
                rhs
            }
        }
        Maxu => {
            if old > rhs {
                old
            } else {
                rhs
            }
        }
    }
}

/// AMO read-modify-write on the 64-bit (D) value.
#[inline(always)]
const fn amo_d(op: crate::decode::AmoOp, old: u64, rhs: u64) -> u64 {
    use crate::decode::AmoOp::*;
    match op {
        Swap => rhs,
        Add => old.wrapping_add(rhs),
        Xor => old ^ rhs,
        And => old & rhs,
        Or => old | rhs,
        Min => {
            if (old as i64) < (rhs as i64) {
                old
            } else {
                rhs
            }
        }
        Max => {
            if (old as i64) > (rhs as i64) {
                old
            } else {
                rhs
            }
        }
        Minu => {
            if old < rhs {
                old
            } else {
                rhs
            }
        }
        Maxu => {
            if old > rhs {
                old
            } else {
                rhs
            }
        }
    }
}

/// E3-T12b: the CPU architectural-state snapshot section. Serializes the hart's COMPLETE execution
/// state — pc, x1..=x31 (x0 is hardwired 0), f0..=f31, the LR/SC reservation, and every CSR field
/// (privilege, mstatus/mcause, fflags/frm, the WARL table, cycle/instret + their per-step write
/// flags, the `time` shadow, PMP, Sv48/Sv57 config, the PROBE + debug-trigger CSRs) — so a restore
/// continues to an instruction-identical trace. Restore is ALL-OR-NOTHING: the whole payload is
/// parsed into locals and only committed to `self` once it parses and is fully consumed, so a
/// malformed section leaves the hart untouched.
impl crate::resume::ComponentSnapshot for Hart {
    const SECTION: u32 = crate::resume::section::CPU;

    fn to_snapshot(&self) -> alloc::vec::Vec<u8> {
        let mut v = alloc::vec::Vec::new();
        v.extend_from_slice(&self.regs.pc.to_le_bytes());
        for i in 1..32u8 {
            v.extend_from_slice(&self.regs.read(i).to_le_bytes());
        }
        for i in 0..32u8 {
            v.extend_from_slice(&self.fregs.read_raw(i).to_le_bytes());
        }
        match self.resv {
            Some((addr, w)) => {
                v.push(1);
                v.extend_from_slice(&addr.to_le_bytes());
                v.push(w);
            }
            None => v.push(0),
        }
        self.csr.snapshot_bytes(&mut v);
        v
    }

    fn restore(&mut self, payload: &[u8]) -> Result<(), crate::resume::SnapshotError> {
        let mut r = crate::resume::Reader::new(payload, Self::SECTION);
        let pc = r.u64()?;
        let mut x = [0u64; 32];
        for xi in x.iter_mut().skip(1) {
            *xi = r.u64()?;
        }
        let mut f = [0u64; 32];
        for fi in f.iter_mut() {
            *fi = r.u64()?;
        }
        let resv = match r.u8()? {
            0 => None,
            1 => {
                let addr = r.u64()?;
                let w = r.u8()?;
                Some((addr, w))
            }
            _ => {
                return Err(crate::resume::SnapshotError::BadComponentState { tag: Self::SECTION });
            }
        };
        let csr = crate::csr::Csrs::parse(&mut r)?;
        r.finish()?;
        // Commit — every architectural field overwritten exactly once (x0 stays hardwired 0).
        self.regs.pc = pc;
        for i in 1..32u8 {
            self.regs.write(i, x[i as usize]);
        }
        for i in 0..32u8 {
            self.fregs.write_raw(i, f[i as usize]);
        }
        self.resv = resv;
        self.csr = csr;
        // The fast TLB's entries were validated against the replaced CSR file (satp, PMP), so drop
        // them. Semantically invisible: the architectural TLB is untouched.
        self.tlb.fast_flush();
        Ok(())
    }
}

/// Do the store range `[addr, addr+len)` and the reservation `(ra, rw)` overlap? An
/// overlapping ordinary store invalidates the LR/SC reservation (A-extension spec).
#[inline(always)]
const fn overlaps(addr: u64, len: u64, ra: u64, rw: u64) -> bool {
    addr < ra.wrapping_add(rw) && ra < addr.wrapping_add(len)
}

/// Map a bus fault on a LOAD to its architectural cause (4 misaligned / 5 access),
/// `tval` = the effective address (including wrapped addresses).
#[inline(always)]
const fn load_fault(f: BusFault, addr: u64) -> Trap {
    Trap {
        cause: match f {
            BusFault::Misaligned => Exception::LoadAddrMisaligned,
            BusFault::Access => Exception::LoadAccessFault,
        },
        tval: addr,
    }
}

/// Resolve a conditional branch (§2.5): taken → transfer to `pc + imm`, trapping
/// cause 0 with tval = target when the target is not IALIGN-aligned; not taken →
/// fall through. Returns the retire tuple (no link register for branches).
#[inline(always)]
const fn branch(taken: bool, pc: u64, imm: i64, insn_len: u64) -> Result<(u8, u64, u64), Trap> {
    if taken {
        let target = pc.wrapping_add(imm as u64);
        // IALIGN=16 (C extension always present): only an ODD target is misaligned.
        if target & 1 != 0 {
            return Err(Trap {
                cause: Exception::InstrAddrMisaligned,
                tval: target,
            });
        }
        Ok((0, 0, target))
    } else {
        Ok((0, 0, pc.wrapping_add(insn_len)))
    }
}

/// Map a bus fault on a STORE to its architectural cause (6 misaligned / 7 access).
#[inline(always)]
const fn store_fault(f: BusFault, addr: u64) -> Trap {
    Trap {
        cause: match f {
            BusFault::Misaligned => Exception::StoreAddrMisaligned,
            BusFault::Access => Exception::StoreAccessFault,
        },
        tval: addr,
    }
}

// ── Translated + PMP-checked physical accesses (E1-T15 / E1-T16) ─────────────────────
// Every data access `a` is a VIRTUAL address: it is (1) TRANSLATED through the Sv39 MMU for the
// data effective privilege (`data_priv`, honoring MPRV) — a translation-rule violation is a page
// fault, a PMP-denied PTE read is an access fault; then (2) the resulting PHYSICAL address is
// PMP-checked for the access; then (3) it goes to the bus. A PMP denial on the final access is an
// access fault (load 5 / store-AMO 7) with `tval = the VIRTUAL address`. These are free functions
// taking `&Csrs` so they compose with `execute`'s `&mut self.regs` borrow (disjoint fields). The
// fetch path (page fault 12 / access fault 1, TRUE current mode) is inline in `step_traced`.
use crate::csr::Csrs;
use crate::mmu::{self, Access};
use crate::pmp::PmpAccess;
use crate::tlb::Tlb;

// ── Softmmu fast path (perf overhaul) ─────────────────────────────────────────────────
// Every aligned access first probes the hart's fast TLB (see `crate::tlb`): a hit returns the
// physical address the full slow path below would compute — translation, `finish_leaf`
// permission/Svade decision, and PMP check included — without running any of it. Only successful
// slow-path outcomes are recorded, only for pages that are entirely RAM and entirely PMP-permitted,
// so every fault (and every MMIO access) still takes the exact slow path and raises the exact trap.
// Debug triggers bypass the fast path altogether.

/// Fast-TLB context of a DATA access: the effective privilege (MPRV-aware) in bits 0-1, plus
/// mstatus.SUM (bit 18 → ctx bit 2) and mstatus.MXR (bit 19 → ctx bit 3) — every CSR input
/// `finish_leaf` reads besides satp. Stores ignore MXR (see [`STORE_CTX_MASK`]).
#[inline(always)]
fn data_ctx(csr: &Csrs) -> (crate::csr::Priv, u64) {
    let eff = csr.data_priv();
    (eff, eff as u64 | ((csr.mstatus >> 16) & 0b1100))
}

/// A store's permission never depends on MXR, so its fast context drops that bit.
const STORE_CTX_MASK: u64 = 0b0111;

/// Probe the fast TLB. Returns the physical address on a live hit, `None` otherwise (including
/// whenever a debug trigger is armed).
#[inline(always)]
fn fast_hit(csr: &Csrs, tlb: &mut Tlb, kind: usize, va: u64, ctx: u64) -> Option<u64> {
    if !csr.triggers_idle() {
        return None;
    }
    let pa = tlb.fast_lookup(kind, va, ctx, csr.pmp.revision())?;
    debug_assert_eq!(
        csr.satp(),
        tlb.fast_satp(),
        "satp changed without Tlb::fast_flush (a stale fast entry just hit)"
    );
    Some(pa)
}

/// After a successful slow-path access, publish its outcome for the whole 4 KiB page when that is
/// sound: the physical page is entirely RAM (so the access never needs device dispatch) and every
/// PMP permission in `pmp` holds for the entire page at `eff` (so no sub-page PMP region can make a
/// later access in the page behave differently).
#[inline(never)]
#[allow(clippy::too_many_arguments)]
fn fast_publish(
    csr: &Csrs,
    tlb: &mut Tlb,
    bus: &impl Bus,
    kind: usize,
    va: u64,
    pa: u64,
    ctx: u64,
    slot: u16,
    eff: crate::csr::Priv,
    pmp: &[PmpAccess],
) {
    let page = pa & !0xFFF;
    if slot != crate::tlb::NO_SLOT
        && csr.triggers_idle()
        && bus.ram_contains(page, 4096)
        && pmp.iter().all(|&k| csr.pmp_ok(page, 4096, k, eff))
    {
        tlb.fast_fill(kind, va, pa, ctx, slot, csr.satp(), csr.pmp.revision());
    }
}

/// Translate a data VA and PMP-check the final PA for a LOAD; returns the physical address.
#[inline(always)]
fn xlate_load(
    csr: &Csrs,
    tlb: &mut Tlb,
    bus: &mut impl Bus,
    va: u64,
    len: u64,
) -> Result<u64, Trap> {
    // §3.7.1 exception priority: address-misaligned outranks access-fault and page-fault.
    // The old path let misalignment surface at the BUS (after translate+PMP), so an access
    // that was BOTH misaligned and untranslatable/PMP-denied reported the wrong (lower-
    // priority) cause. Check natural alignment FIRST (`len` is a power of two). NOTE: until
    // E1-T26 lands misaligned-RAM support, every misaligned data access faults here — same
    // as before, only the PRIORITY (and tval anchoring on the VA) is now spec-correct.
    if va & (len - 1) != 0 {
        return Err(Trap {
            cause: Exception::LoadAddrMisaligned,
            tval: va,
        });
    }
    let (eff, ctx) = data_ctx(csr);
    if let Some(pa) = fast_hit(csr, tlb, crate::tlb::FAST_LOAD, va, ctx) {
        return Ok(pa);
    }
    xlate_load_slow(csr, tlb, bus, va, len, eff, ctx)
}

/// The full load translation (fast-TLB miss): translate, PMP-check, then publish the outcome.
#[inline(never)]
fn xlate_load_slow(
    csr: &Csrs,
    tlb: &mut Tlb,
    bus: &mut impl Bus,
    va: u64,
    len: u64,
    eff: crate::csr::Priv,
    ctx: u64,
) -> Result<u64, Trap> {
    let (pa, slot) = mmu::translate_cached_slot(csr, tlb, bus, va, Access::Load, eff)?;
    if !csr.pmp_ok(pa, len, PmpAccess::Read, eff) {
        return Err(Trap {
            cause: Exception::LoadAccessFault,
            tval: va,
        });
    }
    fast_publish(
        csr,
        tlb,
        bus,
        crate::tlb::FAST_LOAD,
        va,
        pa,
        ctx,
        slot,
        eff,
        &[PmpAccess::Read],
    );
    Ok(pa)
}

/// Translate a data VA and PMP-check the final PA for a STORE (incl. SC / AMO write half).
#[inline(always)]
fn xlate_store(
    csr: &Csrs,
    tlb: &mut Tlb,
    bus: &mut impl Bus,
    va: u64,
    len: u64,
) -> Result<u64, Trap> {
    // §3.7.1: store/AMO address-misaligned outranks store access-fault and page-fault. See
    // the xlate_load note. Check natural alignment before translate+PMP.
    if va & (len - 1) != 0 {
        return Err(Trap {
            cause: Exception::StoreAddrMisaligned,
            tval: va,
        });
    }
    let (eff, ctx) = data_ctx(csr);
    let ctx = ctx & STORE_CTX_MASK;
    if let Some(pa) = fast_hit(csr, tlb, crate::tlb::FAST_STORE, va, ctx) {
        return Ok(pa);
    }
    xlate_store_slow(csr, tlb, bus, va, len, eff, ctx, false)
}

/// The full store/AMO translation (fast-TLB miss). `amo` additionally requires PMP read access,
/// as [`xlate_amo`] does. Store fast entries are published only when the whole page is PMP
/// readable AND writable, so the AMO read half can share them.
#[inline(never)]
#[allow(clippy::too_many_arguments)]
fn xlate_store_slow(
    csr: &Csrs,
    tlb: &mut Tlb,
    bus: &mut impl Bus,
    va: u64,
    len: u64,
    eff: crate::csr::Priv,
    ctx: u64,
    amo: bool,
) -> Result<u64, Trap> {
    // A store is translated as Store, which requires W and D=1 in the leaf (Svade), so a store
    // fast entry can only ever mirror a dirty, writable translation.
    let (pa, slot) = mmu::translate_cached_slot(csr, tlb, bus, va, Access::Store, eff)?;
    let pmp_ok = if amo {
        csr.pmp_ok(pa, len, PmpAccess::Read, eff) && csr.pmp_ok(pa, len, PmpAccess::Write, eff)
    } else {
        csr.pmp_ok(pa, len, PmpAccess::Write, eff)
    };
    if !pmp_ok {
        return Err(Trap {
            cause: Exception::StoreAccessFault,
            tval: va,
        });
    }
    fast_publish(
        csr,
        tlb,
        bus,
        crate::tlb::FAST_STORE,
        va,
        pa,
        ctx,
        slot,
        eff,
        &[PmpAccess::Write, PmpAccess::Read],
    );
    Ok(pa)
}

/// The read half of an AMO: translated as a STORE (needs W + D), PMP-checked for BOTH R and W.
#[inline(always)]
fn xlate_amo(
    csr: &Csrs,
    tlb: &mut Tlb,
    bus: &mut impl Bus,
    va: u64,
    len: u64,
) -> Result<u64, Trap> {
    // AMOs require natural alignment (Unpriv §8.2); a misaligned AMO is StoreAddrMisaligned,
    // and §3.7.1 gives it priority over the translate/PMP faults below. E1-T26's misaligned-
    // RAM support explicitly does NOT extend to atomics, so this pre-check is permanent.
    if va & (len - 1) != 0 {
        return Err(Trap {
            cause: Exception::StoreAddrMisaligned,
            tval: va,
        });
    }
    let (eff, ctx) = data_ctx(csr);
    let ctx = ctx & STORE_CTX_MASK;
    // A store fast entry certifies exactly what an AMO needs: Store translation in this context
    // plus whole-page PMP read AND write.
    if let Some(pa) = fast_hit(csr, tlb, crate::tlb::FAST_STORE, va, ctx) {
        return Ok(pa);
    }
    xlate_store_slow(csr, tlb, bus, va, len, eff, ctx, true)
}

// ── Misaligned data-access support (E1-T26) ──────────────────────────────────────────
// We SUPPORT hardware misaligned scalar load/store to main memory (RAM). Because misaligned
// IS supported, a misaligned scalar access raises NO misaligned exception (Priv §3.7.1): the
// access proceeds, and any translation/PMP/range fault it hits is reported AS-IS (page fault,
// or access fault) — the same fault an aligned access to that address would raise. This is
// the key correctness point the Sail reference exposed: a misaligned access to an UNMAPPED
// page is a PAGE FAULT, not `*AddrMisaligned`. Only atomics (AMO/LR/SC) still require natural
// alignment and raise `*AddrMisaligned` (they pre-check it themselves and never reach here).
//
// Scalar accesses span at most two virtual pages. Validate both physical fragments before
// byte decomposition: adjacent virtual pages need not have adjacent physical frames. This
// preserves all-or-nothing data stores and prevents even partial device accesses.

struct MisalignedRam {
    first: u64,
    second: u64,
    first_len: u64,
}

impl MisalignedRam {
    #[inline]
    fn byte_address(&self, index: u64) -> u64 {
        if index < self.first_len {
            self.first + index
        } else {
            self.second + (index - self.first_len)
        }
    }
}

/// Translate and validate every physical fragment before any data access. Faults
/// identify the failing virtual fragment, including the second page boundary.
#[inline]
fn misaligned_ram_plan(
    csr: &Csrs,
    tlb: &mut Tlb,
    bus: &mut impl Bus,
    a: u64,
    len: u64,
    access: Access,
    pmp: PmpAccess,
) -> Result<MisalignedRam, Trap> {
    let eff = csr.data_priv();
    let fault = |tval| Trap {
        cause: match access {
            Access::Load => Exception::LoadAccessFault,
            _ => Exception::StoreAccessFault,
        },
        tval,
    };
    a.checked_add(len - 1).ok_or_else(|| fault(a))?;
    let pa0 = mmu::translate_cached(csr, tlb, bus, a, access, eff)?;
    let first_len = len.min(4096 - (a & 4095));
    let second_len = len - first_len;
    if !bus.ram_contains(pa0, first_len) || !csr.pmp_ok(pa0, first_len, pmp, eff) {
        return Err(fault(a));
    }
    let second = if second_len == 0 {
        pa0
    } else {
        let va = a + first_len;
        let pa = mmu::translate_cached(csr, tlb, bus, va, access, eff)?;
        if !bus.ram_contains(pa, second_len) || !csr.pmp_ok(pa, second_len, pmp, eff) {
            return Err(fault(va));
        }
        pa
    };
    if second_len != 0 && pa0.checked_add(first_len) == Some(second) {
        // Retain whole-access PMP matching when physical memory is contiguous;
        // two separate PMP entries must not accidentally authorize one range.
        if !bus.ram_contains(pa0, len) || !csr.pmp_ok(pa0, len, pmp, eff) {
            return Err(fault(a));
        }
    }
    Ok(MisalignedRam {
        first: pa0,
        second,
        first_len,
    })
}

/// Handle a misaligned LOAD: assemble `len` little-endian bytes from validated RAM fragments.
/// Returns the raw value in a `u64` (caller truncates + sign/zero-extends). A translation
/// fault propagates as page/access fault; a non-RAM/PMP-denied range is a `LoadAccessFault`
/// (never `LoadAddrMisaligned`, since misaligned is supported).
#[inline]
fn misaligned_load(
    csr: &Csrs,
    tlb: &mut Tlb,
    bus: &mut impl Bus,
    a: u64,
    len: u64,
) -> Result<u64, Trap> {
    let plan = misaligned_ram_plan(csr, tlb, bus, a, len, Access::Load, PmpAccess::Read)?;
    let mut val = 0u64;
    for i in 0..len {
        let b = bus
            .load8(plan.byte_address(i))
            .map_err(|f| load_fault(f, a + i))?;
        val |= u64::from(b) << (8 * i);
    }
    Ok(val)
}

/// Handle a misaligned STORE: write `len` little-endian bytes of `v` to validated RAM
/// fragments. A translation fault propagates as page/access fault; a non-RAM/PMP-denied range
/// is a `StoreAccessFault`. Because the gate runs BEFORE any byte is written, a faulting store
/// mutates nothing (no partial write).
#[inline]
fn misaligned_store(
    csr: &Csrs,
    tlb: &mut Tlb,
    bus: &mut impl Bus,
    a: u64,
    len: u64,
    v: u64,
) -> Result<Option<u64>, Trap> {
    let plan = misaligned_ram_plan(csr, tlb, bus, a, len, Access::Store, PmpAccess::Write)?;
    // Both fragments are proven RAM, so these byte stores cannot partially fault — no
    // partial write is observable (the gate ran before any store).
    for i in 0..len {
        bus.store8(plan.byte_address(i), (v >> (8 * i)) as u8)
            .map_err(|f| store_fault(f, a + i))?;
    }
    // A cross-page store must exit a browser JIT chain before the next instruction:
    // its single-physical-page hint cannot describe both entries in the write log.
    Ok((plan.first_len == len).then_some(plan.first))
}

/// The whole aligned-data fast path: a live fast-TLB hit for an aligned `len`-byte access of
/// `kind` at `va`, or `None` (misaligned, trigger armed, or a miss). Always inlined so the width and
/// kind fold into the caller's constants.
#[inline(always)]
fn fast_data(csr: &Csrs, tlb: &mut Tlb, kind: usize, va: u64, len: u64) -> Option<u64> {
    if va & (len - 1) != 0 {
        return None;
    }
    let (_, ctx) = data_ctx(csr);
    let ctx = if kind == crate::tlb::FAST_STORE {
        ctx & STORE_CTX_MASK
    } else {
        ctx
    };
    fast_hit(csr, tlb, kind, va, ctx)
}

macro_rules! checked_load {
    ($name:ident, $slow:ident, $busfn:ident, $ramfn:ident, $ty:ty, $len:expr) => {
        /// Checked, translated load. The fast-TLB hit path is inlined into the caller; everything
        /// else (triggers, misalignment, translation, PMP, faults) lives in the out-of-line slow
        /// half, which is the original checked path.
        #[inline(always)]
        fn $name(csr: &Csrs, tlb: &mut Tlb, bus: &mut impl Bus, a: u64) -> Result<$ty, Trap> {
            if let Some(pa) = fast_data(csr, tlb, crate::tlb::FAST_LOAD, a, $len) {
                return bus.$ramfn(pa).map_err(|f| load_fault(f, a));
            }
            $slow(csr, tlb, bus, a)
        }

        #[inline(never)]
        fn $slow(csr: &Csrs, tlb: &mut Tlb, bus: &mut impl Bus, a: u64) -> Result<$ty, Trap> {
            // E1-T29: a load (data-address) trigger set on `a` fires a Breakpoint before the load.
            if !csr.triggers_idle() && csr.trigger_fires(a, crate::csr::TrigKind::Load) {
                return Err(Trap {
                    cause: Exception::Breakpoint,
                    tval: a,
                });
            }
            // `is_multiple_of` (not `a & (len-1)`) so the byte case (`$len == 1`) is a clean
            // "always aligned" without a `& 0` mask (clippy `bad_bit_mask`).
            if !a.is_multiple_of($len) {
                // Misaligned: handled for RAM (E1-T26); a fault propagates as page/access
                // fault. The assembled LE value is truncated to width here; `execute`
                // sign/zero-extends.
                return misaligned_load(csr, tlb, bus, a, $len).map(|v| v as $ty);
            }
            // Aligned (checked above) and the fast TLB already missed: go straight to the full
            // translation, which also publishes the outcome for the next access.
            let (eff, ctx) = data_ctx(csr);
            let pa = xlate_load_slow(csr, tlb, bus, a, $len, eff, ctx)?;
            bus.$busfn(pa).map_err(|f| load_fault(f, a))
        }
    };
}
macro_rules! checked_store {
    ($name:ident, $with_phys:ident, $slow:ident, $busfn:ident, $ramfn:ident, $ty:ty, $len:expr) => {
        #[inline(always)]
        fn $name(
            csr: &Csrs,
            tlb: &mut Tlb,
            bus: &mut impl Bus,
            a: u64,
            v: $ty,
        ) -> Result<(), Trap> {
            $with_phys(csr, tlb, bus, a, v).map(|_| ())
        }

        /// Checked, translated store returning the physical address when it reached RAM. The
        /// fast-TLB hit path is inlined; a fast entry exists only for an all-RAM page, so a hit
        /// always reports `Some(pa)`, exactly what the slow path's `ram_contains` would.
        #[inline(always)]
        fn $with_phys(
            csr: &Csrs,
            tlb: &mut Tlb,
            bus: &mut impl Bus,
            a: u64,
            v: $ty,
        ) -> Result<Option<u64>, Trap> {
            if let Some(pa) = fast_data(csr, tlb, crate::tlb::FAST_STORE, a, $len) {
                bus.$ramfn(pa, v).map_err(|f| store_fault(f, a))?;
                return Ok(Some(pa));
            }
            $slow(csr, tlb, bus, a, v)
        }

        #[inline(never)]
        fn $slow(
            csr: &Csrs,
            tlb: &mut Tlb,
            bus: &mut impl Bus,
            a: u64,
            v: $ty,
        ) -> Result<Option<u64>, Trap> {
            // E1-T29: a store (data-address) trigger set on `a` fires a Breakpoint before the store.
            if !csr.triggers_idle() && csr.trigger_fires(a, crate::csr::TrigKind::Store) {
                return Err(Trap {
                    cause: Exception::Breakpoint,
                    tval: a,
                });
            }
            // `is_multiple_of` avoids the `& 0` mask for the byte case (`$len == 1`).
            if !a.is_multiple_of($len) {
                return misaligned_store(csr, tlb, bus, a, $len, v as u64);
            }
            let (eff, ctx) = data_ctx(csr);
            let pa = xlate_store_slow(csr, tlb, bus, a, $len, eff, ctx & STORE_CTX_MASK, false)?;
            bus.$busfn(pa, v).map_err(|f| store_fault(f, a))?;
            Ok(bus.ram_contains(pa, $len).then_some(pa))
        }
    };
}

// Ordinary loads (incl. LR): translated as Load.
checked_load!(cload8, cload8_slow, load8, ram_load8, u8, 1);
checked_load!(cload16, cload16_slow, load16, ram_load16, u16, 2);
checked_load!(cload32, cload32_slow, load32, ram_load32, u32, 4);
checked_load!(cload64, cload64_slow, load64, ram_load64, u64, 8);
// The read half of an AMO (its store half re-translates via cstoreN).
#[inline]
fn camoload32(csr: &Csrs, tlb: &mut Tlb, bus: &mut impl Bus, a: u64) -> Result<u32, Trap> {
    let pa = xlate_amo(csr, tlb, bus, a, 4)?;
    bus.load32(pa).map_err(|f| store_fault(f, a))
}
#[inline]
fn camoload64(csr: &Csrs, tlb: &mut Tlb, bus: &mut impl Bus, a: u64) -> Result<u64, Trap> {
    let pa = xlate_amo(csr, tlb, bus, a, 8)?;
    bus.load64(pa).map_err(|f| store_fault(f, a))
}
// Stores (incl. SC and the write half of an AMO): translated as Store.
checked_store!(
    cstore8,
    cstore8_with_phys,
    cstore8_slow,
    store8,
    ram_store8,
    u8,
    1
);
checked_store!(
    cstore16,
    cstore16_with_phys,
    cstore16_slow,
    store16,
    ram_store16,
    u16,
    2
);
checked_store!(
    cstore32,
    cstore32_with_phys,
    cstore32_slow,
    store32,
    ram_store32,
    u32,
    4
);
checked_store!(
    cstore64,
    cstore64_with_phys,
    cstore64_slow,
    store64,
    ram_store64,
    u64,
    8
);

/// A CSR instruction accessed `addr` without trapping. satp is the one CSR the fast TLB relies on
/// without re-reading it per access (its entries are valid only for the ASID/MODE they were filled
/// under), so any satp access drops the fast entries. Semantically invisible: the architectural
/// TLB — which satp writes do NOT flush — is untouched.
#[inline(always)]
fn note_csr_access(tlb: &mut Tlb, addr: u16) {
    if addr == crate::csr::SATP {
        tlb.fast_flush();
    }
}

/// Translate + PMP-check a 2-byte instruction FETCH at virtual address `va` (TRUE current mode —
/// MPRV never affects fetches). Returns the physical address; a translation-rule violation is an
/// instruction page fault (12), a PMP-denied fetch/PTE-read is an instruction access fault (1),
/// both with `tval = va`. Probes the fast TLB first (context = the current privilege, the only CSR
/// input a fetch permission reads besides satp).
#[inline(always)]
fn fetch_xlate(csr: &Csrs, tlb: &mut Tlb, bus: &mut impl Bus, va: u64) -> Result<u64, Trap> {
    let ctx = csr.mode as u64;
    if let Some(pa) = fast_hit(csr, tlb, crate::tlb::FAST_FETCH, va, ctx) {
        return Ok(pa);
    }
    fetch_xlate_slow(csr, tlb, bus, va, ctx)
}

/// The full fetch translation (fast-TLB miss): translate, PMP-check, then publish the outcome.
#[inline(never)]
fn fetch_xlate_slow(
    csr: &Csrs,
    tlb: &mut Tlb,
    bus: &mut impl Bus,
    va: u64,
    ctx: u64,
) -> Result<u64, Trap> {
    let (pa, slot) = mmu::translate_cached_slot(csr, tlb, bus, va, Access::Fetch, csr.mode)?;
    if !csr.pmp_ok(pa, 2, PmpAccess::Exec, csr.mode) {
        return Err(Trap {
            cause: Exception::InstrAccessFault,
            tval: va,
        });
    }
    fast_publish(
        csr,
        tlb,
        bus,
        crate::tlb::FAST_FETCH,
        va,
        pa,
        ctx,
        slot,
        csr.mode,
        &[PmpAccess::Exec],
    );
    Ok(pa)
}

/// Private retirement capture strategy used by the interpreter boundary.  The unit strategy
/// still runs the same instruction match and architectural commit, but never materializes
/// retirement metadata.  Recording remains the only path that constructs a `MemOp`.
pub(crate) trait RetirementCapture {
    type Output;
    fn load(&mut self, addr: u64, len: u8);
    fn store(&mut self, addr: u64, len: u8, value: u64);
    fn finish(&mut self, rd: u8, value: u64) -> Self::Output;
    fn retire(&mut self, output: Self::Output, pc: u64, insn: u32);
}

pub(crate) struct UnitCapture;

impl RetirementCapture for UnitCapture {
    type Output = ();

    #[inline(always)]
    fn load(&mut self, _addr: u64, _len: u8) {}

    #[inline(always)]
    fn store(&mut self, _addr: u64, _len: u8, _value: u64) {}

    #[inline(always)]
    fn finish(&mut self, _rd: u8, _value: u64) {}

    #[inline(always)]
    fn retire(&mut self, _output: (), _pc: u64, _insn: u32) {}
}

pub(crate) struct RecordingCapture<'a, T: crate::trace::TraceSink> {
    sink: &'a mut T,
    mem: Option<crate::trace::MemOp>,
}

impl<'a, T: crate::trace::TraceSink> RecordingCapture<'a, T> {
    #[inline(always)]
    pub(crate) fn new(sink: &'a mut T) -> Self {
        Self { sink, mem: None }
    }
}

impl<T: crate::trace::TraceSink> RetirementCapture for RecordingCapture<'_, T> {
    type Output = (u8, u64, Option<crate::trace::MemOp>);

    #[inline(always)]
    fn load(&mut self, addr: u64, len: u8) {
        self.mem = Some(crate::trace::MemOp {
            addr,
            len,
            is_store: false,
            value: 0,
        });
    }

    #[inline(always)]
    fn store(&mut self, addr: u64, len: u8, value: u64) {
        self.mem = Some(crate::trace::MemOp {
            addr,
            len,
            is_store: true,
            value,
        });
    }

    #[inline(always)]
    fn finish(&mut self, rd: u8, value: u64) -> Self::Output {
        (rd, value, self.mem.take())
    }

    #[inline(always)]
    fn retire(&mut self, output: Self::Output, pc: u64, insn: u32) {
        let (rd, value, mem) = output;
        self.sink.retire(&crate::trace::TraceRecord {
            pc,
            insn,
            rd: (rd != 0).then_some((rd, value)),
            mem,
        });
    }
}

impl Hart {
    /// A hart in the spec reset state, PC at the `virt`/Spike vector `DRAM_BASE`.
    pub fn new() -> Self {
        Self::default()
    }

    /// Return the hart to the privileged-spec §3.4 reset state with `pc = reset_vector`:
    /// all integer registers 0, M-mode, `mstatus = 0` (MIE=0, MPRV=0), `mcause = 0`, and
    /// the hardwired `misa`/`mhartid`. THE single authority for initial state — every
    /// constructor, harness, and (future) power-on-reset funnels through here, so two
    /// resets from any prior state are bit-identical.
    pub fn reset(&mut self, reset_vector: u64) {
        self.regs = XRegs::default();
        self.regs.pc = reset_vector;
        // Sv48/Sv57 support are hardware config bits, not architectural state — carry them over
        // a reset (E1-T18/T28).
        let sv48 = self.csr.sv48;
        let sv57 = self.csr.sv57;
        self.csr = crate::csr::Csrs::at_reset();
        self.csr.sv48 = sv48;
        self.csr.sv57 = sv57;
        self.resv = None;
        self.fregs = fregs::FRegs::default();
        // Reset flushes the TLB — the walker will re-fill it from the reset page tables. The
        // fast-path-disabled differential oracle is host configuration, so it survives a reset.
        let fast = self.tlb.fast_path_enabled();
        self.tlb = crate::tlb::Tlb::new();
        if !fast {
            self.tlb.disable_fast_path();
        }
        #[cfg(feature = "zicsr-stub")]
        {
            self.csrs = crate::zicsr_stub::CsrFile::default();
        }
    }

    /// Fetch at PC, decode, execute one instruction. On `Ok`, the instruction
    /// retired and PC advanced. On `Err(trap)`, PC and all registers are exactly
    /// as they were before the call (trap purity — asserted by tests).
    ///
    /// Non-generic and unchanged for all callers: it uses the private unit capture so the
    /// interpreter does not construct returned retirement metadata.
    #[inline]
    pub fn step(&mut self, bus: &mut impl Bus) -> Result<(), Trap> {
        self.step_with_capture(bus, UnitCapture)
    }

    /// Like [`step`], plus a [`TraceSink`] hook fired AFTER a successful retirement
    /// (never on a trapping step — a faulting instruction produces no retire record).
    /// Even a sink whose `wants_records()` is false remains an observing public traced path;
    /// only [`Self::step`] selects the private unit capture.
    ///
    /// [`step`]: Self::step
    /// [`TraceSink`]: crate::trace::TraceSink
    #[inline]
    pub fn step_traced<T: crate::trace::TraceSink>(
        &mut self,
        bus: &mut impl Bus,
        sink: &mut T,
    ) -> Result<(), Trap> {
        self.step_with_capture(bus, RecordingCapture::new(sink))
    }

    #[inline]
    fn step_with_capture<C: RetirementCapture>(
        &mut self,
        bus: &mut impl Bus,
        mut capture: C,
    ) -> Result<(), Trap> {
        // E1-T14: arm the Zicntr counter-write suppression for this instruction — only a
        // `csrw mcycle`/`csrw minstret` performed during THIS step's execute suppresses its own
        // retirement increment (clears any stale flag from a host-side/direct CSR write).
        self.csr.arm_counters();
        let pc = self.regs.pc;
        // E1-T29: an execute (instruction-address) trigger set on `pc` fires a Breakpoint BEFORE
        // the instruction is fetched/executed (mcontrol "before" timing, action=exception). The
        // hot path pays a single `triggers_idle()` bool test when no trigger is armed.
        if !self.csr.triggers_idle() && self.csr.trigger_fires(pc, crate::csr::TrigKind::Execute) {
            return Err(Trap {
                cause: Exception::Breakpoint,
                tval: pc,
            });
        }
        // E4-T05: fetch/translate/expand-C/decode is factored into the SHARED `decode_at`, so
        // the legacy path and the predecoded block cache decode through ONE function (no
        // divergence). It returns the decoded micro-op or the precise fetch/decode trap.
        let op = match self.decode_at(bus, pc) {
            Ok(op) => op,
            Err(trap) => {
                // The base decoder rejects CSR/xRET encodings. With the quarantined
                // zicsr-stub feature on, execute them there (they retire and are traced —
                // never silently skipped). `trap.tval` carries the raw fetched bits; CSR/xRET
                // are always 4-byte, so for a decode-rejected 32-bit word it equals `insn`.
                // (Compressed ops never expand to CSR/xRET, so the 16-bit-tval illegal-
                // compressed case simply fails the stub's opcode test and re-returns the trap.)
                #[cfg(feature = "zicsr-stub")]
                if trap.cause == Exception::IllegalInstruction {
                    let insn = trap.tval as u32;
                    if let Some((rd, value)) =
                        crate::zicsr_stub::execute(&mut self.regs, &mut self.csrs, insn)
                    {
                        let output = capture.finish(rd, value);
                        capture.retire(output, pc, insn);
                        return Ok(());
                    }
                }
                return Err(trap);
            }
        };
        let output = self.execute(
            bus,
            op.instr,
            u64::from(op.len),
            u64::from(op.raw),
            &mut capture,
        )?;
        // E1-T14: the instruction retired (execute returned Ok) — advance mcycle/minstret AFTER
        // execute, so a `csrr` that just read them observed the pre-retire count (matches Spike).
        self.csr.retire_tick();
        // Retirement hook — reached only when execute() returns Ok, so no record is
        // emitted for a faulting instruction (trap-purity contract).
        capture.retire(output, pc, op.raw);
        Ok(())
    }

    /// E4-T05: the SHARED decoder — fetch + translate + PMP-check + C-expand + decode of the
    /// instruction at virtual address `va`, returning the predecoded [`MicroOp`] or the
    /// precise fetch/decode [`Trap`] (page fault 12 / instr access fault 1 / instr address
    /// misaligned 0 / illegal instruction 2). This is EXACTLY the front half of
    /// [`step_traced`]; both the legacy path and the block cache decode through it so there
    /// is a single source of truth. It performs NO architectural side effects (no counter
    /// arm, no retire) — the caller owns those.
    ///
    /// [`MicroOp`]: crate::dispatch::MicroOp
    /// [`step_traced`]: Self::step_traced
    pub(crate) fn decode_at(
        &mut self,
        bus: &mut impl Bus,
        va: u64,
    ) -> Result<crate::dispatch::MicroOp, Trap> {
        // E1-T16/T15: translate + PMP-check the fetch of the low parcel (Sv39 page fault 12 /
        // instruction access fault 1, TRUE current mode). Fetch the 16-bit parcel from the PA.
        let lo_pa = fetch_xlate(&self.csr, &mut self.tlb, bus, va)?;
        // Fetch the low 16-bit parcel (C extension: `parcel[1:0] != 0b11` ⇒ a 16-bit
        // compressed instruction; else a 32-bit instruction whose upper half is a SEPARATE
        // access, so a straddling second half can fault precisely).
        let lo = match bus.load16(lo_pa) {
            Ok(w) => w,
            Err(BusFault::Access) => {
                return Err(Trap {
                    cause: Exception::InstrAccessFault,
                    tval: va,
                });
            }
            Err(BusFault::Misaligned) => {
                return Err(Trap {
                    cause: Exception::InstrAddrMisaligned,
                    tval: va,
                });
            }
        };
        // `insn` is the word fed to decode (the 32-bit expansion for a compressed op);
        // `trace_insn` is the raw fetched bits for the trace; `insn_len` is 2 or 4.
        let (insn, insn_len, trace_insn): (u32, u8, u32) = if lo & 0b11 != 0b11 {
            match crate::decode_c::expand_c(lo) {
                Ok(w) => (w, 2, u32::from(lo)),
                // A reserved compressed encoding (incl. the all-zeros parcel) is illegal;
                // mtval is the 16-bit pattern.
                Err(_) => {
                    return Err(Trap {
                        cause: Exception::IllegalInstruction,
                        tval: u64::from(lo),
                    });
                }
            }
        } else {
            // E1-T16/T15: the upper parcel is a SEPARATE physical access — translate + PMP-check
            // it independently, so a 32-bit instruction straddling a page boundary faults
            // precisely on the second parcel (tval = the second page's VA; mepc stays the
            // instruction start).
            let hi_pa = fetch_xlate(&self.csr, &mut self.tlb, bus, va.wrapping_add(2))?;
            let hi = match bus.load16(hi_pa) {
                Ok(w) => w,
                Err(BusFault::Access) => {
                    return Err(Trap {
                        cause: Exception::InstrAccessFault,
                        tval: va.wrapping_add(2),
                    });
                }
                Err(BusFault::Misaligned) => {
                    return Err(Trap {
                        cause: Exception::InstrAddrMisaligned,
                        tval: va.wrapping_add(2),
                    });
                }
            };
            let w = (u32::from(hi) << 16) | u32::from(lo);
            (w, 4, w)
        };
        match decode(insn) {
            Ok(instr) => Ok(crate::dispatch::MicroOp {
                instr,
                len: insn_len,
                raw: trace_insn,
            }),
            // The base decoder rejects CSR/xRET encodings (and, under `zicsr-stub`, they stay
            // illegal here — the caller reroutes them to the stub). `tval` is the raw fetched
            // word so the caller can recover `insn` for the stub / for the mtval payload.
            Err(_) => Err(Trap {
                cause: Exception::IllegalInstruction,
                tval: u64::from(trace_insn),
            }),
        }
    }

    /// E4-T05: translate + PMP-check an instruction fetch at `va`, returning the physical
    /// address — the block cache's key. A thin wrapper over the fetch translation used by
    /// [`decode_at`] so the cache can key a block by physical PC without re-deriving it. Served
    /// by the softmmu fast path on a hit (this runs at every block entry). Only the block
    /// cache / JIT use it, which the quarantined `zicsr-stub` build compiles out.
    #[cfg(not(feature = "zicsr-stub"))]
    #[inline]
    pub(crate) fn fetch_phys(&mut self, bus: &mut impl Bus, va: u64) -> Result<u64, Trap> {
        fetch_xlate(&self.csr, &mut self.tlb, bus, va)
    }

    /// Deliver a synchronous exception (E1-T10): the single trap-entry path. `step`/`execute`
    /// stay PURE — they return `Err(Trap)` having touched no architectural state — and the
    /// caller (the run loop, or a test) invokes this to actually *take* the trap: record
    /// mepc (= `epc`, the faulting pc), mcause, and mtval, push the mstatus interrupt stack,
    /// and vector the PC to the M-mode handler. Synchronous traps ALWAYS enter at mtvec BASE
    /// regardless of MODE — vectored dispatch (BASE + 4×cause) is interrupts-only (§3.1.7).
    /// Because `execute` never partially retires, the state written here is the *only* effect
    /// of a trapping instruction, so mepc/mcause/mtval are exact and RAM/regs are pristine.
    /// (medeleg delegation to S-mode lands in E1-T11; until then every trap is taken in M.)
    pub fn take_trap(&mut self, trap: Trap, epc: u64) {
        let cause = trap.cause as u64;
        // E1-T30 diagnostic: surface every illegal-instruction trap so a boot can pinpoint the
        // decoded-but-execute-REJECTED op that SIGILLs glibc userland (musl runs, glibc doesn't).
        // `tval` carries the raw faulting instruction for IllegalInstruction (Priv §3.1.16), so
        // epc + insn together name the exact PC and opcode. Off by default (log-facade gated on a
        // dedicated target); surface with `RUST_LOG="wvm::trap=info"`. Rare in a healthy boot.
        if matches!(trap.cause, Exception::IllegalInstruction) {
            let (mce, sce, mode) = self.csr.counteren_dbg();
            log::log!(
                target: "wvm::trap",
                log::Level::Info,
                "illegal-instruction epc={:#018x} insn={:#010x} mode={:?} mcounteren={:#x} scounteren={:#x}",
                epc,
                trap.tval as u32,
                mode,
                mce,
                sce
            );
        }
        // E1-T11: an exception delegated by medeleg (and taken below M) enters S-mode; else M.
        if self.csr.delegates_to_s(cause, false) {
            self.csr.deliver_trap_s(epc, cause, trap.tval);
            self.regs.pc = self.csr.s_handler_entry(cause, false);
        } else {
            self.csr.deliver_trap_m(epc, cause, trap.tval);
            self.regs.pc = self.csr.m_handler_entry(cause, false);
        }
    }

    /// Deliver a pending asynchronous interrupt (E1-T11) at an instruction boundary. `epc` is
    /// the pc of the NEXT unexecuted instruction — interrupts are precise: the interrupted
    /// instruction fully retired or never ran, so mepc/sepc points at the resume address.
    /// `cause` is the full mcause (Interrupt bit 63 set); `to_s` routes to S-mode (per mideleg).
    /// stval/mtval is 0 for an interrupt. Vectored MODE=1 enters at BASE + 4×cause_num.
    pub fn take_interrupt(&mut self, cause: u64, to_s: bool, epc: u64) {
        let cause_num = cause & !(1u64 << 63);
        if to_s {
            self.csr.deliver_trap_s(epc, cause, 0);
            self.regs.pc = self.csr.s_handler_entry(cause_num, true);
        } else {
            self.csr.deliver_trap_m(epc, cause, 0);
            self.regs.pc = self.csr.m_handler_entry(cause_num, true);
        }
    }

    /// E4-T10: perform a JIT-emitted load — the `env.load(addr, kind)` host import. `addr` is the
    /// guest effective (virtual) address; `kind` is the width+signedness code the translator emits
    /// (`0 lb, 1 lh, 2 lw, 3 ld, 4 lbu, 5 lhu, 6 lwu`). Reuses the interpreter's translated +
    /// PMP-checked + bus-routed load path (incl. triggers, misaligned-RAM, MMIO), so the value —
    /// and any device-read side effect — is byte-identical to the interpreter. A fault returns the
    /// precise [`Trap`]; the executor unwinds the module and returns a precise compiled side-exit.
    pub fn jit_load(&mut self, bus: &mut impl Bus, addr: u64, kind: i32) -> Result<i64, Trap> {
        Ok(match kind {
            0 => cload8(&self.csr, &mut self.tlb, bus, addr)? as i8 as i64,
            1 => cload16(&self.csr, &mut self.tlb, bus, addr)? as i16 as i64,
            2 => cload32(&self.csr, &mut self.tlb, bus, addr)? as i32 as i64,
            3 => cload64(&self.csr, &mut self.tlb, bus, addr)? as i64,
            4 => u64::from(cload8(&self.csr, &mut self.tlb, bus, addr)?) as i64,
            5 => u64::from(cload16(&self.csr, &mut self.tlb, bus, addr)?) as i64,
            6 => u64::from(cload32(&self.csr, &mut self.tlb, bus, addr)?) as i64,
            _ => {
                return Err(Trap {
                    cause: Exception::IllegalInstruction,
                    tval: 0,
                });
            }
        })
    }

    /// E4-T10: perform a JIT-emitted store — the `env.store(addr, val, width)` host import. `width`
    /// is 1/2/4/8 bytes. Reuses the interpreter's translated + PMP-checked + bus-routed store path,
    /// so the memory/MMIO effect is byte-identical to the interpreter. A fault returns the precise
    /// [`Trap`] (the module is unwound and the executor returns a precise compiled side-exit).
    pub fn jit_store(
        &mut self,
        bus: &mut impl Bus,
        addr: u64,
        val: i64,
        width: i32,
    ) -> Result<(), Trap> {
        self.jit_store_with_ram_phys(bus, addr, val, width)
            .map(|_| ())
    }

    /// E4-T34: the exact JIT store path plus the physical RAM address when the successful store
    /// reached ordinary RAM. The browser uses this observation to keep a compiled chain alive
    /// across data stores while still returning before a store can execute a stale compiled code
    /// page. All validation, MMIO routing, write logging, and LR/SC reservation invalidation stay
    /// in the same path as [`Self::jit_store`].
    pub fn jit_store_with_ram_phys(
        &mut self,
        bus: &mut impl Bus,
        addr: u64,
        val: i64,
        width: i32,
    ) -> Result<Option<u64>, Trap> {
        let ram_phys = match width {
            1 => cstore8_with_phys(&self.csr, &mut self.tlb, bus, addr, val as u8)?,
            2 => cstore16_with_phys(&self.csr, &mut self.tlb, bus, addr, val as u16)?,
            4 => cstore32_with_phys(&self.csr, &mut self.tlb, bus, addr, val as u32)?,
            8 => cstore64_with_phys(&self.csr, &mut self.tlb, bus, addr, val as u64)?,
            _ => {
                return Err(Trap {
                    cause: Exception::IllegalInstruction,
                    tval: 0,
                });
            }
        };
        // A-extension reservation invalidation (E1-T04, mirrored for the JIT store path): a
        // successful plain store that overlaps the reservation granule clears it. In the
        // interpreter this lives in the retire tail of `execute`; the JIT store import bypasses
        // that path, so it must fire the SAME invalidation here or an interpreter-LR / JIT-store /
        // interpreter-SC sequence would let a stale reservation survive (tier-switch incoherence).
        // Runs only after a successful (non-faulting) store, matching the interpreter (a faulting
        // store never invalidates).
        self.note_jit_ram_store(addr, u64::from(width as u32));
        Ok(ram_phys)
    }

    /// Apply the reservation side effect of a successful raw inline-RAM JIT store. The store
    /// already committed its bytes in the shared wasm memory, so this helper deliberately performs
    /// no translation or bus access; it only mirrors the interpreter's successful-store reservation
    /// invalidation.
    pub fn note_jit_ram_store(&mut self, addr: u64, width: u64) {
        if let Some((ra, rw)) = self.resv
            && overlaps(addr, width, ra, u64::from(rw))
        {
            self.resv = None;
        }
    }

    /// Return the physical address of an aligned JIT memory access when the translated range is
    /// ordinary guest RAM. This is the refill half of the browser inline-TLB path: the access
    /// itself still goes through [`Self::jit_load`] / [`Self::jit_store`], and this query only
    /// publishes a successful RAM translation to the generated code. Device windows, faults,
    /// misaligned accesses, and ranges outside RAM return `None` so they stay on the exact host
    /// slow path.
    pub fn jit_ram_phys(
        &mut self,
        bus: &mut impl Bus,
        addr: u64,
        width: u64,
        write: bool,
    ) -> Result<Option<u64>, Trap> {
        if width == 0 || addr & (width - 1) != 0 {
            return Ok(None);
        }
        let pa = if write {
            xlate_store(&self.csr, &mut self.tlb, bus, addr, width)?
        } else {
            xlate_load(&self.csr, &mut self.tlb, bus, addr, width)?
        };
        Ok(bus.ram_contains(pa, width).then_some(pa))
    }

    /// A generated inline-TLB tag authorizes every aligned access in a 4 KiB
    /// page. An individual successful transfer is insufficient: PMP can grant
    /// only one word, or deny a smaller region inside an otherwise allowed page.
    /// Keep those pages on checked imports, without changing the completed access.
    pub fn jit_can_inline_ram_page(&self, bus: &impl Bus, pa: u64, write: bool) -> bool {
        let page = pa & !0xfff;
        self.csr.triggers_idle()
            && bus.ram_contains(page, 4096)
            && self.csr.pmp.check(
                page,
                4096,
                if write {
                    crate::pmp::PmpAccess::Write
                } else {
                    crate::pmp::PmpAccess::Read
                },
                self.csr.data_priv(),
            )
    }

    /// E4-T14: perform a JIT-emitted LR (load-reserved) — the `env.lr(addr, width)` host import.
    /// `width` is 4 (`lr.w`) or 8 (`lr.d`). Byte-identical to the interpreter's `LrW`/`LrD` arms:
    /// natural-alignment pre-check (misaligned → `LoadAddrMisaligned`, reservation untouched), the
    /// interpreter's translated + PMP-checked load, then the reservation set to `(addr, width)` in
    /// the SHARED `self.resv` — so a JIT LR + interpreter SC (or vice versa across a tier switch) is
    /// coherent. Returns the sign-extended loaded value (rd), or the precise fault [`Trap`].
    pub fn jit_lr(&mut self, bus: &mut impl Bus, addr: u64, width: i32) -> Result<i64, Trap> {
        match width {
            4 => {
                if !addr.is_multiple_of(4) {
                    return Err(Trap {
                        cause: Exception::LoadAddrMisaligned,
                        tval: addr,
                    });
                }
                let v = cload32(&self.csr, &mut self.tlb, bus, addr)?;
                self.resv = Some((addr, 4));
                Ok(sext32(v) as i64)
            }
            8 => {
                if !addr.is_multiple_of(8) {
                    return Err(Trap {
                        cause: Exception::LoadAddrMisaligned,
                        tval: addr,
                    });
                }
                let v = cload64(&self.csr, &mut self.tlb, bus, addr)?;
                self.resv = Some((addr, 8));
                Ok(v as i64)
            }
            _ => Err(Trap {
                cause: Exception::IllegalInstruction,
                tval: 0,
            }),
        }
    }

    /// E4-T14: perform a JIT-emitted SC (store-conditional) — the `env.sc(addr, val, width)` host
    /// import. Byte-identical to the interpreter's `ScW`/`ScD` arms: natural-alignment pre-check
    /// (misaligned → `StoreAddrMisaligned`, reservation preserved), then success IFF the SHARED
    /// reservation is exactly `(addr, width)` (a width or address mismatch fails). Either outcome
    /// consumes the reservation. On success the value is stored and `0` is returned; on failure
    /// nothing is stored and `1` is returned. Returns the precise fault [`Trap`] on a store fault.
    pub fn jit_sc(
        &mut self,
        bus: &mut impl Bus,
        addr: u64,
        val: i64,
        width: i32,
    ) -> Result<i64, Trap> {
        match width {
            4 => {
                if !addr.is_multiple_of(4) {
                    return Err(Trap {
                        cause: Exception::StoreAddrMisaligned,
                        tval: addr,
                    });
                }
                let success = self.resv == Some((addr, 4));
                self.resv = None;
                if success {
                    cstore32(&self.csr, &mut self.tlb, bus, addr, val as u32)?;
                    Ok(0)
                } else {
                    Ok(1)
                }
            }
            8 => {
                if !addr.is_multiple_of(8) {
                    return Err(Trap {
                        cause: Exception::StoreAddrMisaligned,
                        tval: addr,
                    });
                }
                let success = self.resv == Some((addr, 8));
                self.resv = None;
                if success {
                    cstore64(&self.csr, &mut self.tlb, bus, addr, val as u64)?;
                    Ok(0)
                } else {
                    Ok(1)
                }
            }
            _ => Err(Trap {
                cause: Exception::IllegalInstruction,
                tval: 0,
            }),
        }
    }

    /// E4-T14: perform a JIT-emitted AMO — the `env.amo(addr, val, op, width)` host import. `op` is
    /// the [`crate::decode::AmoOp`] discriminant the translator emits (0 swap, 1 add, 2 xor, 3 and,
    /// 4 or, 5 min, 6 max, 7 minu, 8 maxu). Byte-identical to the interpreter's `AmoW`/`AmoD` arms:
    /// natural-alignment pre-check (misaligned → `StoreAddrMisaligned`), atomic (single-hart RMW)
    /// load → op → store through the interpreter's AMO-translated path, and — like every successful
    /// store — clears an overlapping reservation. Returns the ORIGINAL loaded value, sign-extended
    /// for `.w`, or the precise fault [`Trap`].
    pub fn jit_amo(
        &mut self,
        bus: &mut impl Bus,
        addr: u64,
        val: i64,
        op: i32,
        width: i32,
    ) -> Result<i64, Trap> {
        let amo_op = match op {
            0 => crate::decode::AmoOp::Swap,
            1 => crate::decode::AmoOp::Add,
            2 => crate::decode::AmoOp::Xor,
            3 => crate::decode::AmoOp::And,
            4 => crate::decode::AmoOp::Or,
            5 => crate::decode::AmoOp::Min,
            6 => crate::decode::AmoOp::Max,
            7 => crate::decode::AmoOp::Minu,
            8 => crate::decode::AmoOp::Maxu,
            _ => {
                return Err(Trap {
                    cause: Exception::IllegalInstruction,
                    tval: 0,
                });
            }
        };
        let (old, len) = match width {
            4 => {
                if !addr.is_multiple_of(4) {
                    return Err(Trap {
                        cause: Exception::StoreAddrMisaligned,
                        tval: addr,
                    });
                }
                let old = camoload32(&self.csr, &mut self.tlb, bus, addr)?;
                let new = amo_w(amo_op, old, val as u32);
                cstore32(&self.csr, &mut self.tlb, bus, addr, new)?;
                (sext32(old) as i64, 4u64)
            }
            8 => {
                if !addr.is_multiple_of(8) {
                    return Err(Trap {
                        cause: Exception::StoreAddrMisaligned,
                        tval: addr,
                    });
                }
                let old = camoload64(&self.csr, &mut self.tlb, bus, addr)?;
                let new = amo_d(amo_op, old, val as u64);
                cstore64(&self.csr, &mut self.tlb, bus, addr, new)?;
                (old as i64, 8u64)
            }
            _ => {
                return Err(Trap {
                    cause: Exception::IllegalInstruction,
                    tval: 0,
                });
            }
        };
        // The AMO write is a store: clear an overlapping reservation, as the interpreter's retire
        // tail does for the AMO `mem` op.
        if let Some((ra, rw)) = self.resv
            && overlaps(addr, len, ra, u64::from(rw))
        {
            self.resv = None;
        }
        Ok(old)
    }

    /// Pure integer semantics shared by ordinary execution and cached replay. These instructions
    /// cannot trap or observe the bus, CSRs, FP state or reservation; only their integer result is
    /// computed here. Writeback, PC advancement and retirement capture remain with the caller.
    #[inline(always)]
    pub(crate) fn integer_result(&self, instr: Instr) -> Option<(u8, u64)> {
        use Instr::*;
        let r = &self.regs;
        let pc = r.pc;
        Some(match instr {
            Lui { rd, imm } => (rd, imm as u64),
            Auipc { rd, imm } => (rd, pc.wrapping_add(imm as u64)),

            Addi { rd, rs1, imm } => (rd, r.read(rs1).wrapping_add(imm as u64)),
            Slti { rd, rs1, imm } => (rd, ((r.read(rs1) as i64) < imm) as u64),
            Sltiu { rd, rs1, imm } => (rd, (r.read(rs1) < imm as u64) as u64),
            Xori { rd, rs1, imm } => (rd, r.read(rs1) ^ imm as u64),
            Ori { rd, rs1, imm } => (rd, r.read(rs1) | imm as u64),
            Andi { rd, rs1, imm } => (rd, r.read(rs1) & imm as u64),
            Slli { rd, rs1, shamt } => (rd, r.read(rs1) << shamt),
            Srli { rd, rs1, shamt } => (rd, r.read(rs1) >> shamt),
            Srai { rd, rs1, shamt } => (rd, ((r.read(rs1) as i64) >> shamt) as u64),

            Addiw { rd, rs1, imm } => (rd, sext32(r.read(rs1).wrapping_add(imm as u64) as u32)),
            Slliw { rd, rs1, shamt } => (rd, sext32((r.read(rs1) as u32) << shamt)),
            Srliw { rd, rs1, shamt } => (rd, sext32((r.read(rs1) as u32) >> shamt)),
            Sraiw { rd, rs1, shamt } => {
                (rd, sext32((((r.read(rs1) as u32) as i32) >> shamt) as u32))
            }

            Add { rd, rs1, rs2 } => (rd, r.read(rs1).wrapping_add(r.read(rs2))),
            Sub { rd, rs1, rs2 } => (rd, r.read(rs1).wrapping_sub(r.read(rs2))),
            // Register shifts: RV64 uses rs2[5:0]; the *W forms use rs2[4:0] (Ch. 5).
            Sll { rd, rs1, rs2 } => (rd, r.read(rs1) << (r.read(rs2) & 0x3F)),
            Slt { rd, rs1, rs2 } => (rd, ((r.read(rs1) as i64) < (r.read(rs2) as i64)) as u64),
            Sltu { rd, rs1, rs2 } => (rd, (r.read(rs1) < r.read(rs2)) as u64),
            Xor { rd, rs1, rs2 } => (rd, r.read(rs1) ^ r.read(rs2)),
            Srl { rd, rs1, rs2 } => (rd, r.read(rs1) >> (r.read(rs2) & 0x3F)),
            Sra { rd, rs1, rs2 } => (rd, ((r.read(rs1) as i64) >> (r.read(rs2) & 0x3F)) as u64),
            Or { rd, rs1, rs2 } => (rd, r.read(rs1) | r.read(rs2)),
            And { rd, rs1, rs2 } => (rd, r.read(rs1) & r.read(rs2)),

            Addw { rd, rs1, rs2 } => (
                rd,
                sext32((r.read(rs1) as u32).wrapping_add(r.read(rs2) as u32)),
            ),
            Subw { rd, rs1, rs2 } => (
                rd,
                sext32((r.read(rs1) as u32).wrapping_sub(r.read(rs2) as u32)),
            ),
            Sllw { rd, rs1, rs2 } => (rd, sext32((r.read(rs1) as u32) << (r.read(rs2) & 0x1F))),
            Srlw { rd, rs1, rs2 } => (rd, sext32((r.read(rs1) as u32) >> (r.read(rs2) & 0x1F))),
            Sraw { rd, rs1, rs2 } => (
                rd,
                sext32((((r.read(rs1) as u32) as i32) >> (r.read(rs2) & 0x1F)) as u32),
            ),

            // ── M extension (E1-T03) ────────────────────────────────────────
            // Products use wide intermediates; the div/rem edge cases are the spec's
            // trap-free definitions (Unprivileged ISA "M" chapter) — Rust's own
            // divide-by-zero and MIN/-1 overflow panics must never be reached, so every
            // divisor-zero and overflow case is branched out BEFORE the `/` or `%`.
            Mul { rd, rs1, rs2 } => (rd, r.read(rs1).wrapping_mul(r.read(rs2))),
            // MULH: high 64 of the signed×signed 128-bit product.
            Mulh { rd, rs1, rs2 } => {
                let p = (r.read(rs1) as i64 as i128) * (r.read(rs2) as i64 as i128);
                (rd, (p >> 64) as u64)
            }
            // MULHSU: high 64 of signed(rs1) × unsigned(rs2). The tricky one: rs1 is
            // sign-extended into i128 (may be negative); rs2 is ZERO-extended (u64→u128,
            // always in 0..2^64, so non-negative) then viewed as i128. Their exact
            // product fits in i128 (|i64|·u64 < 2^127); an arithmetic >>64 keeps the sign.
            Mulhsu { rd, rs1, rs2 } => {
                let p = (r.read(rs1) as i64 as i128) * (r.read(rs2) as u128 as i128);
                (rd, (p >> 64) as u64)
            }
            // MULHU: high 64 of the unsigned×unsigned 128-bit product.
            Mulhu { rd, rs1, rs2 } => {
                let p = (r.read(rs1) as u128) * (r.read(rs2) as u128);
                (rd, (p >> 64) as u64)
            }
            Div { rd, rs1, rs2 } => {
                let (a, b) = (r.read(rs1) as i64, r.read(rs2) as i64);
                let q = if b == 0 {
                    -1i64 // div by zero → all ones
                } else if a == i64::MIN && b == -1 {
                    i64::MIN // signed overflow → dividend
                } else {
                    a.wrapping_div(b)
                };
                (rd, q as u64)
            }
            // Unsigned div/rem: checked_* returns None ONLY on divisor zero (no unsigned
            // overflow case), giving the spec's all-ones / dividend results panic-free.
            Divu { rd, rs1, rs2 } => {
                let (a, b) = (r.read(rs1), r.read(rs2));
                (rd, a.checked_div(b).unwrap_or(u64::MAX))
            }
            Rem { rd, rs1, rs2 } => {
                let (a, b) = (r.read(rs1) as i64, r.read(rs2) as i64);
                let rem = if b == 0 {
                    a // rem by zero → dividend
                } else if a == i64::MIN && b == -1 {
                    0 // overflow → 0
                } else {
                    a.wrapping_rem(b)
                };
                (rd, rem as u64)
            }
            Remu { rd, rs1, rs2 } => {
                let (a, b) = (r.read(rs1), r.read(rs2));
                (rd, a.checked_rem(b).unwrap_or(a))
            }
            // W forms: operate on the low 32 bits (upper bits of the sources are
            // ignored per spec), then sign-extend the 32-bit result to 64.
            Mulw { rd, rs1, rs2 } => (
                rd,
                sext32((r.read(rs1) as u32).wrapping_mul(r.read(rs2) as u32)),
            ),
            Divw { rd, rs1, rs2 } => {
                let (a, b) = (r.read(rs1) as i32, r.read(rs2) as i32);
                let q = if b == 0 {
                    -1i32
                } else if a == i32::MIN && b == -1 {
                    i32::MIN
                } else {
                    a.wrapping_div(b)
                };
                (rd, sext32(q as u32))
            }
            // DIVUW: unsigned 32-bit divide, result STILL sign-extended from bit 31
            // (so a 0xFFFF_FFFF quotient reads back as 0xFFFF_FFFF_FFFF_FFFF).
            Divuw { rd, rs1, rs2 } => {
                let (a, b) = (r.read(rs1) as u32, r.read(rs2) as u32);
                (rd, sext32(a.checked_div(b).unwrap_or(u32::MAX)))
            }
            Remw { rd, rs1, rs2 } => {
                let (a, b) = (r.read(rs1) as i32, r.read(rs2) as i32);
                let rem = if b == 0 {
                    a
                } else if a == i32::MIN && b == -1 {
                    0
                } else {
                    a.wrapping_rem(b)
                };
                (rd, sext32(rem as u32))
            }
            Remuw { rd, rs1, rs2 } => {
                let (a, b) = (r.read(rs1) as u32, r.read(rs2) as u32);
                (rd, sext32(a.checked_rem(b).unwrap_or(a)))
            }

            _ => return None,
        })
    }

    /// Execute a decoded instruction with a private retirement capture strategy. Every arm
    /// either fully retires (writeback + PC advance) or returns a trap having touched nothing.
    ///
    /// `pub(crate)` so the E4-T05 block-cache executor ([`crate::Machine::step_cached`]) can
    /// feed a memoized micro-op into the SAME execute the legacy path uses.
    pub(crate) fn execute<C: RetirementCapture>(
        &mut self,
        bus: &mut impl Bus,
        instr: Instr,
        insn_len: u64,
        // The mtval payload for an ILLEGAL-INSTRUCTION trap: the ORIGINAL fetched bits,
        // zero-extended — 16 bits for a compressed op, 32 for a full one (Priv §3.1.16 /
        // E1-T10). Not `insn`, which is the 32-bit *expansion* of a compressed instruction;
        // a compressed op that is illegal at execute (e.g. C.FLD with FS=Off) must report its
        // 2-byte parcel, not the expansion. (Compressed ops never expand to CSR/xRET, so the
        // CSR-access sites below where this equals `insn` are unaffected.)
        raw_insn: u64,
        capture: &mut C,
    ) -> Result<C::Output, Trap> {
        use Instr::*;
        if let Some((rd, value)) = self.integer_result(instr) {
            self.regs.write(rd, value);
            self.regs.pc = self.regs.pc.wrapping_add(insn_len);
            return Ok(capture.finish(rd, value));
        }
        // F/D: every FP instruction requires mstatus.FS != Off (E1-T06). Checked before any
        // architectural read, so an FS=Off trap leaves fflags and the f-registers untouched.
        if is_fp(&instr) && self.csr.fp_off() {
            return Err(Trap {
                cause: Exception::IllegalInstruction,
                tval: raw_insn,
            });
        }
        let r = &mut self.regs;
        // This effect is independent of optional retirement metadata. It is set only after a
        // store succeeds, and is the sole input to reservation invalidation below.
        let mut successful_store: Option<(u64, u8)> = None;
        let pc = r.pc;
        let pc_next = pc.wrapping_add(insn_len);
        // Per-op result and successor PC; applied at the single retirement point
        // below (x0-discard and PC update live in one place).
        let (rd, value, next_pc): (u8, u64, u64) = match instr {
            Lui { .. }
            | Auipc { .. }
            | Addi { .. }
            | Slti { .. }
            | Sltiu { .. }
            | Xori { .. }
            | Ori { .. }
            | Andi { .. }
            | Slli { .. }
            | Srli { .. }
            | Srai { .. }
            | Addiw { .. }
            | Slliw { .. }
            | Srliw { .. }
            | Sraiw { .. }
            | Add { .. }
            | Sub { .. }
            | Sll { .. }
            | Slt { .. }
            | Sltu { .. }
            | Xor { .. }
            | Srl { .. }
            | Sra { .. }
            | Or { .. }
            | And { .. }
            | Addw { .. }
            | Subw { .. }
            | Sllw { .. }
            | Srlw { .. }
            | Sraw { .. }
            | Mul { .. }
            | Mulh { .. }
            | Mulhsu { .. }
            | Mulhu { .. }
            | Div { .. }
            | Divu { .. }
            | Rem { .. }
            | Remu { .. }
            | Mulw { .. }
            | Divw { .. }
            | Divuw { .. }
            | Remw { .. }
            | Remuw { .. } => {
                unreachable!("pure integer instructions returned before general execution")
            }

            // ── A extension (E1-T04) ────────────────────────────────────────
            // aq/rl are decoded but no-ops for a single in-order hart. LR/SC/AMO require
            // natural alignment: a misaligned LR faults cause 4 (load), a misaligned
            // SC/AMO faults cause 6 (store/AMO) — checked before any memory touch, so a
            // misalignment trap leaves memory and the reservation unchanged.
            LrW { rd, rs1, .. } => {
                let a = r.read(rs1);
                // LR requires natural alignment (Unpriv §8.2). This was implicit while the
                // load path faulted ALL misaligned accesses; E1-T26 made ordinary loads
                // support misaligned RAM, so LR must pre-check alignment itself (mirrors SC).
                if !a.is_multiple_of(4) {
                    return Err(Trap {
                        cause: Exception::LoadAddrMisaligned,
                        tval: a,
                    });
                }
                let v = cload32(&self.csr, &mut self.tlb, bus, a)?;
                self.resv = Some((a, 4));
                capture.load(a, 4);
                (rd, sext32(v), pc_next)
            }
            LrD { rd, rs1, .. } => {
                let a = r.read(rs1);
                if !a.is_multiple_of(8) {
                    return Err(Trap {
                        cause: Exception::LoadAddrMisaligned,
                        tval: a,
                    });
                }
                let v = cload64(&self.csr, &mut self.tlb, bus, a)?;
                self.resv = Some((a, 8));
                capture.load(a, 8);
                (rd, v, pc_next)
            }
            // SC succeeds only against a valid reservation for the SAME address AND width
            // (a width mismatch, e.g. LR.W then SC.D, fails — never a wrong-width write).
            // Success writes memory and rd=0; failure writes nothing and rd=1. Either way
            // the reservation is consumed. Misalignment is checked first (reservation
            // preserved on that trap).
            ScW { rd, rs1, rs2, .. } => {
                let a = r.read(rs1);
                if !a.is_multiple_of(4) {
                    return Err(Trap {
                        cause: Exception::StoreAddrMisaligned,
                        tval: a,
                    });
                }
                let success = self.resv == Some((a, 4));
                self.resv = None;
                if success {
                    let val = r.read(rs2);
                    cstore32(&self.csr, &mut self.tlb, bus, a, val as u32)?;
                    successful_store = Some((a, 4));
                    capture.store(a, 4, val);
                    (rd, 0, pc_next)
                } else {
                    (rd, 1, pc_next)
                }
            }
            ScD { rd, rs1, rs2, .. } => {
                let a = r.read(rs1);
                if !a.is_multiple_of(8) {
                    return Err(Trap {
                        cause: Exception::StoreAddrMisaligned,
                        tval: a,
                    });
                }
                let success = self.resv == Some((a, 8));
                self.resv = None;
                if success {
                    let val = r.read(rs2);
                    cstore64(&self.csr, &mut self.tlb, bus, a, val)?;
                    successful_store = Some((a, 8));
                    capture.store(a, 8, val);
                    (rd, 0, pc_next)
                } else {
                    (rd, 1, pc_next)
                }
            }
            // AMO: atomic load → op → store (single-threaded, so a plain RMW). rd gets the
            // OLD value (sign-extended for W). AMO faults are store/AMO-class (cause 6/7).
            // Alignment is pre-checked, so the load/store legs only ever access-fault.
            AmoW {
                op, rd, rs1, rs2, ..
            } => {
                let a = r.read(rs1);
                if !a.is_multiple_of(4) {
                    return Err(Trap {
                        cause: Exception::StoreAddrMisaligned,
                        tval: a,
                    });
                }
                let old = camoload32(&self.csr, &mut self.tlb, bus, a)?;
                let new = amo_w(op, old, r.read(rs2) as u32);
                cstore32(&self.csr, &mut self.tlb, bus, a, new)?;
                successful_store = Some((a, 4));
                capture.store(a, 4, new as u64);
                (rd, sext32(old), pc_next)
            }
            AmoD {
                op, rd, rs1, rs2, ..
            } => {
                let a = r.read(rs1);
                if !a.is_multiple_of(8) {
                    return Err(Trap {
                        cause: Exception::StoreAddrMisaligned,
                        tval: a,
                    });
                }
                let old = camoload64(&self.csr, &mut self.tlb, bus, a)?;
                let new = amo_d(op, old, r.read(rs2));
                cstore64(&self.csr, &mut self.tlb, bus, a, new)?;
                successful_store = Some((a, 8));
                capture.store(a, 8, new);
                (rd, old, pc_next)
            }

            // FENCE retires as a no-op: single in-order hart, no reordering agents
            // at Level 0. Write to x0 so it flows through the common retire path.
            Fence { .. } => (0, 0, pc_next),

            // Loads (E0-T08): effective address = rs1 + sext(imm), wrapping.
            // A bus fault maps to cause 4/5 with tval = the effective address; the
            // `?` returns BEFORE writeback, so rd (even when rd == rs1) and PC are
            // untouched on fault. LB/LH/LW sign-extend; LBU/LHU/LWU zero-extend.
            Lb { rd, rs1, imm } => {
                let a = ea(r.read(rs1), imm);
                let v = cload8(&self.csr, &mut self.tlb, bus, a)?;
                capture.load(a, 1);
                (rd, v as i8 as i64 as u64, pc_next)
            }
            Lh { rd, rs1, imm } => {
                let a = ea(r.read(rs1), imm);
                let v = cload16(&self.csr, &mut self.tlb, bus, a)?;
                capture.load(a, 2);
                (rd, v as i16 as i64 as u64, pc_next)
            }
            Lw { rd, rs1, imm } => {
                let a = ea(r.read(rs1), imm);
                let v = cload32(&self.csr, &mut self.tlb, bus, a)?;
                capture.load(a, 4);
                (rd, v as i32 as i64 as u64, pc_next)
            }
            Ld { rd, rs1, imm } => {
                let a = ea(r.read(rs1), imm);
                let v = cload64(&self.csr, &mut self.tlb, bus, a)?;
                capture.load(a, 8);
                (rd, v, pc_next)
            }
            Lbu { rd, rs1, imm } => {
                let a = ea(r.read(rs1), imm);
                let v = cload8(&self.csr, &mut self.tlb, bus, a)?;
                capture.load(a, 1);
                (rd, u64::from(v), pc_next)
            }
            Lhu { rd, rs1, imm } => {
                let a = ea(r.read(rs1), imm);
                let v = cload16(&self.csr, &mut self.tlb, bus, a)?;
                capture.load(a, 2);
                (rd, u64::from(v), pc_next)
            }
            Lwu { rd, rs1, imm } => {
                let a = ea(r.read(rs1), imm);
                let v = cload32(&self.csr, &mut self.tlb, bus, a)?;
                capture.load(a, 4);
                (rd, u64::from(v), pc_next)
            }

            // Stores (E0-T08): cause 6/7 with tval = effective address. A faulting
            // bus store writes nothing (E0-T03), so purity holds; on success the
            // bus write IS the side effect and retirement is a no-op write to x0.
            Sb { rs1, rs2, imm } => {
                let a = ea(r.read(rs1), imm);
                let v = r.read(rs2);
                cstore8(&self.csr, &mut self.tlb, bus, a, v as u8)?;
                successful_store = Some((a, 1));
                capture.store(a, 1, v);
                (0, 0, pc_next)
            }
            Sh { rs1, rs2, imm } => {
                let a = ea(r.read(rs1), imm);
                let v = r.read(rs2);
                cstore16(&self.csr, &mut self.tlb, bus, a, v as u16)?;
                successful_store = Some((a, 2));
                capture.store(a, 2, v);
                (0, 0, pc_next)
            }
            Sw { rs1, rs2, imm } => {
                let a = ea(r.read(rs1), imm);
                let v = r.read(rs2);
                cstore32(&self.csr, &mut self.tlb, bus, a, v as u32)?;
                successful_store = Some((a, 4));
                capture.store(a, 4, v);
                (0, 0, pc_next)
            }
            Sd { rs1, rs2, imm } => {
                let a = ea(r.read(rs1), imm);
                let v = r.read(rs2);
                cstore64(&self.csr, &mut self.tlb, bus, a, v)?;
                successful_store = Some((a, 8));
                capture.store(a, 8, v);
                (0, 0, pc_next)
            }

            // Jumps (E0-T09, §2.5): target computed FIRST (so jalr rd==rs1 uses the
            // old rs1), link = pc+4 written only on success; a misaligned target
            // traps cause 0 with tval = target and writes nothing.
            Jal { rd, imm } => {
                let target = pc.wrapping_add(imm as u64);
                if target & 1 != 0 {
                    return Err(Trap {
                        cause: Exception::InstrAddrMisaligned,
                        tval: target,
                    });
                }
                (rd, pc_next, target)
            }
            Jalr { rd, rs1, imm } => {
                let target = ea(r.read(rs1), imm) & !1; // spec: clear bit 0
                if target & 1 != 0 {
                    return Err(Trap {
                        cause: Exception::InstrAddrMisaligned,
                        tval: target,
                    });
                }
                (rd, pc_next, target)
            }

            // Branches (E0-T09): only a TAKEN branch can trap on target misalignment;
            // not-taken retires normally regardless of the encoded target.
            Beq { rs1, rs2, imm } => branch(r.read(rs1) == r.read(rs2), pc, imm, insn_len)?,
            Bne { rs1, rs2, imm } => branch(r.read(rs1) != r.read(rs2), pc, imm, insn_len)?,
            Blt { rs1, rs2, imm } => branch(
                (r.read(rs1) as i64) < (r.read(rs2) as i64),
                pc,
                imm,
                insn_len,
            )?,
            Bge { rs1, rs2, imm } => branch(
                (r.read(rs1) as i64) >= (r.read(rs2) as i64),
                pc,
                imm,
                insn_len,
            )?,
            Bltu { rs1, rs2, imm } => branch(r.read(rs1) < r.read(rs2), pc, imm, insn_len)?,
            Bgeu { rs1, rs2, imm } => branch(r.read(rs1) >= r.read(rs2), pc, imm, insn_len)?,

            // ECALL / EBREAK (E0-T11): precise traps, PC left at the instruction's
            // own address, nothing else mutated. ECALL → cause 11 (env-call-from-M,
            // our only mode at Level 0), tval 0. EBREAK → cause 3 (breakpoint),
            // tval = pc. The host decides what happens next.
            Ecall => {
                // Environment-call cause depends on the originating privilege mode (E1-T09):
                // U→8, S→9, M→11. tval is 0.
                let cause = match self.csr.mode {
                    crate::csr::Priv::U => Exception::EcallFromU,
                    crate::csr::Priv::S => Exception::EcallFromS,
                    crate::csr::Priv::M => Exception::EcallFromM,
                };
                return Err(Trap { cause, tval: 0 });
            }
            Ebreak => {
                return Err(Trap {
                    cause: Exception::Breakpoint,
                    tval: pc,
                });
            }

            // ── Zicsr / Zifencei / xRET (E1-T02) ────────────────────────────
            // FENCE.I is a no-op for an in-order interpreter (no store buffer / i-cache).
            FenceI => (0, 0, pc_next),
            // Wait-for-interrupt retires as a no-op (no interrupts at this level). Per our
            // conservative A-extension policy it drops any LR/SC reservation (E1-T04).
            Wfi => {
                // TW=1 makes WFI in a mode below M illegal (E1-T09; a bounded timeout is a
                // no-op for us since there are no wakeups yet — T11).
                if self.csr.tw() && self.csr.mode < crate::csr::Priv::M {
                    return Err(Trap {
                        cause: Exception::IllegalInstruction,
                        tval: raw_insn,
                    });
                }
                self.resv = None;
                self.last_was_wfi = true; // E2-T20: WFI-deadlock watchdog signal
                (0, 0, pc_next)
            }
            // Supervisor fence (E1-T17, Priv §4.2.1): invalidate the software TLB per the four
            // rs1/rs2 operand forms. Illegal in U-mode; illegal in S-mode when mstatus.TVM=1
            // (a hypervisor trap so a guest OS's SFENCE.VMA is intercepted). Checked before any
            // effect, so a trap leaves the TLB untouched. satp itself does NOT flush — only this.
            SfenceVma { rs1, rs2 } => {
                let m = self.csr.mode;
                if m < crate::csr::Priv::S || (matches!(m, crate::csr::Priv::S) && self.csr.tvm()) {
                    return Err(Trap {
                        cause: Exception::IllegalInstruction,
                        tval: raw_insn,
                    });
                }
                // rs1 = x0 → all VAs; rs2 = x0 → all ASIDs (the ASID is the low 16 bits of rs2).
                let va = (rs1 != 0).then(|| r.read(rs1));
                let asid = (rs2 != 0).then(|| r.read(rs2) & 0xFFFF);
                self.tlb.sfence(va, asid);
                (0, 0, pc_next)
            }
            // Return from M-mode trap (E1-T09): illegal below M; restores the mstatus stack
            // (MIE←MPIE, MPIE←1, mode←MPP, MPP←U, MPRV cleared if returning below M) and
            // transfers to mepc.
            Mret => {
                if self.csr.mode < crate::csr::Priv::M {
                    return Err(Trap {
                        cause: Exception::IllegalInstruction,
                        tval: raw_insn,
                    });
                }
                let target = self.csr.read(crate::csr::MEPC);
                self.csr.mret();
                self.resv = None; // xRET drops any LR/SC reservation (E1-T04)
                (0, 0, target)
            }
            // Return from S-mode trap (E1-T09): illegal below S, and illegal in S when
            // mstatus.TSR=1. Restores the S stack and transfers to sepc.
            Sret => {
                let m = self.csr.mode;
                if m < crate::csr::Priv::S || (matches!(m, crate::csr::Priv::S) && self.csr.tsr()) {
                    return Err(Trap {
                        cause: Exception::IllegalInstruction,
                        tval: raw_insn,
                    });
                }
                let target = self.csr.read(crate::csr::SEPC);
                self.csr.sret();
                self.resv = None;
                (0, 0, target)
            }
            // CSR read/modify/write with spec side-effect suppression, delegated to the
            // one CSR authority. `value` (the old CSR value) retires into rd; the CSR side
            // effect happened inside access().
            Csrrw { rd, rs1, csr } => {
                let src = r.read(rs1);
                let old = self.csr.access(
                    csr,
                    crate::csr::CsrOp::Write,
                    src,
                    false,
                    rd == 0,
                    raw_insn,
                )?;
                note_csr_access(&mut self.tlb, csr);
                (rd, old, pc_next)
            }
            Csrrs { rd, rs1, csr } => {
                let src = r.read(rs1);
                let old = self.csr.access(
                    csr,
                    crate::csr::CsrOp::Set,
                    src,
                    rs1 == 0,
                    rd == 0,
                    raw_insn,
                )?;
                note_csr_access(&mut self.tlb, csr);
                (rd, old, pc_next)
            }
            Csrrc { rd, rs1, csr } => {
                let src = r.read(rs1);
                let old = self.csr.access(
                    csr,
                    crate::csr::CsrOp::Clear,
                    src,
                    rs1 == 0,
                    rd == 0,
                    raw_insn,
                )?;
                note_csr_access(&mut self.tlb, csr);
                (rd, old, pc_next)
            }
            Csrrwi { rd, uimm, csr } => {
                let old = self.csr.access(
                    csr,
                    crate::csr::CsrOp::Write,
                    uimm as u64,
                    false,
                    rd == 0,
                    raw_insn,
                )?;
                note_csr_access(&mut self.tlb, csr);
                (rd, old, pc_next)
            }
            Csrrsi { rd, uimm, csr } => {
                let old = self.csr.access(
                    csr,
                    crate::csr::CsrOp::Set,
                    uimm as u64,
                    uimm == 0,
                    rd == 0,
                    raw_insn,
                )?;
                note_csr_access(&mut self.tlb, csr);
                (rd, old, pc_next)
            }
            Csrrci { rd, uimm, csr } => {
                let old = self.csr.access(
                    csr,
                    crate::csr::CsrOp::Clear,
                    uimm as u64,
                    uimm == 0,
                    rd == 0,
                    raw_insn,
                )?;
                note_csr_access(&mut self.tlb, csr);
                (rd, old, pc_next)
            }

            // ── F extension (E1-T06) ────────────────────────────────────────
            // FS!=Off already checked at the top. Ops that write FP state (an f-register or
            // fflags) mark FS Dirty; FSW/FMV.X.W/FCLASS.S do not (they write memory/x-regs
            // only). rm-carrying ops resolve the rounding mode and trap on a reserved value.
            Flw { rd, rs1, imm } => {
                let a = ea(r.read(rs1), imm);
                let v = cload32(&self.csr, &mut self.tlb, bus, a)?;
                capture.load(a, 4);
                self.fregs.write_f32(rd, v);
                self.csr.mark_fp_dirty();
                (0, 0, pc_next)
            }
            Fsw { rs1, rs2, imm } => {
                let a = ea(r.read(rs1), imm);
                let v = self.fregs.read_raw(rs2) as u32; // raw low 32 bits
                cstore32(&self.csr, &mut self.tlb, bus, a, v)?;
                successful_store = Some((a, 4));
                capture.store(a, 4, u64::from(v));
                (0, 0, pc_next)
            }
            FpArithS {
                op,
                rd,
                rs1,
                rs2,
                rm,
            } => {
                let round = match self.csr.resolve_rm(rm) {
                    Some(x) => x,
                    None => {
                        return Err(Trap {
                            cause: Exception::IllegalInstruction,
                            tval: raw_insn,
                        });
                    }
                };
                let (a, b) = (self.fregs.read_f32(rs1), self.fregs.read_f32(rs2));
                use crate::decode::FpArithOp::*;
                let (res, flags) = match op {
                    Add => F32::add(a, b, round),
                    Sub => F32::sub(a, b, round),
                    Mul => F32::mul(a, b, round),
                    Div => F32::div(a, b, round),
                };
                self.fregs.write_f32(rd, res);
                self.csr.accrue_fflags(flags.0);
                self.csr.mark_fp_dirty();
                (0, 0, pc_next)
            }
            FsqrtS { rd, rs1, rm } => {
                let round = match self.csr.resolve_rm(rm) {
                    Some(x) => x,
                    None => {
                        return Err(Trap {
                            cause: Exception::IllegalInstruction,
                            tval: raw_insn,
                        });
                    }
                };
                let (res, flags) = F32::sqrt(self.fregs.read_f32(rs1), round);
                self.fregs.write_f32(rd, res);
                self.csr.accrue_fflags(flags.0);
                self.csr.mark_fp_dirty();
                (0, 0, pc_next)
            }
            FpFusedS {
                op,
                rd,
                rs1,
                rs2,
                rs3,
                rm,
            } => {
                let round = match self.csr.resolve_rm(rm) {
                    Some(x) => x,
                    None => {
                        return Err(Trap {
                            cause: Exception::IllegalInstruction,
                            tval: raw_insn,
                        });
                    }
                };
                let a = self.fregs.read_f32(rs1);
                let b = self.fregs.read_f32(rs2);
                let c = self.fregs.read_f32(rs3);
                use crate::decode::FpFusedOp::*;
                // Negate a operand by flipping its sign bit; the fused product/sum sign
                // follows. (a*b)±c with the four sign patterns.
                let neg = 0x8000_0000u32;
                let (aa, cc) = match op {
                    Madd => (a, c),
                    Msub => (a, c ^ neg),
                    Nmsub => (a ^ neg, c),
                    Nmadd => (a ^ neg, c ^ neg),
                };
                let (res, flags) = F32::fma(aa, b, cc, round);
                self.fregs.write_f32(rd, res);
                self.csr.accrue_fflags(flags.0);
                self.csr.mark_fp_dirty();
                (0, 0, pc_next)
            }
            FsgnjS { op, rd, rs1, rs2 } => {
                let a = self.fregs.read_f32(rs1);
                let b = self.fregs.read_f32(rs2);
                use crate::decode::FpSgnjOp::*;
                let sign = match op {
                    J => b & 0x8000_0000,
                    Jn => !b & 0x8000_0000,
                    Jx => (a ^ b) & 0x8000_0000,
                };
                self.fregs.write_f32(rd, (a & 0x7FFF_FFFF) | sign);
                self.csr.mark_fp_dirty();
                (0, 0, pc_next)
            }
            FminmaxS {
                is_max,
                rd,
                rs1,
                rs2,
            } => {
                let (res, flags) = crate::softfloat::f32_minmax(
                    self.fregs.read_f32(rs1),
                    self.fregs.read_f32(rs2),
                    is_max,
                );
                self.fregs.write_f32(rd, res);
                self.csr.accrue_fflags(flags.0);
                self.csr.mark_fp_dirty();
                (0, 0, pc_next)
            }
            FpCmpS { op, rd, rs1, rs2 } => {
                let a = self.fregs.read_f32(rs1);
                let b = self.fregs.read_f32(rs2);
                use crate::decode::FpCmpOp::*;
                let (res, flags) = match op {
                    Eq => F32::eq(a, b),
                    Lt => F32::lt(a, b),
                    Le => F32::le(a, b),
                };
                self.csr.accrue_fflags(flags.0);
                self.csr.mark_fp_dirty();
                (rd, res as u64, pc_next)
            }
            FclassS { rd, rs1 } => {
                let mask = crate::softfloat::fclass_f32(self.fregs.read_f32(rs1));
                (rd, mask, pc_next)
            }
            FmvXW { rd, rs1 } => {
                // Raw low-32-bit move, sign-extended (no NaN-box canonicalization).
                (rd, sext32(self.fregs.read_raw(rs1) as u32), pc_next)
            }
            FmvWX { rd, rs1 } => {
                self.fregs.write_f32(rd, r.read(rs1) as u32);
                self.csr.mark_fp_dirty();
                (0, 0, pc_next)
            }
            FcvtToIntS { width, rd, rs1, rm } => {
                let round = match self.csr.resolve_rm(rm) {
                    Some(x) => x,
                    None => {
                        return Err(Trap {
                            cause: Exception::IllegalInstruction,
                            tval: raw_insn,
                        });
                    }
                };
                let (res, flags) =
                    crate::softfloat::f32_to_int(self.fregs.read_f32(rs1), width, round);
                self.csr.accrue_fflags(flags.0);
                self.csr.mark_fp_dirty();
                (rd, res, pc_next)
            }
            FcvtFromIntS { width, rd, rs1, rm } => {
                let round = match self.csr.resolve_rm(rm) {
                    Some(x) => x,
                    None => {
                        return Err(Trap {
                            cause: Exception::IllegalInstruction,
                            tval: raw_insn,
                        });
                    }
                };
                let (res, flags) = crate::softfloat::f32_from_int(r.read(rs1), width, round);
                self.fregs.write_f32(rd, res);
                self.csr.accrue_fflags(flags.0);
                self.csr.mark_fp_dirty();
                (0, 0, pc_next)
            }

            // ── D extension (E1-T07) ────────────────────────────────────────
            // f64 fills the register (NO NaN-boxing); operands/results use read_raw/write_raw.
            Fld { rd, rs1, imm } => {
                let a = ea(r.read(rs1), imm);
                let v = cload64(&self.csr, &mut self.tlb, bus, a)?;
                capture.load(a, 8);
                self.fregs.write_raw(rd, v);
                self.csr.mark_fp_dirty();
                (0, 0, pc_next)
            }
            Fsd { rs1, rs2, imm } => {
                let a = ea(r.read(rs1), imm);
                let v = self.fregs.read_raw(rs2);
                cstore64(&self.csr, &mut self.tlb, bus, a, v)?;
                successful_store = Some((a, 8));
                capture.store(a, 8, v);
                (0, 0, pc_next)
            }
            FpArithD {
                op,
                rd,
                rs1,
                rs2,
                rm,
            } => {
                let round = match self.csr.resolve_rm(rm) {
                    Some(x) => x,
                    None => {
                        return Err(Trap {
                            cause: Exception::IllegalInstruction,
                            tval: raw_insn,
                        });
                    }
                };
                let (a, b) = (self.fregs.read_raw(rs1), self.fregs.read_raw(rs2));
                use crate::decode::FpArithOp::*;
                let (res, flags) = match op {
                    Add => F64::add(a, b, round),
                    Sub => F64::sub(a, b, round),
                    Mul => F64::mul(a, b, round),
                    Div => F64::div(a, b, round),
                };
                self.fregs.write_raw(rd, res);
                self.csr.accrue_fflags(flags.0);
                self.csr.mark_fp_dirty();
                (0, 0, pc_next)
            }
            FsqrtD { rd, rs1, rm } => {
                let round = match self.csr.resolve_rm(rm) {
                    Some(x) => x,
                    None => {
                        return Err(Trap {
                            cause: Exception::IllegalInstruction,
                            tval: raw_insn,
                        });
                    }
                };
                let (res, flags) = F64::sqrt(self.fregs.read_raw(rs1), round);
                self.fregs.write_raw(rd, res);
                self.csr.accrue_fflags(flags.0);
                self.csr.mark_fp_dirty();
                (0, 0, pc_next)
            }
            FpFusedD {
                op,
                rd,
                rs1,
                rs2,
                rs3,
                rm,
            } => {
                let round = match self.csr.resolve_rm(rm) {
                    Some(x) => x,
                    None => {
                        return Err(Trap {
                            cause: Exception::IllegalInstruction,
                            tval: raw_insn,
                        });
                    }
                };
                let a = self.fregs.read_raw(rs1);
                let b = self.fregs.read_raw(rs2);
                let c = self.fregs.read_raw(rs3);
                use crate::decode::FpFusedOp::*;
                let neg = 0x8000_0000_0000_0000u64;
                let (aa, cc) = match op {
                    Madd => (a, c),
                    Msub => (a, c ^ neg),
                    Nmsub => (a ^ neg, c),
                    Nmadd => (a ^ neg, c ^ neg),
                };
                let (res, flags) = F64::fma(aa, b, cc, round);
                self.fregs.write_raw(rd, res);
                self.csr.accrue_fflags(flags.0);
                self.csr.mark_fp_dirty();
                (0, 0, pc_next)
            }
            FsgnjD { op, rd, rs1, rs2 } => {
                let a = self.fregs.read_raw(rs1);
                let b = self.fregs.read_raw(rs2);
                use crate::decode::FpSgnjOp::*;
                let sign = match op {
                    J => b & 0x8000_0000_0000_0000,
                    Jn => !b & 0x8000_0000_0000_0000,
                    Jx => (a ^ b) & 0x8000_0000_0000_0000,
                };
                self.fregs.write_raw(rd, (a & 0x7FFF_FFFF_FFFF_FFFF) | sign);
                self.csr.mark_fp_dirty();
                (0, 0, pc_next)
            }
            FminmaxD {
                is_max,
                rd,
                rs1,
                rs2,
            } => {
                let (res, flags) = crate::softfloat::f64_minmax(
                    self.fregs.read_raw(rs1),
                    self.fregs.read_raw(rs2),
                    is_max,
                );
                self.fregs.write_raw(rd, res);
                self.csr.accrue_fflags(flags.0);
                self.csr.mark_fp_dirty();
                (0, 0, pc_next)
            }
            FpCmpD { op, rd, rs1, rs2 } => {
                let a = self.fregs.read_raw(rs1);
                let b = self.fregs.read_raw(rs2);
                use crate::decode::FpCmpOp::*;
                let (res, flags) = match op {
                    Eq => F64::eq(a, b),
                    Lt => F64::lt(a, b),
                    Le => F64::le(a, b),
                };
                self.csr.accrue_fflags(flags.0);
                self.csr.mark_fp_dirty();
                (rd, res as u64, pc_next)
            }
            FclassD { rd, rs1 } => {
                let mask = crate::softfloat::fclass_f64(self.fregs.read_raw(rs1));
                (rd, mask, pc_next)
            }
            FmvXD { rd, rs1 } => {
                // Raw 64-bit move f→x (no canonicalization).
                (rd, self.fregs.read_raw(rs1), pc_next)
            }
            FmvDX { rd, rs1 } => {
                self.fregs.write_raw(rd, r.read(rs1));
                self.csr.mark_fp_dirty();
                (0, 0, pc_next)
            }
            FcvtToIntD { width, rd, rs1, rm } => {
                let round = match self.csr.resolve_rm(rm) {
                    Some(x) => x,
                    None => {
                        return Err(Trap {
                            cause: Exception::IllegalInstruction,
                            tval: raw_insn,
                        });
                    }
                };
                let (res, flags) =
                    crate::softfloat::f64_to_int(self.fregs.read_raw(rs1), width, round);
                self.csr.accrue_fflags(flags.0);
                self.csr.mark_fp_dirty();
                (rd, res, pc_next)
            }
            FcvtFromIntD { width, rd, rs1, rm } => {
                let round = match self.csr.resolve_rm(rm) {
                    Some(x) => x,
                    None => {
                        return Err(Trap {
                            cause: Exception::IllegalInstruction,
                            tval: raw_insn,
                        });
                    }
                };
                let (res, flags) = crate::softfloat::f64_from_int(r.read(rs1), width, round);
                self.fregs.write_raw(rd, res);
                self.csr.accrue_fflags(flags.0);
                self.csr.mark_fp_dirty();
                (0, 0, pc_next)
            }
            // FCVT.S.D — narrow f64 → f32, rounds, result NaN-boxed.
            FcvtSD { rd, rs1, rm } => {
                let round = match self.csr.resolve_rm(rm) {
                    Some(x) => x,
                    None => {
                        return Err(Trap {
                            cause: Exception::IllegalInstruction,
                            tval: raw_insn,
                        });
                    }
                };
                let (res, flags) = crate::softfloat::f64_to_f32(self.fregs.read_raw(rs1), round);
                self.fregs.write_f32(rd, res);
                self.csr.accrue_fflags(flags.0);
                self.csr.mark_fp_dirty();
                (0, 0, pc_next)
            }
            // FCVT.D.S — widen f32 → f64, exact; the f32 input is NaN-box checked.
            FcvtDS { rd, rs1, rm: _ } => {
                let (res, flags) = crate::softfloat::f32_to_f64(self.fregs.read_f32(rs1));
                self.fregs.write_raw(rd, res);
                self.csr.accrue_fflags(flags.0);
                self.csr.mark_fp_dirty();
                (0, 0, pc_next)
            }
        };
        // A-extension reservation invalidation (E1-T04): a *successful* store that overlaps
        // the reservation granule clears it. This explicit effect remains independent of
        // optional trace metadata, and runs only after the instruction match returned Ok.
        if let (Some((addr, len)), Some((ra, rw))) = (successful_store, self.resv)
            && overlaps(addr, u64::from(len), ra, u64::from(rw))
        {
            self.resv = None;
        }
        // Single retirement point: x0-discard is enforced by XRegs::write.
        r.write(rd, value);
        r.pc = next_pc;
        Ok(capture.finish(rd, value))
    }

    /// E4-T09 JIT differential oracle. Executes ONE decoded instruction and applies its
    /// full architectural retirement (register writeback, `pc` update, memory side effects
    /// through `bus`), exposing the crate-internal [`Self::execute`] as the reference the
    /// `jit-translate` cross-engine equivalence harness compares generated WASM against.
    /// This is the single semantics source of truth; the JIT must be byte-identical to it.
    pub fn exec_oracle(
        &mut self,
        bus: &mut impl Bus,
        instr: Instr,
        insn_len: u64,
        raw_insn: u64,
    ) -> Result<(), Trap> {
        let mut sink = crate::trace::NullSink;
        let mut capture = RecordingCapture::new(&mut sink);
        self.execute(bus, instr, insn_len, raw_insn, &mut capture)
            .map(|_| ())
    }
}
