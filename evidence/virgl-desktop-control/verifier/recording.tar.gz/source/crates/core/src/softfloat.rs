//! IEEE-754 arithmetic backend (E1-T05).
//!
//! # Why not host `f32`/`f64`
//! RISC-V mandates a canonical NaN payload (`0x7fc0_0000` / `0x7ff8_0000_0000_0000`),
//! five sticky exception flags, and five rounding modes — none of which host float ops
//! expose portably, and whose NaN bit patterns diverge between native and wasm32, breaking
//! the determinism guarantee (E0-T22). So the guest FP datapath uses NO host float
//! arithmetic — this module is `#![deny(clippy::float_arithmetic)]`, a compile-time proof.
//!
//! # Backend decision (see `docs/design/softfloat.md`)
//! Berkeley SoftFloat (C) is reference-quality but cannot compile to
//! `wasm32-unknown-unknown` with the available toolchain; `simple-soft-float` no longer
//! builds on current Rust. `rustc_apfloat` (the LLVM APFloat port) is pure-Rust, `no_std`,
//! builds on both targets, and produces the RISC-V-canonical NaN with correct rounding and
//! flags — but has **no `sqrt`**. So: add/sub/mul/div/fma/compare/convert delegate to
//! `rustc_apfloat`; `sqrt` is a hand-rolled *correctly-rounded* integer-only implementation
//! ([`ieee_sqrt`]) built on [`u128::isqrt`] — exact, deterministic, no host float.
#![deny(clippy::float_arithmetic)]

use rustc_apfloat::ieee::{Double, Single};
use rustc_apfloat::{Float, FloatConvert, Round, Status};

/// RISC-V accrued exception flags (`fflags`), bit-positioned exactly as the CSR:
/// NX=0, UF=1, OF=2, DZ=3, NV=4.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct Flags(pub u8);

impl Flags {
    pub const NX: u8 = 0x01; // inexact
    pub const UF: u8 = 0x02; // underflow
    pub const OF: u8 = 0x04; // overflow
    pub const DZ: u8 = 0x08; // divide by zero
    pub const NV: u8 = 0x10; // invalid operation

    pub const NONE: Flags = Flags(0);

    /// Map an apfloat operation status to RISC-V `fflags` bits.
    fn from_status(s: Status) -> Flags {
        let mut f = 0u8;
        if s.contains(Status::INVALID_OP) {
            f |= Self::NV;
        }
        if s.contains(Status::DIV_BY_ZERO) {
            f |= Self::DZ;
        }
        if s.contains(Status::OVERFLOW) {
            f |= Self::OF;
        }
        if s.contains(Status::UNDERFLOW) {
            f |= Self::UF;
        }
        if s.contains(Status::INEXACT) {
            f |= Self::NX;
        }
        Flags(f)
    }
}

/// The five RISC-V rounding modes (`frm` field values 0..=4).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RoundMode {
    /// 000 — round to nearest, ties to even.
    Rne,
    /// 001 — round toward zero.
    Rtz,
    /// 010 — round down (toward −∞).
    Rdn,
    /// 011 — round up (toward +∞).
    Rup,
    /// 100 — round to nearest, ties to max magnitude (away from zero).
    Rmm,
}

impl RoundMode {
    /// Decode a 3-bit `frm`/instruction `rm` field; `None` for the reserved values
    /// (101, 110 reserved; 111 = "dynamic", resolved against `frm` by the caller).
    pub const fn from_bits(rm: u8) -> Option<RoundMode> {
        match rm {
            0b000 => Some(RoundMode::Rne),
            0b001 => Some(RoundMode::Rtz),
            0b010 => Some(RoundMode::Rdn),
            0b011 => Some(RoundMode::Rup),
            0b100 => Some(RoundMode::Rmm),
            _ => None,
        }
    }

    const fn to_apfloat(self) -> Round {
        match self {
            RoundMode::Rne => Round::NearestTiesToEven,
            RoundMode::Rtz => Round::TowardZero,
            RoundMode::Rdn => Round::TowardNegative,
            RoundMode::Rup => Round::TowardPositive,
            RoundMode::Rmm => Round::NearestTiesToAway,
        }
    }
}

/// One IEEE format's operations. Bits are the raw storage integer (`u32`/`u64`); every op
/// returns the result bits paired with the accrued [`Flags`]. No host float arithmetic is
/// used on any path — the guest FP datapath (E1-T06/T07) is built entirely on this trait.
pub trait SoftFloat {
    /// The raw bit storage type (`u32` for f32, `u64` for f64).
    type Bits: Copy + PartialEq;

    fn add(a: Self::Bits, b: Self::Bits, rm: RoundMode) -> (Self::Bits, Flags);
    fn sub(a: Self::Bits, b: Self::Bits, rm: RoundMode) -> (Self::Bits, Flags);
    fn mul(a: Self::Bits, b: Self::Bits, rm: RoundMode) -> (Self::Bits, Flags);
    fn div(a: Self::Bits, b: Self::Bits, rm: RoundMode) -> (Self::Bits, Flags);
    /// Fused multiply-add: `a * b + c` with a single rounding (no intermediate rounding).
    fn fma(a: Self::Bits, b: Self::Bits, c: Self::Bits, rm: RoundMode) -> (Self::Bits, Flags);
    /// Correctly-rounded square root.
    fn sqrt(a: Self::Bits, rm: RoundMode) -> (Self::Bits, Flags);

    /// FEQ: quiet ordered-equality. Only a signaling NaN input raises NV; qNaN → false.
    fn eq(a: Self::Bits, b: Self::Bits) -> (bool, Flags);
    /// FLT: signaling less-than. Any NaN raises NV and yields false.
    fn lt(a: Self::Bits, b: Self::Bits) -> (bool, Flags);
    /// FLE: signaling less-than-or-equal. Any NaN raises NV and yields false.
    fn le(a: Self::Bits, b: Self::Bits) -> (bool, Flags);

    /// The RISC-V canonical quiet NaN for this format.
    fn canonical_nan() -> Self::Bits;
}

/// The pinned APFloat backend omits OF when overflow saturates to a finite
/// value. For F32 add/mul, an inexact largest result needs OF iff the exact
/// magnitude reaches 2^128. Recompute only this rare flag check with the same
/// software backend widened to binary64; never replace the rounded F32 result.
/// Products need at most 48 significant bits. A sum near 2^128 differs from
/// that boundary by at least 2^80, well above binary64's 2^75 spacing below it.
fn f32_saturating_overflow(a: u32, b: u32, multiply: bool) -> bool {
    let mut loses = false;
    let x: Double = Single::from_bits(u128::from(a)).convert(&mut loses).value;
    let y: Double = Single::from_bits(u128::from(b)).convert(&mut loses).value;
    let exact = if multiply {
        x.mul_r(y, Round::NearestTiesToEven).value
    } else {
        x.add_r(y, Round::NearestTiesToEven).value
    };
    exact.ilogb() >= 128
}

/// Correct two pinned APFloat division flag gaps without changing its result:
/// finite overflow saturation, and tiny values rounded to the smallest normal.
/// Both need only comparisons of normalized 24-bit integer significands.
fn f32_division_flags(a: u32, b: u32, rm: RoundMode, bits: u32, status: Status) -> Flags {
    let mut flags = Flags::from_status(status);
    let magnitude = bits & 0x7fff_ffff;
    if status != Status::INEXACT || !matches!(magnitude, 0x7f7f_ffff | 0x0080_0000) {
        return flags;
    }
    // An inexact nonzero finite result guarantees finite, nonzero operands.
    fn normalized(bits: u32) -> (u64, i32) {
        let exponent = ((bits >> 23) & 255) as i32;
        let significand = bits & 0x007f_ffff;
        if exponent == 0 {
            let shift = significand.leading_zeros() - 8;
            (u64::from(significand << shift), -126 - shift as i32)
        } else {
            (u64::from(significand | 0x0080_0000), exponent - 127)
        }
    }
    let (numerator, a_exp) = normalized(a);
    let (denominator, b_exp) = normalized(b);
    let difference = a_exp - b_exp;
    if magnitude == 0x7f7f_ffff {
        // |a/b| >= 2^128 iff the exponent difference exceeds 128,
        // or is exactly 128 and the significand ratio is at least one.
        if difference > 128 || (difference == 128 && numerator >= denominator) {
            flags.0 |= Flags::OF;
        }
    } else {
        // Tininess is decided after precision-24 rounding with an UNBOUNDED
        // exponent, independently of the final subnormal rounding. Just below
        // 2^-126, that precision has spacing 2^-150. Nearest modes reach the
        // normal boundary at 2^-126 - 2^-151; rounding away from zero reaches
        // it strictly above 2^-126 - 2^-150. Toward zero needs |a/b| >= 2^-126.
        // A result at the smallest normal bounds the shifts below to 0..=26.
        debug_assert!((-127..=-125).contains(&difference));
        let negative = (a ^ b) >> 31 != 0;
        let away =
            matches!(rm, RoundMode::Rdn) && negative || matches!(rm, RoundMode::Rup) && !negative;
        let tiny = if matches!(rm, RoundMode::Rne | RoundMode::Rmm) || away {
            let precision = if away { 24 } else { 25 };
            let left = numerator << (difference + 126 + precision);
            let right = denominator * ((1_u64 << precision) - 1);
            if away { left <= right } else { left < right }
        } else {
            numerator << (difference + 127) < denominator << 1
        };
        if tiny {
            flags.0 |= Flags::UF;
        }
    }
    flags
}

/// Restore the pinned backend's two F32 fused-result flag gaps. Result bits
/// already match single rounding; only inexact finite saturation and the
/// smallest normal need an independent boundary check.
fn f32_fma_flags(a: u32, b: u32, c: u32, rm: RoundMode, bits: u32, status: Status) -> Flags {
    let mut flags = Flags::from_status(status);
    let magnitude = bits & 0x7fff_ffff;
    if status != Status::INEXACT || !matches!(magnitude, 0x7f7f_ffff | 0x0080_0000) {
        return flags;
    }
    // All inputs here are finite. Negate both product and addend if needed,
    // so the exact widened fused result is positive. Conversion is exact and
    // binary64's exponent range contains every binary32 product and sum.
    let negative = bits >> 31 != 0;
    let flip = if negative { 0x8000_0000 } else { 0 };
    let mut loses = false;
    let x: Double = Single::from_bits(u128::from(a ^ flip))
        .convert(&mut loses)
        .value;
    let y: Double = Single::from_bits(u128::from(b)).convert(&mut loses).value;
    let z: Double = Single::from_bits(u128::from(c ^ flip))
        .convert(&mut loses)
        .value;
    let away =
        matches!(rm, RoundMode::Rdn) && negative || matches!(rm, RoundMode::Rup) && !negative;
    // Each comparison threshold is exactly representable in binary64. A
    // downward-rounded magnitude preserves >= and <; upward preserves <=.
    // Nearest rounding would lose a tiny addend in 2^128 +/- 2^-149.
    let wide = x
        .mul_add_r(
            y,
            z,
            if magnitude == 0x0080_0000 && away {
                Round::TowardPositive
            } else {
                Round::TowardZero
            },
        )
        .value;
    if magnitude == 0x7f7f_ffff {
        if wide >= Double::from_bits(0x47f0_0000_0000_0000) {
            // 2^128
            flags.0 |= Flags::OF;
        }
    } else {
        // Precision-24 rounding with an unbounded exponent: nearest reaches
        // normal at 2^-126 - 2^-151; away reaches it strictly above
        // 2^-126 - 2^-150. Below 2^-126, binary64 spacing is 2^-179.
        let normal = 0x3810_0000_0000_0000_u128;
        let tiny = if away {
            wide <= Double::from_bits(normal - (1 << 29))
        } else if matches!(rm, RoundMode::Rne | RoundMode::Rmm) {
            wide < Double::from_bits(normal - (1 << 28))
        } else {
            wide < Double::from_bits(normal)
        };
        if tiny {
            flags.0 |= Flags::UF;
        }
    }
    flags
}

/// Generate the [`SoftFloat`] impl for one format from its apfloat type + geometry.
macro_rules! impl_softfloat {
    ($marker:ident, $ap:ty, $bits:ty, $mant:expr, $exp:expr, $bias:expr) => {
        /// Zero-sized marker selecting this IEEE format.
        pub struct $marker;

        impl $marker {
            #[inline]
            fn of(b: $bits) -> $ap {
                <$ap>::from_bits(b as u128)
            }
            /// Extract result bits, **canonicalizing any NaN** to the RISC-V canonical qNaN.
            /// apfloat (like LLVM) propagates NaN payloads; RISC-V mandates that every
            /// NaN-producing FP op return the single canonical NaN, so we override here.
            #[inline]
            fn bits(f: $ap) -> $bits {
                if f.is_nan() {
                    <$ap>::NAN.to_bits() as $bits
                } else {
                    f.to_bits() as $bits
                }
            }

            fn arithmetic_flags(
                a: $bits,
                b: $bits,
                value: $ap,
                status: Status,
                multiply: bool,
            ) -> Flags {
                let mut flags = Flags::from_status(status);
                // Keep the correction scoped to the selected single-precision
                // operations. Other formats and arithmetic families are unchanged.
                if $mant == 23
                    && status == Status::INEXACT
                    && value.is_largest()
                    && f32_saturating_overflow(a as u32, b as u32, multiply)
                {
                    flags.0 |= Flags::OF;
                }
                flags
            }
        }

        impl SoftFloat for $marker {
            type Bits = $bits;

            fn add(a: $bits, b: $bits, rm: RoundMode) -> ($bits, Flags) {
                let r = Float::add_r(Self::of(a), Self::of(b), rm.to_apfloat());
                (
                    Self::bits(r.value),
                    Self::arithmetic_flags(a, b, r.value, r.status, false),
                )
            }
            fn sub(a: $bits, b: $bits, rm: RoundMode) -> ($bits, Flags) {
                let r = Float::sub_r(Self::of(a), Self::of(b), rm.to_apfloat());
                (Self::bits(r.value), Flags::from_status(r.status))
            }
            fn mul(a: $bits, b: $bits, rm: RoundMode) -> ($bits, Flags) {
                let r = Float::mul_r(Self::of(a), Self::of(b), rm.to_apfloat());
                (
                    Self::bits(r.value),
                    Self::arithmetic_flags(a, b, r.value, r.status, true),
                )
            }
            fn div(a: $bits, b: $bits, rm: RoundMode) -> ($bits, Flags) {
                let r = Float::div_r(Self::of(a), Self::of(b), rm.to_apfloat());
                let bits = Self::bits(r.value);
                let flags = if $mant == 23 {
                    f32_division_flags(a as u32, b as u32, rm, bits as u32, r.status)
                } else {
                    Flags::from_status(r.status)
                };
                (bits, flags)
            }
            fn fma(a: $bits, b: $bits, c: $bits, rm: RoundMode) -> ($bits, Flags) {
                let r = Float::mul_add_r(Self::of(a), Self::of(b), Self::of(c), rm.to_apfloat());
                let bits = Self::bits(r.value);
                let flags = if $mant == 23 {
                    f32_fma_flags(a as u32, b as u32, c as u32, rm, bits as u32, r.status)
                } else {
                    Flags::from_status(r.status)
                };
                (bits, flags)
            }
            fn sqrt(a: $bits, rm: RoundMode) -> ($bits, Flags) {
                let (bits, f) = ieee_sqrt(a as u128, $mant, $exp, $bias, rm);
                (bits as $bits, f)
            }

            fn eq(a: $bits, b: $bits) -> (bool, Flags) {
                let (x, y) = (Self::of(a), Self::of(b));
                // FEQ is quiet: only a signaling NaN raises NV.
                let nv = x.is_signaling() || y.is_signaling();
                let eq = matches!(x.partial_cmp(&y), Some(core::cmp::Ordering::Equal));
                (eq, if nv { Flags(Flags::NV) } else { Flags::NONE })
            }
            fn lt(a: $bits, b: $bits) -> (bool, Flags) {
                let (x, y) = (Self::of(a), Self::of(b));
                match x.partial_cmp(&y) {
                    Some(core::cmp::Ordering::Less) => (true, Flags::NONE),
                    Some(_) => (false, Flags::NONE),
                    None => (false, Flags(Flags::NV)), // any NaN → NV, false
                }
            }
            fn le(a: $bits, b: $bits) -> (bool, Flags) {
                let (x, y) = (Self::of(a), Self::of(b));
                match x.partial_cmp(&y) {
                    Some(core::cmp::Ordering::Less | core::cmp::Ordering::Equal) => {
                        (true, Flags::NONE)
                    }
                    Some(_) => (false, Flags::NONE),
                    None => (false, Flags(Flags::NV)),
                }
            }

            fn canonical_nan() -> $bits {
                <$ap>::NAN.to_bits() as $bits
            }
        }
    };
}

impl_softfloat!(F32, Single, u32, 23, 8, 127);
impl_softfloat!(F64, Double, u64, 52, 11, 1023);

/// Widen f32 → f64 (exact; never loses info). A NaN result is canonicalized; a signaling
/// NaN input additionally raises NV (RISC-V FCVT.D.S).
pub fn f32_to_f64(bits: u32) -> (u64, Flags) {
    let mut lost = false;
    let src = Single::from_bits(bits as u128);
    let nv = src.is_signaling();
    let r: rustc_apfloat::StatusAnd<Double> = src.convert(&mut lost);
    let mut f = Flags::from_status(r.status);
    if nv {
        f.0 |= Flags::NV;
    }
    let out = if r.value.is_nan() {
        F64::canonical_nan()
    } else {
        r.value.to_bits() as u64
    };
    (out, f)
}

/// Narrow f64 → f32 with rounding and flags; NaN result canonicalized, sNaN raises NV.
pub fn f64_to_f32(bits: u64, rm: RoundMode) -> (u32, Flags) {
    let mut lost = false;
    let src = Double::from_bits(bits as u128);
    let nv = src.is_signaling();
    let r: rustc_apfloat::StatusAnd<Single> = src.convert_r(rm.to_apfloat(), &mut lost);
    let mut f = Flags::from_status(r.status);
    if nv {
        f.0 |= Flags::NV;
    }
    let out = if r.value.is_nan() {
        F32::canonical_nan()
    } else {
        r.value.to_bits() as u32
    };
    (out, f)
}

// ── F-extension helpers: classify, min/max, float↔int (E1-T06) ──────────────────

#[inline]
const fn f32_is_nan(b: u32) -> bool {
    (b >> 23) & 0xFF == 0xFF && (b & 0x7F_FFFF) != 0
}
#[inline]
const fn f32_is_snan(b: u32) -> bool {
    f32_is_nan(b) && (b >> 22) & 1 == 0
}

/// FCLASS.S: the 10-bit class mask (bit 0 = −∞, 1 = −normal, 2 = −subnormal, 3 = −0,
/// 4 = +0, 5 = +subnormal, 6 = +normal, 7 = +∞, 8 = sNaN, 9 = qNaN). Pure integer.
pub const fn fclass_f32(b: u32) -> u64 {
    let sign = b >> 31;
    let exp = (b >> 23) & 0xFF;
    let frac = b & 0x7F_FFFF;
    let bit = if exp == 0xFF {
        if frac == 0 {
            if sign == 1 { 0 } else { 7 }
        } else if (frac >> 22) & 1 == 0 {
            8
        } else {
            9
        }
    } else if exp == 0 {
        if frac == 0 {
            if sign == 1 { 3 } else { 4 }
        } else if sign == 1 {
            2
        } else {
            5
        }
    } else if sign == 1 {
        1
    } else {
        6
    };
    1u64 << bit
}

/// FMIN.S / FMAX.S. sNaN input raises NV; a NaN operand is dropped in favor of the other;
/// two NaNs yield the canonical qNaN; −0.0 is treated as less than +0.0.
pub fn f32_minmax(a: u32, b: u32, is_max: bool) -> (u32, Flags) {
    let flags = if f32_is_snan(a) || f32_is_snan(b) {
        Flags(Flags::NV)
    } else {
        Flags::NONE
    };
    let (an, bn) = (f32_is_nan(a), f32_is_nan(b));
    let res = if an && bn {
        F32::canonical_nan()
    } else if an {
        b
    } else if bn {
        a
    } else {
        let x = Single::from_bits(a as u128);
        let y = Single::from_bits(b as u128);
        match x.partial_cmp(&y) {
            Some(core::cmp::Ordering::Less) => {
                if is_max {
                    b
                } else {
                    a
                }
            }
            Some(core::cmp::Ordering::Greater) => {
                if is_max {
                    a
                } else {
                    b
                }
            }
            // Equal ⇒ ±0: min picks −0, max picks +0 (choose by sign bit).
            _ => {
                let a_neg = a >> 31 == 1;
                if is_max == a_neg { b } else { a }
            }
        }
    };
    (res, flags)
}

/// FCVT.{W,WU,L,LU}.S — convert f32 to an integer, RISC-V saturating semantics: NaN → the
/// maximum value (not min); out-of-range saturates to the nearest bound; both set NV. The
/// signed/32-bit results are sign-extended into the returned u64.
pub fn f32_to_int(bits: u32, width: crate::decode::FpIntWidth, rm: RoundMode) -> (u64, Flags) {
    use crate::decode::FpIntWidth::*;
    let x = Single::from_bits(bits as u128);
    let round = rm.to_apfloat();
    let mut exact = true;
    let (raw, status) = match width {
        W => {
            let r = x.to_i128_r(32, round, &mut exact);
            (r.value as i32 as i64 as u64, r.status)
        }
        L => {
            let r = x.to_i128_r(64, round, &mut exact);
            (r.value as i64 as u64, r.status)
        }
        Wu => {
            let r = x.to_u128_r(32, round, &mut exact);
            (r.value as u32 as i32 as i64 as u64, r.status) // sign-extend 32→64
        }
        Lu => {
            let r = x.to_u128_r(64, round, &mut exact);
            (r.value as u64, r.status)
        }
    };
    let is_nan = f32_is_nan(bits);
    let result = if is_nan {
        match width {
            W => 0x0000_0000_7FFF_FFFF,
            Wu => 0xFFFF_FFFF_FFFF_FFFF, // sign-extended 0xFFFFFFFF
            L => 0x7FFF_FFFF_FFFF_FFFF,
            Lu => 0xFFFF_FFFF_FFFF_FFFF,
        }
    } else {
        raw
    };
    let mut f = 0u8;
    if is_nan || status.contains(Status::INVALID_OP) {
        f |= Flags::NV; // NaN/overflow — RISC-V does not additionally set NX
    } else if status.contains(Status::INEXACT) {
        f |= Flags::NX;
    }
    (result, Flags(f))
}

/// FCVT.S.{W,WU,L,LU} — convert an integer (from an x-register) to f32, rounding per `rm`.
pub fn f32_from_int(val: u64, width: crate::decode::FpIntWidth, rm: RoundMode) -> (u32, Flags) {
    use crate::decode::FpIntWidth::*;
    let round = rm.to_apfloat();
    let r = match width {
        W => Single::from_i128_r(val as i32 as i128, round),
        Wu => Single::from_u128_r(u128::from(val as u32), round),
        L => Single::from_i128_r(i128::from(val as i64), round),
        Lu => Single::from_u128_r(u128::from(val), round),
    };
    (r.value.to_bits() as u32, Flags::from_status(r.status))
}

// ── D-extension helpers (E1-T07): the f64 mirror of the f32 helpers above ────────

#[inline]
const fn f64_is_nan(b: u64) -> bool {
    (b >> 52) & 0x7FF == 0x7FF && (b & 0xF_FFFF_FFFF_FFFF) != 0
}
#[inline]
const fn f64_is_snan(b: u64) -> bool {
    f64_is_nan(b) && (b >> 51) & 1 == 0
}

/// FCLASS.D: the 10-bit class mask (same bit meanings as [`fclass_f32`]). Pure integer.
pub const fn fclass_f64(b: u64) -> u64 {
    let sign = b >> 63;
    let exp = (b >> 52) & 0x7FF;
    let frac = b & 0xF_FFFF_FFFF_FFFF;
    let bit = if exp == 0x7FF {
        if frac == 0 {
            if sign == 1 { 0 } else { 7 }
        } else if (frac >> 51) & 1 == 0 {
            8
        } else {
            9
        }
    } else if exp == 0 {
        if frac == 0 {
            if sign == 1 { 3 } else { 4 }
        } else if sign == 1 {
            2
        } else {
            5
        }
    } else if sign == 1 {
        1
    } else {
        6
    };
    1u64 << bit
}

/// FMIN.D / FMAX.D — same rules as the f32 variant.
pub fn f64_minmax(a: u64, b: u64, is_max: bool) -> (u64, Flags) {
    let flags = if f64_is_snan(a) || f64_is_snan(b) {
        Flags(Flags::NV)
    } else {
        Flags::NONE
    };
    let (an, bn) = (f64_is_nan(a), f64_is_nan(b));
    let res = if an && bn {
        F64::canonical_nan()
    } else if an {
        b
    } else if bn {
        a
    } else {
        let x = Double::from_bits(a as u128);
        let y = Double::from_bits(b as u128);
        match x.partial_cmp(&y) {
            Some(core::cmp::Ordering::Less) => {
                if is_max {
                    b
                } else {
                    a
                }
            }
            Some(core::cmp::Ordering::Greater) => {
                if is_max {
                    a
                } else {
                    b
                }
            }
            _ => {
                let a_neg = a >> 63 == 1;
                if is_max == a_neg { b } else { a }
            }
        }
    };
    (res, flags)
}

/// FCVT.{W,WU,L,LU}.D — f64 → integer, RISC-V saturating (NaN → max; ±ovf → bound; NV).
pub fn f64_to_int(bits: u64, width: crate::decode::FpIntWidth, rm: RoundMode) -> (u64, Flags) {
    use crate::decode::FpIntWidth::*;
    let x = Double::from_bits(bits as u128);
    let round = rm.to_apfloat();
    let mut exact = true;
    let (raw, status) = match width {
        W => {
            let r = x.to_i128_r(32, round, &mut exact);
            (r.value as i32 as i64 as u64, r.status)
        }
        L => {
            let r = x.to_i128_r(64, round, &mut exact);
            (r.value as i64 as u64, r.status)
        }
        Wu => {
            let r = x.to_u128_r(32, round, &mut exact);
            (r.value as u32 as i32 as i64 as u64, r.status)
        }
        Lu => {
            let r = x.to_u128_r(64, round, &mut exact);
            (r.value as u64, r.status)
        }
    };
    let is_nan = f64_is_nan(bits);
    let result = if is_nan {
        match width {
            W => 0x0000_0000_7FFF_FFFF,
            Wu => 0xFFFF_FFFF_FFFF_FFFF,
            L => 0x7FFF_FFFF_FFFF_FFFF,
            Lu => 0xFFFF_FFFF_FFFF_FFFF,
        }
    } else {
        raw
    };
    let mut f = 0u8;
    if is_nan || status.contains(Status::INVALID_OP) {
        f |= Flags::NV;
    } else if status.contains(Status::INEXACT) {
        f |= Flags::NX;
    }
    (result, Flags(f))
}

/// FCVT.D.{W,WU,L,LU} — integer → f64. W/WU are exact; L/LU may round.
pub fn f64_from_int(val: u64, width: crate::decode::FpIntWidth, rm: RoundMode) -> (u64, Flags) {
    use crate::decode::FpIntWidth::*;
    let round = rm.to_apfloat();
    let r = match width {
        W => Double::from_i128_r(val as i32 as i128, round),
        Wu => Double::from_u128_r(u128::from(val as u32), round),
        L => Double::from_i128_r(i128::from(val as i64), round),
        Lu => Double::from_u128_r(u128::from(val), round),
    };
    (r.value.to_bits() as u64, Flags::from_status(r.status))
}

// ── correctly-rounded integer-only sqrt ─────────────────────────────────────────

/// Bit length (position of the highest set bit, 0 for `v == 0`).
#[inline]
const fn bitlen(v: u128) -> u32 {
    128 - v.leading_zeros()
}

/// Compare `a·2^ea` vs `b·2^eb` for non-negative `a,b` without precision loss.
fn cmp_scaled(a: u128, ea: i32, b: u128, eb: i32) -> core::cmp::Ordering {
    use core::cmp::Ordering::*;
    if a == 0 && b == 0 {
        return Equal;
    }
    if a == 0 {
        return Less;
    }
    if b == 0 {
        return Greater;
    }
    // Bring both to a common exponent = min(ea, eb) by left-shifting the higher one; if a
    // shift would exceed u128, that side is unambiguously larger.
    let lo = ea.min(eb);
    let sa = (ea - lo) as u32;
    let sb = (eb - lo) as u32;
    // Would the shift overflow? (a << sa) fits iff sa + bitlen(a) <= 128.
    let a_of = sa + bitlen(a) > 128;
    let b_of = sb + bitlen(b) > 128;
    match (a_of, b_of) {
        (true, false) => Greater,
        (false, true) => Less,
        (true, true) => {
            // Compare magnitudes by total bit position of the MSB.
            (sa + bitlen(a)).cmp(&(sb + bitlen(b)))
        }
        (false, false) => (a << sa).cmp(&(b << sb)),
    }
}

/// Correctly-rounded IEEE square root, integer-only (no host float). `mant` = fraction
/// bits, `exp` = exponent bits, `bias` = exponent bias. Returns `(result_bits, flags)`.
///
/// Method: decompose `x = m·2^e` (integer significand). Because `sqrt` never under/overflows
/// a normal input (`sqrt(2^-1074) = 2^-537`, still normal), the result is always normal — so
/// only NX (inexact) and NV (invalid: sqrt of a negative) ever fire. Scale `m` by an even
/// shift so `q = isqrt(R)` yields exactly `p = mant+1` significand bits; `q` and `q+1` are
/// the two adjacent candidate floats bracketing the true root, and the correctly-rounded
/// result is chosen by comparing `x` to the candidates' *exact* squares.
fn ieee_sqrt(bits: u128, mant: u32, exp: u32, bias: i32, rm: RoundMode) -> (u128, Flags) {
    let p = mant + 1; // significand precision incl. implicit bit
    let sign = (bits >> (mant + exp)) & 1;
    let exp_mask = (1u128 << exp) - 1;
    let mant_mask = (1u128 << mant) - 1;
    let exp_field = (bits >> mant) & exp_mask;
    let frac = bits & mant_mask;

    let qnan = (exp_mask << mant) | (1u128 << (mant - 1)); // +canonical quiet NaN

    // Specials.
    if exp_field == exp_mask {
        // inf / NaN
        if frac == 0 {
            return if sign == 0 {
                (bits, Flags::NONE) // sqrt(+inf) = +inf
            } else {
                (qnan, Flags(Flags::NV)) // sqrt(-inf) = NaN
            };
        }
        // NaN input → canonical qNaN; a signaling NaN also raises NV.
        let is_snan = (frac >> (mant - 1)) & 1 == 0;
        return (
            qnan,
            if is_snan {
                Flags(Flags::NV)
            } else {
                Flags::NONE
            },
        );
    }
    if exp_field == 0 && frac == 0 {
        return (bits, Flags::NONE); // sqrt(±0) = ±0 (sign preserved)
    }
    if sign == 1 {
        return (qnan, Flags(Flags::NV)); // sqrt(negative) = NaN, NV
    }

    // Positive finite: x = m · 2^e with m an integer significand.
    let (mut m, mut e) = if exp_field == 0 {
        (frac, 1 - bias - mant as i32) // subnormal
    } else {
        (
            (1u128 << mant) | frac,
            exp_field as i32 - bias - mant as i32,
        )
    };
    // Make e even (shift keeps value: m·2^e unchanged).
    if e & 1 != 0 {
        m <<= 1;
        e -= 1;
    }
    // Scale m left by an even amount so the radicand has 2p-1 or 2p bits (→ isqrt has
    // exactly p bits). Parity of the target must match bitlen(m) so the shift stays even.
    let lm = bitlen(m);
    let target = if lm.is_multiple_of(2) {
        2 * p
    } else {
        2 * p - 1
    };
    let s = target - lm; // even, ≥ 0
    let r = m << s;
    let q = r.isqrt(); // floor(sqrt(r)); exactly p bits
    let exact = q * q == r;

    // The floor candidate `lo` has significand q at binary exponent glo = (e - s)/2.
    let glo = (e - s as i32) / 2;

    // Choose significand (q or q+1) per rounding mode, deciding ties by comparing x to the
    // midpoint's exact square. x = m·2^e; mid = (2q+1)·2^(glo-1) → mid² = (2q+1)²·2^(2glo-2).
    let up = if exact {
        false
    } else {
        match rm {
            RoundMode::Rtz | RoundMode::Rdn => false, // x > 0: truncate toward lo
            RoundMode::Rup => true,
            RoundMode::Rne | RoundMode::Rmm => {
                let mid2 = (2 * q + 1) * (2 * q + 1);
                match cmp_scaled(m, e, mid2, 2 * glo - 2) {
                    core::cmp::Ordering::Less => false,
                    core::cmp::Ordering::Greater => true,
                    core::cmp::Ordering::Equal => {
                        // Exact tie (only reachable in principle): RNE → even, RMM → up.
                        match rm {
                            RoundMode::Rmm => true,
                            _ => q & 1 == 1, // ties to even
                        }
                    }
                }
            }
        }
    };

    let mut sig = if up { q + 1 } else { q };
    let mut uexp = glo + (p as i32 - 1); // unbiased exponent (MSB of a p-bit sig at p-1)
    // A round-up carry (q+1 == 2^p) renormalizes to 2^(p-1) with exponent +1.
    if sig >> p != 0 {
        sig >>= 1;
        uexp += 1;
    }

    let biased = (uexp + bias) as u128;
    let out = (sig & mant_mask) | (biased << mant); // sign is +, always normal
    (out, if exact { Flags::NONE } else { Flags(Flags::NX) })
}
