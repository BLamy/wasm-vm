//! Little-endian virtio-gpu control protocol types (virtio spec 1.2 §5.7).
//!
//! These types intentionally use explicit byte encoding instead of host-layout casts.  The same
//! methods therefore produce identical fixtures on native and wasm32 targets.

/// `VIRTIO_GPU_CMD_GET_DISPLAY_INFO`.
pub const CMD_GET_DISPLAY_INFO: u32 = 0x0100;
/// `VIRTIO_GPU_CMD_RESOURCE_CREATE_2D`.
pub const CMD_RESOURCE_CREATE_2D: u32 = 0x0101;
/// `VIRTIO_GPU_CMD_RESOURCE_UNREF`.
pub const CMD_RESOURCE_UNREF: u32 = 0x0102;
/// `VIRTIO_GPU_CMD_SET_SCANOUT`.
pub const CMD_SET_SCANOUT: u32 = 0x0103;
/// `VIRTIO_GPU_CMD_RESOURCE_FLUSH`.
pub const CMD_RESOURCE_FLUSH: u32 = 0x0104;
/// `VIRTIO_GPU_CMD_TRANSFER_TO_HOST_2D`.
pub const CMD_TRANSFER_TO_HOST_2D: u32 = 0x0105;
/// `VIRTIO_GPU_CMD_RESOURCE_ATTACH_BACKING`.
pub const CMD_RESOURCE_ATTACH_BACKING: u32 = 0x0106;
/// `VIRTIO_GPU_CMD_RESOURCE_DETACH_BACKING`.
pub const CMD_RESOURCE_DETACH_BACKING: u32 = 0x0107;
/// `VIRTIO_GPU_CMD_GET_CAPSET_INFO`.
pub const CMD_GET_CAPSET_INFO: u32 = 0x0108;
/// `VIRTIO_GPU_CMD_GET_CAPSET`.
pub const CMD_GET_CAPSET: u32 = 0x0109;
/// `VIRTIO_GPU_CMD_GET_EDID`.
pub const CMD_GET_EDID: u32 = 0x010a;
/// Virtio 1.2 / Linux v6.1 virtio_gpu.h 3D control opcodes. Production negotiation
/// remains disabled; only the explicit proof constructor enables their handler.
pub const CMD_CTX_CREATE: u32 = 0x0200;
pub const CMD_CTX_DESTROY: u32 = 0x0201;
pub const CMD_CTX_ATTACH_RESOURCE: u32 = 0x0202;
pub const CMD_CTX_DETACH_RESOURCE: u32 = 0x0203;
pub const CMD_RESOURCE_CREATE_3D: u32 = 0x0204;
pub const CMD_TRANSFER_TO_HOST_3D: u32 = 0x0205;
pub const CMD_TRANSFER_FROM_HOST_3D: u32 = 0x0206;
pub const CMD_SUBMIT_3D: u32 = 0x0207;
pub const CTX_CREATE_SIZE: usize = 96;
pub const CTX_DESTROY_SIZE: usize = 24;
pub const CTX_RESOURCE_SIZE: usize = 32;
pub const RESOURCE_CREATE_3D_SIZE: usize = 72;
/// `VIRTIO_GPU_CMD_UPDATE_CURSOR`.
pub const CMD_UPDATE_CURSOR: u32 = 0x0300;
/// `VIRTIO_GPU_CMD_MOVE_CURSOR`.
pub const CMD_MOVE_CURSOR: u32 = 0x0301;
/// Successful `GET_DISPLAY_INFO` response.
pub const RESP_OK_DISPLAY_INFO: u32 = 0x1101;
/// Successful command with no response payload.
pub const RESP_OK_NODATA: u32 = 0x1100;
/// Successful `GET_CAPSET_INFO` response.
pub const RESP_OK_CAPSET_INFO: u32 = 0x1102;
/// Successful `GET_CAPSET` response.
pub const RESP_OK_CAPSET: u32 = 0x1103;
/// Successful `GET_EDID` response.
pub const RESP_OK_EDID: u32 = 0x1104;
/// Generic unsupported/malformed-command response (used by E5-T01c).
pub const RESP_ERR_UNSPEC: u32 = 0x1200;
/// Resource command errors (virtio-gpu spec §5.7.6.4).
pub const RESP_ERR_OUT_OF_MEMORY: u32 = 0x1201;
pub const RESP_ERR_INVALID_SCANOUT_ID: u32 = 0x1202;
pub const RESP_ERR_INVALID_RESOURCE_ID: u32 = 0x1203;
pub const RESP_ERR_INVALID_CONTEXT_ID: u32 = 0x1204;
pub const RESP_ERR_INVALID_PARAMETER: u32 = 0x1205;
/// Request/response fence flag.
pub const FLAG_FENCE: u32 = 1 << 0;

/// Virtio-gpu 2D resource formats supported by the host shadow store.
pub const FORMAT_B8G8R8A8_UNORM: u32 = 1;
pub const FORMAT_B8G8R8X8_UNORM: u32 = 2;
pub const FORMAT_A8R8G8B8_UNORM: u32 = 3;
pub const FORMAT_X8R8G8B8_UNORM: u32 = 4;
pub const FORMAT_R8G8B8A8_UNORM: u32 = 67;
pub const FORMAT_R8G8B8X8_UNORM: u32 = 68;

/// Whether a format is one of the six 32-bit formats accepted for 2D resources.
pub const fn is_supported_format(format: u32) -> bool {
    matches!(
        format,
        FORMAT_B8G8R8A8_UNORM
            | FORMAT_B8G8R8X8_UNORM
            | FORMAT_A8R8G8B8_UNORM
            | FORMAT_X8R8G8B8_UNORM
            | FORMAT_R8G8B8A8_UNORM
            | FORMAT_R8G8B8X8_UNORM
    )
}

/// Number of display modes carried by `virtio_gpu_resp_display_info`.
pub const DISPLAY_MODE_COUNT: usize = 16;
/// Wire size of `virtio_gpu_ctrl_hdr`.
pub const CTRL_HDR_SIZE: usize = 24;
/// Wire size of `virtio_gpu_resource_create_2d`.
pub const RESOURCE_CREATE_2D_SIZE: usize = CTRL_HDR_SIZE + 16;
/// Wire size of the fixed part of `virtio_gpu_resource_attach_backing`.
pub const RESOURCE_ATTACH_BACKING_HEADER_SIZE: usize = CTRL_HDR_SIZE + 8;
/// Wire size of `virtio_gpu_resource_detach_backing`.
pub const RESOURCE_DETACH_BACKING_SIZE: usize = CTRL_HDR_SIZE + 8;
/// Wire size of `virtio_gpu_resource_unref`.
pub const RESOURCE_UNREF_SIZE: usize = CTRL_HDR_SIZE + 8;
/// Wire size of `virtio_gpu_rect`.
pub const RECT_SIZE: usize = 16;
/// Wire size of `virtio_gpu_set_scanout`.
pub const SET_SCANOUT_SIZE: usize = CTRL_HDR_SIZE + RECT_SIZE + 8;
/// Wire size of `virtio_gpu_transfer_to_host_2d`.
pub const TRANSFER_TO_HOST_2D_SIZE: usize = CTRL_HDR_SIZE + RECT_SIZE + 16;
/// Wire size of `virtio_gpu_resource_flush`.
pub const RESOURCE_FLUSH_SIZE: usize = CTRL_HDR_SIZE + RECT_SIZE + 8;
/// Wire size of `virtio_gpu_cmd_get_edid` (scanout plus required padding).
pub const GET_EDID_REQUEST_SIZE: usize = CTRL_HDR_SIZE + 8;
/// Wire size of `virtio_gpu_cursor_pos`.
pub const CURSOR_POS_SIZE: usize = 16;
/// Wire size of `virtio_gpu_update_cursor`.
pub const UPDATE_CURSOR_SIZE: usize = CTRL_HDR_SIZE + CURSOR_POS_SIZE + 16;
/// Wire size of `virtio_gpu_move_cursor`.
pub const MOVE_CURSOR_SIZE: usize = CTRL_HDR_SIZE + CURSOR_POS_SIZE;
/// Wire size of one `virtio_gpu_mem_entry`.
pub const RESOURCE_MEM_ENTRY_SIZE: usize = 16;
/// Wire size of one `virtio_gpu_display_one`.
pub const DISPLAY_MODE_SIZE: usize = 24;
/// Wire size of `virtio_gpu_resp_display_info`.
pub const DISPLAY_INFO_RESPONSE_SIZE: usize =
    CTRL_HDR_SIZE + DISPLAY_MODE_COUNT * DISPLAY_MODE_SIZE;
/// Wire size of `virtio_gpu_resp_edid` (size, padding, and the 1024-byte EDID payload).
pub const EDID_RESPONSE_SIZE: usize = CTRL_HDR_SIZE + 8 + 1024;

/// `virtio_gpu_ctrl_hdr`, encoded as le32/le32/le64/le32/u8/u8[3].
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct CtrlHeader {
    pub ty: u32,
    pub flags: u32,
    pub fence_id: u64,
    pub ctx_id: u32,
    pub ring_idx: u8,
    pub padding: [u8; 3],
}

impl CtrlHeader {
    /// Encode the header into its exact 24-byte wire representation.
    pub fn to_bytes(self) -> [u8; CTRL_HDR_SIZE] {
        let mut out = [0u8; CTRL_HDR_SIZE];
        out[0..4].copy_from_slice(&self.ty.to_le_bytes());
        out[4..8].copy_from_slice(&self.flags.to_le_bytes());
        out[8..16].copy_from_slice(&self.fence_id.to_le_bytes());
        out[16..20].copy_from_slice(&self.ctx_id.to_le_bytes());
        out[20] = self.ring_idx;
        out[21..24].copy_from_slice(&self.padding);
        out
    }

    /// Decode a complete header; short input is rejected without indexing it.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() < CTRL_HDR_SIZE {
            return None;
        }
        Some(Self {
            ty: u32::from_le_bytes(bytes[0..4].try_into().ok()?),
            flags: u32::from_le_bytes(bytes[4..8].try_into().ok()?),
            fence_id: u64::from_le_bytes(bytes[8..16].try_into().ok()?),
            ctx_id: u32::from_le_bytes(bytes[16..20].try_into().ok()?),
            ring_idx: bytes[20],
            padding: [bytes[21], bytes[22], bytes[23]],
        })
    }
}

/// `virtio_gpu_get_edid`, containing the scanout whose base block is requested.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct GetEdid {
    pub header: CtrlHeader,
    pub scanout_id: u32,
}

impl GetEdid {
    /// Decode a complete GET_EDID request.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() < GET_EDID_REQUEST_SIZE {
            return None;
        }
        Some(Self {
            header: CtrlHeader::from_bytes(&bytes[..CTRL_HDR_SIZE])?,
            scanout_id: u32::from_le_bytes(bytes[24..28].try_into().ok()?),
        })
    }

    /// Encode the exact 32-byte GET_EDID request layout, leaving the required padding zeroed.
    pub fn to_bytes(self) -> [u8; GET_EDID_REQUEST_SIZE] {
        let mut out = [0u8; GET_EDID_REQUEST_SIZE];
        out[..CTRL_HDR_SIZE].copy_from_slice(&self.header.to_bytes());
        out[24..28].copy_from_slice(&self.scanout_id.to_le_bytes());
        out
    }
}

/// `virtio_gpu_cursor_pos`, shared by UPDATE_CURSOR and MOVE_CURSOR.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct CursorPos {
    pub scanout_id: u32,
    pub x: u32,
    pub y: u32,
    pub padding: u32,
}

impl CursorPos {
    /// Decode a complete cursor position.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() < CURSOR_POS_SIZE {
            return None;
        }
        Some(Self {
            scanout_id: u32::from_le_bytes(bytes[0..4].try_into().ok()?),
            x: u32::from_le_bytes(bytes[4..8].try_into().ok()?),
            y: u32::from_le_bytes(bytes[8..12].try_into().ok()?),
            padding: u32::from_le_bytes(bytes[12..16].try_into().ok()?),
        })
    }

    /// Encode the exact little-endian cursor-position layout.
    pub fn to_bytes(self) -> [u8; CURSOR_POS_SIZE] {
        let mut out = [0u8; CURSOR_POS_SIZE];
        out[0..4].copy_from_slice(&self.scanout_id.to_le_bytes());
        out[4..8].copy_from_slice(&self.x.to_le_bytes());
        out[8..12].copy_from_slice(&self.y.to_le_bytes());
        out[12..16].copy_from_slice(&self.padding.to_le_bytes());
        out
    }
}

/// `virtio_gpu_update_cursor`, with the cursor image resource and hotspot.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct UpdateCursor {
    pub header: CtrlHeader,
    pub pos: CursorPos,
    pub resource_id: u32,
    pub hot_x: u32,
    pub hot_y: u32,
    pub padding: u32,
}

impl UpdateCursor {
    /// Decode a complete UPDATE_CURSOR request.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() < UPDATE_CURSOR_SIZE {
            return None;
        }
        Some(Self {
            header: CtrlHeader::from_bytes(&bytes[..CTRL_HDR_SIZE])?,
            pos: CursorPos::from_bytes(&bytes[CTRL_HDR_SIZE..CTRL_HDR_SIZE + CURSOR_POS_SIZE])?,
            resource_id: u32::from_le_bytes(bytes[40..44].try_into().ok()?),
            hot_x: u32::from_le_bytes(bytes[44..48].try_into().ok()?),
            hot_y: u32::from_le_bytes(bytes[48..52].try_into().ok()?),
            padding: u32::from_le_bytes(bytes[52..56].try_into().ok()?),
        })
    }

    /// Encode the exact 56-byte UPDATE_CURSOR request layout.
    pub fn to_bytes(self) -> [u8; UPDATE_CURSOR_SIZE] {
        let mut out = [0u8; UPDATE_CURSOR_SIZE];
        out[..CTRL_HDR_SIZE].copy_from_slice(&self.header.to_bytes());
        out[CTRL_HDR_SIZE..CTRL_HDR_SIZE + CURSOR_POS_SIZE].copy_from_slice(&self.pos.to_bytes());
        out[40..44].copy_from_slice(&self.resource_id.to_le_bytes());
        out[44..48].copy_from_slice(&self.hot_x.to_le_bytes());
        out[48..52].copy_from_slice(&self.hot_y.to_le_bytes());
        out[52..56].copy_from_slice(&self.padding.to_le_bytes());
        out
    }
}

/// `virtio_gpu_move_cursor`, containing only the new position.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct MoveCursor {
    pub header: CtrlHeader,
    pub pos: CursorPos,
}

impl MoveCursor {
    /// Decode a complete MOVE_CURSOR request.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() < MOVE_CURSOR_SIZE {
            return None;
        }
        Some(Self {
            header: CtrlHeader::from_bytes(&bytes[..CTRL_HDR_SIZE])?,
            pos: CursorPos::from_bytes(&bytes[CTRL_HDR_SIZE..CTRL_HDR_SIZE + CURSOR_POS_SIZE])?,
        })
    }

    /// Encode the exact 40-byte MOVE_CURSOR request layout.
    pub fn to_bytes(self) -> [u8; MOVE_CURSOR_SIZE] {
        let mut out = [0u8; MOVE_CURSOR_SIZE];
        out[..CTRL_HDR_SIZE].copy_from_slice(&self.header.to_bytes());
        out[CTRL_HDR_SIZE..CTRL_HDR_SIZE + CURSOR_POS_SIZE].copy_from_slice(&self.pos.to_bytes());
        out
    }
}

/// `virtio_gpu_resp_edid`, with a size/padding pair followed by the EDID payload area.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct EdidResponse {
    pub header: CtrlHeader,
    pub edid: [u8; 128],
}

impl EdidResponse {
    /// Encode the exact 1056-byte GET_EDID response layout. The device returns one 128-byte base
    /// block and reports that size; the remaining payload area is zero-filled as required by the
    /// fixed-size virtio-gpu response structure.
    pub fn to_bytes(self) -> [u8; EDID_RESPONSE_SIZE] {
        let mut out = [0u8; EDID_RESPONSE_SIZE];
        out[..CTRL_HDR_SIZE].copy_from_slice(&self.header.to_bytes());
        out[CTRL_HDR_SIZE..CTRL_HDR_SIZE + 4]
            .copy_from_slice(&(self.edid.len() as u32).to_le_bytes());
        let edid_start = CTRL_HDR_SIZE + 8;
        out[edid_start..edid_start + self.edid.len()].copy_from_slice(&self.edid);
        out
    }

    /// Decode a complete EDID response.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() < EDID_RESPONSE_SIZE {
            return None;
        }
        let header = CtrlHeader::from_bytes(&bytes[..CTRL_HDR_SIZE])?;
        let size = u32::from_le_bytes(bytes[CTRL_HDR_SIZE..CTRL_HDR_SIZE + 4].try_into().ok()?);
        if size < 128 || size as usize > 1024 {
            return None;
        }
        let mut edid = [0u8; 128];
        let edid_start = CTRL_HDR_SIZE + 8;
        let edid_len = edid.len();
        edid.copy_from_slice(&bytes[edid_start..edid_start + edid_len]);
        Some(Self { header, edid })
    }
}

/// `virtio_gpu_rect`, encoded as four little-endian 32-bit fields.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct Rect {
    pub x: u32,
    pub y: u32,
    pub width: u32,
    pub height: u32,
}

impl Rect {
    /// Decode a complete 16-byte rectangle.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() < RECT_SIZE {
            return None;
        }
        Some(Self {
            x: u32::from_le_bytes(bytes[0..4].try_into().ok()?),
            y: u32::from_le_bytes(bytes[4..8].try_into().ok()?),
            width: u32::from_le_bytes(bytes[8..12].try_into().ok()?),
            height: u32::from_le_bytes(bytes[12..16].try_into().ok()?),
        })
    }

    /// Encode the exact little-endian wire representation.
    pub fn to_bytes(self) -> [u8; RECT_SIZE] {
        let mut out = [0u8; RECT_SIZE];
        out[0..4].copy_from_slice(&self.x.to_le_bytes());
        out[4..8].copy_from_slice(&self.y.to_le_bytes());
        out[8..12].copy_from_slice(&self.width.to_le_bytes());
        out[12..16].copy_from_slice(&self.height.to_le_bytes());
        out
    }
}

/// `virtio_gpu_set_scanout`, with its rectangle between the control header and ids.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SetScanout {
    pub header: CtrlHeader,
    pub rect: Rect,
    pub scanout_id: u32,
    pub resource_id: u32,
}

impl SetScanout {
    /// Decode a complete SET_SCANOUT request.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() < SET_SCANOUT_SIZE {
            return None;
        }
        Some(Self {
            header: CtrlHeader::from_bytes(&bytes[..CTRL_HDR_SIZE])?,
            rect: Rect::from_bytes(&bytes[CTRL_HDR_SIZE..CTRL_HDR_SIZE + RECT_SIZE])?,
            scanout_id: u32::from_le_bytes(bytes[40..44].try_into().ok()?),
            resource_id: u32::from_le_bytes(bytes[44..48].try_into().ok()?),
        })
    }

    /// Encode the exact 48-byte SET_SCANOUT request layout.
    pub fn to_bytes(self) -> [u8; SET_SCANOUT_SIZE] {
        let mut out = [0u8; SET_SCANOUT_SIZE];
        out[..CTRL_HDR_SIZE].copy_from_slice(&self.header.to_bytes());
        out[CTRL_HDR_SIZE..CTRL_HDR_SIZE + RECT_SIZE].copy_from_slice(&self.rect.to_bytes());
        out[40..44].copy_from_slice(&self.scanout_id.to_le_bytes());
        out[44..48].copy_from_slice(&self.resource_id.to_le_bytes());
        out
    }
}

/// `virtio_gpu_transfer_to_host_2d`, with a byte offset into the linear backing stream.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct TransferToHost2d {
    pub header: CtrlHeader,
    pub rect: Rect,
    pub offset: u64,
    pub resource_id: u32,
    pub padding: u32,
}

impl TransferToHost2d {
    /// Decode a complete 56-byte TRANSFER_TO_HOST_2D request.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() < TRANSFER_TO_HOST_2D_SIZE {
            return None;
        }
        Some(Self {
            header: CtrlHeader::from_bytes(&bytes[..CTRL_HDR_SIZE])?,
            rect: Rect::from_bytes(&bytes[CTRL_HDR_SIZE..CTRL_HDR_SIZE + RECT_SIZE])?,
            offset: u64::from_le_bytes(bytes[40..48].try_into().ok()?),
            resource_id: u32::from_le_bytes(bytes[48..52].try_into().ok()?),
            padding: u32::from_le_bytes(bytes[52..56].try_into().ok()?),
        })
    }

    /// Encode the exact little-endian transfer request layout.
    pub fn to_bytes(self) -> [u8; TRANSFER_TO_HOST_2D_SIZE] {
        let mut out = [0u8; TRANSFER_TO_HOST_2D_SIZE];
        out[..CTRL_HDR_SIZE].copy_from_slice(&self.header.to_bytes());
        out[CTRL_HDR_SIZE..CTRL_HDR_SIZE + RECT_SIZE].copy_from_slice(&self.rect.to_bytes());
        out[40..48].copy_from_slice(&self.offset.to_le_bytes());
        out[48..52].copy_from_slice(&self.resource_id.to_le_bytes());
        out[52..56].copy_from_slice(&self.padding.to_le_bytes());
        out
    }
}

/// `virtio_gpu_resource_flush`, with the damaged rectangle between the header and resource id.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ResourceFlush {
    pub header: CtrlHeader,
    pub rect: Rect,
    pub resource_id: u32,
    pub padding: u32,
}

impl ResourceFlush {
    /// Decode a complete 48-byte RESOURCE_FLUSH request.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() < RESOURCE_FLUSH_SIZE {
            return None;
        }
        Some(Self {
            header: CtrlHeader::from_bytes(&bytes[..CTRL_HDR_SIZE])?,
            rect: Rect::from_bytes(&bytes[CTRL_HDR_SIZE..CTRL_HDR_SIZE + RECT_SIZE])?,
            resource_id: u32::from_le_bytes(bytes[40..44].try_into().ok()?),
            padding: u32::from_le_bytes(bytes[44..48].try_into().ok()?),
        })
    }

    /// Encode the exact little-endian flush request layout.
    pub fn to_bytes(self) -> [u8; RESOURCE_FLUSH_SIZE] {
        let mut out = [0u8; RESOURCE_FLUSH_SIZE];
        out[..CTRL_HDR_SIZE].copy_from_slice(&self.header.to_bytes());
        out[CTRL_HDR_SIZE..CTRL_HDR_SIZE + RECT_SIZE].copy_from_slice(&self.rect.to_bytes());
        out[40..44].copy_from_slice(&self.resource_id.to_le_bytes());
        out[44..48].copy_from_slice(&self.padding.to_le_bytes());
        out
    }
}

/// `virtio_gpu_resource_create_2d`, encoded with an explicit little-endian layout.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ResourceCreate2d {
    pub header: CtrlHeader,
    pub resource_id: u32,
    pub format: u32,
    pub width: u32,
    pub height: u32,
}

impl ResourceCreate2d {
    /// Decode a complete CREATE_2D request; short input is rejected before any field access.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() < RESOURCE_CREATE_2D_SIZE {
            return None;
        }
        Some(Self {
            header: CtrlHeader::from_bytes(&bytes[..CTRL_HDR_SIZE])?,
            resource_id: u32::from_le_bytes(bytes[24..28].try_into().ok()?),
            format: u32::from_le_bytes(bytes[28..32].try_into().ok()?),
            width: u32::from_le_bytes(bytes[32..36].try_into().ok()?),
            height: u32::from_le_bytes(bytes[36..40].try_into().ok()?),
        })
    }

    /// Encode the exact 40-byte request layout.
    pub fn to_bytes(self) -> [u8; RESOURCE_CREATE_2D_SIZE] {
        let mut out = [0u8; RESOURCE_CREATE_2D_SIZE];
        out[..CTRL_HDR_SIZE].copy_from_slice(&self.header.to_bytes());
        out[24..28].copy_from_slice(&self.resource_id.to_le_bytes());
        out[28..32].copy_from_slice(&self.format.to_le_bytes());
        out[32..36].copy_from_slice(&self.width.to_le_bytes());
        out[36..40].copy_from_slice(&self.height.to_le_bytes());
        out
    }
}

/// Fixed header of `virtio_gpu_resource_attach_backing`; entries follow immediately afterward.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ResourceAttachBacking {
    pub header: CtrlHeader,
    pub resource_id: u32,
    pub nents: u32,
}

impl ResourceAttachBacking {
    /// Decode the fixed 32-byte attach header.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() < RESOURCE_ATTACH_BACKING_HEADER_SIZE {
            return None;
        }
        Some(Self {
            header: CtrlHeader::from_bytes(&bytes[..CTRL_HDR_SIZE])?,
            resource_id: u32::from_le_bytes(bytes[24..28].try_into().ok()?),
            nents: u32::from_le_bytes(bytes[28..32].try_into().ok()?),
        })
    }

    /// Encode the fixed attach header.
    pub fn to_bytes(self) -> [u8; RESOURCE_ATTACH_BACKING_HEADER_SIZE] {
        let mut out = [0u8; RESOURCE_ATTACH_BACKING_HEADER_SIZE];
        out[..CTRL_HDR_SIZE].copy_from_slice(&self.header.to_bytes());
        out[24..28].copy_from_slice(&self.resource_id.to_le_bytes());
        out[28..32].copy_from_slice(&self.nents.to_le_bytes());
        out
    }
}

/// One guest-physical scatter-gather entry following an attach header.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ResourceMemEntry {
    pub addr: u64,
    pub length: u32,
    pub padding: u32,
}

impl ResourceMemEntry {
    /// Decode one complete little-endian memory entry.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() < RESOURCE_MEM_ENTRY_SIZE {
            return None;
        }
        Some(Self {
            addr: u64::from_le_bytes(bytes[0..8].try_into().ok()?),
            length: u32::from_le_bytes(bytes[8..12].try_into().ok()?),
            padding: u32::from_le_bytes(bytes[12..16].try_into().ok()?),
        })
    }

    /// Encode one memory entry without relying on host struct layout.
    pub fn to_bytes(self) -> [u8; RESOURCE_MEM_ENTRY_SIZE] {
        let mut out = [0u8; RESOURCE_MEM_ENTRY_SIZE];
        out[0..8].copy_from_slice(&self.addr.to_le_bytes());
        out[8..12].copy_from_slice(&self.length.to_le_bytes());
        out[12..16].copy_from_slice(&self.padding.to_le_bytes());
        out
    }
}

/// `virtio_gpu_resource_detach_backing`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ResourceDetachBacking {
    pub header: CtrlHeader,
    pub resource_id: u32,
    pub padding: u32,
}

impl ResourceDetachBacking {
    /// Decode the complete 32-byte detach request.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() < RESOURCE_DETACH_BACKING_SIZE {
            return None;
        }
        Some(Self {
            header: CtrlHeader::from_bytes(&bytes[..CTRL_HDR_SIZE])?,
            resource_id: u32::from_le_bytes(bytes[24..28].try_into().ok()?),
            padding: u32::from_le_bytes(bytes[28..32].try_into().ok()?),
        })
    }

    /// Encode the complete detach request.
    pub fn to_bytes(self) -> [u8; RESOURCE_DETACH_BACKING_SIZE] {
        let mut out = [0u8; RESOURCE_DETACH_BACKING_SIZE];
        out[..CTRL_HDR_SIZE].copy_from_slice(&self.header.to_bytes());
        out[24..28].copy_from_slice(&self.resource_id.to_le_bytes());
        out[28..32].copy_from_slice(&self.padding.to_le_bytes());
        out
    }
}

/// `virtio_gpu_resource_unref`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ResourceUnref {
    pub header: CtrlHeader,
    pub resource_id: u32,
    pub padding: u32,
}

impl ResourceUnref {
    /// Decode the complete 32-byte unref request.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() < RESOURCE_UNREF_SIZE {
            return None;
        }
        Some(Self {
            header: CtrlHeader::from_bytes(&bytes[..CTRL_HDR_SIZE])?,
            resource_id: u32::from_le_bytes(bytes[24..28].try_into().ok()?),
            padding: u32::from_le_bytes(bytes[28..32].try_into().ok()?),
        })
    }

    /// Encode the complete unref request.
    pub fn to_bytes(self) -> [u8; RESOURCE_UNREF_SIZE] {
        let mut out = [0u8; RESOURCE_UNREF_SIZE];
        out[..CTRL_HDR_SIZE].copy_from_slice(&self.header.to_bytes());
        out[24..28].copy_from_slice(&self.resource_id.to_le_bytes());
        out[28..32].copy_from_slice(&self.padding.to_le_bytes());
        out
    }
}

/// One entry in `virtio_gpu_resp_display_info.pmodes`.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct DisplayMode {
    pub x: u32,
    pub y: u32,
    pub width: u32,
    pub height: u32,
    pub enabled: u32,
    pub flags: u32,
}

impl DisplayMode {
    /// Encode one display mode into its exact 24-byte wire representation.
    pub fn to_bytes(self) -> [u8; DISPLAY_MODE_SIZE] {
        let mut out = [0u8; DISPLAY_MODE_SIZE];
        out[0..4].copy_from_slice(&self.x.to_le_bytes());
        out[4..8].copy_from_slice(&self.y.to_le_bytes());
        out[8..12].copy_from_slice(&self.width.to_le_bytes());
        out[12..16].copy_from_slice(&self.height.to_le_bytes());
        out[16..20].copy_from_slice(&self.enabled.to_le_bytes());
        out[20..24].copy_from_slice(&self.flags.to_le_bytes());
        out
    }

    /// Decode one complete display mode; short input is rejected.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() < DISPLAY_MODE_SIZE {
            return None;
        }
        Some(Self {
            x: u32::from_le_bytes(bytes[0..4].try_into().ok()?),
            y: u32::from_le_bytes(bytes[4..8].try_into().ok()?),
            width: u32::from_le_bytes(bytes[8..12].try_into().ok()?),
            height: u32::from_le_bytes(bytes[12..16].try_into().ok()?),
            enabled: u32::from_le_bytes(bytes[16..20].try_into().ok()?),
            flags: u32::from_le_bytes(bytes[20..24].try_into().ok()?),
        })
    }
}

/// `virtio_gpu_resp_display_info`: a response header plus sixteen display modes.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DisplayInfoResponse {
    pub header: CtrlHeader,
    pub modes: [DisplayMode; DISPLAY_MODE_COUNT],
}

impl DisplayInfoResponse {
    /// Build the initial one-scanout response.  Later modes remain disabled and zeroed.
    pub fn new(header: CtrlHeader) -> Self {
        Self::new_with_mode(header, 1280, 800)
    }

    /// Build a one-scanout response using the current host display dimensions.
    pub fn new_with_mode(header: CtrlHeader, width: u32, height: u32) -> Self {
        let mut modes = [DisplayMode::default(); DISPLAY_MODE_COUNT];
        modes[0] = DisplayMode {
            width,
            height,
            enabled: 1,
            ..DisplayMode::default()
        };
        Self { header, modes }
    }

    /// Encode the complete response into the exact 408-byte wire representation.
    pub fn to_bytes(self) -> [u8; DISPLAY_INFO_RESPONSE_SIZE] {
        let mut out = [0u8; DISPLAY_INFO_RESPONSE_SIZE];
        out[0..CTRL_HDR_SIZE].copy_from_slice(&self.header.to_bytes());
        for (index, mode) in self.modes.iter().enumerate() {
            let start = CTRL_HDR_SIZE + index * DISPLAY_MODE_SIZE;
            out[start..start + DISPLAY_MODE_SIZE].copy_from_slice(&mode.to_bytes());
        }
        out
    }

    /// Decode the complete response; every header and mode boundary is checked before access.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() < DISPLAY_INFO_RESPONSE_SIZE {
            return None;
        }
        let header = CtrlHeader::from_bytes(&bytes[0..CTRL_HDR_SIZE])?;
        let mut modes = [DisplayMode::default(); DISPLAY_MODE_COUNT];
        for (index, mode) in modes.iter_mut().enumerate() {
            let start = CTRL_HDR_SIZE + index * DISPLAY_MODE_SIZE;
            *mode = DisplayMode::from_bytes(&bytes[start..start + DISPLAY_MODE_SIZE])?;
        }
        Some(Self { header, modes })
    }
}

/// Names matching the C/UAPI structures are useful at the queue boundary and keep call sites
/// self-documenting without making the Rust field names depend on C keywords.
pub type VirtioGpuCtrlHdr = CtrlHeader;
pub type VirtioGpuDisplayOne = DisplayMode;
pub type VirtioGpuRespDisplayInfo = DisplayInfoResponse;
pub type VirtioGpuGetEdid = GetEdid;
pub type VirtioGpuRespEdid = EdidResponse;
