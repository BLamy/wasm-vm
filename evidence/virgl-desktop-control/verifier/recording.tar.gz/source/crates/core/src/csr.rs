//! Control and status registers (E1-T01 reset state + E1-T02 Zicsr subsystem).
//!
//! One table-driven CSR file every later task (mstatus fields, satp, counters, PMP) plugs
//! into instead of open-coding CSR behavior. It implements the Zicsr mechanics —
//! CSRRW/CSRRS/CSRRC and immediate forms with spec-exact **side-effect suppression**,
//! per-address **privilege** and **read-only** checks derived from the CSR encoding
//! (Privileged §2.1: `addr[11:10]==0b11` ⇒ read-only, `addr[9:8]` ⇒ min privilege), and
//! per-CSR **WARL** legalization.
//!
//! This is the real CSR state that supersedes E0-T19's quarantined `zicsr_stub`; the
//! decoder wires CSR instructions to it only when that feature is OFF, so the rv64ui-p
//! p-env path is unchanged until a later task migrates it.

use alloc::vec::Vec;

use crate::hart::{Exception, Trap};

/// `misa` for this implementation: MXL=2 (RV64), extensions **I M A F D C S U**. WARL and
/// hardwired — writes legalize to this, reads always return it (§3.1.1). Bits: A(0) C(2)
/// D(3) F(5) I(8) M(12) S(18) U(20), MXL=2 in bits 63:62.
pub const MISA_RV64GC_SU: u64 = 0x8000_0000_0014_112D;

// ── CSR addresses used here ───────────────────────────────────────────────────
/// Floating-point CSRs (E1-T06). User read/write (`addr[9:8]=00`, `addr[11:10]=00`).
/// `fcsr` aliases the pair: `fcsr[4:0] = fflags`, `fcsr[7:5] = frm`.
pub const FFLAGS: u16 = 0x001;
pub const FRM: u16 = 0x002;
pub const FCSR: u16 = 0x003;
pub const MSTATUS: u16 = 0x300;
pub const MISA: u16 = 0x301;
pub const MEDELEG: u16 = 0x302;
pub const MIDELEG: u16 = 0x303;
pub const MIE: u16 = 0x304;
pub const MTVEC: u16 = 0x305;
pub const MSCRATCH: u16 = 0x340;
pub const MEPC: u16 = 0x341;
pub const MCAUSE: u16 = 0x342;
pub const MTVAL: u16 = 0x343;
pub const MIP: u16 = 0x344;
pub const SATP: u16 = 0x180;
/// Supervisor CSRs (E1-T09). `sstatus`/`sie`/`sip` are masked *views* over
/// `mstatus`/`mie`/`mip` (single backing storage); the rest are WARL-stored.
pub const SSTATUS: u16 = 0x100;
pub const SIE: u16 = 0x104;
/// Supervisor trap vector (WARL-stored here; full S-mode semantics arrive with the MMU).
pub const STVEC: u16 = 0x105;
pub const SSCRATCH: u16 = 0x140;
pub const SEPC: u16 = 0x141;
pub const SCAUSE: u16 = 0x142;
pub const STVAL: u16 = 0x143;
pub const SIP: u16 = 0x144;
/// `mnstatus` (Smrnmi) — the riscv-tests p-env writes it during machine-mode init. Stored
/// WARL; its NMI semantics are out of scope until an interrupt task.
pub const MNSTATUS: u16 = 0x744;
/// Debug-spec trigger CSRs (E1-T29): a single `mcontrol` trigger (index 0). `tselect` picks
/// the trigger, `tdata1` holds its mcontrol config, `tdata2` the compare value, `tcontrol.mte`
/// gates M-mode firing, `tinfo` advertises the supported trigger type.
pub const TSELECT: u16 = 0x7A0;
pub const TDATA1: u16 = 0x7A1;
pub const TDATA2: u16 = 0x7A2;
pub const TDATA3: u16 = 0x7A3;
pub const TINFO: u16 = 0x7A4;
pub const TCONTROL: u16 = 0x7A5;
/// pmpcfg: 64 entries → the EVEN CSRs pmpcfg0,2,4,…,14 at 0x3A0,0x3A2,…,0x3AE (RV64 has no odd
/// pmpcfg CSRs — 0x3A1/0x3A3/… are illegal). Bank `2b` packs entries `[8b, 8b+8)` (E1-T15/T27).
pub const PMPCFG0: u16 = 0x3A0;
pub const PMPCFG14: u16 = 0x3AE;
/// pmpaddr0..63 at 0x3B0..0x3EF (E1-T15 = 16, extended to 64 in E1-T27).
pub const PMPADDR0: u16 = 0x3B0;
pub const PMPADDR63: u16 = 0x3EF;
pub const MVENDORID: u16 = 0xF11;
pub const MARCHID: u16 = 0xF12;
pub const MIMPID: u16 = 0xF13;
pub const MHARTID: u16 = 0xF14;
/// Zicntr counters (E1-T14). M-mode backing `mcycle`/`minstret` are writable; the unprivileged
/// `cycle`/`time`/`instret` are read-only shadows gated by `mcounteren`/`scounteren`.
pub const MCYCLE: u16 = 0xB00;
pub const MINSTRET: u16 = 0xB02;
pub const MCOUNTEREN: u16 = 0x306;
pub const SCOUNTEREN: u16 = 0x106;
pub const CYCLE: u16 = 0xC00;
pub const TIME: u16 = 0xC01;
pub const INSTRET: u16 = 0xC02;
/// `mcounteren`/`scounteren` writable bits: CY(0)/TM(1)/IR(2). HPM bits 3..31 are read-only 0
/// until hardware performance monitors exist, so the corresponding hpmcounter reads always trap
/// from S/U (their counteren bit can never be set).
const COUNTEREN_WMASK: u64 = 0b111;
/// [`Csrs`] per-instruction counter-write suppression bits (E1-T14).
const WROTE_MCYCLE: u8 = 1 << 0;
const WROTE_MINSTRET: u8 = 1 << 1;
/// Test-only probe CSR with an observable read/write hook (side-effect suppression tests).
pub const PROBE: u16 = 0x7C0; // custom M-mode read/write space

/// Privilege mode (§1.2). The hart resets into machine mode.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Default)]
#[repr(u8)]
pub enum Priv {
    U = 0,
    S = 1,
    /// The reset privilege mode.
    #[default]
    M = 3,
}

/// The Zicsr operation, once the source operand is resolved to a value.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CsrOp {
    /// CSRRW/CSRRWI — replace.
    Write,
    /// CSRRS/CSRRSI — set bits.
    Set,
    /// CSRRC/CSRRCI — clear bits.
    Clear,
}

// ── mstatus field bits (Privileged §3.1.6, RV64) ───────────────────────────────
const M_SIE: u64 = 1 << 1;
const M_MIE: u64 = 1 << 3;
const M_SPIE: u64 = 1 << 5;
const M_MPIE: u64 = 1 << 7;
const M_SPP: u64 = 1 << 8;
const M_MPP: u64 = 0b11 << 11;
const M_FS: u64 = 0b11 << 13;
const M_MPRV: u64 = 1 << 17;
const M_SUM: u64 = 1 << 18;
const M_MXR: u64 = 1 << 19;
const M_TVM: u64 = 1 << 20;
const M_TW: u64 = 1 << 21;
const M_TSR: u64 = 1 << 22;
const M_UXL: u64 = 0b11 << 32;
const M_SXL: u64 = 0b11 << 34;
const M_SD: u64 = 1 << 63;

/// Software-writable `mstatus` bits (everything else is WPRI/read-only). `UXL`/`SXL` are
/// hardwired 0b10 and `SD` is read-only-computed, so they are excluded here and re-derived
/// in [`legalize_mstatus`].
const MSTATUS_WMASK: u64 = M_SIE
    | M_MIE
    | M_SPIE
    | M_MPIE
    | M_SPP
    | M_MPP
    | M_FS
    | M_MPRV
    | M_SUM
    | M_MXR
    | M_TVM
    | M_TW
    | M_TSR;

/// Bits visible when *reading* `sstatus` (§4.1.1): the S-subset of `mstatus` + read-only
/// UXL and SD.
const SSTATUS_RMASK: u64 = M_SIE | M_SPIE | M_SPP | M_FS | M_SUM | M_MXR | M_UXL | M_SD;
/// Bits a write *through* `sstatus` may change (never the M-level bits).
const SSTATUS_WMASK: u64 = M_SIE | M_SPIE | M_SPP | M_FS | M_SUM | M_MXR;
/// S-visible interrupt-enable/-pending bits (SSIE/STIE/SEIE at 1/5/9).
const SIE_SIP_SMASK: u64 = (1 << 1) | (1 << 5) | (1 << 9);
/// SSIP alone — the sole `sip` bit software may write through the S-view (Priv §4.1.3).
const SIP_SSIP: u64 = 1 << 1;

// ── mip/mie interrupt bit positions (Priv §3.1.9) ──────────────────────────────
const IP_SSI: u64 = 1 << 1; // supervisor software
const IP_MSI: u64 = 1 << 3; // machine software
const IP_STI: u64 = 1 << 5; // supervisor timer
const IP_MTI: u64 = 1 << 7; // machine timer
const IP_SEI: u64 = 1 << 9; // supervisor external
const IP_MEI: u64 = 1 << 11; // machine external
/// All six implemented interrupt-enable bits — `mie` is fully writable over these (WARL: the
/// reserved bits read 0).
const MIE_WMASK: u64 = IP_SSI | IP_MSI | IP_STI | IP_MTI | IP_SEI | IP_MEI;
/// `mip` bits SOFTWARE may write from M-mode: only the S-mode pending bits. MSIP/MTIP/MEIP are
/// read-only to software — the CLINT (T12) and PLIC (T13) drive them via [`Csrs::set_mip_bit`].
const MIP_SW_WMASK: u64 = IP_SSI | IP_STI | IP_SEI;
/// `mideleg` writable bits: only S-mode interrupts can be delegated (the M-interrupt bits are
/// read-only 0 — a machine interrupt always targets M).
const MIDELEG_WMASK: u64 = IP_SSI | IP_STI | IP_SEI;
/// `medeleg` writable bits: the implementable exception causes {0..=9, 12, 13, 15}. Cause 11
/// (ecall-from-M) is hardwired 0 — an M trap is never delegated downward — as are the reserved
/// causes 10/14. (Matches Spike's delegable set.)
const MEDELEG_WMASK: u64 = 0x3FF | (1 << 12) | (1 << 13) | (1 << 15);
/// Interrupt priority, highest first: MEI > MSI > MTI > SEI > SSI > STI (Priv §3.1.9).
const INT_PRIORITY: [u64; 6] = [11, 3, 7, 9, 1, 5];

// ── Dense WARL store (perf overhaul) ────────────────────────────────────────────
// Every CSR whose value lives in the generic WARL store gets a fixed slot, so a read is one load
// at a constant offset instead of a linear scan of an insertion-ordered `(addr, value)` list (the
// old layout — `satp` alone was scanned twice per translated memory access, `mip` twice per
// `set_mip_bit`, five times per block boundary). The set is exactly the addresses that can reach
// the store: trap delivery (mepc/mtval, sepc/scause/stval), the `sie`/`sip`/`mip`/`satp` arms of
// `write_raw`, plus every `meta`-accepted address that `write_raw` does not route to a dedicated
// field. Slots are numbered in ASCENDING address order, so walking the present slots in index
// order IS the canonical (address-sorted) snapshot order.
const W_STVEC: usize = 0;
const W_SCOUNTEREN: usize = 1;
const W_SSCRATCH: usize = 2;
const W_SEPC: usize = 3;
const W_SCAUSE: usize = 4;
const W_STVAL: usize = 5;
const W_SATP: usize = 6;
const W_MEDELEG: usize = 7;
const W_MIDELEG: usize = 8;
const W_MIE: usize = 9;
const W_MTVEC: usize = 10;
const W_MCOUNTEREN: usize = 11;
const W_MSCRATCH: usize = 12;
const W_MEPC: usize = 13;
const W_MTVAL: usize = 14;
const W_MIP: usize = 15;
const W_MNSTATUS: usize = 16;
const W_TINFO: usize = 17;
/// Number of dense WARL slots.
const WARL_SLOTS: usize = 18;
/// Slot → CSR address (strictly ascending; checked at compile time below).
const WARL_ADDRS: [u16; WARL_SLOTS] = [
    STVEC, SCOUNTEREN, SSCRATCH, SEPC, SCAUSE, STVAL, SATP, MEDELEG, MIDELEG, MIE, MTVEC,
    MCOUNTEREN, MSCRATCH, MEPC, MTVAL, MIP, MNSTATUS, TINFO,
];

/// CSR address → dense WARL slot, or `None` for an address with no slot (such an address can only
/// enter the store through a snapshot table; it is then kept in [`WarlStore::extra`]).
#[inline]
const fn warl_slot(addr: u16) -> Option<usize> {
    Some(match addr {
        STVEC => W_STVEC,
        SCOUNTEREN => W_SCOUNTEREN,
        SSCRATCH => W_SSCRATCH,
        SEPC => W_SEPC,
        SCAUSE => W_SCAUSE,
        STVAL => W_STVAL,
        SATP => W_SATP,
        MEDELEG => W_MEDELEG,
        MIDELEG => W_MIDELEG,
        MIE => W_MIE,
        MTVEC => W_MTVEC,
        MCOUNTEREN => W_MCOUNTEREN,
        MSCRATCH => W_MSCRATCH,
        MEPC => W_MEPC,
        MTVAL => W_MTVAL,
        MIP => W_MIP,
        MNSTATUS => W_MNSTATUS,
        TINFO => W_TINFO,
        _ => return None,
    })
}

// The slot table and the address map must be exact inverses, in ascending address order, and fit
// the `present` bitmap — otherwise the snapshot order (and the byte layout) would silently change.
const _: () = {
    assert!(WARL_SLOTS <= 32);
    let mut i = 0;
    while i < WARL_SLOTS {
        assert!(matches!(warl_slot(WARL_ADDRS[i]), Some(s) if s == i));
        if i > 0 {
            assert!(WARL_ADDRS[i - 1] < WARL_ADDRS[i]);
        }
        i += 1;
    }
};

/// The generic WARL CSR store: a dense value array plus a "was ever written" bitmap.
///
/// Snapshot contract (unchanged from the old `Vec<(u16, u64)>` layout): the table holds exactly the
/// CSRs that were ever written (a write of 0 still creates the entry), emitted sorted by address.
/// Invariant: `vals[i] == 0` whenever slot `i` is not present, so a read never consults `present`.
#[derive(Debug, Clone, PartialEq, Eq)]
struct WarlStore {
    vals: [u64; WARL_SLOTS],
    /// Bit `i` set ⇔ slot `i` was written (it appears in the snapshot table).
    present: u32,
    /// Cold overflow, reachable ONLY from a snapshot table: entries whose address has no slot, and
    /// repeated addresses after the first occurrence (the old list served the FIRST occurrence and
    /// kept the rest verbatim). Kept in table order so re-serialization stays byte-identical. Empty
    /// for every table this emulator writes.
    extra: Vec<(u16, u64)>,
}

impl WarlStore {
    const fn new() -> Self {
        Self {
            vals: [0; WARL_SLOTS],
            present: 0,
            extra: Vec::new(),
        }
    }

    #[inline(always)]
    const fn slot(&self, i: usize) -> u64 {
        self.vals[i]
    }

    #[inline(always)]
    fn set_slot(&mut self, i: usize, v: u64) {
        self.vals[i] = v;
        self.present |= 1 << i;
    }

    /// Read the store for `addr` (0 if never written).
    #[inline]
    fn get(&self, addr: u16) -> u64 {
        match warl_slot(addr) {
            Some(i) => self.vals[i],
            None => self
                .extra
                .iter()
                .find(|(a, _)| *a == addr)
                .map_or(0, |(_, v)| *v),
        }
    }

    /// Write the store for `addr`.
    #[inline]
    fn set(&mut self, addr: u16, v: u64) {
        match warl_slot(addr) {
            Some(i) => self.set_slot(i, v),
            None => match self.extra.iter_mut().find(|(a, _)| *a == addr) {
                Some(e) => e.1 = v,
                None => self.extra.push((addr, v)),
            },
        }
    }

    /// Append one `(addr, value)` entry of a snapshot table, in table order. The first occurrence
    /// of a slotted address fills the slot (that is the entry reads and writes act on); anything
    /// else is preserved verbatim in `extra`.
    fn push_parsed(&mut self, addr: u16, v: u64) {
        match warl_slot(addr) {
            Some(i) if self.present & (1 << i) == 0 => self.set_slot(i, v),
            _ => self.extra.push((addr, v)),
        }
    }

    /// Emit the canonical table: count, then `(addr, value)` pairs sorted by address — byte-for-byte
    /// what the old `clone + stable sort_by_key` of the insertion-ordered list produced.
    fn snapshot_bytes(&self, out: &mut Vec<u8>) {
        let count = self.present.count_ones() as usize + self.extra.len();
        out.extend_from_slice(&(count as u32).to_le_bytes());
        let mut emit = |a: u16, v: u64| {
            out.extend_from_slice(&a.to_le_bytes());
            out.extend_from_slice(&v.to_le_bytes());
        };
        if self.extra.is_empty() {
            for (i, &a) in WARL_ADDRS.iter().enumerate() {
                if self.present & (1 << i) != 0 {
                    emit(a, self.vals[i]);
                }
            }
            return;
        }
        // Cold (snapshot-restored oddities only): the slotted entry was its address's FIRST
        // occurrence, so it precedes that address's `extra` duplicates; a stable sort over
        // `slots ++ extra` reproduces the old stable sort of the original list exactly.
        let mut all: Vec<(u16, u64)> = WARL_ADDRS
            .iter()
            .enumerate()
            .filter(|(i, _)| self.present & (1 << i) != 0)
            .map(|(i, &a)| (a, self.vals[i]))
            .chain(self.extra.iter().copied())
            .collect();
        all.sort_by_key(|(a, _)| *a);
        for (a, v) in all {
            emit(a, v);
        }
    }
}

/// Legalize a candidate `mstatus` value: keep only writable bits, force `MPP=0b10` (reserved)
/// to `U`, hardwire `UXL`/`SXL`=0b10 (RV64), and recompute the read-only `SD` from `FS`.
const fn legalize_mstatus(v: u64) -> u64 {
    let mut s = v & MSTATUS_WMASK;
    if s & M_MPP == (0b10 << 11) {
        s &= !M_MPP; // reserved MPP=0b10 → U (documented WARL choice)
    }
    s |= (M_UXL & (0b10 << 32)) | (M_SXL & (0b10 << 34)); // UXL = SXL = 2 (64-bit), hardwired
    if s & M_FS == M_FS {
        s |= M_SD; // SD = (FS == Dirty)  [| VS | XS, none yet]
    }
    s
}

/// The reset-defined + Zicsr CSR file. Hardwired identification/`misa` are accessors; the
/// writable M/S CSRs live in a dense WARL store (`mstatus`/`mcause` kept as fields for the
/// E1-T01 reset assertions). `PROBE` carries read/write counters so suppression is testable.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Csrs {
    pub mode: Priv,
    /// Machine status; MIE(3)=0, MPRV(17)=0 at reset (whole register resets to 0).
    pub mstatus: u64,
    /// Machine trap cause; resets to 0.
    pub mcause: u64,
    /// Floating-point accrued exception flags `fflags` (5 bits: NV/DZ/OF/UF/NX). Sticky —
    /// set by FP ops, cleared only by an explicit CSR write (E1-T06).
    pub fflags: u8,
    /// Floating-point dynamic rounding mode `frm` (3 bits).
    pub frm: u8,
    /// WARL storage for the other writable CSRs (mepc, mtvec, mie, satp, …): O(1) dense slots.
    warl: WarlStore,
    /// Zicntr (E1-T14): `mcycle`/`minstret` — writable 64-bit M-CSRs incremented once per
    /// retired instruction; `cycle`/`instret` are read-only shadows of these.
    mcycle: u64,
    minstret: u64,
    /// Per-instruction suppression bits ([`WROTE_MCYCLE`] | [`WROTE_MINSTRET`]): set when THIS
    /// instruction wrote mcycle/minstret, so its own retirement does not also increment that
    /// counter (Spike: the written value stands). Armed (cleared) at each step start and consumed
    /// by `retire_tick`. One byte so the per-instruction arm is a single store and the common
    /// retire is one test; serialized as the two original bools.
    counter_writes: u8,
    /// Shadow of the CLINT `mtime` for the unprivileged `time` counter — the machine refreshes
    /// it each instruction boundary (there is no `mtime` CSR; `time` is a window onto the CLINT).
    time: u64,
    /// Physical Memory Protection unit (E1-T15): 16 entries checked on every physical access.
    pub pmp: crate::pmp::Pmp,
    /// Sv48 support (E1-T18): a hardware CONFIG bit (not resettable architectural state — the
    /// hart either implements Sv48 or it doesn't). When false, a `satp` write with MODE=Sv48 (9)
    /// is an all-or-nothing no-op (the Linux `set_satp_mode` probe reads back the old value).
    /// Preserved across `Hart::reset`.
    pub sv48: bool,
    /// Whether Sv57 (5-level paging, satp MODE=10) is supported (E1-T28). Like `sv48`, a WARL
    /// switch: when false a `satp` write with MODE=10 is a no-op. Preserved across `Hart::reset`.
    pub sv57: bool,
    /// Observable hooks for the test PROBE CSR.
    pub probe_reads: u64,
    pub probe_value: u64,
    /// Debug triggers (E1-T29): a single mcontrol trigger (index 0). `trig_tdata1` is the
    /// mcontrol register (type in [63:60], mode/timing/match/action + execute/store/load bits);
    /// `trig_tdata2` the compare value; `trig_tcontrol.mte` (bit 3) gates M-mode firing.
    /// `triggers_armed` is a fast "any trigger could fire?" flag so the fetch/mem hot path pays
    /// nothing when no trigger is configured to match.
    trig_select: u64,
    trig_tdata1: u64,
    trig_tdata2: u64,
    trig_tcontrol: u64,
    triggers_armed: bool,
}

/// Which access kind is checking a trigger (mcontrol execute/store/load bits).
#[derive(Clone, Copy, PartialEq, Eq)]
pub enum TrigKind {
    Execute,
    Load,
    Store,
}

/// Static metadata for an implemented CSR, derived per address.
struct Meta {
    min_priv: Priv,
    read_only: bool,
    /// WARL legalization mask applied to writes (`!0` = fully writable, `0` = hardwired).
    warl_mask: u64,
}

impl Csrs {
    /// The spec reset state (§3.4): M-mode, `mstatus = 0`, `mcause = 0`, empty WARL store.
    pub fn at_reset() -> Self {
        Self {
            mode: Priv::M,
            mstatus: 0,
            mcause: 0,
            fflags: 0,
            frm: 0,
            warl: WarlStore::new(),
            mcycle: 0,
            minstret: 0,
            counter_writes: 0,
            time: 0,
            pmp: crate::pmp::Pmp::default(),
            sv48: true, // Sv48 supported by default; a Machine/harness may gate it off.
            sv57: true, // Sv57 supported by default (E1-T28).
            probe_reads: 0,
            probe_value: 0,
            // Triggers reset disabled: tdata1 reads back type=2 (mcontrol) with no match bits.
            trig_select: 0,
            trig_tdata1: 2 << 60,
            trig_tdata2: 0,
            trig_tcontrol: 0,
            triggers_armed: false,
        }
    }

    /// mcontrol type field [63:60] == 2, i.e. `tdata1` currently holds an mcontrol trigger.
    const MCONTROL_TYPE: u64 = 2;

    /// Recompute the fast-path "a trigger could fire" flag: true iff the mcontrol trigger is
    /// type-2 with at least one of execute/store/load selected. Called after any tdata write.
    fn recompute_triggers_armed(&mut self) {
        let td1 = self.trig_tdata1;
        self.triggers_armed = (td1 >> 60) & 0xF == Self::MCONTROL_TYPE && (td1 & 0b111) != 0;
    }

    /// True iff no trigger is configured to fire — the hot-path guard the hart checks before
    /// evaluating any trigger. When this is true, `trigger_fires` is never called.
    #[inline(always)]
    pub const fn triggers_idle(&self) -> bool {
        !self.triggers_armed
    }

    /// Does the configured mcontrol trigger fire for an access of `kind` to `addr` in the
    /// CURRENT privilege mode? (Priv §5, Debug spec mcontrol.) Only the equal-match (`match==0`),
    /// action==0 (breakpoint-exception) mcontrol is modeled — what rv64mi-p-breakpoint uses.
    /// M-mode firing additionally requires `tcontrol.mte` (bit 3).
    pub fn trigger_fires(&self, addr: u64, kind: TrigKind) -> bool {
        let td1 = self.trig_tdata1;
        if (td1 >> 60) & 0xF != Self::MCONTROL_TYPE {
            return false;
        }
        // execute=bit2, store=bit1, load=bit0.
        let kind_selected = match kind {
            TrigKind::Execute => td1 & 0b100 != 0,
            TrigKind::Store => td1 & 0b010 != 0,
            TrigKind::Load => td1 & 0b001 != 0,
        };
        if !kind_selected {
            return false;
        }
        // Mode gate: m=bit6, s=bit4, u=bit3. M-mode also needs tcontrol.mte (bit 3).
        let mode_ok = match self.mode {
            Priv::M => td1 & (1 << 6) != 0 && self.trig_tcontrol & (1 << 3) != 0,
            Priv::S => td1 & (1 << 4) != 0,
            Priv::U => td1 & (1 << 3) != 0,
        };
        if !mode_ok {
            return false;
        }
        // action ([15:12]) == 0 (breakpoint exception) and match ([10:7]) == 0 (equal).
        if (td1 >> 12) & 0xF != 0 || (td1 >> 7) & 0xF != 0 {
            return false;
        }
        self.trig_tdata2 == addr
    }

    /// Zicntr (E1-T14): clear the per-instruction counter-write suppression flags. Called at the
    /// START of each step so only writes performed DURING this instruction's execute suppress its
    /// own retirement increment (a stale flag from a direct/host-side write can't leak into a run).
    #[inline(always)]
    pub fn arm_counters(&mut self) {
        self.counter_writes = 0;
    }

    /// Zicntr (E1-T14/E4-T31): advance the retired-instruction counters by `retired`. The JIT may
    /// retire a CSR-free block at once, so this is the bulk-equivalent of repeated
    /// [`Self::retire_tick`] calls. If the current instruction wrote a counter, its write stands and
    /// suppresses the corresponding increment exactly as on the one-instruction interpreter path.
    #[inline(always)]
    pub(crate) fn retire_span(&mut self, retired: u64) {
        let w = self.counter_writes;
        if w & WROTE_MCYCLE == 0 {
            self.mcycle = self.mcycle.wrapping_add(retired);
        }
        if w & WROTE_MINSTRET == 0 {
            self.minstret = self.minstret.wrapping_add(retired);
        }
    }

    /// Zicntr (E1-T14): advance the counters after one successfully retired instruction. A `csrr`
    /// observes the pre-retire count; a `csrw` to a counter suppresses that counter's own tick.
    #[inline(always)]
    pub fn retire_tick(&mut self) {
        self.retire_span(1);
    }

    /// Refresh the `time` counter's window onto the CLINT `mtime` (E1-T14). The machine calls
    /// this each instruction boundary from the CLINT state, so `time` reads track `mtime`.
    #[inline(always)]
    pub fn set_time(&mut self, mtime: u64) {
        self.time = mtime;
    }

    /// The effective privilege for a DATA access (load/store/AMO): with `mstatus.MPRV=1` the
    /// access is checked as though from `MPP` instead of the current mode (Priv §3.1.6.3).
    /// Instruction FETCHES always use the true current mode (MPRV never affects them).
    pub fn data_priv(&self) -> Priv {
        if self.mstatus & M_MPRV != 0 {
            match (self.mstatus >> 11) & 0b11 {
                0b11 => Priv::M,
                0b01 => Priv::S,
                _ => Priv::U,
            }
        } else {
            self.mode
        }
    }

    /// PMP permission check (E1-T15): is a `len`-byte `access` at `addr` by `mode` allowed?
    /// Fast path: with no armed entry, an M access passes and an S/U access is denied (≥1 entry
    /// is implemented, so an unmatched S/U access fails per §3.7).
    pub fn pmp_ok(&self, addr: u64, len: u64, access: crate::pmp::PmpAccess, mode: Priv) -> bool {
        if !self.pmp.any_armed() {
            return matches!(mode, Priv::M);
        }
        self.pmp.check(addr, len, access, mode)
    }

    // ── hardwired identification (read-only) ────────────────────────────────
    pub const fn misa(&self) -> u64 {
        MISA_RV64GC_SU
    }
    pub const fn mhartid(&self) -> u64 {
        0
    }
    pub const fn mvendorid(&self) -> u64 {
        0
    }
    pub const fn marchid(&self) -> u64 {
        0
    }
    pub const fn mimpid(&self) -> u64 {
        0
    }
    pub const fn mie(&self) -> bool {
        self.mstatus & (1 << 3) != 0
    }
    pub const fn mprv(&self) -> bool {
        self.mstatus & (1 << 17) != 0
    }

    // ── mstatus.FS floating-point state (bits 14:13), SD = bit 63 ────────────
    /// The FS field: 0=Off, 1=Initial, 2=Clean, 3=Dirty.
    pub const fn fs(&self) -> u8 {
        ((self.mstatus >> 13) & 0b11) as u8
    }
    /// True when FP is disabled (FS=Off) — every FP instruction and fcsr access traps.
    pub const fn fp_off(&self) -> bool {
        self.fs() == 0
    }
    /// Mark the FP state Dirty (FS=3) and set the SD summary bit (63). Called by every
    /// executed FP instruction and by any fflags/frm/fcsr write.
    pub fn mark_fp_dirty(&mut self) {
        self.mstatus = (self.mstatus & !(0b11 << 13)) | (0b11 << 13) | (1 << 63);
    }
    /// Accumulate FP exception flags into the sticky `fflags` (the flags are OR-accrued and
    /// only cleared by an explicit CSR write).
    pub fn accrue_fflags(&mut self, f: u8) {
        self.fflags |= f & 0x1F;
    }
    /// Resolve an instruction `rm` field against the dynamic `frm` (`rm=7` = DYN). Returns
    /// `None` for a reserved mode (static 5/6, or DYN with a reserved `frm`) → illegal.
    pub const fn resolve_rm(&self, rm: u8) -> Option<crate::softfloat::RoundMode> {
        let eff = if rm == 0b111 { self.frm } else { rm };
        crate::softfloat::RoundMode::from_bits(eff)
    }

    // ── privilege / mstatus state machine (E1-T09, Privileged §3.1.6, §3.3.2) ──
    pub const fn tsr(&self) -> bool {
        self.mstatus & M_TSR != 0
    }
    pub const fn tw(&self) -> bool {
        self.mstatus & M_TW != 0
    }
    pub const fn tvm(&self) -> bool {
        self.mstatus & M_TVM != 0
    }
    /// mstatus.SUM (§4.3): permit S-mode data access to U=1 pages (E1-T16).
    pub const fn sum(&self) -> bool {
        self.mstatus & M_SUM != 0
    }
    /// mstatus.MXR (§4.3): make execute-only (X, R=0) pages readable by loads (E1-T16).
    pub const fn mxr(&self) -> bool {
        self.mstatus & M_MXR != 0
    }
    /// The raw `satp` value (§4.1.11): MODE[63:60], ASID[59:44], PPN[43:0]. Stored WARL. Read on
    /// every translated access, so it is a single load from a fixed slot.
    #[inline(always)]
    pub fn satp(&self) -> u64 {
        self.warl.slot(W_SATP)
    }

    /// Trap delivery into M-mode's mstatus stack: `MPIE←MIE, MIE←0, MPP←prior`, mode←M.
    /// (mepc/mcause/mtval and the mtvec jump are wired in E1-T10.)
    pub fn trap_to_m(&mut self, prior: Priv) {
        let mie = (self.mstatus >> 3) & 1;
        let mut s = self.mstatus & !(M_MPIE | M_MIE | M_MPP);
        s |= mie << 7; // MPIE = MIE ; MIE = 0
        s |= (prior as u64) << 11; // MPP = prior mode
        self.mstatus = legalize_mstatus(s);
        self.mode = Priv::M;
    }

    /// Trap delivery into S-mode: `SPIE←SIE, SIE←0, SPP←(from S?1:0)`, mode←S.
    pub fn trap_to_s(&mut self, prior: Priv) {
        let sie = (self.mstatus >> 1) & 1;
        let mut s = self.mstatus & !(M_SPIE | M_SIE | M_SPP);
        s |= sie << 5; // SPIE = SIE ; SIE = 0
        if matches!(prior, Priv::S) {
            s |= M_SPP; // SPP = 1 from S, 0 from U
        }
        self.mstatus = legalize_mstatus(s);
        self.mode = Priv::S;
    }

    /// MRET: `MIE←MPIE, MPIE←1, mode←MPP, MPP←U`, and `MPRV←0` if the new mode ≠ M.
    pub fn mret(&mut self) {
        let mpie = (self.mstatus >> 7) & 1;
        let new_mode = match (self.mstatus >> 11) & 0b11 {
            3 => Priv::M,
            1 => Priv::S,
            _ => Priv::U,
        };
        let mut s = self.mstatus;
        s = (s & !M_MIE) | (mpie << 3); // MIE = MPIE
        s |= M_MPIE; // MPIE = 1
        s &= !M_MPP; // MPP = U (lowest supported)
        if !matches!(new_mode, Priv::M) {
            s &= !M_MPRV; // MPRV cleared when returning below M
        }
        self.mstatus = legalize_mstatus(s);
        self.mode = new_mode;
    }

    /// SRET: `SIE←SPIE, SPIE←1, mode←SPP, SPP←U`, and `MPRV←0` if the new mode ≠ M.
    pub fn sret(&mut self) {
        let spie = (self.mstatus >> 5) & 1;
        let new_mode = if self.mstatus & M_SPP != 0 {
            Priv::S
        } else {
            Priv::U
        };
        let mut s = self.mstatus;
        s = (s & !M_SIE) | (spie << 1); // SIE = SPIE
        s |= M_SPIE; // SPIE = 1
        s &= !M_SPP; // SPP = U
        if !matches!(new_mode, Priv::M) {
            s &= !M_MPRV;
        }
        self.mstatus = legalize_mstatus(s);
        self.mode = new_mode;
    }

    /// Deliver a synchronous exception into M-mode (E1-T10): record mepc/mcause/mtval and
    /// push the mstatus interrupt stack (`trap_to_m`). `cause` is the raw mcause value —
    /// bit 63 (Interrupt) is 0 for every synchronous exception. mepc keeps the faulting pc
    /// with only bit 0 forced to zero (IALIGN=16 with the C extension). Delegation to S-mode
    /// (medeleg) lands in E1-T11; until then every trap is taken in M. Returns nothing — the
    /// caller reads [`Self::mtvec_base`] for the handler entry PC.
    pub fn deliver_trap_m(&mut self, epc: u64, cause: u64, tval: u64) {
        let prior = self.mode;
        self.warl.set_slot(W_MEPC, epc & !1);
        self.mcause = cause;
        self.warl.set_slot(W_MTVAL, tval);
        self.trap_to_m(prior);
    }

    /// The mtvec BASE address (bits [63:2]); the low two bits are the MODE field, never part
    /// of the target address. Synchronous traps ALWAYS enter here regardless of MODE — the
    /// vectored offset (BASE + 4×cause) applies to interrupts only (Priv §3.1.7).
    pub fn mtvec_base(&self) -> u64 {
        self.warl.slot(W_MTVEC) & !0b11
    }

    /// Deliver a trap into S-mode (E1-T11): record sepc/scause/stval and push the S half of the
    /// mstatus stack (`trap_to_s`). Used for exceptions delegated by `medeleg` and interrupts
    /// delegated by `mideleg`. `cause` is the raw scause value (Interrupt bit 63 set for an
    /// interrupt). sepc keeps the faulting/next pc with bit 0 masked.
    pub fn deliver_trap_s(&mut self, epc: u64, cause: u64, tval: u64) {
        let prior = self.mode;
        self.warl.set_slot(W_SEPC, epc & !1);
        self.warl.set_slot(W_SCAUSE, cause);
        self.warl.set_slot(W_STVAL, tval);
        self.trap_to_s(prior);
    }

    /// The stvec BASE address (bits [63:2]); MODE lives in the low two bits.
    pub fn stvec_base(&self) -> u64 {
        self.warl.slot(W_STVEC) & !0b11
    }

    /// The M-mode handler entry for a trap: BASE always, plus — for an INTERRUPT when mtvec
    /// MODE == 1 (Vectored) — the `BASE + 4×cause` offset. Synchronous traps ignore MODE.
    pub fn m_handler_entry(&self, cause_num: u64, is_interrupt: bool) -> u64 {
        let t = self.warl.slot(W_MTVEC);
        let base = t & !0b11;
        if is_interrupt && (t & 0b11) == 1 {
            base.wrapping_add(4 * cause_num)
        } else {
            base
        }
    }
    /// The S-mode handler entry, mirroring [`Self::m_handler_entry`] for stvec.
    pub fn s_handler_entry(&self, cause_num: u64, is_interrupt: bool) -> u64 {
        let t = self.warl.slot(W_STVEC);
        let base = t & !0b11;
        if is_interrupt && (t & 0b11) == 1 {
            base.wrapping_add(4 * cause_num)
        } else {
            base
        }
    }

    /// Should a trap with mcause number `cause_num` be delegated to S-mode given the current
    /// privilege (E1-T11)? Delegated ONLY when the deleg bit is set AND we are running below M
    /// (S or U) — a trap taken while executing in M always stays in M, never downward (§3.1.8).
    pub fn delegates_to_s(&self, cause_num: u64, is_interrupt: bool) -> bool {
        if matches!(self.mode, Priv::M) {
            return false;
        }
        let deleg = if is_interrupt {
            self.warl.slot(W_MIDELEG)
        } else {
            self.warl.slot(W_MEDELEG)
        };
        deleg & (1 << cause_num) != 0
    }

    /// The highest-priority interrupt to take right now, or `None` (E1-T11). Returns the mcause
    /// value (Interrupt bit 63 set) and whether it targets S-mode. Considers pending&enabled
    /// (`mip & mie`), delegation (`mideleg`), the current privilege, and the global-enable rules
    /// (mstatus.MIE for M-targeted, mstatus.SIE for S-targeted). Priority: MEI>MSI>MTI>SEI>SSI>STI.
    /// An interrupt targeting mode x is taken when: current mode < x, OR (current == x AND xIE).
    /// M-targeted interrupts are never taken while in M with MIE=0, and never below-target masks
    /// a higher privilege's interrupt; a higher-priority interrupt that cannot be taken in the
    /// current mode is skipped so a takeable lower one can fire.
    /// E2-T20: is any interrupt pending AND enabled (`mip & mie != 0`)? A wakeup that could
    /// fire the moment global `xIE` opens — used by the WFI-deadlock watchdog. (Ignores the
    /// global `mstatus.xIE` gates: a WFI wakes on a pending+enabled line even with `xIE=0`.)
    #[inline]
    pub fn mip_and_mie_nonzero(&self) -> bool {
        (self.warl.slot(W_MIP) & self.warl.slot(W_MIE)) != 0
    }

    /// E2-T20 sweep fix: the raw `mie` bits, for gating WHICH armed wakeup sources are actually
    /// deliverable (an armed timer with MTIE=0 can never end a WFI loop).
    #[inline]
    pub fn mie_bits(&self) -> u64 {
        self.warl.slot(W_MIE)
    }

    ///
    /// Sampled at every block boundary, so the common nothing-pending case is two slot loads, an
    /// AND and a branch; the takeability rules then reduce to one mask so the priority walk only
    /// runs when some interrupt will actually be taken.
    #[inline]
    pub fn next_interrupt(&self) -> Option<(u64, bool)> {
        let pend = self.warl.slot(W_MIP) & self.warl.slot(W_MIE);
        if pend == 0 {
            return None;
        }
        self.next_pending_interrupt(pend)
    }

    /// [`Self::next_interrupt`] once `pend = mip & mie` is known to be nonzero. Takeability depends
    /// only on the line's target mode (`mideleg` bit) and the current mode/global enables, so it is
    /// a per-bit mask: the first `INT_PRIORITY` entry in `pend & takeable` is exactly the line the
    /// per-bit priority walk would pick.
    fn next_pending_interrupt(&self, pend: u64) -> Option<(u64, bool)> {
        let mideleg = self.warl.slot(W_MIDELEG);
        // (M-targeted takeable, S-targeted takeable) in the current mode:
        // - M-targeted: taken in S/U always (can't be masked from below); in M iff mstatus.MIE.
        // - S-targeted: taken in U always; in S iff mstatus.SIE; never while in M (M > S).
        let (m_ok, s_ok) = match self.mode {
            Priv::M => (self.mstatus & M_MIE != 0, false),
            Priv::S => (true, self.mstatus & M_SIE != 0),
            Priv::U => (true, true),
        };
        let mut takeable = 0;
        if m_ok {
            takeable |= pend & !mideleg;
        }
        if s_ok {
            takeable |= pend & mideleg;
        }
        if takeable == 0 {
            return None;
        }
        for &i in &INT_PRIORITY {
            if takeable & (1 << i) != 0 {
                return Some(((1u64 << 63) | i, mideleg & (1 << i) != 0));
            }
        }
        None
    }

    /// Device-facing (CLINT/PLIC, and tests until those land): set or clear a `mip` PENDING bit
    /// DIRECTLY, bypassing the software read-only masking. MSIP/MTIP/MEIP are software-read-only
    /// but hardware-driven — this is the hardware path.
    /// Branch-free: called several times per block boundary by the device-level syncs. Like any
    /// store write, it marks `mip` as written (it then appears in the snapshot table).
    #[inline(always)]
    pub fn set_mip_bit(&mut self, bit: u64, on: bool) {
        let v = self.warl.slot(W_MIP);
        self.warl
            .set_slot(W_MIP, (v & !(1 << bit)) | (u64::from(on) << bit));
    }

    /// `sstatus` is a masked read view of `mstatus` (S-visible bits only).
    pub const fn sstatus_read(&self) -> u64 {
        self.mstatus & SSTATUS_RMASK
    }
    /// A write through `sstatus` touches only the S-visible writable bits of `mstatus`.
    pub fn sstatus_write(&mut self, v: u64) {
        let merged = (self.mstatus & !SSTATUS_WMASK) | (v & SSTATUS_WMASK);
        self.mstatus = legalize_mstatus(merged);
    }
    /// The S-interrupt bits (SSIE/STIE/SEIE) currently visible through `sie`/`sip` — those in
    /// the S-subset that are *delegated* to S-mode by `mideleg` (Priv §4.1.3).
    fn s_int_mask(&self) -> u64 {
        SIE_SIP_SMASK & self.warl.slot(W_MIDELEG)
    }
    /// The `sip` bits that are software-*writable* through the S-view. Per Priv §4.1.3 only
    /// SSIP (bit 1) is writable via `sip`; STIP (bit 5) and SEIP (bit 9) are read-only in the
    /// `sip` view (they are driven by the timer / external controller and set through `mip`).
    /// So the sip *write* mask is SSIP-only, still gated on delegation. Reads, by contrast,
    /// expose every delegated S-pending bit — that path stays `s_int_mask()`. (`sie` differs:
    /// STIE/SEIE *are* writable there, so `sie` writes keep using `s_int_mask()`.)
    fn sip_write_mask(&self) -> u64 {
        SIP_SSIP & self.warl.slot(W_MIDELEG)
    }

    /// Metadata for an implemented CSR address, or `None` if unimplemented (→ illegal).
    /// Privilege is `addr[9:8]`; read-only is `addr[11:10]==0b11`.
    fn meta(addr: u16) -> Option<Meta> {
        let min_priv = match (addr >> 8) & 0b11 {
            0b00 => Priv::U,
            0b01 => Priv::S,
            _ => Priv::M,
        };
        let read_only = (addr >> 10) & 0b11 == 0b11;
        let warl_mask = match addr {
            MISA => 0, // hardwired WARL: writes ignored (reads return MISA_RV64GC_SU)
            // FP CSRs: fflags is 5 bits, frm is 3 bits, fcsr is the 8-bit {frm,fflags} pair.
            FFLAGS => 0x1F,
            FRM => 0x07,
            FCSR => 0xFF,
            // mepc: bit 0 is masked (WARL) — IALIGN=16 with the C extension means only bit 0
            // is forced to zero, not bits [1:0] (E1-T08). A write clears it; reads see it.
            MEPC | SEPC => !1,
            // mtvec/stvec MODE (bits [1:0]) is WARL: only Direct(0) and Vectored(1) are
            // legal; a written MODE ≥ 2 legalizes by clearing bit 1 (matches Spike's
            // `val & ~2`), so MODE ∈ {0,1} always reads back and BASE stays 4-byte aligned
            // (its low two bits ARE the MODE field). Synchronous traps ignore MODE (E1-T10).
            MTVEC | STVEC => !0b10,
            // Interrupt WARL masks (E1-T11): mie is writable over the six implemented bits;
            // mideleg only over the S-interrupt bits; medeleg over the implementable exception
            // causes (ecall-from-M / reserved excluded). mip's software-write masking is a
            // read-modify-write done in write_raw (device bits are read-only there), so its
            // mask here stays !0.
            MIE => MIE_WMASK,
            MIDELEG => MIDELEG_WMASK,
            MEDELEG => MEDELEG_WMASK,
            // Zicntr (E1-T14): mcycle/minstret are fully-writable 64-bit M-CSRs; mcounteren/
            // scounteren expose only CY/TM/IR (bits [2:0]) — HPM enable bits read-only 0.
            MCYCLE | MINSTRET => !0,
            MCOUNTEREN | SCOUNTEREN => COUNTEREN_WMASK,
            // PMP (E1-T15 = 16, E1-T27 = 64): the EVEN pmpcfg CSRs (pmpcfg0,2,…,14) and
            // pmpaddr0..63. The module does its own WARL legalization + lock enforcement in
            // write_raw, so the mask is !0. Odd pmpcfg CSRs fail the guard → `meta` returns None
            // → illegal instruction (RV64 has no odd pmpcfg).
            PMPCFG0..=PMPCFG14 if (addr - PMPCFG0).is_multiple_of(2) => !0,
            PMPADDR0..=PMPADDR63 => !0,
            MSTATUS | MCAUSE | MSCRATCH | MTVAL | MIP | SATP
            | MNSTATUS | PROBE
            // Debug triggers (E1-T29): tselect/tdata1/tdata2/tdata3/tcontrol legalize in
            // write_raw (mcontrol WARL + single-trigger clamp), so the mask here is !0.
            | TSELECT | TDATA1 | TDATA2 | TDATA3 | TCONTROL
            // S-mode CSRs (E1-T09): sstatus/sie/sip are masked *views* handled in
            // read_raw/write_raw; the mask here is !0 (the view logic does the masking).
            | SSTATUS | SIE | SIP | SSCRATCH | SCAUSE | STVAL => !0,
            TINFO => 0, // read-only trigger-type info (writes ignored)
            MVENDORID | MARCHID | MIMPID | MHARTID => 0, // RO const 0
            // Read-only user counters cycle/time/instret and hpm (0xC00–0xC1F): reads
            // return 0, writes trap (read_only by encoding).
            0xC00..=0xC1F => 0,
            _ => return None, // unimplemented
        };
        Some(Meta {
            min_priv,
            read_only,
            warl_mask,
        })
    }

    /// Unchecked raw read of a CSR (no privilege/side-effect logic) — for the hart's own use
    /// (reading mepc/sepc during MRET/SRET).
    pub fn read(&mut self, addr: u16) -> u64 {
        self.read_raw(addr)
    }

    /// E1-T30 diagnostic: current (mcounteren, scounteren, mode) for the illegal-trap logger.
    pub(crate) fn counteren_dbg(&self) -> (u64, u64, Priv) {
        (
            self.warl.slot(W_MCOUNTEREN),
            self.warl.slot(W_SCOUNTEREN),
            self.mode,
        )
    }

    /// E3-T12b: append EVERY architectural CSR field to a CPU-section payload, fixed-layout
    /// little-endian. Exhaustive by design — the determinism trace-diff refutes any omission. The
    /// WARL table is emitted in canonical (tag-sorted) order so the encoding is order-independent.
    pub(crate) fn snapshot_bytes(&self, out: &mut Vec<u8>) {
        out.push(self.mode as u8);
        out.extend_from_slice(&self.mstatus.to_le_bytes());
        out.extend_from_slice(&self.mcause.to_le_bytes());
        out.push(self.fflags);
        out.push(self.frm);
        self.warl.snapshot_bytes(out);
        out.extend_from_slice(&self.mcycle.to_le_bytes());
        out.extend_from_slice(&self.minstret.to_le_bytes());
        out.push(u8::from(self.counter_writes & WROTE_MCYCLE != 0));
        out.push(u8::from(self.counter_writes & WROTE_MINSTRET != 0));
        out.extend_from_slice(&self.time.to_le_bytes());
        self.pmp.snapshot_bytes(out);
        out.push(self.sv48 as u8);
        out.push(self.sv57 as u8);
        out.extend_from_slice(&self.probe_reads.to_le_bytes());
        out.extend_from_slice(&self.probe_value.to_le_bytes());
        out.extend_from_slice(&self.trig_select.to_le_bytes());
        out.extend_from_slice(&self.trig_tdata1.to_le_bytes());
        out.extend_from_slice(&self.trig_tdata2.to_le_bytes());
        out.extend_from_slice(&self.trig_tcontrol.to_le_bytes());
        out.push(self.triggers_armed as u8);
    }

    /// E3-T12b: parse a fresh `Csrs` from a CPU-section [`crate::resume::Reader`]. PURE — it builds a
    /// local (never mutates a live hart), so the caller commits only after the whole section parses,
    /// upholding all-or-nothing restore. `sv48`/`sv57` come from the payload (the `core_hash` guard
    /// already ensures the same build, so they match — carried for a complete round-trip).
    pub(crate) fn parse(
        r: &mut crate::resume::Reader,
    ) -> Result<Self, crate::resume::SnapshotError> {
        let err = || crate::resume::SnapshotError::BadComponentState {
            tag: crate::resume::section::CPU,
        };
        let mut c = Csrs::at_reset();
        c.mode = match r.u8()? {
            0 => Priv::U,
            1 => Priv::S,
            3 => Priv::M,
            _ => return Err(err()),
        };
        c.mstatus = r.u64()?;
        c.mcause = r.u64()?;
        c.fflags = r.u8()?;
        c.frm = r.u8()?;
        let n = r.u32()? as usize;
        // No with_capacity(n): a hostile count grows only as reads succeed (each entry is 10 bytes;
        // the bounds-checked reader errors once the section is exhausted), so it can't over-allocate.
        let mut warl = WarlStore::new();
        for _ in 0..n {
            let a = r.u16()?;
            let v = r.u64()?;
            warl.push_parsed(a, v);
        }
        c.warl = warl;
        c.mcycle = r.u64()?;
        c.minstret = r.u64()?;
        if r.bool()? {
            c.counter_writes |= WROTE_MCYCLE;
        }
        if r.bool()? {
            c.counter_writes |= WROTE_MINSTRET;
        }
        c.time = r.u64()?;
        c.pmp.restore_bytes(r)?;
        c.sv48 = r.bool()?;
        c.sv57 = r.bool()?;
        c.probe_reads = r.u64()?;
        c.probe_value = r.u64()?;
        c.trig_select = r.u64()?;
        c.trig_tdata1 = r.u64()?;
        c.trig_tdata2 = r.u64()?;
        c.trig_tcontrol = r.u64()?;
        c.triggers_armed = r.bool()?;
        Ok(c)
    }

    /// Raw read of an implemented CSR's current value (no privilege check). PROBE bumps its
    /// read counter — the observable hook for suppression tests.
    fn read_raw(&mut self, addr: u16) -> u64 {
        match addr {
            MISA => self.misa(),
            MHARTID => self.mhartid(),
            MVENDORID => self.mvendorid(),
            MARCHID => self.marchid(),
            MIMPID => self.mimpid(),
            MSTATUS => self.mstatus,
            MCAUSE => self.mcause,
            // S-mode views (E1-T09): sstatus/sie/sip expose the S-subset of mstatus/mie/mip.
            // Per Priv §4.1.3, an S-interrupt bit is visible/maskable via sie/sip ONLY when it
            // is delegated (mideleg bit set); undelegated bits are read-only zero.
            SSTATUS => self.sstatus_read(),
            SIE => self.warl.slot(W_MIE) & self.s_int_mask(),
            SIP => self.warl.slot(W_MIP) & self.s_int_mask(),
            // FP CSR aliasing: fcsr = frm[7:5] | fflags[4:0].
            FFLAGS => u64::from(self.fflags),
            FRM => u64::from(self.frm),
            FCSR => u64::from((self.frm << 5) | (self.fflags & 0x1F)),
            PROBE => {
                self.probe_reads += 1;
                self.probe_value
            }
            // Zicntr (E1-T14): the M-mode backing counters and their unprivileged shadows.
            MCYCLE | CYCLE => self.mcycle,
            MINSTRET | INSTRET => self.minstret,
            TIME => self.time,
            // PMP (E1-T15): pmpcfg0/2 pack 8 entries each; pmpaddr0..15 are per-entry.
            PMPCFG0..=PMPCFG14 if (addr - PMPCFG0).is_multiple_of(2) => {
                self.pmp.read_cfg((addr - PMPCFG0) as usize)
            }
            PMPADDR0..=PMPADDR63 => self.pmp.read_addr((addr - PMPADDR0) as usize),
            // hpmcounter3..31 (0xC03..) are unimplemented HPMs → read 0.
            0xC00..=0xC1F => 0,
            // Debug triggers (E1-T29). tinfo advertises type-2 (mcontrol) support (bit 2).
            TSELECT => self.trig_select,
            TDATA1 => self.trig_tdata1,
            TDATA2 => self.trig_tdata2,
            TDATA3 => 0,
            TINFO => 1 << (Self::MCONTROL_TYPE),
            TCONTROL => self.trig_tcontrol,
            other => self.warl.get(other),
        }
    }

    /// Raw write of a legalized value (no checks; caller applied the WARL mask).
    fn write_raw(&mut self, addr: u16, v: u64) {
        match addr {
            MSTATUS => self.mstatus = legalize_mstatus(v),
            MCAUSE => self.mcause = v,
            // S-mode views (E1-T09): route through the masked mstatus/mie/mip. `sie` writes the
            // delegated S-interrupt-enable bits (SIE_SIP_SMASK & mideleg); `sip` writes ONLY the
            // delegated SSIP (STIP/SEIP are read-only in the sip view). Undelegated bits are
            // read-only zero and a write leaves mie/mip untouched.
            SSTATUS => self.sstatus_write(v),
            SIE => {
                let m = self.s_int_mask();
                let new = (self.warl.slot(W_MIE) & !m) | (v & m);
                self.warl.set_slot(W_MIE, new);
            }
            SIP => {
                let m = self.sip_write_mask();
                let new = (self.warl.slot(W_MIP) & !m) | (v & m);
                self.warl.set_slot(W_MIP, new);
            }
            // A raw `csrw mip` from M writes only the S-mode pending bits (SSIP/STIP/SEIP);
            // MSIP/MTIP/MEIP are read-only to software (device-driven via set_mip_bit). RMW so
            // the device-driven bits survive (E1-T11).
            MIP => {
                let new = (self.warl.slot(W_MIP) & !MIP_SW_WMASK) | (v & MIP_SW_WMASK);
                self.warl.set_slot(W_MIP, new);
            }
            // FP CSR writes (value already WARL-masked). Writing any of the three marks FP
            // state Dirty. fcsr splits into {frm, fflags}.
            FFLAGS => {
                self.fflags = (v as u8) & 0x1F;
                self.mark_fp_dirty();
            }
            FRM => {
                self.frm = (v as u8) & 0x07;
                self.mark_fp_dirty();
            }
            FCSR => {
                self.fflags = (v as u8) & 0x1F;
                self.frm = ((v >> 5) as u8) & 0x07;
                self.mark_fp_dirty();
            }
            PROBE => self.probe_value = v,
            // Zicntr (E1-T14): mcycle/minstret are writable (the unprivileged cycle/instret are
            // read-only shadows, rejected before reaching write_raw by the read_only encoding).
            // Flag the write so this instruction's own retirement does not re-increment it.
            MCYCLE => {
                self.mcycle = v;
                self.counter_writes |= WROTE_MCYCLE;
            }
            MINSTRET => {
                self.minstret = v;
                self.counter_writes |= WROTE_MINSTRET;
            }
            // PMP (E1-T15): route to the unit, which applies WARL legalization + lock enforcement.
            PMPCFG0..=PMPCFG14 if (addr - PMPCFG0).is_multiple_of(2) => {
                self.pmp.write_cfg((addr - PMPCFG0) as usize, v)
            }
            PMPADDR0..=PMPADDR63 => self.pmp.write_addr((addr - PMPADDR0) as usize, v),
            // satp (E1-T18, §4.1.11): WARL MODE legalization is ALL-OR-NOTHING — a write whose
            // MODE field is unsupported leaves the ENTIRE register (MODE, ASID, and PPN) at its old
            // value, NOT just the MODE. Linux's `set_satp_mode` relies on exactly this to probe
            // Sv48/Sv57 support. Supported MODEs: Bare (0), Sv39 (8), and Sv48 (9) iff configured.
            // A mode change does NOT flush the TLB (SFENCE.VMA is required, T17).
            SATP => {
                // satp MODE is WARL (§4.1.11): only supported modes commit; an unsupported MODE
                // leaves satp unchanged (Bare/previous). Bare(0), Sv39(8), Sv48(9, if enabled),
                // Sv57(10, if enabled — E1-T28).
                let mode = v >> 60;
                if mode == 0 || mode == 8 || (mode == 9 && self.sv48) || (mode == 10 && self.sv57) {
                    self.warl.set_slot(W_SATP, v);
                }
            }
            MISA | MHARTID | MVENDORID | MARCHID | MIMPID => {} // hardwired
            0xC00..=0xC1F => {}
            // Debug triggers (E1-T29):
            // - tselect: only trigger 0 exists → any write clamps to 0.
            // - tdata1: mcontrol WARL — force type=2, clear dmode (bit 59, debug-mode-only);
            //   keep the modeled control bits (mode/timing/match/action + execute/store/load).
            // - tdata2: the compare value (full 64 bits).
            // - tcontrol: only mte (bit 3) / mpte (bit 7) are modeled.
            TSELECT => self.trig_select = 0,
            TDATA1 => {
                self.trig_tdata1 = (v & !(0xFu64 << 60) & !(1u64 << 59)) | (2u64 << 60);
                self.recompute_triggers_armed();
            }
            TDATA2 => {
                self.trig_tdata2 = v;
                self.recompute_triggers_armed();
            }
            TDATA3 => {}
            TCONTROL => self.trig_tcontrol = v & ((1 << 3) | (1 << 7)),
            other => self.warl.set(other, v),
        }
    }

    /// Execute one Zicsr access with full spec semantics. `src` is the resolved operand
    /// (rs1 value or zero-extended uimm); `src_is_zero` is true when the write must be
    /// suppressed for Set/Clear (rs1==x0 or uimm==0); `rd_is_zero` suppresses the read for
    /// Write. Returns the old value to place in `rd` (ignored when `rd_is_zero`), or a
    /// `Trap` for unimplemented / read-only / insufficient-privilege access.
    ///
    /// `illegal_tval` is the faulting instruction word, placed in the trap's `tval`.
    pub fn access(
        &mut self,
        addr: u16,
        op: CsrOp,
        src: u64,
        src_is_zero: bool,
        rd_is_zero: bool,
        illegal_tval: u64,
    ) -> Result<u64, Trap> {
        let illegal = || Trap {
            cause: Exception::IllegalInstruction,
            tval: illegal_tval,
        };

        let meta = Csrs::meta(addr).ok_or_else(illegal)?;
        if self.mode < meta.min_priv {
            return Err(illegal()); // access above current privilege
        }
        // TVM (E1-T20, §3.1.6.5): with mstatus.TVM=1, a `satp` CSR access in S-mode is illegal —
        // the hypervisor-intercept partner of the SFENCE.VMA-in-S trap (E1-T17). M is unaffected.
        if addr == SATP && matches!(self.mode, Priv::S) && self.tvm() {
            return Err(illegal());
        }
        // Zicntr counter gating (E1-T14, §3.1.10/§4.1.5): an S/U access to cycle/time/instret
        // (and any hpmcounter) is illegal unless the matching mcounteren bit is set; U also needs
        // the scounteren bit. M-mode is never gated. HPM bits 3..31 of counteren are read-only 0,
        // so hpmcounter3..31 always trap from S/U.
        if (CYCLE..=0xC1F).contains(&addr) && !matches!(self.mode, Priv::M) {
            let bit = 1u64 << (addr - CYCLE);
            let m_ok = self.warl.slot(W_MCOUNTEREN) & bit != 0;
            let permitted = match self.mode {
                Priv::S => m_ok,
                _ => m_ok && (self.warl.slot(W_SCOUNTEREN) & bit != 0), // U-mode
            };
            if !permitted {
                return Err(illegal());
            }
        }
        // With mstatus.FS=Off, the FP CSRs are inaccessible (E1-T06) — the access itself is
        // an illegal instruction, exactly like an FP compute op.
        if matches!(addr, FFLAGS | FRM | FCSR) && self.fp_off() {
            return Err(illegal());
        }
        // A write occurs for CSRRW always, and for CSRRS/CSRRC only when the source is
        // nonzero (rs1 != x0 / uimm != 0).
        let writes = matches!(op, CsrOp::Write) || !src_is_zero;
        if writes && meta.read_only {
            return Err(illegal()); // write to a read-only CSR
        }

        // Read side effect is suppressed for CSRRW with rd == x0.
        let old = if matches!(op, CsrOp::Write) && rd_is_zero {
            0
        } else {
            self.read_raw(addr)
        };

        if writes {
            // For Set/Clear we need the current value even if the read was suppressed above
            // (rd_is_zero only applies to Write). old already holds it for Set/Clear.
            let base = old;
            let new = match op {
                CsrOp::Write => src,
                CsrOp::Set => base | src,
                CsrOp::Clear => base & !src,
            };
            self.write_raw(addr, new & meta.warl_mask);
        }
        Ok(old)
    }
}

impl Default for Csrs {
    fn default() -> Self {
        Self::at_reset()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Every CSR a guest (or the trap/device paths) can write lands in a dense slot: after writing
    /// all 4096 addresses in M-mode — all-ones and zero, every Zicsr op — plus both trap-delivery
    /// paths and `set_mip_bit`, the cold `extra` overflow is still empty. `extra` is reserved for
    /// snapshot-table oddities; a live write reaching it would mean a slot is missing.
    #[test]
    fn every_writable_csr_has_a_dense_slot() {
        for op in [CsrOp::Write, CsrOp::Set, CsrOp::Clear] {
            for src in [0, !0, 0x5555_5555_5555_5555] {
                let mut c = Csrs::at_reset();
                c.mstatus = legalize_mstatus(M_FS); // FS=Dirty so the FP CSRs are accessible
                for addr in 0..=0xFFFu16 {
                    let _ = c.access(addr, op, src, src == 0, false, 0);
                }
                c.deliver_trap_m(0x1000, 2, 3);
                c.deliver_trap_s(0x2000, 4, 5);
                c.set_mip_bit(7, true);
                assert!(
                    c.warl.extra.is_empty(),
                    "live write escaped the dense slots"
                );
            }
        }
    }

    /// The old store was an insertion-ordered list; its snapshot was a STABLE sort by address, reads
    /// and writes acted on an address's first occurrence, and a table from a snapshot was kept
    /// verbatim (duplicates and slot-less addresses included). Check the dense store reproduces all
    /// of that on a deliberately hostile table.
    #[test]
    fn snapshot_table_matches_old_list_semantics() {
        let table: [(u16, u64); 8] = [
            (MIP, 1),
            (0x999, 2),
            (SATP, 3),
            (MIP, 4),
            (0x999, 5),
            (STVEC, 6),
            (0x100, 7), // SSTATUS: a view with no store slot
            (MIP, 8),
        ];
        let mut w = WarlStore::new();
        for (a, v) in table {
            w.push_parsed(a, v);
        }
        // First occurrence wins for reads, including slot-less addresses.
        assert_eq!(w.get(MIP), 1);
        assert_eq!(w.get(0x999), 2);
        assert_eq!(w.get(0x100), 7);
        assert_eq!(w.get(MEPC), 0, "never written reads 0");
        // …and for writes.
        w.set(MIP, 9);
        w.set(0x999, 10);
        let mut old: alloc::vec::Vec<(u16, u64)> = table.to_vec();
        old[0].1 = 9;
        old[1].1 = 10;
        // A write to a new address appends (then sorts into place).
        w.set(MEPC, 11);
        old.push((MEPC, 11));
        old.sort_by_key(|(a, _)| *a); // stable, exactly as the old serializer
        let mut expect = alloc::vec::Vec::new();
        expect.extend_from_slice(&(old.len() as u32).to_le_bytes());
        for (a, v) in &old {
            expect.extend_from_slice(&a.to_le_bytes());
            expect.extend_from_slice(&v.to_le_bytes());
        }
        let mut got = alloc::vec::Vec::new();
        w.snapshot_bytes(&mut got);
        assert_eq!(got, expect);
    }

    /// The mask-based takeability in `next_interrupt` picks exactly what the old per-bit priority
    /// walk picked, exhaustively over every mode, both global enables, and every pending/enable and
    /// delegation pattern of the six implemented lines plus an unimplemented bit (reachable only
    /// through a restored snapshot).
    #[test]
    fn next_interrupt_matches_per_bit_priority_walk() {
        fn reference(c: &Csrs) -> Option<(u64, bool)> {
            let pend = c.warl.slot(W_MIP) & c.warl.slot(W_MIE);
            let mideleg = c.warl.slot(W_MIDELEG);
            let mie_glob = c.mstatus & M_MIE != 0;
            let sie_glob = c.mstatus & M_SIE != 0;
            for &i in &INT_PRIORITY {
                if pend & (1 << i) == 0 {
                    continue;
                }
                let to_s = mideleg & (1 << i) != 0;
                let takeable = if to_s {
                    match c.mode {
                        Priv::U => true,
                        Priv::S => sie_glob,
                        Priv::M => false,
                    }
                } else {
                    match c.mode {
                        Priv::M => mie_glob,
                        _ => true,
                    }
                };
                if takeable {
                    return Some(((1u64 << 63) | i, to_s));
                }
            }
            None
        }
        // The six lines (1,3,5,7,9,11) plus bit 13, packed into 7 bits.
        let spread =
            |m: u64| -> u64 { (0..7).fold(0, |acc, k| acc | (((m >> k) & 1) << (2 * k + 1))) };
        let mut c = Csrs::at_reset();
        for mode in [Priv::U, Priv::S, Priv::M] {
            for glob in 0..4u64 {
                c.mode = mode;
                c.mstatus = ((glob & 1) * M_MIE) | ((glob >> 1) * M_SIE);
                for pend in 0..128u64 {
                    for deleg in 0..128u64 {
                        c.warl.set_slot(W_MIP, spread(pend));
                        c.warl.set_slot(W_MIE, spread(pend | deleg));
                        c.warl.set_slot(W_MIDELEG, spread(deleg));
                        assert_eq!(c.next_interrupt(), reference(&c));
                    }
                }
            }
        }
    }

    /// The packed counter-write bits serialize as the original two bools (mcycle, then minstret)
    /// right after the counters, and restore into the same suppression behaviour.
    #[test]
    fn counter_write_flags_keep_their_two_bool_encoding() {
        for (wrote_c, wrote_i) in [(false, false), (true, false), (false, true), (true, true)] {
            let mut c = Csrs::at_reset();
            c.arm_counters();
            if wrote_c {
                c.access(MCYCLE, CsrOp::Write, 100, false, true, 0).unwrap();
            }
            if wrote_i {
                c.access(MINSTRET, CsrOp::Write, 200, false, true, 0)
                    .unwrap();
            }
            let mut a = alloc::vec::Vec::new();
            c.snapshot_bytes(&mut a);
            // mode(1) mstatus(8) mcause(8) fflags(1) frm(1) warl(4 + 10*n) mcycle(8) minstret(8)
            let flags = 1 + 8 + 8 + 1 + 1 + 4 + 16;
            assert_eq!(a[flags..flags + 2], [u8::from(wrote_c), u8::from(wrote_i)]);
            let mut r = crate::resume::Reader::new(&a, crate::resume::section::CPU);
            let mut back = Csrs::parse(&mut r).unwrap();
            let mut b = alloc::vec::Vec::new();
            back.snapshot_bytes(&mut b);
            assert_eq!(a, b);
            back.retire_tick();
            let expect_c = if wrote_c { 100 } else { 1 };
            let expect_i = if wrote_i { 200 } else { 1 };
            assert_eq!(back.read(MCYCLE), expect_c);
            assert_eq!(back.read(MINSTRET), expect_i);
        }
    }

    /// Presence, not value, decides table membership: a device clearing a never-set `mip` bit still
    /// creates the entry (the old `warl_set` pushed `(MIP, 0)`), and an untouched store is empty.
    #[test]
    fn set_mip_bit_marks_mip_written_even_when_zero() {
        let mut c = Csrs::at_reset();
        let mut out = alloc::vec::Vec::new();
        c.warl.snapshot_bytes(&mut out);
        assert_eq!(out, 0u32.to_le_bytes());
        c.set_mip_bit(7, false);
        out.clear();
        c.warl.snapshot_bytes(&mut out);
        let mut expect = alloc::vec::Vec::new();
        expect.extend_from_slice(&1u32.to_le_bytes());
        expect.extend_from_slice(&MIP.to_le_bytes());
        expect.extend_from_slice(&0u64.to_le_bytes());
        assert_eq!(out, expect);
    }
}
