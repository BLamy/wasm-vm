//! Guest physical RAM: a heap-allocated, zero-initialized byte array mapped at a base
//! address, implementing [`Bus`] with the E0-T03 fault policy.

use alloc::vec::Vec;

use crate::bus::{Bus, BusFault, mmap};

/// RAM allocation failed (requested size exceeds what the allocator can provide).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct OutOfMemory;

/// Byte-array RAM mapped at `base`, addressed by guest physical address.
pub struct Ram {
    base: u64,
    data: Vec<u8>,
}

impl Ram {
    /// RAM of `bytes` zeroed bytes at the canonical [`mmap::DRAM_BASE`].
    ///
    /// Fails with [`OutOfMemory`] instead of aborting on absurd sizes — the allocation
    /// goes through `try_reserve_exact`, so `Ram::new(usize::MAX)` is an `Err`, not a
    /// process abort. `Ram::new(0)` is allowed: every access simply faults `Access`.
    pub fn new(bytes: usize) -> Result<Self, OutOfMemory> {
        Self::with_base(mmap::DRAM_BASE, bytes)
    }

    /// RAM of `bytes` zeroed bytes at an arbitrary base (test rigs, future regions).
    pub fn with_base(base: u64, bytes: usize) -> Result<Self, OutOfMemory> {
        let mut data = Vec::new();
        data.try_reserve_exact(bytes).map_err(|_| OutOfMemory)?;
        data.resize(bytes, 0);
        Ok(Self { base, data })
    }

    /// Size of this RAM in bytes.
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// True when this RAM has zero bytes (every access faults).
    pub fn is_empty(&self) -> bool {
        self.data.is_empty()
    }

    /// Base guest physical address of this RAM.
    pub fn base(&self) -> u64 {
        self.base
    }

    /// Bounds-check an access and return the starting offset into `data`.
    ///
    /// Overflow-proof by construction: `checked_sub` rejects addresses below base,
    /// `checked_add` rejects `addr + width` wrapping past `u64::MAX`, and the final
    /// compare rejects anything past the end. Range faults take precedence over
    /// alignment faults (see `bus.rs` policy).
    #[inline(always)]
    fn index(&self, addr: u64, width: u64) -> Result<usize, BusFault> {
        let off = addr.checked_sub(self.base).ok_or(BusFault::Access)?;
        let end = off.checked_add(width).ok_or(BusFault::Access)?;
        if end > self.data.len() as u64 {
            return Err(BusFault::Access);
        }
        if addr & (width - 1) != 0 {
            return Err(BusFault::Misaligned);
        }
        Ok(off as usize)
    }

    /// Softmmu fast path: the `W` bytes at `addr`, which the caller already proved aligned and
    /// inside RAM. Still range-checked — by the slice lookup itself, the only bounds check on this
    /// path — so a broken caller faults instead of misbehaving; the alignment test is left to the
    /// caller's proof. `None` = outside RAM.
    #[inline(always)]
    fn fast_bytes<const W: usize>(&self, addr: u64) -> Option<&[u8; W]> {
        let off = usize::try_from(addr.wrapping_sub(self.base)).ok()?;
        self.data.get(off..off.checked_add(W)?)?.try_into().ok()
    }

    /// [`Self::fast_bytes`], mutable.
    #[inline(always)]
    fn fast_bytes_mut<const W: usize>(&mut self, addr: u64) -> Option<&mut [u8; W]> {
        let off = usize::try_from(addr.wrapping_sub(self.base)).ok()?;
        self.data.get_mut(off..off.checked_add(W)?)?.try_into().ok()
    }

    /// Range-check (no alignment requirement) for byte-granular slice access.
    #[inline]
    fn range(&self, addr: u64, len: u64) -> Result<usize, BusFault> {
        let off = addr.checked_sub(self.base).ok_or(BusFault::Access)?;
        let end = off.checked_add(len).ok_or(BusFault::Access)?;
        if end > self.data.len() as u64 {
            return Err(BusFault::Access);
        }
        Ok(off as usize)
    }

    /// Loader escape hatch: copy out `buf.len()` bytes starting at `addr`.
    /// Byte-granular (no alignment requirement); fails `Access` without partial reads.
    pub fn read_slice(&self, addr: u64, buf: &mut [u8]) -> Result<(), BusFault> {
        let off = self.range(addr, buf.len() as u64)?;
        buf.copy_from_slice(&self.data[off..off + buf.len()]);
        Ok(())
    }

    /// The whole RAM byte array in address order (offset 0 == guest addr `base`).
    /// The canonical digest input for [`crate::snapshot::Snapshot`] (E0-T17) — device
    /// and hart state live in struct fields, never in this buffer.
    pub fn as_bytes(&self) -> &[u8] {
        &self.data
    }

    /// Loader escape hatch: copy `data` into RAM starting at `addr`.
    /// Byte-granular; fails `Access` without partial writes.
    pub fn write_slice(&mut self, addr: u64, data: &[u8]) -> Result<(), BusFault> {
        let off = self.range(addr, data.len() as u64)?;
        self.data[off..off + data.len()].copy_from_slice(data);
        Ok(())
    }
}

macro_rules! impl_load {
    ($name:ident, $ty:ty) => {
        #[inline(always)]
        fn $name(&mut self, addr: u64) -> Result<$ty, BusFault> {
            const W: usize = size_of::<$ty>();
            let i = self.index(addr, W as u64)?;
            let bytes: [u8; W] = self.data[i..i + W].try_into().unwrap();
            Ok(<$ty>::from_le_bytes(bytes))
        }
    };
}

macro_rules! impl_store {
    ($name:ident, $ty:ty) => {
        #[inline(always)]
        fn $name(&mut self, addr: u64, val: $ty) -> Result<(), BusFault> {
            const W: usize = size_of::<$ty>();
            let i = self.index(addr, W as u64)?;
            self.data[i..i + W].copy_from_slice(&val.to_le_bytes());
            Ok(())
        }
    };
}

macro_rules! impl_fast_load {
    ($name:ident, $ty:ty) => {
        #[inline(always)]
        fn $name(&mut self, addr: u64) -> Result<$ty, BusFault> {
            const W: usize = size_of::<$ty>();
            debug_assert!(
                addr.is_multiple_of(W as u64),
                "fast-path access must be aligned"
            );
            match self.fast_bytes::<W>(addr) {
                Some(bytes) => Ok(<$ty>::from_le_bytes(*bytes)),
                None => Err(BusFault::Access),
            }
        }
    };
}

macro_rules! impl_fast_store {
    ($name:ident, $ty:ty) => {
        #[inline(always)]
        fn $name(&mut self, addr: u64, val: $ty) -> Result<(), BusFault> {
            const W: usize = size_of::<$ty>();
            debug_assert!(
                addr.is_multiple_of(W as u64),
                "fast-path access must be aligned"
            );
            match self.fast_bytes_mut::<W>(addr) {
                Some(bytes) => {
                    *bytes = val.to_le_bytes();
                    Ok(())
                }
                None => Err(BusFault::Access),
            }
        }
    };
}

impl Bus for Ram {
    impl_fast_load!(ram_load8, u8);
    impl_fast_load!(ram_load16, u16);
    impl_fast_load!(ram_load32, u32);
    impl_fast_load!(ram_load64, u64);
    impl_fast_store!(ram_store8, u8);
    impl_fast_store!(ram_store16, u16);
    impl_fast_store!(ram_store32, u32);
    impl_fast_store!(ram_store64, u64);

    impl_load!(load8, u8);
    impl_load!(load16, u16);
    impl_load!(load32, u32);
    impl_load!(load64, u64);
    impl_store!(store8, u8);
    impl_store!(store16, u16);
    impl_store!(store32, u32);
    impl_store!(store64, u64);

    fn ram_contains(&self, addr: u64, len: u64) -> bool {
        // [addr, addr+len) ⊆ [base, base+len_bytes). Wide compares (checked_add) so a range
        // ending past u64::MAX cannot wrap into a false positive.
        match addr.checked_add(len) {
            Some(end) => addr >= self.base() && end <= self.base() + self.len() as u64,
            None => false,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::bus::mmap::{DRAM_BASE, DRAM_SIZE_DEFAULT};

    const SIZE: u64 = 64 * 1024; // small RAM keeps tests fast; boundaries scale-free
    const END: u64 = DRAM_BASE + SIZE;

    fn ram() -> Ram {
        Ram::with_base(DRAM_BASE, SIZE as usize).unwrap()
    }

    #[test]
    fn default_map_constants() {
        assert_eq!(DRAM_BASE, 0x8000_0000);
        assert_eq!(DRAM_SIZE_DEFAULT, 128 * 1024 * 1024);
        let r = Ram::new(4096).unwrap();
        assert_eq!(r.base(), DRAM_BASE);
    }

    #[test]
    fn roundtrip_every_width_at_base_and_last_slot() {
        let mut r = ram();
        macro_rules! rt {
            ($store:ident, $load:ident, $ty:ty, $val:expr) => {
                let w = size_of::<$ty>() as u64;
                for addr in [DRAM_BASE, END - w] {
                    r.$store(addr, $val).unwrap();
                    assert_eq!(
                        r.$load(addr).unwrap(),
                        $val,
                        "{} @ {addr:#x}",
                        stringify!($load)
                    );
                }
            };
        }
        rt!(store8, load8, u8, 0xA5);
        rt!(store16, load16, u16, 0xBEEF);
        rt!(store32, load32, u32, 0xDEAD_BEEF);
        rt!(store64, load64, u64, 0x0123_4567_89AB_CDEF);
    }

    #[test]
    fn straddling_the_end_is_access_not_panic() {
        let mut r = ram();
        // base + size - 4 is misaligned for width 8 too; range wins per policy.
        assert_eq!(r.load64(END - 4), Err(BusFault::Access));
        assert_eq!(r.store64(END - 4, 0), Err(BusFault::Access));
        // Aligned straddles at every width.
        assert_eq!(r.load16(END - 1), Err(BusFault::Access));
        assert_eq!(r.load32(END - 2), Err(BusFault::Access));
        assert_eq!(r.load64(END - 8), Ok(0)); // last valid slot, for contrast
    }

    #[test]
    fn misaligned_in_range_faults_misaligned_at_every_width() {
        let mut r = ram();
        assert_eq!(r.load16(DRAM_BASE + 1), Err(BusFault::Misaligned));
        assert_eq!(r.load32(DRAM_BASE + 2), Err(BusFault::Misaligned));
        assert_eq!(r.load64(DRAM_BASE + 4), Err(BusFault::Misaligned));
        assert_eq!(r.store16(DRAM_BASE + 3, 0), Err(BusFault::Misaligned));
        assert_eq!(r.store32(DRAM_BASE + 1, 0), Err(BusFault::Misaligned));
        assert_eq!(r.store64(DRAM_BASE + 2, 0), Err(BusFault::Misaligned));
        // width 1 has no alignment requirement
        assert_eq!(r.load8(DRAM_BASE + 1), Ok(0));
    }

    #[test]
    fn little_endian_byte_order() {
        let mut r = ram();
        let a = DRAM_BASE + 0x100;
        r.store32(a, 0xDEAD_BEEF).unwrap();
        let bytes: [u8; 4] = core::array::from_fn(|i| r.load8(a + i as u64).unwrap());
        assert_eq!(bytes, [0xEF, 0xBE, 0xAD, 0xDE]);
    }

    #[test]
    fn extreme_addresses_fault_without_overflow_panics() {
        // Runs with debug_assertions on in `cargo test` dev profile: any wrapping
        // arithmetic would panic here instead of returning Access.
        let mut r = ram();
        for addr in [0u64, 0x7FFF_FFFF_FFFF_FFF8, u64::MAX - 7, u64::MAX] {
            assert_eq!(
                r.load8(addr).err(),
                Some(BusFault::Access),
                "load8 {addr:#x}"
            );
            assert_eq!(r.load64(addr & !7).err(), Some(BusFault::Access));
            assert_eq!(r.store64(addr & !7, 0).err(), Some(BusFault::Access));
        }
        // below-base addresses
        assert_eq!(r.load32(DRAM_BASE - 4), Err(BusFault::Access));
        assert_eq!(r.load64(DRAM_BASE - 8), Err(BusFault::Access));
    }

    #[test]
    fn faulting_store_leaves_ram_bit_identical() {
        let mut r = ram();
        r.store64(END - 8, 0x1122_3344_5566_7788).unwrap();
        let mut before = alloc::vec![0u8; 16];
        r.read_slice(END - 16, &mut before).unwrap();
        assert_eq!(
            r.store64(END - 4, 0xFFFF_FFFF_FFFF_FFFF),
            Err(BusFault::Access)
        );
        assert_eq!(r.store32(END - 3, 0xFFFF_FFFF), Err(BusFault::Access));
        let mut after = alloc::vec![0u8; 16];
        r.read_slice(END - 16, &mut after).unwrap();
        assert_eq!(before, after);
    }

    #[test]
    fn slice_escape_hatch_bounds_and_content() {
        let mut r = ram();
        r.write_slice(DRAM_BASE + 3, &[1, 2, 3, 4, 5]).unwrap(); // no alignment needed
        let mut buf = [0u8; 5];
        r.read_slice(DRAM_BASE + 3, &mut buf).unwrap();
        assert_eq!(buf, [1, 2, 3, 4, 5]);
        // straddle and overflow
        assert_eq!(r.write_slice(END - 2, &[0; 4]), Err(BusFault::Access));
        assert_eq!(r.read_slice(u64::MAX - 1, &mut buf), Err(BusFault::Access));
        // zero-length at end is fine (empty range)
        assert_eq!(r.read_slice(END, &mut []), Ok(()));
    }

    #[test]
    fn zero_and_absurd_sizes_fail_cleanly() {
        let mut z = Ram::new(0).unwrap();
        assert!(z.is_empty());
        assert_eq!(z.load8(DRAM_BASE), Err(BusFault::Access));
        assert_eq!(z.store8(DRAM_BASE, 1), Err(BusFault::Access));
        // capacity overflow is an Err, not an abort
        assert_eq!(Ram::new(usize::MAX).err(), Some(OutOfMemory));
    }

    #[test]
    fn fast_path_accessors_match_the_checked_ones_and_still_range_check() {
        let mut r = ram();
        // Same bytes, same values, every width, at both ends of RAM.
        for addr in [DRAM_BASE, END - 8] {
            r.ram_store64(addr, 0x0123_4567_89AB_CDEF).unwrap();
            assert_eq!(r.load64(addr), Ok(0x0123_4567_89AB_CDEF));
            assert_eq!(r.ram_load64(addr), Ok(0x0123_4567_89AB_CDEF));
            assert_eq!(r.ram_load32(addr + 4), r.load32(addr + 4));
            assert_eq!(r.ram_load16(addr + 6), r.load16(addr + 6));
            assert_eq!(r.ram_load8(addr + 7), r.load8(addr + 7));
            r.ram_store32(addr, 0xDEAD_BEEF).unwrap();
            r.ram_store16(addr + 4, 0xCAFE).unwrap();
            r.ram_store8(addr + 6, 0x5A).unwrap();
            assert_eq!(r.load64(addr), Ok(0x015A_CAFE_DEAD_BEEF));
        }
        // A broken caller outside RAM faults instead of touching memory (no wrap-around alias).
        let before = r.as_bytes().to_vec();
        for addr in [
            END,
            DRAM_BASE - 8,
            0,
            u64::MAX - 7,
            DRAM_BASE + (1u64 << 40),
        ] {
            assert_eq!(r.ram_load64(addr), Err(BusFault::Access), "{addr:#x}");
            assert_eq!(r.ram_store64(addr, 0), Err(BusFault::Access), "{addr:#x}");
        }
        assert_eq!(r.as_bytes(), &before[..]);
        let mut z = Ram::new(0).unwrap();
        assert_eq!(z.ram_load8(DRAM_BASE), Err(BusFault::Access));
    }
}

/// E3-T12: RAM snapshots as its entire byte array through the zero-elision codec (a mostly-idle
/// guest RAM doesn't serialize to its full size). RAM state IS its bytes — nothing hidden — so this
/// is complete by construction. `base` is fixed platform config (bound by the header's base-image
/// hash), not dynamic state, so it isn't part of the payload. Restore into a RAM of a DIFFERENT size
/// is refused: `decode_sparse` reconstructs to exactly the current length or errors, so a snapshot of
/// a differently-sized RAM cannot be applied.
impl crate::resume::ComponentSnapshot for Ram {
    const SECTION: u32 = crate::resume::section::RAM;

    fn to_snapshot(&self) -> alloc::vec::Vec<u8> {
        crate::resume::encode_sparse(&self.data)
    }

    fn restore(&mut self, payload: &[u8]) -> Result<(), crate::resume::SnapshotError> {
        // decode_sparse guarantees the result is exactly `self.data.len()` bytes (or errors), so the
        // copy is length-safe and a wrong-size snapshot is rejected before any mutation.
        let bytes = crate::resume::decode_sparse(payload, self.data.len())?;
        self.data.copy_from_slice(&bytes);
        Ok(())
    }
}

#[cfg(test)]
mod resume_snapshot_tests {
    use super::Ram;
    use crate::resume::{ComponentSnapshot, SnapshotError, section};

    /// A RAM with a mostly-zero body plus a few non-zero spans (the realistic snapshot shape).
    fn patterned(len: usize) -> Ram {
        let mut r = Ram::new(len).unwrap();
        for off in [0usize, 1024, len / 2, len - 4] {
            for k in 0..4 {
                if off + k < len {
                    r.data[off + k] = (off as u8) ^ (k as u8) | 1;
                }
            }
        }
        r
    }

    #[test]
    fn ram_round_trips_completely() {
        let r = patterned(1 << 16);
        assert_eq!(Ram::SECTION, section::RAM);
        let bytes = r.to_snapshot();
        let mut restored = Ram::new(1 << 16).unwrap();
        restored.restore(&bytes).unwrap();
        // Every byte survives — RAM state is exactly its bytes.
        assert_eq!(restored.as_bytes(), r.as_bytes());
    }

    #[test]
    fn a_mostly_zero_ram_snapshot_is_far_under_ram_size() {
        // AC #4 at the RAM level: a mostly-idle 1 MiB RAM must serialize to well under 15%.
        let r = patterned(1 << 20);
        let snap = r.to_snapshot();
        let pct = snap.len() * 100 / r.len();
        assert!(pct < 15, "RAM elided to {pct}% (< 15% required)");
        // …and it still round-trips exactly.
        let mut restored = Ram::new(1 << 20).unwrap();
        restored.restore(&snap).unwrap();
        assert_eq!(restored.as_bytes(), r.as_bytes());
    }

    #[test]
    #[cfg_attr(target_arch = "wasm32", ignore = "256 MiB body is host-only")]
    fn a_mostly_zero_256_mib_ram_encodes_under_15_percent_and_restores_byte_identically() {
        // AC #3 verbatim: a mostly-zero 256 MiB RAM model encodes below 15% of raw size and restores
        // byte-identically. In practice a handful of non-zero spans elide to kilobytes, but the test
        // fixes the exact scale the acceptance criterion names rather than extrapolating from 1 MiB.
        const LEN: usize = 256 << 20;
        let r = patterned(LEN);
        let snap = r.to_snapshot();
        let pct = snap.len() * 100 / r.len();
        assert!(pct < 15, "256 MiB RAM elided to {pct}% (< 15% required)");
        let mut restored = Ram::new(LEN).unwrap();
        restored.restore(&snap).unwrap();
        assert_eq!(
            restored.as_bytes(),
            r.as_bytes(),
            "256 MiB RAM restored byte-identically"
        );
    }

    #[test]
    fn restoring_a_wrong_size_snapshot_is_refused_without_mutating() {
        let src = patterned(4096);
        let snap = src.to_snapshot();
        // A RAM of a different size cannot accept this snapshot (decode reconstructs to 8192 ≠ 4096).
        let mut bigger = patterned(8192);
        let before = bigger.as_bytes().to_vec();
        assert_eq!(
            bigger.restore(&snap),
            Err(SnapshotError::BadSparseEncoding),
            "a differently-sized RAM snapshot is rejected"
        );
        assert_eq!(
            bigger.as_bytes(),
            &before[..],
            "rejected restore left RAM untouched"
        );
    }

    #[test]
    fn a_malformed_payload_is_refused_without_mutating() {
        let mut r = patterned(256);
        let before = r.as_bytes().to_vec();
        // A truncated zero-run chunk (kind byte, no length) is malformed.
        assert!(r.restore(&[0u8]).is_err());
        assert!(r.restore(&[1, 0, 0, 0]).is_err()); // data chunk, len word cut short
        assert_eq!(
            r.as_bytes(),
            &before[..],
            "malformed restore left RAM untouched"
        );
    }
}
