//! E4-T10: the platform boundary between the `no_std` core dispatch loop and a compiled-block
//! executor.
//!
//! `crates/core` is `no_std` and cannot host a WASM engine, so it never *runs* translated blocks
//! itself. Instead it defines the [`CompiledBlockExecutor`] trait: the run loop asks the executor
//! (a) whether the block at a physical PC is compiled ([`CompiledBlockExecutor::is_compiled`]) and,
//! if so, (b) to execute it against the live [`Hart`] + [`SystemBus`]
//! ([`CompiledBlockExecutor::execute`]), returning the frozen E4-T06 [`JitExit`] protocol. A native
//! crate (`wasm-vm-jit-runtime`) implements the trait with wasmtime; the browser executor
//! (`WebAssembly.Module`) is a later ticket (E4-T19). Core holds no engine and stays `no_std`.
//!
//! The executor reaches guest memory through the SAME [`Hart`]/[`SystemBus`] the interpreter uses
//! ([`Hart::jit_load`] / [`Hart::jit_store`]), so a JIT load/store is translated, PMP-checked, and
//! routed to RAM/MMIO byte-identically to the interpreter. A recorded guest fault returns a precise
//! [`JitExit`]; an unclassified engine failure after dispatch must fail closed because an imported
//! access may already have committed a side effect. `None` is reserved for a pre-call cache miss,
//! where interpreting from the same entry is provably replay-safe.

use crate::dispatch::DecodedBlock;
use crate::hart::Hart;
use crate::mmio::SystemBus;
use alloc::boxed::Box;

/// Pure generated-code helper for FADD.S / FMUL.S. Operands have already been
/// NaN-box checked and `rm` resolved/validated (0..=4) by the generated caller.
/// Low 32 bits are the raw result; bits 32..36 are newly accrued RISC-V flags.
/// No hart, bus, memory, device or scheduler reference crosses this boundary.
pub fn fp_arith_s(a: u32, b: u32, multiply: bool, rm: u8) -> u64 {
    use crate::softfloat::{F32, RoundMode, SoftFloat};
    let round = RoundMode::from_bits(rm).expect("generated FP helper requires validated rounding");
    let (bits, flags) = if multiply {
        F32::mul(a, b, round)
    } else {
        F32::add(a, b, round)
    };
    u64::from(bits) | (u64::from(flags.0) << 32)
}

/// Pure FCVT.S.{W,WU,L,LU} helper. The generated caller validates `rm` and
/// selects width 0=W, 1=WU, 2=L or 3=LU. The full integer source crosses this
/// boundary unchanged; the software backend applies width and signedness.
/// Return raw f32 bits in 0..31 and new flags in 32..36, as for `fp_arith_s`.
pub fn fp_from_int_s(value: u64, width: u8, rm: u8) -> u64 {
    use crate::decode::FpIntWidth;
    use crate::softfloat::{RoundMode, f32_from_int};
    let width = match width {
        0 => FpIntWidth::W,
        1 => FpIntWidth::Wu,
        2 => FpIntWidth::L,
        3 => FpIntWidth::Lu,
        _ => panic!("generated FP helper requires a decoded integer width"),
    };
    let round = RoundMode::from_bits(rm).expect("generated FP helper requires validated rounding");
    let (bits, flags) = f32_from_int(value, width, round);
    u64::from(bits) | (u64::from(flags.0) << 32)
}

/// Pure FCVT.W[U].S helper. The caller checks the source NaN box and validates
/// rounding before entry. Return low word bits in 0..31 and flags in 32..36;
/// the generated caller sign-extends the word for both signed and unsigned W.
pub fn fp_to_word_s(bits: u32, unsigned: bool, rm: u8) -> u64 {
    use crate::decode::FpIntWidth;
    use crate::softfloat::{RoundMode, f32_to_int};
    let width = if unsigned {
        FpIntWidth::Wu
    } else {
        FpIntWidth::W
    };
    let round = RoundMode::from_bits(rm).expect("generated FP helper requires validated rounding");
    let (word, flags) = f32_to_int(bits, width, round);
    u64::from(word as u32) | (u64::from(flags.0) << 32)
}

/// Pure FDIV.S helper. The generated caller checks source NaN boxes and
/// validates rounding. Return result bits in 0..31 and new flags in 32..36;
/// no guest execution context crosses this boundary.
pub fn fp_div_s(a: u32, b: u32, rm: u8) -> u64 {
    use crate::softfloat::{F32, RoundMode, SoftFloat};
    let round = RoundMode::from_bits(rm).expect("generated FP helper requires validated rounding");
    let (bits, flags) = F32::div(a, b, round);
    u64::from(bits) | (u64::from(flags.0) << 32)
}

/// Pure FMADD.S helper. Three independently NaN-box-checked sources and a
/// validated rounding mode enter one software fused operation. Return raw
/// result bits and newly raised flags; never touch guest execution context.
pub fn fp_fmadd_s(a: u32, b: u32, c: u32, rm: u8) -> u64 {
    use crate::softfloat::{F32, RoundMode, SoftFloat};
    let round = RoundMode::from_bits(rm).expect("generated FP helper requires validated rounding");
    let (bits, flags) = F32::fma(a, b, c, round);
    u64::from(bits) | (u64::from(flags.0) << 32)
}

/// Operation selectors for the generic generated-code FP helpers [`fp_op64`] / [`fp_op32`].
///
/// These cover every F/D operation whose exact RISC-V result cannot be produced by a few inline
/// integer wasm instructions (rounding, flag computation, NaN canonicalization). The generated
/// caller has already checked FS, NaN-box-checked every single-precision source (passing the
/// canonical NaN for an improperly boxed operand, exactly like `FRegs::read_f32`) and resolved +
/// validated the rounding mode, so each helper is a pure function of its operands. Every selector
/// calls the same `softfloat` routine `Hart::execute` uses, so results and flags are bit-identical
/// to the interpreter by construction.
pub mod fp_op {
    // ── fp_op64: 64-bit result, flags returned separately ──
    pub const ADD_D: u32 = 0;
    pub const SUB_D: u32 = 1;
    pub const MUL_D: u32 = 2;
    pub const DIV_D: u32 = 3;
    pub const SQRT_D: u32 = 4;
    pub const FMADD_D: u32 = 5;
    pub const FMSUB_D: u32 = 6;
    pub const FNMSUB_D: u32 = 7;
    pub const FNMADD_D: u32 = 8;
    pub const MIN_D: u32 = 9;
    pub const MAX_D: u32 = 10;
    /// FCVT.D.S: `a` holds the (NaN-box-checked) single-precision bits.
    pub const CVT_D_S: u32 = 11;
    pub const CVT_D_L: u32 = 12;
    pub const CVT_D_LU: u32 = 13;
    pub const CVT_L_D: u32 = 14;
    pub const CVT_LU_D: u32 = 15;
    /// FCVT.L[U].S: `a` holds the (NaN-box-checked) single-precision bits.
    pub const CVT_L_S: u32 = 16;
    pub const CVT_LU_S: u32 = 17;
    // ── fp_op32: packed `result[31:0] | flags << 32` ──
    pub const SUB_S: u32 = 32;
    pub const SQRT_S: u32 = 33;
    pub const FMSUB_S: u32 = 34;
    pub const FNMSUB_S: u32 = 35;
    pub const FNMADD_S: u32 = 36;
    pub const MIN_S: u32 = 37;
    pub const MAX_S: u32 = 38;
    /// FCLASS.S (no flags; the 10-bit class mask in the low word).
    pub const CLASS_S: u32 = 39;
    /// FCVT.S.D: the rounded single-precision bits (the caller NaN-boxes them).
    pub const CVT_S_D: u32 = 40;
    /// FCVT.W[U].D: the low result word (the caller sign-extends it, as for FCVT.W[U].S).
    pub const CVT_W_D: u32 = 41;
    pub const CVT_WU_D: u32 = 42;
    /// FCLASS.D (no flags).
    pub const CLASS_D: u32 = 43;
}

/// Pure generic helper for F/D operations with a 64-bit result. Returns `(result, flags)`; the
/// executor publishes `flags` through its per-thread flag mailbox (`fp_flags` import) because a
/// 64-bit result plus five flag bits do not fit one wasm `i64` return. `rm` is validated 0..=4.
pub fn fp_op64(op: u32, a: u64, b: u64, c: u64, rm: u8) -> (u64, u8) {
    use crate::decode::FpIntWidth;
    use crate::softfloat::{F64, RoundMode, SoftFloat};
    let round =
        || RoundMode::from_bits(rm).expect("generated FP helper requires validated rounding");
    const NEG: u64 = 0x8000_0000_0000_0000;
    let (bits, flags) = match op {
        fp_op::ADD_D => F64::add(a, b, round()),
        fp_op::SUB_D => F64::sub(a, b, round()),
        fp_op::MUL_D => F64::mul(a, b, round()),
        fp_op::DIV_D => F64::div(a, b, round()),
        fp_op::SQRT_D => F64::sqrt(a, round()),
        // Negation by sign flip before the single fused rounding, exactly as `Hart::execute`.
        fp_op::FMADD_D => F64::fma(a, b, c, round()),
        fp_op::FMSUB_D => F64::fma(a, b, c ^ NEG, round()),
        fp_op::FNMSUB_D => F64::fma(a ^ NEG, b, c, round()),
        fp_op::FNMADD_D => F64::fma(a ^ NEG, b, c ^ NEG, round()),
        fp_op::MIN_D => crate::softfloat::f64_minmax(a, b, false),
        fp_op::MAX_D => crate::softfloat::f64_minmax(a, b, true),
        fp_op::CVT_D_S => crate::softfloat::f32_to_f64(a as u32),
        fp_op::CVT_D_L => crate::softfloat::f64_from_int(a, FpIntWidth::L, round()),
        fp_op::CVT_D_LU => crate::softfloat::f64_from_int(a, FpIntWidth::Lu, round()),
        fp_op::CVT_L_D => crate::softfloat::f64_to_int(a, FpIntWidth::L, round()),
        fp_op::CVT_LU_D => crate::softfloat::f64_to_int(a, FpIntWidth::Lu, round()),
        fp_op::CVT_L_S => crate::softfloat::f32_to_int(a as u32, FpIntWidth::L, round()),
        fp_op::CVT_LU_S => crate::softfloat::f32_to_int(a as u32, FpIntWidth::Lu, round()),
        _ => panic!("generated FP helper requires a known 64-bit operation"),
    };
    (bits, flags.0)
}

/// Pure generic helper for F/D operations with a result of at most 32 bits. Returns the raw
/// result bits in 0..31 and the newly raised flags in 32..36, like [`fp_arith_s`].
/// Single-precision operands arrive in the low 32 bits of `a`/`b`/`c`.
pub fn fp_op32(op: u32, a: u64, b: u64, c: u64, rm: u8) -> u64 {
    use crate::decode::FpIntWidth;
    use crate::softfloat::{F32, Flags, RoundMode, SoftFloat};
    let round =
        || RoundMode::from_bits(rm).expect("generated FP helper requires validated rounding");
    const NEG: u32 = 0x8000_0000;
    let (a32, b32, c32) = (a as u32, b as u32, c as u32);
    let (bits, flags): (u32, Flags) = match op {
        fp_op::SUB_S => F32::sub(a32, b32, round()),
        fp_op::SQRT_S => F32::sqrt(a32, round()),
        fp_op::FMSUB_S => F32::fma(a32, b32, c32 ^ NEG, round()),
        fp_op::FNMSUB_S => F32::fma(a32 ^ NEG, b32, c32, round()),
        fp_op::FNMADD_S => F32::fma(a32 ^ NEG, b32, c32 ^ NEG, round()),
        fp_op::MIN_S => crate::softfloat::f32_minmax(a32, b32, false),
        fp_op::MAX_S => crate::softfloat::f32_minmax(a32, b32, true),
        fp_op::CLASS_S => (crate::softfloat::fclass_f32(a32) as u32, Flags::NONE),
        fp_op::CVT_S_D => crate::softfloat::f64_to_f32(a, round()),
        fp_op::CVT_W_D => {
            let (word, flags) = crate::softfloat::f64_to_int(a, FpIntWidth::W, round());
            (word as u32, flags)
        }
        fp_op::CVT_WU_D => {
            let (word, flags) = crate::softfloat::f64_to_int(a, FpIntWidth::Wu, round());
            (word as u32, flags)
        }
        fp_op::CLASS_D => (crate::softfloat::fclass_f64(a) as u32, Flags::NONE),
        _ => panic!("generated FP helper requires a known 32-bit operation"),
    };
    u64::from(bits) | (u64::from(flags.0) << 32)
}

/// The frozen `CpuState` linear-memory offsets (`docs/jit-architecture.md` §3.1). These MUST match
/// `jit_translate::Abi::FROZEN`; the executor syncs guest registers to `XREG_BASE` and reads the
/// exit protocol back from `EXIT_*`.
pub mod abi {
    /// Base of the `x[0..32]` guest integer register array (each register 8 bytes).
    pub const XREG_BASE: u32 = 0x000;
    /// End of the integer-register array.
    pub const XREG_END: u32 = XREG_BASE + 32 * 8;
    /// Reserved FLEN=64 register range, now consumed by the FP move subset.
    pub const FREG_BASE: u32 = 0x108;
    /// Low byte: fcsr; bit 8: FS enabled; bit 9: FP state dirtied; upper word:
    /// exact FPR write mask. This transport metadata is never a guest CSR value.
    pub const FP_STATE: u32 = 0x208;
    pub const FP_ENABLED: u64 = 1 << 8;
    pub const FP_DIRTY: u64 = 1 << 9;
    /// A generated `fflags`/`frm`/`fcsr` CSR write executed: the low byte is then the
    /// authoritative `{frm, fflags}` pair (overwritten, not accrued) at commit.
    pub const FP_CSR_WRITTEN: u64 = 1 << 10;
    /// `exit_reason` — the [`super::ExitCode`] the block wrote before returning.
    pub const EXIT_REASON: u32 = 0x218;
    /// `exit_pc` — the guest PC to resume at.
    pub const EXIT_PC: u32 = 0x220;
    /// `exit_info` — aux payload (trap cause for `ecall`/`ebreak`).
    pub const EXIT_INFO: u32 = 0x228;
    /// E4-T16 `entry_pc` — the guest VIRTUAL PC the block is entered at. The executor writes the
    /// live `hart.regs.pc` here before each `run` call; the compiled block reads it and emits every
    /// guest-visible PC relative to it, so translated control flow is correct under paging (guest
    /// virtual PC != physical block key) and when a physically-keyed block is reused from a new VA.
    pub const ENTRY_PC: u32 = 0x230;
    /// Exclusive end of the state transferred between a hart and a compiled module.
    pub const HANDOFF_END: u32 = ENTRY_PC + 8;
    /// Exact byte length of the one-call CPU-state handoff.
    pub const HANDOFF_LEN: usize = (HANDOFF_END - XREG_BASE) as usize;
    /// E4-T34: total retired instructions committed by the current in-module chain. This lives
    /// immediately after the frozen handoff and is not copied to/from the private SoftMMU state
    /// view; browser inline-memory executors use it as a shared chain accumulator.
    pub const CHAIN_RETIRED: u32 = HANDOFF_END;
    /// E4-T34: remaining guest-work fuel for an in-module chain. A successor that cannot fit
    /// returns [`super::ExitCode::Budget`] without executing an instruction.
    pub const CHAIN_BUDGET: u32 = CHAIN_RETIRED + 8;
    /// E4-T34: import-side side-effect barrier. A load that resolves to MMIO/misaligned memory,
    /// a host-visible store/atomic import, or a raw inline-RAM store that targets a live compiled
    /// page sets this byte so the current block returns to Rust before a successor can be called
    /// directly. Pending raw data-page stores are guarded separately before LR/SC/AMO operations.
    pub const CHAIN_ABORT: u32 = CHAIN_BUDGET + 8;
    /// E4-T34: exact guest-register write mask accumulated by generated direct-chain functions.
    /// It occupies the upper half of the abort word so the existing byte-sized abort flag and all
    /// later auxiliary offsets remain frozen.
    pub const CHAIN_REG_DIRTY: u32 = CHAIN_ABORT + 4;
    /// E4-T19/E4-T34 intra-module chaining flag. It is deliberately outside [`HANDOFF_END`]: the
    /// native executor leaves it zero, while the browser inline-memory executor enables it only for
    /// a bounded, interrupt-safe chain.
    pub const CHAIN_ENABLED: u32 = 0x250;
    /// E4-T34: count of raw inline-RAM stores waiting for the host-side reservation and code-write
    /// commit. Stored as an i64 so generated code can update it without widening/narrowing.
    pub const CHAIN_STORE_COUNT: u32 = CHAIN_ENABLED + 8;
    /// E4-T34: remaining compiled-block entries allowed in the current direct chain. The browser
    /// executor initializes this from `CompiledBlockExecutor::chain_depth_budget` and decrements it
    /// at each generated-function entry, so the in-module call stack observes the same bound as the
    /// native dispatch loop.
    pub const CHAIN_DEPTH: u32 = CHAIN_STORE_COUNT + 8;
    /// E4-T34: first `{virtual address, physical address, width}` raw-store record.
    pub const CHAIN_STORE_BASE: u32 = CHAIN_DEPTH + 8;
    /// E4-T34: byte size of one raw-store record.
    pub const CHAIN_STORE_ENTRY_BYTES: u32 = 24;
    /// E4-T34: bounded number of raw stores a direct-chain call can record. The direct-chain fuel is
    /// currently no larger than this, so a full log always takes the exact imported slow path.
    pub const CHAIN_STORE_CAPACITY: u32 = 128;
    /// E4-T37: number of generated dynamic-return probes in the current direct chain.
    pub const CHAIN_DYNAMIC_ATTEMPTS: u32 =
        CHAIN_STORE_BASE + CHAIN_STORE_ENTRY_BYTES * CHAIN_STORE_CAPACITY;
    /// E4-T37: number of dynamic-return probes that passed every generated guard and entered a
    /// cached target.
    pub const CHAIN_DYNAMIC_HITS: u32 = CHAIN_DYNAMIC_ATTEMPTS + 8;
    /// E4-T37: number of dynamic-return probes refused by the generated guards.
    pub const CHAIN_DYNAMIC_REFUSALS: u32 = CHAIN_DYNAMIC_HITS + 8;
    /// E4-T39: runtime switch for generated dynamic-return probes. The browser writes this before
    /// each entry so the same compiled module can provide a JALR-off control without recompiling.
    pub const CHAIN_DYNAMIC_ENABLED: u32 = CHAIN_DYNAMIC_REFUSALS + 8;
    /// E4-T39: generated indirect table calls (static and dynamic) in the current direct chain.
    pub const CHAIN_INDIRECT_DISPATCHES: u32 = CHAIN_DYNAMIC_ENABLED + 8;
    /// E4-T39: generated EXEC-TLB/authority predicates evaluated in the current direct chain.
    pub const CHAIN_AUTHORITY_CHECKS: u32 = CHAIN_INDIRECT_DISPATCHES + 8;
    /// Exclusive end of the auxiliary chain state retained beside the frozen handoff.
    pub const CHAIN_STATE_END: u32 = CHAIN_AUTHORITY_CHECKS + 8;
}

/// Reusable transport buffer spanning the compiled module's frozen handoff byte range.
///
/// The translator consumes integer/FPR images, FP control and `entry_pc`, producing
/// changed registers and the exit header. The remaining reserved gaps have no
/// architectural claim. The buffer uses words rather than a `repr(C)` field struct so its
/// byte view stays alignment-independent and little-endian-correct on every Rust host.
#[repr(C)]
pub struct CpuStateHandoff {
    // Stored as little-endian words so common little-endian hosts can marshal the whole register
    // file with one native slice copy. Byte accessors expose the identical frozen ABI image.
    words: [u64; abi::HANDOFF_LEN / 8],
    /// E4-T34 browser-only chain state. Keeping this in the same allocation makes the pointer passed
    /// to an imported-memory module cover both the frozen handoff and the auxiliary state while
    /// preserving [`Self::as_bytes`] and its exact 568-byte contract.
    chain: [u64; ((abi::CHAIN_STATE_END - abi::HANDOFF_END) / 8) as usize],
    /// Host-only cache key, beyond every generated-code offset and byte view.
    fp_register_version: Option<(u64, u64)>,
}

impl Default for CpuStateHandoff {
    fn default() -> Self {
        Self {
            words: [0; abi::HANDOFF_LEN / 8],
            chain: [0; ((abi::CHAIN_STATE_END - abi::HANDOFF_END) / 8) as usize],
            fp_register_version: None,
        }
    }
}

impl CpuStateHandoff {
    /// Marshal live registers, FP permission/control and virtual entry PC. An unchanged
    /// FPR image is reused; the prior exit header is never consumed on entry.
    pub fn prepare(&mut self, hart: &Hart) {
        self.prepare_registers(hart);
        self.prepare_fp_registers(hart);
        self.prepare_fp_control(hart);
        self.set_entry_pc(hart.regs.pc);
    }

    /// Marshal the raw FLEN=64 image, including writable f0. Browser callers may
    /// elide this copy only while the FRegs mutation stamp remains unchanged.
    pub fn prepare_fp_registers(&mut self, hart: &Hart) -> u64 {
        let version = Some(hart.fregs.jit_version());
        if self.fp_register_version == version {
            return 0;
        }
        #[cfg(target_endian = "little")]
        self.words[abi::FREG_BASE as usize / 8..abi::FP_STATE as usize / 8]
            .copy_from_slice(hart.fregs.jit_words());
        #[cfg(target_endian = "big")]
        for register in 0..32u8 {
            self.put_u64(
                abi::FREG_BASE + u32::from(register) * 8,
                hart.fregs.read_raw(register),
            );
        }
        self.fp_register_version = version;
        32 * 8
    }

    /// Refresh FS permission and fcsr for every invocation, clearing the previous
    /// invocation's dirty metadata independently of register-copy elision.
    pub fn prepare_fp_control(&mut self, hart: &Hart) {
        self.put_u64(
            abi::FP_STATE,
            u64::from(hart.csr.fflags | (hart.csr.frm << 5))
                | if hart.csr.fp_off() {
                    0
                } else {
                    abi::FP_ENABLED
                },
        );
    }

    /// Commit only executed FPR writes and accrued flags. FP-to-integer moves leave FS
    /// unchanged. Arithmetic only ORs new flags into the low byte, so accruing it is exact; a
    /// generated `fflags`/`frm`/`fcsr` write (which may clear flags or change the rounding
    /// mode) marks [`abi::FP_CSR_WRITTEN`], making the low byte the authoritative new pair.
    pub fn commit_fp_registers(&mut self, hart: &mut Hart) -> u64 {
        let bytes = commit_fp_state(hart, |offset| self.get_u64(offset));
        self.fp_register_version = Some(hart.fregs.jit_version());
        bytes
    }

    /// Marshal only the live integer-register image. The browser executor uses this separately so
    /// it can skip the 32-word copy when the hart still has the version it committed on the prior
    /// compiled call; the entry PC is independent and is refreshed for every invocation.
    pub fn prepare_registers(&mut self, hart: &Hart) {
        #[cfg(target_endian = "little")]
        self.words[..32].copy_from_slice(hart.regs.jit_words());
        #[cfg(target_endian = "big")]
        for register in 0..32u8 {
            self.put_u64(
                abi::XREG_BASE + u32::from(register) * 8,
                hart.regs.read(register),
            );
        }
    }

    /// Refresh the guest virtual PC consumed by the next generated block entry.
    pub fn set_entry_pc(&mut self, pc: u64) {
        self.put_u64(abi::ENTRY_PC, pc);
    }

    /// Commit the compiled module's integer-register image. `x0` is intentionally skipped so the
    /// architectural hardwired-zero invariant remains owned by `XRegs`.
    pub fn commit_registers(&self, hart: &mut Hart) {
        #[cfg(target_endian = "little")]
        hart.regs.jit_commit_words(&self.words[..32]);
        #[cfg(target_endian = "big")]
        for register in 1..32u8 {
            hart.regs.write(
                register,
                self.get_u64(abi::XREG_BASE + u32::from(register) * 8),
            );
        }
    }

    /// Commit only registers named by a generated direct-chain write mask. This is an optimization
    /// of the browser handoff; the full [`Self::commit_registers`] path remains the compatibility
    /// fallback for the frozen non-chaining ABI.
    pub fn commit_registers_mask(&self, hart: &mut Hart, mask: u32) {
        #[cfg(target_endian = "little")]
        hart.regs.jit_commit_words_mask(&self.words[..32], mask);
        #[cfg(target_endian = "big")]
        for register in 1..32u8 {
            if mask & (1_u32 << u32::from(register)) != 0 {
                hart.regs.write(
                    register,
                    self.get_u64(abi::XREG_BASE + u32::from(register) * 8),
                );
            }
        }
    }

    /// Exit reason mirrored by the compiled block in the state header.
    pub fn exit_reason(&self) -> i32 {
        self.get_u64(abi::EXIT_REASON) as i32
    }

    /// Guest PC materialized by the compiled block for its clean or precise-trap exit.
    pub fn exit_pc(&self) -> u64 {
        self.get_u64(abi::EXIT_PC)
    }

    /// Auxiliary exit payload written by the compiled block.
    pub fn exit_info(&self) -> u64 {
        self.get_u64(abi::EXIT_INFO)
    }

    /// Immutable bytes for a bulk engine write.
    pub fn as_bytes(&self) -> &[u8; abi::HANDOFF_LEN] {
        // SAFETY: `words` is fully initialized, exactly HANDOFF_LEN bytes long, and every byte
        // pattern is valid for `u8`. The returned borrow cannot outlive `self`.
        unsafe { &*self.words.as_ptr().cast::<[u8; abi::HANDOFF_LEN]>() }
    }

    /// Mutable bytes for a bulk engine read.
    pub fn as_mut_bytes(&mut self) -> &mut [u8; abi::HANDOFF_LEN] {
        // SAFETY: same layout argument as `as_bytes`; the exclusive borrow prevents aliasing.
        unsafe { &mut *self.words.as_mut_ptr().cast::<[u8; abi::HANDOFF_LEN]>() }
    }

    fn put_u64(&mut self, offset: u32, value: u64) {
        debug_assert_eq!(offset % 8, 0);
        let index = ((offset - abi::XREG_BASE) / 8) as usize;
        self.words[index] = value.to_le();
    }

    fn get_u64(&self, offset: u32) -> u64 {
        debug_assert_eq!(offset % 8, 0);
        let index = ((offset - abi::XREG_BASE) / 8) as usize;
        u64::from_le(self.words[index])
    }

    fn put_chain_u64(&mut self, offset: u32, value: u64) {
        debug_assert_eq!(offset % 8, 0);
        debug_assert!((abi::HANDOFF_END..abi::CHAIN_STATE_END).contains(&offset));
        let index = ((offset - abi::HANDOFF_END) / 8) as usize;
        self.chain[index] = value.to_le();
    }

    fn chain_u64(&self, offset: u32) -> u64 {
        debug_assert_eq!(offset % 8, 0);
        debug_assert!((abi::HANDOFF_END..abi::CHAIN_STATE_END).contains(&offset));
        let index = ((offset - abi::HANDOFF_END) / 8) as usize;
        u64::from_le(self.chain[index])
    }

    /// Initialize the browser-only bounded direct-chain header before one compiled invocation.
    /// The frozen register/exit handoff remains unchanged and is still the only state copied into
    /// private SoftMMU memories.
    pub fn begin_chain(&mut self, enabled: bool, budget: u64, depth: u64) {
        self.put_chain_u64(abi::CHAIN_RETIRED, 0);
        self.put_chain_u64(abi::CHAIN_BUDGET, budget);
        self.put_chain_u64(abi::CHAIN_ABORT, 0);
        self.put_chain_u64(abi::CHAIN_DEPTH, depth);
        self.put_chain_u64(abi::CHAIN_ENABLED, enabled as u64);
        self.put_chain_u64(abi::CHAIN_STORE_COUNT, 0);
        self.put_chain_u64(abi::CHAIN_DYNAMIC_ATTEMPTS, 0);
        self.put_chain_u64(abi::CHAIN_DYNAMIC_HITS, 0);
        self.put_chain_u64(abi::CHAIN_DYNAMIC_REFUSALS, 0);
        self.put_chain_u64(abi::CHAIN_DYNAMIC_ENABLED, 1);
        self.put_chain_u64(abi::CHAIN_INDIRECT_DISPATCHES, 0);
        self.put_chain_u64(abi::CHAIN_AUTHORITY_CHECKS, 0);
    }

    /// Enable or disable generated dynamic-return probes for the next direct-chain call.
    pub fn set_dynamic_chain_enabled(&mut self, enabled: bool) {
        self.put_chain_u64(abi::CHAIN_DYNAMIC_ENABLED, enabled as u64);
    }

    /// Total retired instructions recorded by the current direct chain.
    pub fn chain_retired(&self) -> u64 {
        self.chain_u64(abi::CHAIN_RETIRED)
    }

    /// Remaining generated-function entries allowed in the current browser direct chain.
    ///
    /// The browser executor uses this diagnostic to distinguish one host-side engine entry from
    /// the number of compiled functions that actually ran before the chain returned. It is kept
    /// outside the frozen handoff and has no architectural effect.
    pub fn chain_depth_remaining(&self) -> u64 {
        self.chain_u64(abi::CHAIN_DEPTH)
    }

    /// Number of generated dynamic-return probes in the current direct chain.
    pub fn dynamic_link_attempts(&self) -> u64 {
        self.chain_u64(abi::CHAIN_DYNAMIC_ATTEMPTS)
    }

    /// Number of generated dynamic-return probes that entered a cached target.
    pub fn dynamic_link_hits(&self) -> u64 {
        self.chain_u64(abi::CHAIN_DYNAMIC_HITS)
    }

    /// Number of generated dynamic-return probes refused by the cache or authority guard.
    pub fn dynamic_link_refusals(&self) -> u64 {
        self.chain_u64(abi::CHAIN_DYNAMIC_REFUSALS)
    }

    /// Number of generated static/dynamic calls through the imported funcref table in the current
    /// direct chain.
    pub fn indirect_dispatches(&self) -> u64 {
        self.chain_u64(abi::CHAIN_INDIRECT_DISPATCHES)
    }

    /// Number of generated EXEC-TLB/authority predicates evaluated in the current direct chain.
    pub fn authority_checks(&self) -> u64 {
        self.chain_u64(abi::CHAIN_AUTHORITY_CHECKS)
    }

    /// Whether an import-side barrier stopped the current direct chain.
    pub fn chain_was_aborted(&self) -> bool {
        self.chain_u64(abi::CHAIN_ABORT) & 1 != 0
    }

    /// Registers written by the current generated direct chain, as a bit mask over x0..x31.
    pub fn chain_reg_dirty(&self) -> u32 {
        (self.chain_u64(abi::CHAIN_ABORT) >> 32) as u32
    }

    /// Pointer to the byte-sized import-side abort flag in the auxiliary chain header.
    pub fn chain_abort_ptr(&mut self) -> *mut u8 {
        // SAFETY: `chain` is a live, aligned array in this allocation and the selected word is
        // addressable for the entire duration of the compiled call.
        self.chain.as_mut_ptr().cast::<u8>().wrapping_add(16)
    }

    /// Number of raw inline-RAM stores recorded by the current compiled call.
    pub fn jit_store_count(&self) -> u64 {
        self.chain_u64(abi::CHAIN_STORE_COUNT)
    }

    /// Read one raw inline-RAM store record as `(virtual_addr, physical_addr, width_bytes)`.
    pub fn jit_store_record(&self, index: u64) -> Option<(u64, u64, u64)> {
        if index >= self.jit_store_count() || index >= u64::from(abi::CHAIN_STORE_CAPACITY) {
            return None;
        }
        let index = u32::try_from(index).ok()?;
        let base = abi::CHAIN_STORE_BASE + index * abi::CHAIN_STORE_ENTRY_BYTES;
        Some((
            self.chain_u64(base),
            self.chain_u64(base + 8),
            self.chain_u64(base + 16),
        ))
    }

    /// Drop the raw-store records after the host has applied their architectural side effects.
    pub fn clear_jit_store_log(&mut self) {
        self.put_chain_u64(abi::CHAIN_STORE_COUNT, 0);
    }
}

/// Exit header of one compiled call, read straight from a module's private state memory.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ModuleExitHeader {
    pub reason: i32,
    pub next_pc: u64,
    pub exit_info: u64,
}

#[inline(always)]
fn state_u64(state: &[u8], offset: u32) -> u64 {
    let at = offset as usize;
    u64::from_le_bytes(state[at..at + 8].try_into().expect("8-byte state word"))
}

#[inline(always)]
fn put_state_u64(state: &mut [u8], offset: u32, value: u64) {
    let at = offset as usize;
    state[at..at + 8].copy_from_slice(&value.to_le_bytes());
}

/// Native private-memory fast path of [`CpuStateHandoff::prepare`]: marshal the entry image
/// DIRECTLY into a module's own state memory (`state` starts at [`abi::XREG_BASE`]), with no
/// intermediate handoff buffer, producing exactly the bytes the generated code consumes.
///
/// `fp_image` is `None` for a block whose translated ops contain no F/D or FP-CSR op: such
/// generated code never reads or writes the FPR image or the FP state word, so neither is
/// transferred (the stale bytes left in the memory are unobservable). Otherwise it is the cached
/// `FRegs` mutation stamp that this memory's FPR image mirrors: the 256-byte image is copied only
/// when the hart's stamp differs, and the FP control word is refreshed on every FP entry (which
/// also clears the previous call's dirty mask).
pub fn prepare_module_state(
    state: &mut [u8],
    hart: &Hart,
    fp_image: Option<&mut Option<(u64, u64)>>,
) {
    let state = &mut state[..abi::HANDOFF_END as usize];
    for (register, word) in hart.regs.jit_words().iter().enumerate() {
        put_state_u64(state, abi::XREG_BASE + register as u32 * 8, *word);
    }
    if let Some(cached) = fp_image {
        let version = hart.fregs.jit_version();
        if *cached != Some(version) {
            for (register, word) in hart.fregs.jit_words().iter().enumerate() {
                put_state_u64(state, abi::FREG_BASE + register as u32 * 8, *word);
            }
            *cached = Some(version);
        }
        put_state_u64(
            state,
            abi::FP_STATE,
            u64::from(hart.csr.fflags | (hart.csr.frm << 5))
                | if hart.csr.fp_off() {
                    0
                } else {
                    abi::FP_ENABLED
                },
        );
    }
    put_state_u64(state, abi::ENTRY_PC, hart.regs.pc);
}

/// Native private-memory fast path of [`CpuStateHandoff::commit_registers`] +
/// [`CpuStateHandoff::commit_fp_registers`]: commit a returned module image straight from its
/// state memory and return the exit header. `fp_image` must be the same selector passed to the
/// matching [`prepare_module_state`]; after an FP commit it records the hart's new `FRegs` stamp,
/// because the memory's FPR image then equals the committed register file.
pub fn commit_module_state(
    state: &[u8],
    hart: &mut Hart,
    fp_image: Option<&mut Option<(u64, u64)>>,
) -> ModuleExitHeader {
    let state = &state[..abi::HANDOFF_END as usize];
    let mut words = [0_u64; 32];
    for (register, word) in words.iter_mut().enumerate().skip(1) {
        *word = state_u64(state, abi::XREG_BASE + register as u32 * 8);
    }
    hart.regs.jit_commit_words(&words);
    if let Some(cached) = fp_image {
        commit_fp_state(hart, |offset| state_u64(state, offset));
        *cached = Some(hart.fregs.jit_version());
    }
    ModuleExitHeader {
        reason: state_u64(state, abi::EXIT_REASON) as i32,
        next_pc: state_u64(state, abi::EXIT_PC),
        exit_info: state_u64(state, abi::EXIT_INFO),
    }
}

/// Shared FP commit: executed FPR writes (by the generated dirty mask) and the accrued — or, after
/// a generated `fflags`/`frm`/`fcsr` write, overwritten — FP control pair. Returns FPR bytes moved.
fn commit_fp_state(hart: &mut Hart, get_u64: impl Fn(u32) -> u64) -> u64 {
    let state = get_u64(abi::FP_STATE);
    let mut mask = (state >> 32) as u32;
    let bytes = u64::from(mask.count_ones()) * 8;
    while mask != 0 {
        let register = mask.trailing_zeros() as u8;
        hart.fregs
            .write_raw(register, get_u64(abi::FREG_BASE + u32::from(register) * 8));
        mask &= mask - 1;
    }
    if state & abi::FP_DIRTY != 0 {
        if state & abi::FP_CSR_WRITTEN != 0 {
            hart.csr.fflags = state as u8 & 0x1f;
            hart.csr.frm = (state >> 5) as u8 & 0x07;
        } else {
            hart.csr.accrue_fflags(state as u8 & 0x1f);
        }
        hart.csr.mark_fp_dirty();
    }
    bytes
}

/// The frozen exit-code enum (`docs/jit-architecture.md` §3.3). The E4-T09 translator emits only
/// the first three; the rest are reserved for later tickets and surfaced here so the run loop can
/// preserve the already-committed compiled state defensively if it ever sees one.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ExitCode {
    /// Block ran to its end; resume at `next_pc`.
    Fallthrough,
    /// Taken conditional branch / `jal` / `jalr`; resume at `next_pc`.
    BranchTaken,
    /// A guest trap (`ecall`/`ebreak`) must be delivered at `next_pc`.
    Trap,
    /// FS=Off at an FP instruction. `exit_info` holds its original instruction
    /// bits and `next_pc` its precise virtual PC; only the preceding prefix retired.
    IllegalInstruction,
    /// Partial-block exit (`CALL_INTERP`, code 6): the compiled prefix of a block retired and the
    /// block's first untranslated instruction must now be INTERPRETED at `next_pc`, as the
    /// continuation of the same decoded block (no block boundary / interrupt sample in between).
    /// `exit_info` = `(op_index << 56) | block_phys_start` names that decoded block and the index
    /// of the untranslated op; for a one-block call `op_index` is also the retired prefix length.
    CallInterp,
    /// Any reserved variant (MMIO/MMU_MISS/NOT_COMPILED/INTERRUPT_POLL) — not produced
    /// by the current translator; treated as a benign unlinked fall-through because the module
    /// register image has already been committed.
    Reserved(i32),
    /// The browser direct-chain fuel was exhausted before the next successor began. The compiled
    /// prefix has already committed and `JitExit::retired` reports its exact span.
    Budget,
}

impl ExitCode {
    /// Decode the `i32` a compiled `run` returns.
    pub fn from_i32(v: i32) -> Self {
        match v {
            0 => ExitCode::Fallthrough,
            1 => ExitCode::BranchTaken,
            2 => ExitCode::Trap,
            6 => ExitCode::CallInterp,
            9 => ExitCode::IllegalInstruction,
            8 => ExitCode::Budget,
            other => ExitCode::Reserved(other),
        }
    }
}

/// The result of a compiled-block execution. `next_pc` / `exit_info` mirror the header slots the
/// block wrote before returning.
///
/// E4-T12 adds `trap`: a PRECISE memory-fault side-exit. When a load/store in a compiled block
/// faults, the runtime does NOT unwind-and-re-interpret (which would re-execute any committing
/// side-effect earlier in the block — the MMIO-write-then-fault double-execute bug); instead it
/// reads back the block's already-written-back register file + faulting PC (the writeback-before-
/// any-trapping-op discipline, `docs/jit-architecture.md` §4) and hands the exact interpreter-
/// produced [`Trap`](crate::hart::Trap) here. The run loop delivers it through the normal
/// `take_trap` path, so mcause/mtval/mepc are produced by the ONE trusted trap implementation.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct JitExit {
    /// The exit code the block returned.
    pub code: ExitCode,
    /// Guest PC to resume at (the header `exit_pc`) — for a `Trap`/mem-fault exit this is the
    /// faulting instruction's PC (→ `mepc`).
    pub next_pc: u64,
    /// Aux payload (the header `exit_info`): trap cause for an `ecall`/`ebreak` `Trap` exit.
    pub exit_info: u64,
    /// `Some` iff a load/store faulted: the precise trap (cause + `mtval`) the interpreter's own
    /// translated/PMP-checked access path produced. The register file in the module's `CpuState`
    /// region is architecturally precise as of the instruction BEFORE the faulting one, and the
    /// runtime has already synced it back into `hart.regs`.
    pub trap: Option<crate::hart::Trap>,
    /// E4-T34: exact number of guest instructions retired by the compiled call, including any
    /// direct in-module successors. Zero means the legacy one-block executor did not provide the
    /// optional count; the core then derives the count from the decoded block as before.
    pub retired: u64,
}

/// E4-T20: the translation-cache budget (`docs/jit-architecture.md` §7 D10). Enforced at install
/// time; when a would-be install pushes any dimension over its high-water mark, eviction runs down
/// to a low-water mark (hysteresis) before the new batch is admitted. Because dropping a wasm
/// Instance's references does NOT free its memory synchronously (browser GC / wasmtime Store
/// reality), enforcement uses OUR OWN byte estimates ([`CompiledBlockExecutor::estimated_bytes`]),
/// never observed engine/browser memory.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct JitCacheBudget {
    /// Max estimated live translated-code bytes (emitted WASM + per-instance overhead).
    pub code_bytes: u64,
    /// Max live Modules/Instances (batches). Eviction granularity is the batch (E4-T19): you cannot
    /// free half a Module.
    pub max_batches: usize,
    /// Max allocated funcref-table slots (block table indices).
    pub table_slots: usize,
    /// Max estimated metadata bytes (link-slot array + table + incoming-edge maps).
    pub metadata_bytes: u64,
}

impl JitCacheBudget {
    /// The `docs/jit-architecture.md` §7 default: 32 MiB code, 256 Modules. `table_slots` /
    /// `metadata_bytes` are generous headroom around those (≈128 blocks/batch × 256 batches).
    pub const DEFAULT: JitCacheBudget = JitCacheBudget {
        code_bytes: 32 * 1024 * 1024,
        max_batches: 256,
        table_slots: 256 * 128,
        metadata_bytes: 8 * 1024 * 1024,
    };
}

impl Default for JitCacheBudget {
    fn default() -> Self {
        JitCacheBudget::DEFAULT
    }
}

/// E4-T20: the two eviction policies A/B'd behind a flag. Both drive the SAME single
/// [`evict_batch`](CompiledBlockExecutor::evict_batch_containing) obligation path; they differ only
/// in WHICH batches they pick at the high-water mark.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum EvictPolicy {
    /// (a) Full generational flush at high-water — QEMU `tb_flush` style: drop the whole cache, let
    /// hot code re-translate. Simple, correct, competitive.
    Flush,
    /// (b) Batch-LRU by last-executed coarse tick (stamped at dispatch entries; chained execution
    /// updates lazily). Evicts the least-recently-run batch repeatedly down to the low-water mark.
    BatchLru,
}

impl Default for EvictPolicy {
    /// Provisional default pending the A/B ledger (deferred to dev). `BatchLru` is the more graceful
    /// degrader under a working set that fits after a little churn; the choice is recorded as debt.
    fn default() -> Self {
        EvictPolicy::BatchLru
    }
}

/// E4-T20: a snapshot of the JIT translation-cache accounting — current usage vs budget, eviction
/// activity, and the re-translation rate (blocks recompiled after eviction — the thrash signal).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub struct JitCacheStats {
    /// Current estimated live code bytes.
    pub code_bytes: u64,
    /// Current live batch (Module/Instance) count.
    pub batches: usize,
    /// Current allocated table slots.
    pub table_slots: usize,
    /// Current estimated metadata bytes.
    pub metadata_bytes: u64,
    /// The active budget.
    pub budget: JitCacheBudget,
    /// The active policy.
    pub policy: EvictPolicy,
    /// Cumulative batches evicted (budget-driven, through the single `evict_batch` path).
    pub evictions: u64,
    /// Cumulative full generational-flush events.
    pub flushes: u64,
    /// Cumulative blocks recompiled AFTER having been evicted — the thrash numerator. Divide by
    /// `installs` for the re-translation rate.
    pub retranslations: u64,
    /// Cumulative blocks installed (compiled) — the re-translation-rate denominator.
    pub installs: u64,
    /// The eviction/invalidation generation counter (E4-T08); bumped on every evict/flush so any
    /// stale cached reference is refused.
    pub generation: u64,
}

/// E4-T37: cumulative browser dynamic-return PIC telemetry plus its bounded live state.
///
/// The default is deliberately zero so native and mock executors remain source-compatible; the
/// browser executor reports generated probe outcomes and its Rust-owned publication ledger.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct DynamicLinkStats {
    /// Generated dynamic-return probes.
    pub attempts: u64,
    /// Probes that passed the cache, chain, and EXEC-TLB authority guards.
    pub hits: u64,
    /// Probes that returned to the dispatcher instead of calling an indirect target.
    pub refusals: u64,
    /// Actual replacement of an existing live PIC entry after hysteresis was satisfied.
    pub retargets: u64,
    /// Current number of live virtual-target entries in the bounded PIC.
    pub live_entries: u64,
    /// Actual PIC entry publications, including replacements.
    pub installs: u64,
}

/// E4-T39: bounded entry-path cost ledger exported by a compiled-block executor.
///
/// The counters are deterministic guest-path observations. The nanosecond fields are optional
/// browser-side samples (zero for executors without a host timer), so the ledger can separate
/// structural work from the wall-clock controls without putting a host clock in `no_std` core.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct JitEntryCostStats {
    /// Whether the executor is currently permitted to sample its host entry clock.
    pub timing_enabled: bool,
    /// Actual host-clock reads made by the entry ledger. This remains exactly zero when timing is
    /// disabled, independently of the clock's resolution or the accumulated nanosecond values.
    pub timer_reads: u64,
    /// Host-side compiled-engine entries.
    pub host_entries: u64,
    /// State/register synchronization operations at those entries.
    pub state_copy_calls: u64,
    /// Bytes moved by state/register synchronization operations.
    pub state_copy_bytes: u64,
    /// Monotonic time spent in state/register synchronization, when sampled.
    pub state_copy_ns: u64,
    /// Monotonic time spent inside compiled engine entries, when sampled.
    pub engine_entry_ns: u64,
    /// Generated static/dynamic calls through the imported funcref table.
    pub indirect_table_dispatches: u64,
    /// Generated EXEC-TLB/authority predicates.
    pub authority_checks: u64,
    /// Host entries whose direct chain was stopped by an imported memory/device boundary.
    pub memory_split_exits: u64,
    /// Imported accesses resolved outside the inline guest-RAM fast path.
    pub device_boundaries: u64,
    /// Monotonic time spent in those device-boundary imports, when sampled.
    pub device_boundary_ns: u64,
}

/// JIT translation-coverage counters (diagnostic only; never architectural state).
///
/// A block is *full* when every op translated, *partial* when a translated prefix ends in a
/// [`ExitCode::CallInterp`] exit at the first untranslated op, and *rejected* when not even its
/// first op translates. `first_unsupported` histograms the first untranslated op of every partial
/// or rejected translation by mnemonic, most frequent first.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct TranslationCoverage {
    pub full_blocks: u64,
    pub partial_blocks: u64,
    pub rejected_blocks: u64,
    /// Runtime partial-block exits that handed the untranslated op to the interpreter.
    pub partial_exits: u64,
    pub first_unsupported: alloc::vec::Vec<(&'static str, u64)>,
}

impl JitCacheStats {
    /// Re-translation rate = retranslations / installs (the thrash signal). `0.0` before any install.
    pub fn retranslation_rate(&self) -> f64 {
        if self.installs == 0 {
            0.0
        } else {
            self.retranslations as f64 / self.installs as f64
        }
    }
}

/// The platform-boundary trait the run loop calls to run T2 (compiled) blocks. Implemented natively
/// by `wasm-vm-jit-runtime` (wasmtime); the browser impl is E4-T19. Object-safe so [`Machine`] can
/// hold a `Box<dyn CompiledBlockExecutor>` without pulling any engine into `no_std` core.
///
/// [`Machine`]: crate::Machine
pub trait CompiledBlockExecutor {
    /// Translate + compile + register the block keyed by its `phys_start`. A block the executor
    /// cannot translate (out-of-scope opcode) is silently skipped (it stays in the interpreter).
    fn install(&mut self, block: &DecodedBlock);

    /// E4-T19: translate + compile a GROUP of blocks (a connected component of the observed-edge
    /// graph) into ONE module of K functions — the batching unit (`docs/jit-architecture.md` §7),
    /// which amortizes per-Module / `WebAssembly.compile` fixed cost the browser is bound by.
    /// `intra[i][e]` is `Some(local)` iff block `i`'s edge `e` (0 = taken/sole/fall-through,
    /// 1 = branch not-taken) targets block `local` IN THIS SAME group — that edge is lowered to an
    /// intra-batch direct call; cross-batch edges reuse E4-T18's funcref-table link slots. The
    /// default impl installs each block singly (a valid non-batching executor); the wasmtime executor
    /// overrides it to build one module. A group whose translation fails (an out-of-scope op in ANY
    /// member) falls back to per-block installation of the translatable members.
    fn install_batch(&mut self, blocks: &[DecodedBlock], _intra: &[[Option<usize>; 2]]) {
        for b in blocks {
            self.install(b);
        }
    }

    /// E4-T19: set the batching knob K — the maximum number of blocks packed into one module. `1`
    /// is the adversarial one-block-per-module mode (registry-accounting stress). Default no-op.
    fn set_batch_size(&mut self, _k: usize) {}

    /// E4-T19: the current batching K.
    fn batch_size(&self) -> usize {
        1
    }

    /// Maximum number of newly translated blocks this executor may install during one public
    /// [`Machine::run`](crate::Machine::run) / `run_traced` call. Browser `runChunk` calls are the
    /// Worker scheduler's cooperative slices: allowing every periodic pump plus the final flush to
    /// install without a shared per-call ceiling turns one nominally bounded CPU quantum into an
    /// unbounded synchronous `WebAssembly.Module` compile stall. Native/mock executors retain the
    /// historical 64-block ceiling; the browser overrides this with a smaller latency budget.
    fn max_translation_attempts_per_run(&self) -> usize {
        64
    }

    /// Maximum discovery nominations staged into the priority compile queue during one public
    /// cooperative run. Staging a full discovery flood is itself synchronous work (including the
    /// bounded queue's backpressure comparisons), so it needs an aggregate ceiling independent of
    /// the smaller block-submission ceiling.
    fn max_staged_nominations_per_run(&self) -> usize {
        256
    }

    /// E4-T19 instance registry: number of live WASM Modules/Instances (batches) — the raw material
    /// for E4-T20's budgets. With no batching this equals [`Self::compiled_count`].
    fn module_count(&self) -> usize {
        self.compiled_count()
    }

    /// E4-T19 instance registry: estimated bytes held live across all Modules+Instances (emitted
    /// code size plus a fixed per-instance overhead estimate). Accurate accounting is the AC.
    fn estimated_bytes(&self) -> u64 {
        0
    }

    /// Is a compiled block registered for physical entry PC `phys_pc`?
    fn is_compiled(&self, phys_pc: u64) -> bool;

    /// Execute the compiled block for `phys_pc` against the live `hart`/`bus`. Guest registers are
    /// synced into the module's `CpuState` region before the call and read back into `hart.regs`
    /// on a clean return; guest memory is reached through `hart`'s translated load/store path so
    /// effects match the interpreter exactly.
    ///
    /// Returns `Some(exit)` on a clean return or a recorded precise guest fault. A defensive cache
    /// miss returns `None` before calling compiled code and without committing a module register
    /// image, allowing the guarded run loop to interpret from the same entry. Once the call has been
    /// attempted, an unclassified engine failure must fail closed rather than return `None`: an
    /// imported access may already have changed RAM, MMIO, or reservation state.
    fn execute(&mut self, phys_pc: u64, hart: &mut Hart, bus: &mut SystemBus) -> Option<JitExit>;

    /// Execute a compiled block with an optional bounded in-module chain. The default preserves the
    /// historical one-block call for native and test executors; the browser inline-memory executor
    /// overrides it to pass the remaining outer work budget and report an exact retired span that
    /// may include direct same-module successors.
    fn execute_with_budget(
        &mut self,
        phys_pc: u64,
        hart: &mut Hart,
        bus: &mut SystemBus,
        _remaining_work: u64,
        _chain_budget: u64,
        _allow_chaining: bool,
    ) -> Option<JitExit> {
        self.execute(phys_pc, hart, bus)
    }

    /// Drop every compiled block (`fence.i` / whole-cache flush / reset / snapshot restore).
    fn invalidate_all(&mut self);

    /// Publish a guarded virtual `jalr` target after the core has resolved it to a compiled
    /// physical block. Native executors keep the historical dispatch path; the browser imported
    /// memory executor may use the publication to call a matching funcref directly on a later hit.
    fn link_dynamic_target(&mut self, _virtual_pc: u64, _phys_pc: u64) {}

    /// Publish a statically-known edge together with the virtual-to-physical fetch observation that
    /// authorized it. The default preserves the historical three-argument link API for executors
    /// that do not need a generated EXEC-TLB guard; the browser executor overrides this to retain
    /// the exact virtual target alongside its physical page.
    fn link_edge_authorized(&mut self, from_phys: u64, edge: u8, to_virtual: u64, to_phys: u64) {
        let _ = to_virtual;
        self.link_edge(from_phys, edge, to_phys);
    }

    /// Drop every compiled block whose physical page frame is `frame` (SMC / DMA-into-code).
    fn invalidate_page(&mut self, frame: u64);

    /// Number of blocks currently compiled + registered.
    fn compiled_count(&self) -> usize;

    /// Count of compiled blocks executed via the JIT over this run (the "JIT actually ran" proof).
    fn executed_blocks(&self) -> u64;

    /// Count of guest instructions retired inside JIT-executed blocks (numerator of the
    /// translated-instruction ratio).
    fn retired_via_jit(&self) -> u64;

    /// Number of generated compiled-function entries made inside browser direct-chain calls.
    /// Native and non-chaining executors use the default zero; the browser implementation uses
    /// this to expose the actual logical-blocks-per-host-entry ledger.
    fn direct_chain_entries(&self) -> u64 {
        0
    }

    /// Number of in-module successor calls made by browser direct chaining. This is the function
    /// entry count minus the outer host-side entries, exposed separately so a verifier can check
    /// the boundary reduction without inferring it from unrelated dispatch statistics.
    fn direct_chain_links(&self) -> u64 {
        0
    }

    /// E4-T37: dynamic-return PIC telemetry. Native and non-browser executors do not publish a
    /// browser funcref cache and therefore retain the zero default.
    fn dynamic_link_stats(&self) -> DynamicLinkStats {
        DynamicLinkStats::default()
    }

    /// E4-T39: snapshot of the compiled entry-path cost ledger. Native and simple executors retain
    /// the zero default; the browser executor reports bounded counters and optional timer samples.
    fn entry_cost_stats(&self) -> JitEntryCostStats {
        JitEntryCostStats::default()
    }

    /// Translation-coverage diagnostics (full / partial / rejected blocks and the first
    /// untranslated op histogram). Executors without the ledger return the zero default.
    fn translation_coverage(&self) -> TranslationCoverage {
        TranslationCoverage::default()
    }

    /// Arm or disarm optional host-clock sampling in the compiled entry path. Structural counters
    /// remain live in both modes. The default is inert for native/simple executors without an
    /// entry timer.
    fn set_entry_timing(&mut self, _on: bool) {}

    /// E4-T31: record the exact retirement count the core committed for a compiled exit. The core,
    /// not the executor, owns this count because it can distinguish a clean block from a precise
    /// mid-block trap. Default no-op keeps simple/mock executors source-compatible.
    fn note_jit_retired(&mut self, _retired: u64) {}

    // ── E4-T20: cache budgets, eviction policy, and stats (default impls: an executor with no
    //    budget enforcement is a valid degenerate) ──

    /// Set the translation-cache budget enforced at install time.
    fn set_jit_budget(&mut self, _budget: JitCacheBudget) {}

    /// The active budget.
    fn jit_budget(&self) -> JitCacheBudget {
        JitCacheBudget::DEFAULT
    }

    /// Select the eviction policy (A/B flag).
    fn set_evict_policy(&mut self, _policy: EvictPolicy) {}

    /// The active eviction policy.
    fn evict_policy(&self) -> EvictPolicy {
        EvictPolicy::default()
    }

    /// A snapshot of the cache accounting (usage vs budget, evictions, re-translation rate).
    fn jit_cache_stats(&self) -> JitCacheStats {
        JitCacheStats::default()
    }

    /// E4-T20: drain the list of physical entry PCs whose compiled batch was EVICTED (budget-driven
    /// or directed) since the last drain. The run loop feeds these back to block discovery
    /// ([`crate::dispatch::BlockDiscovery::renominate`]) so an evicted-but-still-hot block is
    /// re-nominated and re-translated instead of being suppressed by dedup forever. Default empty.
    fn take_evicted(&mut self) -> alloc::vec::Vec<u64> {
        alloc::vec::Vec::new()
    }

    /// Directed-test / debug hook (AC3 "eviction under fire"): force-evict the batch that owns the
    /// block at `phys_pc`, through the single ordered `evict_batch` obligation path. Returns `true`
    /// iff a batch was evicted. A no-op that returns `false` if no such block is compiled.
    fn evict_batch_containing(&mut self, _phys_pc: u64) -> bool {
        false
    }

    // ── E4-T18: block chaining (default impls: a non-chaining executor is a valid degenerate) ──

    /// A/B flag: enable/disable direct block→block chaining. With chaining off every block returns
    /// to the dispatch loop (the E4-T10 behavior); with it on the dispatch loop follows link-slots.
    fn set_chaining(&mut self, _on: bool) {}

    /// Whether chaining is currently enabled.
    fn chaining(&self) -> bool {
        false
    }

    /// E4-T39: enable/disable generated dynamic-return (`jalr`) chaining independently from static
    /// region chaining. The default is a no-op for executors without a generated PIC.
    fn set_dynamic_chaining(&mut self, _on: bool) {}

    /// Whether generated dynamic-return chaining is enabled.
    fn dynamic_chaining(&self) -> bool {
        false
    }

    /// Set the chain-depth budget (max links per chain before a mandatory dispatch return, ≥ 1).
    fn set_chain_depth_budget(&mut self, _n: u32) {}

    /// The current chain-depth budget.
    fn chain_depth_budget(&self) -> u32 {
        1
    }

    /// Whether [`Self::execute_with_budget`] consumes the in-module direct-chain fuel. The run loop
    /// trims that fuel to the next timer deadline before EVERY host entry; an executor that never
    /// chains inside a module (the native one-block-per-call executor) returns `false` so the core
    /// skips the per-entry deadline computation. Defaults to `true` (always compute), which is
    /// behaviour-preserving for every executor.
    fn uses_direct_chain_fuel(&self) -> bool {
        true
    }

    /// Lazily link `edge` (0 = taken / sole / fall-through successor, 1 = not-taken) of the block at
    /// `from_phys` to the compiled successor at `to_phys`, recording the edge in the incoming-edges
    /// map. A no-op if either block is not live-compiled, `edge` is out of range for the block
    /// (a dynamic `jalr` target passes an out-of-range edge so it is never linked), the edge is
    /// already linked to the same target, or chaining is off. Counts one `links_made` on the
    /// transition from stub → linked.
    fn link_edge(&mut self, _from_phys: u64, _edge: u8, _to_phys: u64) {}

    /// The successor a block's link-slot currently points at, or `None` if the slot holds the
    /// dispatch stub / the edge is out of range / the block is not compiled. Used by the dispatch
    /// loop to follow a link and by the unlink-completeness test to assert slot contents.
    fn linked_target(&self, _from_phys: u64, _edge: u8) -> Option<u64> {
        None
    }

    /// Record that a chain of `depth` links returned to the dispatch loop (updates the histogram,
    /// `max_chain_depth`, and `dispatch_entries`).
    fn note_chain(&mut self, _depth: u32) {}

    /// A snapshot of the chaining statistics (links made/cut, dispatch entries, depth histogram).
    fn chain_stats(&self) -> ChainStats {
        ChainStats::default()
    }
}

/// A boxed executor, held by [`Machine`](crate::Machine). Aliased for readability at the field.
pub type BoxedExecutor = Box<dyn CompiledBlockExecutor>;

// ── E4-T18: block chaining (direct linking + safe unlinking) ─────────────────

/// E4-T18 default chain-depth budget: the maximum number of direct block→block links traversed
/// before the chain MUST return to the dispatch loop. This bounds (a) unbounded wasm call-stack
/// growth in the browser in-wasm `call_indirect` epilogue form (the native wasmtime orchestration
/// cannot grow the wasm stack — every `execute` fully returns — but it honors the identical budget
/// so the two backends behave the same), and (b) starvation of the boundary poll. `32` mirrors the
/// order-of-magnitude of the E4-T08 hotness threshold / batching unit and keeps the dispatch-loop
/// re-entry frequent enough that device/interrupt sampling stays responsive; it is a tunable
/// (`Machine::set_chain_depth_budget`), swept against the ledger like the other budgets. Interrupt
/// latency itself does NOT depend on this number — the instruction/interrupt budget is checked at
/// EVERY link (see `Machine::try_jit_block`), so a timer is delivered within one block (≤128 ops)
/// of becoming pending regardless of the chain-depth budget, even at budget = 1 (degenerate).
pub const CHAIN_DEPTH_BUDGET_DEFAULT: u32 = 32;

/// Number of buckets in the chain-depth histogram (`ChainStats::depth_hist`). Depth `d` is counted
/// in bucket `min(d, CHAIN_DEPTH_HIST_LEN - 1)`, so the last bucket is "that-many-or-more links".
pub const CHAIN_DEPTH_HIST_LEN: usize = 65;

/// E4-T18 chaining statistics (A/B + the histogram the ticket asks for). All counters are cumulative
/// across a run; `invalidate_all` tears live links down (counted in `links_cut`) but preserves the
/// counters so an A/B report survives a cache toggle.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ChainStats {
    /// Edges linked (a link-slot written from the dispatch stub to a live successor's table index).
    /// Counted once per distinct edge — re-traversing an already-linked edge does not re-count.
    pub links_made: u64,
    /// Link-slots restored to the dispatch stub by an invalidation (SMC / fence.i-path / eviction /
    /// reset). The unlink-completeness invariant: after any invalidation NO live slot points into a
    /// dead block, and every such restoration is counted here.
    pub links_cut: u64,
    /// Times a chain ended and control returned to the dispatch loop (the "dispatch-loop entries"
    /// stat — one per chain, however many links it followed).
    pub dispatch_entries: u64,
    /// The deepest chain (most links followed before a dispatch return) seen this run.
    pub max_chain_depth: u32,
    /// Histogram of chain depths: `depth_hist[min(depth, LEN-1)]` incremented per dispatch entry.
    pub depth_hist: [u64; CHAIN_DEPTH_HIST_LEN],
}

impl Default for ChainStats {
    fn default() -> Self {
        ChainStats {
            links_made: 0,
            links_cut: 0,
            dispatch_entries: 0,
            max_chain_depth: 0,
            depth_hist: [0; CHAIN_DEPTH_HIST_LEN],
        }
    }
}

impl ChainStats {
    /// Total links followed across all chains this run (Σ depth) — the numerator of "links per
    /// dispatch entry", the direct measure of how much dispatch-loop bouncing chaining removed.
    pub fn total_links_followed(&self) -> u64 {
        self.depth_hist
            .iter()
            .enumerate()
            .map(|(d, n)| d as u64 * n)
            .sum()
    }
}

#[cfg(test)]
mod tests {
    use super::{CpuStateHandoff, abi};
    use crate::hart::Hart;

    #[test]
    fn fp_handoff_exact_offsets_dirty_mask_and_copy_elision() {
        let mut hart = Hart::default();
        let mut handoff = CpuStateHandoff::default();
        hart.fregs.write_raw(0, 0x1234);
        hart.fregs.write_raw(31, 0x9876);
        assert_eq!(handoff.prepare_fp_registers(&hart), 256);
        assert_eq!(handoff.prepare_fp_registers(&hart), 0);
        assert_eq!(handoff.as_bytes()[0x108..0x110], 0x1234_u64.to_le_bytes());
        assert_eq!(handoff.as_bytes()[0x200..0x208], 0x9876_u64.to_le_bytes());
        hart.fregs.write_raw(31, 0xabcd);
        assert_eq!(handoff.prepare_fp_registers(&hart), 256);
        handoff.prepare_fp_control(&hart);
        assert_eq!(handoff.get_u64(0x208), 0);
        handoff.put_u64(0x108, 0xffff_ffff_7fa0_0001);
        handoff.put_u64(0x200, 0xffff_ffff_8000_0000);
        handoff.put_u64(0x208, (0x8000_0001_u64 << 32) | (1 << 9));
        assert_eq!(handoff.commit_fp_registers(&mut hart), 16);
        assert_eq!(hart.fregs.read_raw(0), 0xffff_ffff_7fa0_0001);
        assert_eq!(hart.fregs.read_raw(31), 0xffff_ffff_8000_0000);
        assert_eq!(hart.fregs.read_raw(1), 0);
        assert_eq!(hart.csr.fs(), 3);
        assert_eq!(handoff.prepare_fp_registers(&hart), 0);
        handoff.prepare_fp_control(&hart);
        assert_eq!(handoff.get_u64(0x208), 1 << 8, "old dirty mask is cleared");
        let before = hart.fregs.jit_version();
        assert_eq!(handoff.commit_fp_registers(&mut hart), 0);
        assert_eq!(hart.fregs.jit_version(), before);
        hart.fregs = hart.fregs.clone();
        assert_eq!(
            handoff.prepare_fp_registers(&hart),
            256,
            "clone has a fresh identity"
        );
        assert_eq!(handoff.as_bytes().len(), 568);
    }

    #[test]
    fn cpu_state_handoff_pins_frozen_layout_endian_and_x0() {
        assert_eq!(abi::XREG_END, 0x100);
        assert_eq!(abi::HANDOFF_END, 0x238);
        assert_eq!(abi::HANDOFF_LEN, 568);
        const { assert!(abi::HANDOFF_END < abi::CHAIN_ENABLED) };
        assert_eq!(abi::CHAIN_DEPTH, 0x260);
        assert_eq!(abi::CHAIN_STORE_BASE, 0x268);

        let mut hart = Hart::default();
        hart.regs.pc = 0x0123_4567_89ab_cdef;
        for register in 1..32u8 {
            hart.regs.write(
                register,
                0x8000_0000_0000_0000 | (u64::from(register) * 0x0102_0304_0506_0708),
            );
        }
        let mut handoff = CpuStateHandoff::default();
        handoff.prepare(&hart);

        assert_eq!(handoff.as_bytes().len(), 568);
        assert_eq!(&handoff.as_bytes()[0..8], &0u64.to_le_bytes());
        for register in 1..32u8 {
            let start = register as usize * 8;
            assert_eq!(
                &handoff.as_bytes()[start..start + 8],
                &hart.regs.read(register).to_le_bytes()
            );
        }
        assert_eq!(
            &handoff.as_bytes()[abi::ENTRY_PC as usize..abi::HANDOFF_END as usize],
            &hart.regs.pc.to_le_bytes()
        );

        handoff.put_u64(abi::XREG_BASE, u64::MAX);
        for register in 1..32u8 {
            handoff.put_u64(
                abi::XREG_BASE + u32::from(register) * 8,
                0xfedc_ba98_7654_0000 | u64::from(register),
            );
        }
        handoff.put_u64(abi::EXIT_REASON, 2);
        handoff.put_u64(abi::EXIT_PC, 0x8877_6655_4433_2211);
        handoff.put_u64(abi::EXIT_INFO, 0xff00_ee11_dd22_cc33);
        handoff.commit_registers(&mut hart);

        assert_eq!(hart.regs.read(0), 0);
        for register in 1..32u8 {
            assert_eq!(
                hart.regs.read(register),
                0xfedc_ba98_7654_0000 | u64::from(register)
            );
        }
        assert_eq!(handoff.exit_reason(), 2);
        assert_eq!(handoff.exit_pc(), 0x8877_6655_4433_2211);
        assert_eq!(handoff.exit_info(), 0xff00_ee11_dd22_cc33);
    }
}
