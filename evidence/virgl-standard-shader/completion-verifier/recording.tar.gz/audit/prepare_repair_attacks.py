from pathlib import Path
import json, struct, math, random, sys

out = Path(sys.argv[1]); native = out / 'native'; native.mkdir(parents=True, exist_ok=True)
cases = []
def add(name, a, okay=True, kind=0, b='', code=None):
    cases.append(dict(name=name, a=a, b=b, okay=okay, kind=kind, code=code))
def prog(stage, decl, body):
    return ('FRAG' if stage else 'VERT')+'\n'+decl+'\n'+''.join('%d: %s\n'%(i,s) for i,s in enumerate(body+['END']))
def ordinary(stage, decl='', read='CONST[0]'):
    return prog(stage, decl+'\nDCL OUT[0], '+('COLOR' if stage else 'POSITION'), ['MOV OUT[0], '+read])
vs = prog(0, 'DCL IN[0]\nDCL OUT[0], POSITION', ['MOV OUT[0], IN[0]'])
fs = ordinary(1, 'DCL CONST[0]')
add('healthy-vertex', vs); add('healthy-fragment', fs, kind=1)
for stage in (0,1):
    for high in (1,17,127,255,511):
        for order in (0,1,2):
            zero='DCL CONST[0]'; other='DCL CONST[%d]'%high
            gap='\nIMM[0] UINT32 {4294967295,2147483648,1,33}\nDCL SAMP[15]\nDCL SVIEW[15], 2D, FLOAT\nDCL TEMP[511]\n'
            decl = zero+'\n'+other if order==0 else other+'\n'+zero if order==1 else other+gap+zero
            add('constant-high-%d-stage-%d-order-%d'%(high,stage,order), ordinary(stage,decl,'CONST[%d].wzyx'%high),kind=stage)
    for seed in (0x41584117,0x7ec311d4,0x5c099cab):
        rng=random.Random(seed)
        for trial in range(8):
            indices=[0,1,3,17,511];rng.shuffle(indices)
            decl=[]
            for i,index in enumerate(indices):
                decl.append('DCL CONST[%d]'%index)
                if i%2==0:decl.append('DCL SAMP[%d]'%i)
            decl.append('DCL SVIEW[15], 2D, FLOAT')
            add('shuffle-%d-%d-%d'%(seed,stage,trial),ordinary(stage,'\n'.join(decl),'CONST[511]'),kind=stage)
    for name,decl,source in [
        ('duplicate-zero','DCL CONST[511]\nDCL CONST[0]\nDCL CONST[0]','CONST[511]'),
        ('overlap-zero','DCL CONST[511]\nDCL CONST[0..3]\nDCL CONST[0]','CONST[511]'),
        ('direct-hole','DCL CONST[511]\nDCL CONST[0]','CONST[1]'),
        ('multidim-zero','DCL CONST[511]\nDCL CONST[0][0]','CONST[511]'),
        ('indirect-decl','DCL ADDR[0]\nDCL CONST[511]\nDCL CONST[ADDR[0].x]','CONST[511]'),
        ('past-end','DCL CONST[512]\nDCL CONST[0]','CONST[0]'),
        ('wrapped','DCL CONST[4294967296]\nDCL CONST[0]','CONST[0]')]:
        add('constant-reject-%d-%s'%(stage,name),ordinary(stage,decl,source),False,kind=stage)
    for slots in ([],[0],[15],[0,15],[3,11,15],list(range(16))):
        for family in ('samp-only','sview-only','both','both-reverse'):
            decl=['DCL CONST[0]']
            for slot in slots:
                s='DCL SAMP[%d]'%slot;v='DCL SVIEW[%d], 2D, FLOAT'%slot
                decl.extend([s] if family=='samp-only' else [v] if family=='sview-only' else [s,v] if family=='both' else [v,s])
            add('unused-%d-%s-%s'%(stage,family,slots),ordinary(stage,'\n'.join(decl)),kind=stage)
    for used,unused in (([0],[15]),([15],[0]),([0,15],[3,11]),([3,11,15],[0])):
        decl=['DCL CONST[0]','DCL TEMP[0..3]']
        for slot in used+unused:decl.extend(['DCL SVIEW[%d], 2D, FLOAT'%slot,'DCL SAMP[%d]'%slot])
        body=['TEX TEMP[%d], CONST[0], SAMP[%d], 2D'%(i,slot) for i,slot in enumerate(used)]
        body+=['MOV OUT[0], TEMP[0]']
        add('used-mask-%d-%s-%s'%(stage,used,unused),prog(stage,'\n'.join(decl)+'\nDCL OUT[0], '+('COLOR' if stage else 'POSITION'),body),kind=stage)
    for used in (0,15):
        for missing in ('SAMP','SVIEW'):
            other=15-used
            decl=['DCL CONST[0]','DCL SAMP[%d]'%other,'DCL SVIEW[%d], 2D, FLOAT'%other]
            decl.append(('DCL SVIEW[%d], 2D, FLOAT' if missing=='SAMP' else 'DCL SAMP[%d]')%used)
            add('unused-does-not-grant-read-%d-%d-%s'%(stage,used,missing),prog(stage,'\n'.join(decl)+'\nDCL OUT[0], '+('COLOR' if stage else 'POSITION'),['TEX OUT[0], CONST[0], SAMP[%d], 2D'%used]),False,kind=stage)
# These reachable arms were absent from the prior recorded matrices.
for name,decl in [('sv-color','DCL SV[0], COLOR'),('sview-comma','DCL SVIEW[0] 2D, FLOAT')]:
    add('guard-closure-'+name,ordinary(1,'DCL CONST[0]\n'+decl),False,kind=1)

# Two fresh, well-defined physical probes combine the repaired token movement
# with unused high sampler declarations. Immutable CPU math is recorded first.
plans=[]
for stage,seed in [('fragment',0x41584117),('vertex',0x7ec311d4)]:
    rng=random.Random(seed);a=[.5+rng.randrange(12)/16 for _ in range(4)];scale=[.125+rng.randrange(8)/32 for _ in range(4)];base=[.125,.25,.375,.5]
    decl='DCL CONST[4]\nIMM[0] UINT32 {1,2,31,33}\nDCL SAMP[15]\nDCL SVIEW[15], 2D, FLOAT\nDCL CONST[1..3]\nDCL TEMP[0..5]\nDCL ADDR[0]\nDCL CONST[0]'
    body=['MOV TEMP[5], CONST[3]','MOV TEMP[1], CONST[3]','MOV TEMP[2], CONST[3]','MOV TEMP[3], CONST[3]','ARL ADDR[0].x, CONST[0].xxxx','MOV TEMP[0], CONST[ADDR[0].x]','EX2 TEMP[1].yz, TEMP[0].yxwz','LG2 TEMP[2].xw, TEMP[0].zwxy','SIN TEMP[3].xz, -|TEMP[0].wzyx|','COS TEMP[5].zw, TEMP[0].zywx','NOT TEMP[4], IMM[0]','UADD TEMP[4], -TEMP[4], IMM[0]','USEQ TEMP[4], TEMP[4], CONST[4]','UIF TEMP[4].xxxx :21','MUL TEMP[0], TEMP[0], CONST[2]','ADD TEMP[0].xy, TEMP[0], TEMP[1].yzyz','SUB TEMP[0].zw, TEMP[0], TEMP[2].wxwx','ADD TEMP[0].xz, TEMP[0], -TEMP[3].xzxz','ADD TEMP[0].yw, TEMP[0], TEMP[5].zwzw','MOV OUT[0], TEMP[0]','ELSE :23','MOV OUT[0], CONST[3]','ENDIF']
    # Explicit branch labels reference ELSE20/ENDIF22 (shifted by one in vertex).
    body[13]='UIF TEMP[4].xxxx :20';body[20]='ELSE :22'
    fragment=prog(1,decl+'\nDCL OUT[0], COLOR',body);vertex=vs
    if stage=='vertex':
        vb=['MOV OUT[0], IN[0]']+[s.replace('OUT[0]','OUT[1]') for s in body]
        vb[14]='UIF TEMP[4].xxxx :21';vb[21]='ELSE :23'
        vertex=prog(0,'DCL IN[0]\nDCL OUT[0], POSITION\nDCL OUT[1], GENERIC[0]\n'+decl,vb)
        fragment=prog(1,'DCL IN[0], GENERIC[0], CONSTANT\nDCL SAMP[14]\nDCL SVIEW[14], 2D, FLOAT\nDCL OUT[0], COLOR',['MOV OUT[0], IN[0]'])
    m=[x*y for x,y in zip(a,scale)];e=2**a[1];l=math.log2(a[2]);s=math.sin(-abs(a[3]));c=math.cos(a[2]);expected=[m[0]+e-s,m[1]+e+c,m[2]-l-s,m[3]-l+c]
    words=[struct.unpack('<I',struct.pack('<f',x))[0] for x in [1.75,0,0,0]+a+scale+base]+[3,5,63,67]
    plan=dict(stage=stage,seed=seed,vertexText=vertex,fragmentText=fragment,a=a,scale=scale,base=base,expected=expected,budget=.00005,width=16,height=16)
    plan['vertexWords' if stage=='vertex' else 'fragmentWords']=words;plans.append(plan)
    add('physical-repair-'+stage,vertex,kind=2,b=fragment)
(native/'cases.json').write_text(json.dumps(dict(cases=cases,seeds=[0x41584117,0x7ec311d4,0x5c099cab],originals=[]),indent=2)+'\n')
parts=[struct.pack('<I',len(cases))]
for case in cases:
    parts.append(struct.pack('<I',case['kind']))
    for key in ['a','b']:
        raw=case[key].encode();parts.extend([struct.pack('<I',len(raw)),raw])
(native/'cases.bin').write_bytes(b''.join(parts));(out/'physical-plan.json').write_text(json.dumps(plans,indent=2)+'\n')
print(len(cases),'pre-recorded repair cases; two independently predicted physical plans')
