#!/usr/bin/env python3
import gzip,hashlib,io,json,pathlib,re,shutil,subprocess,tarfile
ROOT=pathlib.Path('/Users/blamy/.codex/worktrees/mips-throughput/wasm-vm')
HERE=pathlib.Path(__file__).parent
OUT=ROOT/'evidence/virgl-standard-shader/completion-verifier'
STAGE=HERE/'completion-recording'
STAGE.mkdir(exist_ok=True);OUT.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def save(path,value):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2)+'\n')
def copy(src,dest):dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
def tree(src,dest):
 for p in sorted(src.rglob('*')):
  if p.is_file():copy(p,dest/p.relative_to(src))
final=ROOT/'target/evidence/virgl-standard-shader-completion-verifier/combined-final'
physical=ROOT/'target/evidence/virgl-standard-shader-completion-verifier/combined'
assert (final/'physical-plan.json').read_bytes()==(physical/'physical-plan.json').read_bytes()
tree(final,STAGE/'suite')
for name in ('hardware','sabotage-sine','sabotage-oracle'):tree(physical/name,STAGE/'suite'/name)
for name in ('hardware.log','sabotage-sine.log','sabotage-oracle.log','physical-audit.json'):copy(physical/name,STAGE/'suite'/name)
audit_names=['predictions.json','final-authentication.json','carry-forward-authentication.json','profile-authentication.json','coverage-audit.json','coverage_audit.py','wrapper-v8-coverage-complete.json','final-unhit-branches.json','final-combined-worker-critic-coverage.json','final-combined-worker-critic-lines.txt','final-combined-worker-critic.profdata','cold-pixels.log','cold-metadata.log','build-debug.log','debug-predictions.json','debug-ordering-predictions.json','debug-input-correction.json','debug-cases.json','debug-cases.bin','debug-fault-audit.json','debug-faults.profdata','debug-faults-coverage.json','debug-faults-lines.txt','build-debug.sh','standard-debug','prepare_repair_attacks.py','seal_completion.py','pressure-v8.log']
for name in audit_names:copy(HERE/name,STAGE/'audit'/name)
for p in sorted(HERE.glob('*.lldb.log')):copy(p,STAGE/'audit'/p.name)
for p in sorted(HERE.glob('*drift.profraw')):copy(p,STAGE/'audit'/p.name)
for name in ('discarded-upstream-output-bound.profraw','invalid-zero-declaration-token.profraw'):copy(HERE/name,STAGE/'audit'/name)
for p in sorted(HERE.glob('standard-debug.dSYM/**/*')):
 if p.is_file():copy(p,STAGE/'audit'/p.relative_to(HERE))
for p in sorted(HERE.glob('*-reexport.json')):copy(p,STAGE/'audit'/p.name)
for p in sorted(HERE.glob('*-reexport.profdata')):copy(p,STAGE/'audit'/p.name)
for folder in ('node-v8','pressure-v8'):tree(HERE/folder,STAGE/'audit'/folder)
runtime=['renderer/virgl-shader/bridge.c','renderer/virgl-shader/bridge.h','renderer/virgl-shader/standard_guard.c','renderer/virgl-shader/standard_guard.h','renderer/virgl-shader/standard_emit.c','renderer/virgl-shader/standard_emit.h','renderer/virgl-shader/standard.mjs','renderer/virgl-shader/build.sh','renderer/virgl-shader/STANDARD.md','renderer/virgl-shader/native_tests/standard_compiler.c','renderer/virgl-shader/native_tests/standard_allocations.c']
frozen='1c17b508d0dc52199613f4c4883486c477773203'
bindings={}
for path in runtime:
 expected=subprocess.check_output(['git','show',frozen+':'+path],cwd=ROOT)
 assert (ROOT/path).read_bytes()==expected,path
 copy(ROOT/path,STAGE/'runtime'/path);bindings[path]=dict(bytes=len(expected),sha256=sha(ROOT/path),head=frozen)
promoted=['Makefile','renderer/virgl-shader/tests/standard-adversarial.mjs','tools/verify-virgl-standard-shader-adversarial.sh','tools/virgl-standard-shader/adversarial-cases.py','tools/virgl-standard-shader/adversarial-browser.mjs','tools/virgl-standard-shader/adversarial-pixels.py','tools/virgl-standard-shader/adversarial-pressure.mjs']
for path in promoted:copy(ROOT/path,STAGE/'promoted-source'/path)
receipt=load(HERE/'sealed/hot/receipt.json')
binary_bindings={}
for path in ['renderer/virgl-shader/build/standard-native/standard-test','renderer/virgl-shader/build/standard-sanitize/standard-test','renderer/virgl-shader/build/wasm/virgl-shader.mjs','renderer/virgl-shader/build/wasm/virgl-shader.wasm']:
 source=HERE/'sealed/hot-generated'/path
 assert source.exists();entry=receipt['generated'][path];expected=entry if isinstance(entry,str) else entry['sha256']
 assert sha(source)==expected and sha(ROOT/path)==expected,path
 binary_bindings[path]=dict(sha256=expected,bytes=source.stat().st_size,source='worker declaration-repair recording hot-generated/'+path)
save(STAGE/'audit/source-binary-bindings.json',dict(runtime=bindings,binaries=binary_bindings,workerArchive=load(HERE/'final-authentication.json')['archiveSha256'],currentClaimCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()))
cases=load(final/'native/cases.json')['cases'];rows=[json.loads(s) for s in (final/'native/native.jsonl').read_text().splitlines()]
assert len(cases)==len(rows)==695 and (final/'native/native.jsonl').read_bytes()==(final/'native/sanitize.jsonl').read_bytes()
assert load(final/'native/metadata.json')==dict(status='passed',cases=695,accepted=208,independentPinnedTgsi=True)
selected=[]
for i,(case,row) in enumerate(zip(cases,rows)):
 assert row['case']==i and row['result']['ok']==case['okay']
 if i>=532:selected.append(dict(name=case['name'],line=i+1,okay=row['result']['ok'],error=row['result'].get('error'),uniforms=[s['metadata']['uniforms'] for s in ([row['result']] if case['kind']!=2 else [row['result']['vertex'],row['result']['fragment']])] if row['result']['ok'] else [],samplers=[s['metadata']['samplers'] for s in ([row['result']] if case['kind']!=2 else [row['result']['vertex'],row['result']['fragment']])] if row['result']['ok'] else []))
save(STAGE/'audit/repair-case-points.json',selected)
pixels=load(physical/'physical-audit.json');assert pixels['status']=='passed' and pixels['frames']==8 and pixels['pixels']==2048
coverage=load(HERE/'coverage-audit.json');assert coverage['status']=='closed' and coverage['remainingNeedsEvidence']==[]
auth=load(HERE/'final-authentication.json');assert auth['status']=='passed'
prediction_ids=[p['id'] for p in load(HERE/'predictions.json')['predictions']]
points={
 'R1-final-custody':'audit/final-authentication.json; all417 members, hot/cold receipts and exact frozen source/binaries authenticate.',
 'R2-constant-order':'audit/repair-case-points.json and suite/native/native.jsonl lines533-692; metadata uniform extent equals independently parsed maximum; both stages/high511/zero late.',
 'R3-token-custody':'suite/hardware/report.json frames[6:8], suite/physical-plan.json, pixel bytes and audit/coverage-audit.json; two repair plans preserve immediate words, indirect addressing and explicit branch targets.',
 'R4-constant-rejection':'audit/repair-case-points.json, suite/native/native.jsonl and audit/constant-extent-drift.lldb.log:2325/2326; duplicate/overlap/hole/wrapped/dimensional inputs reject; injected513 versus512 still rejects.',
 'R5-sampler-declarations':'audit/repair-case-points.json; unused SAMP/SVIEW and all16 masks admit while public sampler arrays are only TEX reads; audit/declared-mask-drift.lldb.log binds guarded32768 to upstream32768 and rejects injected0.',
 'R6-sampler-rejection':'suite/native/native.jsonl lines685-688; unrelated unused slot does not grant missing SAMP/SVIEW reads; malformed operands and unsupported target rejected by carried worker/critic cases.',
 'R7-pixels-repair':'suite/physical-audit.json points[6:8] and hardware/pixels/frame-6-0.f32.gz,frame-7-0.f32.gz; native highp budgets pass; all browser error arrays empty.',
 'R8-legacy-isolation':'audit/carry-forward-authentication.json; complete old bridge prefix equals predecessor except two includes, guard/emitter/wrapper byte-identical to earlier critic boundary; final hot/cold retained ordinary/raw/private recordings authenticate.',
 'R9-sufficiency':'audit/coverage-audit.json;51 changed hunks,49 explicitly classified zero native-arm entries, actualWasm parser pressure, five fault/recovery probes, both detailedV8 wrapper profiles. No needs-evidence or dead-feature entry.'}
verdict=dict(schema='virgl-standard-shader-completion-verdict-v1',task='E6-T11d4',verdict='verified',predecessor='97ed2ca31f08465e442c88aed3a677237f78e236',frozenRuntime=frozen,workerClaimCommit='8101e82c2228012ff6a7435da8ab03e31f4e975d',predictions=[dict(id=i,outcome='HELD',citation=points[i]) for i in prediction_ids],carryForward=load(HERE/'predictions.json')['carryForward'],fresh=dict(cases=695,accepted=208,hardwareFrames=8,pixels=2048,repairSeeds=[1096302871,2126713300],faults=5,sineSabotage=pixels['faults'][0],oracleSabotage=pixels['faults'][1]),coverage=dict(hunks=51,classifiedZeroNativeArmEntries=49,remainingNeedsEvidence=[]),suite=dict(promoted=promoted[1:],verifyTarget='make verify-E6-T11d4-adversarial',validation='Exact recipe components run against authenticated worker native/sanitized/Wasm bytes; source/build modes are the frozen worker hot+cold build modes. make -n and bash -n checked the new recipe. No redundant runtime rebuild or cold clone after test-only promotion.'),scope='Isolated bounded standard compiler/native-highp semantics; no exact/private authority, production capsets, full API/guest boot, GPU execution-time bound or throughput claim.',implementationFixes=[])
save(STAGE/'verdict.json',verdict);save(OUT/'verdict.json',verdict)
save(STAGE/'audit/commands.json',dict(native='Extracted authenticated frozen hot-generated standard-native/standard-test suite/native/cases.bin > native.jsonl; same with standard-sanitize and LLVM_PROFILE_FILE for695 cases; outputs cmp equal.',metadata='python3 tools/virgl-standard-shader/metadata.py combined-final/native; separately decode pinned native TGSI records.',wasm='NODE_V8_COVERAGE=<private>/node-v8 node tools/virgl-standard-shader/node.mjs combined-final/native; NODE_V8_COVERAGE=<private>/pressure-v8 node tools/virgl-standard-shader/adversarial-pressure.mjs combined-final.',hardware='node tools/virgl-standard-shader/adversarial-browser.mjs --output combined/hardware --inputs combined; --fault sine and --fault oracle both exited1 at physical mismatch; offline adversarial-pixels.py passed.',coverage='Reexport all four worker hot/cold matrix/allocation profiles; exact exports equal. Merge hot matrix+allocation+695 critic; export/show against authenticated sealed sanitizer binary. Run five LLDB faults on privately rebuilt unmodified source; export their separate debug coverage.',cold='Authenticate exact1c pristine worker cold clone, receipts, generated bytes, full recording; independent metadata.py and pixels.mjs cold replay passed.',policy='Host rr waived by AGENTS; no GitHub Actions or merge. Runtime unchanged; verifier writes only test/evidence/Makefile/task/status/Queue.'))
records=[]
for path in sorted(STAGE.rglob('*')):
 if path.is_file():records.append(dict(path=str(path.relative_to(STAGE)),bytes=path.stat().st_size,sha256=sha(path)))
save(OUT/'records.json',dict(schema='content-addressed-verifier-recording-v1',records=records))
with (OUT/'recording.tar.gz').open('wb') as f:
 with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0,compresslevel=6) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tf:
   for rec in records:
    p=STAGE/rec['path'];info=tarfile.TarInfo(rec['path']);info.size=rec['bytes'];info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(p.read_bytes()))
manifest=dict(schema='virgl-standard-shader-completion-recording-v1',task='E6-T11d4',verdict='verified',sourceHead=frozen,workerClaimCommit=verdict['workerClaimCommit'],workerArchiveSha256=auth['archiveSha256'],priorCriticArchiveSha256=verdict['carryForward']['criticArchive'],records=len(records),archiveBytes=(OUT/'recording.tar.gz').stat().st_size,archiveSha256=sha(OUT/'recording.tar.gz'),indexSha256=sha(OUT/'records.json'),verdictSha256=sha(OUT/'verdict.json'),freshCases=695,acceptedCases=208,hardwareFrames=8,pixels=2048)
save(OUT/'manifest.json',manifest)
for source,dest in [('coverage-audit.json','coverage-audit.json'),('final-authentication.json','authentication.json'),('predictions.json','predictions.json')]:copy(HERE/source,OUT/dest)
with tarfile.open(OUT/'recording.tar.gz') as tf:
 assert len(tf.getmembers())==len(records)
 for rec in records:
  data=tf.extractfile(rec['path']).read();assert len(data)==rec['bytes'] and hashlib.sha256(data).hexdigest()==rec['sha256']
print(json.dumps(manifest,indent=2))
