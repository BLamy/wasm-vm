from pathlib import Path
import json,struct,math,shutil
OUT=Path('target/evidence/virgl-standard-shader-verifier');NATIVE=OUT/'independent';NATIVE.mkdir(exist_ok=True)
shutil.copytree(OUT/'unpacked/hot/abi',OUT/'abi',dirs_exist_ok=True)
VS='VERT\nDCL IN[0]\nDCL OUT[0], POSITION\n0: MOV OUT[0], IN[0]\n1: END\n'
FS='FRAG\nDCL CONST[0]\nDCL OUT[0], COLOR\n0: MOV OUT[0], CONST[0]\n1: END\n'
cases=[]
def add(name,a,okay=True,kind=0,b='',code=None):cases.append(dict(name=name,a=a,b=b,okay=okay,kind=kind,code=code))
def prog(stage,decl,body):return ('VERT' if stage==0 else 'FRAG')+'\n'+decl+'\n'+''.join(f'{i}: {s}\n' for i,s in enumerate(body+['END']))
add('healthy-owned-vertex',VS)
add('healthy-owned-fragment',FS,kind=1)
# Record predictions first. Each rejection changes precisely one grammatical
# boundary in otherwise valid input; its cause cannot hide behind undeclared IO.
for s in ['', ' ', '\n', 'VERT', 'VERT\n', '\tFRAG\n', 'GEOM\n', 'VERTX\n', 'VERT_\n', 'VERT 0\n']:
 add('missing-header-or-end-'+repr(s),s,False)
for op in ['MOV','SIN','COS','RCP','EX2','LG2','SQRT','RSQ','I2F','U2F','INEG','NOT']:
 for mod in ['', '-', '|', '-|']:
  floating=op not in ['I2F','U2F','INEG','NOT']
  operand=mod+'CONST[0].wzyx'+('|' if mod.endswith('|') else '')
  add('modifier-'+op+'-'+mod,prog(1,'DCL CONST[0]\nDCL TEMP[0]\nDCL OUT[0], COLOR',[op+' TEMP[0], '+operand,'MOV OUT[0], TEMP[0]']),not mod.endswith('|') or floating,kind=1)
for name,decl in [
 ('out-missing-semantic','DCL OUT[1]'),('frag-output-position','DCL OUT[1], POSITION'),('frag-output-generic','DCL OUT[1], GENERIC[0]'),('sv-generic','DCL SV[0], GENERIC[0]'),('sv-position','DCL SV[0], POSITION'),('sv-instance-frag','DCL SV[0], INSTANCEID'),
 ('no-semantic','DCL IN[0]'),('io-range','DCL IN[0..1], GENERIC[0], CONSTANT'),('out-range','DCL OUT[1..2], COLOR[1]'),('imm-decl','DCL IMM[0]'),('masked-temp','DCL TEMP[0].xy'),('masked-const','DCL CONST[0].xy'),('missing-sview-type','DCL SVIEW[0], 2D'),('bad-sview-dim','DCL SVIEW[0], 3D, FLOAT'),('nonconstant-frag-position','DCL IN[0], POSITION, PERSPECTIVE'),('generic-linear','DCL IN[0], GENERIC[0], LINEAR'),('unknown-interp','DCL IN[0], GENERIC[0], FLAT'),('out-color-wrap','DCL OUT[1], COLOR[4294967296]'),('dup-color','DCL OUT[1], COLOR'),('broadcast-extra','PROPERTY FS_COLOR0_WRITES_ALL_CBUFS 1\nDCL OUT[1], COLOR[1]')]:
 add(name,prog(1,'DCL CONST[0]\nDCL OUT[0], COLOR\n'+decl,['MOV OUT[0], CONST[0]']),False,kind=1)
for decl in ['DCL OUT[1].x, POSITION','DCL SV[0], COLOR','DCL SV[0], VERTEXID\nDCL SV[1], VERTEXID']:
 add('vertex-decl-'+decl,VS.replace('0: MOV',decl+'\n0: MOV'),False)
for immed in ['IMM[0] UINT32 {01,0,0,0}','IMM[0] UINT32 {-1,0,0,0}','IMM[0] INT32 {2147483648,0,0,0}','IMM[0] INT32 {-2147483648,0,0,0}','IMM[0] FLT32 {0x1234567,0,0,0}','IMM[0] FLT32 {0x12345678f,0,0,0}','IMM[0] FLT32 {0x,0,0,0}','IMM[0] FLT32 {1e-99,0,0,0}','IMM[0] FLT32 {1e+99,0,0,0}','IMM[0] FLT32 {nan,0,0,0}','IMM[0] FLT64 {0,0,0,0}','IMM[0] UINT32 {0,0,0}','IMM[0] UINT32 {0,0,0,0,0}','IMM[0] UINT32 {0,0,0,0} suffix','IMM[0 UINT32 {0,0,0,0}','IMM[1] UINT32 {0,0,0,0}']:
 add(immed,FS.replace('0: MOV',immed+'\n0: MOV'),False,kind=1)
for instruction in ['MOV_SAT_PRECISE_BAD OUT[0], CONST[0]','MOV_PRECISE_SAT OUT[0], CONST[0]','SIN_'+('A'*40)+' OUT[0], CONST[0]','MOV OUT[0]., CONST[0]','MOV OUT[0].zx, CONST[0]','MOV OUT[0], CONST[0].xxy','MOV OUT[0], CONST[0].xyzwx','MOV OUT[0], |CONST[0]','MOV OUT[0], CONST[0] :1','MOV OUT[0], CONST[0] #comment','MOV OUT[0], CONST[0] garbage','MOV OUT[0], CONST[0], CONST[0]','TEX OUT[0], CONST[0], CONST[0], 2D','TEX OUT[0], CONST[0], -SAMP[0], 2D','TEX OUT[0], CONST[0], SAMP[0].xxxx, 2D','TEX OUT[0], CONST[0], SAMP[0], 3D','TEX OUT[0], CONST[0], SAMP[0], 2D','UARL ADDR[0].xy, CONST[0]','ARL_SAT ADDR[0].x, CONST[0]','UARL_PRECISE ADDR[0].x, CONST[0]','MOV OUT[0], CONST[ADDR[1].x]','MOV OUT[0], CONST[ADDR[0].y]','MOV OUT[0], CONST[ADDR[0].x+1]','MOV OUT[0], CONST[ADDR[0].x][0]','MOV OUT[0], CONST[ADDR[0].x].xxxxx','UIF |CONST[0]|','ELSE :0','ENDLOOP :0','BGNLOOP :0','IF CONST[0] :0','BRK :0']:
 add(instruction,prog(1,'DCL CONST[0]\nDCL ADDR[0]\nDCL SAMP[0]\nDCL OUT[0], COLOR',[instruction]),False,kind=1)
for props in ['PROPERTY FS_COORD_ORIGIN LOWER_LEFT\nPROPERTY FS_COORD_PIXEL_CENTER HALF_INTEGER','PROPERTY FS_COLOR0_WRITES_ALL_CBUFS 0','PROPERTY FS_COLOR0_WRITES_ALL_CBUFS 1']:
 add('property-positive-'+props,FS.replace('DCL CONST',props+'\nDCL CONST'),kind=1)
for prop in ['PROPERTY FS_COORD_ORIGIN','PROPERTY FS_COORD_PIXEL_CENTER','PROPERTY FS_COORD_ORIGIN LOWER_LEFT extra','PROPERTY FS_COLOR0_WRITES_ALL_CBUFS 01','PROPERTY FS_COLOR0_WRITES_ALL_CBUFS -1']:
 add(prop,FS.replace('DCL CONST',prop+'\nDCL CONST'),False,kind=1)
for stage in [0,1]:
 for resource,bound in [('CONST',512),('TEMP',512),('SAMP',16),('SVIEW',16),('ADDR',1)]:
  for n in [bound,bound+1,2**32-1,2**32,10**20]:
   decl=f'DCL {resource}[{n}]'+(', 2D, FLOAT' if resource=='SVIEW' else '')
   add('extent-'+str(stage)+decl,(VS if stage==0 else FS).replace('0: MOV',decl+'\n0: MOV'),False,kind=stage)
 for n in [32,33]:
  decl='DCL CONST[0]\nDCL OUT[0], '+('POSITION' if stage==0 else 'COLOR')
  add('depth-'+str(stage)+'-'+str(n),prog(stage,decl,['IF CONST[0]']*n+['MOV OUT[0], CONST[0]']+['ENDIF']*n),n==32,kind=stage)
for sid in range(16):
 v=prog(0,f'DCL IN[0]\nDCL OUT[0], POSITION\nDCL OUT[31].xz, GENERIC[{sid}]',['MOV OUT[0], IN[0]','MOV OUT[31].xz, IN[0]'])
 f=prog(1,f'DCL IN[31].xz, GENERIC[{sid}], '+('CONSTANT' if sid%2 else 'PERSPECTIVE')+'\nDCL OUT[0], COLOR',['MOV OUT[0].xz, IN[31].xxxx'])
 add('partial-pair-'+str(sid),v,kind=2,b=f)
 add('mask-mismatch-'+str(sid),v,False,kind=2,b=f.replace('IN[31].xz,','IN[31].xy,'),code='incompatible-interface')
 add('semantic-mismatch-'+str(sid),v,False,kind=2,b=f.replace(f'GENERIC[{sid}]',f'GENERIC[{(sid+1)%16}]'),code='incompatible-interface')
seeds=[0x243f6a88,0x85a308d3,0x13198a2e]
plans=[]
for seed in seeds:
 n=seed
 def rand():
  global n
  n^=(n<<13)&0xffffffff;n^=n>>17;n^=(n<<5)&0xffffffff;n&=0xffffffff;return n
 for i in range(80):
  val=rand()
  mutations=[f'IN[{512+val}]',f'IN[-{1+val}]',f'IN[0..{val+512}]',f'IN[0][{val}]',f'IN[0{val}]',f'IN[{val+2**32}]',f'IN[ADDR[0].x]',f'IN[0].xyzw_{val}']
  add(f'seed-{seed}-{i}',VS.replace('IN[0]',mutations[i%len(mutations)]),False)
 # quarter/eighth values are exactly represented in f32; all floating domains
 # below are finite and positive for EX2/LG2. Inputs never depend on emission.
 a=[.5+(rand()%12)/16 for _ in range(4)];scale=[.125+(rand()%8)/32 for _ in range(4)];base=[.125,.25,.375,.5]
 body=['MOV TEMP[5], CONST[3]','MOV TEMP[1], CONST[3]','MOV TEMP[2], CONST[3]','MOV TEMP[3], CONST[3]','ARL ADDR[0].x, CONST[0].xxxx','MOV TEMP[0], CONST[ADDR[0].x]','EX2 TEMP[1].yz, TEMP[0].yxwz','LG2 TEMP[2].xw, TEMP[0].zwxy','SIN TEMP[3].xz, -|TEMP[0].wzyx|','COS TEMP[5].zw, TEMP[0].zywx','NOT TEMP[4], IMM[0]','UADD TEMP[4], -TEMP[4], IMM[0]','USEQ TEMP[4], TEMP[4], CONST[4]','UIF TEMP[4].xxxx','MUL TEMP[0], TEMP[0], CONST[2]','ADD TEMP[0].xy, TEMP[0], TEMP[1].yzyz','SUB TEMP[0].zw, TEMP[0], TEMP[2].wxwx','ADD TEMP[0].xz, TEMP[0], -TEMP[3].xzxz','ADD TEMP[0].yw, TEMP[0], TEMP[5].zwzw','MOV OUT[0], TEMP[0]','ELSE','MOV OUT[0], CONST[3]','ENDIF']
 fs=prog(1,'DCL CONST[0..4]\nDCL ADDR[0]\nDCL TEMP[0..5]\nDCL OUT[0], COLOR\nIMM[0] UINT32 {1,2,31,33}',body)
 mul=[x*y for x,y in zip(a,scale)];s=math.sin(-abs(a[3]));e=2**a[1];l=math.log2(a[2]);expected=[mul[0]+e-s,mul[1]+e+math.cos(a[2]),mul[2]-l-s,mul[3]-l+math.cos(a[2])]
 floats=[1.75,0,0,0]+a+scale+base;words=[struct.unpack('<I',struct.pack('<f',x))[0] for x in floats]+[3,5,63,67]
 plans.append(dict(seed=seed,vertexText=VS,fragmentText=fs,a=a,scale=scale,base=base,fragmentWords=words,expected=expected,budget=.00005,width=16,height=16))
 add('novel-'+str(seed),fs,kind=1)
(NATIVE/'cases.json').write_text(json.dumps(dict(cases=cases,seeds=seeds,originals=[]),indent=2)+'\n')
parts=[struct.pack('<I',len(cases))]
for c in cases:
 parts.append(struct.pack('<I',c['kind']))
 for field in ['a','b']:
  b=c[field].encode();parts.extend([struct.pack('<I',len(b)),b])
(NATIVE/'cases.bin').write_bytes(b''.join(parts));(OUT/'physical-plan.json').write_text(json.dumps(plans,indent=2)+'\n')
print(len(cases),'fresh literal predictions,',len(plans),'novel hardware plans')
