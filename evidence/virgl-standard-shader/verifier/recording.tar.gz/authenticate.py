from pathlib import Path
import hashlib,json,subprocess,tarfile
ROOT=Path.cwd();HERE=ROOT/'target/evidence/virgl-standard-shader-verifier';BASE=ROOT/'evidence/virgl-standard-shader';DEST=HERE/'unpacked'
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((BASE/'manifest.json').read_bytes());index=json.loads((BASE/'records.json').read_bytes())
assert sha((BASE/'recording.tar.gz').read_bytes())=='ee57339a1ce43d5f600a4d0d2c0e4bc47b361a189b78e1807cc31061225067b8'==manifest['archiveSha256']
assert sha((BASE/'records.json').read_bytes())=='a9a18780e726e13e0f6c883ce447e1c415314ff9d4b2604daa6273b5528bff2b'==manifest['recordIndexSha256']
assert manifest['sourceHead']==index['sourceHead']=='571c22593967e1cdae801d0c54ab0833d94b2c43'
records={r['path']:r for r in index['records']};assert len(records)==len(index['records'])==manifest['records']==409
with tarfile.open(BASE/'recording.tar.gz') as t:
 assert {m.name for m in t.getmembers()}==set(records)
 for m in t.getmembers():
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  raw=t.extractfile(m).read();r=records[m.name];assert len(raw)==r['bytes'] and sha(raw)==r['sha256'],m.name
  p=DEST/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
assert sha((DEST/'recording-tool/seal.py').read_bytes())==manifest['recordingToolSha256']=='7651a22aaa59bf8b50824420f018f96c32926f29be590c2bc9dbb7974c527a21'
def git(*a):return subprocess.check_output(['git',*a])
assert git('show',manifest['recordingToolHead']+':tools/virgl-standard-shader/seal.py')==(DEST/'recording-tool/seal.py').read_bytes()
assert set(git('diff','--name-only',manifest['sourceHead'],manifest['recordingToolHead']).decode().splitlines())=={'tools/virgl-standard-shader/seal.py'}
footer=b'Frozen standard compiler, 634 cases, 125 physical frames, coverage and legacy boundaries authenticated.\n'
report=json.loads((DEST/'cold/report.json').read_text());assert report['gitHead']==report['cloneHead']==manifest['sourceHead'] and report['status']=='passed' and report['exitCode']==0 and report['statusBefore']==report['statusAfter']==''
assert sha((DEST/'cold/cold.log').read_bytes())==report['logSha256']
assert sha((DEST/'cold/receipt.json').read_bytes())==report['receiptSha256']==manifest['coldReceiptSha256']
assert sha((DEST/'hot/receipt.json').read_bytes())==manifest['hotReceiptSha256']
assert sha((DEST/'cold/report.json').read_bytes())==manifest['coldReportSha256']
summary={'archive':manifest['archiveSha256'],'index':manifest['recordIndexSha256'],'sourceHead':manifest['sourceHead'],'recordingToolHead':manifest['recordingToolHead'],'records':len(records),'coldClone':report['clone'],'sides':{}}
cache={}
for side in ['hot','cold']:
 r=json.loads((DEST/side/'receipt.json').read_text());assert r['status']=='passed' and r['gitHead']==manifest['sourceHead']
 for name,d in r['files'].items():
  raw=(DEST/side/name).read_bytes()
  if name=='acceptance.log':assert raw.endswith(footer) and sha(raw[:-len(footer)])==d
  else:assert sha(raw)==d,(side,name)
 for name,d in r['sources'].items():
  if name not in cache:cache[name]=git('show',manifest['sourceHead']+':'+name)
  assert sha(cache[name])==d,(side,name)
 for name,d in r['generated'].items():
  assert sha((DEST/(side+'-generated')/name).read_bytes())==d,(side,name)
  actual=(ROOT if side=='hot' else Path(report['clone']))/name
  assert actual.is_file() and sha(actual.read_bytes())==d,(side,'actual',name)
 summary['sides'][side]={'files':len(r['files']),'sources':len(r['sources']),'generated':len(r['generated']),'cases':r['cases'],'frames':r['frames'],'pixels':r['pixels'],'stack':r['stack']}
legacy=git('show','97ed2ca31f08465e442c88aed3a677237f78e236:renderer/virgl-shader/bridge.c');current=(ROOT/'renderer/virgl-shader/bridge.c').read_bytes().split(b'/* The standard facet deliberately')[0]
for include in [b'#include "standard_guard.h"\n',b'#include "standard_emit.h"\n']:current=current.replace(include,b'')
assert current.rstrip()==legacy.rstrip()
summary['legacyBodySha256']=sha(legacy)
summary['status']='passed';(HERE/'authentication.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
