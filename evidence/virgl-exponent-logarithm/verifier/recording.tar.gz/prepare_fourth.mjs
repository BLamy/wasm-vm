import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {spawnSync,execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const out=path.resolve('evidence/virgl-exponent-logarithm/verifier'),seed=305419896;
const {OPS,vectors,carrier,bytesFragment}=await import(pathToFileURL(path.resolve('tools/virgl-exponent-logarithm/cases.mjs')));
const {physicalPlan}=await import(pathToFileURL(path.resolve('tools/virgl-exponent-logarithm/plan.mjs')));
const primary=JSON.parse(fs.readFileSync(path.join(out,'unpacked/generated/exponent-logarithm-primary.json')));
const seen=new Set(primary.map(c=>c.text)),cases=[];
for(const op of OPS)for(const v of vectors(op,seed))for(const variant of ['direct','swizzle-xxxx']){
 for(const [stage,text]of [['vertex',carrier(op,v,variant)],...[0,1,2,3].map(l=>['fragment',bytesFragment(op,v,l,variant)])])if(!seen.has(text)){seen.add(text);cases.push({name:`critic-${op}-${v.name}-${variant}-${stage}-${cases.length}`,stage,text});}
}
const u=n=>{const b=Buffer.alloc(4);b.writeUInt32LE(n);return b;};
const input=Buffer.concat([Buffer.from('VXL1'),u(cases.length),...cases.flatMap(c=>{const b=Buffer.from(c.text);return[u(c.stage==='vertex'?0:1),u(1),u(1),u(b.length),b];})]);
fs.writeFileSync(path.join(out,'fourth-cases.bin'),input);
const binary=path.join(out,'unpacked/generated/exponent-logarithm-sanitize/exponent-logarithm-test');fs.chmodSync(binary,0o755);
const run=spawnSync(binary,[],{input,env:{...process.env,LLVM_PROFILE_FILE:path.join(out,'fourth.profraw'),ASAN_OPTIONS:'abort_on_error=1',UBSAN_OPTIONS:'halt_on_error=1'},maxBuffer:64e6});
fs.writeFileSync(path.join(out,'fourth-native.log'),run.stdout??'');fs.writeFileSync(path.join(out,'fourth-native.stderr'),run.stderr??'');assert.equal(run.status,0,String(run.stderr));assert.equal(run.stderr.length,0);
const admitted=[],tokens=[];
for(const line of run.stdout.toString().trim().split('\n')){
 const m=/^(CASE|PRIMARY) (\d+) (.*)$/.exec(line);if(!m){assert.equal(line,'STATUS passed');continue;}
 const c=cases[+m[2]],r=JSON.parse(m[3]);if(m[1]==='CASE'){assert.equal(r.ok,true);admitted.push({name:c.name,result:r});}
 else{assert.ok(r.exponentInstructions.every(i=>i.sourceType===4&&i.destinationType===4&&i.outputMode===2));primary.push({...c,primary:r});tokens.push({name:c.name,instructions:r.exponentInstructions});}
}
assert.equal(tokens.length,cases.length);assert.equal(admitted.length,cases.length);
const primaryBytes=JSON.stringify(primary,null,2)+'\n';fs.writeFileSync(path.join(out,'fourth-primary.json'),primaryBytes);
const plans=physicalPlan(seed,primary);fs.writeFileSync(path.join(out,'fourth-plan.json'),JSON.stringify(plans,null,2)+'\n');
// The unchanged Decimal reference records every equation for the fresh schedule.
const expressions=[...plans.vertices.flatMap(v=>v.vectors.flatMap(x=>x.selected)),...plans.fragments.map(f=>f.selected)].filter(x=>x.op);
fs.writeFileSync(path.join(out,'fourth-expressions.json'),JSON.stringify(expressions));
const py="import sys,json;sys.path.insert(0,'tools/virgl-exponent-logarithm');from reference import predict;from pathlib import Path;p=Path('evidence/virgl-exponent-logarithm/verifier');k=sorted({(r['op'],r['word'])for r in json.loads((p/'fourth-expressions.json').read_bytes())});j=json.loads((p/'unpacked/generated/exponent-logarithm-reference.json').read_bytes());import hashlib;j['primaryFileSha256']=hashlib.sha256((p/'fourth-primary.json').read_bytes()).hexdigest();j['rows']=[predict(op,w)for op,w in k];(p/'fourth-reference.json').write_text(json.dumps(j,indent=2)+'\\n');print(len(k))";
execFileSync('python3',['-c',py],{stdio:'inherit'});
const hash=b=>createHash('sha256').update(b).digest('hex');
fs.writeFileSync(path.join(out,'fourth-prediction.json'),JSON.stringify({seed,primaryAdded:cases.length,binarySha256:hash(fs.readFileSync(binary)),fixtureSha256:hash(input),primarySha256:hash(primaryBytes),planSha256:hash(JSON.stringify(plans)),referenceSha256:hash(fs.readFileSync(path.join(out,'fourth-reference.json'))),admitted,tokens},null,2)+'\n');
// Only generated inputs are replaced; all runtime/harness sources remain frozen.
for(const [from,to]of [['fourth-primary.json','exponent-logarithm-primary.json'],['fourth-reference.json','exponent-logarithm-reference.json']])fs.copyFileSync(path.join(out,from),path.resolve('renderer/virgl-shader/build/'+to));
console.log(`${cases.length} unchanged pinned witnesses and seed ${seed} predictions frozen before GPU`);
