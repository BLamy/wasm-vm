import hashlib,json,subprocess,re
from pathlib import Path
OUT=Path('evidence/virgl-exponent-logarithm/verifier');ROOT=Path.cwd();sha=lambda b:hashlib.sha256(b).hexdigest();checks=[]
for prefix in ['hot','cold/acceptance']:
 p=OUT/'unpacked'/prefix;n=json.loads((p/'native/report.json').read_bytes());w=json.loads((p/'wasm/report.json').read_bytes());c=json.loads((p/'consumer.json').read_bytes())
 assert len(n['cases'])==len(w['cases'])==len(w['pairs'])==1615 and n['primaryComparisons']==1548
 assert w['nativeSha256']==c['nativeSha256']==sha((p/'native/report.json').read_bytes())
 for x,y,z in zip(n['cases'],w['cases'],w['pairs']):
  assert x['index']==y['index']==z['index'] and x['result']==y['result'] and z['result']['ok']==x['ok']
  assert x['textSha256']==sha(x['text'].encode())
  if x['ok']:assert x['consumerDomain']['ok'] and x['consumerDomain']['exponent']['kind']=='tgsi-bounded-exponent-logarithm-v1'
  else:assert not any(k in x['result']for k in ['glsl','metadata'])and not any(k in z['result']for k in ['vertex','fragment'])
  if x['primary']:assert all(t['sourceType']==t['destinationType']==4 and t['outputMode']==2 for t in x['primaryResult']['exponentInstructions'])
 assert len(c['contracts'])==1552 and len(c['forgeries'])==928 and len(c['banks'])==18 and len(c['combined'])==4 and c['accessorInvocations']==0
 assert all(f['result']['ok']is False for f in c['forgeries'])and all(x['base']==x['restored'] for x in c['combined'])
 assert all(x['result']['ok']==x['wanted']for b in c['banks']for x in b['checks'])
 guard_counts=[]
 for name,count in [('joins',402),('hex',49),('signed',108),('conversion',1575),('scalar',1427),('minimum',4524),('fraction',4469),('saturation',1160)]:
  g=json.loads((p/('independent-'+name+'-guards.json')).read_bytes());assert g['status']=='passed'and g['cases']==len(g['native'])==len(g['wasm'])==count;guard_counts.append({'guard':name,'count':count,'sha256':sha((p/('independent-'+name+'-guards.json')).read_bytes())})
 assert sum(x['count']for x in guard_counts)==13714
 checks.append({'recording':prefix,'nativeCases':len(n['cases']),'wasmCases':len(w['cases']),'wasmPairs':len(w['pairs']),'successes':1552,'pinnedInstructions':1548,'consumerContracts':1552,'metadataAttacks':928,'banks':18,'combinedBases':4,'accessorInvocations':0,'priorGuards':guard_counts})
# Frozen native result sources bind actual executable shader strings, not outputs
# invented by a matrix. Every primary vector's GLSL must equal the actual parser
# and unchanged vendor conversion witness, including the known discrepancy.
primary=json.loads((OUT/'unpacked/generated/exponent-logarithm-primary.json').read_bytes());witness={p['text']:p['primary']for p in primary}
for report in (OUT/'unpacked').glob('**/gpu-*/report.json'):
 j=json.loads(report.read_bytes());a=j['acceptance'];assert not j['trackedChanges']and a['fault']is None
 assert j['browserErrors']=={'console':[],'page':[],'requests':[]}
 for group in ['vertices','fragments']:
  for x in a[group]:
   if x['backend']=='mesa':assert x['primary']==witness[x['text']]
 for record in j['sources']:
  name=record['path']
  if name.startswith('renderer/virgl-shader/build/'):
   raw=(OUT/'unpacked'/('cold-generated'if '/cold/'in str(report)else 'generated')/name.removeprefix('renderer/virgl-shader/build/'))
   if not raw.exists():raw=OUT/'unpacked/generated'/name.removeprefix('renderer/virgl-shader/build/')
   raw=raw.read_bytes()
  else:raw=subprocess.check_output(['git','show','a3c2b48995cc6165f4a2844497671273d7305029:'+name])
  assert sha(raw)==record['sha256']
# The fourth input table is extra actual pinned conversion at the same exact
# archived source/binary, with declared oracle and schedule before observation.
fourth=json.loads((OUT/'gpu-305419896/report.json').read_bytes());a=fourth['acceptance'];pred=json.loads((OUT/'fourth-prediction.json').read_bytes());p=json.loads((OUT/'fourth-primary.json').read_bytes());witness={x['text']:x['primary']for x in p}
assert fourth['status']==a['status']=='passed'and not fourth['trackedChanges'] and pred['seed']==a['seed']==305419896 and pred['planSha256']==a['planSha256']
assert pred['referenceSha256']==a['referenceFile']['sha256']and pred['primarySha256']==a['primaryFile']['sha256']
for g in ['vertices','fragments']:
 for x in a[g]:
  if x['backend']=='mesa':assert x['primary']==witness[x['text']]
source_bindings=[]
for record in fourth['sources']:
 name=record['path']
 if name.endswith('/exponent-logarithm-primary.json'):raw=(OUT/'fourth-primary.json').read_bytes()
 elif name.endswith('/exponent-logarithm-reference.json'):raw=(OUT/'fourth-reference.json').read_bytes()
 else:raw=(ROOT/name).read_bytes()
 assert sha(raw)==record['sha256'];source_bindings.append({'path':name,'sha256':record['sha256']})
novel=json.loads((OUT/'independent-regressions.json').read_bytes());assert novel['status']=='passed'and novel['cases']==len(novel['native'])==len(novel['wasm'])==1022
attacks=[x for x in novel['native']if '-partial-1123745792-2147483648-'in x['name']or '-join-version-kill-'in x['name']]
# Select concrete +/-125.5 and +/-124 source facts by their mathematical extrema.
attacks.extend(x for x in novel['native']if x['name'].startswith('EX2-partial-')and x.get('minimum')in [-125.5,-124]and x.get('maximum')in [125.5,124])
assert any(x.get('minimum')==-125.5 and x.get('maximum')==125.5 and x['result']['ok']is False for x in attacks)
assert any(x.get('minimum')==-124 and x.get('maximum')==124 and x['result']['ok']is True for x in attacks)
report={'status':'passed','recordings':checks,'fourth':{'words':a['checkedWords'],'pixels':a['checkedPixels'],'renderer':a['renderer'],'sourceBindings':source_bindings,'additionalActualPrimaryCases':pred['primaryAdded']},'novelAttacks':attacks,'scope':{'runtimeEdited':False,'productionNegotiation':False,'guestExecution':False,'fullOriginalAdmission':False,'fpsMips':False,'rr':'waived by current AGENTS.md'},'carrierArgument':'Mantissa and exponent/sign finite normal carriers expose all 32 bits from a single evaluated word. Fragment four-byte I2F is exact (0..255); highp DIV by 255 has <=2.5 ULP, scaled byte error <0.00008, strictly below RGBA8 half-step with dithering disabled.'}
(OUT/'final-audits.json').write_text(json.dumps(report,indent=2)+'\n');print('1615 native/Wasm outcomes x2, 1548 real pinned witnesses x2, all metadata/prior guards, fourth source bindings, and bounded novel attacks held')
