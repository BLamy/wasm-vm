import hashlib,json,tarfile,subprocess
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'evidence/virgl-exponent-logarithm/verifier';sha=lambda b:hashlib.sha256(b).hexdigest()
def authenticate(base):
 p=ROOT/base;m=json.loads((p/'manifest.json').read_bytes());idxraw=(p/'records.json').read_bytes();a=(p/m['archive']['path']).read_bytes()
 index=m.get('recordIndex',m.get('index'));assert sha(idxraw)==index['sha256'] and sha(a)==m['archive']['sha256'];idx=json.loads(idxraw);rows=idx['records']if isinstance(idx,dict)else idx;records={}
 with tarfile.open(p/m['archive']['path'])as t:
  assert len(t.getmembers())==len(rows) and len({x.name for x in t.getmembers()})==len(rows)
  for r in rows:
   x=t.getmember(r['path']);assert x.isfile() and not Path(x.name).is_absolute()and '..'not in Path(x.name).parts;b=t.extractfile(x).read();assert len(b)==r['bytes'] and sha(b)==r['sha256'];records[x.name]=b
 return m,records,{'boundary':str(base),'manifestSha256':sha((p/'manifest.json').read_bytes()),'archiveSha256':m['archive']['sha256'],'indexSha256':index['sha256'],'members':len(rows),'verdict':m.get('verdict')}
prior=[]
for name in ['virgl-saturation','virgl-precise-fraction','virgl-minimum-selection','virgl-scalar-operations','virgl-signed-conversions','virgl-signed-integers','virgl-hex-literals','virgl-compiler-bounds']:
 m,records,binding=authenticate(Path('evidence')/name/'verifier');assert m['verdict']=='verified';binding['promoted']=[]
 promoted=m.get('promoted',m.get('guard',m.get('promotedGuard',m.get('promotedTest',[]))));promoted=[promoted] if isinstance(promoted,dict)else promoted
 for r in promoted:
  r=dict(r);r['testSha256']=r.get('testSha256',r.get('sha256'));data=(ROOT/r['path']).read_bytes();assert sha(data)==r['testSha256']
  if r.get('archiveMember'):assert sha(records[r['archiveMember']])==r['testSha256']
  binding['promoted'].append({'path':r['path'],'sha256':r['testSha256'],'sealedSourceCopies':[k for k,v in records.items()if sha(v)==r['testSha256']]})
 prior.append(binding)
m,records,parent=authenticate(Path('evidence/virgl-saturation/worker'));receipt=json.loads(records['hot/receipt.json']);unchanged=[];changed=[];generated=[]
for r in receipt['sources']:
 name=r['path']
 if name.startswith('renderer/virgl-shader/build/'):generated.append(r);continue
 raw=(ROOT/name).read_bytes();entry={'path':name,'previousSha256':r['sha256'],'currentSha256':sha(raw)}
 (unchanged if sha(raw)==r['sha256'] else changed).append(entry)
sat=json.loads((ROOT/'evidence/virgl-saturation/verifier/manifest.json').read_bytes());prior_promotion=[r for r in changed if r['path']==sat['targetWiring']['path']];assert all(r['currentSha256']==sat['targetWiring']['sha256']for r in prior_promotion);changed=[r for r in changed if r not in prior_promotion]
allowed={'renderer/virgl-shader/bridge.c','renderer/virgl-shader/raw_bits.c','renderer/virgl-shader/raw_bits.h','renderer/virgl-shader/build.sh','renderer/virgl-command/constant-domain.mjs','Makefile'}
assert all(r['path']in allowed for r in changed),changed
# Existing captured source statement and retained complete outcomes, not regenerated expectations.
counts=[]
for prefix in ['hot','cold/acceptance']:
 legacy=json.loads((OUT/'unpacked'/prefix/'legacy.json').read_bytes());assert len(legacy['cases'])==4246
 for c in legacy['cases']:
  assert c['parent']==c['old'] and c['added']['ok']==c['ok']==c['old']['ok']
  if c['ok']:
   restored=dict(c['added']['metadata']);restored['profile']=restored.pop('exponentBaseProfile');restored.pop('exponentContract');old=dict(c['old']['metadata'])
   if c['baseTransition']:old['profile']='virgl-webgl2-raw-bits-v1'
   assert restored==old
  else:assert not any(k in c['added']for k in ['glsl','metadata'])
 held=json.loads((OUT/'unpacked'/prefix/'held-saturation/report.json').read_bytes());assert held['status']=='passed'and held['physicalWords']==39576 and held['faultExit']!=0
 capture=OUT/'unpacked'/prefix/'held-saturation/capture.json';guards=OUT/(prefix.replace('/','-')+'-held-saturation-guards.json')
 subprocess.run(['python3','renderer/virgl-shader/tests/saturation-capture-regressions.py','--report',str(capture),'--output',str(guards)],check=True)
 retained=json.loads((OUT/'unpacked'/prefix/'retained/report.json').read_bytes());assert sum(c['native']['ok']for c in retained['originals'])==23 and len(retained['originals'])==25
 assert sum(c['native']['ok']for c in retained['historical'])==5 and len(retained['historical'])==112
 counts.append({'recording':prefix,'wholePriorResults':4246,'completeOriginals':{'current':len(retained['originals']),'accepted':23,'historical':112,'historicalAccepted':5},'heldSaturationWords':held['physicalWords'],'captureSha256':sha(capture.read_bytes()),'sourceGuardSha256':sha(guards.read_bytes())})
report={'status':'passed','priorHeldSeals':prior,'parentWorker':parent,'unchangedDependencies':unchanged,'changedBoundariesReceivingCurrentProof':changed,'unchangedPriorCriticTargetPromotion':prior_promotion,'generatedParentArtifactsReceivingNewNativeWasmProof':generated,'recordings':counts,'policy':'Carry unchanged predictions and sealed evidence; changed four runtime files and two acceptance/build declarations receive this fresh scope audit. No unrelated runtime requirement introduced.'}
(OUT/'carry-forward.json').write_text(json.dumps(report,indent=2)+'\n');print(len(prior),'seals,',len(unchanged),'unchanged dependencies;',len(changed),'changed boundaries freshly proved')
