from pathlib import Path
import json,hashlib,subprocess
ROOT=Path.cwd();OUT=ROOT/'evidence/virgl-exponent-logarithm/verifier';SRC=ROOT/'renderer/virgl-shader';sha=lambda b:hashlib.sha256(b).hexdigest();p=OUT/'sabotage';p.mkdir(exist_ok=True)
raw=(SRC/'raw_bits.c').read_text();needle='maximum > UINT32_C(0x42fa0000)';replacement='maximum > UINT32_C(0x42fc0000)';assert raw.count(needle)==1
(p/'raw_bits.c').write_text(raw.replace(needle,replacement))
sources=[str(SRC/'bridge.c'),str(p/'raw_bits.c'),str(SRC/'generated/u_format_table.c'),str(SRC/'checked_upstream.c'),*[str(f)for f in sorted((SRC/'vendor/src/gallium/auxiliary/tgsi').glob('*.c'))],str(SRC/'vendor/src/gallium/auxiliary/cso_cache/cso_hash.c'),str(SRC/'vendor/src/gallium/auxiliary/cso_cache/cso_cache.c'),str(SRC/'vendor/src/mesa/util/u_debug.c'),str(SRC/'cli.c')]
args=['clang','-std=gnu11','-D_GNU_SOURCE','-D_DARWIN_C_SOURCE','-DUTIL_ARCH_LITTLE_ENDIAN=1','-DUTIL_ARCH_BIG_ENDIAN=0','-DHAVE___BUILTIN_CLZ=1','-DHAVE___BUILTIN_CLZLL=1','-DHAVE___BUILTIN_POPCOUNT=1','-O1',*[f'-I{SRC/sub}' for sub in ['.','generated','vendor/src','vendor/src/mesa','vendor/src/mesa/pipe','vendor/src/mesa/compat','vendor/src/gallium/include','vendor/src/gallium/auxiliary','vendor/src/gallium/auxiliary/util']],*sources,'-lm','-o',str(p/'native')]
with (OUT/'sabotage-build.log').open('w')as log:subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
cmd=['node','renderer/virgl-shader/tests/exponent-logarithm-regressions.mjs','--native',str(p/'native'),'--native-only','--output',str(OUT/'sabotage-regressions.json')]
r=subprocess.run(cmd,capture_output=True,cwd=ROOT);(OUT/'sabotage-regressions.log').write_bytes(r.stdout+r.stderr);assert r.returncode!=0
j=json.loads((OUT/'sabotage-regressions.json').read_bytes());assert j['status']=='failed' and j['failure']['counterexample']['ok']is False and j['failure']['counterexample']['result']['ok']is True
meta={'status':'passed','mutation':{'path':'renderer/virgl-shader/raw_bits.c','needle':needle,'replacement':replacement,'sourceBeforeSha256':sha(raw.encode()),'sourceAfterSha256':sha((p/'raw_bits.c').read_bytes())},'buildCommand':args,'command':cmd,'exitCode':r.returncode,'concreteFailure':j['failure']}
(OUT/'sabotage-source.json').write_text(json.dumps(meta,indent=2)+'\n');print(j['failure']['counterexample']['name'],'rejects negative-bound sabotage')
