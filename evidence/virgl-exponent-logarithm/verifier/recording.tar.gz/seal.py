"""Seal the complete independent verifier record, then authenticate every member."""
import gzip,hashlib,io,json,tarfile
from pathlib import Path,PurePosixPath
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];sha=lambda b:hashlib.sha256(b).hexdigest()
exclude={'unpacked','__pycache__','manifest.json','records.json','recording.tar.gz','README.md','seal-authentication.json'}
def binding(p):return {'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
v=json.loads((OUT/'verdict.json').read_bytes());assert v['verdict']=='verified'and v['held']==11 and v['failed']==v['needsEvidence']==0
files=sorted(p for p in OUT.rglob('*')if p.is_file()and not p.is_symlink()and not any(part in exclude or part.endswith('.dSYM')for part in p.relative_to(OUT).parts))
index={'schema':'virgl-exponent-logarithm-critic-records-v1','task':'E6-T12g6i','sourceHead':v['sourceHead'],'workerSubmission':v['workerSubmission'],'records':[binding(p)for p in files]}
(OUT/'records.json').write_text(json.dumps(index,indent=2)+'\n')
with (OUT/'recording.tar.gz').open('wb')as stream:
 with gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0)as compressed:
  with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT)as t:
   for p in files:
    b=p.read_bytes();m=tarfile.TarInfo(str(p.relative_to(OUT)));m.size=len(b);m.mode=0o644;m.mtime=0;t.addfile(m,io.BytesIO(b))
actual=[]
with tarfile.open(OUT/'recording.tar.gz')as t:
 for m in t.getmembers():
  name=PurePosixPath(m.name);assert m.isfile()and not name.is_absolute()and '..'not in name.parts;b=t.extractfile(m).read();actual.append({'path':m.name,'bytes':len(b),'sha256':sha(b)})
assert len({r['path']for r in actual})==len(actual)and actual==index['records']
for r in v['promoted']:
 assert sha((ROOT/r['path']).read_bytes())==sha((OUT/r['archiveMember']).read_bytes())==r['testSha256'];assert sha((OUT/r['report']).read_bytes())==r['reportSha256']
 assert json.loads((OUT/r['report']).read_bytes())['testSha256']==r['testSha256']
assert sha((ROOT/v['targetWiring']['path']).read_bytes())==sha((OUT/v['targetWiring']['archiveMember']).read_bytes())==v['targetWiring']['sha256']
m={'schema':'virgl-exponent-logarithm-critic-seal-v1','task':'E6-T12g6i','verdict':'verified','sourceHead':v['sourceHead'],'workerSubmission':v['workerSubmission'],'base':v['base'],'records':len(files),'allMembersAuthenticated':True,'archive':binding(OUT/'recording.tar.gz'),'recordIndex':binding(OUT/'records.json'),'verdictRecord':binding(OUT/'verdict.json'),'predictions':{'held':11,'failed':0,'needsEvidence':0},'workerDependencies':v['workerDependencies'],'promoted':v['promoted'],'targetWiring':v['targetWiring'],'coverage':v['coverage'],'physical':v['physical'],'priorHeldSeals':v['priorHeldSeals'],'carried':v['carried'],'scope':v['scope']}
(OUT/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
(OUT/'README.md').write_text(f'''# E6-T12g6i fresh adversarial verifier

VERDICT: **verified**. This session did not implement the task or edit runtime.
All 11 predictions were declared before inspecting recorded state, then marked
HELD with precise archived points/digests in `verdict.json`. The exact runtime
source is `{v['sourceHead']}`; worker submission is `{v['workerSubmission']}`
and the verified predecessor is `{v['base']}`.

`manifest.json`, `records.json`, and `recording.tar.gz` seal {len(files)} unique
regular members. Every byte length and SHA256 was checked after sealing. They
preserve prediction tables, independent numerical-series audits, the actual
fourth physical capture/screenshot/V8 evidence, source equations, prior-proof
bindings, copied-source and test sabotage, original recorded-binary replays,
original-profile re-exports, source audits, complete commands and the exact
promoted guard/wiring snapshots. `unpacked/` is excluded as an extracted duplicate
of the independently authenticated worker archive. The worker archive/index
remain `{v['workerDependencies']['archiveSha256']}` /
`{v['workerDependencies']['indexSha256']}` for the original 115 records.

All 91 worker and 59 fourth-schedule intervals/budgets pass an independently
implemented 270-digit directed atanh/Taylor calculation with explicit rational
tail bounds; it uses neither Decimal transcendental functions nor GLSL to predict
results. The Khronos ESSL 3.00 primary PDF matches the pinned digest; its section
4.5.1 specifies the admitted budgets. Domain guards enumerate every possible
partially known word; post-swizzle x, negation, masks, aliases, source kills,
joins, numerical authority and absent F2I/result-range inference are exercised.

Source-level TGSI equations verify 78,912 archived physical words and 182,784
RGBA8 pixels, plus 13,152 words and 30,464 pixels at independent nonzero seed
305,419,896 on the genuine Apple M4 Max hardware GPU. Its schedule/reference
predictions preceded observation; 160 additional pinned parser/converter
witnesses came from the exact archived sanitizer binary. All 18 literal captured
broadcast statements run unchanged on both backends. The pinned componentwise
EX2/LG2 bug remains explicit: 316 concrete vertex deviations per schedule;
canonical broadcasts obey the specified scalar equations. All shaderSource
events bind to actual unchanged owned/pinned output.

Both archived native binaries replay their full 1,615-case transcript exactly;
1,548 typed FLOAT/REPL witnesses and complete native/Wasm/pair outcomes hold.
The new independent guard contributes 1,022 native/Wasm cases. All 22 runtime
hunks / 77 added lines are executed or explicitly waived as declarations,
comments or a function signature. Every new domain-predicate edge has nonzero
counts in both authentic profiles. Metadata proof retains 1,552 contracts,
928 rejected mutations, 18 banks, four combined policies and zero accessor
execution. Physical A/B/A replacement/restoration, copied caller data, sync/async
and cache policies, atomic refusal, reflection and zero disposal budgets hold.

Eight predecessor critic seals and 298 unchanged dependencies carry HELD
results forward. All 4,246 complete prior responses and 13,714 prior guards
remain proven per set, as do unchanged SAT physical/fault equations. The single
worker cold clone ran the same command at the frozen exact source with scrubbed
environment, clean before/after and exit zero. No duplicate cold clone ran.

Every ex2/lg2/broadcast physical fault in both hot/cold sets contradicts the
promoted source oracle. A copied C negative-bound relaxation and corrupted
acceptance/oracle expectations fail independent guards. The bounded novel attack
rejects unknown-sign +/-125.5 while permitting +/-124 and refuses killed facts
across a conditional join. Promoted domain and capture guards are wired into
`make verify-E6-T12g6i`; identities/dependencies are in the manifest.

This is a private compiler boundary: full original programs remain gated;
production GPU negotiation and live guest offload are disabled. No whole-body,
FPS/MIPS, public-demo/deploy or host rr claim is made. rr and ssh-dev are waived
by current repository policy. Only the affected C/consumer/native/Wasm/physical
gauntlet and touched verifier harness checks are in scope; no Actions were used.
''')
auth={'status':'passed','members':len(actual),'archive':m['archive'],'recordIndex':m['recordIndex'],'manifest':binding(OUT/'manifest.json'),'verdictRecord':m['verdictRecord'],'promoted':v['promoted']}
(OUT/'seal-authentication.json').write_text(json.dumps(auth,indent=2)+'\n');print(json.dumps(auth,indent=2))
