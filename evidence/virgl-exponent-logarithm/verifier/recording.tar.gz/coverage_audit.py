import json,re,subprocess,hashlib
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'evidence/virgl-exponent-logarithm/verifier';runtime=['renderer/virgl-shader/bridge.c','renderer/virgl-shader/raw_bits.c','renderer/virgl-shader/raw_bits.h','renderer/virgl-command/constant-domain.mjs'];changes=[]
for name in runtime:
 diff=subprocess.check_output(['git','diff','--unified=0','2aa21751921bb047f8bb6b58432d35c093a76b62','7757338d','--',name],text=True);line=0;hunk=None
 for raw in diff.splitlines():
  if raw.startswith('@@'):line=int(re.search(r'\+(\d+)',raw).group(1));hunk=raw
  elif raw.startswith(('+++','---')):continue
  elif raw.startswith('+'):changes.append({'file':name,'line':line,'text':raw[1:],'hunk':hunk});line+=1
  elif not raw.startswith(('-','\\')):line+=1
c=[];v8=[]
for label in ['hot','cold-acceptance']:
 j=json.loads((OUT/('coverage-'+label+'.json')).read_bytes())
 for d in j['data']:
  for f in d['files']:
   name=next((n for n in runtime if n.endswith('/'+Path(f['filename']).name)),None)
   if name:c.append({'source':label,'file':name,'segments':f['segments']})
for file in (OUT/'unpacked').glob('**/gpu-*/browser-coverage.json'):
 j=json.loads(file.read_bytes())
 for s in j['scripts']:
  if s['source']==runtime[-1]:
   assert s['sha256']==hashlib.sha256((ROOT/s['source']).read_bytes()).hexdigest();v8.append({'source':str(file.relative_to(OUT)),'ranges':[r for f in s['coverage']['functions']for r in f['ranges']]})
for file in (OUT/'node-consumer-coverage').glob('*.json'):
 for s in json.loads(file.read_bytes())['result']:
  if s['url'].endswith('/'+runtime[-1]):v8.append({'source':str(file.relative_to(OUT)),'ranges':[r for f in s['functions']for r in f['ranges']]})
lines=(ROOT/runtime[-1]).read_text().splitlines(keepends=True);offsets=[0]
for s in lines:offsets.append(offsets[-1]+len(s))
for row in changes:
 txt=row['text'].strip()
 if row['file'].endswith('raw_bits.c') and txt.startswith('static bool exponent_domain_proved('):row.update(classification='waived',reason='function signature has no executable region; function body recorded 3234 calls and every predicate edge has positive counts in both authentic profiles');continue
 if row['file'].endswith('.h'):row.update(classification='waived',reason='opcode/type/mask declarations and static assertions; actual EX2/LG2 arity, masks, metadata and emission covered by frozen native/Wasm and physical records');continue
 if not txt or txt.startswith(('/*','*','//')):row.update(classification='waived',reason='comment or whitespace');continue
 if row['file'].endswith('.mjs'):
  start=offsets[row['line']-1]+len(row['text'])-len(row['text'].lstrip());hits=[]
  for record in v8:
   candidates=[r for r in record['ranges']if r['startOffset']<=start<r['endOffset']]
   if candidates:hits.append({'source':record['source'],'count':min(candidates,key=lambda r:r['endOffset']-r['startOffset'])['count']})
 else:
  hits=[]
  for record in c:
   if record['file']!=row['file']:continue
   segments=record['segments'];found=[s[2]for s in segments if s[0]==row['line']and s[3]and not s[5]]
   if not found:
    prior=[s for s in segments if s[0]<row['line']and s[3]and not s[5]]
    if prior:found=[prior[-1][2]]
   hits.append({'source':record['source'],'count':max(found,default=0)})
 row['hits']=hits;row['classification']='executed' if any(h['count']>0 for h in hits)else 'needs-evidence'
 if row['classification']=='needs-evidence'and (txt in ['{','}']or txt.startswith('case ')):row.update(classification='waived',reason='structural label/brace; associated function and positive opcode execution/emission shown by profile and paired physical records')
branches=[]
for label in ['hot','cold-acceptance']:
 j=json.loads((OUT/('coverage-'+label+'.json')).read_bytes())
 f=next(f for d in j['data']for f in d['functions']if f['name'].endswith(':exponent_domain_proved'))
 assert f['count']==3234 and all(b[4]>0 and b[5]>0 for b in f['branches'])
 branches.append({'source':label,'function':f['name'],'count':f['count'],'branches':f['branches'],'allPredicateEdgesHit':True})
gaps=[r for r in changes if r['classification']=='needs-evidence']
j={'status':'passed'if not gaps else 'needs-evidence','runtimeHunks':len({(r['file'],r['hunk'])for r in changes}),'addedRuntimeLines':len(changes),'changedLines':changes,'needsEvidence':gaps,'domainPredicate':branches,'v8Records':len(v8)}
(OUT/'coverage-audit.json').write_text(json.dumps(j,indent=2)+'\n');print(j['status'],j['runtimeHunks'],'runtime hunks /',j['addedRuntimeLines'],'lines;',len(gaps),'gaps')
for g in gaps:print(g['file'],g['line'],g['text'])
