import hashlib, json, subprocess, tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
SOURCE = 'a3c2b48995cc6165f4a2844497671273d7305029'
WORKER = ROOT / 'evidence/virgl-exponent-logarithm/worker'
sha = lambda b: hashlib.sha256(b).hexdigest()
manifest = json.loads((WORKER/'manifest.json').read_bytes())
index = json.loads((WORKER/'records.json').read_bytes())
assert manifest['sourceHead'] == index['sourceHead'] == SOURCE
for key in ['archive','recordIndex']:
    item = manifest[key]; raw = (WORKER/item['path']).read_bytes()
    assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
rows = index['records']; assert len(rows) == manifest['records'] == 115
unpacked = OUT/'unpacked'; unpacked.mkdir(exist_ok=True)
with tarfile.open(WORKER/manifest['archive']['path']) as t:
    members = t.getmembers()
    assert len(members) == len(rows) and all(m.isfile() for m in members)
    assert len({m.name for m in members}) == len(members)
    for row in rows:
        name = row['path']; assert not Path(name).is_absolute() and '..' not in Path(name).parts
        raw = t.extractfile(name).read()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
        file = unpacked/name; file.parent.mkdir(parents=True,exist_ok=True); file.write_bytes(raw)
sources=[]
for prefix,generated in [('hot','generated'),('cold/acceptance','cold-generated')]:
    receipt_raw=(unpacked/prefix/'receipt.json').read_bytes(); receipt=json.loads(receipt_raw)
    assert receipt['gitHead']==SOURCE and receipt['status']=='passed'
    expected=manifest['hotReceiptSha256' if prefix=='hot' else 'coldReceiptSha256']
    assert sha(receipt_raw)==expected
    for row in receipt['records']:
        raw=(unpacked/prefix/row['path']).read_bytes()
        assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
    for row in receipt['sources']:
        name=row['path']
        if name.startswith('renderer/virgl-shader/build/'):
            file=unpacked/generated/name.removeprefix('renderer/virgl-shader/build/')
            if not file.exists():
                # Cold seal keeps only its referenced generated artifacts.
                file=unpacked/'generated'/name.removeprefix('renderer/virgl-shader/build/')
            raw=file.read_bytes()
        else:
            raw=subprocess.check_output(['git','show',SOURCE+':'+name],cwd=ROOT)
            assert (ROOT/name).read_bytes()==raw, 'working source differs: '+name
        assert len(raw)==row['bytes'] and sha(raw)==row['sha256'], name
        sources.append({'recording':prefix,**row})
cold=json.loads((unpacked/'cold/report.json').read_bytes())
assert sha((unpacked/'cold/report.json').read_bytes())==manifest['coldReportSha256']
assert cold['gitHead']==cold['cloneHead']==SOURCE and cold['status']=='passed' and cold['exitCode']==0
assert cold['command']==['make','verify-E6-T12g6i'] and not cold['statusBefore'] and not cold['statusAfter']
assert sha((unpacked/'cold/cold.log').read_bytes())==cold['logSha256']
assert sha((unpacked/'cold/acceptance/receipt.json').read_bytes())==cold['receiptSha256']
changed=subprocess.check_output(['git','diff','--name-only',SOURCE+'..7757338d'],cwd=ROOT,text=True).splitlines()
assert all(n.startswith('evidence/virgl-exponent-logarithm/worker/') or n in ['tasks/QUEUE.md','tasks/epic-6-transcendence/E6-T12g6i-exponent-logarithm.md'] for n in changed)
report={'status':'passed','workerManifestSha256':sha((WORKER/'manifest.json').read_bytes()),'archive':manifest['archive'],'recordIndex':manifest['recordIndex'],'records':rows,'sourceHead':SOURCE,'authenticatedSourceEntries':len(sources),'sources':sources,'cold':cold,'submissionChanges':changed}
(OUT/'authentication.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'passed','members':len(rows),'sourceEntries':len(sources),'cold':cold,'changedAfterFreeze':changed},indent=2))
