"""Critic's independent series enclosures. No Decimal ln/exp or GLSL oracle."""
import hashlib,json,math
from decimal import Decimal,localcontext,ROUND_FLOOR,ROUND_CEILING
from fractions import Fraction
from functools import lru_cache
from pathlib import Path
OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def real(w):
 e=(w>>23)&255;assert e!=255
 sig=(w&0x7fffff)+(0x800000 if e else 0)
 q=Fraction(sig)*Fraction(2)**(e-150 if e else -149)
 return -q if w&0x80000000 else q
def binexp(q):
 n,d=abs(q).numerator,abs(q).denominator;e=n.bit_length()-d.bit_length()
 return e-int(abs(q)<Fraction(2)**e)
def rational(r):return Fraction(int(r['n']),int(r['d']))
def ratio(q):return {'n':str(q.numerator),'d':str(q.denominator)}
def dec(q,mode):
 with localcontext() as c:
  c.prec=270;c.rounding=mode
  return Decimal(q.numerator)/Decimal(q.denominator)
@lru_cache(None)
def log_series(q):
 # ln(q)=2 sum z^(2k+1)/(2k+1), z=(q-1)/(q+1), 1<=q<=2.
 # Exact positive tail <=2 z^(2N+1)/((2N+1)(1-z^2)).
 assert 1<=q<=2;z=(q-1)/(q+1);ends=[];N=340
 for mode in [ROUND_FLOOR,ROUND_CEILING]:
  with localcontext() as c:
   c.prec=270;c.rounding=mode;t=dec(z,mode);t2=t*t;term=t;total=Decimal(0)
   for k in range(N):total+=term/Decimal(2*k+1);term*=t2
   value=2*total
   if mode==ROUND_CEILING:
    tail=2*(Fraction(1,3)**(2*N+1))/(Fraction(2*N+1)*(1-Fraction(1,9)))
    value+=dec(tail,mode)
   ends.append(value)
 return ends
@lru_cache(None)
def independent(op,w):
 x=real(w);e=binexp(x) if x else 0
 if op=='LG2' and x==Fraction(2)**e:return Fraction(e),Fraction(e)
 if op=='EX2' and x.denominator==1:return (Fraction(2)**int(x),)*2
 l2,h2=log_series(Fraction(2))
 if op=='LG2':
  l,h=log_series(x/(Fraction(2)**e));ans=[]
  for mode,y,z in [(ROUND_FLOOR,l,h2),(ROUND_CEILING,h,l2)]:
   with localcontext() as c:
    c.prec=270;c.rounding=mode;ans.append(Fraction(Decimal(e)+y/z))
  return tuple(ans)
 n=x.numerator//x.denominator;f=x-n;ans=[];N=260
 for mode,z in [(ROUND_FLOOR,l2),(ROUND_CEILING,h2)]:
  with localcontext() as c:
   c.prec=270;c.rounding=mode;y=dec(f,mode)*z;assert 0<=y<1
   term=Decimal(1);total=Decimal(1)
   for k in range(1,N+1):term=term*y/Decimal(k);total+=term
   if mode==ROUND_CEILING:total+=dec(Fraction(3,math.factorial(N+1)),mode)
   ans.append(Fraction(total)*(Fraction(2)**n))
 return tuple(ans)
def audit(reference_path,out):
 raw=reference_path.read_bytes();j=json.loads(raw);rows=[]
 for r in j['rows']:
  op,w=r['op'],r['word'];x=real(w);lo,hi=independent(op,w)
  assert rational(r['lower'])<=lo<=hi<=rational(r['upper']),(op,hex(w),'160 enclosure')
  assert rational(r['higherLower'])<=lo<=hi<=rational(r['higherUpper']),(op,hex(w),'220 enclosure')
  if op=='EX2':budget=(3+2*abs(x))*Fraction(2)**(x.numerator//x.denominator-23);strict=False
  elif Fraction(1,2)<=x<=2:budget=Fraction(2)**-21;strict=True
  else:
   assert binexp(lo)==binexp(hi);budget=3*Fraction(2)**(binexp(lo)-23);strict=False
  assert budget==rational(r['budget']) and r['strict']==strict
  assert rational(r['allowedLower'])==rational(r['upper'])-budget and rational(r['allowedUpper'])==rational(r['lower'])+budget
  rows.append({'op':op,'word':w,'lower':ratio(lo),'upper':ratio(hi),'budget':ratio(budget),'strict':strict})
 report={'status':'passed','referenceSha256':sha(raw),'seriesPrecision':270,'logSeriesTerms':340,'expSeriesTerms':260,'method':'positive atanh series with rational tail bound; positive exponential Taylor series after exact binary range reduction; all arithmetic directed','rows':rows}
 out.write_text(json.dumps(report,indent=2)+'\n');print(len(rows),'enclosures and budgets independently held')
if __name__=='__main__':
 import sys
 p=Path(sys.argv[1]) if len(sys.argv)>1 else OUT/'unpacked/generated/exponent-logarithm-reference.json'
 audit(p,Path(sys.argv[2]) if len(sys.argv)>2 else OUT/'reference-audit.json')
