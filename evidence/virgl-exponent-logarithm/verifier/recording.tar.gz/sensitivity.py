import json,subprocess,hashlib
from pathlib import Path
OUT=Path('evidence/virgl-exponent-logarithm/verifier');sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for prefix in ['hot','cold/acceptance']:
 for kind in ['ex2','lg2','broadcast']:
  report=OUT/'unpacked'/prefix/('fault-'+kind)/'report.json';guard=OUT/(prefix.replace('/','-')+'-fault-'+kind+'-guards.json')
  command=['python3','renderer/virgl-shader/tests/exponent-logarithm-capture-regressions.py','--report',str(report),'--output',str(guard)];r=subprocess.run(command,capture_output=True);(OUT/(guard.stem+'.log')).write_bytes(r.stdout+r.stderr);assert r.returncode!=0
  j=json.loads(report.read_bytes());a=j['acceptance'];v=next(v for v in a['vertices']if v['mutation']);m=v['mutation'];x=next(x for x in v['vectors']if 'failure'in x)
  assert m['original']==v['pair']['vertex']['glsl'] and m['served']==m['original'].replace(m['needle'],m['replacement'],1)
  g=json.loads(guard.read_bytes());assert g['status']=='failed'and "'vertex'"in g['failure']['message'];assert 'independent exponent word mismatch'in a['failure']['message']
  rows.append({'record':str(report.relative_to(OUT)),'sha256':sha(report.read_bytes()),'mode':kind,'point':{'vertex':a['vertices'].index(v),'vector':v['vectors'].index(x),'captureSha256':x['sha256'],'failure':x['failure']},'sourceMutation':m,'independentGuard':str(guard.relative_to(OUT)),'guardSha256':sha(guard.read_bytes()),'exitCode':r.returncode})
# A worker's false stored oracle cannot bless genuine bytes from a different source.
p=OUT/'gpu-305419896/report.json';j=json.loads(p.read_bytes());j['acceptance']['vertices'][0]['vectors'][0]['oracles'][0]['word']^=1
fake=OUT/'forged-stored-oracle.json';fake.write_text(json.dumps(j)+'\n');guard=OUT/'forged-stored-oracle-guards.json';r=subprocess.run(['python3','renderer/virgl-shader/tests/exponent-logarithm-capture-regressions.py','--report',str(fake),'--output',str(guard)],capture_output=True);(OUT/'forged-stored-oracle.log').write_bytes(r.stdout+r.stderr);assert r.returncode!=0
result={'status':'passed','recordedPhysicalFaults':rows,'storedOracleSabotage':{'inputSha256':sha(fake.read_bytes()),'exitCode':r.returncode,'failure':json.loads(guard.read_bytes())['failure']},'implementation':json.loads((OUT/'sabotage-source.json').read_bytes()),'testFixture':json.loads((OUT/'test-fixture-sabotage.json').read_bytes())}
(OUT/'sensitivity.json').write_text(json.dumps(result,indent=2)+'\n');print('Six source faults, negative-bound implementation mutation and two false expectations rejected')
