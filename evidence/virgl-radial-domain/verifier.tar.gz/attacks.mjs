import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';

const root=process.cwd(), out=path.resolve('target/evidence/radial-domain-verifier-20261003-fresh');
const imported=p=>import(pathToFileURL(path.join(root,p)));
const {createVirglShaderBridge}=await imported('renderer/virgl-shader/index.mjs');
const {parseConstantDomain,checkRadialBank}=await imported('renderer/virgl-command/constant-domain.mjs');
const fixture=JSON.parse(fs.readFileSync('renderer/virgl-shader/tests/radial-domain-cases.json'));
const bridge=await createVirglShaderBridge({wasmBinary:fs.readFileSync('renderer/virgl-shader/build/wasm/virgl-shader.wasm')});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const buf=new ArrayBuffer(4),dv=new DataView(buf);
const number=w=>{dv.setUint32(0,w,true);return dv.getFloat32(0,true);};
const threshold=number(0x3727c5ac);
const valid=w=>Number.isFinite(number(w))&&Math.abs(number(w))>=threshold;
const f=Math.fround;
const report={schema:'radial-fresh-attacks-v1',status:'running',seed:0xe3d21a77,classification:[],extents:[],graphs:[],metadata:[],ownership:[],combined:[],counterexample:[],sabotage:null};
const explicit=[0,0x80000000,1,0x80000001,0x007fffff,0x807fffff,0x3727c5ab,0x3727c5ac,0x3727c5ad,0xb727c5ab,0xb727c5ac,0xb727c5ad,0x7f800000,0xff800000,0x7fa00123,0xffa00123,0x7fc00123,0xffc00123,0x7f7fffff,0xff7fffff,0x35800000];
let seed=report.seed;
const rnd=()=>{seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return seed>>>0;};
const samples=[...explicit,...Array.from({length:2048},rnd)];
for(const count of [6,46]){
 const words=Array(count*4).fill(0);words[36]=count===46?2:undefined;if(count===6)words.length=count*4;
 for(const coefficient of samples){words[16]=coefficient;const got=checkRadialBank(words,count,count===46);assert.equal(got.ok,valid(coefficient),'independent numeric classification '+coefficient);if(got.ok){assert.notEqual(got.words,words);assert.deepEqual(got.words,words);assert.equal(Object.isFrozen(got.words),true);}report.classification.push({count,coefficient,expected:valid(coefficient),result:got.ok?{ok:true}:got});}
}
for(const [count,counted] of [[4,false],[48,false],[5.5,false],[true,false],[6,true],[46,0],[46,null]]){
 const result=checkRadialBank(Array(184).fill(0),count,counted);assert.equal(result.ok,false);assert.equal(result.error.code,'constant-radial-domain-error');report.extents.push({count,counted,result});
}
{const words=Array(24).fill(0);words[16]=0x3727c5ac;assert.equal(checkRadialBank(words,6).ok,true);}
for(const stage of ['vertex','fragment']){
 const plain=fixture.cases.find(c=>c.name==='plain-'+stage).text;
 const mutations=[
  ['novel-dead-enclosure',plain.replace('MAX TEMP[0].x','UIF IMM[0].yyyy\nMAX TEMP[0].x').replace('ADD TEMP[4]','ENDIF\nADD TEMP[4]'),false],
  ['negated-selector',plain.replace('UIF TEMP[1].xxxx','UIF -TEMP[1].xxxx'),false],
  ['predicate-current-alias',plain.replace('FSLT TEMP[1].x','FSLT TEMP[0].x').replace('UIF TEMP[1].xxxx','UIF TEMP[0].xxxx'),true],
  ['novel-extra-unwritten-else-lane',plain.replace('MOV TEMP[2], CONST[5]','MOV TEMP[2].xyz, CONST[5].xyzx'),false]
 ];
 for(const[name,text,expected]of mutations){
  const native=spawnSync(path.join(root,'target/evidence/radial-domain-worker/probes/native'),[stage],{input:text,encoding:'utf8',env:{...process.env,ASAN_OPTIONS:'abort_on_error=1',UBSAN_OPTIONS:'halt_on_error=1',LLVM_PROFILE_FILE:path.join(out,'independent-%p.profraw')}});
  assert.equal(native.status,0);assert.equal(native.stderr,'');const nr=JSON.parse(native.stdout),result=bridge.translate({stage,text});assert.equal(result.ok,expected,name);assert.deepEqual(result,nr,'full native/Wasm novel attack equality');report.graphs.push({name,stage,text,inputSha256:sha(text),predictedOk:expected,result});
 }
 // Independently exercise every worker-authored graph rejection through the actual compiler.
 for(const row of fixture.cases.filter(c=>c.stage===stage&&!c.ok)){
  const result=bridge.translate({stage,text:row.text});assert.equal(result.ok,false,row.name);assert.equal(result.error.code,'unsupported-feature');report.graphs.push({name:row.name,stage,inputSha256:sha(row.text),predictedOk:false,result});
 }
}
for(const kernel of fixture.kernels){
 const row=fixture.cases.find(c=>c.name===kernel.case),r=bridge.translate({stage:kernel.stage,text:row.text});assert.equal(r.ok,true);const parsed=parseConstantDomain(r.metadata,kernel.stage);assert.equal(parsed.ok,true);assert.deepEqual(parsed.radialDomain,r.metadata.constantRadialDomains[0]);
 const edits=[['delete radial',m=>delete m.constantRadialDomains],['radial bank name',m=>m.constantRadialDomains[0].name='other'],['radial wrong extent',m=>m.constantRadialDomains[0].count++],['radial extra property',m=>m.constantRadialDomains[0].untrusted=1],['delete finite',m=>delete m.constantDomains]];
 for(const key of ['constantAccesses','constantConstraints'])if(Object.hasOwn(r.metadata,key))edits.push(['delete '+key,m=>delete m[key]]);
 for(const[name,edit]of edits){const m=structuredClone(r.metadata);edit(m);const result=parseConstantDomain(m,kernel.stage);assert.equal(result.ok,false,name);assert.equal(result.error.code,'shader-domain-error');report.metadata.push({kernel:kernel.case,name,result});}
 const words=Array(Math.min(kernel.count,46)*4).fill(0);words[16]=0x3f800000;if(parsed.constraint)words[36]=18;
 const approved=checkRadialBank(words,kernel.count,Boolean(parsed.constraint));assert.equal(approved.ok,true);words[16]=0;assert.equal(approved.words[16],0x3f800000);assert.equal(checkRadialBank(words,kernel.count,Boolean(parsed.constraint)).ok,false);report.ownership.push({kernel:kernel.case,approvedCoefficient:approved.words[16],mutatedCoefficient:words[16]});
 if(parsed.constraint){words[16]=0x3f800000;for(const count of [19,0x7f7fffff]){words[36]=count;const result=checkRadialBank(words,kernel.count,true);assert.equal(result.ok,false);assert.equal(result.error.code,'constant-constraint-error');report.combined.push({kernel:kernel.case,count,result});}words[36]=0x80000000;assert.equal(checkRadialBank(words,kernel.count,true).ok,true);}
}
const prior=JSON.parse(fs.readFileSync('target/evidence/radial-domain-worker/native/native-report.json'));
for(const profile of ['virgl-webgl2-straight-line-v5',...Array.from({length:13},(_,i)=>'virgl-webgl2-raw-bits-v'+(i+1))])for(const stage of ['vertex','fragment']){
 const labels=['raw','integer','float','numeric','component','dot','constant','structured','indirect','loop','equality','selected'];
 const row=labels.flatMap(x=>prior[x+'Cases']).find(x=>x.stage===stage&&x.result.ok&&x.result.metadata.profile===profile);assert.ok(row);
 const m=structuredClone(row.result.metadata);m.constantRadialDomains=[{kind:'constant-bank-radial-coefficient-f32-v1',stage,slot:0,name:(stage==='vertex'?'vs':'fs')+'const0',count:6,register:4,component:0,minimumMagnitude:0x3727c5ac}];const result=parseConstantDomain(m,stage);assert.equal(result.ok,false);report.metadata.push({profile,stage,name:'old profile rejects radial',result});
}
for(const missingWord of [0,0x407ffffe]){
 const coefficient=number(0x35800000),q=[4,0],focus=[1,0],B=f(f(q[0]*focus[0])+f(q[1]*focus[1])),C=f(f(q[0]*q[0])+f(q[1]*q[1])),primary=f(f(0.5*C)/B),alternate=f(f(B-number(missingWord))/coefficient),root=primary>1||primary<=0?alternate:primary;
 report.counterexample.push({coefficientWord:0x35800000,missingWord,B,C,primary,alternate,root,transparent:root>1||root<=0});
}
assert.deepEqual(report.counterexample.map(x=>[x.primary,x.root,x.transparent]),[[2,4194304,true],[2,0.5,false]]);
const original=fs.readFileSync('renderer/virgl-command/constant-domain.mjs','utf8'),seam='if (magnitude < 0x3727c5ac)';assert.equal(original.split(seam).length,2);const changed=original.replace(seam,'if (false && magnitude < 0x3727c5ac)'),mutated=path.join(out,'independently-removed-coefficient-check.mjs');fs.writeFileSync(mutated,changed);const fault=await import(pathToFileURL(mutated));
const bank=Array(184).fill(0);bank[16]=0x35800000;bank[36]=2;const normal=checkRadialBank(bank,46,true),wrong=fault.checkRadialBank(bank,46,true);assert.equal(normal.ok,false);assert.equal(wrong.ok,true);let caught=null;try{assert.equal(valid(wrong.words[16]),true,'independent coefficient predicate fails before any GPU call');}catch(error){caught={name:error.name,message:error.message};}assert.equal(caught?.name,'AssertionError');report.sabotage={sourceSha256:sha(original),faultSha256:sha(changed),bank,normal,wrong,caught,gpuCalls:0};
report.status='passed';fs.writeFileSync(path.join(out,'attacks.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,classification:report.classification.length,graphs:report.graphs.length,metadata:report.metadata.length,ownership:report.ownership.length,combined:report.combined.length,sabotage:report.sabotage.caught.name}));
