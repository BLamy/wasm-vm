#!/bin/sh
exec clang -g -fsanitize=address,undefined -fprofile-instr-generate -fcoverage-mapping "$@"
